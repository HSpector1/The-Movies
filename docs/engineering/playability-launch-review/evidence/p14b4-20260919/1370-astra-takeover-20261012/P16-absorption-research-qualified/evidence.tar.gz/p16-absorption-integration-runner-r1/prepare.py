from pathlib import Path
import shutil,json,hashlib,difflib
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=Path('/Users/zacheryspector/studio-specialists/p16');old=A/'p16-held-title-regression-runner-r1';D=Path(__file__).parent;OUT=A/'p16-absorption-integration-r1-run';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in ['auto_freeze.py','account-results.py']:shutil.copyfile(old/p,D/p)
s=(D/'account-results.py').read_text().replace('assert len(files)==len(expected)==8 and total==32','assert expected and total > 0 and len(files)==len(expected)')
s=s.replace("'files':8,'identities':32", "'files':len(expected),'identities':total").replace('heldtitle coherent32; notbroadgate','coherent rights/save and absorption/F17; research excluded; notbroadgate');(D/'account-results.py').write_text(s)
rows=json.loads((old/'EXPECTED-IDENTITIES.json').read_text())
for row in rows:row['sourceSHA256']=sha(K/row['file'])
# Final clean-target revision is awaited: retain original exact names as an explicit unlaunchable draft.
rows+=json.loads((A/'p16-absorption-clean-target-tests-r2/EXPECTED-IDENTITIES.json').read_text())
selection=json.loads((A/'p16-quote-age-tests-r1/SELECTION.json').read_text());rows.append({'file':selection['file'],'sourceSHA256':sha(K/selection['file']),'names':['F17 public bilateral quote-age boundaries from genuine pre162 '+n for n in selection['names'][:6]]+['F17 finite policy pure-unit boundaries (not campaign or absorption execution) '+selection['names'][6]]})
(D/'EXPECTED-IDENTITIES.json').write_text(json.dumps(rows,indent=2)+'\n')
files=[r['file'] for r in rows]
commands=[['node','node_modules/typescript/bin/tsc','--noEmit'],['node','node_modules/typescript/bin/tsc','-p','ui/tsconfig.json','--noEmit'],['node','node_modules/typescript/bin/tsc','-p','tsconfig.bridge.json','--noEmit'],['node','node_modules/vitest/vitest.mjs','run','--project','core','--no-file-parallelism','--no-cache','--reporter=default','--reporter=json','--outputFile.json='+str(OUT/'results.json'),*files]]
(D/'SELECTION.json').write_text(json.dumps(commands,indent=2)+'\n')
b=json.loads((old/'BINDINGS.json').read_text());b.update(package=str(A/'p16-absorption-f17-coherent-r1'),patchSHA256='cdf4e982b0f03747ad0e6e0a3b5033e7b1fc55cfaa50329e5c089cd50cda4c75',manifestSHA256='92b99bb5d7bedb01f1904c11ae29990d351777cf56cd37e54077f1fbd961b9a1',pathCount=153,plannedPathCount=153,scope='root/UI/Bridge then ten complete files; research excluded; no acceptance',expectedCompiledTests={r['file']:r['sourceSHA256'] for r in rows})
assert sha(K/'tests/p16-absorption-clean-target.test.ts')=='56e62de90b84df522373a167d8c3ec7e11dca9937870f0c1c623cdc19fd7c7c4'
b['finalCleanTestAdmission']='reviewed r2 five identities, installed exact56e62de9 by parent';b['researchIncluded']=False
b['installedSourceReceiptSHA256']=sha(A/'P16-ABSORPTION-F17-PARENT-INSTALL-R1.json')
for row in b['artifacts']:
 p=Path(row['path'])
 if p.parent==old and p.name in ['EXPECTED-IDENTITIES.json','account-results.py']:row.update(path=str(D/p.name),sha256=sha(D/p.name))
b['artifacts'] += [{'path':str(p),'sha256':sha(p)} for p in [A/'P16-ABSORPTION-F17-PARENT-INSTALL-R1.json',A/'p16-absorption-root-literal-test-r1/SOURCE.patch',A/'p16-absorption-root-literal-test-r1/MANIFEST.json',A/'p16-quote-age-tests-r1/quote-age.test.ts',A/'p16-quote-age-tests-r1/PINS.json',A/'p16-absorption-clean-target-tests-r2/p16-absorption-clean-target.test.ts',A/'p16-absorption-clean-target-tests-r2/EXPECTED-IDENTITIES.json']]
(D/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace('p16-held-title-regression-r1-run','p16-absorption-integration-r1-run')
s=s.replace('# UNRUN, fail-closed compiler diagnostic. Parent alone binds and launches.','# UNRUN, fail-closed absorption/F17 compiler and complete-file qualification. Parent alone binds and launches.')
a=s.index('commands=[[');z=s.index("for path,pin in b['expectedCompiledTests']",a)
s=s[:a]+'commands='+repr(commands)+"\nneed(json.loads(pathlib.Path(os.environ['SELECTION']).read_text())==commands,'literal threecompiler+tencompletefiles commands')\nneed(b['researchIncluded'] is False,'research excluded until actual extension separately admitted')\nneed('PENDING' not in b['finalCleanTestAdmission'] and all('PENDING' not in pin for pin in b['expectedCompiledTests'].values()),'reviewed final test/identities pending')\nexpected=json.loads((pathlib.Path(os.environ['SCRIPT']).parent/'EXPECTED-IDENTITIES.json').read_text())\nneed([row['file'] for row in expected]==commands[-1][10:],'exact complete-file identity selection')\nneed(all(row['sourceSHA256']==b['expectedCompiledTests'][row['file']] and row['names'] for row in expected),'source identity hashes')\n"+s[z:]
# argv before filepaths has ten fixed elements (node,entry,run,project,core,serial,cache,default,json,output).
s=s.replace("'scope':'rootcompiler and eightcompletefiles32; reviewedheldtitle sourcefix; noacceptance claim'", "'scope':'threecompilers then ten complete rights/save/absorption/F17 files; research excluded; noacceptance claim'")
a=s.index('run tsc-root node');z=s.index('ec=$?;remember estate-red',a)
s=s[:a]+'''# Collect all ordinary compiler diagnostics; no runtime on failed compiler prerequisites.
compile_failure=0
run tsc-root node node_modules/typescript/bin/tsc --noEmit
ec=$?;remember tsc-root "$ec";[ "$ec" -le 2 ] || exit "$ec";[ "$ec" = 0 ] || compile_failure=1
run tsc-ui node node_modules/typescript/bin/tsc -p ui/tsconfig.json --noEmit
ec=$?;remember tsc-ui "$ec";[ "$ec" -le 2 ] || exit "$ec";[ "$ec" = 0 ] || compile_failure=1
run tsc-bridge node node_modules/typescript/bin/tsc -p tsconfig.bridge.json --noEmit
ec=$?;remember tsc-bridge "$ec";[ "$ec" -le 2 ] || exit "$ec";[ "$ec" = 0 ] || compile_failure=1
[ "$compile_failure" = 0 ] || exit 2
run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '''+' '.join(files)+'\n'+s[z:]
(D/'runner.sh').write_text(s);(D/'DELTA-vs-held-regression.diff').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='old/runner.sh',tofile='new/runner.sh')))
print(json.dumps({p:sha(D/p) for p in ['runner.sh','auto_freeze.py','SELECTION.json','BINDINGS.json','EXPECTED-IDENTITIES.json','account-results.py']},indent=2))
