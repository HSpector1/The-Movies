from pathlib import Path
import json,hashlib,difflib
K=Path('/Users/zacheryspector/studio-specialists/p16');A=Path(__file__).parent;files={}
def load(p):
 s=(K/p).read_text();files[p]=[s,s];return s
def save(p,s):files[p][1]=s
files['src/core/quoteAge.ts']=['','''// F17: delegated finite quote-age policy. Quote age is not property or subject age.
// v0 is the explicit interpretation of unstamped retained rows. Never rewrite those rows.
// v1 stamps new producers; max12 absorption preview age is a NEW bounded producer choice,
// aligned with the existing exclusive13-week disclosure lifetime, not recovered old law.
export type QuoteAgeKind = 'bilateralOffer' | 'disclosure' | 'absorptionPreview' | 'estateBid'
export type QuoteAgePolicyVersion = 0 | 1
export const QUOTE_AGE_POLICY_VERSION = 1 as const
const bounds = Object.freeze({
  bilateralOffer: Object.freeze({ min: 0, max: 3 }),
  disclosure: Object.freeze({ min: 0, max: 12 }),
  absorptionPreview: Object.freeze({ min: 0, max: 12 }),
  estateBid: Object.freeze({ min: 0, max: 13 }),
})
export const QUOTE_AGE_POLICIES = Object.freeze({ 0: bounds, 1: bounds })

/** Missing persisted stamps mean historical v0, never an implicit rewrite to v1. */
export function quoteAgeVersionRefusal(version: unknown): string | null {
  return version === undefined || version === 0 || version === 1 ? null : 'unknownQuoteAgePolicyVersion'
}

/** Every current acceptance revalidates finite age, including a retained unstamped v0 row. */
export function quoteAgeRefusal(kind: QuoteAgeKind, quotedAtWeek: number, week: number, version: unknown): string | null {
  const invalid = quoteAgeVersionRefusal(version)
  if (invalid !== null) return invalid
  if (!Number.isSafeInteger(quotedAtWeek) || quotedAtWeek < 0 || !Number.isSafeInteger(week) || week < 0) return 'invalidQuoteWeeks'
  const age = week - quotedAtWeek
  if (age < 0) return 'futureQuote'
  const policy = QUOTE_AGE_POLICIES[version === 1 ? 1 : 0][kind]
  if (age < policy.min) return 'quoteTooYoung'
  return age > policy.max ? 'quoteTooOld' : null
}
''']
p='src/core/rights.ts';s=load(p)
s=s.replace("import { HOLLYWOOD_STARTING_MANIFEST }", "import { QUOTE_AGE_POLICIES, quoteAgeRefusal, quoteAgeVersionRefusal, type QuoteAgePolicyVersion } from './quoteAge.js'\nimport { HOLLYWOOD_STARTING_MANIFEST }")
s=s.replace('export type RightsOffer = {','export type RightsOffer = {\n  /** Absence denotes retained historical v0; new producers stamp v1 without rewriting old rows. */\n  quoteAgePolicyVersion?: QuoteAgePolicyVersion\n  disclosureId?: string | null')
s=s.replace('export type DiligenceRecord = {','export type DiligenceRecord = {\n  quoteAgePolicyVersion?: QuoteAgePolicyVersion')
s=s.replace('export type EstateBid = { id:', 'export type EstateBid = { quoteAgePolicyVersion?: QuoteAgePolicyVersion; id:')
needle="    idNumber(o.id, `${path}.id`)"
s=s.replace(needle,needle+'''
    const versionRefusal = quoteAgeVersionRefusal(o.quoteAgePolicyVersion)
    if (versionRefusal !== null) refuse(path, versionRefusal)
    if (o.quoteAgePolicyVersion === 1 && o.expiresWeek !== o.week + QUOTE_AGE_POLICIES[1].bilateralOffer.max + 1) refuse(path, 'v1 offer expiry must be quote week plus4')
    if (o.quoteAgePolicyVersion === 1 && o.status === 'accepted' && quoteAgeRefusal('bilateralOffer', o.week, o.resolvedWeek!, 1) !== null) refuse(path, 'accepted offer violates its quote age')
    if (o.disclosureId !== undefined && o.disclosureId !== null) {
      const disclosure = rights.diligence.find(d => d.id === o.disclosureId)
      if (disclosure === undefined || disclosure.recipientId !== o.offerorId || disclosure.target.kind !== 'studio' || disclosure.target.studioId !== o.counterpartyId) refuse(path, 'disclosure is not held for this offer')
      if (o.status === 'accepted' && (quoteAgeRefusal('disclosure', disclosure!.week, o.resolvedWeek!, disclosure!.quoteAgePolicyVersion) !== null || o.resolvedWeek! >= disclosure!.staleFromWeek)) refuse(path, 'accepted offer used a stale disclosure')
    }''')
needle="    idNumber(d.id, `${path}.id`)"
s=s.replace(needle,needle+'''
    const versionRefusal = quoteAgeVersionRefusal(d.quoteAgePolicyVersion)
    if (versionRefusal !== null) refuse(path, versionRefusal)
    if (!Number.isSafeInteger(d.week) || d.week < 0 || d.week > tick || !Number.isSafeInteger(d.staleFromWeek) || d.staleFromWeek <= d.week) refuse(path, 'invalid disclosure weeks')
    if (d.quoteAgePolicyVersion === 1 && d.staleFromWeek !== d.week + QUOTE_AGE_POLICIES[1].disclosure.max + 1) refuse(path, 'v1 disclosure expires at quote week plus13')''')
needle="      idNumber(b.id, `estates[${i}].bids[${j}].id`)"
s=s.replace(needle,needle+'''
      const versionRefusal = quoteAgeVersionRefusal(b.quoteAgePolicyVersion)
      if (versionRefusal !== null) refuse(`estates[${i}].bids[${j}]`, versionRefusal)
      if (b.quoteAgePolicyVersion === 1 && b.status === 'won' && quoteAgeRefusal('estateBid', b.week, e.closedWeek!, 1) !== null) refuse(`estates[${i}].bids[${j}]`, 'winning bid violates its quote age')''');save(p,s)
p='src/core/assetSale.ts';s=load(p);s="import { QUOTE_AGE_POLICIES, QUOTE_AGE_POLICY_VERSION, quoteAgeRefusal } from './quoteAge.js'\n"+s
s=s.replace("  return week >= record.staleFromWeek ? 'staleDisclosure' : null", "  const age = quoteAgeRefusal('disclosure', record.week, week, record.quoteAgePolicyVersion)\n  return age !== null ? age : week >= record.staleFromWeek ? 'staleDisclosure' : null")
s=s.replace('const offer: RightsOffer = { id:', "const offer: RightsOffer = { quoteAgePolicyVersion: QUOTE_AGE_POLICY_VERSION, disclosureId: input.disclosureId ?? null, id:")
s=s.replace('  const buyer = buyerOf(offer)\n  const permitted', "  const age = quoteAgeRefusal('bilateralOffer', offer.week, week, offer.quoteAgePolicyVersion)\n  if (age !== null) return age\n  const disclosure = disclosureRefusal(state, offer.offerorId, offer.counterpartyId, offer.disclosureId, week)\n  if (disclosure !== null) return disclosure\n  const buyer = buyerOf(offer)\n  const permitted",1)
s=s.replace('expiresWeek: week + TUNING.RIGHTS_OFFER_DURATION_WEEKS', 'expiresWeek: week + QUOTE_AGE_POLICIES[QUOTE_AGE_POLICY_VERSION].bilateralOffer.max + 1')
save(p,s)
p='src/core/dueDiligence.ts';s=load(p);s="import { QUOTE_AGE_POLICIES, QUOTE_AGE_POLICY_VERSION } from './quoteAge.js'\n"+s
s=s.replace('const record: DiligenceRecord = { id:', 'const record: DiligenceRecord = { quoteAgePolicyVersion: QUOTE_AGE_POLICY_VERSION, id:').replace('staleFromWeek: week + TUNING.RIGHTS_DISCLOSURE_STALE_WEEKS', 'staleFromWeek: week + QUOTE_AGE_POLICIES[QUOTE_AGE_POLICY_VERSION].disclosure.max + 1');save(p,s)
p='src/core/estate.ts';s=load(p);s="import { QUOTE_AGE_POLICY_VERSION, quoteAgeRefusal } from './quoteAge.js'\n"+s
s=s.replace('const bid: EstateBid = { id:', 'const bid: EstateBid = { quoteAgePolicyVersion: QUOTE_AGE_POLICY_VERSION, id:')
s=s.replace('      const permitted = permittedBidderRefusal(next, bid.bidderId, week, readers)', "      const quoteAge = quoteAgeRefusal('estateBid', bid.week, week, bid.quoteAgePolicyVersion)\n      const permitted = permittedBidderRefusal(next, bid.bidderId, week, readers)")
s=s.replace('const refusal = encumbered !== null ? encumbered : permitted', 'const refusal = quoteAge !== null ? quoteAge : encumbered !== null ? encumbered : permitted');save(p,s)
p='src/core/acquisition.ts';s=load(p);s="import { QUOTE_AGE_POLICY_VERSION, quoteAgeRefusal, type QuoteAgePolicyVersion } from './quoteAge.js'\n"+s
s=s.replace('export type AbsorptionInput = { buyerId:', 'export type AbsorptionInput = { quotedAtWeek?: number; quoteAgePolicyVersion?: QuoteAgePolicyVersion; buyerId:')
s=s.replace("  kind: 'quote'\n  buyerId:", "  kind: 'quote'\n  quotedAtWeek: number; quoteAgePolicyVersion: QuoteAgePolicyVersion\n  buyerId:")
s=s.replace("  if (week < record.week || week >= record.staleFromWeek) return 'staleDisclosure'", "  const age = quoteAgeRefusal('disclosure', record.week, week, record.quoteAgePolicyVersion)\n  if (age !== null) return age\n  if (week >= record.staleFromWeek) return 'staleDisclosure'")
i=s.index('/** r2 (F8/F33)')
s=s[:i]+'''/** Close must carry the dated preview; re-quoting current facts never renews an old preview. */
export function absorptionQuoteAgeRefusal(input: AbsorptionInput, week: number, requireCarried: boolean): string | null {
  if (input.quotedAtWeek === undefined && input.quoteAgePolicyVersion === undefined) return requireCarried ? 'absorptionQuoteRequired' : null
  if (input.quotedAtWeek === undefined || input.quoteAgePolicyVersion === undefined) return 'incompleteAbsorptionQuote'
  return quoteAgeRefusal('absorptionPreview', input.quotedAtWeek, week, input.quoteAgePolicyVersion)
}

'''+s[i:]
s=s.replace('  const refusal = absorptionRefusal(state,', "  const age = absorptionQuoteAgeRefusal(input, week, false)\n  if (age !== null) return { kind: 'refusal', refusal: age }\n  const refusal = absorptionRefusal(state,",1)
s=s.replace("return { kind: 'quote', buyerId:", "return { kind: 'quote', quotedAtWeek: input.quotedAtWeek ?? week, quoteAgePolicyVersion: input.quoteAgePolicyVersion ?? QUOTE_AGE_POLICY_VERSION, buyerId:",1)
s=s.replace('  throw new Error(`absorption closing of', "  const age = absorptionQuoteAgeRefusal(input, week, true)\n  if (age !== null) throw new Error(`absorption closing refused: ${age}`)\n  throw new Error(`absorption closing of",1);save(p,s)
patch=[];rows=[]
for p,(old,new) in files.items():
 for sub,data in [('preimages',old),('postimages',new)]:
  q=A/sub/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(data)
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=('/dev/null' if old=='' else 'a/'+p),tofile='b/'+p))
 rows.append({'path':p,'newFile':old=='','preSHA256':hashlib.sha256(old.encode()).hexdigest(),'postSHA256':hashlib.sha256(new.encode()).hexdigest()})
(A/'SOURCE.patch').write_text(''.join(patch));(A/'MANIFEST.json').write_text(json.dumps({'status':'UNRUN A-only F17 source draft','files':rows},indent=2)+'\n')
print(json.dumps({p:hashlib.sha256((A/p).read_bytes()).hexdigest() for p in ['SOURCE.patch','MANIFEST.json']},indent=2))
