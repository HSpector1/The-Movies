from pathlib import Path
import hashlib,json,difflib
K=Path('/Users/zacheryspector/studio-specialists/p16'); A=Path(__file__).parent
changes={}
def load(p):
 s=(K/p).read_text(); changes[p]=[s,s]; return s
def save(p,s): changes[p][1]=s
p='src/core/economyView.ts';s=load(p)
s=s.replace('TheatricalRun, LedgerKind }','TheatricalRun, LedgerKind, LedgerEntry }')
s=s.replace('  financing: number // P15B (1357-A', '  rights: number // Signed ordinary rights sales, purchases and licence fees\n  estatePurchases: number // Buyer ledger debits only; proceeds remain in the P15 estate account\n  acquisition: number // Signed acquisition outlay, including actual target cash at par\n  diligence: number // Actual due diligence fees, separate from ordinary overhead\n  financing: number // P15B (1357-A',1)
s=s.replace('  financing: 0,\n  net: 0,','  rights: 0,\n  estatePurchases: 0,\n  acquisition: 0,\n  diligence: 0,\n  financing: 0,\n  net: 0,',1)
a=s.index('  // P16 (Save49): a library');b=s.index('\n}',a)
s=s[:a]+'''  // F40: retained cash owners have separate reporting homes, not building capex/overhead.
  rightsConsideration: 'rights',
  acquisitionOutlay: 'acquisition',
  dueDiligenceFee: 'diligence','''+s[b:]
anchor='// Aggregate the whole signed ledger by kind.'
i=s.index(anchor)
s=s[:i]+'''/** Classify buyer consideration from the actual keyed estateSale receipt, never its description. */
export function estatePurchaseClassifier(state: GameState): (entry: LedgerEntry) => boolean {
  const player = state.hollywood?.playerStudioId
  const transactions = new Map((state.rights?.transactions ?? [])
    .filter(t => t.kind === 'estateSale' && t.payerId === player)
    .map(t => [t.id, t] as const))
  return entry => {
    if (entry.kind !== 'rightsConsideration') return false
    const transaction = transactions.get(entry.note)
    return transaction !== undefined && transaction.week === entry.week && -transaction.amount === entry.amount
  }
}

'''+s[i:]
s=s.replace('  const t = ZERO_TOTALS()\n  for','  const t = ZERO_TOTALS()\n  const estatePurchase = estatePurchaseClassifier(state)\n  for',1).replace('    t[KIND_FIELD[e.kind]] += e.amount','    t[estatePurchase(e) ? \'estatePurchases\' : KIND_FIELD[e.kind]] += e.amount',1)
s=s.replace('  financing: number // P15B: loan principal','  // Optional only for retained pre-F40 UI receipts. New engine summaries always supply all four.\n  rights?: number\n  estatePurchases?: number\n  acquisition?: number\n  diligence?: number\n  financing: number // P15B: loan principal',1)
s=s.replace('    financing: 0,\n    otherCash: 0,','    rights: 0,\n    estatePurchases: 0,\n    acquisition: 0,\n    diligence: 0,\n    financing: 0,\n    otherCash: 0,',1)
s=s.replace('  for (const e of state.ledger) {\n    if (e.week < fromWeek','  const estatePurchase = estatePurchaseClassifier(state)\n  for (const e of state.ledger) {\n    if (e.week < fromWeek',1)
a=s.index('      // P16 (Save49): rights consideration');b=s.index('      default: {',a)
s=s[:a]+'''      case 'rightsConsideration':
        if (estatePurchase(e)) s.estatePurchases = (s.estatePurchases ?? 0) + e.amount
        else s.rights = (s.rights ?? 0) + e.amount
        break
      case 'acquisitionOutlay':
        s.acquisition = (s.acquisition ?? 0) + e.amount
        break
      case 'dueDiligenceFee':
        s.diligence = (s.diligence ?? 0) + e.amount
        break
'''+s[b:];save(p,s)
p='src/core/financeReport.ts';s=load(p).replace("import { financeView }","import { estatePurchaseClassifier, financeView }")
s=s.replace('export type FinanceCategory = { kind: LedgerKind;', "// A reporting category, not a new ledger kind or cash authority.\nexport type FinanceCategoryKind = LedgerKind | 'estatePurchase'\nconst CATEGORY_LABELS: Record<FinanceCategoryKind, string> = { ...FINANCE_CATEGORIES, estatePurchase: 'Estate asset purchases (proceeds paid to the estate)' }\nexport type FinanceCategory = { kind: FinanceCategoryKind;")
s=s.replace('kind: LedgerKind; label: string; periodAmount:', 'kind: FinanceCategoryKind; label: string; periodAmount:')
s=s.replace('Map<LedgerKind, FinanceCategory>','Map<FinanceCategoryKind, FinanceCategory>')
s=s.replace('function addCategory(byKind: Map<FinanceCategoryKind, FinanceCategory>, entry: LedgerEntry): void {\n  const category = byKind.get(entry.kind) ?? { kind: entry.kind, label: FINANCE_CATEGORIES[entry.kind], amount: 0, entryCount: 0 }', "function addCategory(byKind: Map<FinanceCategoryKind, FinanceCategory>, entry: LedgerEntry, estatePurchase: (entry: LedgerEntry) => boolean): void {\n  const kind: FinanceCategoryKind = estatePurchase(entry) ? 'estatePurchase' : entry.kind\n  const category = byKind.get(kind) ?? { kind, label: CATEGORY_LABELS[kind], amount: 0, entryCount: 0 }")
s=s.replace('  byKind.set(entry.kind, category)','  byKind.set(category.kind, category)')
s=s.replace('  const checkpoint = state.cashLedgerCheckpoint', '  const estatePurchase = estatePurchaseClassifier(state)\n  const checkpoint = state.cashLedgerCheckpoint')
s=s.replace('  const estatePurchase = estatePurchaseClassifier(state)\n  const checkpoint = state.cashLedgerCheckpoint', '  const checkpoint = state.cashLedgerCheckpoint', 1)
s=s.replace('  const safeOffset =', '  const estatePurchase = estatePurchaseClassifier(state)\n  const safeOffset =', 1)
s=s.replace('addCategory(byKind, entry)','addCategory(byKind, entry, estatePurchase)').replace('addCategory(weekCategories, entry)','addCategory(weekCategories, entry, estatePurchase)').replace('addCategory(categories, entry)','addCategory(categories, entry, estatePurchase)')
s=s.replace('(Object.keys(FINANCE_CATEGORIES) as LedgerKind[])','(Object.keys(CATEGORY_LABELS) as FinanceCategoryKind[])').replace('kind, label: FINANCE_CATEGORIES[kind],','kind, label: CATEGORY_LABELS[kind],')
s=s.replace('categoryLabel: FINANCE_CATEGORIES[entry.kind]', "categoryLabel: CATEGORY_LABELS[estatePurchase(entry) ? 'estatePurchase' : entry.kind]")
save(p,s)
p='ui/src/lot/snapshot/nextEvent.ts';s=load(p)
s=s.replace('const SUMMARY_MONEY_KEYS = [', "const P16_SUMMARY_KEYS = ['rights', 'estatePurchases', 'acquisition', 'diligence'] as const\n\nconst SUMMARY_MONEY_KEYS = [")
s=s.replace('if (!isRecord(value) || !hasExactOwnKeys(value, SUMMARY_KEYS)) return false', 'if (!isRecord(value)) return false\n  const modern = hasExactOwnKeys(value, [...SUMMARY_KEYS, ...P16_SUMMARY_KEYS])\n  if (!modern && !hasExactOwnKeys(value, SUMMARY_KEYS)) return false\n  if (modern && P16_SUMMARY_KEYS.some(key => !isFiniteNumber(value[key]))) return false')
s=s.replace('    financing: summary.financing,', '    ...(summary.rights === undefined ? {} : { rights: summary.rights, estatePurchases: summary.estatePurchases, acquisition: summary.acquisition, diligence: summary.diligence }),\n    financing: summary.financing,')
# exactOptionalPropertyTypes: copy only after all-four presence, old input retains original shape.
s=s.replace('summary.rights === undefined', 'summary.rights === undefined || summary.estatePurchases === undefined || summary.acquisition === undefined || summary.diligence === undefined')
save(p,s)
p='ui/src/lot/LotNextEventRail.tsx';s=load(p).replace('    { label: "Studio construction", value: summary.construction },','    { label: "Studio construction", value: summary.construction },\n    { label: "Rights trades and licences", value: summary.rights ?? 0 },\n    { label: "Estate asset purchases", value: summary.estatePurchases ?? 0 },\n    { label: "Acquisition net cash", value: summary.acquisition ?? 0 },\n    { label: "Due diligence fees", value: summary.diligence ?? 0 },');s=s.replace('    { label: \"Rights trades and licences\", value: summary.rights ?? 0 },', '    ...(summary.rights === undefined ? [] : [{ label: \"Rights trades and licences\", value: summary.rights },')
s=s.replace('    { label: \"Due diligence fees\", value: summary.diligence ?? 0 },', '    { label: \"Due diligence fees\", value: summary.diligence ?? 0 }]),')
save(p,s)
for p,prefix,obj in [('ui/src/screens/Dashboard.tsx','fin','fin.totals'),('ui/src/screens/WeeklySummary.tsx','sum','summary')]:
 s=load(p);needle='          <Metric label="Studio construction"'
 a=s.index(needle);b=s.index('          </Metric>',a)+len('          </Metric>')
 extra=''
 for field,label in [('rights','Rights trades and licences'),('estatePurchases','Estate asset purchases'),('acquisition','Acquisition net cash'),('diligence','Due diligence fees')]:
  value=f'{obj}.{field}' if prefix=='fin' else f'({obj}.{field} ?? 0)'
  extra+=f'\n          <Metric label="{label}" small testid="{prefix}-{field}">\n            {{money({value})}}\n          </Metric>'
 if prefix == 'sum': extra='\n          {summary.rights !== undefined && <> '+extra+'\n          </>}'
 s=s[:b]+extra+s[b:];save(p,s)
p='src/core/financeReport.ts';s=changes[p][1]
s += """
/** Own closed-studio accounting only. These are retained P15 amounts, not operating cash or rival disclosure. */
export function ownedEstateFinance(state: GameState) {
  const player = state.hollywood?.playerStudioId
  const closure = state.studioClosure?.closures.find(c => c.studioId === player)
  if (closure === undefined) return null
  const events = state.studioClosure.estateEvents.filter(e => e.closureId === closure.closureId)
  const claims = state.studioClosure.claims.filter(c => c.closureId === closure.closureId)
  return {
    closureId: closure.closureId, closureWeek: closure.closureWeek,
    closingCash: closure.cash.closing,
    runReceipts: events.filter(e => e.kind === 'runReceipt').reduce((sum, e) => sum + e.amount, 0),
    saleProceeds: events.filter(e => e.kind === 'saleReceipt').reduce((sum, e) => sum + e.amount, 0),
    claimPayments: claims.reduce((sum, c) => sum + c.paid, 0),
    unpaidClaims: claims.reduce((sum, c) => sum + c.unpaid, 0),
    stoppedLoanRemainder: closure.loan?.remainder ?? 0,
    basis: 'Retained P15 closure cash, actual estate receipts and claim payments. Estate proceeds are not operating studio revenue; unpaid loan remainder is not assumed by a buyer.',
  }
}
"""
save(p,s)
p='bridge/finance.ts';s=load(p).replace('financeHistory, financeOverview','financeHistory, financeOverview, ownedEstateFinance')
s=s.replace('  return { ...overview, employees, facilities, films, upcoming:', '  return { ...overview, estateAccounting: ownedEstateFinance(state), employees, facilities, films, upcoming:')
save(p,s)
p='bridge/schema/bridge-schema.ts';s=load(p).replace('export const PROJECTION_VERSION = 58 as const', '// Projection59: separate F40 finance categories and own retained estate accounting. Protocol4 is unchanged.\nexport const PROJECTION_VERSION = 59 as const')
s=s.replace("const StudioFinanceSnapshot = object('StudioFinanceSnapshot', {", """const StudioFinanceEstateAccounting = object('StudioFinanceEstateAccounting', {
  closureId: nonEmptyText(), closureWeek: nonNegativeInteger(), closingCash: number(),
  runReceipts: number({ minimum: 0 }), saleProceeds: number({ minimum: 0 }),
  claimPayments: number({ minimum: 0 }), unpaidClaims: number({ minimum: 0 }),
  stoppedLoanRemainder: number({ minimum: 0 }), basis: nonEmptyText(),
})
const StudioFinanceSnapshot = object('StudioFinanceSnapshot', {
  estateAccounting: nullable(reference('StudioFinanceEstateAccounting', StudioFinanceEstateAccounting)),""")
s=s.replace('  StudioFinanceCostSeries,', '  StudioFinanceEstateAccounting,\n  StudioFinanceCostSeries,')
save(p,s)
p='bridge/runtime-checkpoint.ts';s=load(p)
s=s.replace('export const SUPPORTED_PRIOR_PROTOCOL_4_SCHEMA_IDS: ReadonlyMap<string, string> = new Map<string, string>([', "export const SUPPORTED_PRIOR_PROTOCOL_4_SCHEMA_IDS: ReadonlyMap<string, string> = new Map<string, string>([\n  // Actual shipped P15B projection58, before the F40 presentation boundary.\n  ['sha256:13b7933fdd1e3dc9851dd08630e46efd43e70227f5e0c6f6cf130d885752ab74', 'projection-v58'],")
save(p,s)

patch=[];manifest=[]
for p,(old,new) in changes.items():
 before=A/'preimages'/p;after=A/'postimages'/p;before.parent.mkdir(parents=True,exist_ok=True);after.parent.mkdir(parents=True,exist_ok=True);before.write_text(old);after.write_text(new)
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 manifest.append({'path':p,'preSha256':hashlib.sha256(old.encode()).hexdigest(),'postSha256':hashlib.sha256(new.encode()).hexdigest()})
(A/'SOURCE.patch').write_text(''.join(patch));(A/'MANIFEST.json').write_text(json.dumps({'status':'UNRUN A-only source draft','files':manifest},indent=2)+'\n')
print(json.dumps({'patch':hashlib.sha256((A/'SOURCE.patch').read_bytes()).hexdigest(),'manifest':hashlib.sha256((A/'MANIFEST.json').read_bytes()).hexdigest(),'paths':list(changes)},indent=2))
