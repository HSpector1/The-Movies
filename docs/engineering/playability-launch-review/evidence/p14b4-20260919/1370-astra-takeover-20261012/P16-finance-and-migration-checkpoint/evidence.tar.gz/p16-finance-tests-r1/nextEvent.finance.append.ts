// F40 retained receipt compatibility through the real acceptance boundary.
import { expect,it } from 'vitest'
import { newFoundedGame } from '../../test/founding.ts'
import { advanceWeek } from '../../engine/adapter.ts'
import { acceptedLotNextEventReceipt } from './nextEvent.ts'
const keys=['rights','estatePurchases','acquisition','diligence'] as const
it('F40 accepts all four actual summary fields and retained old shape while refusing partial mixed and extra receipt fields',()=>{
 const initial=newFoundedGame('f40-receipt-shapes'),result=advanceWeek(initial)
 for(const key of keys)expect(Number.isFinite(result.summary[key])).toBe(true)
 const modern=acceptedLotNextEventReceipt(initial,result)
 expect(modern).not.toBeNull()
 for(const key of keys)expect(modern!.summary[key]).toBe(result.summary[key])
 const oldSummary={...result.summary}
 for(const key of keys)delete oldSummary[key]
 const old=acceptedLotNextEventReceipt(initial,{...result,summary:oldSummary})
 expect(old).not.toBeNull()
 for(const key of keys)expect(Object.hasOwn(old!.summary,key)).toBe(false)
 for(const missing of keys) {
  const partial={...result.summary};delete partial[missing]
  expect(acceptedLotNextEventReceipt(initial,{...result,summary:partial})).toBeNull()
 }
 const mixed={...oldSummary,rights:0}
 expect(acceptedLotNextEventReceipt(initial,{...result,summary:mixed})).toBeNull()
 const extra={...result.summary,foreignFinanceKey:0}
 expect(acceptedLotNextEventReceipt(initial,{...result,summary:extra})).toBeNull()
 for(const key of keys) {
  const invalid={...result.summary,[key]:Number.NaN}
  expect(acceptedLotNextEventReceipt(initial,{...result,summary:invalid})).toBeNull()
 }
 const original=result.summary.rights
 modern!.summary.rights=123456
 expect(result.summary.rights).toBe(original) // accepted output is detached, no result mutation.
})
