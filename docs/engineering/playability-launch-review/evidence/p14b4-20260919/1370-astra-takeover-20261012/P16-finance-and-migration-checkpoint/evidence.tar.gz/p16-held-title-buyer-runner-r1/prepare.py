from pathlib import Path
import json,hashlib,shutil,difflib
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');old=A/'p16-held-title-regression-runner-r1';new=A/'p16-held-title-buyer-runner-r1';new.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['auto_freeze.py','account-results.py','extract-identities.cjs']:shutil.copyfile(old/name,new/name)
account=(new/'account-results.py').read_text().replace('len(expected)==8 and total==32','len(expected)==1 and total==1');(new/'account-results.py').write_text(account)
test=A/'p16-held-title-tests-r2/p16-held-title-buyer-public.test.ts';testsha=sha(test)
name='real purchased R04film0 survives four fixed public campaigns and joins actual buyer closure without changing creator history';file='tests/p16-held-title-buyer-public.test.ts'
expected=[{'file':file,'sourceSHA256':testsha,'names':[name]}];(new/'EXPECTED-IDENTITIES.json').write_text(json.dumps(expected,indent=2)+'\n')
out=A/'p16-held-title-buyer-r1-run';commands=[['node','node_modules/vitest/vitest.mjs','run','--project','core','--no-file-parallelism','--no-cache','--reporter=default','--reporter=json','--outputFile.json='+str(out/'results.json'),file]]
(new/'SELECTION.json').write_text(json.dumps(commands,indent=2)+'\n')
b=json.loads((old/'BINDINGS.json').read_text());oldpackage=b['package'];oldpatch=b['patchSHA256'];oldmanifest=b['manifestSHA256'];oldcount=b['pathCount']
b.update(package='PENDING_FINAL128_PACKAGE',patchSHA256='PENDING',manifestSHA256='PENDING',pathCount='PENDING',plannedPathCount=128,scope='single complete buyer-public file1; unchanged127 product root0 reused, new test compiler status separate',expectedCompiledTests={file:testsha})
b['productCompilerReuse']={'package':oldpackage,'patchSHA256':oldpatch,'manifestSHA256':oldmanifest,'pathCount':oldcount,'result':str(A/'p16-held-title-regression-r1-run/results.jsonl'),'qualifiedRootSeconds':46,'newTest':file}
for row in b['artifacts']:
 p=Path(row['path'])
 if p.parent==old:
  row['path']=str(new/p.name);row['sha256']=sha(new/p.name)
b['artifacts'] += [{'path':str(p),'sha256':sha(p)} for p in [test,A/'p16-held-title-regression-r1-run/results.jsonl',A/'p16-held-title-regression-r1-run/tsc-root.log',Path(oldpackage)/'MANIFEST.json',Path(oldpackage)/'PATCH.diff']]
(new/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
s=(old/'runner.sh').read_text().replace(str(old),str(new)).replace('p16-held-title-regression-r1-run','p16-held-title-buyer-r1-run')
s=s.replace('# UNRUN, fail-closed compiler diagnostic. Parent alone binds and launches.','# UNRUN, fail-closed one-file buyer-public diagnostic. Parent alone binds and launches.')
a=s.index('commands=[[');z=s.index("for path,pin in b['expectedCompiledTests']",a)
s=s[:a]+"commands="+repr(commands)+"\nneed(json.loads(pathlib.Path(os.environ['SELECTION']).read_text())==commands,'literal one complete buyer file command')\n"+s[z:]
a=s.index('\nsubprocess.run(g+');s=s[:a]+'''
reuse=b['productCompilerReuse'];prior=pathlib.Path(reuse['package'])
need(sha(prior/'PATCH.diff')==reuse['patchSHA256'] and sha(prior/'MANIFEST.json')==reuse['manifestSHA256'],'reused product packet pins')
oldm=json.loads((prior/'MANIFEST.json').read_text());current={f['path']:f for f in m['files']}
need(len(oldm['files'])==reuse['pathCount']==127,'prior product count')
need(set(current)=={f['path'] for f in oldm['files']}|{reuse['newTest']} and len(current)==128,'only one new test delta')
for f in oldm['files']:
 need(current[f['path']]['sha256']==f['sha256'] and current[f['path']]['mode']==f['mode'],'unchanged qualified product '+f['path'])
records=[json.loads(line) for line in pathlib.Path(reuse['result']).read_text().splitlines()]
roots=[row for row in records if row['name']=='tsc-root']
need(len(roots)==1 and roots[0]['exit']==0 and roots[0]['seconds']==46 and roots[0]['node']=='v20.20.2' and roots[0]['command']==['node','node_modules/typescript/bin/tsc','--noEmit'],'actual prior root0 receipt')
''' +s[a:]
s=s.replace("'scope':'rootcompiler and eightcompletefiles32; reviewedheldtitle sourcefix; noacceptance claim'", "'scope':'single complete buyer-public file1; prior product root0 reused; newtest compilation unclaimed; noacceptance claim'")
a=s.index('run tsc-root node');z=s.index('ec=$?;remember estate-red',a)
s=s[:a]+'''# Product root0 is reused only after exact127 postimage/mode agreement above.
# This new test was not included in that compiler invocation; parent qualifies its types separately.
run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" tests/p16-held-title-buyer-public.test.ts
'''+s[z:]
(new/'runner.sh').write_text(s)
(new/'DELTA-vs-regression.diff').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='regression/runner.sh',tofile='buyer/runner.sh')))
(new/'README.md').write_text('''UNRUN focused buyer-public route, one complete file / one default5000ms leaf. No root compiler repeat. Parent installs/binds final128 packet, reviews four external bootstrap hashes, and alone launches via existing lane. Final packet pins remain PENDING and fail closed. Current draft test SHA is in EXPECTED-IDENTITIES/BINDINGS; parent must confirm final import-cleaned test bytes before binding.

Reuses actual127r2 root0/46s only for unchanged127 product postimages and modes; admission proves the new128 packet differs solely by the added test. It does NOT claim the new test compiled in that previous root command. Existing source/config/index/HEAD/metadata and dependency/capture/input strict freeze remains; retained R04 and R03 proof bindings unchanged, no setup moved outside the leaf. Child exit, reporter identity/count/status/full diagnostics and duration accounting remain distinct from wrapper; reported PASS over5000ms stays unqualified. No filter, fallback, budget widening or guaranteed route acceptance.

Required launch is parent-owned lane-run-r8.sh with the runner as owned child, explicit P16_BOOTSTRAP_SCRIPT_SHA256, AUTO_HELPER, SELECTION and BINDINGS hashes. No compiler, test, engine or generator executed to author this derivative; K/R/index/HANDOFF untouched. bash -n is the only script validation.
''')
print(json.dumps({k:sha(new/k) for k in ['runner.sh','auto_freeze.py','SELECTION.json','BINDINGS.json','EXPECTED-IDENTITIES.json','account-results.py']},indent=2))
