import { readFileSync } from 'node:fs'
import { gunzipSync } from 'node:zlib'
import {managedStudio as createManagedBridgeState} from './contracts/_contractFixtures.js'
import { createHash } from 'node:crypto'

import { describe, expect, it } from 'vitest'

import {
  BRIDGE_RUNTIME_CHECKPOINT_FORMAT,
  BRIDGE_RUNTIME_CHECKPOINT_VERSION,
  BridgeRuntimeCheckpointError,
  LEGACY_BRIDGE_RUNTIME_PROTOCOL_VERSION,
  LEGACY_BRIDGE_RUNTIME_SCHEMA_ID,
  PREVIOUS_BRIDGE_RUNTIME_PROTOCOL_4_SCHEMA_ID,
  SUPPORTED_PRIOR_PROTOCOL_4_SCHEMA_IDS,
  appendBridgeRuntimeJournalEntry,
  createBridgeRuntimeCheckpoint,
  createBridgeRuntimeJournalEntry,
  decodeBridgeRuntimeCheckpoint,
  encodeBridgeRuntimeCheckpoint,
  hydrateBridgeRuntimeCheckpoint,
  loadBridgeRuntimeCheckpoint,
  type BridgeRuntimeCheckpointLimits,
  type BridgeRuntimeCheckpointV1,
  type BridgeRuntimeJournalEntryV1,
} from '../bridge/runtime-checkpoint.ts'
import {
  PROTOCOL_VERSION,
  SCHEMA_ID,
  type ControlEnvelope,
  type SubmitIntentCommand,
} from '../bridge/protocol.ts'
import {
  BridgeSession,
  createBridgeInitialState,
} from '../bridge/session.ts'
import { canonicalJson } from '../bridge/schema/canonical.ts'
import { exportSaveJson } from '../ui/src/engine/adapter.ts'
import { LIVE_SAVE_VERSION, exportSave, makeSaveV14 } from '../src/core/index.js'
import * as shipped47Save from '../src/core/save.js'
import { accepted45 } from './helpers/1368-recovery-witnesses.js'

function sha256(value: string): string {
  return createHash('sha256').update(value, 'utf8').digest('hex')
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

type Fixture = {
  checkpoint: BridgeRuntimeCheckpointV1
  commandEntry: BridgeRuntimeJournalEntryV1
  saveEntry: BridgeRuntimeJournalEntryV1
  currentSaveJson: string
  savedSaveJson: string
}

function fixture(): Fixture {
  const session = new BridgeSession(
    createBridgeInitialState('bridge-runtime-checkpoint'),
    'bridge-runtime-checkpoint-session',
  )
  const option = session.snapshot().availableIntents.find(
    (candidate) => candidate.kind === 'commissionScreenplay',
  )
  if (option === undefined) throw new Error('Checkpoint fixture omitted commission intent.')
  const command: SubmitIntentCommand = {
    protocolVersion: PROTOCOL_VERSION,
    schemaId: SCHEMA_ID,
    sessionId: session.sessionId,
    commandId: 'checkpoint-command',
    expectedStateRevision: session.stateRevision,
    type: 'submitIntent',
    payload: { intentId: option.intentId },
  }
  const commandResponse = session.command(command)
  if (!commandResponse.accepted) throw new Error(commandResponse.message)
  const commandEntry = createBridgeRuntimeJournalEntry('command', command, commandResponse)

  const saveControl: ControlEnvelope = {
    protocolVersion: PROTOCOL_VERSION,
    schemaId: SCHEMA_ID,
    sessionId: session.sessionId,
    commandId: 'checkpoint-save',
    expectedStateRevision: session.stateRevision,
  }
  const saveResponse = session.save(saveControl)
  if (!saveResponse.accepted) throw new Error(saveResponse.message)
  const saveEntry = createBridgeRuntimeJournalEntry('save', saveControl, saveResponse)
  const currentSaveJson = exportSaveJson(session.gameState)
  const checkpoint = createBridgeRuntimeCheckpoint({
    sessionId: session.sessionId,
    stateRevision: session.stateRevision,
    currentSaveJson,
    savedSaveJson: saveResponse.saveJson,
    journal: [commandEntry, saveEntry],
  })
  return {
    checkpoint,
    commandEntry,
    saveEntry,
    currentSaveJson,
    savedSaveJson: saveResponse.saveJson,
  }
}

function protocol3Bytes(checkpoint: BridgeRuntimeCheckpointV1): string {
  const journal = checkpoint.journal.map((entry) => {
    const request = JSON.parse(entry.requestJson) as Record<string, unknown>
    const response = JSON.parse(entry.responseJson) as Record<string, unknown>
    request.protocolVersion = LEGACY_BRIDGE_RUNTIME_PROTOCOL_VERSION
    request.schemaId = LEGACY_BRIDGE_RUNTIME_SCHEMA_ID
    response.protocolVersion = LEGACY_BRIDGE_RUNTIME_PROTOCOL_VERSION
    response.schemaId = LEGACY_BRIDGE_RUNTIME_SCHEMA_ID
    return {
      ...entry,
      requestJson: canonicalJson(request),
      responseJson: canonicalJson(response),
    }
  })
  const legacy = {
    ...checkpoint,
    protocolVersion: LEGACY_BRIDGE_RUNTIME_PROTOCOL_VERSION,
    schemaId: LEGACY_BRIDGE_RUNTIME_SCHEMA_ID,
    journalDigest: sha256(canonicalJson(journal)),
    journal,
  }
  return `${canonicalJson(legacy)}\n`
}

function previousProtocol4Bytes(checkpoint: BridgeRuntimeCheckpointV1): string {
  const journal = checkpoint.journal.map((entry) => {
    const request = JSON.parse(entry.requestJson) as Record<string, unknown>
    const response = JSON.parse(entry.responseJson) as Record<string, unknown>
    request.schemaId = PREVIOUS_BRIDGE_RUNTIME_PROTOCOL_4_SCHEMA_ID
    response.schemaId = PREVIOUS_BRIDGE_RUNTIME_PROTOCOL_4_SCHEMA_ID
    return {
      ...entry,
      requestJson: canonicalJson(request),
      responseJson: canonicalJson(response),
    }
  })
  return `${canonicalJson({
    ...checkpoint,
    schemaId: PREVIOUS_BRIDGE_RUNTIME_PROTOCOL_4_SCHEMA_ID,
    journalDigest: sha256(canonicalJson(journal)),
    journal,
  })}\n`
}

// ── P04A REOPEN fixtures: genuine old-shape prior protocol-4 checkpoints ────
// Built from real V14 saves (minted with the exported `makeSaveV14`, never the
// Owner's real profile) plus wholly opaque journal bodies, so these exercise
// the unified prior-import path exactly as a real durable checkpoint written
// under an old protocol-4 schema would be shaped: the save slots are genuine,
// versioned save bytes; the journal is deliberately NOT current-contract-
// shaped, because the new import path must never parse it.
//
// Seeded with `createManagedBridgeState` (founding resolved, no picture
// played through to release) rather than `createBridgeInitialState` — a
// genuine prior-era protocol-4 world predates the `releaseCommitted` studio
// event kind, so its state can never legally contain a release drive. Using
// the full first-movie playthrough here would mint a `releaseCommitted` row
// that the frozen V14 validator correctly refuses.
function v14CurrentSaveJson(seed: string): string {
  return exportSave(makeSaveV14(createManagedBridgeState(seed)))
}

function opaqueJournalEntry(commandId: string, tag: string): BridgeRuntimeJournalEntryV1 {
  return {
    route: 'command',
    commandId,
    requestJson: canonicalJson({ opaqueHistoricalRequest: tag, commandId }),
    responseJson: canonicalJson({ opaqueHistoricalResponse: tag, commandId }),
  }
}

type PriorProtocol4Fixture = {
  schemaId: string
  sessionId: string
  stateRevision: number
  currentSaveJson: string
  savedSaveJson: string | null
  journal: readonly BridgeRuntimeJournalEntryV1[]
}

function priorProtocol4Bytes(fixture: PriorProtocol4Fixture): string {
  const currentStateDigest = sha256(fixture.currentSaveJson)
  const savedStateDigest = fixture.savedSaveJson === null ? null : sha256(fixture.savedSaveJson)
  const journal = [...fixture.journal]
  const checkpoint = {
    format: BRIDGE_RUNTIME_CHECKPOINT_FORMAT,
    checkpointVersion: BRIDGE_RUNTIME_CHECKPOINT_VERSION,
    protocolVersion: PROTOCOL_VERSION,
    schemaId: fixture.schemaId,
    sessionId: fixture.sessionId,
    stateRevision: fixture.stateRevision,
    currentSaveJson: fixture.currentSaveJson,
    currentStateDigest,
    savedSaveJson: fixture.savedSaveJson,
    savedStateDigest,
    journalDigest: sha256(canonicalJson(journal)),
    journal,
  }
  return `${canonicalJson(checkpoint)}\n`
}

const V4_SCHEMA_ID = 'sha256:f84ae77ec59a0d7ca7cdd89115456504ddecbde2c6e3839936e4951bd65bce61'
// Relationship slice B (1358-N P2): the outgoing projection-56 identity, the checked-in
// contract-manifest schemaId before the projection-57 bump (5245072a).
const OUTGOING_56 = 'sha256:349b2d3ec0614f2c9a6c481888e826651c230c6bcc9c84b2b13a82b566bfcec1'

describe('BridgeRuntimeCheckpointV1', () => {
  it('forward-migrates protocol 3 by preserving both V15 slots and discarding incompatible replay bytes', () => {
    const source = fixture()
    const legacyBytes = protocol3Bytes(source.checkpoint)
    expect(() => decodeBridgeRuntimeCheckpoint(legacyBytes)).toThrow(/protocolVersion/)

    const loaded = loadBridgeRuntimeCheckpoint(
      legacyBytes,
      undefined,
      () => 'runtime-protocol-4-session',
    )
    expect(loaded.migratedFromProtocolVersion).toBe(3)
    expect(loaded.hydrated.checkpoint).toMatchObject({
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      sessionId: 'runtime-protocol-4-session',
      stateRevision: 0,
      currentSaveJson: source.currentSaveJson,
      savedSaveJson: source.savedSaveJson,
      journal: [],
    })
    expect(loaded.hydrated.checkpoint.currentStateDigest).toBe(sha256(source.currentSaveJson))
    expect(loaded.hydrated.checkpoint.savedStateDigest).toBe(sha256(source.savedSaveJson))
    expect(loaded.hydrated.currentSave.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(loaded.hydrated.savedSave?.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(() => decodeBridgeRuntimeCheckpoint(
      encodeBridgeRuntimeCheckpoint(loaded.hydrated.checkpoint),
    )).not.toThrow()

    const corrupted = JSON.parse(legacyBytes) as Record<string, unknown>
    corrupted.journalDigest = '0'.repeat(64)
    expect(() => loadBridgeRuntimeCheckpoint(
      `${canonicalJson(corrupted)}\n`,
      undefined,
      () => 'runtime-protocol-4-session',
    )).toThrow(/journalDigest/)
  })

  it('rolls the previous protocol-4 schema forward without changing either V15 save slot', () => {
    const source = fixture()
    const priorBytes = previousProtocol4Bytes(source.checkpoint)
    expect(() => decodeBridgeRuntimeCheckpoint(priorBytes)).toThrow(/schemaId/)

    const loaded = loadBridgeRuntimeCheckpoint(
      priorBytes,
      undefined,
      () => 'runtime-current-schema-session',
    )
    expect(loaded.migratedFromProtocolVersion).toBe(PROTOCOL_VERSION)
    expect(loaded.hydrated.checkpoint).toMatchObject({
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      sessionId: 'runtime-current-schema-session',
      stateRevision: 0,
      currentSaveJson: source.currentSaveJson,
      currentStateDigest: sha256(source.currentSaveJson),
      savedSaveJson: source.savedSaveJson,
      savedStateDigest: sha256(source.savedSaveJson),
      journal: [],
    })
    expect(loaded.hydrated.currentSave.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(loaded.hydrated.savedSave?.saveVersion).toBe(LIVE_SAVE_VERSION)

    const corrupted = JSON.parse(priorBytes) as Record<string, unknown>
    corrupted.journalDigest = '0'.repeat(64)
    expect(() => loadBridgeRuntimeCheckpoint(
      `${canonicalJson(corrupted)}\n`,
      undefined,
      () => 'runtime-current-schema-session',
    )).toThrow(/journalDigest/)
  })

  it('rolls an authentic previous protocol-4 checkpoint with no explicit save slot', () => {
    const source = new BridgeSession(
      createBridgeInitialState('bridge-runtime-checkpoint-prior-p4-unsaved'),
      'bridge-runtime-checkpoint-prior-p4-unsaved-session',
    ).exportRuntimeCheckpoint()
    expect(source.savedSaveJson).toBeNull()
    expect(source.savedStateDigest).toBeNull()

    const loaded = loadBridgeRuntimeCheckpoint(
      previousProtocol4Bytes(source),
      undefined,
      () => 'runtime-current-schema-unsaved-session',
    )
    expect(loaded.migratedFromProtocolVersion).toBe(PROTOCOL_VERSION)
    expect(loaded.hydrated.checkpoint).toMatchObject({
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      sessionId: 'runtime-current-schema-unsaved-session',
      stateRevision: 0,
      currentSaveJson: source.currentSaveJson,
      currentStateDigest: source.currentStateDigest,
      savedSaveJson: null,
      savedStateDigest: null,
      journal: [],
    })
    expect(loaded.hydrated.savedSave).toBeNull()
  })

  it('rejects an impossible open-founding state attributed to the previous protocol-4 runtime', () => {
    const rawFounding = BridgeSession.createRuntime().exportRuntimeCheckpoint()
    const impossiblePriorBytes = previousProtocol4Bytes(rawFounding)

    expect(() => loadBridgeRuntimeCheckpoint(
      impossiblePriorBytes,
      undefined,
      () => 'runtime-impossible-founding-session',
    )).toThrow(/previous protocol-4 production authority cannot contain an open founding draft/)
  })

  it('encodes one exact closed canonical shape with one LF and hydrates stable V15 bytes', () => {
    const source = fixture()
    const encoded = encodeBridgeRuntimeCheckpoint(source.checkpoint)
    expect(encoded.endsWith('\n')).toBe(true)
    expect(encoded.endsWith('\n\n')).toBe(false)
    expect(encoded).not.toContain('\r')
    expect(encoded).toBe(`${canonicalJson(source.checkpoint)}\n`)

    const hydrated = decodeBridgeRuntimeCheckpoint(encoded)
    expect(hydrated.checkpoint).toEqual(source.checkpoint)
    expect(encodeBridgeRuntimeCheckpoint(hydrated.checkpoint)).toBe(encoded)
    expect(hydrated.currentSave.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(hydrated.savedSave?.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(hydrated.checkpoint.currentSaveJson).toBe(source.currentSaveJson)
    expect(hydrated.checkpoint.savedSaveJson).toBe(source.savedSaveJson)
    expect(hydrated.checkpoint.currentStateDigest).toBe(sha256(source.currentSaveJson))
    expect(hydrated.checkpoint.savedStateDigest).toBe(sha256(source.savedSaveJson))
    expect(hydrated.checkpointBytes).toBe(Buffer.byteLength(encoded, 'utf8'))
    expect(hydrated.journal.map((entry) => entry.route)).toEqual(['command', 'save'])

    expect(Object.keys(hydrated.checkpoint).sort()).toEqual([
      'checkpointVersion',
      'currentSaveJson',
      'currentStateDigest',
      'format',
      'journal',
      'journalDigest',
      'protocolVersion',
      'savedSaveJson',
      'savedStateDigest',
      'schemaId',
      'sessionId',
      'stateRevision',
    ])
    expect(hydrated.checkpoint).toMatchObject({
      format: BRIDGE_RUNTIME_CHECKPOINT_FORMAT,
      checkpointVersion: BRIDGE_RUNTIME_CHECKPOINT_VERSION,
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
    })
    expect(JSON.parse(source.currentSaveJson)).not.toHaveProperty('journal')
  })

  it('requires canonical checkpoint bytes followed by exactly one LF', () => {
    const checkpoint = fixture().checkpoint
    const canonical = encodeBridgeRuntimeCheckpoint(checkpoint)
    expect(() => decodeBridgeRuntimeCheckpoint(canonical.trimEnd())).toThrow(/exactly one LF/)
    expect(() => decodeBridgeRuntimeCheckpoint(canonical.replace(/\n$/, '\r\n'))).toThrow(/exactly one LF/)
    expect(() => decodeBridgeRuntimeCheckpoint(` ${canonical}`)).toThrow(/canonical JSON/)
    expect(() => decodeBridgeRuntimeCheckpoint(`${canonical}\n`)).toThrow(/exactly one LF/)
  })

  it('rejects missing and additional roots plus incompatible format, version, protocol, and schema', () => {
    const checkpoint = fixture().checkpoint
    const extra = { ...checkpoint, timestamp: 'not-authorized' }
    expect(() => hydrateBridgeRuntimeCheckpoint(extra)).toThrow(/unknown field "timestamp"/)
    const hidden = clone(checkpoint) as BridgeRuntimeCheckpointV1 & { secret?: string }
    Object.defineProperty(hidden, 'secret', { value: 'not-authorized', enumerable: false })
    expect(() => hydrateBridgeRuntimeCheckpoint(hidden)).toThrow(/unknown field "secret"/)

    const missing = clone(checkpoint) as Partial<BridgeRuntimeCheckpointV1>
    delete missing.sessionId
    expect(() => hydrateBridgeRuntimeCheckpoint(missing)).toThrow(/missing required field "sessionId"/)
    expect(() => hydrateBridgeRuntimeCheckpoint({ ...checkpoint, format: 'other' })).toThrow(/checkpoint\.format/)
    expect(() => hydrateBridgeRuntimeCheckpoint({ ...checkpoint, checkpointVersion: 2 })).toThrow(/checkpointVersion/)
    expect(() => hydrateBridgeRuntimeCheckpoint({ ...checkpoint, protocolVersion: 99 })).toThrow(/protocolVersion/)
    expect(() => hydrateBridgeRuntimeCheckpoint({ ...checkpoint, schemaId: 'sha256:wrong' })).toThrow(/schemaId/)
    expect(Object.keys(checkpoint).some((key) => /time|secret|token|path/i.test(key))).toBe(false)
  })

  it('requires untouched canonical V15 current and explicit-save bytes with exact digests', () => {
    const checkpoint = fixture().checkpoint
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      currentStateDigest: '0'.repeat(64),
    })).toThrow(/does not match currentSaveJson/)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      savedStateDigest: 'f'.repeat(64),
    })).toThrow(/does not match savedSaveJson/)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      savedSaveJson: null,
    })).toThrow(/must be null exactly/)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      savedSaveJson: null,
      savedStateDigest: null,
    })).toThrow(/latest accepted save journal response/)
    expect(() => createBridgeRuntimeCheckpoint({
      sessionId: checkpoint.sessionId,
      stateRevision: checkpoint.stateRevision,
      currentSaveJson: checkpoint.currentSaveJson,
      savedSaveJson: null,
      journal: [fixture().commandEntry],
    })).not.toThrow()

    const differentSavedJson = exportSaveJson(createBridgeInitialState('checkpoint-different-save'))
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      savedSaveJson: differentSavedJson,
      savedStateDigest: sha256(differentSavedJson),
    })).toThrow(/latest accepted save journal response/)

    const nonCanonicalSave = `${checkpoint.currentSaveJson}\n`
    expect(() => createBridgeRuntimeCheckpoint({
      sessionId: checkpoint.sessionId,
      stateRevision: checkpoint.stateRevision,
      currentSaveJson: nonCanonicalSave,
      savedSaveJson: checkpoint.savedSaveJson,
      journal: checkpoint.journal,
      // 1327-C sweep (C15, S8 form): the live save version moved past V38; the
      // guard's own message is version-aware (`bridge/runtime-checkpoint.ts:501`,
      // `must preserve the canonical V${LIVE_SAVE_VERSION} save bytes exactly`).
      // The refused-non-canonical-bytes premise still holds, only the number
      // in its own message moved with the live version.
    })).toThrow(new RegExp(`canonical V${LIVE_SAVE_VERSION} save bytes exactly`)) // 1370-AR r3: the message is built from LIVE_SAVE_VERSION (bridge/runtime-checkpoint.ts)

    const forgedSave = JSON.parse(checkpoint.currentSaveJson) as Record<string, unknown>
    forgedSave['bridgeJournal'] = []
    expect(() => createBridgeRuntimeCheckpoint({
      sessionId: checkpoint.sessionId,
      stateRevision: checkpoint.stateRevision,
      currentSaveJson: canonicalJson(forgedSave),
      savedSaveJson: checkpoint.savedSaveJson,
      journal: checkpoint.journal,
    })).toThrow(/unknown field "bridgeJournal"/)
  })

  it('validates route-specific requests, responses, identity, session, revision, and canonical JSON', () => {
    const source = fixture()
    const checkpoint = source.checkpoint
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, route: 'save' }],
    })).toThrow(/save request contract/)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, commandId: 'different' }],
    })).toThrow(/commandId does not match/)

    const wrongSessionRequest = JSON.parse(source.commandEntry.requestJson) as Record<string, unknown>
    wrongSessionRequest['sessionId'] = 'different-session'
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, requestJson: canonicalJson(wrongSessionRequest) }],
    })).toThrow(/request sessionId/)

    const wrongSessionResponse = JSON.parse(source.commandEntry.responseJson) as Record<string, unknown>
    wrongSessionResponse['sessionId'] = 'different-session'
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, responseJson: canonicalJson(wrongSessionResponse) }],
    })).toThrow(/response sessionId/)

    const wrongSchemaRequest = JSON.parse(source.commandEntry.requestJson) as Record<string, unknown>
    wrongSchemaRequest['schemaId'] = 'sha256:different-request-schema'
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, requestJson: canonicalJson(wrongSchemaRequest) }],
    })).toThrow(/request schemaId/)

    const wrongSchemaResponse = JSON.parse(source.commandEntry.responseJson) as Record<string, unknown>
    wrongSchemaResponse['schemaId'] = 'sha256:different-response-schema'
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, responseJson: canonicalJson(wrongSchemaResponse) }],
    })).toThrow(/response schemaId/)

    const wrongRevision = JSON.parse(source.commandEntry.responseJson) as Record<string, unknown>
    wrongRevision['stateRevision'] = 0
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, responseJson: canonicalJson(wrongRevision) }],
    })).toThrow(/response revision does not match/)

    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, requestJson: ` ${source.commandEntry.requestJson}` }],
    })).toThrow(/canonical JSON/)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, unexpected: true }],
    })).toThrow(/unknown field "unexpected"/)

    const wrongCurrentDigest = JSON.parse(source.commandEntry.responseJson) as Record<string, unknown>
    wrongCurrentDigest['stateDigest'] = 'f'.repeat(64)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, responseJson: canonicalJson(wrongCurrentDigest) }],
    })).toThrow(/current checkpoint state at the same revision/)

    const wrongCurrentWeek = JSON.parse(source.commandEntry.responseJson) as Record<string, unknown>
    wrongCurrentWeek['gameWeek'] = (wrongCurrentWeek['gameWeek'] as number) + 1
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...checkpoint,
      journal: [{ ...source.commandEntry, responseJson: canonicalJson(wrongCurrentWeek) }],
    })).toThrow(/current checkpoint state at the same revision/)
  })

  it('binds exact historical bytes and rejection semantics to their original route', () => {
    const source = fixture()
    const tamperedResponse = JSON.parse(source.commandEntry.responseJson) as Record<string, unknown>
    tamperedResponse['message'] = 'Schema-valid but not the response that was committed.'
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...source.checkpoint,
      journal: [{
        ...source.commandEntry,
        responseJson: canonicalJson(tamperedResponse),
      }, source.saveEntry],
    })).toThrow(/journalDigest.*canonical journal bytes/)

    const noSaveSession = new BridgeSession(
      createBridgeInitialState('bridge-runtime-route-rejection'),
      'bridge-runtime-route-rejection',
    )
    const noSaveControl: ControlEnvelope = {
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      sessionId: noSaveSession.sessionId,
      commandId: 'route-rejection',
      expectedStateRevision: 0,
    }
    const noSave = noSaveSession.load(noSaveControl)
    if (noSave.accepted) throw new Error('Expected no-save rejection fixture.')
    const loadEntry = createBridgeRuntimeJournalEntry('load', noSaveControl, noSave)
    const rebound = { ...loadEntry, route: 'save' as const }
    expect(() => createBridgeRuntimeCheckpoint({
      sessionId: noSaveSession.sessionId,
      stateRevision: 0,
      currentSaveJson: exportSaveJson(noSaveSession.gameState),
      savedSaveJson: null,
      journal: [rebound],
    })).toThrow(/NO_SAVE is not a journalable save rejection/)
  })

  it('rejects duplicate identities and revision-regressing journal order', () => {
    const source = fixture()
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...source.checkpoint,
      journal: [source.commandEntry, source.commandEntry],
    })).toThrow(/duplicates an earlier journal identity/)
    const newerRequest = JSON.parse(source.commandEntry.requestJson) as Record<string, unknown>
    newerRequest['commandId'] = 'checkpoint-newer-command'
    newerRequest['expectedStateRevision'] = 1
    const newerResponse = JSON.parse(source.commandEntry.responseJson) as Record<string, unknown>
    newerResponse['commandId'] = 'checkpoint-newer-command'
    newerResponse['stateRevision'] = 2
    const newerEntry: BridgeRuntimeJournalEntryV1 = {
      route: 'command',
      commandId: 'checkpoint-newer-command',
      requestJson: canonicalJson(newerRequest),
      responseJson: canonicalJson(newerResponse),
    }
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...source.checkpoint,
      stateRevision: 2,
      journal: [newerEntry, source.commandEntry],
    })).toThrow(/response revisions must be non-decreasing/)
  })

  it('binds the root revision to the terminal journal response', () => {
    const source = fixture()
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...source.checkpoint,
      stateRevision: source.checkpoint.stateRevision + 1,
    })).toThrow(/stateRevision.*terminal journal response revision/)

    const fresh = new BridgeSession(
      createBridgeInitialState('bridge-runtime-empty-revision'),
      'bridge-runtime-empty-revision',
    ).exportRuntimeCheckpoint()
    expect(fresh.journal).toHaveLength(0)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...fresh,
      stateRevision: 1,
    })).toThrow(/stateRevision.*must be 0 when the journal is empty/)
  })

  it('returns a normalized prospective append only after identity and capacity validation', () => {
    const source = fixture()
    const base = createBridgeRuntimeCheckpoint({
      sessionId: source.checkpoint.sessionId,
      stateRevision: source.checkpoint.stateRevision,
      currentSaveJson: source.currentSaveJson,
      savedSaveJson: source.savedSaveJson,
      journal: [source.commandEntry],
    })
    const appended = appendBridgeRuntimeJournalEntry(base, source.saveEntry)
    expect(appended.journal).toEqual([source.commandEntry, source.saveEntry])
    expect(() => appendBridgeRuntimeJournalEntry(appended, source.saveEntry)).toThrow(/duplicates/)
    expect(() => appendBridgeRuntimeJournalEntry(base, source.saveEntry, {
      maxCheckpointBytes: 64 * 1024 * 1024,
      maxJournalEntries: 1,
      maxJournalBytes: 32 * 1024 * 1024,
    })).toThrow(/maximum is 1/)
    expect(base.journal).toEqual([source.commandEntry])
  })

  it('enforces injectable entry, journal-byte, and checkpoint-byte bounds before hydration', () => {
    const source = fixture()
    const encoded = encodeBridgeRuntimeCheckpoint(source.checkpoint)
    const hydrated = decodeBridgeRuntimeCheckpoint(encoded)
    const limits = (
      overrides: Partial<BridgeRuntimeCheckpointLimits>,
    ): BridgeRuntimeCheckpointLimits => ({
      maxCheckpointBytes: 64 * 1024 * 1024,
      maxJournalEntries: 512,
      maxJournalBytes: 32 * 1024 * 1024,
      ...overrides,
    })

    expect(() => hydrateBridgeRuntimeCheckpoint(
      source.checkpoint,
      limits({ maxJournalEntries: 1 }),
    )).toThrow(/maximum is 1/)
    expect(() => hydrateBridgeRuntimeCheckpoint(
      source.checkpoint,
      limits({ maxJournalBytes: hydrated.journalBytes - 1 }),
    )).toThrow(/checkpoint\.journal: uses/)
    expect(() => decodeBridgeRuntimeCheckpoint(
      encoded,
      limits({ maxCheckpointBytes: Buffer.byteLength(encoded, 'utf8') - 1 }),
    )).toThrow(/checkpoint: uses/)
    expect(() => hydrateBridgeRuntimeCheckpoint(
      source.checkpoint,
      limits({ maxJournalEntries: 2, maxJournalBytes: hydrated.journalBytes }),
    )).not.toThrow()
  })

  it('validates an accepted save response V15 payload and digest before journaling it', () => {
    const source = fixture()
    const badResponse = JSON.parse(source.saveEntry.responseJson) as Record<string, unknown>
    badResponse['stateDigest'] = '0'.repeat(64)
    expect(() => hydrateBridgeRuntimeCheckpoint({
      ...source.checkpoint,
      journal: [
        source.commandEntry,
        { ...source.saveEntry, responseJson: canonicalJson(badResponse) },
      ],
    })).toThrow(/accepted save response digest/)
  })

  it('surfaces a typed checkpoint error with the exact failing path', () => {
    try {
      hydrateBridgeRuntimeCheckpoint({})
      throw new Error('Expected checkpoint validation to fail.')
    } catch (error) {
      expect(error).toBeInstanceOf(BridgeRuntimeCheckpointError)
      expect((error as BridgeRuntimeCheckpointError).checkpointPath).toBe('checkpoint')
    }
  })
})

describe('P04A REOPEN — enumerated prior protocol-4 checkpoint import', () => {
  it('preserves both actual accepted P12 founding slots through the P13 save migration', () => {
    const savedSaveJson = gunzipSync(readFileSync(new URL('./fixtures/p13a/accepted-v19.json.gz', import.meta.url))).toString('utf8')
    const currentSaveJson = gunzipSync(readFileSync(new URL('./fixtures/p13a/accepted-v19-hired.json.gz', import.meta.url))).toString('utf8')
    expect(currentSaveJson).not.toBe(savedSaveJson)
    const prior = priorProtocol4Bytes({
      schemaId: 'sha256:8b2569b1f925bedf214ee556841fe28b61e544f1f13bb4741c84a0a318e81a85',
      sessionId: 'native-p12-before-upgrade', stateRevision: 1,
      currentSaveJson, savedSaveJson, journal: [],
    })
    const loaded = loadBridgeRuntimeCheckpoint(prior, undefined, () => 'native-p12-after-upgrade')
    expect(loaded.hydrated.checkpoint).toMatchObject({
      stateRevision: 0, schemaId: SCHEMA_ID,
      sessionId: 'native-p12-after-upgrade', journal: [],
    })
    expect(loaded.hydrated.currentSave.state.founding).not.toBeNull()
    expect(loaded.hydrated.savedSave!.state.founding).not.toBeNull()
    expect(loaded.hydrated.currentSave.state.contracts).toEqual(JSON.parse(currentSaveJson).state.contracts)
    expect(loaded.hydrated.savedSave!.state.contracts).toEqual(JSON.parse(savedSaveJson).state.contracts)
    expect(loaded.hydrated.currentSave.state.technology.projects).toEqual([])
    expect(loaded.hydrated.savedSave!.state.technology.projects).toEqual([])
    expect(loaded.hydrated.currentSave.state.studio.cash).toBe(JSON.parse(currentSaveJson).state.studio.cash)
    const encoded = encodeBridgeRuntimeCheckpoint(loaded.hydrated.checkpoint)
    expect(loadBridgeRuntimeCheckpoint(encoded).migratedFromProtocolVersion).toBeNull()
  })

  it('migrates a v4-identity (f84ae77e) checkpoint with a V14 current save and an opaque 2-entry journal', () => {
    const seedState = createManagedBridgeState('prior-p4-v4-basic')
    const currentSaveJson = exportSave(makeSaveV14(seedState))
    const priorBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-v4-basic-session',
      stateRevision: 21,
      currentSaveJson,
      savedSaveJson: null,
      journal: [
        opaqueJournalEntry('prior-command-1', 'alpha'),
        opaqueJournalEntry('prior-command-2', 'beta'),
      ],
    })

    const loaded = loadBridgeRuntimeCheckpoint(priorBytes, undefined, () => 'fresh-v4-basic-session')

    // (6)/(7) fresh session + revision-0 laws.
    expect(loaded.migratedFromProtocolVersion).toBe(PROTOCOL_VERSION)
    expect(loaded.hydrated.checkpoint.sessionId).toBe('fresh-v4-basic-session')
    expect(loaded.hydrated.checkpoint.sessionId).not.toBe('prior-v4-basic-session')
    expect(loaded.hydrated.checkpoint.stateRevision).toBe(0)
    expect(loaded.hydrated.checkpoint.journal).toEqual([])

    // save now V16, digests recomputed correctly.
    expect(loaded.hydrated.checkpoint.schemaId).toBe(SCHEMA_ID)
    expect(loaded.hydrated.currentSave.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(loaded.hydrated.checkpoint.currentStateDigest)
      .toBe(sha256(loaded.hydrated.checkpoint.currentSaveJson))

    // (4) V14 -> V16 content preservation, field-level.
    expect(loaded.hydrated.currentSave.state.market.tick).toBe(seedState.market.tick)
    expect(loaded.hydrated.currentSave.state.studio.cash).toBe(seedState.studio.cash)
    expect(loaded.hydrated.currentSave.state.founding).toBeNull()
  })

  it('preserves and migrates a non-null savedSaveJson slot for a prior protocol-4 identity', () => {
    const currentState = createManagedBridgeState('prior-p4-v4-saved-current')
    const savedState = createManagedBridgeState('prior-p4-v4-saved-saved')
    const currentSaveJson = exportSave(makeSaveV14(currentState))
    const savedSaveJson = exportSave(makeSaveV14(savedState))
    const priorBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-v4-saved-session',
      stateRevision: 3,
      currentSaveJson,
      savedSaveJson,
      journal: [opaqueJournalEntry('prior-saved-command', 'gamma')],
    })

    const loaded = loadBridgeRuntimeCheckpoint(priorBytes, undefined, () => 'fresh-v4-saved-session')

    expect(loaded.migratedFromProtocolVersion).toBe(PROTOCOL_VERSION)
    expect(loaded.hydrated.checkpoint.savedSaveJson).not.toBeNull()
    expect(loaded.hydrated.savedSave?.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(loaded.hydrated.savedSave?.state.market.tick).toBe(savedState.market.tick)
    expect(loaded.hydrated.savedSave?.state.studio.cash).toBe(savedState.studio.cash)
    expect(loaded.hydrated.checkpoint.savedStateDigest)
      .toBe(sha256(loaded.hydrated.checkpoint.savedSaveJson ?? ''))
    // currentSaveJson also preserved+migrated, independent of the saved slot.
    expect(loaded.hydrated.currentSave.state.market.tick).toBe(currentState.market.tick)
  })

  it.each(Array.from(SUPPORTED_PRIOR_PROTOCOL_4_SCHEMA_IDS.entries()))(
    'accepts and migrates the enumerated %s (%s) identity',
    (schemaId, era) => {
      const seedState = createManagedBridgeState(`prior-p4-each-${era}`)
      const currentSaveJson = exportSave(makeSaveV14(seedState))
      const priorBytes = priorProtocol4Bytes({
        schemaId,
        sessionId: `prior-session-${era}`,
        stateRevision: 0,
        currentSaveJson,
        savedSaveJson: null,
        journal: [],
      })

      const loaded = loadBridgeRuntimeCheckpoint(priorBytes, undefined, () => `fresh-session-${era}`)
      expect(loaded.migratedFromProtocolVersion).toBe(PROTOCOL_VERSION)
      expect(loaded.hydrated.checkpoint.schemaId).toBe(SCHEMA_ID)
      expect(loaded.hydrated.checkpoint.stateRevision).toBe(0)
      expect(loaded.hydrated.checkpoint.journal).toEqual([])
      expect(loaded.hydrated.currentSave.saveVersion).toBe(LIVE_SAVE_VERSION)
    },
  )

  it('fails closed on a duplicate commandId, a wrong journalDigest, and non-canonical bytes', () => {
    const currentSaveJson = v14CurrentSaveJson('prior-p4-journal-integrity')

    const duplicateBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-v4-dup-session',
      stateRevision: 0,
      currentSaveJson,
      savedSaveJson: null,
      journal: [
        opaqueJournalEntry('same-command-id', 'one'),
        opaqueJournalEntry('same-command-id', 'two'),
      ],
    })
    expect(() => loadBridgeRuntimeCheckpoint(duplicateBytes)).toThrow(/duplicates an earlier journal identity/)

    const validBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-v4-digest-session',
      stateRevision: 0,
      currentSaveJson,
      savedSaveJson: null,
      journal: [opaqueJournalEntry('journal-digest-command', 'one')],
    })
    const corruptedDigest = JSON.parse(validBytes) as Record<string, unknown>
    corruptedDigest['journalDigest'] = '0'.repeat(64)
    expect(() => loadBridgeRuntimeCheckpoint(`${canonicalJson(corruptedDigest)}\n`))
      .toThrow(/journalDigest/)

    expect(() => loadBridgeRuntimeCheckpoint(` ${validBytes}`)).toThrow(/canonical JSON/)
    expect(() => loadBridgeRuntimeCheckpoint(validBytes.trimEnd())).toThrow(/exactly one LF/)
  })

  it('re-hydrates the migrated output via the normal current-schema path (write-read round trip, idempotent)', () => {
    const currentSaveJson = v14CurrentSaveJson('prior-p4-roundtrip')
    const priorBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-v4-roundtrip-session',
      stateRevision: 5,
      currentSaveJson,
      savedSaveJson: null,
      journal: [opaqueJournalEntry('roundtrip-command', 'one')],
    })

    const loaded = loadBridgeRuntimeCheckpoint(priorBytes, undefined, () => 'fresh-v4-roundtrip-session')
    const encoded = encodeBridgeRuntimeCheckpoint(loaded.hydrated.checkpoint)

    // (8) migrated output re-hydrates via the normal path.
    const decoded = decodeBridgeRuntimeCheckpoint(encoded)
    expect(decoded.checkpoint).toEqual(loaded.hydrated.checkpoint)

    // (9) idempotence: loading the migrated bytes again takes the NORMAL
    // (non-migrating) path, because the output is already current-schema —
    // running the import twice is impossible by construction.
    const reloaded = loadBridgeRuntimeCheckpoint(encoded)
    expect(reloaded.migratedFromProtocolVersion).toBeNull()
    expect(reloaded.hydrated.checkpoint).toEqual(loaded.hydrated.checkpoint)

    // (10) current-schema checkpoint bytes unchanged by a load/store round trip.
    expect(encodeBridgeRuntimeCheckpoint(reloaded.hydrated.checkpoint)).toBe(encoded)
  })

  it('fails closed on an unknown protocol-4 schemaId with the exact current message', () => {
    const currentSaveJson = v14CurrentSaveJson('prior-p4-unknown-schema')
    const unknownBytes = priorProtocol4Bytes({
      schemaId: 'sha256:' + 'ab'.repeat(32),
      sessionId: 'prior-unknown-session',
      stateRevision: 0,
      currentSaveJson,
      savedSaveJson: null,
      journal: [],
    })
    expect(() => loadBridgeRuntimeCheckpoint(unknownBytes))
      .toThrow(/does not match the running TypeScript bridge schema/)
  })

  it('fails closed on malformed prior protocol-4 checkpoint bytes', () => {
    const currentSaveJson = v14CurrentSaveJson('prior-p4-malformed')
    const validBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-malformed-session',
      stateRevision: 0,
      currentSaveJson,
      savedSaveJson: null,
      journal: [],
    })

    // Truncated JSON.
    expect(() => loadBridgeRuntimeCheckpoint(validBytes.slice(0, -5))).toThrow(/not valid JSON/)

    // Missing a required root key.
    const missingKey = JSON.parse(validBytes) as Record<string, unknown>
    delete missingKey['journalDigest']
    expect(() => loadBridgeRuntimeCheckpoint(`${canonicalJson(missingKey)}\n`))
      .toThrow(/missing required field "journalDigest"/)

    // Unknown extra root key.
    const extraKey = { ...(JSON.parse(validBytes) as Record<string, unknown>), notAuthorized: true }
    expect(() => loadBridgeRuntimeCheckpoint(`${canonicalJson(extraKey)}\n`))
      .toThrow(/unknown field "notAuthorized"/)

    // Malformed journal entry (wrong keys).
    const badJournalEntry = JSON.parse(validBytes) as Record<string, unknown>
    badJournalEntry['journal'] = [{ route: 'command', commandId: 'x' }]
    expect(() => loadBridgeRuntimeCheckpoint(`${canonicalJson(badJournalEntry)}\n`))
      .toThrow(/missing required field/)
  })

  it('rejects an impossible open-founding state on either migrated save slot', () => {
    const founding = BridgeSession.createRuntime().exportRuntimeCheckpoint()
    const foundingState = JSON.parse(founding.currentSaveJson) as { state: { founding: unknown } }
    expect(foundingState.state.founding).not.toBeNull()

    const priorBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-founding-session',
      stateRevision: 0,
      currentSaveJson: founding.currentSaveJson,
      savedSaveJson: null,
      journal: [],
    })
    expect(() => loadBridgeRuntimeCheckpoint(priorBytes))
      .toThrow(/previous protocol-4 production authority cannot contain an open founding draft/)
  })

  it('never parses journal request/response bodies for a prior protocol-4 identity', () => {
    // The journal bodies below are NOT current-contract-shaped at all (no
    // route-matching command/response fields BRIDGE_SCHEMA would recognize).
    // If the import path ever hydrated them, this would throw; it must not.
    const currentSaveJson = v14CurrentSaveJson('prior-p4-opaque-journal')
    const priorBytes = priorProtocol4Bytes({
      schemaId: V4_SCHEMA_ID,
      sessionId: 'prior-opaque-session',
      stateRevision: 99,
      currentSaveJson,
      savedSaveJson: null,
      journal: [
        {
          route: 'save',
          commandId: 'totally-opaque-1',
          requestJson: canonicalJson('not even an object'),
          responseJson: canonicalJson({ nothing: 'to see here' }),
        },
      ],
    })
    const loaded = loadBridgeRuntimeCheckpoint(priorBytes, undefined, () => 'fresh-opaque-session')
    expect(loaded.migratedFromProtocolVersion).toBe(PROTOCOL_VERSION)
    expect(loaded.hydrated.checkpoint.journal).toEqual([])
  })
})

// ── P04A REOPEN hostile-review hardening ─────────────────────────────────────
// The exact mechanism that bricked the Owner's profile was the acceptance
// boundary drifting out of sync with the running schema. These pins make both
// failure directions loud at test time.
describe('prior protocol-4 acceptance boundary pins', () => {
  it('never contains the RUNNING schema identity (re-migration must be impossible)', () => {
    // If a future projection bump ever leaves the current identity inside the
    // map, every launch would silently re-migrate: journal wiped, revision
    // reset, session re-minted — on every start. This pin makes that loud.
    expect(SUPPORTED_PRIOR_PROTOCOL_4_SCHEMA_IDS.has(SCHEMA_ID)).toBe(false)
  })

  it('contains exactly the independently pinned historical protocol-4 identities', () => {
    // Load-bearing completeness: iterating the map cannot catch a wrong or
    // missing hash; these literals were re-derived independently from the
    // generated-header history during hostile review. A projection bump must
    // consciously append its OUTGOING identity here — the P04A reopen
    // happened because v9/v10 never were. P05A W2 appended the outgoing
    // projection-v11 identity per the schema-bump law; the W2 correction wave
    // (range-review F2, the canonical $id URN bump) appended the WIP-branch
    // intermediate v12-stale-urn identity the same way.
    // P05A.3 appended the outgoing projection-v12 identity (a6f37459…) when
    // v13 put the hiring market on the casting wire. P06A W2 appended the
    // outgoing projection-v13 identity (0474ceaf…) when the W2 contract mint
    // moved the running schema to V16 / projection-14. P08A W2 appended the
    // outgoing projection-v15 identity (ddce1c39…, the P07-accepted schema) when
    // the Standing & Studio History section moved the running schema to
    // V17 / projection-16. P09 W1 appended the outgoing projection-v16 identity
    // (85a6d125…, the P08 core checkpoint schema) when the placement quote
    // family and the founding regime moved the running schema to V18 /
    // projection-17. P10A W0 appended the outgoing projection-v17 identity (18de162d…,
    // the P09 core checkpoint schema) when the Talent section moved the running schema to
    // projection-18. P10-R1 appended the outgoing projection-v18 identity (ea5d645f…, the
    // P10 person-route candidate schema) when the contract actions / contract quote family
    // moved the running schema to projection-19.
    // AUD-001: P07 missed the outgoing P06 projection-v14 identity. Its literal
    // comes from the accepted receipt and frozen P06 checkpoint, independently
    // exercised by bridge-p06-checkpoint-recovery.test.ts.
    // Recovery projection20 registers the outgoing projection19 header frozen
    // at recovery base1b5eb8f08c81c7d9c639058c3e28b21b9c1f8e84.
    expect([...SUPPORTED_PRIOR_PROTOCOL_4_SCHEMA_IDS.keys()].sort()).toEqual([
      // P14B.6 (700-T2): the outgoing projection-48 identity — the checked-in
      // contract-manifest schemaId before the projection-49 bump (ad49031f^), also
      // pinned independently by bridge-p14b4-runtime47-compatibility.test.ts.
      'sha256:00c0075bef257634956da7d16d117a145d203047e7169c643156b7971c4c7fec',
      'sha256:01f15efc8fc33fd810b051242857385ca23b5e1c775b357db1bfe5a70e907e1e',
      'sha256:0285e92f32c27cd2960df802b3f7ea156a15372f05001ad1f4964c2f25db55b5',
      'sha256:0474ceafd6c148f329fe99eac328c79ed0b0caf906e0f7442b7f3cf0fe40cb4f',
      'sha256:15033cf9ca43be65abcb25fc6f910f9487ac23056090126ec7d3e2353f6ce587',
      'sha256:18de162d1a9da3034378f71cec3d3b3f109ea91df8c1a8d40469924108b36e78',
      'sha256:1bad05a95c284e64ceaef54c276f2dd0ccad8ca3ef1b12198068bb61b85198c9',
      // Authentic P11 projection24, also retained byte-for-byte in p11-core-v1 fixtures.
      'sha256:204a71924bd8c2e8ae9af47591226894b3e42f62457da3cc20ed6b106ede611a',
      // Authentic outgoing ready26: d906's generated header and unchanged v3 corpus.
      'sha256:2b339a6a8b3e5add0726b7eaac9ce8746e235d8b6111a6816f890ff56afdffd1',
      // R2/R3: genuine1307 outgoing55 current111/saved110 checkpoint.
      'sha256:2c377b6fa3c559eee753e7a9d91d4956399cca1a5693edb15adb3de7c4f27158',
      // Relationship slice B: outgoing56, 349b2d3e… (OUTGOING_56 above).
      OUTGOING_56,
      'sha256:510f08e4a551827a30e0f3d93bbe09fa5ddadbd39366b4dcfa93530500c7979c',
      // P14B.4 (record 600): the outgoing projection-46 identity — the checked-in
      // contract-manifest schemaId before the projection-47 bump (47b2bbf4^), also
      // pinned independently by bridge-p14b4-runtime47-compatibility.test.ts.
      'sha256:584bdd8565030f049d548b1af4fcbf8c517ca7c9150016736f632f1ef8fcb98c',
      // Genuine outgoing projection45: e37cd23 generated header and preserved runtime checkpoint.
      'sha256:5b2a4ca93d930e90a288db55bb5cc3fdc8eea070ef51fa1450a193a325bd755d',
      // P14B.8: the outgoing projection-49 identity — the checked-in contract-manifest
      // schemaId before the projection-50 bump, also pinned independently by
      // bridge-p14b4-runtime47-compatibility.test.ts.
      'sha256:60af24c58bc4bea8f04e7fc818f8401daeadd87da91252e60cfcf3ee028d8e1b',
      'sha256:625377a2804a681da3be209da02850e221ae33ac5f58b727f6395736ad607ad1',
      'sha256:6a2c01feaf02c931a8c41bbf2090f8af003b89a492d77135d7aab2b42a8d3dc9',
      // P14B.5 (662-T2): the outgoing projection-47 identity — the checked-in
      // contract-manifest schemaId before the projection-48 bump (040651b4^), also
      // pinned independently by bridge-p14b4-runtime47-compatibility.test.ts.
      'sha256:6f6b48805aadcf14d456614d87bf1571eb1ce0d9aa0bc44f604e7976f4f85538',
      'sha256:71529afdcb8e5cf645ab136efb9685256da0039e86d989bfab97b7b2cc5d9a8b',
      // Actual shipped projection57, independent of unlanded candidate57 identity.
      C17_SHIPPED_OUTGOING_57,
      'sha256:7e3af4db0d3d18cdeaab00082e0034f304a9141f46ea87e9e64e5a99d985483c',
      'sha256:80f2f0fcd14d1b25e713c2624286a6c05a98c53ea5cfcb2b47612f8c030f5e47',
      'sha256:85a6d125960dce49b4775f842d7b56d7360c81cef3638cd819057c79c99f0236',
      'sha256:8b2569b1f925bedf214ee556841fe28b61e544f1f13bb4741c84a0a318e81a85',
      'sha256:92317ec179456cdc5bd5cc7c4ca47dd066b768a9e2e45519f1263ef921a211a4',
      'sha256:97940e51e0566bed80231b223e5b7303a45d62db8d698f693e525eb244775211',
      // P4/P5: genuine1221 outgoing54 current-waived/saved-earned slots.
      'sha256:9c5bba3fcc58e857fe57e33623a86f096cd04e00547bea8f2dae3a656025b302',
      'sha256:a481d14f3810ffbafcba2bbf509db7340263f3f0fd665a059507a1567d98923d',
      // 875: genuine outgoing projection51, preserved in the pre-bump C.2-RM runtime corpus.
      'sha256:a690e6f9e6f93f3a78f8eed8eaa20a1532a9ebd82812b0bc9414a04fdcb5968f',
      'sha256:a6f374596e956800f9547ad538fdd859c01bda3460aac8b877279c67686c6f4b',
      'sha256:b779faa92227bd1f2e623ad04d0899c87e7ddc60ce43f9ae9c39a7626c20a83d',
      'sha256:ba9cd199704f66d375585d0bec2128c950618a3ba6a8cf0845a5550fde41659f',
      'sha256:be7ed660d04ed9b1056f48e946f86f26c10cab42b950a273d57ad9cba372f5bb',
      // Native R05 preview12 manifest/DTO, before the Profile date-label addition.
      'sha256:c6ab1b2f181b7cbbd1b873a276f0be0516a505f258c3c9ad996042e43e096712',
      // R3-N7-SIM-01: the outgoing projection-31 identity, appended when the
      // read-only operationsEvents section moved the running schema to 32.
      'sha256:c9c07d6febe4afee7f7c27c991acdfa1c86b6c3a7f5dff8528d7fa5ad72e43a1',
      'sha256:c9dad9f3d8bb94445db1a5425d90db3f9894da9354f47a07992ff96261cfc399',
      'sha256:d3338cb713385cc23414e6a17293a5900871764f0eeaed19698e17634e74740b',
      // P3: genuine1117 outgoing53 natural and waiver checkpoints.
      'sha256:d59e144e4077f669804ca87dd6184ef23bd44c9d93e44eb795f2b66350926a4d',
      'sha256:ddce1c399ac4ff58327b296a0600428ac3f3346b84f3639e66e48e53a65fbe99',
      // R3-N4-SIM-20: the outgoing projection-30 identity (4dd667dc's generated header),
      // appended when the batched N4/N5/N6 read-model deltas moved the running schema to 31.
      'sha256:e2d354dcbae1a6dc93a2367756512c14243b11be202a26107de0c81a4f3e0698', // 840: genuine outgoing projection50 (824/842)
      'sha256:e64a3b659e4247b98631f1caa1f0e9eb0b6016aac92b0f46be590360ff9cee48',
      'sha256:ea5d645f34a472f4710b9273b225d6f15433d6d17ae8ed1af3c03686a225c8c4',
      'sha256:eb95add0fc06a54d19998c4707dd0b0ba861a22cfee6d8e6631499beeea18e25',
      // C.3: genuine outgoing52 preserved in953 before the current53 cutover.
      'sha256:f036ccdd62c4ac2a700a27796631e1c4f8c85f9cccfb14ac6850083fb8dba5f2',
      'sha256:f84ae77ec59a0d7ca7cdd89115456504ddecbde2c6e3839936e4951bd65bce61',
      // Authentic P11 core25, preserved in the v2 public corpus and copied core control.
      'sha256:fe9bf4558dc12abc5f258ba8b8f581242e06361cfbae8ae31d8c676f6c7a6460',
    ])
  })
})

// Append to EXISTING tests/bridge-runtime-checkpoint.test.ts; bindings in IMPORTS.txt.
// Constructed in-memory checkpoint control using admitted historical capture slots.
// This is NOT a captured production57 checkpoint or a new genuine restart record.
const C17_SHIPPED_OUTGOING_57 = 'sha256:74826ef419bfa816647b3de156de3e24fb50327879e207c844c1e1a12b9c1253'

describe('C17 shipped projection57 carry-forward', () => {
  it('registers the actual shipped projection57 identity, independently of map iteration', () => {
    expect(SUPPORTED_PRIOR_PROTOCOL_4_SCHEMA_IDS.get(C17_SHIPPED_OUTGOING_57)).toBe('projection-v57')
    expect(C17_SHIPPED_OUTGOING_57).not.toBe(SCHEMA_ID)
  })

  it('independently migrates two admitted Save47 slots under actual shipped57 and discards opaque prior journal', () => {
    // Reuse retained actual Save45 captures and PUBLIC lawful migration. No Save48
    // projection, header retag, cash edit or manufactured receipt enters these slots.
    const current45 = accepted45('research').old
    const saved45 = accepted45('baseline265').old
    expect(current45.state.market.tick).toBe(267)
    expect(saved45.state.market.tick).toBe(265)
    const original45 = [shipped47Save.stableStringify(current45), shipped47Save.stableStringify(saved45)]
    const current47 = shipped47Save.migrateToV47(current45)
    const saved47 = shipped47Save.migrateToV47(saved45)
    expect(shipped47Save.stableStringify(current45)).toBe(original45[0])
    expect(shipped47Save.stableStringify(saved45)).toBe(original45[1])
    expect(current47.saveVersion).toBe(47)
    expect(saved47.saveVersion).toBe(47)
    const before47 = [shipped47Save.stableStringify(current47), shipped47Save.stableStringify(saved47)]
    expect(shipped47Save.validateSaveV47(current47)).toBe(current47)
    expect(shipped47Save.validateSaveV47(saved47)).toBe(saved47)
    expect(shipped47Save.stableStringify(current47)).toBe(before47[0])
    expect(shipped47Save.stableStringify(saved47)).toBe(before47[1])
    const currentSaveJson = shipped47Save.exportSave(current47)
    const savedSaveJson = shipped47Save.exportSave(saved47)
    expect(currentSaveJson).not.toBe(savedSaveJson)
    const expectedCurrent = shipped47Save.migrateToLive(shipped47Save.importSave(currentSaveJson))
    const expectedSaved = shipped47Save.migrateToLive(shipped47Save.importSave(savedSaveJson))
    const priorBytes = priorProtocol4Bytes({
      schemaId: C17_SHIPPED_OUTGOING_57,
      sessionId: 'constructed-shipped57-session',
      stateRevision: 17,
      currentSaveJson,
      savedSaveJson,
      journal: [opaqueJournalEntry('constructed-shipped57-command', 'actual57-opaque-unit-control')],
    })
    const loaded = loadBridgeRuntimeCheckpoint(priorBytes, undefined, () => 'fresh-shipped57-unit-session')
    expect(loaded.migratedFromProtocolVersion).toBe(PROTOCOL_VERSION)
    expect(loaded.hydrated.checkpoint).toMatchObject({
      schemaId: SCHEMA_ID, protocolVersion: PROTOCOL_VERSION,
      sessionId: 'fresh-shipped57-unit-session', stateRevision: 0, journal: [],
    })
    expect(loaded.hydrated.journal).toEqual([])
    // Whole envelopes, not a clock-only or current-slot copied-to-saved check.
    expect(loaded.hydrated.currentSave).toEqual(expectedCurrent)
    expect(loaded.hydrated.savedSave).toEqual(expectedSaved)
    expect(loaded.hydrated.currentSave.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(loaded.hydrated.savedSave?.saveVersion).toBe(LIVE_SAVE_VERSION)
    expect(loaded.hydrated.currentSave.state.market.tick).toBe(267)
    expect(loaded.hydrated.savedSave?.state.market.tick).toBe(265)
    expect(loaded.hydrated.checkpoint.currentStateDigest).toBe(sha256(loaded.hydrated.checkpoint.currentSaveJson))
    expect(loaded.hydrated.checkpoint.savedStateDigest).toBe(sha256(loaded.hydrated.checkpoint.savedSaveJson!))
    const encoded = encodeBridgeRuntimeCheckpoint(loaded.hydrated.checkpoint)
    const reloaded = loadBridgeRuntimeCheckpoint(encoded)
    expect(reloaded.migratedFromProtocolVersion).toBeNull()
    expect(reloaded.hydrated.checkpoint).toEqual(loaded.hydrated.checkpoint)
    expect(encodeBridgeRuntimeCheckpoint(reloaded.hydrated.checkpoint)).toBe(encoded)
    expect(shipped47Save.stableStringify(current47)).toBe(before47[0])
    expect(shipped47Save.stableStringify(saved47)).toBe(before47[1])
  })
})
