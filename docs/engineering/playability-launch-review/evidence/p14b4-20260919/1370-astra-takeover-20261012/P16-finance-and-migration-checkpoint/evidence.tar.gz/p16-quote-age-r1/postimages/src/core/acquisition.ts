import { QUOTE_AGE_POLICY_VERSION, quoteAgeRefusal, type QuoteAgePolicyVersion } from './quoteAge.js'
// ── P16C: healthy whole-studio absorption — pure law, quote and retention preview ──
//
// Authority: P16 integration contract §5 ("The initial healthy target must be willing and
// stable-stage both at quote and at closing. It may reject the offer ... the operating player studio
// is NotForSale ... The player explicitly chooses retention with a disclosed no-action default.
// Iterate the target's authoritative contract order, keeping only lawful contracts fitting usable
// capacity and the complete transaction's affordability ... Non-retained healthy staff get the lawful
// capped exit once, charged to the target in its closing account. Retained work cannot outlive its
// lawful required participants: continue the required participants and capacity through its
// obligations, or take an explicit producer-supported cancellation/write-off ... consideration is the
// agreed non-cash asset/business price; target cash transfers at par after its actual closing exits,
// including a negative amount. Closing outlay is consideration minus that post-exit cash, plus
// separately named real charges exactly once. Guarantees are disclosed beside value, never subtracted
// ... There is no max(0, price - guarantees) shortcut ... A healthy target carrying an outstanding v1
// distress loan is refused ... Cancel target in-flight research while retaining verified work ...
// Facilities do not move to the buyer"), §7 group H; 1362-O §5.4, §5.6, §5.8, §5.9.
//
// r2 (review F2/F24/F59) USABLE CAPACITY: the SHARED OPERATIONS ALLOCATOR decides, CUMULATIVELY. The target's
// productions are seated in target order into the buyer's operations, each admission's returned operations carried into
// the next, against the buyer's present commitments (its own workflows plus the installation, script, casting and set
// occupancy the live advances hand the allocator). A production whose present phase the allocator cannot seat now
// (`QueueableCapacityRefusal`) does not fit usable capacity: `cancelRequired`, `noCapacity:<capability>`. Every later
// phase must also find usable capacity in the buyer's facilities (a facility of the capability, `noFacility`, with at
// least one slot, `noCapacity`); when those later phases compete for time with the buyer's own work, the same allocator
// queues them at run time exactly as it queues the buyer's own pictures. No headcount cap is invented. The no-action
// default keeps no person whose busy work cannot continue (`workCannotContinue`); an explicit choice may, and the
// coupled outcome is quoted either way.
//
// r2 (review F6/F7/F8/F13/F33): the quote needs the buyer's OWN fresh, full-scope, paid disclosure about the target
// (1362-O 5.5; contract §6) before it reveals anything; the target's consent is checked AT THE QUOTE against an ask that
// prices the post-exit cash the buyer takes at par (1362-O 5.8: no acquisition windfall); P14's person-choice refusals
// (a Distrusted issuer, a Nemesis on the roster) bind the buyer like any other employer; money is whole dollars (the
// target's cash floored; fixed cost and reserve rounded up).
//
// CONTRACT GAP (P16C): executable closing is DEFERRED. Contract §2 names its producer prerequisites
// — the P12 operating-state discriminator with terminal provenance, employer-bound continuation
// contract ids with exact employment reason values and linked validation, and Wave 4's typed
// dispositions — none of which exist at base 6510c971 (P15B Wave 4 is concurrent work). The pure
// law below (eligibility, disclosure, consent policy, money separation, retention preview,
// dispositions) is the complete quote; `closeAbsorption` refuses loudly and names the prerequisites.
// Research and the inventor price advantage (1362-O 5.9) are QUOTED, not executed: nothing is
// cancelled and no advantage moves until closing exists.

import { contractEndRefusal } from './careerLifecycle.js'
import { castingOccupiedFacilitySlots } from './castingSessions.js'
import { guaranteedComp, terminationCost, weeklySalary } from './employment.js'
import type { RivalBusiness } from './hollywoodTypes.js'
import { resourceClaims, setOccupiedFacilitySlots } from './occupancy.js'
import { addManagedProductionWorkflow } from './operations.js'
import { productionPhaseForRemainingTicks, requirementsForPhase } from './productionPhases.js'
import { QueueableCapacityRefusal } from './productionQueue.js'
import { libraryValuationV1 } from './propertyValuation.js'
import { conditionFactsFor, corporateConditionReaders, permittedBidderRefusal, spendableCash, weeklyFixedCost, type CorporateConditionReaders } from './rightsFinance.js'
import { resolveTitles, subjectsHeldBy, type DiligenceScopeItem, type RightSubject } from './rights.js'
import { scriptOccupiedFacilitySlots } from './scriptDevelopment.js'
import { personReservationRefusal } from './talentMarket.js'
import { rivalInstallationSlots } from './technologyRival.js'
import { TUNING } from './tuning.js'
import type { FacilityCapability, GameState, Production, ProductionPhase, ScriptDevelopment, StudioOperations } from './types.js'

export type RetentionChoice = { kind: 'default' } | { kind: 'explicit'; contractIds: string[] }
export type AbsorptionInput = { quotedAtWeek?: number; quoteAgePolicyVersion?: QuoteAgePolicyVersion; buyerId: string; targetId: string; consideration: number; retention: RetentionChoice; disclosureId: string | null }
export type ContractRetentionReason = 'issuerDistrusted' | 'nemesisOnRoster' | 'retirementCap' | 'unaffordable' | 'notSelected' | 'workCannotContinue' | null
export type AbsorptionContractQuote = {
  contractId: string; talentId: string; annualSalary: number; signingBonus: number; startWeek: number; endWeekExclusive: number; weeklySalary: number
  retained: boolean; reason: ContractRetentionReason
  /** The target production this person is a required participant of (first in the target's production order), or null. */
  busyOn: string | null
  /** The lawful capped exit, charged once to the target when not retained. */
  exitCost: number
  /** Remaining guaranteed salary: DISCLOSED beside value, never netted against consideration. */
  guarantee: number
}
export type ProductionDisposition = 'continues' | 'cancelRequired'
export type ProductionDispositionReason = 'missingParticipants' | 'buyerOperationsNotManaged' | 'productionIdCollision'
  | `noFacility:${FacilityCapability}` | `noCapacity:${FacilityCapability}` | null
export type AbsorptionProductionQuote = {
  productionId: string
  remainingTicks: number
  phase: ProductionPhase
  disposition: ProductionDisposition
  reason: ProductionDispositionReason
  /** The capability the capacity verdict named, when it named one. */
  blockedCapability: FacilityCapability | null
  /** Required participants employed by the target and not retained (for a reason other than this work being unhostable). */
  missingParticipants: string[]
}
export type AbsorptionQuote = {
  kind: 'quote'
  quotedAtWeek: number; quoteAgePolicyVersion: QuoteAgePolicyVersion
  buyerId: string; targetId: string; week: number; consideration: number; disclosureId: string
  rights: RightSubject[]; rightsValue: number | null
  contracts: AbsorptionContractQuote[]
  exitCharges: number; targetCashBeforeExits: number; postExitCash: number; guarantees: number; outlay: number
  /** The target's consent ask at this retention: premium-adjusted library value plus the post-exit cash, whole dollars. */
  ask: number
  resultingWeeklyFixedCost: number; reserveAfter: number; affordable: boolean
  productions: AbsorptionProductionQuote[]
  research: { projectId: string; disposition: 'cancelRetainingVerifiedProgress'; verifiedWork: number; expenditure: number }[]
  facilities: { facilityId: string; disposition: 'remainsWithTargetHistory' }[]
}
export type AbsorptionRefusal = { kind: 'refusal'; refusal: string }

export const ABSORPTION_CLOSING_PREREQUISITES: readonly string[] = [
  'P12 operating-state discriminator and terminal provenance for the absorbed identity',
  'P12/P14 employer-bound continuation contract ids and the exact employment reason values with linked validation',
  'P15B Wave 4 typed dispositions for the target\'s work, runs, research and facilities',
]

/** The disclosure an absorption quote needs: rights, employment and liabilities — everything the quote reveals. */
export const ABSORPTION_DISCLOSURE_SCOPE: readonly DiligenceScopeItem[] = ['rights', 'employment', 'liabilities']

export function absorptionRefusal(state: GameState, buyerId: string, targetId: string, week: number, readers: CorporateConditionReaders = corporateConditionReaders): string | null {
  const h = state.hollywood
  if (!h) return 'noIndustry'
  if (targetId === h.playerStudioId) return 'playerNotForSale'
  if (buyerId === targetId) return 'selfDealing'
  const identity = h.identities.find((i) => i.studioId === targetId)
  if (identity === undefined || identity.enteredWeek === null || !h.businesses.some((b) => b.studioId === targetId)) return 'unknownTarget'
  if (state.rights.estates.some((e) => e.studioId === targetId)) return 'targetTerminal'
  const buyer = permittedBidderRefusal(state, buyerId, week, readers)
  if (buyer !== null) return `buyerNotPermitted:${buyer}`
  const target = conditionFactsFor(state, targetId, week, readers)
  if (target === null) return 'targetConditionUnavailable'
  if (target.stage !== 'stable') return `targetNotStable:${target.stage}`
  if (target.hasOutstandingLoan) return 'targetOutstandingLoan'
  return null
}

/** r2 (F7): null when `disclosureId` is the buyer's own, fresh, full-scope disclosure about this target; else why not. */
export function absorptionDisclosureRefusal(state: GameState, buyerId: string, targetId: string, disclosureId: string | null | undefined, week: number): string | null {
  if (disclosureId === null || disclosureId === undefined) return 'disclosureRequired'
  const record = state.rights.diligence.find((d) => d.id === disclosureId)
  if (record === undefined || record.recipientId !== buyerId || record.target.kind !== 'studio' || record.target.studioId !== targetId) return 'disclosureNotHeld'
  if (!ABSORPTION_DISCLOSURE_SCOPE.every((item) => record.scope.includes(item))) return 'disclosureScope'
  const age = quoteAgeRefusal('disclosure', record.week, week, record.quoteAgePolicyVersion)
  if (age !== null) return age
  if (week >= record.staleFromWeek) return 'staleDisclosure'
  return null
}

/** Close must carry the dated preview; re-quoting current facts never renews an old preview. */
export function absorptionQuoteAgeRefusal(input: AbsorptionInput, week: number, requireCarried: boolean): string | null {
  if (input.quotedAtWeek === undefined && input.quoteAgePolicyVersion === undefined) return requireCarried ? 'absorptionQuoteRequired' : null
  if (input.quotedAtWeek === undefined || input.quoteAgePolicyVersion === undefined) return 'incompleteAbsorptionQuote'
  return quoteAgeRefusal('absorptionPreview', input.quotedAtWeek, week, input.quoteAgePolicyVersion)
}

/** r2 (F8/F33): the consent ask — premium-adjusted library value plus the post-exit cash that moves at par, never below zero. */
export function absorptionAsk(libraryValue: number, postExitCash: number): number {
  return Math.max(0, Math.ceil((libraryValue * (100 + TUNING.RIGHTS_WILLINGNESS_PREMIUM_PERCENT)) / 100) + postExitCash)
}

/** The provisional consent policy: a rival sells its business at or above its ask (`absorptionAsk`). */
export function rivalAbsorptionWillingness(state: GameState, targetId: string, consideration: number, postExitCash: number, week: number)
  : { willing: boolean; reason: string; value: number | null; ask: number | null } {
  const value = libraryValuationV1(state, targetId, week)
  if (value.kind !== 'available') return { willing: false, reason: `valueUnavailable:${value.reason}`, value: null, ask: null }
  const ask = absorptionAsk(value.total, postExitCash)
  return consideration >= ask ? { willing: true, reason: 'willing', value: value.total, ask } : { willing: false, reason: `notWilling:considerationBelowAsk:${ask}`, value: value.total, ask }
}

type Row = Omit<AbsorptionContractQuote, 'retained' | 'reason' | 'busyOn'>

type Verdict =
  | { kind: 'seated' }
  | { kind: 'refused'; reason: Exclude<ProductionDispositionReason, 'missingParticipants' | null>; capability: FacilityCapability | null }

/** A rival's live script development, exactly as hollywoodTick reads it for the allocator. */
function hotDevelopment(b: RivalBusiness): ScriptDevelopment {
  return { mode: 'managed', projects: b.activeScriptOrdinals.map((i) => b.development.projects[i]!) }
}

/** The buyer's operations and the slots its present commitments occupy — the inputs the live advances hand the allocator (tick.ts, hollywoodTick.ts). */
function buyerOperations(state: GameState, buyerId: string): { operations: StudioOperations; occupied: ReadonlySet<string> } {
  const h = state.hollywood!
  if (buyerId === h.playerStudioId) {
    return { operations: state.operations, occupied: new Set<string>([
      ...resourceClaims(state).filter((c) => c.owner === 'installation' && c.facilitySlotKey !== null).map((c) => c.facilitySlotKey!),
      ...scriptOccupiedFacilitySlots(state.scriptDevelopment),
      ...castingOccupiedFacilitySlots(state.castingSessions),
      ...setOccupiedFacilitySlots(state.sets, state.operations, state.scriptDevelopment, state.castingSessions),
    ]) }
  }
  const b = h.businesses.find((x) => x.studioId === buyerId)!
  return { operations: b.operations, occupied: new Set<string>([...scriptOccupiedFacilitySlots(hotDevelopment(b)), ...rivalInstallationSlots(state.technology, b)]) }
}

/** Every capability a production still needs, from its present phase through release-ready, in requirement order. */
function remainingCapabilities(remainingTicks: number): FacilityCapability[] {
  const out: FacilityCapability[] = []
  for (let t = remainingTicks; t >= 1; t--) for (const c of requirementsForPhase(productionPhaseForRemainingTicks(t))) if (!out.includes(c)) out.push(c)
  return out
}

/** The shared allocator's CUMULATIVE verdicts: each target production, in target order, against the buyer and every earlier admission. */
function seatTargetProductions(operations: StudioOperations, occupied: ReadonlySet<string>, productions: readonly Production[]): Map<string, Verdict> {
  const verdicts = new Map<string, Verdict>()
  let seated = operations
  for (const p of productions) {
    if (seated.mode !== 'managed') { verdicts.set(p.id, { kind: 'refused', reason: 'buyerOperationsNotManaged', capability: null }); continue }
    if (seated.workflows.some((w) => w.productionId === p.id)) { verdicts.set(p.id, { kind: 'refused', reason: 'productionIdCollision', capability: null }); continue }
    const needs = remainingCapabilities(p.remainingTicks)
    const absent = needs.find((c) => !seated.facilities.some((f) => f.capability === c))
    if (absent !== undefined) { verdicts.set(p.id, { kind: 'refused', reason: `noFacility:${absent}`, capability: absent }); continue }
    const empty = needs.find((c) => seated.facilities.filter((f) => f.capability === c).every((f) => f.capacity < 1))
    if (empty !== undefined) { verdicts.set(p.id, { kind: 'refused', reason: `noCapacity:${empty}`, capability: empty }); continue }
    try {
      seated = addManagedProductionWorkflow(seated, { id: p.id, startTick: p.startTick, remainingTicks: p.remainingTicks }, occupied)
      verdicts.set(p.id, { kind: 'seated' })
    } catch (error) {
      if (!(error instanceof QueueableCapacityRefusal)) throw error
      verdicts.set(p.id, { kind: 'refused', reason: `noCapacity:${error.capability}`, capability: error.capability })
    }
  }
  return verdicts
}

const participantsOf = (p: Production): string[] => [p.writerId, p.directorId, ...p.craftIds, ...Object.values(p.cast)]

export function quoteAbsorption(state: GameState, input: AbsorptionInput, week: number, readers: CorporateConditionReaders = corporateConditionReaders): AbsorptionQuote | AbsorptionRefusal {
  const age = absorptionQuoteAgeRefusal(input, week, false)
  if (age !== null) return { kind: 'refusal', refusal: age }
  const refusal = absorptionRefusal(state, input.buyerId, input.targetId, week, readers)
  if (refusal !== null) return { kind: 'refusal', refusal }
  if (!Number.isSafeInteger(input.consideration) || input.consideration < 0) return { kind: 'refusal', refusal: 'invalidConsideration' }
  const disclosure = absorptionDisclosureRefusal(state, input.buyerId, input.targetId, input.disclosureId, week)
  if (disclosure !== null) return { kind: 'refusal', refusal: disclosure }
  const h = state.hollywood!
  const business = h.businesses.find((b) => b.studioId === input.targetId)!
  // The target's authoritative contract order: its live employment intervals in root order.
  const rows: Row[] = h.activeEmploymentOrdinals.map((i) => h.employment[i]!)
    .filter((e) => e.studioId === input.targetId && e.endedWeek === null && e.terms.startWeek <= week && week < e.terms.endWeekExclusive)
    .map((e) => ({ contractId: e.contractId, talentId: e.terms.talentId, annualSalary: e.terms.annualSalary, signingBonus: e.terms.signingBonus,
      startWeek: e.terms.startWeek, endWeekExclusive: e.terms.endWeekExclusive, weeklySalary: weeklySalary(e.terms.annualSalary),
      exitCost: terminationCost(e.terms, week), guarantee: guaranteedComp(e.terms, week) }))
  if (input.retention.kind === 'explicit') {
    for (const id of input.retention.contractIds) if (!rows.some((r) => r.contractId === id)) return { kind: 'refusal', refusal: `unknownContract:${id}` }
  }
  // Work: who is busy on which target production, and the allocator's cumulative verdict on hosting each one.
  const busyOn = new Map<string, string>()
  for (const p of business.productions) for (const id of participantsOf(p)) if (!busyOn.has(id)) busyOn.set(id, p.id)
  const buyer = buyerOperations(state, input.buyerId)
  const verdicts = seatTargetProductions(buyer.operations, buyer.occupied, business.productions)
  const hostable = (talentId: string): boolean => { const pid = busyOn.get(talentId); return pid === undefined || verdicts.get(pid)!.kind === 'seated' }
  const buyerFixed = weeklyFixedCost(state, input.buyerId)
  const spendable = spendableCash(state, input.buyerId)
  const targetCash = Math.floor(business.account.cash)
  const money = (retained: ReadonlySet<string>) => {
    const exitCharges = rows.filter((r) => !retained.has(r.contractId)).reduce((s, r) => s + r.exitCost, 0)
    const postExitCash = targetCash - exitCharges
    const outlay = input.consideration - postExitCash
    const kept = rows.filter((r) => retained.has(r.contractId))
    const resultingWeeklyFixedCost = Math.ceil(buyerFixed + kept.reduce((s, r) => s + r.weeklySalary, 0) + TUNING.OVERHEAD_PER_EMPLOYEE * kept.length)
    const reserveAfter = TUNING.RIGHTS_RESERVE_WEEKS * resultingWeeklyFixedCost
    return { exitCharges, postExitCash, outlay, resultingWeeklyFixedCost, reserveAfter, affordable: spendable - outlay >= reserveAfter,
      guarantees: kept.reduce((s, r) => s + r.guarantee, 0) }
  }
  // Person law first (P14: "I will not work for them" needs neither a price nor a seat), then the retirement cap.
  const personRefusal = (r: Row): ContractRetentionReason => personReservationRefusal(state, r.talentId, input.buyerId, week)
    ?? (contractEndRefusal(state, r.talentId, r.endWeekExclusive) === null ? null : 'retirementCap')
  const reasons = new Map<string, ContractRetentionReason>()
  const retained = new Set<string>()
  if (input.retention.kind === 'default') {
    // The disclosed no-action default: target order; the person consents; lawful; work that can be hosted; affordable for the COMPLETE transaction.
    for (const r of rows) {
      const person = personRefusal(r)
      if (person !== null) { reasons.set(r.contractId, person); continue }
      if (!hostable(r.talentId)) { reasons.set(r.contractId, 'workCannotContinue'); continue }
      if (money(new Set([...retained, r.contractId])).affordable) retained.add(r.contractId)
      else reasons.set(r.contractId, 'unaffordable')
    }
  } else {
    const chosen = new Set(input.retention.contractIds)
    for (const r of rows) {
      if (!chosen.has(r.contractId)) { reasons.set(r.contractId, 'notSelected'); continue }
      const person = personRefusal(r)
      if (person !== null) { reasons.set(r.contractId, person); continue }
      retained.add(r.contractId)
    }
  }
  const m = money(retained)
  // The target consents at the quote (contract §5), to a price that includes the cash it hands over at par.
  const willingness = rivalAbsorptionWillingness(state, input.targetId, input.consideration, m.postExitCash, week)
  if (!willingness.willing) return { kind: 'refusal', refusal: `targetNotWilling:${willingness.reason.replace(/^notWilling:/, '')}` }
  const contracts: AbsorptionContractQuote[] = rows.map((r) => ({ ...r, busyOn: busyOn.get(r.talentId) ?? null, retained: retained.has(r.contractId),
    reason: retained.has(r.contractId) ? null : reasons.get(r.contractId) ?? 'notSelected' }))
  const employees = new Map(rows.map((r) => [r.talentId, r.contractId]))
  const productions: AbsorptionProductionQuote[] = business.productions.map((p) => {
    const missing = [...new Set(participantsOf(p).filter((id) => {
      const contractId = employees.get(id)
      return contractId !== undefined && !retained.has(contractId) && reasons.get(contractId) !== 'workCannotContinue'
    }))]
    const verdict = verdicts.get(p.id)!
    const base = { productionId: p.id, remainingTicks: p.remainingTicks, phase: productionPhaseForRemainingTicks(p.remainingTicks), missingParticipants: missing }
    if (verdict.kind === 'refused') return { ...base, disposition: 'cancelRequired', reason: verdict.reason, blockedCapability: verdict.capability }
    if (missing.length > 0) return { ...base, disposition: 'cancelRequired', reason: 'missingParticipants', blockedCapability: null }
    return { ...base, disposition: 'continues', reason: null, blockedCapability: null }
  })
  const rights = subjectsHeldBy(resolveTitles(state), state.rights.estates, input.targetId, week)
  const research = (state.technology.projects ?? []).filter((p) => p.studioId === input.targetId && p.status !== 'completed' && p.status !== 'cancelled')
    .map((p) => ({ projectId: p.id, disposition: 'cancelRetainingVerifiedProgress' as const, verifiedWork: p.verifiedWork, expenditure: p.expenditure }))
  const facilities = business.operations.facilities.map((f) => ({ facilityId: f.id, disposition: 'remainsWithTargetHistory' as const }))
  return { kind: 'quote', quotedAtWeek: input.quotedAtWeek ?? week, quoteAgePolicyVersion: input.quoteAgePolicyVersion ?? QUOTE_AGE_POLICY_VERSION, buyerId: input.buyerId, targetId: input.targetId, week, consideration: input.consideration, disclosureId: input.disclosureId!, rights,
    rightsValue: willingness.value, contracts, exitCharges: m.exitCharges, targetCashBeforeExits: targetCash,
    postExitCash: m.postExitCash, guarantees: m.guarantees, outlay: m.outlay, ask: willingness.ask!, resultingWeeklyFixedCost: m.resultingWeeklyFixedCost,
    reserveAfter: m.reserveAfter, affordable: m.affordable, productions, research, facilities }
}

/** Deferred by contract §2: refuses loudly, names the producer prerequisites, changes nothing. */
export function closeAbsorption(_state: GameState, input: AbsorptionInput, week: number): never {
  const age = absorptionQuoteAgeRefusal(input, week, true)
  if (age !== null) throw new Error(`absorption closing refused: ${age}`)
  throw new Error(`absorption closing of ${input.targetId} by ${input.buyerId} at week ${week} is deferred: it requires the ${ABSORPTION_CLOSING_PREREQUISITES.join('; ')}. ` +
    'Use quoteAbsorption for the preview (P16 contract §2, §5).')
}
