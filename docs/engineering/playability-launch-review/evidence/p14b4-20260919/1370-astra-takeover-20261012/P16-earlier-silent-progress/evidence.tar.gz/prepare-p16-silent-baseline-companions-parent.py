import pathlib,json,hashlib,re,difflib,os
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r7';D=A/'p16-work-release61-integration-runner-r9';out=A/'p16-work-release61-integration-r9-run';p=A/'p16-silent-baseline-and-relationships-r1';test=A/'p16-continued-work-silent-early-tests-r1-baseline'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
assert (A/'P16-MANUAL-CANCEL-COMPANIONS-R8-ACTUAL-REVIEW.md').is_file()
m=json.loads((p/'MANIFEST.json').read_text());D.mkdir()
ids=json.loads((test/'EXPECTED-IDENTITIES.json').read_text())
one=dict(file=ids['file'],sourceSHA256=sha(K/ids['file']),count=1,names=ids['identities'],leaves=[dict(fullName=n,budgetMs=5000,budgetSource='unchanged core default; complete setup inside test') for n in ids['identities']])
assert len(one['names'])==1 and one['sourceSHA256']=='0f8858fcf41242cb076134c4bfe4514df778b80813ab9448563e9791b3e3cc39'
relationship=next(row for row in json.loads((A/'p16-manual-cancel-companion-selection-format-r2/EXPECTED-IDENTITIES.json').read_text()) if row['file']=='tests/p14b5-relationships.test.ts')
assert relationship['sourceSHA256']==sha(K/relationship['file']) and len(relationship['names'])==53
expected=[relationship,one];write('EXPECTED-IDENTITIES.json',expected)
commands=json.loads((old/'SELECTION.json').read_text());commands[-1][9]='--outputFile.json='+str(out/'results.json');commands[-1][10:]=[r['file'] for r in expected];write('SELECTION.json',commands)
(D/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
account=(A/'p16-work-release61-integration-runner-r8/account-results.py').read_text().replace('complete five manual-cancel companion files; exact original per-leaf budgets and inherited failures remain visible','complete relationships53 plus genuine early SILENT baseline1; original budgets and all failures retained')
(D/'account-results.py').write_text(account)
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(A/'p16-work-release61-integration-r7-run'),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root compiler then complete manual-cancel three-test file commands','literal root compiler then relationships53 and early SILENT baseline1 commands')
s=s.replace('fresh root compiler then complete manual-cancel3 with actual relationships/staffing/reader/publication rollback; original failed baseline retained','fresh root compiler; complete relationships53 after exact zero-only helper repair and early SILENT baseline1 on unchanged product source; all inherited failures and genuine baseline RED retained')
s=s.replace('tests/p16-continued-work-cancel.test.ts\nec=$?', ' '.join(r['file'] for r in expected)+'\nec=$?')
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((A/'p16-work-release61-integration-runner-r8/BINDINGS.json').read_text());b.pop('rootReuse')
b.update(package=str(p),patchSHA256=sha(p/'PATCH.diff'),manifestSHA256=sha(p/'MANIFEST.json'),pathCount=len(m['files']),plannedPathCount=len(m['files']),scope='Exact four-zero movement test projection repair and prospective genuine early SILENT baseline',executionScope='Fresh compiler and complete2 files54 original per-leaf budgets; current product source unchanged from185; early acquisition RED prospective, no downstream acceptance if unreached; all inherited failures retained',expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},finalCleanTestAdmission='Independent baseline and zero-only helper reviews KEEP; no test body weakening or product source changes',installedSourceReceiptSHA256=sha(p/'INSTALL-RECEIPT.json'))
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',p/'INSTALL-RECEIPT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R8-PARENT-RESULT.json',A/'P16-MANUAL-CANCEL-COMPANIONS-R8-ACTUAL-REVIEW.md',A/'P16-SILENT-BASELINE-RELATIONSHIPS-INSTALL-SPEC.json',test/'SOURCE.patch',test/'MANIFEST.json',test/'EXPECTED-IDENTITIES.json',A/'P16-CONTINUED-WORK-SILENT-EARLY-BASELINE-R1-INDEPENDENT-REVIEW.md',A/'p16-relationships-projection-money-fix-r1/SOURCE.patch',A/'p16-relationships-projection-money-fix-r1/MANIFEST.json',A/'P16-RELATIONSHIPS-PROJECTION-MONEY-FIX-R1-INDEPENDENT-REVIEW.md',A/'p16-manual-cancel-companion-selection-format-r2/EXPECTED-IDENTITIES.json',A/'p16-manual-cancel-companion-selection-format-r2/FORMAT-CORRECTION.json']
for q in paths:
 assert q.is_file()
 if str(q) not in {r['path'] for r in b['artifacts']}:b['artifacts'].append(dict(path=str(q),sha256=sha(q)))
write('BINDINGS.json',b)
(D/'DELTA-vs-r7-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r7/runner.sh',tofile='r9/runner.sh')))
(D/'README.md').write_text('UNRUN: parent-only root compiler then complete relationships53 plus actual-input early SILENT baseline1. Product source unchanged from qualified185; only exact-four-zero historical test projection helper repair and new baseline. No historical reader widening, budgets unchanged, no unreached assertion credit. Original R8 failures/timing/accounting98 preserved.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
