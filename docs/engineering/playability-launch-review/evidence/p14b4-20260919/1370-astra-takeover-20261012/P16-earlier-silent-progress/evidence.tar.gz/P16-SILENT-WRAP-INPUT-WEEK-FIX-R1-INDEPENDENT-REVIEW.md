# SILENT wrap input-week correction R1

KEEP for installation and measured successor qualification; UNRUN. Exact SOURCE0f6c1e04daebbe34bd6239f9cdb206ffb3a96cb4103845e5fa3abad0e3ffb569 and MANIFEST7c972866546c23f644992eb98f3e4e8e3e7650c2462ff6b2d47f0f418f70384c verified.

Both literal joins correct a real observer-clock error. tick.ts:268 creates the event sink with currentTick. operations.ts:1343 emits wrapped without a week override; StudioEventSink.append at studioEvents.ts:181 therefore preserves that input week. commitStudioEvents(...,currentTick+1) uses its last argument only for compaction; it appends the already-stamped drafts. Thus native work input166 produces observed state167 with wrapped.week166, matching actual workStep.week, not week+1.

The two changes align the current collision-view exception and the authoritative exact-one wrap proof. Buyer ownership, original creator production/body, actual4→3 step, admissible date, duplicate-owner refusal, exact-one/none-before-wrap checks remain. Allocator/default frozen contexts remain untouched, and no event or producer/history is retimed. This addresses the R10 full-save first cause without a generic identity exception or weakening a frozen reader.

The additional test assertion should pin wrapped.week166 on the fixed route. Successful save/replay, ready/hold/explicit commitment/release and later buyer title/run assertions remain unqualified until actually measured; this static review does not infer their success. Original R10 failures/timings remain retained. No runtime or K/R changes performed.
