# S5 mid-deployment serialization correction — STATIC / UNRUN

Only import existing exportCurrentState and replace three exportSave(makeSave(...)) pairs for state, resumed and uninterrupted. save.ts:6729 validates current state then JSON-detaches; exportSave:6746 validates that already-admitted save again then stableStringify. exportCurrentState:6752 is exactly stableStringify(makeSave(state)), preserving current validation/detachment/canonical bytes while removing the redundant second validation in each pair.

Every assertion remains: the real exportSave(importSave(json))===json roundtrip, mid-deployment operationalWeek=null and final resumed/uninterrupted canonical byte equality. Actual importSave(json) for resumed branch remains separate. No setup/body/tick/policy changes: genuine generated two-Laboratory setup through780 plus actual research completion and both2tick branches remain. Default5000ms budget unchanged. No cached state, fixture retag, skipped validator boundary, performance pass claim or repeat retry. Potential benefit is limited to three duplicate full validations; the full780tick setup remains and actual time must be measured in next relevant coherent gate.

Sparse A-only patch plus complete original/postimage content hashes; no K/R writes or tests/runtime/compiler/profile executed.
