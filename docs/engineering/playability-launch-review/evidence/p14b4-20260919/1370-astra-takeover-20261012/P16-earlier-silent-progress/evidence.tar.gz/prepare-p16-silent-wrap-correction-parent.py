from pathlib import Path
import json,hashlib,os,re,difflib
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r10';D=A/'p16-work-release61-integration-runner-r11';out=A/'p16-work-release61-integration-r11-run';p=A/'p16-silent-earlier-wrap-corrected-r1'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
m=json.loads((p/'MANIFEST.json').read_text());D.mkdir()
expected=json.loads((old/'EXPECTED-IDENTITIES.json').read_text())
for row in expected:row['sourceSHA256']=sha(K/row['file'])
assert len(expected)==2 and sum(len(x['names']) for x in expected)==57
write('EXPECTED-IDENTITIES.json',expected)
commands=json.loads((old/'SELECTION.json').read_text());commands[-1][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
for name in ['auto_freeze.py','account-results.py']:(D/name).write_bytes((old/name).read_bytes())
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(A/'p16-work-release61-integration-r10-run'),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('fresh root compiler; complete relationships53 after guarded helper repair and early SILENT final4 through native firsttake/wrap/explicitrelease/save; all original and inherited failures retained','fresh root compiler; unchanged complete57 after exact input-week wrap joins and strict inline historical test projection correction; all prior and inherited failures retained')
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text());b.update(package=str(p),patchSHA256=sha(p/'PATCH.diff'),manifestSHA256=sha(p/'MANIFEST.json'),pathCount=len(m['files']),plannedPathCount=len(m['files']),expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},installedSourceReceiptSHA256=sha(p/'INSTALL-RECEIPT.json'),scope='Exact native input-week wrap reader correction, additive observed/input-week test and strict inline bytes historical test projection',executionScope='Fresh root compiler then same complete57 original per-leaf budgets; no production event retime, historical reader weakening or waived inherited failures; native/player/wholeP16 acceptance remains separate',finalCleanTestAdmission='Independent exact two-line source and parent mechanical test corrections KEEP; original R10 collision and inline guard failures retained')
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',p/'INSTALL-RECEIPT.json',A/'P16-SILENT-WRAP-CORRECTION-INSTALL-SPEC.json',A/'p16-silent-wrap-input-week-fix-r1/SOURCE.patch',A/'p16-silent-wrap-input-week-fix-r1/MANIFEST.json',A/'P16-SILENT-WRAP-INPUT-WEEK-FIX-R1-INDEPENDENT-REVIEW.md',A/'p16-silent-wrap-and-inline-tests-parent-r1/DELTA.patch',A/'p16-silent-wrap-and-inline-tests-parent-r1/MANIFEST.json',A/'P16-SILENT-WRAP-INLINE-TESTS-PARENT-R1-INDEPENDENT-REVIEW.md',A/'P16-WORK-RELEASE61-INTEGRATION-R10-PARENT-RESULT.json',A/'P16-SILENT-FINAL-COMPANIONS-R10-ACTUAL-REVIEW.md']
for q in paths:
 assert q.is_file()
 if str(q) not in {r['path'] for r in b['artifacts']}:b['artifacts'].append(dict(path=str(q),sha256=sha(q)))
write('BINDINGS.json',b)
(D/'DELTA-vs-r10-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r10/runner.sh',tofile='r11/runner.sh')))
(D/'README.md').write_text('UNRUN: root compiler and unchanged complete57; exact native wrap inputweek correction, additive eventstamp166/observed167 assertion and strict four-zero/current-context test comparison helper. All original failures and timings preserved; no new claim until actual measurement and independent reconciliation.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
