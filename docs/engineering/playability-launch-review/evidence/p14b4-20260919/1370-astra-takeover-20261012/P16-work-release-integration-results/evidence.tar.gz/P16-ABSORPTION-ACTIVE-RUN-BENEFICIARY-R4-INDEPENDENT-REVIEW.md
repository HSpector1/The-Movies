# Active-run beneficiary expectation R4

KEEP exact additive expectation, UNRUN. Postc8b0dec556f47d16a55b17ebd7a27e6b2d22cb4a7c6683531a7508e715ec4847/deltac40fef67df428150a56d20a3bb7112647a590749e1072562a809aa9b909605d9; all artifact hashes verified/pre5c04 preserved.

One exact toEqual adds beneficiaryFromWeek at actual closing input tick170. Existing acquisition producer records C for inherited active runs, while canonical validator independently requires C (future continued films require their actual later release). All prior prefix/cumulative/identity checks remain exact, no partialmatcher or deletion. Same2 identities/default5s/mutants/purity and measured first-cause correction retained.

Current181 both leaves stopped at this old shape before later settlement/mutants; prior167 twoPASS is separately retained and cannot qualify changed181 later behavior. Complete corrected-file execution remains necessary. No runtime/K/R changes by reviewer.
