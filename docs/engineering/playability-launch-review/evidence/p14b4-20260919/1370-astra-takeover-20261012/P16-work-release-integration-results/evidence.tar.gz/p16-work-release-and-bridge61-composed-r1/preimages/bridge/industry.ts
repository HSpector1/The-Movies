import {filmScoreTenths} from '../src/core/powerRanking.js'
/** Public, bounded Industry reads. Authoritative IDs and facts only; no private business inputs. */
import {campaignDate} from '../src/core/calendar.js'
import {technologyAnnouncements} from '../src/core/technologyDisclosure.js'
import {technologyEntry} from '../src/core/technologyCatalogue.js'
import {filmAudienceScore} from '../src/core/index.js'
import {publicConditionLabel} from '../src/core/corporateNotices.js'
import {flattenParticipants} from '../src/core/starPower.js'
import type {GameState,Standing,PowerRankingRecord} from '../src/core/types.js'
import type {HollywoodChartSnapshot,IndustryReceipt} from '../src/core/hollywoodTypes.js'
import {INDUSTRY_LANES,type IndustryPage,type IndustryQuery,type IndustrySummary,type PowerRankingPage} from './schema/industry-schema.ts'
import {PROTOCOL_VERSION,SCHEMA_ID,SNAPSHOT_VERSION} from './protocol.ts'
import {snapshotBuildContextFor} from './snapshot-build-context.ts'
import {studioPresence} from '../src/core/presence.ts'
import {historyProjection} from './history.ts'
import {laboratoryPage,type LaboratoryIntent} from './laboratory.ts'
import {plansPage,type PlanIntent} from './plans.ts'
import {officePage,type OfficeIntent} from './office.ts'
import {contractTermLabel} from './contract.ts'
import {marketPage,MARKET_CLOSED_PAGE_SIZE} from './market.ts'
import {personWorldRoute} from './world.ts'
import {personCareer,personLifecycle} from './lifecycle.ts'
import {recentCareerEvents} from '../src/core/studioCalendar.ts'
import {studioTrustDescriptor} from '../src/core/promises.ts'

type Film=IndustryPage['films'][number]
type Credit=IndustryPage['credits'][number]
type Person=IndustryPage['people'][number]
type Studio=IndustryPage['studios'][number]
type Activity=IndustryPage['activities'][number]
const byText=(a:string,b:string)=>a<b?-1:a>b?1:0
const laneLabels={audienceAwareness:'Audience Awareness',industryPrestige:'Industry Prestige',commercialConfidence:'Commercial Confidence',output:'Released Films'}
const meanings={audienceAwareness:'How familiar audiences are with this studio.',industryPrestige:'The studio’s standing within the film industry.',commercialConfidence:'Confidence in the studio’s commercial record.',output:'Canonical released films, including separately labelled authored history.'}
function observedAdoption(state:GameState,receipt:IndustryReceipt) {
  if(receipt.kind!=='technologyAdopted'||receipt.week>state.market.tick)return null
  const studio=state.hollywood?.identities.find(s=>s.studioId===receipt.studioId&&s.enteredWeek!==null&&s.enteredWeek<=receipt.week)
  if(!studio)return null
  return state.technology?.adoptions.find(a=>a.id===receipt.adoptionId&&a.studioId===receipt.studioId&&
    a.operationalWeek!==null&&a.operationalWeek===receipt.week)??null
}
export function industrySummary(state:GameState):IndustrySummary {
  return {calendar:campaignDate(state.market.tick),available:state.hollywood!==null,playerStudioId:state.hollywood?.playerStudioId??null,
    activeStudioCount:state.hollywood?.identities.filter(s=>s.enteredWeek!==null).length??0,
    notice:state.hollywood?'Separate public comparison lanes. Open a studio, film or person to inspect the record.':'Industry is unavailable in this historical control.'}
}
type Index={studios:Studio[];studioById:Map<string,Studio>;films:Film[];filmById:Map<string,Film>;credits:Map<string,Credit[]>;
  filmsByStudio:Map<string,Film[]>;filmsByPerson:Map<string,Film[]>;people:Map<string,Person>;roster:Map<string,Person[]>;activities:Activity[]}
const indexes=new WeakMap<GameState,Index>()
function indexFor(state:GameState):Index {
  const cached=indexes.get(state);if(cached)return cached
  const h=state.hollywood
  if(!h)throw new Error('Industry authority is unavailable')
  const names=new Map(h.identities.map(s=>[s.studioId,s.name]))
  const employer=new Map<string,string>()
  for(const i of h.activeEmploymentOrdinals){const e=h.employment[i]!;employer.set(e.terms.talentId,e.studioId)}
  for(const c of state.contracts)if(c.startWeek<=state.market.tick&&state.market.tick<c.endWeekExclusive)employer.set(c.talentId,h.playerStudioId)
  const credits=new Map<string,Credit[]>()
  const toCredit=(c:{talentId:string;name:string;role:string}):Credit=>({talentId:c.talentId,name:c.name,role:c.role,
    employerStudioId:employer.get(c.talentId)??null,employerName:names.get(employer.get(c.talentId)??'')??null})
  const films:Film[]=h.films.map(f=>{
    credits.set(f.filmId,f.credits.map(toCredit))
    const authored=f.provenance==='authored-start/v1'
    const liveRun=authored?null:h.businesses.find(b=>b.studioId===f.studioId)?.runs.find(r=>r.productionId===f.filmId)
    return {filmId:f.filmId,studioId:f.studioId,studioName:names.get(f.studioId)!,title:f.title,genre:f.genre,
      dateLabel:authored?`${f.released.year} · Before this campaign`:campaignDate(f.result.releaseTick).label,
      releaseWeek:authored?null:f.result.releaseTick,historicalYear:authored?f.released.year:null,provenance:f.provenance,
      criticScore:authored?f.criticScore:f.result.criticScore,audienceScore:authored?f.audienceScore:filmAudienceScore(state,f.result),
      openingGross:authored?f.openingGross:f.result.boxOffice.opening,totalGross:authored?f.totalGross:liveRun?liveRun.cumulativeGrossPaid:f.result.boxOffice.total,
      runStatus:authored||f.settledWeek!==null?'settled':'inRun',
      businessNotice:authored?'Authored starting record; its run and historical effects were already settled before 1920.':f.settledWeek!==null?'Completed theatrical run. Public gross is distinct from studio revenue.':'The theatrical run is active. Total shows gross earned so far; future receipts, costs and studio revenue remain private.'}
  })
  const concepts=new Map(state.concepts.map(c=>[c.id,c]))
  for(const f of state.studio.releasedFilms) {
    const concept=concepts.get(f.conceptId),run=state.theatricalRuns.find(r=>r.productionId===f.productionId)
    credits.set(f.productionId,f.participants?flattenParticipants(f.participants).map(toCredit):[])
    films.push({filmId:f.productionId,studioId:h.playerStudioId,studioName:names.get(h.playerStudioId)!,title:concept?.title??f.productionId,genre:concept?.genre??'Unknown',dateLabel:campaignDate(f.releaseTick).label,releaseWeek:f.releaseTick,historicalYear:null,provenance:'player-record',criticScore:f.criticScore,audienceScore:filmAudienceScore(state,f),openingGross:f.boxOffice.opening,totalGross:run?.status==='active'?run.cumulativeGrossPaid:f.boxOffice.total,runStatus:run?.status==='active'?'inRun':run?'settled':'recorded',businessNotice:run?.status==='active'?'The run is active; total shows public gross earned so far. Open your film result for private finances.':'Recorded public gross. Open your film result for its full business record.'})
  }
  const filmsByStudio=new Map<string,Film[]>(),filmsByPerson=new Map<string,Film[]>()
  const append=<T>(map:Map<string,T[]>,key:string,row:T)=>{const rows=map.get(key);if(rows)rows.push(row);else map.set(key,[row])}
  for(const film of films){append(filmsByStudio,film.studioId,film);for(const c of credits.get(film.filmId)??[])append(filmsByPerson,c.talentId,film)}
  const people=new Map<string,Person>(),roster=new Map<string,Person[]>()
  const onLot=new Set(studioPresence(state).people.map(p=>p.talentId))
  // P14A.3: the PUBLIC world-route case facts join the row — the open-case status line and
  // the reference that opens that exact case, both null unless a case is open, and neither
  // carrying a figure of any kind. The presence set is reused, never rebuilt per person.
  for(const t of state.talent){const owner=employer.get(t.id)??null;const route=personWorldRoute(state,t.id,onLot.has(t.id));const lifecycle=personLifecycle(state,t),career=personCareer(state,t);const person:Person={careerStatus:career.status,careerLine:career.line,professionRetiredWeek:career.professionRetirements.at(-1)?.retiredWeek??null,industryRetiredWeek:career.industryRetiredWeek,lastProfessionChangeWeek:career.lastChange?.week??null,lifecycleStatus:lifecycle.status,lifecycleLine:lifecycle.line,retiredWeek:lifecycle.retiredWeek,talentId:t.id,name:t.name,roleLabel:t.role==='craft'?'Crew':t.role[0]!.toUpperCase()+t.role.slice(1),employerStudioId:owner,employerName:owner?names.get(owner)??null:null,
    employmentLabel:owner?`Studio: ${names.get(owner)}`:'No exclusive studio contract',creditCount:filmsByPerson.get(t.id)?.length??0,onPlayerLot:onLot.has(t.id),
    caseStatusLine:route.statusLine,caseRef:route.caseRef,
    notice:'Credits establish work on a film. They do not establish historical employment. Current employer is read from the present contract.'};people.set(t.id,person);if(owner)append(roster,owner,person)}
  const current=h.chart??{week:state.market.tick,rows:h.identities.filter(s=>s.enteredWeek!==null).map(s=>({studioId:s.studioId,standing:h.businesses.find(b=>b.studioId===s.studioId)?.standing??state.studio.standing,output:filmsByStudio.get(s.studioId)?.length??0}))},prior=h.previousChart
  const sameCohort=current!==null&&prior!==null&&current.rows.length===prior.rows.length&&current.rows.every(r=>prior.rows.some(p=>p.studioId===r.studioId))
  const rank=(snapshot:HollywoodChartSnapshot,key:typeof INDUSTRY_LANES[number],studioId:string)=>{
    const value=(r:HollywoodChartSnapshot['rows'][number])=>key==='output'?r.output:r.standing[key]
    const own=snapshot.rows.find(r=>r.studioId===studioId);if(!own)return null
    return 1+snapshot.rows.filter(r=>value(r)>value(own)).length
  }
  const studios:Studio[]=h.identities.filter(s=>s.enteredWeek!==null).map(s=>{
    const owned=filmsByStudio.get(s.studioId)??[],business=h.businesses.find(b=>b.studioId===s.studioId)
    const standing:Standing=business?.standing??state.studio.standing
    const chartRow=current?.rows.find(r=>r.studioId===s.studioId)
    const lanes=INDUSTRY_LANES.map(key=>{
      const currentRank=current?rank(current,key,s.studioId):null,previousRank=prior?rank(prior,key,s.studioId):null
      const comparable=sameCohort&&currentRank!==null&&previousRank!==null
      const movement=!prior?'unavailable':previousRank===null?'new':!comparable?'unavailable':currentRank!<previousRank?'up':currentRank!>previousRank?'down':'unchanged'
      return {key,label:laneLabels[key],meaning:meanings[key],value:key==='output'?(chartRow?.output??owned.length):(chartRow?.standing[key]??standing[key]),rank:currentRank??1,priorRank:comparable?previousRank:null,movement,
        movementLabel:movement==='new'?'New to this comparison':movement==='unavailable'?'No comparable prior cohort':movement==='unchanged'?'No rank change':`${movement==='up'?'Up':'Down'} ${Math.abs(currentRank!-previousRank!)} since ${campaignDate(prior!.week).label}`,
        snapshotWeek:current?.week??state.market.tick,snapshotLabel:`Comparison: ${campaignDate(current?.week??state.market.tick).label} · ${current.rows.length} studios`,priorWeek:comparable?prior!.week:null} satisfies Studio['lanes'][number]
    })
    return {studioId:s.studioId,name:s.name,mark:s.mark,color:s.color,player:s.role==='player',
      trustLabel:studioTrustDescriptor(state,s.studioId,state.market.tick).label,
      foundingLabel:s.role==='player'&&state.founding!==null?`Campaign began ${campaignDate(s.enteredWeek!).label} · Studio founding in progress`:s.founding===null?'Founding date not recorded':s.founding.kind==='beforeCampaign'?`Established ${s.founding.year}`:`Founded ${campaignDate(s.founding.week).label}`,
      entryLabel:`Present since ${campaignDate(s.enteredWeek!).label}`,conditionLabel:publicConditionLabel(state,s.studioId),recordingNotice:h.origin==='migration'?`Industry recording begins ${campaignDate(s.recordedFromWeek!).label}. Earlier rival films are not reconstructed.`:s.row>4?'Entered during this campaign; film records come from actual releases.':'Authored earlier films are labelled separately from this campaign’s simulated releases.',filmCount:owned.length,authoredFilmCount:owned.filter(f=>f.provenance==='authored-start/v1').length,liveFilmCount:owned.filter(f=>f.provenance!=='authored-start/v1').length,lanes}
  })
  const filmById=new Map(films.map(f=>[f.filmId,f]))
  const activities:Activity[]=h.receipts.flatMap((r):Activity[]=>{
    const studio=names.get(r.studioId)!,base={eventId:r.eventId,week:r.week,dateLabel:campaignDate(r.week).label,studioId:r.studioId}
    if(r.kind==='studioEntered')return [{...base,group:'studios' as const,headline:`${studio} joins Hollywood`,detail:r.origin==='fresh'?'Starting incumbent. Earlier authored film records are already settled.':'A new recorded company begins with finite starting resources and no backfilled filmography.',filmId:null,talentId:null}]
    if(r.kind==='employment')return r.reason==='renewal'||r.reason==='entry'||r.reason==='existing-player-contract'?[]:[{...base,group:'people' as const,headline:`${people.get(r.talentId)?.name??r.talentId}: ${r.toStudioId?'joined '+names.get(r.toStudioId):'contract ended'}`,detail:'Recorded employment transition. Contract terms remain private.',filmId:null,talentId:r.talentId}]
    if(r.kind==='filmReleased')return [{...base,group:'releases' as const,headline:`${studio} releases ${filmById.get(r.productionId)?.title??r.productionId}`,detail:`Released through recorded development, production, post-production and release commitments. Release Standing: ${(['audienceAwareness','industryPrestige','commercialConfidence'] as const).map(key=>`${laneLabels[key]} ${r.before[key].toFixed(1)} → ${r.after[key].toFixed(1)}`).join('; ')}. These are separate recorded changes at release, before later drift.`,filmId:r.productionId,talentId:null}]
    if(r.kind==='filmSettled')return [{...base,group:'releases' as const,headline:`${filmById.get(r.productionId)?.title??r.productionId} completes its theatrical run`,detail:'The final scheduled payment was received. The settled public result is now complete.',filmId:r.productionId,talentId:null}]
    if(r.kind==='filmAnnounced')return [{...base,group:'announcements' as const,headline:`${studio} announces a film`,detail:'An actual funded production has been greenlit. No release date is promised.',filmId:r.productionId,talentId:null}]
    // P13B-S8: the ONE public rival research fact. A rival Laboratory becoming operational
    // is observable plant; its seats, instruments, projects and spend are not. So
    // `laboratoryCommitted`, `instrumentOperational`, `researchSeatAssigned` and
    // `researchCompleted` fall through to the empty return below and publish nothing at
    // all, and no count reaches this text — "how much capacity" is exactly the private
    // fact. Rival finance stays behind the public standings; no money kind is read here.
    if(r.kind==='laboratoryOperational')return [{...base,group:'studios' as const,headline:`${studio} expands its research capacity`,
      detail:'A recorded research Laboratory is now operational. Its seats, instruments, research projects and spending remain private.',filmId:null,talentId:null}]
    if(r.kind==='technologyAdopted') {
      const adoption=observedAdoption(state,r);if(!adoption)return []
      return [{...base,group:'studios',headline:`${studio} now has operational synchronized sound`,
        detail:adoption.route==='purchase'?'Synchronized sound became operational through the commercial purchase route on existing studio capacity. This records an actual adoption; future productions are not promised.':'Synchronized sound became operational following completed research and physical installation. This records an actual adoption; future productions are not promised.',filmId:null,talentId:null}]
    }
    return []
  })
  // P14B.2: one PUBLIC activity per exact outcome receipt. Terms remain private;
  // neither reason prose nor a coincident person/week is an outcome identity.
  // P14B.7, A DECISION AND NOT AN OVERSIGHT: WAIVED is EXCLUDED here, so the
  // invariant above reads "per SATISFIED or BROKEN outcome receipt". The fold
  // publishes no terms — it publishes an OUTCOME, and these rows carry no studio
  // filter, so a rival's kept/broken promises are already public by name. Owner,
  // 2026-09-23: a waiver is a settlement the person ACCEPTED, so there is no
  // breach to announce; the issuer gets a private confirmation instead
  // (`promiseHistoryFor`, viewer-scoped, and the waived attention row in
  // bridge/trust.ts). The existing kept/broken announcements are untouched.
  // DO NOT "fix" this filter by admitting WAIVED: `outcomeKind` is closed to
  // promiseKept/promiseBroken (schema/industry-schema.ts:147), so announcing a
  // waiver widens a closed enum and is a projection step (49 -> 50), not a line
  // change. The cost was priced and the Owner chose silence.
  const outcomes=new Map(state.promises
    .filter(p=>p.outcomeEventId!==null&&(p.outcome==='SATISFIED'||p.outcome==='BROKEN'))
    .map(p=>[p.outcomeEventId,p]))
  for(const receipt of state.talentMarket.receipts) {
    if(receipt.kind!=='promiseOutcome')continue
    const promise=outcomes.get(receipt.eventId)
    if(!promise)continue
    const kept=promise.outcome==='SATISFIED'
    activities.push({eventId:receipt.eventId,week:receipt.week,dateLabel:campaignDate(receipt.week).label,
      group:'people',studioId:promise.issuerStudioId,filmId:null,talentId:promise.beneficiaryPersonId,
      outcomeKind:kept?'promiseKept':'promiseBroken',
      headline:`${names.get(promise.issuerStudioId)??promise.issuerStudioId} ${kept?'kept':'broke'} its promise to ${people.get(promise.beneficiaryPersonId)?.name??promise.beneficiaryPersonId}`,
      detail:receipt.reasons.join(' ')})
  }
  // Career events are public facts with no employer; they retain only 13 weeks.
  for(const event of recentCareerEvents(state)) activities.push({
    eventId:event.eventId,week:event.week,dateLabel:campaignDate(event.week).label,
    group:'people',studioId:null,filmId:null,talentId:event.talentId,careerKind:event.kind,
    headline:event.kind==='professionChanged'?`${event.talentName} becomes a ${event.profession}`:`${event.talentName} retires from the industry`,
    detail:event.line,
  })
  // P13B-S7: the public technology announcements. A DERIVED CLOCK FACT — the catalogue's
  // milestone data plus this campaign's week, nothing else: no receipt is minted, read or
  // needed, so a Save As copy, a reloaded save and two campaigns differing only in rival
  // facts publish the identical row for the same week. `studioId` is null because the
  // campaign clock owns no studio, which is also what keeps the row out of every per-studio
  // History filter below — null never matches a studio id.
  for(const announcement of technologyAnnouncements(state.market.tick)) {
    const entry=technologyEntry(announcement.technologyId)
    activities.push({eventId:`technology-announcement-${entry.id}`,week:announcement.week,dateLabel:campaignDate(announcement.week).label,group:'announcements',
      headline:`Industry announces ${entry.name}`,
      detail:`Commercial access opens ${campaignDate(entry.commercialWeek).label}. Public milestone facts from the catalogue; not a rival schedule.`,
      studioId:null,filmId:null,talentId:null})
  }
  const index={studios,studioById:new Map(studios.map(s=>[s.studioId,s])),films,filmById:new Map(films.map(f=>[f.filmId,f])),credits,filmsByStudio,filmsByPerson,people,roster,activities}
  indexes.set(state,index);return index
}
// ── P14A.2: the Pulse fold — ONE row per talent-market settlement ───────────
// Companion §2.1.8 and the disclosure row at line 92: after settlement, WHO the person
// joined and on WHAT TERM LENGTH is public; the compensation stays private. A settlement
// writes two P12 employment receipts — the subject's `expiry` and the winner's start —
// which the Pulse has published as two separate rows. They are ONE public event, so they
// fold into one `retained` (same employer) or `moved` (a new one) row.
//
// The join is (talentId, settlement week, receipt kind) and it is EXACT, not a
// coincidence: a person holds one contract at a time, so at most one expiry and one
// start receipt exist for that person in that week. The companion's prose says the
// `settled` receipt references the two by `eventId`; the landed receipt carries no such
// field, and persisting one would be a new save fact (a V29 candidate) that no consumer
// needs while this join is exact — recorded OPEN, deliberately not added here.
//
// Declined, expired and invalidated cases keep the existing rows: nobody signed, and the
// person leaves for the free-agent pool exactly as today. The per-person Employment route
// is untouched — it publishes the authoritative receipts themselves, unfolded.
type EmploymentReceipt=Extract<IndustryReceipt,{kind:'employment'}>
function pulseSettlementFold(state:GameState,people:Map<string,Person>):{drop:Set<string>;replace:Map<string,Activity>} {
  const drop=new Set<string>(),replace=new Map<string,Activity>()
  const h=state.hollywood
  if(!h)return {drop,replace}
  const names=new Map(h.identities.map(s=>[s.studioId,s.name]))
  const receipt=(talentId:string,week:number,reasons:readonly EmploymentReceipt['reason'][]):EmploymentReceipt|undefined=>
    h.receipts.find((r):r is EmploymentReceipt=>r.kind==='employment'&&r.talentId===talentId&&r.week===week&&reasons.includes(r.reason))
  for(const settled of state.talentMarket.receipts) {
    if(settled.kind!=='settled')continue
    // P14C.2b (780 §5.3): a settled one final extension is no contract case; its two
    // P12 rows stay the ordinary employment transitions they are, unfolded.
    if(state.talentMarket.cases.some(c=>c.variant==='retirementExtension'&&c.talentId===settled.talentId&&c.outcome==='settled'&&c.closedWeek===settled.week))continue
    const expiry=receipt(settled.talentId,settled.week,['expiry'])
    const start=receipt(settled.talentId,settled.week,['replacement','player-contract'])
    if(!expiry||!start||start.toStudioId===null)continue
    const termWeeks=h.employment.find(e=>e.contractId===start.contractId)?.terms.termWeeks
    if(termWeeks===undefined)continue
    const name=people.get(settled.talentId)?.name??settled.talentId
    const joined=names.get(start.toStudioId)??start.toStudioId
    const retained=expiry.studioId===start.toStudioId
    drop.add(expiry.eventId)
    replace.set(start.eventId,{eventId:start.eventId,week:settled.week,dateLabel:campaignDate(settled.week).label,group:'people',
      studioId:start.toStudioId,filmId:null,talentId:settled.talentId,settlementKind:retained?'retained':'moved',
      headline:retained?`${name} re-signs with ${joined}`:`${name} moves to ${joined}`,
      detail:`Settled contract case: ${contractTermLabel(termWeeks)}. Compensation remains private.`})
  }
  return {drop,replace}
}
const chronology=(f:Film)=>(f.releaseWeek??((f.historicalYear??1919)-1920)*52)
function filterFilms(rows:Film[],q:IndustryQuery,week:number):Film[] {
  return rows.filter(f=>q.period==='authored'?f.provenance==='authored-start/v1':q.period==='live'?f.provenance!=='authored-start/v1':q.period==='recent'?f.releaseWeek!==null&&f.releaseWeek>=Math.max(0,week-51):true)
    .sort((a,b)=>{const value=(f:Film)=>q.lane==='critics'?f.criticScore:q.lane==='audience'?f.audienceScore:q.lane==='opening'?f.openingGross:q.lane==='total'?f.totalGross:chronology(f);return value(b)-value(a)||byText(a.filmId,b.filmId)})
}
/** Pure viewer comparison: archive identities/definition and the W-13 ranked cohort are authority. */
export function powerRankingMovement(current:PowerRankingRecord,prior:PowerRankingRecord|null,studioId:string):{priorRank:number|null;movement:'new'|'unavailable'|'up'|'down'|'unchanged'} {
  const own=current.rows.find(r=>r.studioId===studioId)
  const previous=prior?.rows.find(r=>r.studioId===studioId)
  const unavailable={priorRank:null,movement:'unavailable' as const}
  if(!own?.ranked||own.rank===null||prior===null||prior.week!==current.week-13||previous===undefined||prior.definitionVersion!==current.definitionVersion)return unavailable
  if(!previous.ranked||previous.rank===null)return {priorRank:null,movement:'new'}
  const nowIds=current.rows.filter(r=>r.ranked).map(r=>r.studioId).sort()
  const priorIds=prior.rows.filter(r=>r.ranked).map(r=>r.studioId).sort()
  if(nowIds.length!==priorIds.length||nowIds.some((id,i)=>id!==priorIds[i]))return unavailable
  return {priorRank:previous.rank,movement:own.rank<previous.rank?'up':own.rank>previous.rank?'down':'unchanged'}
}
const rankingUnavailable='Not enough comparable history for a Power Ranking.'
const rankingBanner='Power Ranking is recent comparative momentum. Studio Standing and Studio History are separate.'
const firstQuarter=(week:number)=>Math.ceil(week/13)*13
const bandLabels={inTheRed:'In the red',strained:'Strained',stable:'Stable',thriving:'Thriving'}
function quarterCondition(state:GameState,studioId:string,week:number):PowerRankingPage['rows'][number]['distressStage'] {
  const root=state.corporateCondition
  const record=root.studios.find(r=>r.studioId===studioId)
  if(week<=root.recordedFromWeek||record===undefined||week<record.firstEvaluatedWeek)return 'notRecorded'
  let stage:PowerRankingPage['rows'][number]['distressStage']='stable'
  for(const event of root.events)if(event.studioId===studioId&&event.week<=week)stage=event.to
  return stage
}
function rankingPage(state:GameState,index:Index,record:PowerRankingRecord):PowerRankingPage {
  const h=state.hollywood!
  const prior=state.powerRanking.snapshots.find(r=>r.week===record.week-13)??null
  const rankedCount=record.rows.filter(r=>r.ranked).length
  const rows=record.rows.map(row=>{
    const identity=h.identities.find(s=>s.studioId===row.studioId)!
    const comparison=powerRankingMovement(record,prior,row.studioId)
    const movementLabel=comparison.movement==='new'?'New to this comparison':comparison.movement==='unavailable'?'No comparable prior cohort':comparison.movement==='unchanged'?'No rank change':`${comparison.movement==='up'?'Up':'Down'} ${Math.abs(row.rank!-comparison.priorRank!)} since ${campaignDate(prior!.week).label}`
    const films=row.countedFilmIds.map(filmId=>{
      const film=index.filmById.get(filmId)
      if(film===undefined||film.studioId!==row.studioId)throw new Error('A counted Power Ranking release is missing from the retained film record.')
      // Finished counted releases retain their final public totals; do not disclose gross in the page.
      return {filmId,title:film.title,criticScore:film.criticScore,scoreTenths:filmScoreTenths(film,state.market.baseMarketValue)}
    })
    const pointsTenths=row.filmsTenths+row.releasesTenths
    return {studioId:row.studioId,name:identity.name,player:identity.role==='player',ranked:row.ranked,rank:row.rank,
      rankLabel:row.ranked?`#${row.rank} of ${rankedCount} ranked`:record.available?`Ranked from ${campaignDate(firstQuarter(Math.max(identity.enteredWeek!,h.originWeek)+52)).label}`:rankingUnavailable,
      ...comparison,movementLabel,filmsTenths:row.filmsTenths,films,filmsLine:films.length===0?'No finished release in the window.':null,
      releases:row.releases,releasesTenths:row.releasesTenths,pointsTenths,pointsLabel:`${(pointsTenths/10).toFixed(1)} of 20 · 2 of 3 lanes recorded (Honors not recorded)`,
      honors:'notRecorded' as const,band:row.band,bandLabel:bandLabels[row.band],distressStage:quarterCondition(state,row.studioId,record.week)}
  })
  return {snapshotId:record.id,priorSnapshotId:prior?.id??null,week:record.week,dateLabel:campaignDate(record.week).label,
    definitionVersion:record.definitionVersion,windowLabel:`${campaignDate(Math.max(0,record.windowStartWeek)).label} to ${campaignDate(record.week-1).label}`,
    available:record.available,availabilityLine:record.available?null:rankingUnavailable,
    firstRankedLabel:record.available?null:`First ranked quarter: ${campaignDate(firstQuarter(h.originWeek+52)).label}`,
    recordingNotice:state.powerRanking.recordedFromWeek>h.originWeek?`Power Ranking recording begins ${campaignDate(state.powerRanking.snapshots[0]!.week).label}. Earlier quarters are not reconstructed.`:null,
    rankedCount,cohortCount:record.rows.length,rows}
}

/** Query results own their output objects; the immutable per-state index never escapes. */
export function industryPage(state:GameState,sessionId:string,stateRevision:number,q:IndustryQuery,laboratoryIntents:readonly LaboratoryIntent[]=[],planIntents:readonly PlanIntent[]=[],officeIntents:readonly OfficeIntent[]=[]):IndustryPage {
  if(!Number.isInteger(q.page)||q.page<0||!Number.isInteger(q.pageSize)||q.pageSize<1||q.pageSize>50) {
    throw new Error('Industry pages require a non-negative integer page and a pageSize from 1 to 50.')
  }
  const index=indexFor(state),h=state.hollywood!,calendar=campaignDate(state.market.tick)
  const result:IndustryPage={protocolVersion:PROTOCOL_VERSION,schemaId:SCHEMA_ID,snapshotVersion:SNAPSHOT_VERSION,type:'industryPage',requestId:q.requestId,sessionId,stateRevision,stateDigest:snapshotBuildContextFor(state).stateDigest(),calendar,view:q.view,targetId:q.targetId,page:q.page,pageSize:q.pageSize,totalRows:0,pageCount:0,lane:q.lane,period:q.period,title:'Industry',notice:'Public facts only. Standing channels and film measures have separate meanings. The quarterly Power Ranking is a separate comparison.',studios:[],films:[],people:[],credits:[],activities:[],projects:[],tendencies:[],laboratory:null,plans:null,office:null,market:null,powerRanking:null}
  const page=<T>(rows:T[]):T[]=>{result.totalRows=rows.length;result.pageCount=Math.ceil(rows.length/q.pageSize);if(q.page>0&&q.page>=result.pageCount)throw new Error('That page is outside this snapshot. Return to the first page.');return rows.slice(q.page*q.pageSize,(q.page+1)*q.pageSize)}
  if(q.view==='powerRanking') {
    const records=state.powerRanking.snapshots
    const selected=q.targetId===null?records.at(-1):records.find(r=>q.targetId===`power-ranking-${r.week}`)
    if(selected===undefined&&q.targetId!==null)throw new Error('That Power Ranking quarter is not in this record.')
    result.title='Power Ranking'
    if(selected===undefined) {
      if(q.page!==0)throw new Error('That page is outside this snapshot. Return to the first page.')
      const first=firstQuarter(Math.max(h.originWeek,state.powerRanking.recordedFromWeek)+1)
      result.notice=`${rankingUnavailable} First recorded quarter: ${campaignDate(first).label}.`
    } else {
      result.notice=rankingBanner
      const selectedPage=rankingPage(state,index,selected)
      result.powerRanking={...selectedPage,rows:page(selectedPage.rows)}
    }
  } else if(q.view==='alumni') {
    if(q.targetId!==null)throw new Error('The alumni list requires a null targetId; open a person for detail.')
    result.title='Alumni'
    result.notice='People who completed a profession remain in the public record, including those working in a new profession. Recorded credits count roles on released films; honors are not recorded.'
    result.people=page([...index.people.values()].filter(person=>person.professionRetiredWeek!==null)
      .sort((a,b)=>b.professionRetiredWeek!-a.professionRetiredWeek!||byText(a.talentId,b.talentId)))
  } else if(q.view==='office') {
    // P13B-S4: one Development & Casting building's standard and its in-place
    // conversions. `officePage` resolves this studio's own bodies alone; a rival
    // facility id is absent from that set and refused above as INVALID_CONTROL.
    const office=officePage(state,q.targetId,officeIntents,q.page,q.pageSize)
    result.office=office.office;result.totalRows=office.totalRows;result.pageCount=office.pageCount
    result.title=office.office.title;result.notice='Your studio\u2019s Development & Casting building. A conversion raises this building\u2019s development standard in place and closes the building while the work runs; the standard increment is charged only once it reopens.'
  } else if(q.view==='market') {
    // P14A.2: the player's own Talent Market workspace. `marketPage` reads this studio's
    // lawful disclosure alone — a competing studio's tier, salary and bonus reach it only
    // as the engine's literal UNKNOWN marker, and a rival employment interval publishes no
    // compensation at all. `page` pages the CLOSED bucket, `historyPage` the selected
    // person's employer history; the response's own `pageSize` stays the request's.
    const market=marketPage(state,{view:'market',targetId:q.targetId,page:q.page,historyPage:q.historyPage??0})
    result.market=market;result.totalRows=market.cases.closed.total
    result.pageCount=Math.ceil(market.cases.closed.total/MARKET_CLOSED_PAGE_SIZE)
    result.title='Talent Market'
    result.notice='Open contract cases, the people free to sign now, and your own proposals. What a competing studio is paying is not public; that a proposal exists, for how long and from when, is.'
  } else if(q.view==='plans') {
    // P13B-S3: the studio's own ordered physical intentions. Player-safe by construction —
    // `plansPage` reads the player studio's plans alone; a rival's row never reaches here.
    const page=plansPage(state,planIntents,q.page,q.pageSize)
    result.plans=page.plans;result.totalRows=page.totalRows;result.pageCount=page.pageCount
    result.title=page.plans.title;result.notice=page.plans.notice
  } else if(q.view==='laboratory') {
    const laboratory=laboratoryPage(state,q.targetId,laboratoryIntents,q.page,q.pageSize)
    result.laboratory=laboratory.laboratory;result.totalRows=laboratory.totalRows;result.pageCount=laboratory.pageCount
    result.title=laboratory.laboratory.title;result.notice='Your studio’s Laboratory. Research, employment and physical installation remain separate commitments. Silent films remain lawful.'
  } else if(q.view==='studios') {
    const lane=INDUSTRY_LANES.find(k=>k===q.lane)??'audienceAwareness'
    const rows=structuredClone(index.studios)
    if(lane==='output'&&q.period==='recent') {
      const current=h.chart,prior=h.previousChart,at=current?.week??state.market.tick
      const count=(id:string,week:number)=>(index.filmsByStudio.get(id)??[]).filter(f=>f.releaseWeek!==null&&f.releaseWeek<week&&f.releaseWeek>=Math.max(0,week-52)).length
      const comparable=!!current&&!!prior&&current.rows.length===prior.rows.length&&current.rows.every(r=>prior.rows.some(p=>p.studioId===r.studioId))
      for(const studio of rows) {
        const l=studio.lanes.find(l=>l.key==='output')!,value=count(studio.studioId,at)
        l.label='Released Films · Last 52 weeks';l.meaning='Actual campaign releases in the 52 weeks ending at the comparison date; authored starting history is excluded.';l.value=value
        l.rank=1+rows.filter(s=>count(s.studioId,at)>value).length
        l.priorRank=comparable?1+prior!.rows.filter(r=>count(r.studioId,prior!.week)>count(studio.studioId,prior!.week)).length:null
        l.priorWeek=comparable?prior!.week:null
        l.movement=!prior?'unavailable':!prior.rows.some(r=>r.studioId===studio.studioId)?'new':l.priorRank===null?'unavailable':l.rank<l.priorRank?'up':l.rank>l.priorRank?'down':'unchanged'
        l.movementLabel=l.movement==='new'?'New to this comparison':l.priorRank===null?'No comparable prior cohort':l.movement==='unchanged'?'No rank change':`${l.movement==='up'?'Up':'Down'} ${Math.abs(l.rank-l.priorRank)} since ${campaignDate(prior!.week).label}`
      }
    }
    result.title='Studio Charts';result.studios=page(rows.sort((a,b)=>a.lanes.find(l=>l.key===lane)!.rank-b.lanes.find(l=>l.key===lane)!.rank||byText(a.studioId,b.studioId)))
  } else if(q.view==='films') {
    result.title='Movie Charts';result.films=page(filterFilms(index.films,q,state.market.tick))
  } else if(q.view==='studio'||q.view==='history'||q.view==='roster') {
    const studio=index.studioById.get(q.targetId??'');if(!studio)throw new Error('That studio is not present in this campaign.')
    result.title=q.view==='history'?`${studio.name} · History`:studio.name;result.studios=[studio];result.notice=studio.recordingNotice
    if(q.view==='roster') {
      result.title=`${studio.name} · Current roster`
      result.people=page(index.roster.get(studio.studioId)??[])
    }
    else if(q.view==='history') {
      result.films=(index.filmsByStudio.get(studio.studioId)??[]).filter(f=>f.provenance==='authored-start/v1')
      const records=studio.player?historyProjection(state).timeline.map((r):Activity=>({eventId:`player-history-${r.eventId}`,week:r.week,dateLabel:campaignDate(r.week).label,
        group:r.filmId?'releases':r.personId?'people':'studios',headline:r.headline,detail:r.detail,studioId:h.playerStudioId,filmId:r.filmId,talentId:r.personId})):index.activities.filter(r=>r.studioId===studio.studioId)
      result.activities=page(records.filter(r=>q.period!=='recent'||r.week>=Math.max(0,state.market.tick-12)).sort((a,b)=>b.week-a.week||byText(a.eventId,b.eventId)))
    }
    else {
      const all=index.filmsByStudio.get(studio.studioId)??[]
      result.films=page(filterFilms(all,q,state.market.tick));result.people=(index.roster.get(studio.studioId)??[]).slice(0,6)
      result.notice+=` Showing ${result.people.length} of ${index.roster.get(studio.studioId)?.length??0} current people; open the complete roster for every member.`
      const business=h.businesses.find(b=>b.studioId===studio.studioId)
      for(const p of business?.productions??[]){const cost=business!.projects.find(c=>c.productionId===p.id);if(cost?.announcedWeek===null||!cost)continue;const concept=h.concepts[cost.conceptOrdinal]!
        result.projects.push({productionId:p.id,studioId:studio.studioId,title:concept.title,genre:concept.genre,announcedWeek:cost.announcedWeek,dateLabel:campaignDate(cost.announcedWeek).label,stageLabel:'In production',notice:'Announced at actual greenlight. Scheduling and unrevealed development remain private.'})}
      const observed=all.filter(f=>f.provenance!=='authored-start/v1'&&f.releaseWeek!==null&&f.releaseWeek>=Math.max(0,state.market.tick-155))
      const genres=new Map<string,number>();for(const f of observed)genres.set(f.genre,(genres.get(f.genre)??0)+1)
      const leading=[...genres.entries()].sort((a,b)=>b[1]-a[1]||byText(a[0],b[0]))[0]
      result.tendencies=[{label:'Observed release genres',detail:observed.length<3?`${observed.length} recorded releases: too small a sample to describe a tendency.`:`${leading![1]} of ${observed.length} releases were ${leading![0]}. Other genres remain possible.`,sampleCount:observed.length,fromLabel:campaignDate(Math.max(studio.recordingNotice.includes('Earlier')?h.originWeek:0,state.market.tick-155)).label,throughLabel:calendar.label,basis:'Last 156 campaign weeks of released films. Authored starting films and unrevealed plans are excluded; this is observation, not a strategy forecast.'}]
      result.tendencies.push({label:'Observed release pace',detail:`${observed.length} recorded releases during this window. This is past output; future releases are not promised.`,sampleCount:observed.length,
        fromLabel:campaignDate(Math.max(h.originWeek,state.market.tick-155)).label,throughLabel:calendar.label,basis:'Actual released-film dates during the last 156 campaign weeks. No hidden production budgets or plans are inferred.'})
      const soundReceipts=h.receipts.filter(r=>r.studioId===studio.studioId&&r.week>=Math.max(0,state.market.tick-155)&&observedAdoption(state,r)!==null)
      if(soundReceipts.length) {
        const latest=soundReceipts[soundReceipts.length-1]!
        const adoption=observedAdoption(state,latest)!
        result.tendencies.push({label:'Observed sound adoption',detail:`Synchronized sound became operational ${campaignDate(latest.week).label} through ${adoption.route==='purchase'?'commercial purchase':'research and installation'}.`,sampleCount:soundReceipts.length,
          fromLabel:campaignDate(Math.max(h.originWeek,state.market.tick-155)).label,throughLabel:calendar.label,
          basis:'Completed adoption receipts from the last 156 campaign weeks. This is observed capability, not a strategy forecast or a promise about future films.'})
      }
    }
  } else if(q.view==='project') {
    const business=h.businesses.find(b=>b.projects.some(p=>p.productionId===q.targetId))
    const cost=business?.projects.find(p=>p.productionId===q.targetId)
    if(!business||!cost||cost.announcedWeek===null)throw new Error('No authoritative public announcement exists for that production.')
    const concept=h.concepts[cost.conceptOrdinal]!,production=business.productions.find(p=>p.id===q.targetId),film=index.filmById.get(q.targetId!)
    result.title=concept.title;result.studios=[index.studioById.get(business.studioId)!]
    result.projects=[{productionId:cost.productionId!,studioId:business.studioId,title:concept.title,genre:concept.genre,announcedWeek:cost.announcedWeek,dateLabel:campaignDate(cost.announcedWeek).label,
      stageLabel:film?'Released':'In production',notice:'Publicly announced production. Private schedules, costs and unannounced development are not disclosed.'}]
    if(film){result.films=[film];result.credits=page(index.credits.get(film.filmId)??[])}
    else result.credits=page(production?.participants?flattenParticipants(production.participants).map(c=>({talentId:c.talentId,name:c.name,role:c.role,
      employerStudioId:index.people.get(c.talentId)?.employerStudioId??null,employerName:index.people.get(c.talentId)?.employerName??null})):[])
  } else if(q.view==='employment') {
    const person=index.people.get(q.targetId??'');if(!person)throw new Error('That person is absent from this campaign.')
    result.title=`${person.name} · Recorded employment`;result.people=[person]
    result.notice=`Employment recording begins ${campaignDate(h.originWeek).label}. Film credits do not establish an employer. Existing migration contracts are observations, not newly signed contracts.`
    result.activities=page(h.receipts.flatMap((r):Activity[]=>r.kind==='employment'&&r.talentId===person.talentId?[{eventId:r.eventId,week:r.week,dateLabel:campaignDate(r.week).label,group:'people',studioId:r.studioId,filmId:null,talentId:r.talentId,
      headline:`${index.studioById.get(r.studioId)!.name} · ${r.reason==='existing-player-contract'?'Existing contract observed':r.toStudioId===null?'Contract ended':r.reason==='renewal'?'Contract renewed':'Contract began'}`,
      detail:'Actual recorded employment authority. Contract terms are kept private in Industry.'}]:[]).reverse())
  } else if(q.view==='film') {
    const film=index.filmById.get(q.targetId??'');if(!film)throw new Error('That film has no released result yet. Open its studio for the public announcement.')
    result.title=film.title;result.films=[film];result.credits=page(index.credits.get(film.filmId)??[]);result.notice=film.businessNotice
  } else if(q.view==='person') {
    const person=index.people.get(q.targetId??'');if(!person)throw new Error('That person is absent from this campaign.')
    result.title=person.name;result.people=[person];result.films=page(filterFilms(index.filmsByPerson.get(person.talentId)??[],q,state.market.tick));result.notice=person.notice
  } else {
    result.title='Industry Pulse';result.notice='Grouped material activity for the last 13 campaign weeks, and every public technology milestone already announced. Routine phase changes and ordinary renewals are omitted.'
    const groupOrder={releases:0,people:1,studios:2,announcements:3}
    // Only technology announcements are permanent. Null-studio career events
    // retain the same nonfuture 13-week window as ordinary recent news.
    // P14A.2: each settlement's two P12 rows fold into the ONE public row above.
    const fold=pulseSettlementFold(state,index.people)
    const rows=index.activities.flatMap(r=>fold.drop.has(r.eventId)?[]:[fold.replace.get(r.eventId)??r])
    result.activities=page(rows.filter(r=>(r.studioId===null&&r.group==='announcements'&&r.eventId.startsWith('technology-announcement-'))||(r.week<=state.market.tick&&state.market.tick-r.week<13)).sort((a,b)=>groupOrder[a.group]-groupOrder[b.group]||b.week-a.week||byText(a.eventId,b.eventId)))
  }
  return structuredClone(result)
}
