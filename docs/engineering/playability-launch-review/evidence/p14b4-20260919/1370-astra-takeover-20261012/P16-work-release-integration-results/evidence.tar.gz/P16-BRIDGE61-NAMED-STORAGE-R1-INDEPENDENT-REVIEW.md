# Projection61 grouped named storage

KEEP sparse correction for successor generation, UNRUN. SOURCE78f4077b603489c8e91180a094d983aebfbf558cc533b54480254ae88e90a3c9/MANIFEST3a0f2dd1ce90d265171858bbc4cd8e4a5bc32c4f61e2316425454abd26f7e7e9; two file pre/post hashes verified.

Actual third canonical generation rejects StudioAbsorptionQuoteSnapshot.terms/anyOf/0 as anonymous object storage. analyzeStorage589 rejects all inline object storage, including named x-csharp-name objects behind nullable/array, independently of the earlier discriminated-union constraint. Prior bounded union reviews did not establish this storage condition; all three failures remain retained and fixtures unstarted.

Five unchanged object shapes become named definitions: AbsorptionQuoteTerms and its array ProductionVerdict; PaidReportRight, nullable-array Employment, and nullable Liabilities. Storage now references each exact named object and definitions register all five. Field/literal/nullability/array semantics and closed-object strictness unchanged; no emitter/parser workaround or manually generated output. Core quote/readback new61 nested object storage now consists of named references; primitive/enumeration arrays and nullable scalar members remain valid existing DSL storage. Previous four union-member named fixes remain intact. No additional inline object storage found in these added61 routes by source inspection; actual generation is still required for complete emitter qualification.

No future schema hash invented, historical bodies changed, or gate requirement waived. Parent successor keeps the same canonical two commands and declared four-output/non-output guards with fresh paths/packet/proof pins. No runtime or K/R/index writes performed.
