---
name: handoff
description: Write or resume from HANDOFF.md so Claude and Codex can take over each other's work cold. Use when the user says handoff, hand off, resume, switch to Codex/Claude, "pick up where it left off", when a HANDOFF TRIGGER usage warning appears, or before a session ends with work in flight.
---

# Handoff

HANDOFF.md at the repo root is the single source of truth for who is working, on what, from which commit. Claude and Codex both read and write it. Chat summaries and zip packets do not replace it.

## Mode 1: write (handoff)

Run at every checkpoint commit, when a HANDOFF TRIGGER appears, when the user signals a stop (shutdown, outage, leaving), and before you expect the session to end.

1. Reach a safe point. Let running tests finish, or record them as running with PID and log path.
2. Rewrite every section of the template below from what you verified this session. Replace stale text; don't append a diary.
3. Leave the `AUTO` block alone. `handoff_guard.py` stamps it on session end and compaction.
4. Commit HANDOFF.md with the work in progress and push it, unless the repo's rules or an active recorded run forbid commits. If a commit is forbidden, save the file and say so in "Blockers".
5. Tell the user in one line: handoff written, commit SHA, next step.

## Mode 2: read (resume)

1. `git fetch`, then read HANDOFF.md, the repo's AGENTS.md/CLAUDE.md, and whatever files HANDOFF.md names as required reading.
2. Verify before acting: branch and HEAD match "Where the work is"; the remote has no newer commits (if it does, keep them and report); every listed running job is still alive or finished (check the logs).
3. Report any mismatch in one short block, then continue from "Next step". Do not restart planning or reopen anything under "Closed".
4. Set "Last writer" to yourself at your first checkpoint.

## Template

```markdown
# HANDOFF

Last writer: <Claude | Codex> (<model>), <date from `date`>

## Where the work is
- Repo / branch / HEAD: <branch> @ <full sha>, pushed: <yes | no, why>
- Required reading, in order: <files>

## Active order
- Governing Owner order: <name + file or record id>
- In scope: <bounded list>
- Closed, do not reopen: <list>

## State
- Done this session: <verified results with evidence: test counts, commits>
- In flight: <running jobs: PID, command, log path, expected finish>
- Claims limits: <what is measured versus reasoned but unmeasured>

## Next step
<exact next action, specific enough to execute without asking>

## Open decisions for the Owner
- <question>: recommend <X> because <reason>

## Blockers and warnings
- <anything that will bite the next agent>

## Auto snapshot
<!-- AUTO:BEGIN (handoff_guard.py rewrites this block) -->
<!-- AUTO:END -->
```
