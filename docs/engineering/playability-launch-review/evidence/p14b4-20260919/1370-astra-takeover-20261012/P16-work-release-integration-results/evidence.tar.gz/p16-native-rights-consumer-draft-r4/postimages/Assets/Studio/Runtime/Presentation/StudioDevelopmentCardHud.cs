using System;
using Studio.Runtime.Data;
using Studio.Runtime.Infrastructure;
using UnityEngine;

namespace ProjectStudio.UnitySpike.Presentation
{
    /// <summary>
    /// P03A: which Development surface is open. Derived from live selection and
    /// the authoritative board every access — never a stored single truth.
    /// </summary>
    public enum StudioDevelopmentCardLayer
    {
        None,
        /// <summary>The compact department inspector (annex C).</summary>
        Department,
        /// <summary>The retained commission workspace (annex D).</summary>
        Commission,
        /// <summary>The retained review workspace (annex E).</summary>
        Review,
    }

    /// <summary>
    /// The pure Development-card laws: sizes, tiers, and layer geometry. The
    /// commit-arm clock and the card-rect law are shared with the founding card
    /// so one 0.7-second constant and one geometry rule govern every commit
    /// surface on the lot.
    /// </summary>
    public static class StudioDevelopmentCardContracts
    {
        public const float DepartmentLargeHeight = 560f;
        public const float DepartmentStandardHeight = 520f;
        public const float DepartmentCompactHeight = 490f;

        /// <summary>
        /// Both retained workspaces render at full height or not at all — the
        /// founding fail-closed clamp law. The tall form NEVER exceeds the
        /// founding admin-confirm sheet, so the living-time chip's derived
        /// minimum height stays valid; the compact form fills the narrow proof
        /// floor's whole available band (18f top floor to the receipt gap).
        /// </summary>
        public const float WorkspaceHeight = 620f;
        public const float WorkspaceCompactHeight = 600f;

        /// <summary>
        /// P03A hostile-review remedy (blocker 1): at tall viewports the review
        /// sheet grows INTO the band between the top floor and the receipt —
        /// clamped to this cap — instead of rendering tall typography and extra
        /// rows into the standard 620f box, which clipped the rewrite's
        /// opportunity cost and the Back control at 1720x1045. The poster
        /// typography itself is earned by the RESOLVED sheet height (see
        /// TallContentMinimumHeight), never by screen height alone, so a screen
        /// just over the tall threshold keeps standard content in a roomier
        /// sheet rather than overflowing.
        /// </summary>
        public const float WorkspaceTallCap = 780f;
        public const float WorkspaceStandardCap = 660f;
        public const float TallContentMinimumHeight = 760f;

        public static float WorkspaceHeightFor(float screenHeight) =>
            screenHeight >= 860f ? WorkspaceHeight : WorkspaceCompactHeight;

        public static float WorkspaceHeightFor(float screenHeight, float availableBand) =>
            screenHeight >= 860f && availableBand > WorkspaceHeight
                ? Mathf.Min(availableBand, screenHeight >= 1000f ? WorkspaceTallCap : WorkspaceStandardCap)
                : WorkspaceHeightFor(screenHeight);

        public static float DepartmentHeightFor(float screenHeight) =>
            screenHeight >= 1000f ? DepartmentLargeHeight
            : screenHeight >= 860f ? DepartmentStandardHeight
            : DepartmentCompactHeight;

        public static float LayerHeight(StudioDevelopmentCardLayer layer, float screenHeight)
        {
            switch (layer)
            {
                case StudioDevelopmentCardLayer.Department: return DepartmentHeightFor(screenHeight);
                case StudioDevelopmentCardLayer.Commission: return WorkspaceHeightFor(screenHeight);
                case StudioDevelopmentCardLayer.Review: return WorkspaceHeightFor(screenHeight);
                default: return 0f;
            }
        }

        /// <summary>
        /// The retained workspaces hang from the TOP floor (below the chip
        /// band), while the department inspector stacks above the selection
        /// receipt like every compact card. Construction, not convention: the
        /// department's bottom action band — where the reveal was pressed —
        /// and a workspace's commit zone can then never share pixels at any
        /// supported viewport. Fail-closed: a workspace that cannot fit whole
        /// between the top floor and the receipt renders nothing.
        /// </summary>
        public static Rect WorkspaceRect(
            Rect receiptRect,
            float height,
            float minimumWidth,
            float topFloor,
            float leftFloor)
        {
            if (receiptRect == Rect.zero) return Rect.zero;
            if (topFloor + height > receiptRect.yMin - StudioFoundingCardContracts.CardGap)
                return Rect.zero;
            var width = Mathf.Max(receiptRect.width, minimumWidth);
            var left = Mathf.Max(leftFloor, receiptRect.xMax - width);
            width = Mathf.Min(width, receiptRect.xMax - left);
            return new Rect(left, topFloor, width, height);
        }

        public static float LayerMinimumWidth(StudioDevelopmentCardLayer layer, float screenWidth)
        {
            switch (layer)
            {
                case StudioDevelopmentCardLayer.Department:
                    return Mathf.Clamp(screenWidth * 0.40f, 520f, 680f);
                case StudioDevelopmentCardLayer.Commission:
                    return Mathf.Clamp(screenWidth * 0.56f, 660f, 980f);
                case StudioDevelopmentCardLayer.Review:
                    return Mathf.Clamp(screenWidth * 0.60f, 720f, 980f);
                default: return 0f;
            }
        }

        /// <summary>The two workspaces are commit surfaces: full height or nothing.</summary>
        public static bool LayerAllowsHeightClamp(StudioDevelopmentCardLayer layer) =>
            layer == StudioDevelopmentCardLayer.Department;

        /// <summary>
        /// P04A.1 (Owner failure remedy B1/B2/B4): the journey authority's own
        /// statement that Development work for THIS screenplay is complete and
        /// the next owner is Casting. Never inferred from status text or from
        /// board.castingBoundaryLine's prose — joined by the journey's own
        /// scriptProjectId, exactly the wire identity the authority uses, so a
        /// differently-commissioned project sharing the board can never borrow
        /// this project's readiness. site == "casting" IS the authority's own
        /// statement that the next owner is Casting; the client invents nothing.
        /// </summary>
        public static bool ReadyForCasting(
            StudioDevelopmentProjectSnapshot project,
            StudioFirstFilmJourneySnapshot journey)
        {
            var next = journey?.next;
            return project != null && next != null &&
                string.Equals(next.site, StudioJourneyNextSnapshotSiteValues.Casting, StringComparison.Ordinal) &&
                !string.IsNullOrWhiteSpace(journey.scriptProjectId) &&
                string.Equals(journey.scriptProjectId, project.projectId, StringComparison.Ordinal);
        }
    }

    /// <summary>
    /// The Development card — the department's compact inspector and its two
    /// retained-lot workspaces (commission and review), all screen-space over a
    /// live, unmoved camera. Every fact and every player-facing sentence comes
    /// from the authoritative board or a quote the TypeScript authority minted;
    /// the card composes layout, never copy, never legality. Commits dispatch
    /// only opaque authority-issued intentIds through the single-flight client,
    /// behind the shared 0.7-second arm and the geometric commit-placement law.
    /// </summary>
    public sealed class StudioDevelopmentCardHud : MonoBehaviour
    {
        private StudioBridgeClient client;
        private StudioBridgeClient subscribedClient;
        private StudioSelectionManager selection;
        private StudioHud studioHud;

        private StudioDevelopmentCardLayer stage = StudioDevelopmentCardLayer.Department;
        private string lastSelectedStableId;
        private float layerChangedAtRealtime = float.NegativeInfinity;
        private string cardFeedback;
        private string receiptLine;

        // ── Commission draft state (presentation-only; discarded on Back) ────
        private bool draftOriginal;
        private int conceptIndex;
        private int writerIndex;
        private int genreIndex;
        private int openingIndex = 1;   // Slow Setup — the browser form's default
        private int midpointIndex;      // Reversal
        private int endingIndex = 1;    // Bittersweet
        private bool[] segmentSelected = Array.Empty<bool>();
        private readonly int[] centerIndex = { 1, 1, 1 };

        // ── Quote state ──────────────────────────────────────────────────────
        private bool quoteDirty = true;
        private string quoteCommandId;
        private StudioBridgeQuoteResponse pendingQuote;
        private string quoteNotice;

        // ── Commit state ─────────────────────────────────────────────────────
        private string pendingCommandId;
        private string pendingCommitKind;

        // ── Proof instruments (Repaint-honest; reset at OnGUI entry) ─────────
        public Rect LastCommissionCommitScreenRect { get; private set; }
        public Rect LastAcceptCommitScreenRect { get; private set; }
        public Rect LastRewriteCommitScreenRect { get; private set; }
        public Rect LastCommissionOpenScreenRect { get; private set; }
        public Rect LastReviewOpenScreenRect { get; private set; }

        /// <summary>
        /// Hostile-review blocker 1 instruments: the LAST element of the rewrite
        /// column (its supporting cost / projection tail — the opportunity cost
        /// the package forbids hiding) and the review's Back control, both as
        /// live screen rects. The proof asserts each sits whole inside the card;
        /// a sheet that overflows can no longer report itself readable on the
        /// strength of its commit buttons alone.
        /// </summary>
        public Rect LastReviewTailScreenRect { get; private set; }
        public Rect LastReviewBackScreenRect { get; private set; }

        /// <summary>P03A.1: the explicit Locate-writer control's live rect.</summary>
        public Rect LastLocateWriterScreenRect { get; private set; }

        /// <summary>P04A.1 B4: the explicit GO TO CASTING control's live rect.</summary>
        public Rect LastGoToCastingScreenRect { get; private set; }
        public string LastRefusalReason { get; private set; } = "none";
        public string CardFeedback => cardFeedback;
        public string ReceiptLine => receiptLine;
        public string PendingQuoteCommitLabel => pendingQuote?.quote?.commitLabel;

        private Rect currentAreaRect;
        private Texture2D surfaceTexture;
        private GUIStyle surfaceStyle;
        private GUIStyle eyebrowStyle;
        private GUIStyle titleStyle;
        private GUIStyle bodyStyle;
        private GUIStyle mutedStyle;
        private GUIStyle strengthStyle;
        private GUIStyle forecastStyle;
        private GUIStyle concernStyle;
        private GUIStyle bigNumberStyle;
        private GUIStyle sectionStyle;
        private GUIStyle statLabelStyle;
        private GUIStyle statValueStyle;
        private GUIStyle figureStyle;
        private GUIStyle buttonStyle;
        private GUIStyle commitButtonStyle;
        private float stylesScale;

        public void Configure(StudioBridgeClient bridgeClient)
        {
            client = bridgeClient;
            EnsureSubscriptions();
        }

        public bool CommitArmed =>
            StudioFoundingCardContracts.CommitArmed(layerChangedAtRealtime, Time.realtimeSinceStartup);

        /// <summary>
        /// Selection owns the card: only the Development office opens it, and
        /// only while the authority publishes a board. The founding lane keeps
        /// sole ownership of the pre-founding world.
        /// </summary>
        public StudioDevelopmentCardLayer Layer
        {
            get
            {
                EnsureSceneReferences();
                var selected = selection == null ? null : selection.Selected;
                if (selected == null) return StudioDevelopmentCardLayer.None;
                if (selected.StableId != StudioDevelopmentContracts.BuildingStableId)
                    return StudioDevelopmentCardLayer.None;
                return Board() == null ? StudioDevelopmentCardLayer.None : stage;
            }
        }

        private StudioDevelopmentBoardSnapshot Board() =>
            client?.Current?.snapshot?.development?.development?.board;

        // ── Layer transitions (public seams: the GUI and the proof call these) ─

        public bool OpenCommission()
        {
            if (Layer != StudioDevelopmentCardLayer.Department) { LastRefusalReason = $"layer:{Layer}"; return false; }
            var board = Board();
            if (board == null) { LastRefusalReason = "no-board"; return false; }
            if (!board.commission.canSubmitMarketIntent && !board.commission.canSubmitOriginalIntent)
            {
                LastRefusalReason = "commission-closed";
                return false;
            }
            ResetDraft(board);
            stage = StudioDevelopmentCardLayer.Commission;
            receiptLine = null;
            cardFeedback = null;
            MarkLayerChanged();
            LastRefusalReason = "none";
            return true;
        }

        public bool OpenReview()
        {
            if (Layer != StudioDevelopmentCardLayer.Department) { LastRefusalReason = $"layer:{Layer}"; return false; }
            if (Board()?.review == null) { LastRefusalReason = "no-review"; return false; }
            stage = StudioDevelopmentCardLayer.Review;
            receiptLine = null;
            cardFeedback = null;
            MarkLayerChanged();
            LastRefusalReason = "none";
            return true;
        }

        public bool BackToDepartment()
        {
            if (stage == StudioDevelopmentCardLayer.Department) return false;
            stage = StudioDevelopmentCardLayer.Department;
            ClearQuote();
            cardFeedback = null;
            MarkLayerChanged();
            return true;
        }

        // ── Draft mutation seams (each invalidates the standing quote) ───────

        public void ToggleSource()
        {
            var board = Board();
            if (board == null) return;
            if (!draftOriginal && !board.commission.canSubmitOriginalIntent) return;
            if (draftOriginal && board.commission.concepts.Length == 0) return;
            draftOriginal = !draftOriginal;
            DraftChanged();
        }

        public void CycleConcept(int step) { conceptIndex = Cycle(conceptIndex, step, Board()?.commission.concepts.Length ?? 0); DraftChanged(); }
        public void CycleWriter(int step) { writerIndex = Cycle(writerIndex, step, Board()?.commission.writers.Length ?? 0); DraftChanged(); }
        public void CycleGenre(int step) { genreIndex = Cycle(genreIndex, step, Board()?.commission.catalog.genres.Length ?? 0); DraftChanged(); }
        public void CycleOpening(int step) { openingIndex = Cycle(openingIndex, step, Board()?.commission.catalog.openings.Length ?? 0); DraftChanged(); }
        public void CycleMidpoint(int step) { midpointIndex = Cycle(midpointIndex, step, Board()?.commission.catalog.midpoints.Length ?? 0); DraftChanged(); }
        public void CycleEnding(int step) { endingIndex = Cycle(endingIndex, step, Board()?.commission.catalog.endings.Length ?? 0); DraftChanged(); }

        public void ToggleSegment(int index)
        {
            if (index < 0 || index >= segmentSelected.Length) return;
            segmentSelected[index] = !segmentSelected[index];
            var any = false;
            foreach (var picked in segmentSelected) any |= picked;
            if (!any) segmentSelected[index] = true; // at least one audience, always
            DraftChanged();
        }

        public void CyclePromise(int axis, int step)
        {
            if (axis < 0 || axis >= centerIndex.Length) return;
            centerIndex[axis] = Cycle(centerIndex[axis], step, 4);
            DraftChanged();
        }

        private static int Cycle(int value, int step, int count) =>
            count <= 0 ? 0 : ((value + step) % count + count) % count;

        private void DraftChanged()
        {
            pendingQuote = null;
            quoteCommandId = null;
            quoteDirty = true;
            quoteNotice = null;
        }

        private void ClearQuote()
        {
            pendingQuote = null;
            quoteCommandId = null;
            quoteDirty = true;
            quoteNotice = null;
        }

        private void ResetDraft(StudioDevelopmentBoardSnapshot board)
        {
            draftOriginal = board.commission.concepts.Length == 0 &&
                            board.commission.canSubmitOriginalIntent;
            conceptIndex = 0;
            genreIndex = 0;
            openingIndex = 1;
            midpointIndex = 0;
            endingIndex = 1;
            writerIndex = FirstAvailableWriter(board);
            var segments = board.commission.catalog.segments;
            segmentSelected = new bool[segments.Length];
            for (var index = 0; index < segments.Length; index++)
                segmentSelected[index] = segments[index]?.id == "adult";
            if (segmentSelected.Length > 0)
            {
                var any = false;
                foreach (var picked in segmentSelected) any |= picked;
                if (!any) segmentSelected[0] = true;
            }
            centerIndex[0] = 1;
            centerIndex[1] = 1;
            centerIndex[2] = 1;
            ClearQuote();
        }

        private static int FirstAvailableWriter(StudioDevelopmentBoardSnapshot board)
        {
            var writers = board.commission.writers;
            for (var index = 0; index < writers.Length; index++)
                if (writers[index] != null && writers[index].available) return index;
            return 0;
        }

        /// <summary>The exact draft the quote and the proof both read.</summary>
        public StudioCommissionDraftPayload CurrentDraft()
        {
            var board = Board();
            if (board == null) return null;
            var commission = board.commission;
            var catalog = commission.catalog;
            if (catalog.openings.Length == 0 || catalog.midpoints.Length == 0 ||
                catalog.endings.Length == 0 || catalog.segments.Length == 0)
                return null;
            if (commission.writers.Length == 0) return null;
            if (!draftOriginal && commission.concepts.Length == 0) return null;
            if (draftOriginal && catalog.genres.Length == 0) return null;
            var segmentCount = 0;
            foreach (var picked in segmentSelected) if (picked) segmentCount++;
            if (segmentCount == 0) return null;
            var segments = new string[segmentCount];
            var cursor = 0;
            for (var index = 0; index < segmentSelected.Length && index < catalog.segments.Length; index++)
                if (segmentSelected[index]) segments[cursor++] = catalog.segments[index].id;
            return new StudioCommissionDraftPayload
            {
                source = draftOriginal ? "original" : "market",
                conceptId = draftOriginal ? null : commission.concepts[Clamp(conceptIndex, commission.concepts.Length)].id,
                genre = draftOriginal ? catalog.genres[Clamp(genreIndex, catalog.genres.Length)].id : null,
                writerId = commission.writers[Clamp(writerIndex, commission.writers.Length)].id,
                opening = catalog.openings[Clamp(openingIndex, catalog.openings.Length)].id,
                midpoint = catalog.midpoints[Clamp(midpointIndex, catalog.midpoints.Length)].id,
                ending = catalog.endings[Clamp(endingIndex, catalog.endings.Length)].id,
                intendedSegments = segments,
                intimacyCenter = centerIndex[0],
                tonalWeightCenter = centerIndex[1],
                kineticEnergyCenter = centerIndex[2],
            };
        }

        private static int Clamp(int value, int count) =>
            count <= 0 ? 0 : Mathf.Clamp(value, 0, count - 1);

        // ── Commits ──────────────────────────────────────────────────────────

        /// <summary>
        /// Commits the quoted commission. Legal only from the commission layer,
        /// only armed, and only with a quote the authority minted for the
        /// CURRENT revision — the client echoes the opaque intentId and nothing
        /// else.
        /// </summary>
        public bool CommitCommission()
        {
            if (Layer != StudioDevelopmentCardLayer.Commission) { LastRefusalReason = $"layer:{Layer}"; return false; }
            if (!CommitArmed) { LastRefusalReason = "unarmed"; return false; }
            var quote = pendingQuote;
            if (quote == null) { LastRefusalReason = "no-quote"; return false; }
            if (client?.Current == null || quote.stateRevision != client.Current.stateRevision)
            {
                LastRefusalReason = "stale-quote";
                ClearQuote();
                return false;
            }
            return DispatchIntent(
                new StudioBridgeIntentOption
                {
                    intentId = quote.quote.intentId,
                    kind = StudioBridgeQuoteResponse.QuoteKind(quote.quote),
                    label = quote.quote.commitLabel,
                    detail = string.Empty,
                    projectId = null,
                    castingSessionId = null,
                    productionId = null,
                },
                "commission");
        }

        public bool CommitAccept()
        {
            if (Layer != StudioDevelopmentCardLayer.Review) { LastRefusalReason = $"layer:{Layer}"; return false; }
            if (!CommitArmed) { LastRefusalReason = "unarmed"; return false; }
            var review = Board()?.review;
            if (review == null) { LastRefusalReason = "no-review"; return false; }
            var option = FindReviewOption(StudioBridgeIntentOptionKindValues.AcceptScreenplay, review.projectId);
            if (option == null) { LastRefusalReason = "no-option"; return false; }
            return DispatchIntent(option, "accept");
        }

        public bool CommitRewrite()
        {
            if (Layer != StudioDevelopmentCardLayer.Review) { LastRefusalReason = $"layer:{Layer}"; return false; }
            if (!CommitArmed) { LastRefusalReason = "unarmed"; return false; }
            var review = Board()?.review;
            if (review == null) { LastRefusalReason = "no-review"; return false; }
            if (!review.rewrite.available) { LastRefusalReason = "rewrite-unavailable"; return false; }
            var option = FindReviewOption(StudioBridgeIntentOptionKindValues.RequestRewrite, review.projectId);
            if (option == null) { LastRefusalReason = "no-option"; return false; }
            return DispatchIntent(option, "rewrite");
        }

        private StudioBridgeIntentOption FindReviewOption(string kind, string projectId)
        {
            var options = client?.Current?.availableIntents;
            if (options == null) return null;
            foreach (var option in options)
            {
                if (option == null) continue;
                if (!string.Equals(option.kind, kind, StringComparison.Ordinal)) continue;
                if (option.projectId != null && option.projectId != projectId) continue;
                return option;
            }
            return null;
        }

        private bool DispatchIntent(StudioBridgeIntentOption option, string commitKind)
        {
            if (client == null || !client.ActionsEnabled)
            {
                LastRefusalReason = client == null
                    ? "no-client"
                    : $"actions-disabled:{client.ConnectionState}" +
                      $":inflight={client.RequestInFlight}:pending={client.PendingPost}";
                return false;
            }
            var commandId = Guid.NewGuid().ToString("N");
            if (!client.SubmitIntent(option, false, commandId))
            {
                LastRefusalReason = "post-refused";
                return false;
            }
            LastRefusalReason = "none";
            pendingCommandId = commandId;
            pendingCommitKind = commitKind;
            cardFeedback = null;
            return true;
        }

        // ── Authority confirmations ──────────────────────────────────────────

        private void OnCommandAccepted(StudioBridgeSnapshotResponse response)
        {
            if (response == null || pendingCommandId == null) return;
            var kind = pendingCommitKind;
            pendingCommandId = null;
            pendingCommitKind = null;
            // The accepted message is the authority's own receipt sentence; the
            // fresh board underneath the Department card carries the successor
            // facts (drafting row, rewriting row, or Ready + Casting boundary).
            receiptLine = null;
            if (kind == "commission" || kind == "accept" || kind == "rewrite")
            {
                var message = client?.LastAcceptedCommandMessage;
                receiptLine = string.IsNullOrWhiteSpace(message) ? null : message;
                stage = StudioDevelopmentCardLayer.Department;
                ClearQuote();
                MarkLayerChanged();
            }
        }

        private void OnCommandRejected(StudioBridgeRejectedResponse rejected)
        {
            if (rejected == null || pendingCommandId == null) return;
            if (rejected.commandId != pendingCommandId) return;
            pendingCommandId = null;
            pendingCommitKind = null;
            cardFeedback = rejected.rejection != null
                ? rejected.rejection.blocker + " " + rejected.rejection.remedy
                : "The studio could not complete that action.";
            ClearQuote();
        }

        private void OnQuoteAccepted(StudioBridgeQuoteResponse quoted)
        {
            if (quoted == null || quoted.commandId != quoteCommandId) return;
            if (client?.Current == null || quoted.stateRevision != client.Current.stateRevision)
            {
                quoteDirty = true;
                return;
            }
            pendingQuote = quoted;
            quoteNotice = null;
            // A fresh quote re-arms the commit: the button that appears (or
            // relabels) under the summary cannot swallow a stray click.
            MarkLayerChanged();
        }

        private void OnQuoteRejected(StudioBridgeRejectedResponse rejected)
        {
            if (rejected == null || rejected.commandId != quoteCommandId) return;
            quoteCommandId = null;
            pendingQuote = null;
            quoteNotice = rejected.rejection != null
                ? rejected.rejection.blocker + " " + rejected.rejection.remedy
                : rejected.message;
        }

        private void OnQuoteUnresolved(string message)
        {
            quoteCommandId = null;
            quoteDirty = true;
            quoteNotice = message;
        }

        // ── Frame loop ───────────────────────────────────────────────────────

        private void Update()
        {
            EnsureSceneReferences();
            EnsureSubscriptions();
            var selected = selection == null ? null : selection.Selected;
            var stableId = selected == null ? null : selected.StableId;
            if (stableId != lastSelectedStableId)
            {
                lastSelectedStableId = stableId;
                stage = StudioDevelopmentCardLayer.Department;
                cardFeedback = null;
                receiptLine = null;
                ClearQuote();
                MarkLayerChanged();
            }
            MaintainQuote();
        }

        private void MaintainQuote()
        {
            if (Layer != StudioDevelopmentCardLayer.Commission) return;
            var current = client?.Current;
            if (current == null) return;
            if (pendingQuote != null && pendingQuote.stateRevision != current.stateRevision)
            {
                pendingQuote = null;
                quoteDirty = true;
            }
            if (!quoteDirty || client.QuoteInFlight) return;
            var draft = CurrentDraft();
            if (draft == null) return;
            var commandId = client.RequestCommissionQuote(draft);
            if (commandId == null) return;
            quoteCommandId = commandId;
            quoteDirty = false;
        }

        private void MarkLayerChanged() => layerChangedAtRealtime = Time.realtimeSinceStartup;

        public bool ContainsScreenPoint(Vector2 screenPoint)
        {
            var rect = CurrentCardRect();
            if (rect == Rect.zero) return false;
            var guiPoint = new Vector2(screenPoint.x, Screen.height - screenPoint.y);
            return rect.Contains(guiPoint);
        }

        public Rect CurrentCardRect()
        {
            var layer = Layer;
            if (layer == StudioDevelopmentCardLayer.None) return Rect.zero;
            EnsureSceneReferences();
            if (studioHud == null) return Rect.zero;
            // P03A.3 scale seam: every pinned contract function below computes
            // in BASE space (identity at and below the reference viewport), so
            // the live receipt rect is un-scaled back to base before it feeds
            // them, base screen dimensions are derived for the *HeightFor/
            // *WidthFor laws, and only the FINAL assembled rect is scaled out
            // to the screen — the pinned laws themselves never learn the scale.
            var s = StudioLegacyUiMetrics.CurrentScale;
            var baseWidth = Screen.width / s;
            var baseHeight = Screen.height / s;
            var topFloor = StudioLivingTimeHud.ChipShownFor(Screen.width, Screen.height)
                ? StudioLivingTimeHud.ChipTop + StudioLivingTimeHud.ChipHeight + StudioFoundingCardContracts.CardGap
                : 18f;
            var leftFloor = client != null && client.WorkflowPanelVisible
                ? StudioHud.WorkflowPanelInset + StudioHud.WorkflowPanelMaximumWidth + StudioFoundingCardContracts.CardGap
                : 18f;
            var receipt = StudioLegacyUiMetrics.Unscale(studioHud.SelectionReceiptGuiRect, s);
            Rect baseRect;
            if (layer != StudioDevelopmentCardLayer.Department)
            {
                var availableBand = receipt == Rect.zero
                    ? 0f
                    : receipt.yMin - StudioFoundingCardContracts.CardGap - topFloor;
                baseRect = StudioDevelopmentCardContracts.WorkspaceRect(
                    receipt,
                    StudioDevelopmentCardContracts.WorkspaceHeightFor(baseHeight, availableBand),
                    StudioDevelopmentCardContracts.LayerMinimumWidth(layer, baseWidth),
                    topFloor,
                    leftFloor);
            }
            else
            {
                baseRect = StudioFoundingCardContracts.CardRect(
                    receipt,
                    StudioDevelopmentCardContracts.LayerHeight(layer, baseHeight),
                    StudioDevelopmentCardContracts.LayerMinimumWidth(layer, baseWidth),
                    StudioDevelopmentCardContracts.LayerAllowsHeightClamp(layer),
                    topFloor,
                    leftFloor);
            }
            return StudioLegacyUiMetrics.Scale(baseRect, s);
        }

        private void OnGUI()
        {
            if (Event.current.type == EventType.Repaint)
            {
                LastCommissionCommitScreenRect = Rect.zero;
                LastAcceptCommitScreenRect = Rect.zero;
                LastRewriteCommitScreenRect = Rect.zero;
                LastCommissionOpenScreenRect = Rect.zero;
                LastReviewOpenScreenRect = Rect.zero;
                LastReviewTailScreenRect = Rect.zero;
                LastReviewBackScreenRect = Rect.zero;
                LastLocateWriterScreenRect = Rect.zero;
                LastGoToCastingScreenRect = Rect.zero;
                // A card that is not drawing must not leave a stale rect the
                // owner-input proof could aim at.
                StudioUiElementRegistry.Withdraw("development-go-to-casting");
            }
            var layer = Layer;
            if (layer == StudioDevelopmentCardLayer.None) return;
            var rect = CurrentCardRect();
            if (rect == Rect.zero) return;
            EnsureStyles();
            currentAreaRect = rect;
            GUILayout.BeginArea(rect);
            GUILayout.BeginVertical(surfaceStyle, GUILayout.ExpandHeight(true));
            var board = Board();
            switch (layer)
            {
                case StudioDevelopmentCardLayer.Department: DrawDepartment(board); break;
                case StudioDevelopmentCardLayer.Commission: DrawCommission(board); break;
                case StudioDevelopmentCardLayer.Review: DrawReview(board); break;
            }
            if (!string.IsNullOrEmpty(cardFeedback)) GUILayout.Label(cardFeedback, concernStyle);
            GUILayout.EndVertical();
            GUILayout.EndArea();
        }

        // ── Department (annex C): what is this, what is happening, what next ─

        private void DrawDepartment(StudioDevelopmentBoardSnapshot board)
        {
            if (board == null) return;
            var s = StudioLegacyUiMetrics.CurrentScale;
            var journey = client?.Current?.snapshot?.journeyNotices?.firstFilmJourney;
            GUILayout.Label("IN THE LOT · DEVELOPMENT", eyebrowStyle);
            GUILayout.Label("Development", titleStyle);
            GUILayout.Label(board.worldStatus, bodyStyle);
            if (!string.IsNullOrEmpty(receiptLine))
            {
                GUILayout.Space(6f * s);
                GUILayout.Label(receiptLine, strengthStyle);
            }
            GUILayout.Space(8f * s);

            var priority = board.projects.Length > 0 ? board.projects[0] : null;
            var readyForCasting = StudioDevelopmentCardContracts.ReadyForCasting(priority, journey);
            if (priority != null && priority.section != "productionHistory")
            {
                // P03A.3 hierarchy (acceptance doc §7): the six uniform rows
                // once gave the project's name, phase, writer, and clock equal
                // visual weight. Same authoritative facts, now RANKED — the
                // screenplay leads, its phase-and-clock stand as one strong
                // supporting line, and the quieter facts read as quiet facts.
                // Nothing added, nothing removed.
                GUILayout.Label(priority.title, figureStyle);
                var stateLine = priority.statusLabel;
                if (priority.dueWeek != null)
                {
                    var weeks = priority.weeksUntilDecision;
                    stateLine += weeks == null
                        ? $" · decision Week {priority.dueWeek}"
                        : $" · decision Week {priority.dueWeek} ({(weeks == 1 ? "1 week" : $"{weeks} weeks")})";
                }
                GUILayout.Label(stateLine, sectionStyle);
                GUILayout.Label($"Writer · {priority.writerName}", statValueStyle);
                if (priority.facilityName != null && priority.slot != null)
                    GUILayout.Label($"{priority.facilityName} · Slot {priority.slot + 1}", statValueStyle);
                if (priority.assessment != null)
                    GUILayout.Label(
                        $"Assessment · {priority.assessment.label} {FormatScore(priority.assessment.score)} · {priority.assessment.band}",
                        statValueStyle);
            }
            else
            {
                GUILayout.Label("No screenplay is in development.", bodyStyle);
            }
            GUILayout.Label($"Capacity · {board.capacity.occupied} / {board.capacity.capacity} occupied", mutedStyle);

            if (board.attention.kind == "capacity-constraint")
            {
                GUILayout.Space(4f * s);
                GUILayout.Label(board.attention.headline, concernStyle);
                GUILayout.Label(board.attention.detail, mutedStyle);
            }
            else if (board.commission.blockers.Length > 0 &&
                     !board.commission.canSubmitMarketIntent &&
                     !board.commission.canSubmitOriginalIntent)
            {
                var blocker = board.commission.blockers[0];
                GUILayout.Space(4f * s);
                GUILayout.Label(blocker.headline, concernStyle);
                GUILayout.Label($"Remedy: {blocker.remedy}", mutedStyle);
            }
            if (readyForCasting)
            {
                // B1 (P04A.1 — Owner failure remedy): "It was not super clear I
                // needed to go to Casting because the film was done." The
                // authority's own castingBoundaryLine prose below is kept
                // verbatim, but it is no longer the ONLY signal — this header
                // states the handoff in words that name the destination, and
                // the GO TO CASTING commit below gives it a control.
                GUILayout.Space(6f * s);
                GUILayout.Label("READY FOR CASTING", eyebrowStyle);
                GUILayout.Label(priority.title, figureStyle);
                GUILayout.Label("Development is complete.", bodyStyle);
            }
            if (board.castingBoundaryLine != null)
            {
                GUILayout.Space(4f * s);
                GUILayout.Label(board.castingBoundaryLine, strengthStyle);
            }

            GUILayout.FlexibleSpace();
            if (readyForCasting)
            {
                // B4: the one explicit action the memo/rail/card all lacked —
                // "Casting" as an actionable DESTINATION, not just a word in
                // prose. Routes ONLY through the click-gated Locate seam
                // (Package 02's explicit-command law); never automatic.
                if (GUILayout.Button("GO TO CASTING", commitButtonStyle, GUILayout.MinHeight(54f * s)))
                    StudioLocateAction.Locate(StudioCastingInspectorCard.CastingBuildingStableId, true);
                CaptureRect(rect =>
                {
                    LastGoToCastingScreenRect = rect;
                    // P04A.1: IMGUI has no visual tree for the packaged
                    // owner-input proof to walk, so this control publishes its
                    // own rect. Geometry evidence only — the proof still clicks
                    // real pixels through the OS.
                    StudioUiElementRegistry.Publish(
                        "development-go-to-casting",
                        StudioUiElementRegistry.FromGuiRect(rect),
                        visible: true,
                        enabled: true,
                        text: "GO TO CASTING");
                });
            }
            if (board.review != null)
            {
                if (GUILayout.Button("Review screenplay", commitButtonStyle, GUILayout.MinHeight(54f * s)))
                    OpenReview();
                CaptureRect(rect => LastReviewOpenScreenRect = rect);
            }
            if (board.commission.canSubmitMarketIntent || board.commission.canSubmitOriginalIntent)
            {
                if (GUILayout.Button("Commission a screenplay", buttonStyle, GUILayout.MinHeight(48f * s)))
                    OpenCommission();
                CaptureRect(rect => LastCommissionOpenScreenRect = rect);
            }
            // P03A.1: the writer may lawfully be anywhere on the lot — walking
            // from the shared pool or working at the office — and the player
            // must never have to hunt. Locate is an EXPLICIT command that
            // promises camera movement (Package 02); it selects the exact
            // authoritative writer and focuses them through the selection
            // manager's own double-click seam. Never automatic.
            if (priority != null &&
                (priority.status == "drafting" || priority.status == "rewriting") &&
                !string.IsNullOrWhiteSpace(priority.writerId))
            {
                if (GUILayout.Button($"Locate writer · {priority.writerName}", buttonStyle, GUILayout.MinHeight(38f * s)))
                    StudioLocateAction.Locate(priority.writerId, true);
                CaptureRect(rect => LastLocateWriterScreenRect = rect);
            }
        }

        // ── Commission (annex D): choices left, TypeScript's consequence right ─

        private void DrawCommission(StudioDevelopmentBoardSnapshot board)
        {
            if (board == null) return;
            var s = StudioLegacyUiMetrics.CurrentScale;
            var commission = board.commission;
            var catalog = commission.catalog;
            GUILayout.Label("LIVE LOT · DEVELOPMENT", eyebrowStyle);
            GUILayout.Label("Commission screenplay", titleStyle);
            GUILayout.Space(6f * s);

            var contentWidth = currentAreaRect.width - 32f * s;
            var choicesWidth = contentWidth * 0.55f;
            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical(GUILayout.Width(choicesWidth));

            if (Screen.height >= 860f * s) GUILayout.Label("1 · PICTURE", sectionStyle);
            if (commission.canSubmitOriginalIntent && commission.concepts.Length > 0)
                CyclerRow("Source", draftOriginal ? "Original screenplay" : "Market premise", () => ToggleSource(), () => ToggleSource());
            else
                ConsequenceRow("Source", draftOriginal || commission.concepts.Length == 0 ? "Original screenplay" : "Market premise");
            if (!draftOriginal && commission.concepts.Length > 0)
            {
                var concept = commission.concepts[Clamp(conceptIndex, commission.concepts.Length)];
                CyclerRow("Premise", $"{concept.title} — {concept.genre}", () => CycleConcept(-1), () => CycleConcept(1));
            }
            if (draftOriginal && catalog.genres.Length > 0)
            {
                var genre = catalog.genres[Clamp(genreIndex, catalog.genres.Length)];
                CyclerRow("Direction", genre.label, () => CycleGenre(-1), () => CycleGenre(1));
            }
            if (commission.writers.Length > 0)
            {
                var writer = commission.writers[Clamp(writerIndex, commission.writers.Length)];
                var writerLine = $"{writer.name} — {writer.estimateLabel} {FormatScore(writer.estimateScore)}";
                if (!writer.available && writer.assignmentLabel != null)
                    writerLine += $" — {writer.assignmentLabel}";
                CyclerRow("Writer", writerLine, () => CycleWriter(-1), () => CycleWriter(1));
            }

            if (Screen.height >= 860f * s)
            {
                GUILayout.Space(6f * s);
                GUILayout.Label("2 · CREATIVE BRIEF", sectionStyle);
            }
            if (catalog.openings.Length > 0)
                CyclerRow("Opening", catalog.openings[Clamp(openingIndex, catalog.openings.Length)].title, () => CycleOpening(-1), () => CycleOpening(1));
            if (catalog.midpoints.Length > 0)
                CyclerRow("Midpoint", catalog.midpoints[Clamp(midpointIndex, catalog.midpoints.Length)].title, () => CycleMidpoint(-1), () => CycleMidpoint(1));
            if (catalog.endings.Length > 0)
                CyclerRow("Ending", catalog.endings[Clamp(endingIndex, catalog.endings.Length)].title, () => CycleEnding(-1), () => CycleEnding(1));

            GUILayout.Space(4f * s);
            // Two audiences per row: four in one line would overflow the fixed
            // choices column at the narrow proof floor.
            var segmentCount = Mathf.Min(catalog.segments.Length, segmentSelected.Length);
            for (var rowStart = 0; rowStart < segmentCount; rowStart += 2)
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label(
                    rowStart == 0 ? "Audiences" : " ",
                    statLabelStyle,
                    GUILayout.Width(LabelColumnWidth()));
                for (var index = rowStart; index < Mathf.Min(rowStart + 2, segmentCount); index++)
                {
                    var picked = GUILayout.Toggle(
                        segmentSelected[index],
                        " " + catalog.segments[index].label,
                        ToggleStyle(),
                        GUILayout.MinHeight(28f * s));
                    if (picked != segmentSelected[index]) ToggleSegment(index);
                }
                GUILayout.EndHorizontal();
            }

            for (var axis = 0; axis < catalog.promiseAxes.Length && axis < centerIndex.Length; axis++)
            {
                var info = catalog.promiseAxes[axis];
                var labels = info.centerLabels;
                var center = Clamp(centerIndex[axis], labels.Length);
                CyclerRow(info.title, labels.Length > 0 ? labels[center] : "—",
                    CyclePromiseAction(axis, -1), CyclePromiseAction(axis, 1));
            }

            GUILayout.EndVertical();
            GUILayout.Space(14f * s);
            GUILayout.BeginVertical();

            GUILayout.Label("COMMITMENT", sectionStyle);
            var quote = pendingQuote?.quote as StudioCommissionQuoteSnapshot;
            if (quote != null)
            {
                GUILayout.Label(quote.queues ? "Joins the Development & Casting queue" : "Starts now", figureStyle);
                GUILayout.Label($"Writer: {quote.writerName}", bodyStyle);
                if (quote.title != null) GUILayout.Label($"Premise: {quote.title}", bodyStyle);
                if (quote.draftWeeks != null)
                    GUILayout.Label(
                        quote.draftWeeks == 1 ? "Draft: about 1 week" : $"Draft: about {quote.draftWeeks} weeks",
                        bodyStyle);
                if (quote.reviewWeek != null) GUILayout.Label($"Review: Week {quote.reviewWeek}", bodyStyle);
                GUILayout.Space(8f * s);
                // The commit renders directly under the core terms — HIGH on the
                // card, never in a bottom band (the founding geometric law); the
                // authority's full consequence prose follows beneath it.
                GUI.enabled = client != null && client.ActionsEnabled && CommitArmed;
                if (GUILayout.Button(quote.commitLabel, commitButtonStyle, GUILayout.MinHeight(56f * s)))
                    CommitCommission();
                GUI.enabled = true;
                CaptureRect(rect => LastCommissionCommitScreenRect = rect);
                GUILayout.Label(quote.consequence, mutedStyle);
                if (quote.officeUpliftLine != null) GUILayout.Label(quote.officeUpliftLine, mutedStyle);
                if (quote.richnessNote != null) GUILayout.Label(quote.richnessNote, mutedStyle);
                if (quote.paceNote != null && Screen.height >= 860f * s) GUILayout.Label(quote.paceNote, mutedStyle);
                GUILayout.Label(quote.noFeeLine, mutedStyle);
                if (quote.queueNote != null) GUILayout.Label(quote.queueNote, mutedStyle);
                CommitAvailabilityHint();
            }
            else if (quoteNotice != null)
            {
                GUILayout.Label(quoteNotice, concernStyle);
            }
            else
            {
                GUILayout.Label("Confirming terms with the studio…", mutedStyle);
            }

            GUILayout.EndVertical();
            GUILayout.EndHorizontal();

            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Back to Development", buttonStyle, GUILayout.MinHeight(44f * s)))
                BackToDepartment();
        }

        // ── Review (annex E): evidence above, the two consequences side by side ─

        private void DrawReview(StudioDevelopmentBoardSnapshot board)
        {
            var review = board?.review;
            var s = StudioLegacyUiMetrics.CurrentScale;
            if (review == null)
            {
                GUILayout.Label("DEVELOPMENT", eyebrowStyle);
                GUILayout.Label("The review is no longer waiting.", bodyStyle);
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("Back to Development", buttonStyle, GUILayout.MinHeight(44f * s)))
                    BackToDepartment();
                CaptureRect(rect => LastReviewBackScreenRect = rect);
                return;
            }
            // The tall tier earns the poster typography — but only when the
            // RESOLVED sheet is tall enough to hold it (hostile-review blocker 1:
            // screen height alone once bought big type inside a standard box).
            // The standard tier keeps every fact and drops only point size — the
            // live clip instruments are the net either way. currentAreaRect is
            // already SCREEN space (CurrentCardRect's own scaled output), so the
            // BASE threshold scales up to compare against it — never the other
            // way around, since a base-space Screen.height/s would fight the
            // already-scaled currentAreaRect.height on the same comparison.
            var tall = Screen.height >= 1000f * s &&
                currentAreaRect.height >= StudioDevelopmentCardContracts.TallContentMinimumHeight * s;
            var consequenceStyle = tall ? bodyStyle : mutedStyle;
            GUILayout.Label(
                review.reviewState == "first-draft" ? "FIRST-DRAFT REVIEW" : "FINAL-DRAFT REVIEW",
                eyebrowStyle);
            GUILayout.Label(review.title, titleStyle);
            var identity = $"{review.genre} · {review.writerRoleLabel} {review.writerName}";
            if (review.provenanceLabel != null) identity += $" · {review.provenanceLabel}";
            GUILayout.Label(identity, mutedStyle);
            if (tall && review.deliveryLine != null) GUILayout.Label(review.deliveryLine, mutedStyle);
            GUILayout.Space(4f * s);

            if (review.assessment != null)
            {
                if (tall)
                {
                    // `Est.` stays INSEPARABLE from its number (package §10.2 /
                    // §13.2): one non-wrapping label sized to its own text —
                    // never a fixed column a longer score can wrap out of.
                    var scoreText = $"{review.assessment.label} {FormatScore(review.assessment.score)}";
                    var scoreWidth = bigNumberStyle.CalcSize(new GUIContent(scoreText)).x + 6f * s;
                    GUILayout.BeginHorizontal();
                    GUILayout.Label(scoreText, bigNumberStyle, GUILayout.Width(scoreWidth));
                    GUILayout.BeginVertical();
                    GUILayout.Space(10f * s);
                    GUILayout.Label(review.assessment.band, figureStyle);
                    foreach (var strength in review.assessment.strengths) GUILayout.Label(strength, strengthStyle);
                    foreach (var concern in review.assessment.concerns) GUILayout.Label(concern, concernStyle);
                    GUILayout.EndVertical();
                    GUILayout.EndHorizontal();
                }
                else
                {
                    GUILayout.Label(
                        $"{review.assessment.label} {FormatScore(review.assessment.score)} · {review.assessment.band}",
                        figureStyle);
                    // The compact tier keeps the band, the basis, and the brief;
                    // the generic band sentences yield to the 580f budget.
                    if (Screen.height >= 860f * s)
                    {
                        foreach (var strength in review.assessment.strengths) GUILayout.Label(strength, mutedStyle);
                        foreach (var concern in review.assessment.concerns) GUILayout.Label(concern, mutedStyle);
                    }
                }
            }
            if (review.whyThisEstimate.Length > 0)
            {
                // The findings are facts and render at every tier; the section
                // HEADER is a label the tall sheet earns. The standard 636f
                // sheet at 1440x900 spends that row keeping the Back control
                // whole — the tail/Back containment laws are the net.
                if (tall) GUILayout.Label("WHY THIS ESTIMATE", sectionStyle);
                foreach (var line in review.whyThisEstimate)
                    GUILayout.Label($"{line.label}: {line.finding}", mutedStyle);
            }
            GUILayout.Label(
                $"{review.brief.openingTitle} / {review.brief.midpointTitle} / {review.brief.endingTitle} · " +
                string.Join(" + ", review.brief.segmentLabels),
                mutedStyle);
            if (tall)
                GUILayout.Label(string.Join(" · ", review.brief.promiseLines), mutedStyle);
            GUILayout.Space(6f * s);

            var columnWidth = (currentAreaRect.width - 32f * s - 14f * s) * 0.5f;
            GUILayout.BeginHorizontal();

            GUILayout.BeginVertical(GUILayout.Width(columnWidth));
            GUILayout.Label("ACCEPT NOW", sectionStyle);
            foreach (var line in review.accept.lines) GUILayout.Label(line, consequenceStyle);
            GUILayout.Space(6f * s);
            GUI.enabled = client != null && client.ActionsEnabled && CommitArmed;
            if (GUILayout.Button(review.accept.label, commitButtonStyle, GUILayout.MinHeight(54f * s)))
                CommitAccept();
            GUI.enabled = true;
            CaptureRect(rect => LastAcceptCommitScreenRect = rect);
            GUILayout.EndVertical();

            GUILayout.Space(14f * s);

            GUILayout.BeginVertical(GUILayout.Width(columnWidth));
            GUILayout.Label("FINAL REWRITE", sectionStyle);
            if (review.rewrite.available)
            {
                var preview = review.rewrite.preview;
                if (preview != null)
                {
                    GUILayout.Label($"{preview.currentLine}  →  {preview.projectedLine}", consequenceStyle);
                    // Annex F3: a neutral/gold forecast arrow with the text —
                    // never celebratory green certainty. The arrow is the
                    // required redundant icon; the words are the authority's.
                    GUILayout.Label(
                        preview.direction == "gain" ? $"↗ {preview.directionLine}"
                        : preview.direction == "decline" ? $"↘ {preview.directionLine}"
                        : $"→ {preview.directionLine}",
                        preview.direction == "decline" ? concernStyle : forecastStyle);
                    GUILayout.Label(
                        $"{preview.writerName} · {preview.capacityLine} Review Week {preview.dueWeek}.",
                        consequenceStyle);
                }
                GUILayout.Space(6f * s);
                // The commit sits directly under the core consequence — HIGH on
                // the card, never in the shared bottom band where the previous
                // layer's reveal was pressed (the founding geometric law); the
                // supporting cost and projection notes follow beneath it. The
                // label is the authority's own action label; the card never
                // invents a rewrite verb of its own.
                if (review.rewrite.label != null)
                {
                    GUI.enabled = client != null && client.ActionsEnabled && CommitArmed;
                    if (GUILayout.Button(review.rewrite.label, commitButtonStyle, GUILayout.MinHeight(54f * s)))
                        CommitRewrite();
                    GUI.enabled = true;
                    CaptureRect(rect => LastRewriteCommitScreenRect = rect);
                }
                if (preview != null)
                {
                    GUILayout.Label(preview.operatingLine, mutedStyle);
                    GUILayout.Label(preview.projectionNote, mutedStyle);
                }
            }
            else if (review.finalNote != null)
            {
                GUILayout.Label(review.finalNote, bodyStyle);
            }
            else
            {
                foreach (var blocker in review.rewrite.blockers)
                {
                    GUILayout.Label(blocker.headline, concernStyle);
                    GUILayout.Label($"Remedy: {blocker.remedy}", mutedStyle);
                }
            }
            CaptureRect(rect => LastReviewTailScreenRect = rect);
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();

            CommitAvailabilityHint();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Back to Development", buttonStyle, GUILayout.MinHeight(44f * s)))
                BackToDepartment();
            CaptureRect(rect => LastReviewBackScreenRect = rect);
        }

        // ── Shared drawing helpers ───────────────────────────────────────────

        private float LabelColumnWidth()
        {
            var s = StudioLegacyUiMetrics.CurrentScale;
            return currentAreaRect.width >= 570f * s && Screen.height >= 860f * s ? 170f * s : 130f * s;
        }

        private void ConsequenceRow(string label, string value)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, statLabelStyle, GUILayout.Width(LabelColumnWidth()));
            GUILayout.Label(value, figureStyle);
            GUILayout.EndHorizontal();
        }

        private void CyclerRow(string label, string value, Action previous, Action next)
        {
            var s = StudioLegacyUiMetrics.CurrentScale;
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, statLabelStyle, GUILayout.Width(LabelColumnWidth()));
            if (GUILayout.Button("‹", buttonStyle, GUILayout.Width(34f * s), GUILayout.MinHeight(30f * s))) previous();
            GUILayout.Label(value, statValueStyle, GUILayout.ExpandWidth(true));
            if (GUILayout.Button("›", buttonStyle, GUILayout.Width(34f * s), GUILayout.MinHeight(30f * s))) next();
            GUILayout.EndHorizontal();
        }

        private Action CyclePromiseAction(int axis, int step) => () => CyclePromise(axis, step);

        private void CommitAvailabilityHint()
        {
            if (client == null || !client.ActionsEnabled)
                GUILayout.Label("Waiting for the current studio state…", mutedStyle);
        }

        private void CaptureRect(Action<Rect> record)
        {
            if (Event.current.type != EventType.Repaint) return;
            record(ToScreenRect(GUILayoutUtility.GetLastRect()));
        }

        private Rect ToScreenRect(Rect local) =>
            new Rect(currentAreaRect.x + local.x, currentAreaRect.y + local.y, local.width, local.height);

        private static string FormatScore(double value) =>
            Math.Abs(value - Math.Round(value)) < 0.0001d
                ? ((int)Math.Round(value)).ToString()
                : value.ToString("0.0");

        private GUIStyle ToggleStyle()
        {
            var scale = StudioLegacyUiMetrics.CurrentScale;
            if (toggleStyle != null && Mathf.Approximately(toggleStyleScale, scale)) return toggleStyle;
            toggleStyleScale = scale;
            toggleStyle = new GUIStyle(GUI.skin.toggle)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.StatFontSize, scale),
                normal = { textColor = new Color(0.20f, 0.16f, 0.12f) },
            };
            return toggleStyle;
        }

        private GUIStyle toggleStyle;
        private float toggleStyleScale;

        // ── Wiring ───────────────────────────────────────────────────────────

        private void EnsureSceneReferences()
        {
            if (client == null) client = FindFirstObjectByType<StudioBridgeClient>();
            if (selection == null) selection = FindFirstObjectByType<StudioSelectionManager>();
            if (studioHud == null) studioHud = FindFirstObjectByType<StudioHud>();
        }

        private void EnsureSubscriptions()
        {
            if (client == subscribedClient) return;
            Unsubscribe();
            subscribedClient = client;
            if (subscribedClient == null) return;
            subscribedClient.CommandAccepted += OnCommandAccepted;
            subscribedClient.CommandRejected += OnCommandRejected;
            subscribedClient.QuoteAccepted += OnQuoteAccepted;
            subscribedClient.QuoteRejected += OnQuoteRejected;
            subscribedClient.QuoteUnresolved += OnQuoteUnresolved;
        }

        private void Unsubscribe()
        {
            if (subscribedClient == null) return;
            subscribedClient.CommandAccepted -= OnCommandAccepted;
            subscribedClient.CommandRejected -= OnCommandRejected;
            subscribedClient.QuoteAccepted -= OnQuoteAccepted;
            subscribedClient.QuoteRejected -= OnQuoteRejected;
            subscribedClient.QuoteUnresolved -= OnQuoteUnresolved;
            subscribedClient = null;
        }

        private void OnDestroy()
        {
            Unsubscribe();
            if (surfaceTexture != null) Destroy(surfaceTexture);
        }

        private void EnsureStyles()
        {
            var scale = StudioLegacyUiMetrics.CurrentScale;
            if (surfaceStyle != null && Mathf.Approximately(stylesScale, scale)) return;
            stylesScale = scale;
            if (surfaceTexture == null)
            {
                surfaceTexture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                surfaceTexture.SetPixel(0, 0, new Color(0.93f, 0.89f, 0.79f, 0.96f));
                surfaceTexture.Apply();
                surfaceTexture.hideFlags = HideFlags.HideAndDontSave;
            }
            surfaceStyle = new GUIStyle(GUI.skin.box)
            {
                padding = new RectOffset(
                    Mathf.RoundToInt(16 * scale),
                    Mathf.RoundToInt(16 * scale),
                    Mathf.RoundToInt(12 * scale),
                    Mathf.RoundToInt(12 * scale)),
                normal = { background = surfaceTexture },
            };
            var ink = new Color(0.20f, 0.16f, 0.12f);
            var oxblood = new Color(0.43f, 0.16f, 0.10f);
            var sepia = new Color(0.35f, 0.30f, 0.24f);
            eyebrowStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.EyebrowFontSize, scale),
                fontStyle = FontStyle.Bold,
                normal = { textColor = oxblood },
            };
            titleStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.TitleFontSize, scale),
                fontStyle = FontStyle.Bold,
                wordWrap = true,
                normal = { textColor = ink },
            };
            bodyStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.BodyFontSize, scale),
                wordWrap = true,
                normal = { textColor = ink },
            };
            mutedStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.MutedFontSize, scale),
                wordWrap = true,
                normal = { textColor = sepia },
            };
            strengthStyle = new GUIStyle(bodyStyle)
            {
                normal = { textColor = new Color(0.12f, 0.34f, 0.16f) },
            };
            concernStyle = new GUIStyle(bodyStyle)
            {
                normal = { textColor = new Color(0.62f, 0.14f, 0.10f) },
            };
            // Annex F3 forecast voice: warm gold — a projection, not a promise.
            forecastStyle = new GUIStyle(bodyStyle)
            {
                normal = { textColor = new Color(0.55f, 0.40f, 0.10f) },
            };
            bigNumberStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.BigNumberFontSize, scale),
                fontStyle = FontStyle.Bold,
                alignment = TextAnchor.UpperLeft,
                normal = { textColor = oxblood },
            };
            sectionStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.SectionFontSize, scale),
                fontStyle = FontStyle.Bold,
                normal = { textColor = oxblood },
            };
            statLabelStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.StatFontSize, scale),
                alignment = TextAnchor.MiddleLeft,
                normal = { textColor = ink },
            };
            statValueStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.StatFontSize, scale),
                alignment = TextAnchor.MiddleLeft,
                wordWrap = true,
                normal = { textColor = sepia },
            };
            figureStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.FigureFontSize, scale),
                fontStyle = FontStyle.Bold,
                wordWrap = true,
                alignment = TextAnchor.MiddleLeft,
                normal = { textColor = ink },
            };
            buttonStyle = new GUIStyle(GUI.skin.button)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.ButtonFontSize, scale),
            };
            commitButtonStyle = new GUIStyle(GUI.skin.button)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(StudioFoundingCardContracts.ButtonFontSize, scale),
                fontStyle = FontStyle.Bold,
            };
            foreach (var style in new[] { buttonStyle, commitButtonStyle })
            {
                style.normal.textColor = ink;
                style.hover.textColor = ink;
                style.active.textColor = ink;
                style.focused.textColor = ink;
            }
            commitButtonStyle.normal.textColor = oxblood;
        }
    }
}
