# Projection61 readback named-union correction

KEEP sparse correction for fresh generation; UNRUN. SOURCE30e43896fc1e19cf00bf72c184a075ad9259720ac8cb687bda7faec4698b2693/MANIFESTce3b779bbf77725cce0765c67a2e9f83e33a6600b9cc1c05af193a9dc35dc4af; industry post13e90714cbe82d307d8edbf2ee07b7e190bc8c746a943ad29ebfa2e5cfe61359. Declared hashes verified.

Second actual generation contractchild1/1s fails CF08-ANONYMOUS-MEMBER at StudioPaidReportSubject/anyOf/0, referenced by body.rights[].subject. Fixtures never start; retain both failed attempts. First correction addressed core draft unions only and did not establish full generator compatibility; this adjacent readback omission was caught by canonical generation.

Both PaidReportTarget and PaidReportSubject lift their existing exact/literal objects to named constants, reference them as members, and export all four in industryDefinitions. Accepted JSON fields and discriminator values unchanged; strict object validation and inferred data shape preserved. No emitter change, alternate serialization, fabricated generated hash or historical identity rewrite.

Targeted inspection of all union calls in changed61 bridge-schema/industry-schema/intent-schema agrees with UNION-INSPECTION: two new core draft unions, two new readback unions now local namedrefs; existing command/promise/request/quote unions already reference named members; intent-schema has none. No remaining inline object member found in these union calls. This closes the specific named-member constraint, not proof that every later emitter constraint will pass. Parent fresh generation must retain exact four output envelope and unchanged non-output/source/index/inputs guards. No reviewer runtime or K/R writes.
