using System;
using Studio.Runtime.Data;
using Studio.Runtime.Infrastructure;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UIElements;

namespace ProjectStudio.UnitySpike.Presentation
{
    /// <summary>
    /// P04A Wave 0: the single UI Toolkit workspace host. Owns the runtime
    /// UIDocument, its code-created PanelSettings (the ONE scaling-policy
    /// site — ScaleWithScreenSize, 1920x1080 reference resolution, match
    /// 0.5), the guarded EventSystem/InputSystemUIInputModule pair, and the
    /// full-screen picking scrim that IS the world-click suppression while a
    /// workspace stands open: once an EventSystem exists, StudioCameraInput's
    /// existing EventSystem-first IsPointerOverUi check picks up the panel
    /// for free — zero StudioCameraInput edits.
    ///
    /// Esc grammar (frozen): TryConsumeCancel peels exactly one UI layer per
    /// call — modal, then a nested layer, then the workspace root. Wave 0 has
    /// neither a modal nor a nested layer yet, so one call closes the root.
    ///
    /// SuspendForLocate hands the frame to a "Locate this on the lot" control
    /// without discarding where the player was: it hides the panel, restores
    /// camera input, dispatches the one sanctioned Locate call, and reopens
    /// itself — with the retained context intact — the instant
    /// TycoonCameraController reports the navigation origin restored (i.e.
    /// the player found their own way back to this camera pose).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class StudioWorkspaceHost : MonoBehaviour
    {
        private UIDocument uiDocument;
        private PanelSettings panelSettings;
        private StudioPresentationInputContext inputContext;
        private TycoonCameraController cameraController;
        private StudioBridgeClient client;
        private StudioBridgePresentation presentation;
        private StudioSelectionManager selectionManager;

        private VisualElement scrim;
        private StudioCastingWorkspace castingWorkspace;
        private StudioCastingInspectorCard inspectorCard;

        private StudioCastingWorkspaceContext retainedContext;
        private bool workspaceOpen;
        private bool suspendedForLocate;
        private bool subscribedToNavigationRestore;
        private bool subscribedToClientSnapshots;
        private bool subscribedToCastingQuoteEvents;

        // ── P04A Wave 6: the greenlight commit's own tracked commandId — the
        // generic CommandAccepted/CommandRejected events fire for EVERY
        // submitted command in the whole game; this is what lets
        // OnGreenlightCommandAccepted/Rejected below attribute the next one
        // (or the exact matching rejection) to OUR commit specifically,
        // mirroring StudioDevelopmentCardHud's own pendingCommandId pattern. ──
        private string pendingGreenlightCommandId;

        public static StudioWorkspaceHost Instance { get; private set; }

        public bool WorkspaceOpen => workspaceOpen;

        private bool initialized;

        private void Awake() => EnsureInitialized();

        /// <summary>
        /// Idempotent setup, called from Awake AND defensively from every
        /// public entry point below. Awake's own timing is enough in the
        /// running game (StudioBridgeBootstrap adds this component at
        /// runtime, where Awake always fires before any other call can
        /// reach it) — the defensive re-check exists purely so this
        /// singleton's invariants (Instance set, PanelSettings created,
        /// scrim/panel built) never depend on exactly when Unity happens to
        /// invoke Awake for a component created moments earlier.
        /// </summary>
        private void EnsureInitialized()
        {
            if (initialized) return;
            initialized = true;

            Instance = this;

            cameraController = FindFirstObjectByType<TycoonCameraController>();
            client = GetComponent<StudioBridgeClient>();
            if (client == null) client = FindFirstObjectByType<StudioBridgeClient>();
            presentation = FindFirstObjectByType<StudioBridgePresentation>();
            selectionManager = FindFirstObjectByType<StudioSelectionManager>();
            inputContext = GetComponent<StudioPresentationInputContext>();
            if (inputContext == null) inputContext = gameObject.AddComponent<StudioPresentationInputContext>();

            uiDocument = GetComponent<UIDocument>();
            if (uiDocument == null) uiDocument = gameObject.AddComponent<UIDocument>();

            panelSettings = ScriptableObject.CreateInstance<PanelSettings>();
            panelSettings.scaleMode = PanelScaleMode.ScaleWithScreenSize;
            panelSettings.referenceResolution = new Vector2Int(1920, 1080);
            panelSettings.match = 0.5f;
            uiDocument.panelSettings = panelSettings;

            EnsureEventSystem();
            BuildVisualTree();
            ApplyClosedVisualState();
        }

        private void OnEnable()
        {
            EnsureInitialized();
            SubscribeClientSnapshots();
            SubscribeCastingQuoteEvents();
            EvaluateCastingOwnerPresence();
        }

        private void Start()
        {
            if (client?.Current != null) OnSnapshotApplied(client.Current);
        }

        private void Update()
        {
            EnsureInitialized();
            RefreshInspectorCardVisibility();
            if (workspaceOpen)
            {
                castingWorkspace?.MaintainScreenTestQuote();
                castingWorkspace?.MaintainGreenlightQuote();
            }
            MaybeEmitElementMap();
        }

        // ── P04A.1: the element map — geometry evidence, never an input bypass ─
        //
        // Owner charter §11 requires a packaged proof that clicks the SAME public
        // mouse path the Owner uses and records, per step, the clicked element
        // NAME, the screen coordinate, the action produced and the resulting
        // visual state. Reflection-only tests are explicitly insufficient.
        //
        // This emitter is what makes the honest version of that possible. Under
        // -studioUiElementMap it periodically writes every named workspace
        // element's rect — in Unity screen space — to a JSON file. The harness
        // reads it to decide WHERE to aim and WHAT to call the thing it hit;
        // the click itself is still a real OS HID event landing on real pixels,
        // and nothing here can activate a control. It is opt-in, gameplay-inert,
        // and follows the same command-line-flag convention as every existing
        // -studio*Proof runner.
        //
        // It is also how the P04A.1 root cause was measured: at 1440x900 the
        // ScrollView reported viewportH 1023 == contentH 1023 with vRange 0..0,
        // proving the body could not scroll and that the dossier was unreachable.
        private const string ElementMapFlag = "-studioUiElementMap";
        private const string ElementMapPathFlag = "-studioUiElementMapPath";
        private const int ElementMapIntervalFrames = 15;
        private string elementMapPath;
        private long elementMapGeneration;
        private bool elementMapResolved;

        private void MaybeEmitElementMap()
        {
            if (!elementMapResolved)
            {
                elementMapResolved = true;
                elementMapPath = ResolveElementMapPath();
            }
            if (elementMapPath == null) return;
            if (Time.frameCount % ElementMapIntervalFrames != 0) return;

            var panel = uiDocument?.rootVisualElement?.panel;
            if (panel == null) return;

            var builder = new System.Text.StringBuilder();
            var mapRoot = uiDocument.rootVisualElement;
            builder.Append("{\"screenWidth\":").Append(Screen.width)
                   .Append(",\"screenHeight\":").Append(Screen.height)
                   .Append(",\"workspaceOpen\":").Append(workspaceOpen ? "true" : "false")
                   .Append(",\"rootPicking\":\"").Append(mapRoot.pickingMode)
                   .Append("\",\"rootEnabled\":").Append(mapRoot.enabledInHierarchy ? "true" : "false")
                   .Append(",\"eventSystem\":\"")
                   .Append(EventSystem.current == null
                       ? "none"
                       : (EventSystem.current.isActiveAndEnabled ? "active" : "inactive"))
                   .Append("\",\"mapGeneration\":").Append(++elementMapGeneration)
                   .Append(",\"frameCount\":").Append(Time.frameCount)
                   // ── P04A.2 A+B diagnosis — OBSERVATION ONLY ────────────────
                   // Everything the proof needs to classify a failed
                   // `expect workspace open` as product / harness /
                   // sequencing / environment, published at the same instant
                   // as the element rects it is compared against.
                   .Append(",\"diag\":{\"suspendedForLocate\":").Append(suspendedForLocate ? "true" : "false")
                   .Append(",\"retainedProjectId\":\"").Append(Escape(retainedContext?.ProjectId ?? ""))
                   .Append("\",\"selectionStableId\":\"").Append(Escape(selectionManager?.Selected?.StableId ?? ""))
                   .Append("\",\"castingBuildingStableId\":\"").Append(StudioCastingInspectorCard.CastingBuildingStableId)
                   .Append("\",\"castingBoardProjectCount\":").Append(CastingBoard()?.projects?.Length ?? -1)
                   .Append(",\"inspectorCardBoundProjectId\":\"").Append(Escape(inspectorCard?.BoundProjectId ?? ""))
                   .Append("\",\"inspectorCardDisplayed\":").Append(inspectorCard != null && inspectorCard.IsDisplayed ? "true" : "false")
                   .Append(",\"hasInputContext\":").Append(inputContext != null ? "true" : "false")
                   .Append("},\"elements\":[");
            var first = true;
            AppendElements(uiDocument.rootVisualElement, uiDocument.rootVisualElement, builder, ref first);
            // Legacy IMGUI surfaces have no visual tree to walk; the ones a
            // player-input proof must reach publish their own rects instead.
            foreach (var entry in StudioUiElementRegistry.Entries)
            {
                if (!first) builder.Append(',');
                first = false;
                builder.Append("{\"name\":\"").Append(Escape(entry.Name))
                       .Append("\",\"type\":\"IMGUI\",\"classes\":\"\",\"text\":\"")
                       .Append(Escape(entry.Text))
                       .Append("\",\"visible\":").Append(entry.Visible ? "true" : "false")
                       .Append(",\"enabled\":").Append(entry.Enabled ? "true" : "false")
                       .Append(",\"screenRect\":[")
                       .Append(entry.ScreenRect.x.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                       .Append(entry.ScreenRect.y.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                       .Append(entry.ScreenRect.width.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                       .Append(entry.ScreenRect.height.ToString("F1", System.Globalization.CultureInfo.InvariantCulture))
                       .Append("]}");
            }
            builder.Append("]}");

            try
            {
                System.IO.File.WriteAllText(elementMapPath, builder.ToString());
            }
            catch (Exception error)
            {
                Debug.LogWarning($"[StudioWorkspaceHost] element map write failed: {error.Message}");
                elementMapPath = null;
            }
        }

        private static string ResolveElementMapPath()
        {
            var arguments = Environment.GetCommandLineArgs();
            if (Array.IndexOf(arguments, ElementMapFlag) < 0) return null;
            var pathIndex = Array.IndexOf(arguments, ElementMapPathFlag);
            if (pathIndex >= 0 && pathIndex + 1 < arguments.Length) return arguments[pathIndex + 1];
            return System.IO.Path.Combine(Application.persistentDataPath, "studio-ui-element-map.json");
        }

        /// <summary>
        /// Walks the real hierarchy (not the content-container view — a
        /// ScrollView's own chrome must be visible to the map) and records every
        /// NAMED element. Rects are converted from panel space into Unity screen
        /// space by inverting the panel's own ScreenToPanel mapping at two
        /// reference corners, so the scaling policy stays owned by PanelSettings
        /// and is never duplicated as a constant here.
        /// </summary>
        private static void AppendElements(
            VisualElement element,
            VisualElement panelRoot,
            System.Text.StringBuilder builder,
            ref bool first)
        {
            if (element == null) return;

            if (!string.IsNullOrEmpty(element.name))
            {
                var bound = element.worldBound;
                // A rect alone is not an aimable target. Content scrolled out of
                // the workspace body still HAS a worldBound, and an earlier
                // version of this map published those — so a harness aiming at
                // the second candidate row's [Choose] actually clicked the
                // readiness strip drawn over it, and the run looked like a
                // click that "did nothing". worldClip is the element's resolved
                // clipping rectangle; intersecting with it is what turns a rect
                // into a place a real pointer can honestly land.
                var clipped = VisibleAreaOf(element, bound);
                var screenRect = PanelRectToScreen(panelRoot, clipped);
                var visible = element.resolvedStyle.display == DisplayStyle.Flex &&
                              bound.width > 0f && bound.height > 0f &&
                              clipped.width > 1f && clipped.height > 1f &&
                              // A sliver peeking past a scroll edge is not a
                              // control a player could reasonably hit either.
                              clipped.height >= bound.height * 0.6f;
                if (!first) builder.Append(',');
                first = false;
                builder.Append("{\"name\":\"").Append(Escape(element.name))
                       .Append("\",\"type\":\"").Append(element.GetType().Name)
                       .Append("\",\"classes\":\"").Append(Escape(string.Join(" ", element.GetClasses())))
                       .Append("\",\"text\":\"").Append(Escape(element is TextElement text ? text.text : string.Empty))
                       .Append("\",\"visible\":").Append(visible ? "true" : "false")
                       .Append(",\"enabled\":").Append(element.enabledInHierarchy ? "true" : "false")
                       .Append(",\"screenRect\":[")
                       .Append(screenRect.x.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                       .Append(screenRect.y.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                       .Append(screenRect.width.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                       .Append(screenRect.height.ToString("F1", System.Globalization.CultureInfo.InvariantCulture))
                       .Append("]}");
            }

            for (var index = 0; index < element.hierarchy.childCount; index++)
                AppendElements(element.hierarchy[index], panelRoot, builder, ref first);
        }

        /// <summary>
        /// Panel space (origin TOP-left, y down) to Unity screen space (origin
        /// BOTTOM-left, y up, pixels) — the convention every other rect in the
        /// map already uses, and the one a pointer harness needs.
        ///
        /// Derived from the panel root's own measured size rather than from
        /// RuntimePanelUtils.ScreenToPanel: an earlier version inferred the
        /// mapping by inverting ScreenToPanel at two corners and got the Y axis
        /// backwards, which put [OPEN CASTING] 270 points above where it
        /// actually was. A harness aiming at that would have clicked empty sky
        /// and — worse — could have recorded the miss as a pass. The root is
        /// stretched to the whole panel by BuildVisualTree, so its worldBound IS
        /// the panel rect, and the overlay scale is simply screen/panel.
        /// </summary>
        /// <summary>
        /// The part of an element that is actually on screen: its own rect
        /// intersected with every ancestor's.
        ///
        /// `VisualElement.worldClip` would say this directly but is not public
        /// in this Unity version, and reading resolved `overflow` is not
        /// available either. Intersecting the ancestor chain is the honest
        /// approximation: in this panel every container is normal-flow and
        /// contains its children, so the only place the intersection actually
        /// bites is the one that matters — content scrolled outside the
        /// workspace body, which has a perfectly good worldBound and is
        /// nonetheless somewhere no pointer can reach it.
        /// </summary>
        private static Rect VisibleAreaOf(VisualElement element, Rect bound)
        {
            var visible = bound;
            for (var ancestor = element.hierarchy.parent; ancestor != null; ancestor = ancestor.hierarchy.parent)
            {
                visible = Intersection(visible, ancestor.worldBound);
                if (visible.width <= 0f || visible.height <= 0f) return Rect.zero;
            }
            return visible;
        }

        /// <summary>The overlapping area of two panel-space rects, or an empty rect.</summary>
        private static Rect Intersection(Rect a, Rect b)
        {
            var xMin = Mathf.Max(a.xMin, b.xMin);
            var yMin = Mathf.Max(a.yMin, b.yMin);
            var xMax = Mathf.Min(a.xMax, b.xMax);
            var yMax = Mathf.Min(a.yMax, b.yMax);
            if (xMax <= xMin || yMax <= yMin) return Rect.zero;
            return new Rect(xMin, yMin, xMax - xMin, yMax - yMin);
        }

        private static Rect PanelRectToScreen(VisualElement panelRoot, Rect panelRect)
        {
            var panelBound = panelRoot.worldBound;
            if (panelBound.width <= 0f || panelBound.height <= 0f) return Rect.zero;

            var scaleX = Screen.width / panelBound.width;
            var scaleY = Screen.height / panelBound.height;
            var width = panelRect.width * scaleX;
            var height = panelRect.height * scaleY;
            var left = (panelRect.x - panelBound.x) * scaleX;
            var topInYDown = (panelRect.y - panelBound.y) * scaleY;
            return new Rect(left, Screen.height - (topInYDown + height), width, height);
        }

        private static string Escape(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", " ").Replace("\r", " ");
        }

        private void OnDisable()
        {
            UnsubscribeClientSnapshots();
            UnsubscribeCastingQuoteEvents();
            // P04A: a disabled host can never strand the memo verbless — the
            // classic manual casting verbs must return the instant no
            // workspace declares presence over them. Mirrors
            // StudioLivingTimeHud's own OnDisable law for time ownership.
            if (client != null) client.SetCastingOwnerPresent(false);
            // SMALL FIX B: a disabled-but-not-destroyed host must not leave
            // workspaceOpen stuck true — StudioHud/StudioProductionRailHud
            // read Instance.WorkspaceOpen directly and would suppress the
            // rail/receipt forever otherwise. Mirrors CloseWorkspace's own
            // state reset (never touching retainedContext beyond exactly
            // what CloseWorkspace already does to it: null it).
            workspaceOpen = false;
            retainedContext = null;
            // Re-verdict advisory: reset ALL the latches CloseWorkspace resets.
            // A host disabled mid-Locate must not suppress the inspector card
            // forever (suspendedForLocate) nor reopen later from a stale
            // NavigationOriginRestored subscription against a null context.
            suspendedForLocate = false;
            UnsubscribeNavigationOriginRestored();
            ApplyClosedVisualState();
            if (inputContext != null) inputContext.RestoreForWorkspace();
        }

        private void OnDestroy()
        {
            UnsubscribeNavigationOriginRestored();
            UnsubscribeClientSnapshots();
            UnsubscribeCastingQuoteEvents();
            if (client != null) client.SetCastingOwnerPresent(false);
            if (Instance == this) Instance = null;
            if (panelSettings != null) DestroyImmediate(panelSettings);
        }

        /// <summary>Opens (or re-targets) the Casting workspace for one project.</summary>
        public void OpenCasting(string projectId)
        {
            EnsureInitialized();
            UnsubscribeNavigationOriginRestored();
            retainedContext = new StudioCastingWorkspaceContext { ProjectId = projectId };
            suspendedForLocate = false;
            workspaceOpen = true;
            BindCastingWorkspace();
            ApplyOpenVisualState();
            if (inputContext != null) inputContext.SuspendForWorkspace();
        }

        public void CloseWorkspace()
        {
            EnsureInitialized();
            UnsubscribeNavigationOriginRestored();
            workspaceOpen = false;
            suspendedForLocate = false;
            retainedContext = null;
            ApplyClosedVisualState();
            if (inputContext != null) inputContext.RestoreForWorkspace();
        }

        // ── P04A.1: transient-draft honesty ──────────────────────────────────
        //
        // The Casting package draft and the camera-test slate are PRESENTATION
        // ONLY — they live entirely in the retained context and are deliberately
        // absent from Save V15 (Package 04 §1.3, annex §H1). Closing the
        // workspace therefore destroys them. That is lawful, but it must never
        // be silent: P04A.1 §14 requires an explicit confirmation before a
        // player action throws away selections they can see on screen.
        //
        // The prompt itself is NOT rendered here. Legacy IMGUI draws above this
        // runtime UI Toolkit panel (observed: the LOT SELECTION receipt
        // overdraws the Casting inspector card), so a UI Toolkit modal could not
        // actually be modal over the memo. StudioSystemMenuHud owns the one
        // confirmation surface — for closing here, and for Load Game and Quit to
        // Desktop — and registers itself through the seam below.
        //
        // Fail OPEN toward playability, exactly like the memo-ownership law: with
        // no confirmation owner registered, a close proceeds immediately rather
        // than trapping the player in a workspace they cannot leave.

        /// <summary>
        /// True while the player holds Casting selections that exist only in
        /// presentation state — any filled package role, either budget pick, or
        /// a non-empty camera-test slate. False whenever no workspace is open.
        /// </summary>
        public static bool HasUncommittedCastingDraft => ContextHasDraft(Instance?.retainedContext);

        internal static bool ContextHasDraft(StudioCastingWorkspaceContext context)
        {
            if (context == null) return false;
            // The package draft and the budgets are uncommitted until Greenlight.
            //
            // AFTER a greenlight the authority accepted, they are not: the
            // package became a production, and the ids are retained only so the
            // receipt and review can still name what was committed. Warning the
            // player they are about to discard that work is false, and it lands
            // in the worst possible place — the moment just after they greenlit
            // their first picture, on the [Close] the receipt itself offers.
            // This is the same defect the camera-test slate note below already
            // records, on the other committed artefact in this workspace.
            if (context.GreenlightCommitted) return false;
            if (!string.IsNullOrEmpty(context.DirectorId)
                || !string.IsNullOrEmpty(context.LeadId)
                || !string.IsNullOrEmpty(context.AntagonistId)
                || !string.IsNullOrEmpty(context.SupportId)
                || !string.IsNullOrEmpty(context.CraftLeadId)
                || context.NegativeAmount.HasValue
                || context.MarketingAmount.HasValue) return true;

            // The camera-test slate counts ONLY while the planner is still open,
            // i.e. before the tests have been committed.
            //
            // Caught by the sealed casting-navigation proof: that journey commits
            // a screen-test quote and then presses Esc, and an earlier version of
            // this method counted the retained slate as an uncommitted draft. Esc
            // then raised a discard warning instead of closing the workspace —
            // regressing the sealed one-layer Esc grammar AND telling the player
            // something false, because once the quote is committed the session is
            // real and the slate is no longer a pending selection at all. The
            // context keeps it purely so the Underway view can show which six
            // reads the client itself submitted (see StudioCastingWorkspaceContext).
            //
            // Bind() already clears PlannerActive the moment sessionStatus leaves
            // notStarted, so it is exactly the "nothing has been committed yet"
            // signal this needs.
            if (!context.PlannerActive) return false;
            return (context.SlateLead != null && context.SlateLead.Count > 0)
                || (context.SlateAntagonist != null && context.SlateAntagonist.Count > 0)
                || (context.SlateSupport != null && context.SlateSupport.Count > 0);
        }

        /// <summary>
        /// The one confirmation seam. StudioSystemMenuHud assigns this; the
        /// argument is the "the player confirmed — proceed" continuation, which
        /// the owner invokes only on an explicit Discard. Null = no owner.
        /// </summary>
        public static Action<Action> DiscardConfirmationOwner;

        /// <summary>
        /// The PLAYER's close route — [Back] and the Esc grammar's workspace-root
        /// step. Confirms first when discarding would lose visible selections.
        /// Authority-driven closes (the project leaving the board) keep calling
        /// <see cref="CloseWorkspace"/> directly: those are not a player act and
        /// must never raise a prompt the player did not ask for.
        /// </summary>
        public void RequestCloseWorkspace()
        {
            EnsureInitialized();
            if (!workspaceOpen || !HasUncommittedCastingDraft || DiscardConfirmationOwner == null)
            {
                CloseWorkspace();
                return;
            }
            DiscardConfirmationOwner(CloseWorkspace);
        }

        /// <summary>
        /// P04A.1: makes the whole UI Toolkit panel inert while a higher layer
        /// owns the frame — today, the Studio Menu.
        ///
        /// This is not cosmetic. Legacy IMGUI and the runtime UI Toolkit panel
        /// are two independent input paths: IMGUI draws above the panel but does
        /// not block its picking, so without this a "modal" menu would still let
        /// clicks land on the Casting workspace underneath it. Setting the panel
        /// root to Ignore stops UI Toolkit picking outright, which also makes
        /// StudioCameraInput's EventSystem-first check stop reporting the panel —
        /// so the menu's own suppression of world clicks is the single owner of
        /// the frame while it stands open.
        ///
        /// Nothing here closes, commits, or mutates: the workspace and its
        /// reversible draft are exactly as the player left them when the frame
        /// comes back.
        /// </summary>
        public static void SetPanelInputSuppressed(bool suppressed)
        {
            var root = Instance?.uiDocument?.rootVisualElement;
            if (root == null) return;
            root.pickingMode = suppressed ? PickingMode.Ignore : PickingMode.Position;
            root.SetEnabled(!suppressed);
        }

        /// <summary>
        /// P04A Wave 3 Esc grammar: modal (none yet), then the dossier nested
        /// layer (a selected candidate — peels back to the list, which stays
        /// exactly as it was), then workspace-root close — exactly one layer
        /// peels per call. False when nothing is open, or while suspended for
        /// a Locate round trip (the world's own Esc grammar owns the frame).
        /// </summary>
        public static bool TryConsumeCancel()
        {
            var instance = Instance;
            if (instance == null) return false;
            if (instance.suspendedForLocate) return false;
            if (!instance.workspaceOpen) return false;

            if (instance.castingWorkspace != null && instance.castingWorkspace.TryPeelDossier())
                return true;

            // P04A.1: the workspace-root peel is a PLAYER act, so it takes the
            // confirming route — Esc must not silently throw away a package
            // draft the player can see on screen. Exactly one layer still peels
            // per press: when a confirmation is raised, the prompt IS this
            // press's one layer.
            instance.RequestCloseWorkspace();
            return true;
        }

        /// <summary>
        /// Hands the world back to a "Locate this on the lot" control without
        /// discarding where the player was: hide the panel, restore camera
        /// input, dispatch the one sanctioned Locate call, then wait for the
        /// navigation-origin restore to reopen with the retained context.
        /// </summary>
        public void SuspendForLocate(string stableId, bool focus)
        {
            EnsureInitialized();
            if (!workspaceOpen || suspendedForLocate) return;

            ApplyClosedVisualState();
            if (inputContext != null) inputContext.RestoreForWorkspace();
            workspaceOpen = false;
            suspendedForLocate = true;

            StudioLocateAction.Locate(stableId, focus);

            SubscribeNavigationOriginRestored();
        }

        /// <summary>The scrim covers the whole screen while a workspace is open.</summary>
        public bool ContainsScreenPoint(Vector2 point)
        {
            EnsureInitialized();
            if (!workspaceOpen) return false;
            return point.x >= 0f && point.x <= Screen.width && point.y >= 0f && point.y <= Screen.height;
        }

        private void SubscribeNavigationOriginRestored()
        {
            if (subscribedToNavigationRestore || cameraController == null) return;
            cameraController.NavigationOriginRestored += OnNavigationOriginRestored;
            subscribedToNavigationRestore = true;
        }

        private void UnsubscribeNavigationOriginRestored()
        {
            if (!subscribedToNavigationRestore || cameraController == null) return;
            cameraController.NavigationOriginRestored -= OnNavigationOriginRestored;
            subscribedToNavigationRestore = false;
        }

        private void OnNavigationOriginRestored()
        {
            UnsubscribeNavigationOriginRestored();
            if (!suspendedForLocate) return;

            suspendedForLocate = false;
            workspaceOpen = true;
            ApplyOpenVisualState();
            if (inputContext != null) inputContext.SuspendForWorkspace();
        }

        private void BuildVisualTree()
        {
            var root = uiDocument.rootVisualElement;
            root.Clear();
            // P04A visual-defect fix — the actual root cause, confirmed by
            // instrumenting root.worldBound/layout in a built Player: with
            // every direct child of `root` positioned absolutely (the scrim,
            // castingWorkspace.Root, and inspectorCard.Root all set
            // `style.position = Position.Absolute` below), NONE of them
            // participate in `root`'s own normal-flow auto-height
            // computation — so `root` itself resolved to width=full-panel-
            // width but height=0 (confirmed via worldBound in the Player
            // log), collapsing every absolutely-positioned descendant's
            // inset-based geometry (top/bottom, or 0/0/0/0) to zero height
            // right along with it. This is why NOTHING rendered — not even
            // an inline, fully-opaque diagnostic background color set
            // directly on castingWorkspace.Root — regardless of any USS/
            // theme/custom-property state: there was no drawable area at
            // all. `root` must stretch to its own panel explicitly, exactly
            // like every child anchored against it already assumes it does.
            root.style.position = Position.Absolute;
            root.style.left = 0f;
            root.style.top = 0f;
            root.style.right = 0f;
            root.style.bottom = 0f;

            // P04A visual-defect fix — the SECOND real root cause, confirmed
            // once the zero-height bug above was fixed and the panel became
            // visible: not one glyph rendered anywhere (Debug.LogError-free —
            // Resources.Load for both stylesheets succeeds, so this is not
            // suspect #1). The Player log independently confirms it: Unity
            // itself logs "No Theme Style Sheet set to PanelSettings , UI
            // will not render properly" the instant this code-created
            // PanelSettings is constructed above — this project has never
            // run the Editor's UI Toolkit "add a UI Document" workflow that
            // normally auto-wires a themeStyleSheet/PanelTextSettings pair,
            // and PanelSettings created via ScriptableObject.CreateInstance
            // gets neither. Hostile-review correction: this does NOT mean no
            // theme asset exists in-tree — Assets/UI Toolkit/UnityThemes/
            // UnityDefaultRuntimeTheme.tss is already here (Unity auto-
            // generates it the first time a project touches the UI Toolkit
            // workflow). It is deliberately NOT wired to this code-created
            // PanelSettings.themeStyleSheet: this project's explicit --ps-*
            // token sheet plus per-workspace USS already own the entire
            // visual look end to end, and wiring Unity's stock default theme
            // on top would silently introduce a second, unreviewed source of
            // default control styling this lane never asked for. It remains
            // a candidate for a future, deliberate wiring decision — not
            // adopted here. Instead every text element gets an explicit font
            // the same way the panel itself gets explicit geometry: Unity's
            // own always-available built-in runtime font, assigned once here
            // and inherited by every descendant Label/Button, with zero new
            // assets.
            root.style.unityFontDefinition = new StyleFontDefinition(
                FontDefinition.FromFont(Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf")));

            // Separately (defensive hardening, not the cause above):
            // StudioUiTokens.uss declares every --ps-* custom property under
            // a `:root` rule. Unity's `:root` pseudo-class is documented to
            // match "the root element of the panel" — in practice this is
            // only reliably rootVisualElement itself when nothing
            // disqualifies it, and real-world Unity UI
            // Toolkit deployments have repeatedly hit configurations where a
            // `:root`-only rule silently matches nothing once a stylesheet is
            // attached programmatically rather than through the UI Builder.
            // A dedicated class name on the actual attached root removes that
            // ambiguity entirely: StudioUiTokens.uss now matches on BOTH
            // `:root` and `.ps-app-root`, so the custom properties resolve
            // here regardless of which one Unity's selector engine honors.
            root.AddToClassList("ps-app-root");
            ApplyStyleSheets(root);


            scrim = new VisualElement { name = "workspace-scrim", pickingMode = PickingMode.Position };
            scrim.style.position = Position.Absolute;
            scrim.style.left = 0f;
            scrim.style.top = 0f;
            scrim.style.right = 0f;
            scrim.style.bottom = 0f;
            scrim.style.backgroundColor = new Color(0f, 0f, 0f, 0.4f);
            // No click handler is ever registered on the scrim: clicking it
            // must do nothing — no close, no commit. Its only job is picking
            // (so StudioCameraInput's EventSystem-first IsPointerOverUi check
            // swallows the click before it reaches world picking/orbit).
            root.Add(scrim);

            castingWorkspace = new StudioCastingWorkspace();
            castingWorkspace.Configure(
                RequestCloseWorkspace,
                ResolveLocateStableId,
                SuspendForLocate,
                RequestScreenTestQuote,
                IsScreenTestQuoteInFlight,
                LiveStateRevision,
                AreScreenTestActionsEnabled,
                CommitScreenTestQuote,
                AcknowledgeReview);
            castingWorkspace.ConfigureGreenlight(
                CommitGreenlightQuote,
                OpenCasting,
                CurrentActiveProductions);
            // Right-anchored per annex D1: min(1120px, 82vw), 24-32px inset,
            // <=88% height, dodging the top-right BACK band (190x50 scaled)
            // and the bottom-right receipt band (r4 recon §8). This is Wave
            // 0's own geometry in the UI Toolkit reference space (1920x1080)
            // — not a byte-identical match to the legacy IMGUI surfaces,
            // which scale off a different reference resolution and have no
            // "avoid right dock" hook to compose with.
            castingWorkspace.Root.style.position = Position.Absolute;
            castingWorkspace.Root.style.right = 28f;
            castingWorkspace.Root.style.top = 90f;
            castingWorkspace.Root.style.bottom = 170f;
            castingWorkspace.Root.style.width = new Length(82f, LengthUnit.Percent);
            castingWorkspace.Root.style.maxWidth = 1120f;
            castingWorkspace.Root.style.maxHeight = new Length(88f, LengthUnit.Percent);
            root.Add(castingWorkspace.Root);

            inspectorCard = new StudioCastingInspectorCard();
            inspectorCard.Configure(OpenCasting);
            // Compact world-entry card. r4 §8's composite geography leaves no
            // fully clear left-anchored band (the memo panel runs the FULL
            // screen height), so this mirrors the established compact-card
            // convention instead: stacked near the bottom-right, above where
            // the legacy selection receipt renders, clear of the top-right
            // BACK band. It is hidden whenever the full workspace is open
            // (RefreshInspectorCardVisibility) so the two right-anchored
            // surfaces never compete for the same pixels.
            inspectorCard.Root.style.position = Position.Absolute;
            inspectorCard.Root.style.right = 28f;
            inspectorCard.Root.style.bottom = 190f;
            inspectorCard.Root.style.width = 360f;
            root.Add(inspectorCard.Root);
        }

        private static void ApplyStyleSheets(VisualElement root) =>
            ApplyStyleSheets(root, TokensStyleSheetResourceName, WorkspaceStyleSheetResourceName);

        /// <summary>
        /// Loads and attaches the two frozen USS resources by name, taking the
        /// resource name as a parameter purely so an EditMode test can prove
        /// the failure path (a missing/renamed asset) logs loudly rather than
        /// silently rendering an unstyled panel — "honest failure beats
        /// silence" per this workspace's own design law. The two production
        /// call sites always go through the no-argument overload above, which
        /// is pinned to the real frozen resource names.
        /// </summary>
        internal static void ApplyStyleSheets(VisualElement root, string tokensResourceName, string workspaceResourceName)
        {
            var tokens = Resources.Load<StyleSheet>(tokensResourceName);
            if (tokens != null)
            {
                root.styleSheets.Add(tokens);
            }
            else
            {
                Debug.LogError(
                    $"[StudioWorkspaceHost] StyleSheet '{tokensResourceName}' failed to load from Resources — " +
                    "the Casting workspace will render with no design tokens (no colors, spacing, or type scale).");
            }

            var workspace = Resources.Load<StyleSheet>(workspaceResourceName);
            if (workspace != null)
            {
                root.styleSheets.Add(workspace);
            }
            else
            {
                Debug.LogError(
                    $"[StudioWorkspaceHost] StyleSheet '{workspaceResourceName}' failed to load from Resources — " +
                    "the Casting workspace will render with no cosmetic styling at all.");
            }
        }

        private const string TokensStyleSheetResourceName = "StudioUiTokens";
        private const string WorkspaceStyleSheetResourceName = "StudioCastingWorkspace";

        private void ApplyOpenVisualState()
        {
            if (scrim != null) scrim.style.display = DisplayStyle.Flex;
            if (castingWorkspace != null) castingWorkspace.Root.style.display = DisplayStyle.Flex;
        }

        private void ApplyClosedVisualState()
        {
            if (scrim != null) scrim.style.display = DisplayStyle.None;
            if (castingWorkspace != null) castingWorkspace.Root.style.display = DisplayStyle.None;
        }

        /// <summary>Looks up the open project's fresh snapshot and rebinds the workspace to it.</summary>
        private void BindCastingWorkspace()
        {
            if (castingWorkspace == null) return;
            var project = FindProject(CastingBoard(), retainedContext?.ProjectId);
            castingWorkspace.Bind(retainedContext, project, CastingBoard()?.capacityLine);
            castingWorkspace.BindExpiryNotices(CastingBoard()?.expiryNotices);
        }

        private StudioCastingBoardSnapshot CastingBoard() => client?.Current?.snapshot?.casting?.casting?.board;

        private static StudioCastingProjectSnapshot FindProject(StudioCastingBoardSnapshot board, string projectId)
        {
            if (board?.projects == null || string.IsNullOrEmpty(projectId)) return null;
            for (var index = 0; index < board.projects.Length; index++)
                if (board.projects[index] != null &&
                    string.Equals(board.projects[index].projectId, projectId, StringComparison.Ordinal))
                    return board.projects[index];
            return null;
        }

        /// <summary>
        /// P04A Wave 3: the smallest read of StudioBridgePresentation's body
        /// join — resolves a talentId to a world stableId only while it is
        /// CURRENTLY bound to a live authoritative body, else null (never
        /// guesses, never falls back to a stale id).
        /// </summary>
        private string ResolveLocateStableId(string talentId)
        {
            if (presentation == null) presentation = FindFirstObjectByType<StudioBridgePresentation>();
            if (presentation == null) return null;
            return presentation.TryGetAuthoritativePersonStableId(talentId, out var stableId) ? stableId : null;
        }

        /// <summary>
        /// Recomputes visibility for the world-entry card. Called every frame
        /// (selection can change without any snapshot event) and again on
        /// every snapshot refresh. The card is suppressed while the full
        /// workspace is open — the two right-anchored surfaces never compete
        /// for the same pixels — and while suspended for a Locate round trip.
        /// </summary>
        private void RefreshInspectorCardVisibility()
        {
            if (inspectorCard == null) return;
            if (selectionManager == null) selectionManager = FindFirstObjectByType<StudioSelectionManager>();
            var selected = selectionManager != null ? selectionManager.Selected : null;
            var isCastingSelection = selected != null &&
                string.Equals(selected.StableId, StudioCastingInspectorCard.CastingBuildingStableId, StringComparison.Ordinal) &&
                !workspaceOpen && !suspendedForLocate;
            inspectorCard.Evaluate(isCastingSelection, CastingBoard());
        }

        /// <summary>
        /// P04A: USABLE means the host is installed+functional (true simply
        /// by virtue of this method running) AND the casting projection
        /// publishes a non-null board — i.e. the world path to Casting
        /// exists. NOT merely while the workspace happens to be open; mirrors
        /// StudioLivingTimeHud's SetWorldTimeOwnerPresent contract one level
        /// up (fail closed toward playability: no declared owner ⇒ the memo
        /// keeps its classic manual casting verbs).
        /// </summary>
        private void EvaluateCastingOwnerPresence()
        {
            if (client == null) return;
            client.SetCastingOwnerPresent(CastingBoard() != null);
        }

        private void SubscribeClientSnapshots()
        {
            if (client == null) client = GetComponent<StudioBridgeClient>();
            if (client == null) client = FindFirstObjectByType<StudioBridgeClient>();
            if (client == null || subscribedToClientSnapshots) return;
            client.SnapshotApplied += OnSnapshotApplied;
            subscribedToClientSnapshots = true;
        }

        private void UnsubscribeClientSnapshots()
        {
            if (!subscribedToClientSnapshots || client == null) return;
            client.SnapshotApplied -= OnSnapshotApplied;
            subscribedToClientSnapshots = false;
        }

        // ── P04A Wave 4: screen-test quote/commit/acknowledge plumbing ───────
        //
        // The workspace controller never touches the network itself (proven
        // by its own source-text test); every one of these six methods is a
        // thin wrapper the workspace reaches only through the delegates
        // Configure wires, exactly like ResolveLocateStableId/SuspendForLocate
        // already are for the Locate seam.

        private void SubscribeCastingQuoteEvents()
        {
            if (client == null) client = GetComponent<StudioBridgeClient>();
            if (client == null) client = FindFirstObjectByType<StudioBridgeClient>();
            if (client == null || subscribedToCastingQuoteEvents) return;
            client.CastingQuoteAccepted += OnCastingQuoteAccepted;
            client.CastingQuoteRejected += OnCastingQuoteRejected;
            client.CastingQuoteUnresolved += OnCastingQuoteUnresolved;
            // Wave 6: the greenlight COMMIT (not the quote ask) rides the
            // generic command lifecycle every ordinary intent submission
            // already uses — the same two events StudioDevelopmentCardHud
            // subscribes for its own commission/accept/rewrite commits.
            client.CommandAccepted += OnGreenlightCommandAccepted;
            client.CommandRejected += OnGreenlightCommandRejected;
            subscribedToCastingQuoteEvents = true;
        }

        private void UnsubscribeCastingQuoteEvents()
        {
            if (!subscribedToCastingQuoteEvents || client == null) return;
            client.CastingQuoteAccepted -= OnCastingQuoteAccepted;
            client.CastingQuoteRejected -= OnCastingQuoteRejected;
            client.CastingQuoteUnresolved -= OnCastingQuoteUnresolved;
            client.CommandAccepted -= OnGreenlightCommandAccepted;
            client.CommandRejected -= OnGreenlightCommandRejected;
            subscribedToCastingQuoteEvents = false;
        }

        private void OnCastingQuoteAccepted(StudioBridgeQuoteResponse quoted)
        {
            castingWorkspace?.HandleScreenTestQuoteAccepted(quoted);
            castingWorkspace?.HandleGreenlightQuoteAccepted(quoted);
        }

        private void OnCastingQuoteRejected(StudioBridgeRejectedResponse rejected)
        {
            castingWorkspace?.HandleScreenTestQuoteRejected(rejected);
            castingWorkspace?.HandleGreenlightQuoteRejected(rejected);
        }

        private void OnCastingQuoteUnresolved(string message)
        {
            castingWorkspace?.HandleScreenTestQuoteUnresolved(message);
            castingWorkspace?.HandleGreenlightQuoteUnresolved(message);
        }

        /// <summary>
        /// CommandAccepted fires for EVERY accepted command in the whole
        /// game and carries no commandId of its own (mirrors
        /// StudioDevelopmentCardHud.OnCommandAccepted exactly) — safe only
        /// because the wider post lifecycle is single-flight: the next
        /// acceptance while we have a pending greenlight commandId can only
        /// be ours.
        /// </summary>
        private void OnGreenlightCommandAccepted(StudioBridgeSnapshotResponse response)
        {
            if (response == null || pendingGreenlightCommandId == null) return;
            pendingGreenlightCommandId = null;
            castingWorkspace?.HandleGreenlightCommitAccepted(response);
        }

        private void OnGreenlightCommandRejected(StudioBridgeRejectedResponse rejected)
        {
            if (rejected == null || pendingGreenlightCommandId == null) return;
            if (rejected.commandId != pendingGreenlightCommandId) return;
            pendingGreenlightCommandId = null;
            castingWorkspace?.HandleGreenlightCommitRejected(rejected);
        }

        /// <summary>Mirrors CommitScreenTestQuote's dispatch, plus an explicit tracked commandId so the accept/reject events above can be attributed to THIS commit.</summary>
        private bool CommitGreenlightQuote(StudioQuoteSnapshot quote)
        {
            if (client == null || !client.ActionsEnabled || quote == null) return false;
            if (!(quote is StudioCastingQuoteSnapshot casting) || casting.kind != StudioCastingQuoteSnapshotKindValues.GreenlightPicture) return false;
            var commandId = Guid.NewGuid().ToString("N");
            var dispatched = client.SubmitIntent(new StudioBridgeIntentOption
            {
                intentId = quote.intentId,
                kind = casting.kind,
                label = quote.commitLabel,
                detail = string.Empty,
                projectId = null,
                castingSessionId = null,
                productionId = null,
            }, false, commandId);
            if (dispatched) pendingGreenlightCommandId = commandId;
            return dispatched;
        }

        /// <summary>The live productions list, read fresh at greenlight-commit time only to corroborate the receipt's "formed" verification.</summary>
        private StudioProductionSnapshot[] CurrentActiveProductions() =>
            client?.Current?.snapshot?.productions?.activeProductions ?? Array.Empty<StudioProductionSnapshot>();

        private string RequestScreenTestQuote(StudioCastingDraftPayload draft) =>
            client?.RequestCastingQuote(draft);

        private bool IsScreenTestQuoteInFlight() => client != null && client.CastingQuoteInFlight;

        private int? LiveStateRevision() => client?.Current?.stateRevision;

        private bool AreScreenTestActionsEnabled() => client != null && client.ActionsEnabled;

        /// <summary>Mirrors StudioDevelopmentCardHud.CommitCommission's dispatch exactly: echo the quoted intentId/kind/label, nothing else.</summary>
        private bool CommitScreenTestQuote(StudioQuoteSnapshot quote)
        {
            if (client == null || !client.ActionsEnabled || quote == null) return false;
            if (!(quote is StudioCastingQuoteSnapshot casting) || casting.kind != StudioCastingQuoteSnapshotKindValues.StartAuditions) return false;
            return client.SubmitIntent(new StudioBridgeIntentOption
            {
                intentId = quote.intentId,
                kind = casting.kind,
                label = quote.commitLabel,
                detail = string.Empty,
                projectId = null,
                castingSessionId = null,
                productionId = null,
            });
        }

        /// <summary>Mirrors StudioDevelopmentCardHud's FindReviewOption: locate the live acknowledgeAuditions option for this exact project, then submit it.</summary>
        private bool AcknowledgeReview(string projectId)
        {
            if (client == null || !client.ActionsEnabled) return false;
            var option = FindCastingIntent(StudioBridgeIntentOptionKindValues.AcknowledgeAuditions, projectId);
            if (option == null) return false;
            return client.SubmitIntent(option);
        }

        private StudioBridgeIntentOption FindCastingIntent(string kind, string projectId)
        {
            var options = client?.Current?.availableIntents;
            if (options == null) return null;
            foreach (var option in options)
            {
                if (option == null) continue;
                if (!string.Equals(option.kind, kind, StringComparison.Ordinal)) continue;
                if (option.projectId != null && option.projectId != projectId) continue;
                return option;
            }
            return null;
        }

        /// <summary>
        /// The ONE snapshot-refresh entry point: re-declares casting-owner
        /// presence, refreshes the world-entry card, and — while the
        /// workspace is open — rebinds it to the SAME projectId's fresh data,
        /// preserving the retained role/candidate selection wherever the new
        /// board still supports it (StudioCastingWorkspace.Bind's job) and
        /// closing cleanly, without throwing, if the open project left the
        /// board entirely. Never touches the camera.
        /// </summary>
        private void OnSnapshotApplied(StudioBridgeSnapshotResponse response)
        {
            EvaluateCastingOwnerPresence();
            RefreshInspectorCardVisibility();
            if (!workspaceOpen) return;

            var project = FindProject(CastingBoard(), retainedContext?.ProjectId);
            // Wave 6: a FORMED greenlight commit removes its project from the
            // casting board entirely (its casting job is done — it becomes a
            // production) the instant this very snapshot lands, which can
            // arrive BEFORE the matching CommandAccepted event that resolves
            // the receipt (ApplySnapshot fires SnapshotApplied synchronously
            // ahead of CommandAccepted in StudioBridgeClient). Never treat
            // that disappearance as "the project left the board for some
            // other reason" while a greenlight commit THIS workspace itself
            // submitted is still in flight or already showing a receipt.
            var greenlightInProgress = pendingGreenlightCommandId != null || (castingWorkspace?.GreenlightCommitPending ?? false);
            if (project == null && !greenlightInProgress)
            {
                CloseWorkspace();
                return;
            }
            castingWorkspace?.Bind(retainedContext, project, CastingBoard()?.capacityLine);
            castingWorkspace?.BindExpiryNotices(CastingBoard()?.expiryNotices);
        }

        private static void EnsureEventSystem()
        {
            var eventSystem = FindFirstObjectByType<EventSystem>();
            if (eventSystem == null)
            {
                var eventSystemObject = new GameObject("StudioWorkspaceEventSystem");
                eventSystem = eventSystemObject.AddComponent<EventSystem>();
            }

            var inputModule = eventSystem.GetComponent<InputSystemUIInputModule>();
            if (inputModule == null)
            {
                inputModule = eventSystem.gameObject.AddComponent<InputSystemUIInputModule>();
                AssignWorkspaceInputActions(inputModule);
            }
        }

        private static void AssignWorkspaceInputActions(InputSystemUIInputModule inputModule)
        {
#if UNITY_EDITOR
            // Assets/InputSystem_Actions.inputactions is the template asset's
            // UI action map (Navigate/Submit/Cancel/Point/Click/ScrollWheel)
            // — exactly the shape InputSystemUIInputModule wants. It is not
            // Resources-loadable (it lives outside any Resources folder), so
            // in-Editor contexts (Editor Play Mode, EditMode/PlayMode tests)
            // load it via AssetDatabase. A standalone Player build has no
            // AssetDatabase and falls back to the Input System package's own
            // built-in default UI actions below.
            var projectActions = UnityEditor.AssetDatabase.LoadAssetAtPath<UnityEngine.InputSystem.InputActionAsset>(
                "Assets/InputSystem_Actions.inputactions");
            if (projectActions != null)
            {
                inputModule.actionsAsset = projectActions;
                return;
            }
#endif
            inputModule.AssignDefaultActions();
        }
    }
}
