# Continued production identity controls R4

KEEP additive control delta, UNRUN. Posta99540fa75027c3d98dc0049e8b65bd8fa8d12bc57d468c43b1b15d0e1042bd1/DELTAafb3f52ee88c5f7cd47e387411ba2e513625ef50afc4bba3528a54a12166328e; all artifact hashes verified/pre443a8b3 preserved.

Positive real final journey requires default persistedProductionIds reserve the actual foreign film ID without changing caller bytes. This establishes reservation in the actual full state; it does not individually prove every observation contributes to the set. Actual duplicated creator film body, after fully admitted positive, must fail full49 at precise duplicate film identity while preserving mutated caller bytes. Hollywood film-loop uniqueness independently rejects the duplicate even though its exact buyer observations are eligible for reader attribution joins.

The only helper addition is optional exact expectedPattern for this duplicate; other mutations/default category remain unchanged. No positive fabricated film, sourceprefix exemption or allocator replacement. All prior public fixed journey/replay/firsttake/Standing/title/cash/hostile/rollback assertions retained; same3names/default5s/setupinside. Original duplicate failures remain preserved; positive and hostile post-fix budgets remain unmeasured. No runtime or K/R edits.
