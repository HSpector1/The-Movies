# Bridge61 readback named-union repair — STATIC / UNRUN

Generatorr2 session5320 failed CF08-ANONYMOUS-MEMBER at StudioPaidReportSubject/anyOf/0 in industry-schema.ts; fixture generator unstarted. Original r1/r2 failures remain. Earlier bridge-schema inspection omitted industry readback; its no-further-pattern conclusion was incomplete.

One-file repair lifts four existing closed object members into named constants, references them in StudioPaidReportTarget and StudioPaidReportSubject, and registers all four in industryDefinitions. Exact studio/estateLot targets and R1/propertyId vs R2/filmId subjects keep tags, required keys, string rules, closed validation and order. No data fields, policy, source emitter or generated files changed. The two target member classes stay distinct from diligence request classes, preserving one-union-per-class inheritance.

UNION-INSPECTION.json enumerates every union in all changed61 schema files obtained from the actual combined source manifest (bridge-schema, industry-schema, intent-schema), with proposed industry postimage. All now have named reference members; canonical top-level oneOf also uses local refs. Nullable schema/null pairs are ordinary nullable fields, not discriminated object union members. Nested paid body ordinary object properties remain unchanged. No future schemaId/hash is guessed; canonical generation must measure actual outputs.

Actual181r2 preimage declared package equality checked. Parent owns audit, source installation, successor package/bootstrap binding and canonical generation. No K/R/index edits, compiler, tests, generator or preflight by author. Required next evidence remains both canonical generators succeeding with all nonoutput source/index/input guards intact, followed by coherent gate.

Reusable correction: inspect the complete changed schema file set, including readback definitions, rather than only the canonical request schema entry file.
