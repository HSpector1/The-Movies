# Current61 root type correction — STATIC / UNRUN

Actual integration root exit2/48s: duplicate Production import rights.ts1/32 and narrower continuedReception.records.includes(rec) tick864. Remove only redundant Production import; same original type import retained atline1.

The existing ReleaseRecord contains filmResult/benchmarks/ctx plus broadcast/develop, whereas actual continued Standing records have only firstthree. Honest local Pick<ReleaseRecord,filmResult|benchmarks|ctx>[] aliases the same real returned array, types the combined Standing collection and supplies includes receiver. No copied array for the alias, cast, invented growth record, changed required participant, original global type or source validator relaxation. Real sort/map/includes/Standing/receipts remain unchanged; alias carries same object identities. Tests/source runtime branches unchanged.

No K/R/index edits, compiler/tests/runtime by author. Parent preserves failed root/currentrun, owns post-terminal installation/recorded qualification. Resume native source compatibility work separately after delivery.

R2 adds only measured UI2/90s schema diagnostic: string-only enumeration([0,1]) incorrectly formed numeric policy enum under type:string. Existing nullable(integer({minimum:0,maximum:1})) is the exact numeric null/0/1 domain: rejects fractions, outside integers, strings and booleans without DSL/emitter changes. Existing integer imported. This corrects the intended paid receipt policy storage; all otherfields unchanged. Previous measured61 generationr4 retained as superseded; canonical JSON/C#/manifest/fixtures MUST regenerate before another coherentgate. No manual generated patch or protocol/version gameplay change. Native successor drafting deferred until actual canonical shape final.
