import pathlib,json,hashlib,subprocess,sys,datetime
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16');old,delta,new,review=sys.argv[1:];old=A/old;delta=A/delta;new=A/new;review=A/review
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
def git(*a):return subprocess.check_output(g+list(a))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert not (A.parent/'HEAVY-LANE-LOCK').exists();assert review.is_file() and 'KEEP' in review.read_text();assert not new.exists()
assert git('diff','--cached','--binary')==(old/'PATCH.diff').read_bytes();assert set(git('diff','--name-only').decode().splitlines())<={'HANDOFF.md'}
m=json.loads((old/'MANIFEST.json').read_text())
for f in m['files']:assert sha(K/f['path'])==f['sha256'] and oct((K/f['path']).stat().st_mode&0o777)==f['mode']
d=json.loads((delta/'MANIFEST.json').read_text())
for f in d['files']:assert sha(K/f['path'])==f.get('preimageSHA256',f.get('preimageSha256'))
subprocess.run(g+['apply','--check','--index',str(delta/'SOURCE.patch')],check=True);subprocess.run(g+['apply','--index',str(delta/'SOURCE.patch')],check=True)
for f in d['files']:assert sha(K/f['path'])==f.get('postimageSHA256',f.get('postimageSha256'))
new.mkdir();(new/'PATCH.diff').write_bytes(git('diff','--cached','--binary'))
for f in m['files']:
 q=K/f['path'];f.update(sha256=sha(q),bytes=q.stat().st_size,mode=oct(q.stat().st_mode&0o777));assert hashlib.sha256(git('show',':'+f['path'])).hexdigest()==f['sha256']
m.update(at=datetime.datetime.now().astimezone().isoformat(),scope='Reviewed source correction; pending actual canonical generation and coherent verification')
(new/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
r=dict(package=str(new),patchSHA256=sha(new/'PATCH.diff'),manifestSHA256=sha(new/'MANIFEST.json'),pathCount=len(m['files']),deltaPatchSHA256=sha(delta/'SOURCE.patch'),deltaManifestSHA256=sha(delta/'MANIFEST.json'),review=str(review),reviewSHA256=sha(review),changedOnly=d['files'])
(new/'INSTALL-RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');subprocess.run(g+['diff','--check','--cached'],check=True);print(json.dumps(r))
