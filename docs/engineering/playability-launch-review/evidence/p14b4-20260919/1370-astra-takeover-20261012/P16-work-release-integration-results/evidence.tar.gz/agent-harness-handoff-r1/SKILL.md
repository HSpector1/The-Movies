---
name: handoff
description: Write or resume from HANDOFF.md so Claude and Codex can take over each other's work cold. Use when the user says handoff, hand off, resume, switch to Codex/Claude, "pick up where it left off", when a HANDOFF TRIGGER usage warning appears, or before a session ends with work in flight.
---

# Handoff

HANDOFF.md at the repo root is the single source of truth for who is working, on what, from which commit. Claude and Codex both read and write it. Chat summaries and zip packets do not replace it.

## Mode 1: write (handoff)

Run at every checkpoint commit, when a HANDOFF TRIGGER appears, when the user signals a stop (shutdown, outage, leaving), and before you expect the session to end.

1. Reach a safe point. Check the recorded run and project write lock before editing. While a run freezes HANDOFF/source/index, keep its files unchanged and retain a continuation note outside the frozen scope with PID, log and exact next action; update HANDOFF after the run and required reconciliation finish.
2. Update the current state and existing remaining-requirements list from verified evidence; replace stale next steps. Preserve original failures and historical acceptance limits. Distinguish compilation, reached assertions, timing budgets, technical landing and player acceptance. Record substantive lessons with the failure, correction, measured outcome and evidence pointer; link the lessons section near the top.
3. Leave the `AUTO` block alone. `handoff_guard.py` stamps it on session end and compaction.
4. At the safe checkpoint, commit recoverable work/evidence and HANDOFF, and push within the existing authorization. Verify the explicit remote URL and branch ref; a stale tracking ref is insufficient. If writes are frozen, defer them without interrupting the run. Never reset, stash, clean or discard newer work to create a handoff.
5. Tell the user in one line: handoff written, commit SHA, next step.

## Mode 2: read (resume)

1. Read the current section of HANDOFF.md and its exact next action first. Inspect any named run/lock read-only before Git mutations or dispatch. At a safe point, fetch the explicit recorded remote/ref with repository Git flags, then read the relevant AGENTS.md/CLAUDE.md and required evidence. Expand historical sections only for the active requirement.
2. Verify before acting: branch and HEAD match "Where the work is"; the remote has no newer commits (if it does, keep them and report); every listed running job is still alive or finished (check the logs).
3. Report any mismatch in one short block, then continue from "Next step". Do not restart planning or reopen anything under "Closed".
4. Set "Last writer" at the first safe checkpoint. Resume completed specialists with the tool that starts a new turn; messaging an idle agent alone may not restart it. Preserve the chosen models and single execution lane. Reuse accepted inputs/results; do not reopen closed cleanup, hydrate archives for status, or retry an unchanged failed preflight.

## Shared hook

`~/.claude/hooks/handoff_guard.py` serves Claude and Codex; the Codex skill may be a symlink to this shared skill. Read-only Git uses disabled automatic maintenance and optional locks. Optional `~/.claude/state/handoff_guard_projects.json` (version1; projects with absolute `roots` and `writeBlockers`) defers AUTO writes while a configured lock exists. The hook never clears locks or launches work; deferrals are logged in `~/.claude/state/handoff_guard.log`. A later safe snapshot records current state. Snapshot replacement is atomic, but its final check and replacement are not one compare-and-swap operation: require a quiescent writer boundary and keep the parent responsible for coordinating concurrent writers. Keep hook trust and usage thresholds intact; never manufacture trust hashes or weaken run guards.

## Template

```markdown
# HANDOFF

Last writer: <Claude | Codex> (<model>), <date from `date`>

## Where the work is
- Repo / branch / HEAD: <branch> @ <full sha>, pushed: <yes | no, why>
- Required reading, in order: <files>

## Active order
- Governing Owner order: <name + file or record id>
- In scope: <bounded list>
- Closed, do not reopen: <list>

## State
- Done this session: <verified results with evidence: test counts, commits>
- In flight: <running jobs: PID, command, log path, expected finish>
- Claims limits: <what is measured versus reasoned but unmeasured>

## Next step
<exact next action, specific enough to execute without asking>

## Open decisions for the Owner
- <question>: recommend <X> because <reason>

## Blockers and warnings
- <anything that will bite the next agent>

## Auto snapshot
<!-- AUTO:BEGIN (handoff_guard.py rewrites this block) -->
<!-- AUTO:END -->
```
