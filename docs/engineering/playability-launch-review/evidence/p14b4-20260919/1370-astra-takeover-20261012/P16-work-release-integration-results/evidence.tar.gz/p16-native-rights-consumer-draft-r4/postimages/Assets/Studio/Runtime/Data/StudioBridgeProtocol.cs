using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace Studio.Runtime.Data
{
    public static partial class StudioBridgeContract
    {
        public static void RequireProtocolCompatible(int protocolVersion, string schemaId)
        {
            if (protocolVersion != ProtocolVersion)
                throw new StudioSnapshotFormatException(
                    $"Bridge protocol mismatch: expected {ProtocolVersion}, received {protocolVersion}.");
            if (!string.Equals(schemaId, SchemaId, StringComparison.Ordinal))
                throw new StudioSnapshotFormatException(
                    $"Bridge schema mismatch: expected {SchemaId}, received {schemaId ?? "<null>"}.");
        }
    }

    public sealed partial class StudioBridgeHealthResponse
    {
        public void NormalizeAndValidate()
        {
            StudioBridgeHandshakeResponseValidation.NormalizeAndValidate(
                protocolVersion,
                schemaId,
                snapshotVersion,
                runtimeInstanceId,
                sessionId,
                stateRevision,
                gameWeek,
                stateDigest);
            if (!string.Equals(status, StudioBridgeHealthResponseStatusValues.Ok, StringComparison.Ordinal))
                throw new StudioSnapshotFormatException(
                    $"Bridge health status must be {StudioBridgeHealthResponseStatusValues.Ok}, received {status ?? "<null>"}.");
        }
    }

    public sealed partial class StudioBridgeSessionResponse
    {
        public void NormalizeAndValidate()
        {
            StudioBridgeHandshakeResponseValidation.NormalizeAndValidate(
                protocolVersion,
                schemaId,
                snapshotVersion,
                runtimeInstanceId,
                sessionId,
                stateRevision,
                gameWeek,
                stateDigest);
        }
    }

    public sealed partial class StudioBridgeSnapshotResponse
    {
        public void NormalizeAndValidate()
        {
            StudioBridgeResponseValidation.NormalizeAndValidate(
                protocolVersion,
                schemaId,
                snapshotVersion,
                sessionId,
                stateRevision,
                gameWeek,
                stateDigest,
                snapshot,
                ref availableIntents,
                metrics);
        }
    }

    public sealed partial class StudioBridgeAcceptedCommandResponse
    {
        public void NormalizeAndValidate()
        {
            if (!accepted)
                throw new StudioSnapshotFormatException("Bridge accepted-command response did not accept the command.");
            if (string.IsNullOrWhiteSpace(commandId))
                throw new StudioSnapshotFormatException("Bridge accepted-command response has no commandId.");
            if (processingMs < 0d)
                throw new StudioSnapshotFormatException("Bridge accepted-command processingMs cannot be negative.");
            var snapshotResponse = ToSnapshotResponse();
            snapshotResponse.NormalizeAndValidate();
            availableIntents = snapshotResponse.availableIntents;
        }

        public StudioBridgeSnapshotResponse ToSnapshotResponse() => new StudioBridgeSnapshotResponse
        {
            protocolVersion = protocolVersion,
            schemaId = schemaId,
            snapshotVersion = snapshotVersion,
            sessionId = sessionId,
            stateRevision = stateRevision,
            gameWeek = gameWeek,
            stateDigest = stateDigest,
            snapshot = snapshot,
            founding = founding,
            treasury = treasury,
            availableIntents = availableIntents,
            metrics = metrics,
        };
    }

    public sealed partial class StudioBridgeSaveResponse
    {
        public void NormalizeAndValidate()
        {
            StudioBridgeContract.RequireProtocolCompatible(protocolVersion, schemaId);
            if (!accepted) throw new StudioSnapshotFormatException("Bridge save response was not accepted.");
            if (string.IsNullOrWhiteSpace(sessionId)) throw new StudioSnapshotFormatException("Bridge save sessionId is missing.");
            if (string.IsNullOrWhiteSpace(commandId)) throw new StudioSnapshotFormatException("Bridge save commandId is missing.");
            if (stateRevision < 0) throw new StudioSnapshotFormatException("Bridge save revision cannot be negative.");
            if (string.IsNullOrWhiteSpace(stateDigest)) throw new StudioSnapshotFormatException("Bridge save digest is missing.");
            if (string.IsNullOrWhiteSpace(saveJson)) throw new StudioSnapshotFormatException("Bridge save payload is missing.");
        }
    }

    /// <summary>Accepted current tagged quote. Canonical wire validation and generated member
    /// discriminators own each family's fields; envelope and inherited family checks remain here.</summary>
    public sealed partial class StudioBridgeQuoteResponse
    {
        // The canonical converter owns the tagged family. No flattened base-kind or shadow DTO.
        public static string QuoteKind(StudioQuoteSnapshot value)
        {
            if (value is StudioCommissionQuoteSnapshot memberCommission) return memberCommission.kind;
            if (value is StudioCastingQuoteSnapshot memberCasting) return memberCasting.kind;
            if (value is StudioContractQuoteSnapshot memberContract) return memberContract.kind;
            if (value is StudioDiligenceQuoteSnapshot memberDiligence) return memberDiligence.kind;
            if (value is StudioAbsorptionQuoteSnapshot memberAbsorption) return memberAbsorption.kind;
            if (value is StudioLoanQuoteSnapshot memberLoan) return memberLoan.kind;
            if (value is StudioMarketProposalQuoteSnapshot memberMarketProposal) return memberMarketProposal.kind;
            if (value is StudioPlacementQuoteSnapshot memberPlacement) return memberPlacement.kind;
            if (value is StudioPromiseWaiverQuoteSnapshot memberPromiseWaiver) return memberPromiseWaiver.kind;
            if (value is StudioSetCommissionQuoteSnapshot memberSetCommission) return memberSetCommission.kind;
            throw new StudioSnapshotFormatException("Bridge quote has an unknown canonical member.");
        }

        public void NormalizeAndValidate()
        {
            StudioBridgeContract.RequireProtocolCompatible(protocolVersion, schemaId);
            if (!accepted) throw new StudioSnapshotFormatException("Bridge quote response was not accepted.");
            if (string.IsNullOrWhiteSpace(sessionId)) throw new StudioSnapshotFormatException("Bridge quote sessionId is missing.");
            if (string.IsNullOrWhiteSpace(commandId)) throw new StudioSnapshotFormatException("Bridge quote commandId is missing.");
            if (stateRevision < 0) throw new StudioSnapshotFormatException("Bridge quote revision cannot be negative.");
            if (string.IsNullOrWhiteSpace(stateDigest)) throw new StudioSnapshotFormatException("Bridge quote digest is missing.");
            if (quote == null) throw new StudioSnapshotFormatException("Bridge quote payload is missing.");
            if (string.IsNullOrWhiteSpace(quote.intentId)) throw new StudioSnapshotFormatException("Bridge quote intentId is missing.");
            if (string.IsNullOrWhiteSpace(QuoteKind(quote))) throw new StudioSnapshotFormatException("Bridge quote kind is missing.");
            if (string.IsNullOrWhiteSpace(quote.commitLabel)) throw new StudioSnapshotFormatException("Bridge quote commit label is missing.");
            if (quote is StudioCommissionQuoteSnapshot commission)
            {
                if (string.IsNullOrWhiteSpace(commission.consequence))
                    throw new StudioSnapshotFormatException("Bridge commission quote consequence is missing.");
            }
            else if (quote is StudioCastingQuoteSnapshot casting &&
                (casting.kind == StudioCastingQuoteSnapshotKindValues.StartAuditions ||
                 casting.kind == StudioCastingQuoteSnapshotKindValues.GreenlightPicture))
            {
                if (string.IsNullOrWhiteSpace(casting.projectId))
                    throw new StudioSnapshotFormatException("Bridge casting quote projectId is missing.");
                if (string.IsNullOrWhiteSpace(casting.title))
                    throw new StudioSnapshotFormatException("Bridge casting quote title is missing.");
            }
            // Every other exact generated member is already closed/required-field validated by
            // ParseQuoteResponse's canonical WireValidator before this envelope normalization.
        }
    }

    public sealed partial class StudioBridgeRejectedResponse
    {
        public void NormalizeAndValidate()
        {
            StudioBridgeContract.RequireProtocolCompatible(protocolVersion, schemaId);
            if (accepted) throw new StudioSnapshotFormatException("Bridge rejection response was marked accepted.");
            if (string.IsNullOrWhiteSpace(sessionId)) throw new StudioSnapshotFormatException("Bridge rejection sessionId is missing.");
            if (string.IsNullOrWhiteSpace(reasonCode)) throw new StudioSnapshotFormatException("Bridge rejection reasonCode is missing.");
            if (string.IsNullOrWhiteSpace(message)) throw new StudioSnapshotFormatException("Bridge rejection message is missing.");
            if (string.IsNullOrWhiteSpace(stateDigest)) throw new StudioSnapshotFormatException("Bridge rejection digest is missing.");
            if (stateRevision < 0) throw new StudioSnapshotFormatException("Bridge rejection revision cannot be negative.");
            if (processingMs < 0d) throw new StudioSnapshotFormatException("Bridge rejection processingMs cannot be negative.");
            if (rejection == null) throw new StudioSnapshotFormatException("Bridge rejection guidance is missing.");
            if (string.IsNullOrWhiteSpace(rejection.category))
                throw new StudioSnapshotFormatException("Bridge rejection category is missing.");
            if (string.IsNullOrWhiteSpace(rejection.blocker))
                throw new StudioSnapshotFormatException("Bridge rejection blocker is missing.");
            if (rejection.currentHolder != null && string.IsNullOrWhiteSpace(rejection.currentHolder))
                throw new StudioSnapshotFormatException("Bridge rejection currentHolder is empty.");
            if (string.IsNullOrWhiteSpace(rejection.remedy))
                throw new StudioSnapshotFormatException("Bridge rejection remedy is missing.");
        }
    }

    internal static class StudioBridgeResponseValidation
    {
        public static void NormalizeAndValidate(
            int protocolVersion,
            string schemaId,
            int snapshotVersion,
            string sessionId,
            int stateRevision,
            int gameWeek,
            string stateDigest,
            StudioProjectionBundle snapshot,
            ref StudioBridgeIntentOption[] availableIntents,
            StudioBridgeMetrics metrics)
        {
            StudioBridgeContract.RequireCompatible(protocolVersion, schemaId, snapshotVersion);
            if (string.IsNullOrWhiteSpace(sessionId)) throw new StudioSnapshotFormatException("Bridge sessionId is missing.");
            if (stateRevision < 0) throw new StudioSnapshotFormatException("Bridge stateRevision cannot be negative.");
            if (snapshot == null) throw new StudioSnapshotFormatException("Bridge snapshot is missing.");
            snapshot.Normalize();
            if (snapshot.lot == null || snapshot.productions == null || snapshot.people == null ||
                snapshot.construction == null || snapshot.journeyNotices == null || snapshot.releaseResults == null ||
                snapshot.development == null || snapshot.development.development == null ||
                snapshot.casting == null || snapshot.casting.casting == null)
                throw new StudioSnapshotFormatException("Bridge projection bundle is incomplete.");
            ValidateLocationIdentities(snapshot.lot, snapshot.productions, snapshot.construction);
            if (gameWeek != snapshot.lot.week)
                throw new StudioSnapshotFormatException(
                    $"Bridge gameWeek {gameWeek} disagrees with lot projection week {snapshot.lot.week}.");
            if (snapshot.construction.placement == null)
                throw new StudioSnapshotFormatException("Bridge construction placement projection is missing.");
            if (gameWeek != snapshot.construction.placement.currentWeek)
                throw new StudioSnapshotFormatException(
                    $"Bridge gameWeek {gameWeek} disagrees with construction projection week " +
                    $"{snapshot.construction.placement.currentWeek}.");
            if (snapshot.people.presence != null && gameWeek != snapshot.people.presence.week)
                throw new StudioSnapshotFormatException(
                    $"Bridge gameWeek {gameWeek} disagrees with people presence week {snapshot.people.presence.week}.");
            if (snapshot.journeyNotices.weekTheater != null && gameWeek != snapshot.journeyNotices.weekTheater.week)
                throw new StudioSnapshotFormatException(
                    $"Bridge gameWeek {gameWeek} disagrees with journey theater week " +
                    $"{snapshot.journeyNotices.weekTheater.week}.");
            if (string.IsNullOrWhiteSpace(stateDigest))
                throw new StudioSnapshotFormatException("Bridge stateDigest is missing.");
            if (metrics == null) throw new StudioSnapshotFormatException("Bridge metrics are missing.");
            availableIntents ??= Array.Empty<StudioBridgeIntentOption>();
            for (var index = 0; index < availableIntents.Length; index++)
            {
                var option = availableIntents[index];
                if (option == null || string.IsNullOrWhiteSpace(option.intentId) ||
                    string.IsNullOrWhiteSpace(option.kind) || string.IsNullOrWhiteSpace(option.label))
                    throw new StudioSnapshotFormatException($"Bridge availableIntents[{index}] is incomplete.");
            }
        }

        private static void ValidateLocationIdentities(
            StudioLotProjection lot,
            StudioProductionsProjection productions,
            StudioConstructionProjection construction)
        {
            AddBuildingIds(lot.buildings, "$.snapshot.lot.buildings");
            if (lot.property == null)
                throw new StudioSnapshotFormatException("$.snapshot.lot.property is null.");
            var propertyBuildingIds = AddPropertyBuildingIds(
                lot.property.buildings,
                "$.snapshot.lot.property.buildings");
            ValidateConstructionLocationIdentities(lot.property, construction);

            var stageBuildingIds = new HashSet<string>(StringComparer.Ordinal);
            var stageFacilityIds = new HashSet<string>(StringComparer.Ordinal);
            for (var index = 0; index < lot.stages.Length; index++)
            {
                var stage = lot.stages[index];
                var path = $"$.snapshot.lot.stages[{index}]";
                if (stage == null) throw new StudioSnapshotFormatException($"{path} is null.");
                if (string.IsNullOrWhiteSpace(stage.buildingId))
                    throw new StudioSnapshotFormatException($"{path}.buildingId has no stable identity.");
                if (string.IsNullOrWhiteSpace(stage.facilityId))
                    throw new StudioSnapshotFormatException($"{path}.facilityId has no stable identity.");
                if (!stageBuildingIds.Add(stage.buildingId))
                    throw new StudioSnapshotFormatException(
                        $"$.snapshot.lot.stages repeats building identity {stage.buildingId}.");
                if (!stageFacilityIds.Add(stage.facilityId))
                    throw new StudioSnapshotFormatException(
                        $"$.snapshot.lot.stages repeats facility identity {stage.facilityId}.");
                RequirePropertyBuildingId(stage.buildingId, $"{path}.buildingId", propertyBuildingIds);
            }

            for (var index = 0; index < productions.activeProductions.Length; index++)
            {
                var production = productions.activeProductions[index];
                var path = $"$.snapshot.productions.activeProductions[{index}]";
                if (production == null) throw new StudioSnapshotFormatException($"{path} is null.");
                RequirePropertyBuildingId(production.stageId, $"{path}.stageId", propertyBuildingIds);
            }

            for (var index = 0; index < productions.productionOperations.Length; index++)
            {
                var operation = productions.productionOperations[index];
                var path = $"$.snapshot.productions.productionOperations[{index}]";
                if (operation == null) throw new StudioSnapshotFormatException($"{path} is null.");
                RequirePropertyBuildingId(
                    operation.locationBuildingId,
                    $"{path}.locationBuildingId",
                    propertyBuildingIds);
            }
        }

        private static void ValidateConstructionLocationIdentities(
            StudioPropertySnapshot property,
            StudioConstructionProjection construction)
        {
            if (construction.placement == null)
                throw new StudioSnapshotFormatException("$.snapshot.construction.placement is null.");

            var placementIds = new HashSet<int>();
            var facilityIds = new HashSet<string>(StringComparer.Ordinal);
            var placements = construction.placement.placements;
            for (var index = 0; index < placements.Length; index++)
            {
                var placement = placements[index];
                var path = $"$.snapshot.construction.placement.placements[{index}]";
                if (placement == null) throw new StudioSnapshotFormatException($"{path} is null.");
                if (!placementIds.Add(placement.id))
                    throw new StudioSnapshotFormatException(
                        "$.snapshot.construction.placement.placements repeats placement identity " + placement.id + ".");
                if (string.IsNullOrWhiteSpace(placement.facilityId))
                    throw new StudioSnapshotFormatException($"{path}.facilityId has no stable identity.");
                if (!facilityIds.Add(placement.facilityId))
                    throw new StudioSnapshotFormatException(
                        "$.snapshot.construction.placement.placements repeats facility identity " +
                        placement.facilityId + ".");

                var matchingBodies = property.buildings
                    .Where(building => building != null && building.placedFacilityId == placement.id)
                    .ToArray();
                if (string.Equals(placement.parcelId, "expansion", StringComparison.Ordinal))
                {
                    if (matchingBodies.Length != 0)
                    {
                        throw new StudioSnapshotFormatException(
                            $"{path} is on legacy expansion ground and must not duplicate it with a property body.");
                    }
                    continue;
                }

                if (matchingBodies.Length != 1)
                {
                    throw new StudioSnapshotFormatException(
                        $"{path}.id must join exactly one property building by placedFacilityId; found {matchingBodies.Length}.");
                }
                var expectedBuildingId = "placed-" + placement.id;
                if (!string.Equals(matchingBodies[0].id, expectedBuildingId, StringComparison.Ordinal))
                {
                    throw new StudioSnapshotFormatException(
                        $"{path}.id requires property building {expectedBuildingId}; found {matchingBodies[0].id}.");
                }
            }
        }

        private static void RequirePropertyBuildingId(
            string id,
            string path,
            HashSet<string> propertyBuildingIds)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new StudioSnapshotFormatException($"{path} has no stable identity.");
            if (!propertyBuildingIds.Contains(id))
            {
                throw new StudioSnapshotFormatException(
                    $"{path} references unknown property building {id}.");
            }
        }

        private static HashSet<string> AddBuildingIds(
            StudioBuildingSnapshot[] buildings,
            string path)
        {
            var ids = new HashSet<string>(StringComparer.Ordinal);
            for (var index = 0; index < buildings.Length; index++)
            {
                var building = buildings[index];
                AddBuildingId(building?.id, $"{path}[{index}]", path, ids);
            }
            return ids;
        }

        private static HashSet<string> AddPropertyBuildingIds(
            StudioPropertyBuildingSnapshot[] buildings,
            string path)
        {
            var ids = new HashSet<string>(StringComparer.Ordinal);
            if (buildings == null) return ids;
            for (var index = 0; index < buildings.Length; index++)
            {
                var building = buildings[index];
                AddBuildingId(building?.id, $"{path}[{index}]", path, ids);
            }
            return ids;
        }

        private static void AddBuildingId(
            string id,
            string itemPath,
            string collectionPath,
            HashSet<string> ids)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new StudioSnapshotFormatException($"{itemPath}.id has no stable identity.");
            if (!ids.Add(id))
            {
                throw new StudioSnapshotFormatException(
                    $"{collectionPath} repeats stable identity {id}.");
            }
        }
    }

    internal static class StudioBridgeHandshakeResponseValidation
    {
        public static void NormalizeAndValidate(
            int protocolVersion,
            string schemaId,
            int snapshotVersion,
            string runtimeInstanceId,
            string sessionId,
            int stateRevision,
            int gameWeek,
            string stateDigest)
        {
            StudioBridgeContract.RequireCompatible(protocolVersion, schemaId, snapshotVersion);
            if (string.IsNullOrWhiteSpace(runtimeInstanceId))
                throw new StudioSnapshotFormatException("Bridge runtimeInstanceId is missing.");
            if (string.IsNullOrWhiteSpace(sessionId))
                throw new StudioSnapshotFormatException("Bridge sessionId is missing.");
            if (stateRevision < 0)
                throw new StudioSnapshotFormatException("Bridge stateRevision cannot be negative.");
            if (gameWeek < 0)
                throw new StudioSnapshotFormatException("Bridge gameWeek cannot be negative.");
            if (string.IsNullOrWhiteSpace(stateDigest))
                throw new StudioSnapshotFormatException("Bridge stateDigest is missing.");
        }
    }

    public static class StudioBridgeJson
    {
        public static StudioBridgeHealthResponse ParseHealth(string json)
        {
            var response = StudioBridgeWireValidator.Parse<StudioBridgeHealthResponse>(
                json,
                nameof(StudioBridgeHealthResponse),
                true);
            response.NormalizeAndValidate();
            return response;
        }

        public static StudioBridgeSessionResponse ParseSession(string json)
        {
            var response = StudioBridgeWireValidator.Parse<StudioBridgeSessionResponse>(
                json,
                nameof(StudioBridgeSessionResponse),
                true);
            response.NormalizeAndValidate();
            return response;
        }

        public static StudioBridgeSnapshotResponse ParseSnapshot(string json)
        {
            var response = StudioBridgeWireValidator.Parse<StudioBridgeSnapshotResponse>(
                json,
                nameof(StudioBridgeSnapshotResponse),
                true);
            response.NormalizeAndValidate();
            return response;
        }

        public static StudioBridgeAcceptedCommandResponse ParseAcceptedCommand(string json)
        {
            var response = StudioBridgeWireValidator.Parse<StudioBridgeAcceptedCommandResponse>(
                json,
                nameof(StudioBridgeAcceptedCommandResponse),
                true);
            response.NormalizeAndValidate();
            return response;
        }

        public static StudioBridgeSaveResponse ParseSaveResponse(string json)
        {
            var response = StudioBridgeWireValidator.Parse<StudioBridgeSaveResponse>(
                json,
                nameof(StudioBridgeSaveResponse),
                false);
            response.NormalizeAndValidate();
            return response;
        }

        public static StudioBridgeRejectedResponse ParseRejectedResponse(string json)
        {
            var response = StudioBridgeWireValidator.Parse<StudioBridgeRejectedResponse>(
                json,
                nameof(StudioBridgeRejectedResponse),
                false);
            response.NormalizeAndValidate();
            return response;
        }

        /// <summary>P03A: the commission-quote response (no projection bundle rides it).</summary>
        public static StudioBridgeQuoteResponse ParseQuoteResponse(string json)
        {
            var response = StudioBridgeWireValidator.Parse<StudioBridgeQuoteResponse>(
                json,
                nameof(StudioBridgeQuoteResponse),
                false);
            response.NormalizeAndValidate();
            return response;
        }

        public static string SubmitIntent(
            string sessionId,
            string commandId,
            int expectedRevision,
            string intentId) =>
            Serialize(new StudioBridgeIntentRequest
            {
                protocolVersion = StudioBridgeContract.ProtocolVersion,
                schemaId = StudioBridgeContract.SchemaId,
                sessionId = sessionId,
                commandId = commandId,
                expectedStateRevision = expectedRevision,
                type = StudioBridgeIntentRequestTypeValues.SubmitIntent,
                payload = new StudioBridgeIntentPayload { intentId = intentId },
            });

        public static string Control(
            string sessionId,
            string commandId,
            int expectedRevision) =>
            Serialize(new StudioBridgeControlRequest
            {
                protocolVersion = StudioBridgeContract.ProtocolVersion,
                schemaId = StudioBridgeContract.SchemaId,
                sessionId = sessionId,
                commandId = commandId,
                expectedStateRevision = expectedRevision,
            });

        /// <summary>
        /// P03A: the commission-quote request. The draft carries enum ids and
        /// center INDICES only — the range math, the genre binding, and every
        /// legality decision stay on the TypeScript side of the wire.
        /// </summary>
        public static string Quote(
            string sessionId,
            string commandId,
            int expectedRevision,
            StudioCommissionDraftPayload draft) =>
            Serialize(new StudioBridgeQuoteRequest
            {
                protocolVersion = StudioBridgeContract.ProtocolVersion,
                schemaId = StudioBridgeContract.SchemaId,
                sessionId = sessionId,
                commandId = commandId,
                expectedStateRevision = expectedRevision,
                type = StudioBridgeQuoteRequestTypeValues.QuoteCommission,
                draft = draft,
            });

        private static string Serialize(object value) =>
            JsonConvert.SerializeObject(
                value,
                Formatting.None,
                StudioBridgeContract.CreateStrictJsonSettings());
    }
}
