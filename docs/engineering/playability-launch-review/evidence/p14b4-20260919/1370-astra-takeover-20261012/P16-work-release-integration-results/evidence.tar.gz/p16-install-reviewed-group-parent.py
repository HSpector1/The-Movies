import pathlib, json, hashlib, subprocess, sys, datetime, os
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16')
old,new,spec=map(pathlib.Path,sys.argv[1:])
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
def git(*a): return subprocess.check_output(g+list(a))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not new.exists()
assert git('diff','--cached','--binary')==(old/'PATCH.diff').read_bytes()
assert set(git('diff','--name-only').decode().splitlines())<={'HANDOFF.md'}
assert not git('ls-files','--others','--exclude-standard')
for f in json.loads((old/'MANIFEST.json').read_text())['files']:
 assert sha(K/f['path'])==f['sha256'] and oct((K/f['path']).stat().st_mode&0o777)==f['mode']
rows=json.loads(spec.read_text()); seen=set()
for row in rows:
 assert sha(A/row['patch'])==row['patchSHA256']
 assert sha(A/row['review'])==row['reviewSHA256'] and 'KEEP' in (A/row['review']).read_text()
 for f in row['files']:
  assert f['path'] not in seen; seen.add(f['path'])
  assert sha(K/f['path'])==f['preimageSHA256']
 subprocess.run(g+['apply','--check','--index',str(A/row['patch'])],check=True)
for row in rows:
 subprocess.run(g+['apply','--index',str(A/row['patch'])],check=True)
 for f in row['files']: assert sha(K/f['path'])==f['postimageSHA256']
new.mkdir(); (new/'PATCH.diff').write_bytes(git('diff','--cached','--binary'))
files=[]
for path in git('diff','--cached','--name-only','-z').decode().split('\0'):
 if not path: continue
 p=K/path; pin=sha(p); assert hashlib.sha256(git('show',':'+path)).hexdigest()==pin
 files.append(dict(path=path,sha256=pin,bytes=p.stat().st_size,mode=oct(p.stat().st_mode&0o777)))
manifest=dict(at=datetime.datetime.now().astimezone().isoformat(),base=git('rev-parse','HEAD').decode().strip(),scope='Reviewed current49 identity and independent test corrections; focused execution pending',files=files)
(new/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt=dict(package=str(new),pathCount=len(files),patchSHA256=sha(new/'PATCH.diff'),manifestSHA256=sha(new/'MANIFEST.json'),deltas=rows)
(new/'INSTALL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(g+['diff','--check','--cached'],check=True)
print(json.dumps({k:v for k,v in receipt.items() if k!='deltas'}))
