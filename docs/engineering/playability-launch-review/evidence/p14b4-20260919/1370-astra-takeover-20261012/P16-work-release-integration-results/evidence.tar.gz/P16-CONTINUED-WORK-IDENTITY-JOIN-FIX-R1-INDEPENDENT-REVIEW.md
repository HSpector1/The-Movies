# Continued-work identity join R1

KEEP bounded source correction, UNRUN. SOURCEa6d80e427fbe9457f642576c9ca4c7247664f1def14298bcfa115d1c905a17bf/MANIFEST443396c72d5e2540b32e376bb78131ac996600335cba9bd545b0a657c91738f4; three pre/postimages verified.

Actual continuation final publication fails because current buyer premiere/P08A Standing records correctly refer to the same creator film, but Hollywood collision initialization treats them as distinct player creation. New reader collision view omits only exact matched buyer premiere or releaseResult Standing production/week when current rights era identifies actual buyer absorption, detached original paid production and real creator simulation film at the same release week. All other player active/released/script/ledger/career/wrapped/otherhistory domains still reserve and collide. Default persistedProductionIds used for actual minting retains every identity; frozen/default reader has no map and takes old exact walk.

No record deleted, copied player body, collision exemption by prefix, allocator normalization or validator shape bypass. Parent fulljoined source/counter/release/Standing/title proof must remain and rejects false coordinated owner claims; this preliminary identity view alone is not paid-work authority. Scope corrects attribution for genuinely shared observation, not arbitrary duplicate film acceptance.

Actual source success/reload/hostile omission and all original5s tests remain unmeasured; initial two journey failures and later-unreached assertions stay preserved. Static only, no runtime/K/R/index changes.
