import pathlib,json,subprocess,sys,importlib.util,collections
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');rev=sys.argv[1]
D=A/f'p16-work-release61-integration-runner-{rev}';out=A/f'p16-work-release61-integration-{rev}-run';audit=A/f'p16-work-release61-integration-{rev}-parent-reconciliation'
assert not (A.parent/'HEAVY-LANE-LOCK').exists()
terminal=json.loads((out/'terminal.json').read_text());audit.mkdir()
s=(D/'runner.sh').read_text().split('check_freeze() {',1)[0].replace('OUT='+str(out),'OUT='+str(audit))+'\nfreeze_snapshot > "$OUT/independent-freeze.json"\n'
subprocess.run(['/bin/bash'],input=s,text=True,check=True)
before=json.loads((out/'freeze.json').read_text());after=json.loads((audit/'independent-freeze.json').read_text())
spec=importlib.util.spec_from_file_location('freeze',D/'auto_freeze.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper);helper.compare_envelopes(before,after)
children=[json.loads(line) for line in (out/'results.jsonl').read_text().splitlines()];r=dict(terminal=terminal,children=children,independentFinalFreeze='PASS',sourceCount=len(before['files']),inputCount=len(before['inputs']),strictChecks=len((out/'metadata-checks.jsonl').read_text().splitlines()),strictErrorsBytes=(out/'metadata-checks-errors.log').stat().st_size,audit=str(audit),scope=json.loads((D/'BINDINGS.json').read_text())['executionScope'])
if (out/'results.json').exists():
 report=json.loads((out/'results.json').read_text());expected=json.loads((D/'EXPECTED-IDENTITIES.json').read_text());rows=[];seen=set();assert len(report['testResults'])==len(expected)
 for want in expected:
  found=[f for f in report['testResults'] if f['name'].endswith('/'+want['file'])];assert len(found)==1
  actual=found[0]['assertionResults'];assert sorted(a['fullName'] for a in actual)==sorted(want['names'])
  for a in actual:
   identity=(want['file'],a['fullName']);assert identity not in seen;seen.add(identity)
   assert a['status'] in ['passed','failed'];rows.append(dict(file=want['file'],**a))
 counts=collections.Counter(row['status'] for row in rows);assert report['numTotalTests']==len(rows) and report['numPassedTests']==counts['passed'] and report['numFailedTests']==counts['failed'] and report['numPendingTests']==report['numTodoTests']==0
 r.update(counts=dict(counts),identities=len(rows),rows=rows,allBudgetQualified=all(x.get('duration') is not None and x['duration']<=5000 for x in rows),maxMs=max(x.get('duration') or 0 for x in rows),failures=[x for x in rows if x['status']!='passed'],overBudget=[x for x in rows if x.get('duration') is None or x['duration']>5000])
else:r.update(runtime='NOT_STARTED',assertionsCounted=0)
(A/f'P16-WORK-RELEASE61-INTEGRATION-{rev.upper()}-PARENT-RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ['rows','failures','overBudget','children']}))
for f in r.get('failures',[]):print(json.dumps(dict(file=f['file'],name=f['fullName'],failure=f['failureMessages'])))
