import pathlib,json,hashlib,re,difflib,os
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r2';D=A/'p16-work-release61-integration-runner-r3';out=A/'p16-work-release61-integration-r3-run';p=A/'p16-work-release-identity-focused-r1'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK');D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
files=['tests/p16-absorption-active-run.test.ts','tests/p16-absorption-continued-production.test.ts','tests/bridge-p16-rights-parity.test.ts']
previous=json.loads((old/'SELECTION.json').read_text());commands=[previous[0],previous[2],previous[-1][:10]+files];commands[-1][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
expect=json.loads((old/'EXPECTED-IDENTITIES.json').read_text());expect=[next(row for row in expect if row['file']==f) for f in files]
for row in expect:row['sourceSHA256']=sha(K/row['file'])
assert sum(len(row['names']) for row in expect)==12;write('EXPECTED-IDENTITIES.json',expect)
for n in ['auto_freeze.py','account-results.py']:(D/n).write_bytes((old/n).read_bytes())
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(A/'p16-work-release61-integration-r2-run'),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal threecompilers twogeneratorchecks21completefiles commands','literal root and Bridge compilers then three complete files commands')
s=s.replace('fresh threecompilers twogeneratorchecks21completefiles76 identities; coherent source qualification, no fullP16 acceptance','focused root and Bridge compilers then three complete files12 identities; no whole gate or P16 acceptance')
s=re.sub(r'^run tsc-ui .*\n.*\n','',s,flags=re.M)
s=re.sub(r'^run generator-(?:contract|fixtures)-check .*\n.*\n','',s,flags=re.M)
s=re.sub(r'^run estate-red .*$', 'run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(files),s,flags=re.M)
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text());m=json.loads((p/'MANIFEST.json').read_text())
b.update(package=str(p),patchSHA256=sha(p/'PATCH.diff'),manifestSHA256=sha(p/'MANIFEST.json'),pathCount=len(m['files']),plannedPathCount=len(m['files']),scope='Focused current49 identity and beneficiary correction; 12 unchanged budget identities',executionScope='root and Bridge compilers then complete active2 continued3 parity7; no fresh UI/generator or broad gate claim',expectedCompiledTests={row['file']:row['sourceSHA256'] for row in expect},finalCleanTestAdmission='Reviewed identity source, exact beneficiary expectation, additive allocator/duplicate controls and same-caller parity serialization; all original assertions and budgets retained',installedSourceReceiptSHA256=sha(p/'INSTALL-RECEIPT.json'))
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',p/'INSTALL-RECEIPT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R2-PARENT-RESULT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R2-INDEPENDENT-RESULT-REVIEW.md',A/'AGENT-HARNESS-HANDOFF-R1-INSTALL-RECEIPT.json']
for row in json.loads((A/'P16-IDENTITY-FOCUSED-R1-INSTALL-SPEC.json').read_text()): paths.extend([A/row['patch'],A/row['review'],(A/row['patch']).parent/'MANIFEST.json'])
for q in paths:
 if str(q) not in {r['path'] for r in b['artifacts']}:b['artifacts'].append(dict(path=str(q),sha256=sha(q)))
write('BINDINGS.json',b)
(D/'DELTA-vs-r2-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r2/runner.sh',tofile='r3/runner.sh')))
(D/'README.md').write_text('Focused identity correction gate. Fresh root and Bridge compilers; complete active-run2 + continued-production3 + Bridge-parity7. Exact 12 identities, default 5s, setup stays inside each leaf. Prior UI/generator results retained separately; no whole gate claim. Existing strict source/index/input/AUTO freeze and lane/floors unchanged. All previous failures preserved. Parent external four-file bootstrap pins required.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
