# Bridge parity same-caller purity R2

KEEP proposed harness-only correction, UNRUN. Postee78ae74f6448ed8d1a3eb74c06cd6bde54edf3d0373c080625d7339a39d4644/DELTAf839d4db1cd85caa378e4e7eb0647ff2c638ef18e5407005431c1ad900abf6fe; all manifest artifact hashes verified, actual pre4d5d10b9 preserved.

Only12 same-caller before/after serialization calls change from key-sorted stableStringify to native JSON.stringify: parsed raw, publicly admitted old/current inputs, same Bridge gameState checkpoints and admitted changed private resolver caller. Plain JSON game/save state is the subject; native comparisons preserve complete values and additionally detect key-order mutations. They are not substitutes for digest/canonical inter-producer equality. All8 canonical calls remain, including cross-public/direct/session and saved serialization comparisons, and authoritative digest/public export/import/replay/full admissions unchanged.

No setup moved outside leaves, no cache, route/transaction/assertion reduction, new fixture, timeout or production serializer change. Same7 identities/default5s. Original allfunctionalPASS but second6709ms overrun remains unqualified; this source-grounded lower-allocation comparison may help but does not promise performance. Complete-file measured durations/refusal/rollback remain necessary. No runtime/K/R or bound-run artifacts changed.
