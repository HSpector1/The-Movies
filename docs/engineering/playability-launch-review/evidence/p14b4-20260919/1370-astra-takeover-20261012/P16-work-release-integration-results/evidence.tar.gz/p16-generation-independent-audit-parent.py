import pathlib,json,subprocess,sys,copy
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16');rev=sys.argv[1]
D=A/f'p16-work-release61-generation-runner-{rev}';out=A/f'p16-work-release61-generation-{rev}-run';audit=A/f'p16-work-release61-generation-{rev}-parent-reconciliation'
assert not (A.parent/'HEAVY-LANE-LOCK').exists()
terminal=json.loads((out/'terminal.json').read_text());audit.mkdir()
s=(D/'runner.sh').read_text().split('check_freeze() {',1)[0].replace('OUT='+str(out),'OUT='+str(audit))+'\nfreeze_snapshot > "$OUT/independent-freeze.json"\n'
subprocess.run(['/bin/bash'],input=s,text=True,check=True)
before=json.loads((out/'freeze.json').read_text());after=json.loads((audit/'independent-freeze.json').read_text());b=json.loads((D/'BINDINGS.json').read_text());outputs=[dict(path=p,before=before['files'][p],after=after['files'][p]) for p in b['generatorOutputs']]
x,y=copy.deepcopy(before),copy.deepcopy(after)
for v in [x,y]:
 for p in b['generatorOutputs']:assert v['files'].pop(p)[0]=='file'
 for k in ['diff','status','autoMetadata']:v.pop(k)
assert x==y,'independent foreign source/index/inputs changed'
assert json.loads((out/'nonoutput-before.json').read_text())==json.loads((audit/'nonoutput-current.json').read_text()),'independent nonoutput status/diff changed'
children=[json.loads(line) for line in (out/'results.jsonl').read_text().splitlines()]
r=dict(terminal=terminal,children=children,outputs=outputs,actualManifest=json.loads((K/'generated/unity/project-studio-bridge.contract-manifest.json').read_text()),independentNonOutputFreeze='PASS',sourceCount=len(before['files']),inputCount=len(before['inputs']),scope='canonical generation only; compiler/runtime pending')
(A/f'P16-WORK-RELEASE61-GENERATION-{rev.upper()}-PARENT-RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(independentNonOutputFreeze='PASS',sourceCount=r['sourceCount'],inputCount=r['inputCount'],outputsChanged=[o['path'] for o in outputs if o['before']!=o['after']],terminal=terminal,manifest=r['actualManifest'])))
