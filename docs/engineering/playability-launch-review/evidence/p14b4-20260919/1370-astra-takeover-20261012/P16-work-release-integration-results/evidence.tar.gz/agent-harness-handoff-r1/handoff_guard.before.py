#!/usr/bin/env python3
"""Shared Claude/Codex handoff guard.

Usage (hook command):  handoff_guard.py <claude|codex> <event>
Events:
  usage   PostToolUse/Stop: once weekly usage >= HANDOFF_USAGE_PCT (default 95),
          tell the model to update HANDOFF.md now (fires once per session per reset).
  snap    SessionEnd/PreCompact: stamp mechanical git state into HANDOFF.md's
          AUTO block. No model involved, so it works even when the session dies.
Usage sources:
  claude  ~/.claude/state/usage.json, written by statusline.py
  codex   rate_limits in ~/.codex/sessions/**/rollout-*<session_id>.jsonl
Errors go to stderr + ~/.claude/state/handoff_guard.log; always exit 0 so a
broken guard never wedges a session.
"""
import datetime, glob, json, os, subprocess, sys, traceback

STATE = os.path.expanduser("~/.claude/state")
LOG = os.path.join(STATE, "handoff_guard.log")
FIRED = os.path.join(STATE, "handoff_fired.json")
THRESHOLD = float(os.environ.get("HANDOFF_USAGE_PCT", "95"))
BEGIN, END = "<!-- AUTO:BEGIN (handoff_guard.py rewrites this block) -->", "<!-- AUTO:END -->"


def git(cwd, *args):
    r = subprocess.run(["git", "-C", cwd, *args], capture_output=True, text=True, timeout=10)
    return r.stdout.strip() if r.returncode == 0 else ""


def weekly_usage(tool, payload):
    """Return (used_percent, resets_at) for the 7-day window, or (None, None)."""
    if tool == "claude":
        try:
            rl = json.load(open(os.path.join(STATE, "usage.json"))).get("rate_limits") or {}
        except FileNotFoundError:
            return None, None
        w = rl.get("seven_day") or {}
        return w.get("used_percentage"), w.get("resets_at")
    sid = payload.get("session_id", "")
    files = sorted(glob.glob(os.path.expanduser(f"~/.codex/sessions/*/*/*/rollout-*{sid}.jsonl")))
    if not sid or not files:
        return None, None
    best = (None, None)
    with open(files[-1], "rb") as f:  # rate_limits land in token_count events near the tail
        f.seek(max(0, os.path.getsize(files[-1]) - 2_000_000))
        for line in f:
            if b'"rate_limits"' not in line:
                continue
            try:
                rl = json.loads(line)["payload"]["rate_limits"]
            except (ValueError, KeyError, TypeError):
                continue
            for w in (rl.get("primary"), rl.get("secondary")):
                if w and w.get("window_minutes", 0) >= 10080:
                    best = (w.get("used_percent"), w.get("resets_at"))
    return best


def usage(tool, event_name, payload):
    if payload.get("stop_hook_active"):
        return
    pct, resets = weekly_usage(tool, payload)
    if pct is None or pct < THRESHOLD:
        return
    key = f"{tool}:{payload.get('session_id')}:{resets}"
    try:
        fired = json.load(open(FIRED))
    except (FileNotFoundError, ValueError):
        fired = {}
    if key in fired:
        return
    fired[key] = datetime.datetime.now().isoformat(timespec="seconds")
    json.dump(fired, open(FIRED, "w"))
    other = "Codex" if tool == "claude" else "Claude"
    msg = (f"HANDOFF TRIGGER: {tool} weekly usage is at {pct:.0f}% (threshold {THRESHOLD:.0f}%). "
           f"Reach the nearest safe point, then use the handoff skill now: rewrite HANDOFF.md at the repo root "
           f"so {other} can resume cold, commit and push per the repo's rules, then continue only if budget remains.")
    if event_name == "Stop":
        print(json.dumps({"decision": "block", "reason": msg}))
    else:
        print(json.dumps({"hookSpecificOutput": {"hookEventName": event_name, "additionalContext": msg}}))


def snap(tool, event_name, payload):
    root = git(payload.get("cwd") or os.getcwd(), "rev-parse", "--show-toplevel")
    path = os.path.join(root, "HANDOFF.md") if root else ""
    if not path or not os.path.exists(path):
        return  # opt-in: only repos that already have HANDOFF.md
    upstream = git(root, "rev-parse", "--abbrev-ref", "@{u}")
    ahead = git(root, "rev-list", "--count", "@{u}..HEAD") if upstream else "?"
    dirty = git(root, "status", "--porcelain").splitlines()
    now = subprocess.run(["date", "+%Y-%m-%d %H:%M %Z"], capture_output=True, text=True).stdout.strip()
    block = "\n".join([
        BEGIN,
        f"- Stamped: {now} by **{tool}** on {event_name} (session {payload.get('session_id', '?')})",
        f"- Branch: `{git(root, 'branch', '--show-current') or 'DETACHED'}` @ `{git(root, 'rev-parse', 'HEAD')}`",
        f"- Upstream: `{upstream or 'none'}`, unpushed commits: {ahead}",
        f"- Uncommitted files: {len(dirty)}" + "".join(f"\n  - `{d}`" for d in dirty[:15])
        + ("\n  - ..." if len(dirty) > 15 else ""),
        "- Last commits:",
        *[f"  - {l}" for l in git(root, "log", "--oneline", "-5").splitlines()],
        END,
    ])
    text = open(path).read()
    if BEGIN in text and END in text:
        text = text[:text.index(BEGIN)] + block + text[text.index(END) + len(END):]
    else:
        text = text.rstrip() + "\n\n## Auto snapshot\n\n" + block + "\n"
    open(path, "w").write(text)


def main():
    tool, mode = sys.argv[1], sys.argv[2]
    raw = sys.stdin.read()
    payload = json.loads(raw) if raw.strip() else {}
    event_name = payload.get("hook_event_name", "Stop")
    {"usage": usage, "snap": snap}[mode](tool, event_name, payload)


if __name__ == "__main__":
    os.makedirs(STATE, exist_ok=True)
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        sys.stderr.write(f"handoff_guard FAILED: {err}")
        with open(LOG, "a") as f:
            f.write(f"--- {datetime.datetime.now().isoformat()} {sys.argv[1:]}\n{err}")
    sys.exit(0)
