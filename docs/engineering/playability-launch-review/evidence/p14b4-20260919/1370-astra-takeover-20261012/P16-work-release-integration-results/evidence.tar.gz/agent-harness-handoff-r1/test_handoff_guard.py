import importlib.util,json,pathlib,stat,tempfile,unittest
from unittest.mock import patch
D=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('guard',D/'handoff_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
class SnapshotTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='handoff-test-',dir=D);self.addCleanup(self.tmp.cleanup)
  self.root=pathlib.Path(self.tmp.name);self.path=self.root/'HANDOFF.md';self.path.write_text('Owner state\n'+g.BEGIN+'\nold\n'+g.END+'\nLessons stay\n');self.original=self.path.read_bytes()
  self.lock=self.root/'lane.lock';self.config=self.root/'projects.json';self.config.write_text(json.dumps({'version':1,'projects':[{'roots':[str(self.root)],'writeBlockers':[str(self.lock)]}]}))
  self.after=None
  self.mocks=[patch.object(g,'PROJECTS',str(self.config)),patch.object(g,'STATE',str(self.root)),patch.object(g,'LOG',str(self.root/'guard.log')),patch.object(g,'git',side_effect=self.git)]
  for m in self.mocks:m.start();self.addCleanup(m.stop)
 def git(self,cwd,*args):
  if args==('rev-parse','--show-toplevel'):return str(self.root)
  if args==('status','--porcelain'):
   if self.after:self.after()
   return 'M HANDOFF.md'
  return {('rev-parse','--abbrev-ref','@{u}'):'',('branch','--show-current'):'work',('rev-parse','HEAD'):'1'*40,('log','--oneline','-5'):'1111111 checkpoint'}.get(args,'')
 def snap(self):g.snap('codex','PreCompact',{'cwd':str(self.root),'session_id':'test'})
 def test_occupied_lane_preserves_document_and_lock(self):
  self.lock.write_text('owner token');before=self.lock.read_bytes();self.snap();self.assertEqual(self.path.read_bytes(),self.original);self.assertEqual(self.lock.read_bytes(),before);self.assertIn('deferred',(self.root/'guard.log').read_text())
 def test_unlocked_snapshot_preserves_model_text_and_mode(self):
  self.path.chmod(0o640);self.snap();text=self.path.read_text();self.assertTrue(text.startswith('Owner state\n'));self.assertTrue(text.endswith('\nLessons stay\n'));self.assertIn('work',text);self.assertEqual(stat.S_IMODE(self.path.stat().st_mode),0o640);self.assertEqual(list(self.root.glob('.handoff-snapshot-*')),[])
 def test_lane_appearing_during_capture_defers(self):
  self.after=lambda:self.lock.write_text('new owner');self.snap();self.assertEqual(self.path.read_bytes(),self.original)
 def test_concurrent_model_edit_is_preserved(self):
  self.after=lambda:self.path.write_text('newer model work\n'+g.BEGIN+'\nnew\n'+g.END+'\n')
  with self.assertRaisesRegex(ValueError,'changed during'):self.snap()
  self.assertTrue(self.path.read_text().startswith('newer model work'));self.assertEqual(list(self.root.glob('.handoff-snapshot-*')),[])
 def test_crlf_outside_auto_bytes_preserved(self):
  before=b'Owner \xc3\xa9\r\n'+g.BEGIN.encode()+b'\r\nold\r\n'+g.END.encode()+b'\r\nLessons\t \r\n'
  self.path.write_bytes(before);self.snap();after=self.path.read_bytes()
  self.assertEqual(after.split(g.BEGIN.encode())[0],before.split(g.BEGIN.encode())[0]);self.assertEqual(after.split(g.END.encode())[1],before.split(g.END.encode())[1])
 def test_missing_auto_preserves_all_original_trailing_bytes(self):
  before=b'Owner work\r\n\t  \r\n';self.path.write_bytes(before);self.snap();self.assertTrue(self.path.read_bytes().startswith(before));self.assertIn(g.BEGIN.encode(),self.path.read_bytes())
 def test_failed_replace_preserves_complete_original(self):
  with patch.object(g.os,'replace',side_effect=OSError('simulated replacement failure')):
   with self.assertRaises(OSError):self.snap()
  self.assertEqual(self.path.read_bytes(),self.original);self.assertEqual(list(self.root.glob('.handoff-snapshot-*')),[])
 def test_symlink_does_not_write_target(self):
  target=self.root/'target.md';target.write_bytes(self.original);self.path.unlink();self.path.symlink_to(target)
  with self.assertRaisesRegex(ValueError,'regular single-link'):self.snap()
  self.assertTrue(self.path.is_symlink());self.assertEqual(target.read_bytes(),self.original)
 def test_malformed_auto_keeps_original(self):
  self.path.write_text('model work\n'+g.BEGIN+'\nunterminated')
  before=self.path.read_bytes()
  with self.assertRaisesRegex(ValueError,'AUTO markers'):self.snap()
  self.assertEqual(self.path.read_bytes(),before)
 def test_other_project_not_deferred(self):
  self.config.write_text(json.dumps({'version':1,'projects':[{'roots':[str(self.root/'other')],'writeBlockers':[str(self.lock)]}]}));self.lock.write_text('other project');self.snap();self.assertNotEqual(self.path.read_bytes(),self.original)
 def test_malformed_configuration_preserves_handoff(self):
  self.config.write_text('{badjson')
  with self.assertRaises(ValueError):self.snap()
  self.assertEqual(self.path.read_bytes(),self.original)
class GitTests(unittest.TestCase):
 def test_read_command_disables_index_refresh_and_automatic_maintenance(self):
  spec=importlib.util.spec_from_file_location('original_guard',D/'handoff_guard.py');actual=importlib.util.module_from_spec(spec);spec.loader.exec_module(actual)
  with patch.object(actual.subprocess,'run') as run:
   run.return_value.returncode=0;run.return_value.stdout='ok\n';self.assertEqual(actual.git('/repo','status','--porcelain'),'ok');argv=run.call_args.args[0];self.assertIn('--no-optional-locks',argv);self.assertIn('gc.auto=0',argv);self.assertIn('maintenance.auto=0',argv)
if __name__=='__main__':unittest.main(verbosity=2)
