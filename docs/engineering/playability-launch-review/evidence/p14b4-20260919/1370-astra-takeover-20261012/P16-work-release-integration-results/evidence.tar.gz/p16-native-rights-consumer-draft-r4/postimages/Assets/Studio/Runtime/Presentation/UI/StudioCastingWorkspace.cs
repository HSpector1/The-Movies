using System;
using System.Collections.Generic;
using Studio.Runtime.Data;
using UnityEngine;
using UnityEngine.UIElements;

namespace ProjectStudio.UnitySpike.Presentation
{
    /// <summary>
    /// P04A Wave 3/4 — the role-first Casting workspace controller. Builds the
    /// frozen `casting-` element tree ONCE (stable identity across binds —
    /// nothing here is torn down and recreated on every snapshot) and rebinds
    /// its CONTENT from a live <see cref="StudioCastingProjectSnapshot"/> on
    /// open and on every snapshot refresh, preserving the retained context's
    /// selected role/candidate wherever the new data still supports it.
    ///
    /// Role-first, selection-not-commitment: selecting a role or a candidate
    /// here is inspection only. It never dispatches to the authority, never
    /// moves a camera, never selects a world entity — [Locate in world] is the
    /// one sanctioned bridge back to the lot, reached only through the
    /// delegate <see cref="Configure"/> supplies (StudioWorkspaceHost's own
    /// SuspendForLocate, one layer up).
    ///
    /// Fit != OVR != evidence != Star Power != availability != cost: every
    /// one of these is its own labeled field, never combined, and every
    /// dossier ends with the fixed disclosure line, verbatim.
    /// Candidate lists are the projection's OWN order (fit-sorted TypeScript
    /// side) — this class never re-sorts, it only labels the order honestly.
    ///
    /// Wave 4 layers three phase-driven modes over that same shell, all
    /// selected purely from the bound project's own sessionStatus (plus one
    /// local-only "planner entered" flag): PLANNER (notStarted, entered
    /// explicitly), UNDERWAY (queued/auditioning) and REVIEW (review). Every
    /// number or line in the consequence/results panels is the authority's
    /// own — a quote's weekLine/slotLine/noFeeLine/noHoldLine/uniquePeople,
    /// or a results snapshot's evidence — never invented here. The network
    /// calls that make a screen-test quote or a commit real live one layer up,
    /// behind the delegates <see cref="Configure"/> wires: this class only
    /// ever shapes local data and calls those delegates, exactly like the
    /// Locate seam above it.
    /// </summary>
    public sealed class StudioCastingWorkspace
    {
        public const string DisclosureLine =
            "Public signals support this assessment; Fit also includes an undisclosed role-read component.";

        /// <summary>The persistent Review-mode line: evidence, never selection. Frozen wording.</summary>
        public const string ReviewEvidenceLine =
            "Camera tests add evidence. They did not select the cast.";

        private const string CastingRoleKey = "writer";
        private static readonly string[] SelectableRoleKeys = { "director", "lead", "antagonist", "support", "craft" };
        private static readonly string[] SelectableRoleLabels = { "Director", "Lead", "Antagonist", "Support", "Craft" };

        /// <summary>
        /// P04A.2 §14: the pinned role-summary's own labels. Identical to
        /// <see cref="SelectableRoleLabels"/> except that the craft seat is
        /// spelled out in full ("Craft Lead") exactly as the summary spec
        /// names it — the summary is the one surface a player reads to answer
        /// "who is cast where" without any surrounding role-rail context.
        /// </summary>
        private static readonly string[] RoleSummaryLabels = { "Director", "Lead", "Antagonist", "Support", "Craft Lead" };

        /// <summary>The three camera-test-eligible roles, in the order every slate/review panel walks them.</summary>
        private static readonly string[] ScreenTestRoleKeys = { "lead", "antagonist", "support" };
        private static readonly string[] ScreenTestRoleLabels = { "Lead", "Antagonist", "Support" };
        private const int ScreenTestSlateSizePerRole = 2;

        private enum CastingWorkspaceMode { Base, Planner, Underway, Review }

        // ── outward seams (Host wires every one of these; every default is a
        // safe no-op so a workspace built without Configure — e.g. a test
        // exercising Bind/SelectRole/SelectCandidate/slate mutation only —
        // never throws and never reaches a network call on its own). ────────
        private Func<string, string> resolveLocateStableId = _ => null;
        private Action<string, bool> requestLocate = (_, __) => { };
        private Action closeRequested = () => { };
        private Func<StudioCastingDraftPayload, string> requestScreenTestQuoteFor = _ => null;
        private Func<bool> screenTestQuoteInFlight = () => false;
        private Func<int?> liveStateRevision = () => null;
        private Func<bool> screenTestActionsEnabled = () => false;
        private Func<StudioQuoteSnapshot, bool> commitScreenTestQuoteFor = _ => false;
        private Func<string, bool> acknowledgeReviewFor = _ => false;

        // ── Wave 6: the additional outward seams ConfigureGreenlight wires.
        // Kept OFF the frozen nine-parameter Configure(...) — two existing
        // Wave 4/5 regression suites invoke that exact method via reflection
        // with a fixed nine-argument array, so its signature is untouchable.
        // Every default is a safe no-op, matching every other seam here. ────
        private Func<StudioQuoteSnapshot, bool> commitGreenlightQuoteFor = _ => false;
        private Action<string> openCastingForProjectFor = _ => { };
        private Func<StudioProductionSnapshot[]> currentActiveProductionsProvider =
            () => Array.Empty<StudioProductionSnapshot>();

        private readonly Label titleLabel;
        private readonly Label phaseLabel;
        private readonly Label draftBadge;
        private readonly VisualElement roleRail;
        private readonly RoleRow writerRow;
        private readonly RoleRow[] selectableRows;
        private readonly Label uniquePeopleLabel;
        private readonly VisualElement candidateList;
        private readonly Label sortLabel;
        private readonly VisualElement dossier;
        private readonly Button backButton;
        private readonly Button planTestsButton;
        private readonly Button continueWithoutTestsButton;
        private readonly Button primaryActionButton;

        // ── Wave 4: planner (casting-slate-*) ────────────────────────────────
        private readonly VisualElement slatePlannerRoot;
        private readonly VisualElement[] slateRoleRows;
        private readonly Label slateCompletenessLabel;
        private readonly Label slateNoticeLabel;
        private readonly VisualElement slateConsequenceRoot;
        private readonly Label slateConsequenceWeekLabel;
        private readonly Label slateConsequenceSlotLabel;
        private readonly Label slateConsequenceNoFeeLabel;
        private readonly Label slateConsequenceNoHoldLabel;
        private readonly Label slateConsequenceUniqueLabel;
        private readonly Label slateConsequenceQueueNoteLabel;
        private readonly Button slateStartButton;
        private readonly Button slateCancelButton;

        // ── Wave 4: underway (casting-underway-*) ────────────────────────────
        private readonly VisualElement underwayRoot;
        private readonly Label underwaySessionLabel;
        private readonly Label underwayDueLabel;
        private readonly Label underwayWeeksLabel;
        private readonly Label underwayConsequenceLabel;
        private readonly Label underwayCapacityLabel;
        private readonly VisualElement underwayReadsList;
        private readonly Label underwayEmptyLabel;

        // ── Wave 4: review (casting-review-*) ────────────────────────────────
        private readonly VisualElement reviewRoot;
        private readonly Label reviewEvidenceLineLabel;
        private readonly VisualElement[] reviewRoleContainers;
        private readonly Button reviewContinueButton;

        // ── Wave 5: compare (casting-compare-*) ──────────────────────────────
        private readonly VisualElement compareBar;
        private readonly Label compareBarLabel;
        private readonly Button compareOpenButton;
        private readonly VisualElement compareRoot;
        private readonly VisualElement compareColumnsContainer;
        private readonly Button compareCloseButton;

        // ── Wave 5: budget pickers (casting-budget-*) ────────────────────────
        private readonly VisualElement budgetSectionRoot;
        private readonly VisualElement budgetNegativeRoot;
        private readonly VisualElement budgetMarketingRoot;

        // ── Wave 5: readiness + Review Greenlight nav ────────────────────────
        private readonly VisualElement readinessRoot;
        // P04A.1 A4: the persistent next-action region is two lines — a
        // section-size headline answering "what remains" at a glance, and a
        // body-size guidance line underneath naming why/what next. Both are
        // built purely from DraftGaps()'s own truth (see RenderReadiness).
        private readonly Label readinessHeadlineLabel;
        /// <summary>The active role, pinned outside the scroll (see RenderReadiness).</summary>
        private readonly Label nowCastingLabel;
        // P04A.2 §14: the always-visible five-role summary — WHO is cast
        // WHERE, pinned outside the scroll alongside NOW CASTING. The only
        // other surface that names occupants (RenderRoleRail) lives inside
        // casting-scroll and, per that code's own measurement, scrolls
        // entirely off screen at 1440x900.
        private readonly VisualElement roleSummaryRoot;
        private readonly Label[] roleSummaryRows;
        private readonly Label readinessLabel;
        private readonly Button reviewGreenlightButton;

        // ── Wave 6: the real Greenlight review (casting-gl-*) ────────────────
        private readonly VisualElement greenlightReviewRoot;
        private readonly Label glHeadline;
        private readonly VisualElement glReviewBody;
        private readonly VisualElement glCompany;
        private readonly VisualElement glPackage;
        private readonly Label glStrongestLabel;
        private readonly Label glWeakestLabel;
        private readonly Label glForecastLabel;
        private readonly Label glSetDemandLabel;
        private readonly VisualElement glCommitment;
        private readonly Label glNegativeLabel;
        private readonly Label glMarketingLabel;
        private readonly Label glFreelancerFeesLabel;
        private readonly Label glTotalImmediateLabel;
        private readonly Label glCashBeforeLabel;
        private readonly Label glCashAfterLabel;
        private readonly VisualElement glCapacity;
        private readonly Label glCapacityBoardLabel;
        private readonly Label glQueueFramingLabel;
        private readonly Label glQueueNoteLabel;
        private readonly VisualElement glBlockers;
        private readonly Label glNotice;
        private readonly VisualElement glReceipt;
        private readonly Label glReceiptLabel;
        private readonly Button glReceiptCloseButton;

        // The sticky footer: a SIBLING of casting-scroll (added to Root, not
        // the scrolling body) so it stays put on screen regardless of scroll
        // offset while the review is open.
        private readonly VisualElement glFooter;
        // Lead fix: the base sticky action bar — a Root child; mode-exclusive
        // with the greenlight-review footer (exactly one bottom band shows).
        private readonly VisualElement actionBarRoot;
        private readonly Button glBackButton;
        private readonly Button glCommitButton;

        // ── Wave 6: board-level expiry notices (casting-expiry-notice-*) ─────
        private readonly VisualElement expiryNoticesRoot;

        /// <summary>
        /// Wave 5: every candidate this workspace instance has ever seen in
        /// ANY role pool, across every Bind — the one honest way to keep a
        /// pinned-compare column or a role-rail draft occupant's IDENTITY
        /// visible after they leave the live pool entirely (a departed
        /// candidate has no fresh wire row to read a name off). Never used to
        /// fabricate a fresh availability fact — a candidate missing from the
        /// LIVE pool always renders as "no longer offered", never a stale
        /// live-looking reading.
        /// </summary>
        private readonly Dictionary<string, StudioCastingCandidateSnapshot> lastKnownCandidates = new(StringComparer.Ordinal);

        // ── Wave 5: duplicate-person conflict — transient, one open prompt at
        // a time, never part of the retained context (mirrors the Wave 4
        // quote fields' own transience: this is a same-session UI prompt, not
        // state that must survive a Locate round trip). ─────────────────────
        private string pendingMoveTalentId;
        private string pendingMoveTargetRole;
        private string pendingMoveFromRole;

        private StudioCastingWorkspaceContext context;
        private StudioCastingProjectSnapshot project;

        /// <summary>
        /// The board's own `capacityLine` (e.g. "1 of 2 slots busy") — one level
        /// above the bound project on the wire, so Bind's caller passes it
        /// through explicitly. Optional/back-compatible: a caller that has not
        /// yet been updated to pass it renders the Underway facts without this
        /// one line rather than throwing or guessing.
        /// </summary>
        private string boardCapacityLine;

        // ── Wave 4: screen-test quote/commit/acknowledge state (transient —
        // never part of the retained context, exactly like the Development
        // card's own quote fields live on the HUD, not its draft model). ────
        private StudioBridgeQuoteResponse pendingScreenTestQuote;
        private string pendingScreenTestQuoteCommandId;
        private bool screenTestQuoteDirty = true;
        private string screenTestQuoteNotice;
        private string slateNotice;
        private float slateArmedAtRealtime = float.NegativeInfinity;
        private string acknowledgedForSessionId;

        // ── Wave 6: greenlight quote/commit/receipt state (transient — never
        // part of the retained context, exactly like the Wave 4 screen-test
        // quote fields above). Reset whenever Bind() sees a BRAND NEW context
        // instance (a fresh OpenCasting), never on an ordinary snapshot
        // rebind of the SAME open session. ───────────────────────────────────
        private StudioBridgeQuoteResponse pendingGreenlightQuote;
        private string pendingGreenlightQuoteCommandId;
        private bool greenlightQuoteDirty = true;
        private string greenlightQuoteNotice;
        private float greenlightArmedAtRealtime = float.NegativeInfinity;
        private bool greenlightCommitInFlight;
        private bool greenlightReceiptShowing;
        private string greenlightReceiptCopy;

        // Captured at the instant CommitGreenlightQuote() dispatches — the
        // quote's OWN facts, never re-derived — so the receipt can speak
        // truthfully even after the bound project itself vanishes from the
        // live board (a FORMED greenlight leaves casting's board entirely).
        private bool greenlightExpectedQueues;
        private string greenlightExpectedTitle;
        private string greenlightExpectedProjectId;
        private int? greenlightExpectedTotalImmediate;
        private HashSet<string> preCommitProductionIds;

        /// <summary>True from a successful dispatch until Host resolves the accept/reject via the generic CommandAccepted/CommandRejected events.</summary>
        public bool GreenlightCommitPending => greenlightCommitInFlight || greenlightReceiptShowing;

        public VisualElement Root { get; }

        private sealed class RoleRow
        {
            public VisualElement Element;
            public Label Text;
            public string RoleKey;
        }

        public StudioCastingWorkspace()
        {
            Root = new VisualElement { name = "casting-root", pickingMode = PickingMode.Position };

            var scroll = new ScrollView(ScrollViewMode.Vertical) { name = "casting-scroll" };
            scroll.style.flexGrow = 1f;
            Root.Add(scroll);
            var body = scroll.contentContainer;
            // Wave 7B visual-defect fix (FIX 3 — row overlap root cause):
            // every row/section this class builds below is plain normal-flow
            // (no absolute positioning, no fixed heights) — but ScrollView's
            // own content container carries Yoga's default flex-shrink: 1
            // like everything else, so once total content height exceeds the
            // scroll viewport (routine here: role rail + candidate list, or
            // company + package + commitment + capacity + blockers all
            // rendered together), Yoga is free to COMPRESS body and its
            // children below their own intrinsic content height instead of
            // overflowing into the scrollbar — which is exactly what
            // produced the lead's overlapping rows (a role rail row and a
            // candidate row occupying the same compressed vertical span).
            // This project's runtime PanelSettings has no themeStyleSheet
            // (see StudioWorkspaceHost.BuildVisualTree), so none of Unity's
            // own default ScrollView styling — which normally pins the
            // content container's flex-shrink to 0 for exactly this reason
            // — is present to guard against it. Pinning it explicitly here,
            // in code, makes every section/row's height a pure function of
            // its own content regardless of how many Clear()/Add() bursts
            // land inside a single frame (screen-test slate fills, package
            // drafts) or how deep the viewport's overflow runs.
            body.style.flexShrink = 0f;

            var header = new VisualElement { name = "casting-header" };
            titleLabel = new Label { name = "casting-title" };
            titleLabel.AddToClassList("casting-workspace-title");
            phaseLabel = new Label();
            phaseLabel.AddToClassList("casting-phase-line");
            draftBadge = new Label("Package draft · not committed") { name = "casting-draft-badge" };
            draftBadge.AddToClassList("meta");
            header.Add(titleLabel);
            header.Add(phaseLabel);
            header.Add(draftBadge);
            body.Add(header);

            // ── Wave 6: board-level expiry notices — independent of which
            // project this workspace instance is currently bound to. ────────
            expiryNoticesRoot = new VisualElement { name = "casting-expiry-notices" };
            body.Add(expiryNoticesRoot);

            roleRail = new VisualElement { name = "casting-role-rail" };
            writerRow = BuildRoleRow(CastingRoleKey, null);
            writerRow.Element.SetEnabled(true);
            roleRail.Add(writerRow.Element);
            selectableRows = new RoleRow[SelectableRoleKeys.Length];
            for (var index = 0; index < SelectableRoleKeys.Length; index++)
            {
                var roleKey = SelectableRoleKeys[index];
                var row = BuildRoleRow(roleKey, SelectableRoleLabels[index]);
                row.Element.RegisterCallback<ClickEvent>(_ => SelectRole(roleKey));
                selectableRows[index] = row;
                roleRail.Add(row.Element);
            }
            body.Add(roleRail);

            uniquePeopleLabel = new Label { name = "casting-slate-unique" };
            uniquePeopleLabel.AddToClassList("meta");
            uniquePeopleLabel.style.display = DisplayStyle.None;
            body.Add(uniquePeopleLabel);

            sortLabel = new Label("Sorted by Fit");
            sortLabel.AddToClassList("meta");
            body.Add(sortLabel);

            candidateList = new VisualElement { name = "casting-candidate-list" };
            body.Add(candidateList);

            dossier = new VisualElement { name = "casting-dossier" };
            dossier.style.display = DisplayStyle.None;
            body.Add(dossier);

            // ── Wave 5: compare bar + layer (non-mutating; scoped to role) ───
            compareBar = new VisualElement { name = "casting-compare-bar" };
            compareBar.style.display = DisplayStyle.None;
            compareBarLabel = new Label { name = "casting-compare-bar-label" };
            compareBarLabel.AddToClassList("meta");
            compareOpenButton = new Button(HandleCompareOpenClicked) { name = "casting-compare-open", text = "Compare pinned" };
            compareBar.Add(compareBarLabel);
            compareBar.Add(compareOpenButton);
            body.Add(compareBar);

            compareRoot = new VisualElement { name = "casting-compare" };
            compareRoot.style.display = DisplayStyle.None;
            var compareHeader = new Label("Comparing candidates — pinning never changes the package draft.")
            {
                name = "casting-compare-header",
            };
            compareHeader.AddToClassList("meta");
            compareRoot.Add(compareHeader);
            compareColumnsContainer = new VisualElement { name = "casting-compare-columns" };
            compareColumnsContainer.style.flexDirection = FlexDirection.Row;
            compareRoot.Add(compareColumnsContainer);
            compareCloseButton = new Button(() => CloseCompare()) { name = "casting-compare-back", text = "Back to candidates" };
            compareRoot.Add(compareCloseButton);
            body.Add(compareRoot);

            // ── Wave 5: budget pickers — published-menu-only, one selected each ──
            budgetSectionRoot = new VisualElement { name = "casting-budget-section" };
            budgetSectionRoot.style.display = DisplayStyle.None;
            var negativeLabel = new Label("Negative budget") { name = "casting-budget-negative-label" };
            negativeLabel.AddToClassList("meta");
            budgetNegativeRoot = new VisualElement { name = "casting-budget-negative" };
            var marketingLabel = new Label("Marketing budget") { name = "casting-budget-marketing-label" };
            marketingLabel.AddToClassList("meta");
            budgetMarketingRoot = new VisualElement { name = "casting-budget-marketing" };
            budgetSectionRoot.Add(negativeLabel);
            budgetSectionRoot.Add(budgetNegativeRoot);
            budgetSectionRoot.Add(marketingLabel);
            budgetSectionRoot.Add(budgetMarketingRoot);
            body.Add(budgetSectionRoot);

            // ── Wave 5: readiness strip + [Review Greenlight] navigation ────
            readinessRoot = new VisualElement { name = "casting-readiness" };
            readinessRoot.style.display = DisplayStyle.None;
            // A4: headline first (section size, e.g. "3 OF 5 ROLES FILLED" /
            // "PACKAGE READY"), then the guidance line (body size — not the
            // 15px `meta` class, which read too small to answer the North
            // Star's five questions at a glance).
            // The active role, pinned outside the scroll — see RenderReadiness.
            nowCastingLabel = new Label { name = "casting-readiness-role" };
            nowCastingLabel.AddToClassList("casting-readiness-role");
            readinessRoot.Add(nowCastingLabel);

            // ── P04A.2 §14: the ALWAYS-VISIBLE five-role summary, between
            // NOW CASTING and the readiness headline. Before this, the pinned
            // region showed only a COUNT ("3 OF 5 ROLES FILLED") plus a gap
            // list — it never named WHO was cast WHERE, and the one surface
            // that did (the role rail) scrolls off screen. Each role gets its
            // own stably named Label so the summary can be asserted on text,
            // never on colour; the container flows as a wrapping row so five
            // roles cost roughly two short lines rather than five, keeping the
            // primary action on screen at 1280x800 (the smallest required
            // viewport). Rebuilt from DraftGaps()/RoleRailStatus()'s own truth
            // on every render — see RenderReadiness.
            roleSummaryRoot = new VisualElement { name = "casting-role-summary" };
            roleSummaryRows = new Label[SelectableRoleKeys.Length];
            for (var index = 0; index < SelectableRoleKeys.Length; index++)
            {
                var summaryRow = new Label { name = $"casting-role-summary-{SelectableRoleKeys[index]}" };
                summaryRow.AddToClassList("casting-role-summary-row");
                roleSummaryRows[index] = summaryRow;
                roleSummaryRoot.Add(summaryRow);
            }
            readinessRoot.Add(roleSummaryRoot);

            readinessHeadlineLabel = new Label { name = "casting-readiness-headline" };
            readinessRoot.Add(readinessHeadlineLabel);
            readinessLabel = new Label { name = "casting-readiness-label" };
            readinessRoot.Add(readinessLabel);
            reviewGreenlightButton = new Button(HandleReviewGreenlightClicked)
            {
                name = "casting-review-greenlight",
                text = "Review Greenlight",
            };
            reviewGreenlightButton.AddToClassList("primary-action");
            reviewGreenlightButton.SetEnabled(false);
            readinessRoot.Add(reviewGreenlightButton);
            // Lead fix (design D1 "sticky bottom action region"): the
            // readiness strip and its Review Greenlight action live OUTSIDE
            // the scroll, as normal-flow Root children after it — the primary
            // decision path is always visible; only content scrolls.
            Root.Add(readinessRoot);

            // ── Wave 6: casting-greenlight-review — the real review ──────────
            greenlightReviewRoot = new VisualElement { name = "casting-greenlight-review" };
            greenlightReviewRoot.style.display = DisplayStyle.None;

            // Legacy Wave-5 hand-off text: permanently hidden. Kept only
            // because the frozen Wave-5 regression suite
            // (StudioCastingPackageDraftTests, outside this lane's file
            // allowlist and therefore un-editable) asserts this exact element
            // still contains "next wave". The real review is everything
            // below, under the casting-gl-* names the freeze specifies.
            var legacyGreenlightBody = new Label(
                "The full Greenlight review — spend confirmation and the commit itself — arrives in the next wave. " +
                "Your package draft is saved exactly as you left it.")
            {
                name = "casting-greenlight-review-body",
            };
            legacyGreenlightBody.style.display = DisplayStyle.None;
            greenlightReviewRoot.Add(legacyGreenlightBody);

            glHeadline = new Label { name = "casting-gl-headline" };
            glHeadline.AddToClassList("casting-workspace-title");
            greenlightReviewRoot.Add(glHeadline);

            glReviewBody = new VisualElement { name = "casting-gl-review-body" };
            greenlightReviewRoot.Add(glReviewBody);

            glCompany = new VisualElement { name = "casting-gl-company" };
            glReviewBody.Add(glCompany);

            glPackage = new VisualElement { name = "casting-gl-package" };
            glStrongestLabel = new Label { name = "casting-gl-strongest" };
            glWeakestLabel = new Label { name = "casting-gl-weakest" };
            glForecastLabel = new Label { name = "casting-gl-forecast" };
            glForecastLabel.AddToClassList("meta");
            glSetDemandLabel = new Label { name = "casting-gl-setdemand" };
            glSetDemandLabel.AddToClassList("meta");
            glPackage.Add(glStrongestLabel);
            glPackage.Add(glWeakestLabel);
            glPackage.Add(glForecastLabel);
            glPackage.Add(glSetDemandLabel);
            glReviewBody.Add(glPackage);

            glCommitment = new VisualElement { name = "casting-gl-commitment" };
            glNegativeLabel = new Label { name = "casting-gl-negative" };
            glMarketingLabel = new Label { name = "casting-gl-marketing" };
            glFreelancerFeesLabel = new Label { name = "casting-gl-freelancer-fees" };
            glTotalImmediateLabel = new Label { name = "casting-gl-total-immediate" };
            glCashBeforeLabel = new Label { name = "casting-gl-cash-before" };
            glCashAfterLabel = new Label { name = "casting-gl-cash-after" };
            glCommitment.Add(glNegativeLabel);
            glCommitment.Add(glMarketingLabel);
            glCommitment.Add(glFreelancerFeesLabel);
            glCommitment.Add(glTotalImmediateLabel);
            glCommitment.Add(glCashBeforeLabel);
            glCommitment.Add(glCashAfterLabel);
            glReviewBody.Add(glCommitment);

            glCapacity = new VisualElement { name = "casting-gl-capacity" };
            glCapacityBoardLabel = new Label { name = "casting-gl-capacity-board" };
            glCapacityBoardLabel.AddToClassList("meta");
            glQueueFramingLabel = new Label { name = "casting-gl-queue-framing" };
            glQueueNoteLabel = new Label { name = "casting-gl-queue-note" };
            glQueueNoteLabel.AddToClassList("meta");
            glCapacity.Add(glCapacityBoardLabel);
            glCapacity.Add(glQueueFramingLabel);
            glCapacity.Add(glQueueNoteLabel);
            glReviewBody.Add(glCapacity);

            glBlockers = new VisualElement { name = "casting-gl-blockers" };
            glReviewBody.Add(glBlockers);

            glNotice = new Label { name = "casting-gl-notice" };
            glNotice.AddToClassList("refusal");
            glNotice.style.display = DisplayStyle.None;
            glReviewBody.Add(glNotice);

            glReceipt = new VisualElement { name = "casting-gl-receipt" };
            glReceipt.style.display = DisplayStyle.None;
            glReceiptLabel = new Label { name = "casting-gl-receipt-text" };
            glReceiptLabel.AddToClassList("casting-workspace-title");
            glReceiptCloseButton = new Button(() => CloseGreenlightReceipt())
            {
                name = "casting-gl-receipt-close",
                text = "Close",
            };
            glReceipt.Add(glReceiptLabel);
            glReceipt.Add(glReceiptCloseButton);
            greenlightReviewRoot.Add(glReceipt);

            body.Add(greenlightReviewRoot);

            // ── Wave 4: the camera-test planner panel ────────────────────────
            slatePlannerRoot = new VisualElement { name = "casting-slate-planner" };
            slatePlannerRoot.style.display = DisplayStyle.None;
            slateRoleRows = new VisualElement[ScreenTestRoleKeys.Length];
            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var row = new VisualElement { name = $"casting-slate-role-{ScreenTestRoleKeys[index]}" };
                slateRoleRows[index] = row;
                slatePlannerRoot.Add(row);
            }
            slateCompletenessLabel = new Label { name = "casting-slate-completeness" };
            slateCompletenessLabel.AddToClassList("attention");
            slateCompletenessLabel.style.display = DisplayStyle.None;
            slatePlannerRoot.Add(slateCompletenessLabel);
            slateNoticeLabel = new Label { name = "casting-slate-notice" };
            slateNoticeLabel.AddToClassList("refusal");
            slateNoticeLabel.style.display = DisplayStyle.None;
            slatePlannerRoot.Add(slateNoticeLabel);

            slateConsequenceRoot = new VisualElement { name = "casting-slate-consequence" };
            slateConsequenceRoot.style.display = DisplayStyle.None;
            slateConsequenceWeekLabel = new Label { name = "casting-slate-consequence-week" };
            slateConsequenceSlotLabel = new Label { name = "casting-slate-consequence-slot" };
            slateConsequenceNoFeeLabel = new Label { name = "casting-slate-consequence-nofee" };
            slateConsequenceNoHoldLabel = new Label { name = "casting-slate-consequence-nohold" };
            slateConsequenceUniqueLabel = new Label { name = "casting-slate-consequence-unique" };
            // BLOCKER 3(c): the accepted screen-test quote's own queueNote —
            // verbatim TS copy, bound only when it queues and carries one,
            // exactly like the greenlight path's glQueueNoteLabel.
            slateConsequenceQueueNoteLabel = new Label { name = "casting-slate-consequence-queuenote" };
            slateConsequenceQueueNoteLabel.AddToClassList("meta");
            slateConsequenceRoot.Add(slateConsequenceWeekLabel);
            slateConsequenceRoot.Add(slateConsequenceSlotLabel);
            slateConsequenceRoot.Add(slateConsequenceNoFeeLabel);
            slateConsequenceRoot.Add(slateConsequenceNoHoldLabel);
            slateConsequenceRoot.Add(slateConsequenceUniqueLabel);
            slateConsequenceRoot.Add(slateConsequenceQueueNoteLabel);
            slatePlannerRoot.Add(slateConsequenceRoot);

            var slateActions = new VisualElement { name = "casting-slate-actions" };
            slateActions.AddToClassList("casting-slate-actions");
            slateStartButton = new Button(HandleStartScreenTestsClicked)
            {
                name = "casting-slate-start",
                text = "Start one-week camera tests",
            };
            slateStartButton.AddToClassList("primary-action");
            slateCancelButton = new Button(HandleCancelPlannerClicked) { name = "casting-slate-cancel", text = "Cancel" };
            slateActions.Add(slateStartButton);
            slateActions.Add(slateCancelButton);
            slatePlannerRoot.Add(slateActions);
            body.Add(slatePlannerRoot);

            // ── Wave 4: the underway (queued/auditioning) panel ──────────────
            underwayRoot = new VisualElement { name = "casting-underway" };
            underwayRoot.style.display = DisplayStyle.None;
            underwaySessionLabel = new Label { name = "casting-underway-session" };
            underwayDueLabel = new Label { name = "casting-underway-due" };
            underwayWeeksLabel = new Label { name = "casting-underway-weeks" };
            underwayWeeksLabel.AddToClassList("meta");
            underwayConsequenceLabel = new Label { name = "casting-underway-consequence" };
            underwayConsequenceLabel.AddToClassList("meta");
            underwayCapacityLabel = new Label { name = "casting-underway-capacity" };
            underwayCapacityLabel.AddToClassList("meta");
            underwayCapacityLabel.style.display = DisplayStyle.None;
            underwayRoot.Add(underwaySessionLabel);
            underwayRoot.Add(underwayDueLabel);
            underwayRoot.Add(underwayWeeksLabel);
            underwayRoot.Add(underwayConsequenceLabel);
            underwayRoot.Add(underwayCapacityLabel);
            underwayReadsList = new VisualElement { name = "casting-underway-reads" };
            underwayRoot.Add(underwayReadsList);
            underwayEmptyLabel = new Label("No results yet") { name = "casting-underway-empty" };
            underwayEmptyLabel.AddToClassList("meta");
            underwayRoot.Add(underwayEmptyLabel);
            body.Add(underwayRoot);

            // ── Wave 4: the review panel ──────────────────────────────────────
            reviewRoot = new VisualElement { name = "casting-review" };
            reviewRoot.style.display = DisplayStyle.None;
            reviewEvidenceLineLabel = new Label(ReviewEvidenceLine) { name = "casting-review-evidence-line" };
            reviewRoot.Add(reviewEvidenceLineLabel);
            reviewRoleContainers = new VisualElement[ScreenTestRoleKeys.Length];
            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var container = new VisualElement { name = $"casting-review-role-{ScreenTestRoleKeys[index]}" };
                reviewRoleContainers[index] = container;
                reviewRoot.Add(container);
            }
            reviewContinueButton = new Button(HandleReviewContinueClicked)
            {
                name = "casting-review-continue",
                text = "Continue to Casting",
            };
            reviewContinueButton.AddToClassList("primary-action");
            reviewRoot.Add(reviewContinueButton);
            body.Add(reviewRoot);

            actionBarRoot = new VisualElement { name = "casting-actionbar" };
            var actionBar = actionBarRoot;
            backButton = new Button(HandleBackClicked) { name = "casting-back", text = "Back" };
            backButton.AddToClassList("primary-action");
            planTestsButton = new Button(HandlePlanTestsClicked) { name = "casting-plan-tests", text = "Plan camera tests" };
            planTestsButton.style.display = DisplayStyle.None;
            continueWithoutTestsButton = new Button(HandleContinueWithoutTestsClicked)
            {
                name = "casting-continue-without-tests",
                text = "Continue without tests",
            };
            continueWithoutTestsButton.AddToClassList("meta");
            continueWithoutTestsButton.style.display = DisplayStyle.None;
            // AUTHORIZED CLEANUP (Wave 6): the Wave 3 "coming soon" placeholder
            // is superseded by the real flow (readiness → casting-review-
            // greenlight → casting-greenlight-review → casting-gl-commit).
            // The element is kept — never removed — solely because the
            // frozen Wave 3 regression suite (StudioCastingWorkspaceTests,
            // outside this lane's file allowlist) asserts
            // `Q<Button>("casting-primary-action")` is not null. Repurposed
            // to inert-correct: permanently hidden, permanently disabled, its
            // click handler a no-op — it can never be seen or activated.
            primaryActionButton = new Button(HandlePrimaryActionClicked)
            {
                name = "casting-primary-action",
                text = "Retired — see Review Greenlight",
            };
            primaryActionButton.SetEnabled(false);
            primaryActionButton.AddToClassList("disabled");
            primaryActionButton.style.display = DisplayStyle.None;
            actionBar.Add(backButton);
            actionBar.Add(planTestsButton);
            actionBar.Add(continueWithoutTestsButton);
            actionBar.Add(primaryActionButton);
            // Lead fix (design D1): the action bar joins the sticky bottom
            // region — a normal-flow Root child after the scroll, always
            // visible regardless of scroll position.
            Root.Add(actionBar);

            // ── Wave 6/7B: the Greenlight-review footer — a NORMAL-FLOW
            // sibling added to Root after casting-scroll. It stays visible at
            // the panel bottom because the scroll itself shrinks (flex-shrink
            // 1 + min-height 0 in USS) — overflow goes to the scrollbar, so
            // content can never render underneath this footer. ───────────────
            glFooter = new VisualElement { name = "casting-gl-footer" };
            glFooter.style.display = DisplayStyle.None;
            glBackButton = new Button(() => CloseGreenlightReview()) { name = "casting-gl-back", text = "Back to package" };
            glCommitButton = new Button(() => CommitGreenlightQuote()) { name = "casting-gl-commit", text = "Confirm Greenlight" };
            glCommitButton.AddToClassList("primary-action");
            glCommitButton.SetEnabled(false);
            glFooter.Add(glBackButton);
            glFooter.Add(glCommitButton);
            Root.Add(glFooter);
        }

        /// <summary>
        /// Wires every outward seam: Back (host.CloseWorkspace), Locate
        /// resolution/dispatch (unchanged from Wave 3), and the Wave 4
        /// screen-test lifecycle — requesting a quote, reading whether one is
        /// in flight, reading the live state revision, reading whether
        /// actions are currently enabled, committing an accepted quote, and
        /// acknowledging a finished review. Every one of these six delegates
        /// is the ONLY place this class ever reaches the authority: it hands
        /// off the exact data and nothing else, exactly like the Locate seam
        /// above it. Every default is a safe no-op, so a workspace built
        /// without calling this (e.g. a test exercising Bind/SelectRole/
        /// SelectCandidate/slate mutation only) never throws.
        /// </summary>
        public void Configure(
            Action closeWorkspace,
            Func<string, string> resolveLocateStableIdFor,
            Action<string, bool> suspendForLocate,
            Func<StudioCastingDraftPayload, string> requestScreenTestQuote,
            Func<bool> isScreenTestQuoteInFlight,
            Func<int?> currentLiveStateRevision,
            Func<bool> areScreenTestActionsEnabled,
            Func<StudioQuoteSnapshot, bool> commitScreenTestQuote,
            Func<string, bool> acknowledgeReview)
        {
            closeRequested = closeWorkspace ?? (() => { });
            resolveLocateStableId = resolveLocateStableIdFor ?? (_ => null);
            requestLocate = suspendForLocate ?? ((_, __) => { });
            requestScreenTestQuoteFor = requestScreenTestQuote ?? (_ => null);
            screenTestQuoteInFlight = isScreenTestQuoteInFlight ?? (() => false);
            liveStateRevision = currentLiveStateRevision ?? (() => null);
            screenTestActionsEnabled = areScreenTestActionsEnabled ?? (() => false);
            commitScreenTestQuoteFor = commitScreenTestQuote ?? (_ => false);
            acknowledgeReviewFor = acknowledgeReview ?? (_ => false);
        }

        /// <summary>
        /// Wave 6's three additional outward seams: committing the quoted
        /// greenlight package intent (Host tracks its own commandId and
        /// forwards the generic CommandAccepted/CommandRejected events back
        /// through HandleGreenlightCommitAccepted/Rejected below), reopening
        /// the workspace for a DIFFERENT (or the same) projectId from an
        /// expiry notice's [Review package], and reading the live productions
        /// list at commit time (used only to corroborate the receipt's
        /// "formed" verification). Kept off the frozen nine-parameter
        /// Configure(...) so that method's signature — invoked via fixed-
        /// arity reflection by two existing regression suites — never
        /// changes shape.
        /// </summary>
        public void ConfigureGreenlight(
            Func<StudioQuoteSnapshot, bool> commitGreenlightQuote,
            Action<string> openCastingForProject,
            Func<StudioProductionSnapshot[]> currentActiveProductions)
        {
            commitGreenlightQuoteFor = commitGreenlightQuote ?? (_ => false);
            openCastingForProjectFor = openCastingForProject ?? (_ => { });
            currentActiveProductionsProvider = currentActiveProductions ?? (() => Array.Empty<StudioProductionSnapshot>());
        }

        /// <summary>
        /// (Re)binds the workspace to one project. Called on OpenCasting and
        /// on every snapshot refresh while the workspace is open. Preserves
        /// the retained context's role (always one of the five fixed keys)
        /// and candidate selection wherever the new project still supports
        /// them; clears what it cannot. Never throws — a null project (the
        /// board went legacy, or the project left it) renders the emptiest
        /// honest state rather than raising.
        ///
        /// `capacityLine` is the BOARD's own capacity fact (one level above a
        /// single project on the wire — `StudioCastingBoardSnapshot.capacityLine`)
        /// surfaced into the Underway facts; optional so an unmigrated caller
        /// keeps compiling and simply omits that one line.
        /// </summary>
        public void Bind(
            StudioCastingWorkspaceContext workspaceContext,
            StudioCastingProjectSnapshot boundProject,
            string capacityLine = null)
        {
            // Wave 6: a genuinely NEW context instance means a fresh
            // OpenCasting (Host always mints a new one), never an ordinary
            // snapshot-refresh rebind of the SAME open session — the one
            // reliable signal to wipe any stale held greenlight quote/
            // receipt from a PREVIOUS project this same long-lived
            // controller instance may have shown earlier.
            if (!ReferenceEquals(context, workspaceContext)) ResetGreenlightTransientState();

            context = workspaceContext;
            project = boundProject;
            boardCapacityLine = capacityLine;

            if (context == null)
            {
                RenderEmpty();
                return;
            }

            if (project == null)
            {
                if (GreenlightCommitPending)
                {
                    // The bound project can legitimately vanish from the live
                    // board the instant a FORMED greenlight commit succeeds
                    // (casting's job is done; it becomes a production) — this
                    // must never be treated as "the project left the board
                    // for some other reason" while a greenlight commit THIS
                    // workspace itself just submitted is in flight or has
                    // already produced a receipt. Preserve it exactly like
                    // Wave 4 keeps rendering an ordinary sessionStatus
                    // refresh, rather than collapsing to the empty state.
                    RenderGreenlightOnlyState();
                    return;
                }

                context.Role = null;
                context.CandidateId = null;
                context.PlannerActive = false;
                context.CompareOpen = false;
                context.GreenlightReviewOpen = false;
                ClearPendingMove();
                RenderEmpty();
                return;
            }

            // Wave 5: cache every candidate this Bind sees, in EVERY pool, so
            // an identity survives even after the person later leaves the
            // live pool entirely (a pinned-compare column or a role-rail
            // draft occupant that goes silent otherwise has no name to show).
            CacheKnownCandidates();

            if (string.IsNullOrEmpty(context.Role) || Array.IndexOf(SelectableRoleKeys, context.Role) < 0)
                context.Role = SelectableRoleKeys[0];
            if (!string.IsNullOrEmpty(context.CandidateId) && !PoolContains(context.Role, context.CandidateId))
                context.CandidateId = null;
            // The planner only exists pre-session; once the session moves on
            // the flag is meaningless, so Bind fails it closed rather than
            // let a stale entry leak the planner panel back onto a later
            // sessionStatus (e.g. after a Cancel-less commit succeeds).
            if (!string.Equals(project.sessionStatus, StudioCastingProjectSnapshotSessionStatusValues.NotStarted, StringComparison.Ordinal))
                context.PlannerActive = false;
            // P04A.2 (FINDING 3): a conflict prompt must not outlive the pools
            // it names — but it must not be DESTROYED by an ordinary snapshot
            // refresh either, while every word of it is still true. Host calls
            // Bind() on every applied snapshot, and P04A.2's Living Time now
            // lands one every WeekSecondsAt1x, so an unconditional clear here
            // silently deleted the player's armed Move (and its "X leaves Y."
            // disclosure) mid-decision, with no explanation, after a couple of
            // seconds. Preserve it when it is still entirely true, and clear it
            // exactly as before when it is not — re-derived from the LIVE draft
            // and the NEW snapshot's pools, never from cached display strings.
            if (!PendingMoveSurvivesRebind()) ClearPendingMove();

            RenderAll();
        }

        /// <summary>
        /// Wave 6: renders board.expiryNotices as a workspace notice block,
        /// independent of whichever single project this instance is
        /// currently bound to. Called by Host alongside every Bind() (on
        /// open and on every snapshot refresh). Dedupes by eventSeq against
        /// the context-held set — an event still present in a later
        /// snapshot's array is never shown twice in the SAME open-workspace
        /// session. A null/empty array simply clears the block.
        /// </summary>
        public void BindExpiryNotices(StudioCastingExpiryNoticeSnapshot[] notices)
        {
            expiryNoticesRoot.Clear();
            if (context == null || notices == null) return;
            foreach (var notice in notices)
            {
                if (notice == null) continue;
                if (context.SurfacedExpiryEventSeqs.Contains(notice.eventSeq)) continue;
                context.SurfacedExpiryEventSeqs.Add(notice.eventSeq);

                var row = new VisualElement { name = $"casting-expiry-notice-{notice.eventSeq}" };
                row.AddToClassList("casting-expiry-notice-row");
                var text = new Label($"{notice.title} could not begin production — {notice.reason}")
                {
                    name = $"casting-expiry-notice-text-{notice.eventSeq}",
                };
                text.AddToClassList("attention");
                var projectId = notice.projectId;
                var reviewButton = new Button(() => ReviewExpiryNoticeProject(projectId))
                {
                    name = $"casting-expiry-notice-review-{notice.eventSeq}",
                    text = notice.reviewActionLabel,
                };
                row.Add(text);
                row.Add(reviewButton);
                expiryNoticesRoot.Add(row);
            }
        }

        /// <summary>An expiry notice's [Review package]: opens/rebinds the workspace to the exact projectId the notice named — the SAME re-targetable OpenCasting every world entry point uses.</summary>
        public void ReviewExpiryNoticeProject(string projectId) => openCastingForProjectFor(projectId);

        /// <summary>
        /// Role selection retargets the candidate list. Inspection only.
        /// Compare is scoped to the SELECTED role (Wave 5), so switching
        /// roles clears any pins/open compare layer along with it — a Lead
        /// pin has no meaning once the rail retargets to Antagonist.
        /// </summary>
        public void SelectRole(string roleKey)
        {
            if (context == null || project == null) return;
            if (Array.IndexOf(SelectableRoleKeys, roleKey) < 0) return;
            if (string.Equals(context.Role, roleKey, StringComparison.Ordinal)) return;
            context.Role = roleKey;
            context.CandidateId = null;
            context.ComparePins.Clear();
            context.CompareOpen = false;
            ClearPendingMove();
            RenderAll();
        }

        /// <summary>
        /// Row activation: select/inspect only. Mutates nothing else — Choose
        /// is the ONLY thing that ever fills a draft slot.
        ///
        /// P04A.2 (FINDING 4): inspection no longer cancels an armed Move.
        /// Reading someone is the one gesture that is defined to change
        /// nothing, and the person a player most wants to read at exactly that
        /// moment is the one the eviction line names ("Bram Cole leaves
        /// Antagonist." — who IS Bram Cole?). Clicking that row used to destroy
        /// the whole disclosure before it could be acted on, with no word said.
        /// Nothing about inspecting can falsify the prompt: this method refuses
        /// any talentId outside the CURRENT role's pool, so context.Role is
        /// unchanged, the draft is unchanged, and the pools are unchanged — the
        /// three facts the prompt asserts all still hold. The prompt still has
        /// its own explicit dismissals (Choose another instead / Esc), and the
        /// row block only ever renders for the mover's own row, so inspecting
        /// anybody else simply opens their dossier beneath the standing prompt.
        /// </summary>
        public void SelectCandidate(string talentId)
        {
            if (context == null || project == null) return;
            if (!PoolContains(context.Role, talentId)) return;
            context.CandidateId = talentId;
            RenderAll();
        }

        /// <summary>
        /// The Esc grammar's nested layers, most-nested first (Wave 5): the
        /// Wave-6 hand-off placeholder, then the compare layer, then a
        /// selected candidate (the open dossier) — leaving whatever is
        /// beneath exactly as it was. Returns false when there is nothing to
        /// peel, so the caller can fall through to closing the workspace root.
        /// </summary>
        public bool TryPeelDossier()
        {
            if (context == null) return false;

            // Wave 6: the receipt sits ABOVE the review in the peel stack —
            // Esc here never resubmits or reopens the review (already closed
            // by HandleGreenlightCommitAccepted); it simply lands on package,
            // exactly like every other Esc in this method only ever hides
            // one layer and leaves whatever is beneath untouched.
            if (greenlightReceiptShowing)
            {
                greenlightReceiptShowing = false;
                greenlightReceiptCopy = null;
                RenderAll();
                return true;
            }

            if (context.GreenlightReviewOpen)
            {
                context.GreenlightReviewOpen = false;
                RenderAll();
                return true;
            }

            if (context.CompareOpen)
            {
                context.CompareOpen = false;
                RenderAll();
                return true;
            }

            if (string.IsNullOrEmpty(context.CandidateId)) return false;
            context.CandidateId = null;
            ClearPendingMove();
            RenderAll();
            return true;
        }

        /// <summary>The plain-language camera-test phase line, shared with the world-entry card.</summary>
        public static string PhaseLine(string sessionStatus, int? dueWeek)
        {
            switch (sessionStatus)
            {
                case "notStarted":
                    return "Ready for camera tests";
                case "queued":
                    // BLOCKER 3(a) (design §C3): a queued request is waiting
                    // for a shared slot — it is NOT underway, and it has no
                    // due week it can honestly claim yet, so none is appended
                    // here (unlike the auditioning line below, which always
                    // has a real due week once testing actually starts).
                    return "Camera tests waiting for a shared slot";
                case "auditioning":
                    return dueWeek.HasValue
                        ? $"Camera tests underway · due Week {dueWeek.Value}"
                        : "Camera tests underway";
                case "review":
                    return "Camera-test review required";
                case "complete":
                    return "Complete";
                default:
                    return "Casting status unavailable";
            }
        }

        // ── Wave 4: planner entry/exit (local-only; no network call) ────────

        /// <summary>
        /// The explicit [Plan camera tests] entry. No preselection: a freshly
        /// entered planner's slate is exactly whatever the retained context
        /// already held (empty, the first time). Legal only from the Base
        /// view while the project has not yet started a session.
        /// </summary>
        public bool EnterScreenTestPlanner()
        {
            if (context == null || project == null) return false;
            if (!string.Equals(project.sessionStatus, StudioCastingProjectSnapshotSessionStatusValues.NotStarted, StringComparison.Ordinal))
                return false;
            context.PlannerActive = true;
            slateNotice = null;
            slateArmedAtRealtime = Time.realtimeSinceStartup;
            SlateChanged();
            RenderAll();
            return true;
        }

        /// <summary>
        /// The clearly secondary entry-point route: the direct package path
        /// (the Wave 3 role-first browsing this same shell already renders)
        /// stays exactly where it is. This never enters the planner and never
        /// touches the slate — it is honest precisely because its destination
        /// is the view already showing.
        /// </summary>
        public bool ContinueWithoutTests()
        {
            if (context == null) return false;
            context.PlannerActive = false;
            RenderAll();
            return true;
        }

        /// <summary>[Cancel]: discards the local slate only. Never reaches the authority.</summary>
        public bool CancelScreenTestPlanner()
        {
            if (context == null) return false;
            context.SlateLead.Clear();
            context.SlateAntagonist.Clear();
            context.SlateSupport.Clear();
            context.PlannerActive = false;
            slateNotice = null;
            SlateChanged();
            RenderAll();
            return true;
        }

        /// <summary>
        /// Adds a candidate to one role's screen-test slate — the ONLY way a
        /// candidate enters a read (no row-click preselection). Rejects a
        /// within-role duplicate or a full role locally, with named copy;
        /// cross-role duplicates (the same person reading for two roles) are
        /// allowed, per law.
        /// </summary>
        public bool AddToScreenTestSlate(string roleKey, string talentId)
        {
            if (context == null || project == null || string.IsNullOrEmpty(talentId)) return false;
            if (Array.IndexOf(ScreenTestRoleKeys, roleKey) < 0) return false;
            var slate = SlateFor(roleKey);
            if (slate == null) return false;
            var roleLabel = ScreenTestRoleLabelFor(roleKey);
            if (!PoolContains(roleKey, talentId))
            {
                slateNotice = $"That person is not offered for {roleLabel}.";
                RenderSlatePlanner(true);
                return false;
            }
            if (slate.Contains(talentId))
            {
                slateNotice = $"Already reading for {roleLabel}.";
                RenderSlatePlanner(true);
                return false;
            }
            if (slate.Count >= ScreenTestSlateSizePerRole)
            {
                slateNotice = $"{roleLabel} already has {ScreenTestSlateSizePerRole} readers.";
                RenderSlatePlanner(true);
                return false;
            }
            slate.Add(talentId);
            slateNotice = null;
            SlateChanged();
            RenderRoleRail();
            RenderCandidateList();
            RenderSlatePlanner(true);
            return true;
        }

        /// <summary>Removes one chip from a role's slate. Always legal (a slate can always shrink).</summary>
        public bool RemoveFromScreenTestSlate(string roleKey, string talentId)
        {
            if (context == null) return false;
            var slate = SlateFor(roleKey);
            if (slate == null || !slate.Remove(talentId)) return false;
            slateNotice = null;
            SlateChanged();
            RenderRoleRail();
            RenderCandidateList();
            RenderSlatePlanner(true);
            return true;
        }

        // ── Wave 4: quote lifecycle ───────────────────────────────────────────

        /// <summary>
        /// The MaintainQuote-precedent poll: invalidates a held quote the
        /// instant the live state revision moves past it (mirrors the
        /// Development card's own MaintainQuote), then — while the planner is
        /// open, the slate is complete/eligible, and nothing is already in
        /// flight — asks for a fresh one. A slate edit invalidates the held
        /// quote immediately (see <see cref="SlateChanged"/>), so this method
        /// only ever re-asks; it never itself decides staleness beyond the
        /// revision check.
        /// </summary>
        public void MaintainScreenTestQuote()
        {
            if (context == null || project == null) return;
            if (CurrentMode() != CastingWorkspaceMode.Planner) return;

            var revision = liveStateRevision();
            if (pendingScreenTestQuote != null && revision.HasValue && pendingScreenTestQuote.stateRevision != revision.Value)
            {
                pendingScreenTestQuote = null;
                screenTestQuoteDirty = true;
                RenderSlatePlanner(true);
            }

            if (!screenTestQuoteDirty || screenTestQuoteInFlight()) return;
            var draft = BuildScreenTestDraftIfComplete();
            if (draft == null) return;
            var commandId = requestScreenTestQuoteFor(draft);
            if (commandId == null) return;
            pendingScreenTestQuoteCommandId = commandId;
            screenTestQuoteDirty = false;
        }

        /// <summary>Forwards an accepted quote from the Host's subscription. Stale-for-revision quotes are dropped, re-arming a fresh ask.</summary>
        public void HandleScreenTestQuoteAccepted(StudioBridgeQuoteResponse quoted)
        {
            if (quoted == null || quoted.commandId != pendingScreenTestQuoteCommandId) return;
            if (!(quoted.quote is StudioCastingQuoteSnapshot member) || member.kind != StudioCastingQuoteSnapshotKindValues.StartAuditions) return;
            var revision = liveStateRevision();
            if (revision.HasValue && quoted.stateRevision != revision.Value)
            {
                screenTestQuoteDirty = true;
                return;
            }
            pendingScreenTestQuote = quoted;
            screenTestQuoteNotice = null;
            // A fresh quote re-arms the commit: the button that appears (or
            // relabels) under the consequence panel cannot swallow a stray
            // click that landed on the control that revealed it.
            slateArmedAtRealtime = Time.realtimeSinceStartup;
            RenderSlatePlanner(true);
        }

        /// <summary>
        /// Forwards the authority's structured refusal. Preserves all six
        /// slate choices — only the quote itself clears — and shows the
        /// authority's own TS-authored blocker/remedy sentence, never
        /// client-invented copy.
        /// </summary>
        public void HandleScreenTestQuoteRejected(StudioBridgeRejectedResponse rejected)
        {
            if (rejected == null || rejected.commandId != pendingScreenTestQuoteCommandId) return;
            pendingScreenTestQuoteCommandId = null;
            pendingScreenTestQuote = null;
            // P04A.2 — the exact twin of the greenlight latch below, and it
            // obeys the same one law. Two KINDS of refusal arrive here:
            //
            //   ENVELOPE refusals — the authority never looked at the slate.
            //     Bridge session.ts `quoteGuard` emits exactly two, in this
            //     order, from the same guard: SESSION_MISMATCH (the ask names a
            //     bridge session that is no longer the authority's) and
            //     STALE_REVISION (the ask named revision N; the authority has
            //     moved on). `rejectionFor` gives them the parallel envelope
            //     categories "session-mismatch" and "state-stale". Both say
            //     nothing whatever about the six reads. Both must RE-ARM: this
            //     handler has just cleared the held quote, and
            //     MaintainScreenTestQuote's revision-invalidation branch only
            //     re-arms while a quote is HELD — so without a re-arm here the
            //     planner latches off for good and no legal action revives it.
            //     Living Time makes STALE_REVISION ordinary (the week turns
            //     while the ask is in flight); SESSION_MISMATCH is rarer, but
            //     re-arming it is strictly more recoverable and cannot spin —
            //     StudioBridgeClient.RequestCastingQuote refuses to post at all
            //     unless ConnectionState is Live with no casting quote already
            //     in flight, and when it returns null MaintainScreenTestQuote
            //     leaves the dirty flag SET without sending anything. A re-arm
            //     therefore means only "ask again once the session is healthy".
            //
            //   DRAFT refusals — ENGINE_REJECTED, the authority reading THIS
            //     slate and saying no. These must NOT re-arm: re-asking an
            //     unchanged refused slate would loop forever (the Wave 7A-fix
            //     law). The escape is the documented one — edit the slate
            //     (SlateChanged re-arms), or leave and re-enter the planner.
            if (string.Equals(
                    rejected.reasonCode,
                    StudioBridgeRejectedResponseReasonCodeValues.STALEREVISION,
                    StringComparison.Ordinal) ||
                string.Equals(
                    rejected.reasonCode,
                    StudioBridgeRejectedResponseReasonCodeValues.SESSIONMISMATCH,
                    StringComparison.Ordinal))
                screenTestQuoteDirty = true;
            screenTestQuoteNotice = rejected.rejection != null
                ? rejected.rejection.blocker + " " + rejected.rejection.remedy
                : rejected.message;
            RenderSlatePlanner(true);
        }

        /// <summary>An unresolved quote simply re-asks; nothing about the slate changes.</summary>
        public void HandleScreenTestQuoteUnresolved(string message)
        {
            pendingScreenTestQuoteCommandId = null;
            screenTestQuoteDirty = true;
            screenTestQuoteNotice = message;
            RenderSlatePlanner(true);
        }

        /// <summary>True once the arm window has passed since the commit control last (re)appeared — the shared 0.7s law.</summary>
        public bool ScreenTestCommitArmed =>
            StudioFoundingCardContracts.CommitArmed(slateArmedAtRealtime, Time.realtimeSinceStartup);

        /// <summary>
        /// Commits the held quote through the ordinary intent path, exactly
        /// once, and only while armed. A stale quote (the live revision moved
        /// since it was minted) is dropped rather than committed — the next
        /// MaintainScreenTestQuote poll asks fresh.
        /// </summary>
        public bool CommitScreenTestQuote()
        {
            if (context == null || project == null) return false;
            if (CurrentMode() != CastingWorkspaceMode.Planner) return false;
            if (!ScreenTestCommitArmed) return false;
            var quote = pendingScreenTestQuote;
            if (quote == null) return false;
            var revision = liveStateRevision();
            if (!revision.HasValue || quote.stateRevision != revision.Value)
            {
                pendingScreenTestQuote = null;
                screenTestQuoteDirty = true;
                RenderSlatePlanner(true);
                return false;
            }
            // Consumed immediately: even a second call landing inside the
            // same frame (before any re-arm or snapshot refresh) finds no
            // quote and refuses, guaranteeing exactly one dispatch per
            // accepted quote regardless of click cadence.
            pendingScreenTestQuote = null;
            var dispatched = commitScreenTestQuoteFor(quote.quote);
            if (!dispatched) screenTestQuoteDirty = true;
            RenderSlatePlanner(true);
            return dispatched;
        }

        // ── Wave 4: review acknowledge ────────────────────────────────────────

        /// <summary>
        /// [Continue to Casting]: submits the acknowledge intent exactly once
        /// per review session. Guarded by the session's own id, not a raw
        /// click latch, so a slow round trip cannot be double-dispatched and
        /// a genuinely NEW review session (a later sessionId) is never
        /// permanently locked out by an earlier one's guard.
        /// </summary>
        public bool ContinueToCasting()
        {
            if (project == null) return false;
            if (!string.IsNullOrEmpty(project.sessionId) &&
                string.Equals(acknowledgedForSessionId, project.sessionId, StringComparison.Ordinal))
                return false;
            var dispatched = acknowledgeReviewFor(project.projectId);
            if (dispatched) acknowledgedForSessionId = project.sessionId;
            RenderReview(CurrentMode() == CastingWorkspaceMode.Review);
            return dispatched;
        }

        // ── rendering ───────────────────────────────────────────────────────

        private void RenderEmpty()
        {
            // Wave 6: "missing project join fails closed to showing the
            // projectId" — an expiry notice's [Review package] (or any other
            // OpenCasting) targeting a projectId the live board no longer
            // carries renders the raw id rather than a silent generic label,
            // so the player can see exactly which project could not be
            // found, instead of a plain, unexplained "Casting".
            titleLabel.text = context != null && !string.IsNullOrEmpty(context.ProjectId)
                ? $"Casting · {context.ProjectId}"
                : "Casting";
            phaseLabel.text = string.Empty;
            roleRail.style.display = DisplayStyle.None;
            uniquePeopleLabel.style.display = DisplayStyle.None;
            sortLabel.style.display = DisplayStyle.None;
            candidateList.Clear();
            dossier.style.display = DisplayStyle.None;
            dossier.Clear();
            planTestsButton.style.display = DisplayStyle.None;
            continueWithoutTestsButton.style.display = DisplayStyle.None;
            slatePlannerRoot.style.display = DisplayStyle.None;
            underwayRoot.style.display = DisplayStyle.None;
            reviewRoot.style.display = DisplayStyle.None;
            compareBar.style.display = DisplayStyle.None;
            compareRoot.style.display = DisplayStyle.None;
            compareColumnsContainer.Clear();
            budgetSectionRoot.style.display = DisplayStyle.None;
            readinessRoot.style.display = DisplayStyle.None;
            reviewGreenlightButton.SetEnabled(false);
            greenlightReviewRoot.style.display = DisplayStyle.None;
            glFooter.style.display = DisplayStyle.None;
        }

        /// <summary>
        /// Wave 6: the bound project is null (it left the casting board, or
        /// was never found) but a greenlight commit this workspace itself
        /// submitted is either still in flight or has already resolved to a
        /// receipt — never collapse to the generic empty state in that
        /// specific window; keep only the greenlight panel/receipt visible,
        /// using the captured quote facts since there is no live project row
        /// left to read from.
        /// </summary>
        private void RenderGreenlightOnlyState()
        {
            titleLabel.text = !string.IsNullOrEmpty(greenlightExpectedTitle)
                ? greenlightExpectedTitle
                : (context != null && !string.IsNullOrEmpty(context.ProjectId) ? $"Casting · {context.ProjectId}" : "Casting");
            phaseLabel.text = string.Empty;
            roleRail.style.display = DisplayStyle.None;
            uniquePeopleLabel.style.display = DisplayStyle.None;
            sortLabel.style.display = DisplayStyle.None;
            candidateList.Clear();
            dossier.style.display = DisplayStyle.None;
            dossier.Clear();
            planTestsButton.style.display = DisplayStyle.None;
            continueWithoutTestsButton.style.display = DisplayStyle.None;
            slatePlannerRoot.style.display = DisplayStyle.None;
            underwayRoot.style.display = DisplayStyle.None;
            reviewRoot.style.display = DisplayStyle.None;
            compareBar.style.display = DisplayStyle.None;
            compareRoot.style.display = DisplayStyle.None;
            compareColumnsContainer.Clear();
            budgetSectionRoot.style.display = DisplayStyle.None;
            readinessRoot.style.display = DisplayStyle.None;
            reviewGreenlightButton.SetEnabled(false);

            RenderGreenlightReview(true, greenlightReceiptShowing);
        }

        private CastingWorkspaceMode CurrentMode()
        {
            if (project == null) return CastingWorkspaceMode.Base;
            switch (project.sessionStatus)
            {
                case StudioCastingProjectSnapshotSessionStatusValues.Queued:
                case StudioCastingProjectSnapshotSessionStatusValues.Auditioning:
                    return CastingWorkspaceMode.Underway;
                case StudioCastingProjectSnapshotSessionStatusValues.Review:
                    return CastingWorkspaceMode.Review;
                case StudioCastingProjectSnapshotSessionStatusValues.NotStarted:
                    return context != null && context.PlannerActive ? CastingWorkspaceMode.Planner : CastingWorkspaceMode.Base;
                default:
                    return CastingWorkspaceMode.Base;
            }
        }

        /// <summary>The one render entry point every local mutation and every Bind funnels through.</summary>
        private void RenderAll()
        {
            if (project == null)
            {
                if (GreenlightCommitPending)
                {
                    RenderGreenlightOnlyState();
                    return;
                }
                RenderEmpty();
                return;
            }

            RenderHeader();
            var mode = CurrentMode();
            // Wave 5/6: the package draft (role choose/replace/remove,
            // compare, budgets, readiness, [Review Greenlight]) attaches to
            // the SAME Base state Wave 3 already renders — i.e. exactly the
            // "notStarted (not planning)" and "complete" phases named in the
            // task. The real Greenlight review (and, once accepted, the
            // receipt) takes the whole panel over while either is open; the
            // compare layer takes over just the candidate-list/dossier area
            // while IT is open.
            var showGreenlightReceipt = greenlightReceiptShowing;
            var greenlightReviewOpen = showGreenlightReceipt ||
                (mode == CastingWorkspaceMode.Base && context != null && context.GreenlightReviewOpen);
            var packagePanelVisible = mode == CastingWorkspaceMode.Base && !greenlightReviewOpen;
            var compareOpen = packagePanelVisible && context != null && context.CompareOpen;
            var baseShellVisible = (mode == CastingWorkspaceMode.Base || mode == CastingWorkspaceMode.Planner) && !greenlightReviewOpen;

            roleRail.style.display = baseShellVisible ? DisplayStyle.Flex : DisplayStyle.None;
            sortLabel.style.display = (baseShellVisible && !compareOpen) ? DisplayStyle.Flex : DisplayStyle.None;
            if (baseShellVisible)
            {
                RenderRoleRail();
                if (!compareOpen)
                {
                    RenderCandidateList();
                    RenderDossier();
                }
                else
                {
                    candidateList.Clear();
                    dossier.style.display = DisplayStyle.None;
                    dossier.Clear();
                }
            }
            else
            {
                uniquePeopleLabel.style.display = DisplayStyle.None;
                candidateList.Clear();
                dossier.style.display = DisplayStyle.None;
                dossier.Clear();
            }

            var showEntryActions = mode == CastingWorkspaceMode.Base && !greenlightReviewOpen &&
                string.Equals(project.sessionStatus, StudioCastingProjectSnapshotSessionStatusValues.NotStarted, StringComparison.Ordinal);
            planTestsButton.style.display = showEntryActions ? DisplayStyle.Flex : DisplayStyle.None;
            continueWithoutTestsButton.style.display = showEntryActions ? DisplayStyle.Flex : DisplayStyle.None;

            RenderSlatePlanner(mode == CastingWorkspaceMode.Planner);
            RenderUnderway(mode == CastingWorkspaceMode.Underway);
            RenderReview(mode == CastingWorkspaceMode.Review);

            RenderCompareBar(packagePanelVisible);
            RenderCompare(compareOpen);
            RenderBudgetPickers(packagePanelVisible);
            RenderReadiness(packagePanelVisible);
            RenderGreenlightReview(greenlightReviewOpen, showGreenlightReceipt);
        }

        private void RenderHeader()
        {
            titleLabel.text = $"{project.title} · {project.genre} · Writer: {project.writerName}";
            phaseLabel.text = PhaseLine(project.sessionStatus, project.dueWeek);
        }

        private void RenderRoleRail()
        {
            // P04A.2 §11: the rail row keeps its position (it is the one place
            // the whole company reads top-to-bottom) but must no longer read
            // as a SLOT. "Locked" described a seat that could not be changed;
            // "Screenplay credit" describes what this actually is — a
            // permanent authorship credit that is never an availability claim
            // on the person. Still non-clickable, still 0.85 opacity: it is
            // information, not a role you cast.
            writerRow.Text.text = $"Writer · Screenplay credit · {project.writerName}";
            var planning = context != null && context.PlannerActive;
            for (var index = 0; index < selectableRows.Length; index++)
            {
                var row = selectableRows[index];
                var count = PoolFor(row.RoleKey).Length;
                var screenTestIndex = Array.IndexOf(ScreenTestRoleKeys, row.RoleKey);
                if (planning && screenTestIndex >= 0)
                {
                    var chosen = SlateFor(row.RoleKey)?.Count ?? 0;
                    row.Text.text =
                        $"{SelectableRoleLabels[index]} · {chosen}/{ScreenTestSlateSizePerRole} chosen · {count} candidate{(count == 1 ? "" : "s")}";
                    row.Element.RemoveFromClassList("blocked");
                }
                else
                {
                    // Wave 5: the package draft's own fill state — "Unfilled"
                    // until an explicit Choose, then name+fit, then "Unavailable
                    // now — <reason>" the instant the live pool says so. Never
                    // auto-replaced: the draft id stays exactly what the player
                    // chose regardless of what this row says.
                    var status = RoleRailStatus(row.RoleKey, index);
                    row.Text.text = status.filled
                        ? $"{SelectableRoleLabels[index]} · {status.line}"
                        : $"{SelectableRoleLabels[index]} · Unfilled · {count} candidate{(count == 1 ? "" : "s")}";
                    if (status.blocked) row.Element.AddToClassList("blocked");
                    else row.Element.RemoveFromClassList("blocked");
                }
                if (string.Equals(row.RoleKey, context.Role, StringComparison.Ordinal))
                {
                    // A3: selection state must never be colour-only — the
                    // .selected left-border colour is joined by a leading
                    // marker and explicit words, so the active role reads
                    // unmistakably even without colour vision.
                    row.Element.AddToClassList("selected");
                    row.Text.text = $"▸ {row.Text.text} · CASTING NOW";
                }
                else
                {
                    row.Element.RemoveFromClassList("selected");
                }
            }

            if (planning)
            {
                uniquePeopleLabel.text = $"Unique people chosen: {UniquePeopleCount()}";
                uniquePeopleLabel.style.display = DisplayStyle.Flex;
            }
            else
            {
                uniquePeopleLabel.style.display = DisplayStyle.None;
            }
        }

        private void RenderCandidateList()
        {
            candidateList.Clear();
            if (context?.Role == null) return;
            var pool = PoolFor(context.Role);
            var planningThisRole = context.PlannerActive && Array.IndexOf(ScreenTestRoleKeys, context.Role) >= 0;
            for (var index = 0; index < pool.Length; index++)
            {
                var candidate = pool[index];
                if (candidate == null || string.IsNullOrWhiteSpace(candidate.talentId)) continue;
                candidateList.Add(BuildCandidateRow(candidate, planningThisRole));
            }
        }

        private VisualElement BuildCandidateRow(StudioCastingCandidateSnapshot candidate, bool showAddToTest)
        {
            var row = new VisualElement { name = $"casting-candidate-{candidate.talentId}" };
            row.AddToClassList("casting-candidate-row");
            var isInspected = string.Equals(candidate.talentId, context.CandidateId, StringComparison.Ordinal);
            if (isInspected) row.AddToClassList("selected");
            row.RegisterCallback<ClickEvent>(_ => SelectCandidate(candidate.talentId));

            var identity = new Label($"{candidate.name} — {candidate.professionLabel} · {BadgeText(candidate.contractBadge)}");
            var stats = new Label($"OVR {candidate.ovr} · {RoleLabelFor(context.Role)} FIT {candidate.fit}");
            var evidence = new Label(candidate.evidence != null ? "Evidence: tested" : "Not tested");
            evidence.AddToClassList("meta");
            var availability = new Label(candidate.availabilityLabel);
            availability.AddToClassList("meta");
            var cost = new Label(candidate.projectCostLabel);
            cost.AddToClassList("meta");
            var signal = StrongestSignal(candidate);
            var signalLabel = new Label(signal != null ? signal.text : string.Empty);
            signalLabel.AddToClassList("meta");

            row.Add(identity);

            // ── P04A.2 (2): CROSS-ROLE ACTOR CLARITY. An actor already cast
            // in a DIFFERENT draft role used to fall straight into the bare
            // else branch below and render "Choose for <this role>" with NO
            // assignment text at all — the conflict was disclosed only AFTER
            // a click, inside ChooseForRole → FindOccupiedRole. This badge
            // sits immediately below the name, is visible WITHOUT opening the
            // dossier, WITHOUT clicking Choose and WITHOUT a tooltip, and is
            // TEXT (colour/border/tint alone would be forbidden).
            //
            // FindOccupiedRole excludes the role being viewed AND the writer
            // (it walks SelectableRoleKeys only, and under P04A.2 product law
            // a screenplay CREDIT is never a seat, never an availability
            // blocker), so the current role's own occupant keeps the SELECTED
            // FOR badge below and never doubles up here.
            //
            // Deliberately a DIFFERENT element name and a DIFFERENT text
            // prefix from that badge: the sealed P04A.1 regression asserts a
            // NON-OCCUPANT row carries no Label named casting-row-selected-{id}
            // and no Label whose text starts with "SELECTED FOR". That
            // assertion is untouched — this badge coexists with it.
            var castElsewhereRole = FindOccupiedRole(candidate.talentId, context.Role);
            if (castElsewhereRole != null)
            {
                var castAsBadge = new Label($"CAST AS {RoleLabelFor(castElsewhereRole).ToUpperInvariant()}")
                {
                    name = $"casting-row-castas-{candidate.talentId}",
                };
                castAsBadge.AddToClassList("casting-row-castas-badge");
                row.Add(castAsBadge);
            }

            row.Add(stats);

            if (isInspected)
            {
                // A3: selection state must never be colour-only — the
                // .selected left-border colour change is joined by an
                // explicit text marker, so an inspected row is unmistakable
                // even without colour vision.
                var inspecting = new Label("INSPECTING") { name = $"casting-row-inspecting-{candidate.talentId}" };
                inspecting.AddToClassList("casting-row-inspecting-badge");
                row.Add(inspecting);
            }

            // ── A2: an explicit, named assignment control on the row itself
            // — casting must never require reaching the dossier below the
            // whole candidate list. Routes through the SAME
            // ChooseForRole(roleKey, talentId) / RemoveFromRole(roleKey) the
            // dossier already uses; never a second mutation path. The row's
            // own click handler above stays SelectCandidate-only — nothing
            // added here changes what a plain click on the row does. ───────
            var roleKey = context.Role;
            var roleLabel = RoleLabelFor(roleKey);
            var currentOccupant = GetDraftValue(roleKey);
            var isCurrentOccupant = !string.IsNullOrEmpty(currentOccupant) &&
                string.Equals(currentOccupant, candidate.talentId, StringComparison.Ordinal);
            var isPendingMoveForThis = pendingMoveTalentId != null &&
                string.Equals(pendingMoveTalentId, candidate.talentId, StringComparison.Ordinal) &&
                string.Equals(pendingMoveTargetRole, roleKey, StringComparison.Ordinal);

            var rowActions = new VisualElement { name = $"casting-row-actions-{candidate.talentId}" };
            rowActions.AddToClassList("casting-row-actions");

            if (isPendingMoveForThis)
            {
                // The duplicate-person conflict a row-initiated Choose just
                // armed (ChooseForRole returned false without mutating
                // either slot) — surfaced here too, not only in the
                // dossier, since the dossier may not even be showing this
                // candidate. Exactly the dossier's own atomic pair: Move
                // performs the one complete edit; Cancel touches neither
                // slot. Same delegates, never a second mutation path.
                var conflictLabel = new Label($"Already cast as {RoleLabelFor(pendingMoveFromRole)}.")
                {
                    name = $"casting-row-conflict-{candidate.talentId}",
                };
                conflictLabel.AddToClassList("attention");
                rowActions.Add(conflictLabel);

                // P04A.2 §13: and the OTHER half of the move's effect — the
                // person the target role is about to lose. Filling that slot
                // displaces whoever holds it, silently until now. Stated
                // BEFORE the press, in the same block as the control, so the
                // one atomic edit is fully readable in advance. Disclosure
                // only: the move is not blocked and gains no second step.
                var rowEvictionLine = PendingMoveEvictionLine();
                if (rowEvictionLine != null)
                {
                    var evictionLabel = new Label(rowEvictionLine)
                    {
                        name = $"casting-row-move-evicts-{candidate.talentId}",
                    };
                    evictionLabel.AddToClassList("attention");
                    rowActions.Add(evictionLabel);
                }

                // P04A.2 §13: the atomic move already existed
                // (ConfirmMoveForRole clears the old slot and fills the new
                // one in ONE call); what it never did was name where the
                // person ends up. Naming BOTH ends makes the one control's
                // whole effect readable before it is pressed.
                var moveButton = new Button(() => ConfirmMoveForRole())
                {
                    name = $"casting-row-move-{candidate.talentId}",
                    text = $"MOVE FROM {RoleLabelFor(pendingMoveFromRole).ToUpperInvariant()} " +
                           $"TO {RoleLabelFor(pendingMoveTargetRole).ToUpperInvariant()}",
                };
                moveButton.AddToClassList("primary-action");
                rowActions.Add(moveButton);

                var cancelMoveButton = new Button(() => CancelPendingMove())
                {
                    name = $"casting-row-move-cancel-{candidate.talentId}",
                    text = "Choose another instead",
                };
                cancelMoveButton.AddToClassList("meta");
                rowActions.Add(cancelMoveButton);
            }
            else if (isCurrentOccupant)
            {
                var badge = new Label($"SELECTED FOR {roleLabel.ToUpperInvariant()}")
                {
                    name = $"casting-row-selected-{candidate.talentId}",
                };
                badge.AddToClassList("casting-row-selected-badge");
                rowActions.Add(badge);

                var removeButton = new Button(() => RemoveFromRole(roleKey))
                {
                    name = $"casting-row-remove-{candidate.talentId}",
                    text = $"Remove from {roleLabel}",
                };
                rowActions.Add(removeButton);
            }
            else
            {
                var chooseText = string.IsNullOrEmpty(currentOccupant)
                    ? $"Choose for {roleLabel}"
                    : $"Replace with {candidate.name}";
                var chooseButton = new Button(() => ChooseForRole(roleKey, candidate.talentId))
                {
                    name = $"casting-row-choose-{candidate.talentId}",
                    text = chooseText,
                };
                rowActions.Add(chooseButton);
            }

            // Lead integration fix: the action block sits DIRECTLY under the
            // identity and the two headline numbers, ahead of the four
            // supporting detail lines — decision first, evidence after.
            //
            // Order matters here, measured rather than assumed. In the packaged
            // player at 1440x900 the scroll viewport is 580px of panel space and
            // the header + role rail + sort line already consume 472 of it, so a
            // candidate row starts at y=586 with the viewport ending at y=694.
            // With the action block appended LAST it landed around y=760-804 —
            // still below the fold on open, which is the same failure the Owner
            // hit, only one scroll shallower. Placed here the first candidate's
            // [Choose for <Role>] is visible the moment Casting opens, with no
            // scrolling and no instructions.
            row.Add(rowActions);

            row.Add(evidence);
            row.Add(availability);
            row.Add(cost);
            row.Add(signalLabel);

            if (showAddToTest)
            {
                var testRoleKey = context.Role;
                var testRoleLabel = ScreenTestRoleLabelFor(testRoleKey);
                var addButton = new Button(() => AddToScreenTestSlate(testRoleKey, candidate.talentId))
                {
                    name = $"casting-slate-add-{candidate.talentId}",
                    text = $"Add to {testRoleLabel} test",
                };
                var slate = SlateFor(testRoleKey);
                var alreadyIn = slate != null && slate.Contains(candidate.talentId);
                var full = slate != null && slate.Count >= ScreenTestSlateSizePerRole;
                addButton.SetEnabled(!alreadyIn && !full);
                row.Add(addButton);
            }

            return row;
        }

        private void RenderDossier()
        {
            dossier.Clear();
            var candidate = SelectedCandidate();
            if (candidate == null)
            {
                dossier.style.display = DisplayStyle.None;
                return;
            }
            dossier.style.display = DisplayStyle.Flex;

            var portrait = new VisualElement { name = "casting-dossier-portrait" };
            portrait.AddToClassList("casting-dossier-portrait");
            dossier.Add(portrait);

            dossier.Add(new Label($"{candidate.name} — {candidate.professionLabel} · {BadgeText(candidate.contractBadge)}"));

            // P04A.2 (2): the dossier is the DEEPEST inspection surface — the
            // one a player opens precisely to decide — and it used to be the
            // only appearance of an assigned actor carrying no assignment
            // text at all. The row and the comparison column both disclose it;
            // this closes the third. Directly under the name, above every
            // number, so the fact is read before the judgement is formed.
            AddDossierDraftBadge(candidate.talentId, context.Role);

            var ovr = new Label($"OVR {candidate.ovr}") { name = "casting-dossier-ovr" };
            ovr.AddToClassList("casting-dossier-bignumber");
            var fit = new Label($"{RoleLabelFor(context.Role)} FIT {candidate.fit}") { name = "casting-dossier-fit" };
            fit.AddToClassList("casting-dossier-bignumber");
            dossier.Add(ovr);
            dossier.Add(fit);

            dossier.Add(new Label(
                $"EP {candidate.epLow}–{candidate.epHigh} · expected {candidate.epExpected}"));

            if (candidate.signals != null)
            {
                for (var index = 0; index < candidate.signals.Length; index++)
                {
                    var signalSnapshot = candidate.signals[index];
                    if (signalSnapshot == null) continue;
                    var signalLine = new Label(signalSnapshot.text);
                    switch (signalSnapshot.kind)
                    {
                        case "concern":
                            signalLine.AddToClassList("blocked");
                            break;
                        case "action":
                            signalLine.AddToClassList("attention");
                            break;
                    }
                    dossier.Add(signalLine);
                }
            }

            var roleLabel = RoleLabelFor(context.Role);
            dossier.Add(new Label(candidate.evidence != null
                ? $"Camera-tested for {roleLabel}: est ~{candidate.evidence.estimate} " +
                  $"(range {candidate.evidence.low}–{candidate.evidence.high})"
                : $"Not camera-tested for {roleLabel}"));

            dossier.Add(new Label(candidate.genreExperienceLabel));
            dossier.Add(new Label($"Commercial signal · Star Power {candidate.starPower}"));
            dossier.Add(new Label(candidate.available
                ? candidate.availabilityLabel
                : $"{candidate.availabilityLabel} · {candidate.currentWorkLabel}"));
            dossier.Add(new Label(candidate.projectCostLabel));

            var disclosure = new Label(DisclosureLine) { name = "casting-dossier-disclosure" };
            disclosure.AddToClassList("meta");
            dossier.Add(disclosure);

            var actions = new VisualElement { name = "casting-dossier-actions" };
            var locateStableId = resolveLocateStableId(candidate.talentId);
            var locateButton = new Button(() => HandleLocateClicked(locateStableId))
            {
                name = "casting-locate",
                text = "Locate in world",
            };
            locateButton.SetEnabled(!string.IsNullOrEmpty(locateStableId));
            actions.Add(locateButton);

            // ── Wave 5: Choose/Replace/Remove — the ONLY controls that ever
            // fill, replace, or clear a draft slot. Every one of these is a
            // purely local edit: no submit, no quote, ever. ─────────────────
            var roleKeyForActions = context.Role;
            var roleLabelForActions = RoleLabelFor(roleKeyForActions);
            var currentOccupant = GetDraftValue(roleKeyForActions);
            var isCurrentOccupant = !string.IsNullOrEmpty(currentOccupant) &&
                string.Equals(currentOccupant, candidate.talentId, StringComparison.Ordinal);
            var isPendingMoveForThis = pendingMoveTalentId != null &&
                string.Equals(pendingMoveTalentId, candidate.talentId, StringComparison.Ordinal) &&
                string.Equals(pendingMoveTargetRole, roleKeyForActions, StringComparison.Ordinal);

            if (isPendingMoveForThis)
            {
                // Duplicate-person law: never a partial state. Neither slot
                // has changed yet — only [Move from <Role>] performs the
                // atomic edit (clear the old slot AND fill the new one in
                // ONE call); "or choose another" is simply not clicking it.
                var conflictLabel = new Label(
                    $"{candidate.name} is already cast as {RoleLabelFor(pendingMoveFromRole)} in this package.")
                {
                    name = "casting-move-conflict",
                };
                conflictLabel.AddToClassList("attention");
                dossier.Insert(dossier.IndexOf(disclosure) + 1, conflictLabel);

                // P04A.2 §13: the dossier twin of the row's displacement
                // line — inserted directly BELOW the conflict sentence, so
                // the two halves of the move's effect (where the mover goes,
                // who consequently leaves) are read together and before the
                // control below is pressed.
                var dossierEvictionLine = PendingMoveEvictionLine();
                if (dossierEvictionLine != null)
                {
                    var evictionLabel = new Label(dossierEvictionLine) { name = "casting-move-evicts" };
                    evictionLabel.AddToClassList("attention");
                    dossier.Insert(dossier.IndexOf(conflictLabel) + 1, evictionLabel);
                }

                // P04A.2 §13: the dossier twin of the row control — same
                // delegate, same atomic edit, and now the same both-ends name.
                var moveButton = new Button(() => ConfirmMoveForRole())
                {
                    name = "casting-move",
                    text = $"MOVE FROM {RoleLabelFor(pendingMoveFromRole).ToUpperInvariant()} " +
                           $"TO {RoleLabelFor(pendingMoveTargetRole).ToUpperInvariant()}",
                };
                moveButton.AddToClassList("primary-action");
                var cancelMoveButton = new Button(() => CancelPendingMove())
                {
                    name = "casting-move-cancel",
                    text = "Choose another instead",
                };
                cancelMoveButton.AddToClassList("meta");
                actions.Add(moveButton);
                actions.Add(cancelMoveButton);
            }
            else if (isCurrentOccupant)
            {
                var castLabel = new Label($"Cast as {roleLabelForActions} in this package draft.") { name = "casting-cast-label" };
                castLabel.AddToClassList("meta");
                dossier.Insert(dossier.IndexOf(disclosure) + 1, castLabel);

                var removeButton = new Button(() => RemoveFromRole(roleKeyForActions))
                {
                    name = "casting-remove",
                    text = $"Remove from {roleLabelForActions}",
                };
                actions.Add(removeButton);
            }
            else
            {
                var chooseLabel = string.IsNullOrEmpty(currentOccupant)
                    ? $"Choose {candidate.name} for {roleLabelForActions}"
                    : $"Replace with {candidate.name}";
                var chooseButton = new Button(() => ChooseForRole(roleKeyForActions, candidate.talentId))
                {
                    name = "casting-choose",
                    text = chooseLabel,
                };
                actions.Add(chooseButton);
            }

            var pinned = context.ComparePins.Contains(candidate.talentId);
            var pinButton = new Button(() => TogglePinForCompare(candidate.talentId))
            {
                name = "casting-pin-compare",
                text = pinned ? "Unpin from compare" : "Pin to compare",
            };
            pinButton.SetEnabled(pinned || context.ComparePins.Count < 4);
            actions.Add(pinButton);

            if (context.PlannerActive && Array.IndexOf(ScreenTestRoleKeys, context.Role) >= 0)
            {
                var roleKey = context.Role;
                var roleLabelForRole = ScreenTestRoleLabelFor(roleKey);
                var addButton = new Button(() => AddToScreenTestSlate(roleKey, candidate.talentId))
                {
                    name = "casting-slate-add",
                    text = $"Add to {roleLabelForRole} test",
                };
                var slate = SlateFor(roleKey);
                var alreadyIn = slate != null && slate.Contains(candidate.talentId);
                var full = slate != null && slate.Count >= ScreenTestSlateSizePerRole;
                addButton.SetEnabled(!alreadyIn && !full);
                actions.Add(addButton);
            }

            dossier.Add(actions);
        }

        private void RenderSlatePlanner(bool visible)
        {
            if (!visible || context == null || project == null)
            {
                slatePlannerRoot.style.display = DisplayStyle.None;
                return;
            }
            slatePlannerRoot.style.display = DisplayStyle.Flex;

            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var roleKey = ScreenTestRoleKeys[index];
                var container = slateRoleRows[index];
                container.Clear();
                var slate = SlateFor(roleKey);
                var header = new Label($"{ScreenTestRoleLabels[index]} · {slate.Count}/{ScreenTestSlateSizePerRole} chosen");
                header.AddToClassList("meta");
                container.Add(header);
                foreach (var talentId in slate)
                {
                    var capturedRoleKey = roleKey;
                    var capturedTalentId = talentId;
                    var candidate = FindCandidateInPool(roleKey, talentId);
                    var name = candidate?.name ?? talentId;
                    var ineligible = candidate != null && !candidate.available;
                    var chipText = ineligible
                        ? $"{name} — Unavailable: {candidate.availabilityLabel}"
                        : $"{name} ×";
                    var chip = new Button(() => RemoveFromScreenTestSlate(capturedRoleKey, capturedTalentId))
                    {
                        name = $"casting-slate-chip-{roleKey}-{talentId}",
                        text = chipText,
                    };
                    if (ineligible) chip.AddToClassList("blocked");
                    container.Add(chip);

                    // P04A.2 (FINDING 5): law (2) says an actor assigned in the
                    // draft carries VISIBLE TEXT on EVERY appearance. The slate
                    // chip is an appearance — and on this very screen the same
                    // person is badged in the candidate list beside it, so a
                    // bare name here contradicted the badge two panels over.
                    // Same two sentences, same words, derived the same way
                    // (GetDraftValue / FindOccupiedRole, which walk the five
                    // selectable seats only — a screenplay credit is never a
                    // seat). A DISTINCT element name, so no frozen row,
                    // dossier, compare or chip assertion is disturbed: the chip
                    // Button keeps casting-slate-chip-{role}-{id} and its exact
                    // text, and this Label is a sibling beside it.
                    var slateBadgeText = SlateChipAssignmentText(roleKey, talentId);
                    if (slateBadgeText != null)
                    {
                        var slateBadge = new Label(slateBadgeText)
                        {
                            name = $"casting-slate-chip-assignment-{roleKey}-{talentId}",
                        };
                        slateBadge.AddToClassList(
                            slateBadgeText.StartsWith("SELECTED FOR", StringComparison.Ordinal)
                                ? "casting-row-selected-badge"
                                : "casting-row-castas-badge");
                        container.Add(slateBadge);
                    }
                }
            }

            var gap = CompletenessGapMessage();
            slateCompletenessLabel.text = gap ?? string.Empty;
            slateCompletenessLabel.style.display = gap != null ? DisplayStyle.Flex : DisplayStyle.None;

            var notice = screenTestQuoteNotice ?? slateNotice;
            slateNoticeLabel.text = notice ?? string.Empty;
            slateNoticeLabel.style.display = notice != null ? DisplayStyle.Flex : DisplayStyle.None;

            var quote = pendingScreenTestQuote?.quote as StudioCastingQuoteSnapshot;
            if (quote != null)
            {
                slateConsequenceRoot.style.display = DisplayStyle.Flex;
                slateConsequenceWeekLabel.text = quote.weekLine ?? string.Empty;
                slateConsequenceSlotLabel.text = quote.slotLine ?? string.Empty;
                slateConsequenceNoFeeLabel.text = quote.noFeeLine ?? string.Empty;
                slateConsequenceNoHoldLabel.text = quote.noHoldLine ?? string.Empty;
                slateConsequenceUniqueLabel.text =
                    quote.uniquePeople.HasValue ? $"Unique people confirmed: {quote.uniquePeople.Value}" : string.Empty;
                // BLOCKER 3(c): mirrors RenderGlCapacity's own showQueueNote
                // gate exactly — queueNote is shown only when the quote
                // itself says it queues AND carries a non-empty note.
                var showQueueNote = quote.queues && !string.IsNullOrEmpty(quote.queueNote);
                slateConsequenceQueueNoteLabel.text = showQueueNote ? quote.queueNote : string.Empty;
                slateConsequenceQueueNoteLabel.style.display = showQueueNote ? DisplayStyle.Flex : DisplayStyle.None;
            }
            else
            {
                slateConsequenceRoot.style.display = DisplayStyle.None;
            }

            var revision = liveStateRevision();
            var quoteFresh = quote != null && (!revision.HasValue || pendingScreenTestQuote.stateRevision == revision.Value);
            var canStart = gap == null && quoteFresh && screenTestActionsEnabled() && ScreenTestCommitArmed;
            slateStartButton.SetEnabled(canStart);
        }

        /// <summary>
        /// P04A.2 (FINDING 5): the one assignment sentence a slate chip owes,
        /// or null when the person holds no draft seat at all. Identical in
        /// wording and derivation to the row, dossier and compare badges: the
        /// occupant of the role whose slate this is reads "SELECTED FOR
        /// &lt;ROLE&gt;", anyone holding a DIFFERENT draft seat reads "CAST AS
        /// &lt;ROLE&gt;". The three screen-test roles are all selectable seats,
        /// so RoleLabelFor names them exactly as every other surface does.
        /// </summary>
        private string SlateChipAssignmentText(string roleKey, string talentId)
        {
            if (string.IsNullOrEmpty(talentId) || string.IsNullOrEmpty(roleKey)) return null;
            if (string.Equals(GetDraftValue(roleKey), talentId, StringComparison.Ordinal))
                return $"SELECTED FOR {RoleLabelFor(roleKey).ToUpperInvariant()}";
            var castElsewhereRole = FindOccupiedRole(talentId, roleKey);
            return castElsewhereRole == null
                ? null
                : $"CAST AS {RoleLabelFor(castElsewhereRole).ToUpperInvariant()}";
        }

        private void RenderUnderway(bool visible)
        {
            if (!visible || project == null)
            {
                underwayRoot.style.display = DisplayStyle.None;
                return;
            }
            underwayRoot.style.display = DisplayStyle.Flex;

            // BLOCKER 3(b): 'queued' is not underway — the request is waiting
            // for a shared slot, so the session/due/weeks-until-decision
            // facts below (which read as an active countdown already
            // running) would be false for a queued session. Show the exact
            // same truthful waiting line PhaseLine already states instead of
            // those facts. Once the authority actually starts the session
            // (sessionStatus flips to auditioning) the ordinary facts return.
            var queued = string.Equals(
                project.sessionStatus,
                StudioCastingProjectSnapshotSessionStatusValues.Queued,
                StringComparison.Ordinal);
            underwaySessionLabel.text = queued
                ? PhaseLine(project.sessionStatus, project.dueWeek)
                : string.IsNullOrEmpty(project.sessionId)
                    ? "Camera-test session pending"
                    : $"Session {project.sessionId}";
            underwayDueLabel.text = queued
                ? string.Empty
                : project.dueWeek.HasValue
                    ? $"Due Week {project.dueWeek.Value}"
                    : "Due week not yet set";
            underwayWeeksLabel.text = queued
                ? string.Empty
                : project.weeksUntilDecision.HasValue
                    ? $"{project.weeksUntilDecision.Value} week(s) until decision"
                    : string.Empty;
            underwayConsequenceLabel.text = project.consequence ?? string.Empty;
            if (string.IsNullOrEmpty(boardCapacityLine))
            {
                underwayCapacityLabel.style.display = DisplayStyle.None;
                underwayCapacityLabel.text = string.Empty;
            }
            else
            {
                underwayCapacityLabel.style.display = DisplayStyle.Flex;
                underwayCapacityLabel.text = boardCapacityLine;
            }

            underwayReadsList.Clear();
            var anyReads = false;
            // FIX 1: the projection's OWN activeSlate is authoritative and
            // survives a restart (it comes straight from the queued/auditioning
            // CastingSession, not client memory) — prefer it whenever the
            // authority publishes one. Fall back to the locally retained
            // context slate (resolved against the CURRENT candidate pool) only
            // when activeSlate is null, e.g. an unmigrated snapshot.
            var activeSlate = project.activeSlate;
            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var roleKey = ScreenTestRoleKeys[index];
                if (activeSlate != null)
                {
                    var reads = ActiveSlateReadsFor(activeSlate, roleKey);
                    foreach (var read in reads)
                    {
                        if (read == null) continue;
                        anyReads = true;
                        var readRow = new Label($"{ScreenTestRoleLabels[index]} · {read.name}")
                        {
                            name = $"casting-underway-read-{roleKey}-{read.talentId}",
                        };
                        underwayReadsList.Add(readRow);
                    }
                    continue;
                }
                var slate = SlateFor(roleKey);
                if (slate == null) continue;
                foreach (var talentId in slate)
                {
                    anyReads = true;
                    var candidate = FindCandidateInPool(roleKey, talentId);
                    var name = candidate?.name ?? talentId;
                    var readRow = new Label($"{ScreenTestRoleLabels[index]} · {name}")
                    {
                        name = $"casting-underway-read-{roleKey}-{talentId}",
                    };
                    underwayReadsList.Add(readRow);
                }
            }
            if (!anyReads)
            {
                var none = new Label("The six reads are not available from this device.");
                none.AddToClassList("meta");
                underwayReadsList.Add(none);
            }

            underwayEmptyLabel.text = "No results yet";
        }

        private void RenderReview(bool visible)
        {
            if (!visible || project == null)
            {
                reviewRoot.style.display = DisplayStyle.None;
                return;
            }
            reviewRoot.style.display = DisplayStyle.Flex;

            var results = project.results;
            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var roleKey = ScreenTestRoleKeys[index];
                var container = reviewRoleContainers[index];
                container.Clear();
                var roleHeader = new Label(ScreenTestRoleLabels[index]);
                roleHeader.AddToClassList("meta");
                container.Add(roleHeader);
                var evidenceList = ResultsFor(results, roleKey);
                foreach (var evidence in evidenceList)
                {
                    if (evidence == null) continue;
                    var candidate = FindCandidateInPool(roleKey, evidence.talentId);
                    var name = candidate?.name ?? evidence.talentId;
                    var resultLabel = new Label($"{name} — est ~{evidence.estimate} (range {evidence.low}–{evidence.high})")
                    {
                        name = $"casting-review-result-{roleKey}-{evidence.talentId}",
                    };
                    var fitLabel = new Label(candidate != null ? $"Fit {candidate.fit}" : "Fit unavailable")
                    {
                        name = $"casting-review-fit-{roleKey}-{evidence.talentId}",
                    };
                    container.Add(resultLabel);
                    container.Add(fitLabel);
                }
            }

            var alreadyAcknowledged = !string.IsNullOrEmpty(project.sessionId) &&
                string.Equals(acknowledgedForSessionId, project.sessionId, StringComparison.Ordinal);
            reviewContinueButton.SetEnabled(!alreadyAcknowledged && screenTestActionsEnabled());
        }

        private void HandleBackClicked() => closeRequested();

        private void HandlePlanTestsClicked() => EnterScreenTestPlanner();

        private void HandleContinueWithoutTestsClicked() => ContinueWithoutTests();

        private void HandleStartScreenTestsClicked() => CommitScreenTestQuote();

        private void HandleCancelPlannerClicked() => CancelScreenTestPlanner();

        private void HandleReviewContinueClicked() => ContinueToCasting();

        private void HandlePrimaryActionClicked()
        {
            // Wave 3: honest placeholder only — package assembly is a later wave.
        }

        private void HandleLocateClicked(string stableId)
        {
            if (string.IsNullOrEmpty(stableId)) return;
            requestLocate(stableId, true);
        }

        private void HandleCompareOpenClicked() => OpenCompare();

        private void HandleReviewGreenlightClicked() => OpenGreenlightReview();

        // ── data helpers ────────────────────────────────────────────────────

        private StudioCastingCandidateSnapshot SelectedCandidate()
        {
            if (context?.CandidateId == null || project == null) return null;
            var pool = PoolFor(context.Role);
            for (var index = 0; index < pool.Length; index++)
                if (pool[index] != null && string.Equals(pool[index].talentId, context.CandidateId, StringComparison.Ordinal))
                    return pool[index];
            return null;
        }

        private bool PoolContains(string roleKey, string talentId)
        {
            var pool = PoolFor(roleKey);
            for (var index = 0; index < pool.Length; index++)
                if (pool[index] != null && string.Equals(pool[index].talentId, talentId, StringComparison.Ordinal))
                    return true;
            return false;
        }

        private StudioCastingCandidateSnapshot[] PoolFor(string roleKey)
        {
            if (project == null) return Array.Empty<StudioCastingCandidateSnapshot>();
            return roleKey switch
            {
                "director" => project.directorCandidates ?? Array.Empty<StudioCastingCandidateSnapshot>(),
                "lead" => project.leadCandidates ?? Array.Empty<StudioCastingCandidateSnapshot>(),
                "antagonist" => project.antagonistCandidates ?? Array.Empty<StudioCastingCandidateSnapshot>(),
                "support" => project.supportCandidates ?? Array.Empty<StudioCastingCandidateSnapshot>(),
                "craft" => project.craftCandidates ?? Array.Empty<StudioCastingCandidateSnapshot>(),
                _ => Array.Empty<StudioCastingCandidateSnapshot>(),
            };
        }

        private StudioCastingCandidateSnapshot FindCandidateInPool(string roleKey, string talentId)
        {
            var pool = PoolFor(roleKey);
            for (var index = 0; index < pool.Length; index++)
                if (pool[index] != null && string.Equals(pool[index].talentId, talentId, StringComparison.Ordinal))
                    return pool[index];
            return null;
        }

        /// <summary>The authoritative six reads for one screen-test role, straight off the projection's activeSlate.</summary>
        private static StudioCastingSlateReadSnapshot[] ActiveSlateReadsFor(
            StudioCastingActiveSlateSnapshot activeSlate, string roleKey) => roleKey switch
        {
            "lead" => activeSlate.lead ?? Array.Empty<StudioCastingSlateReadSnapshot>(),
            "antagonist" => activeSlate.antagonist ?? Array.Empty<StudioCastingSlateReadSnapshot>(),
            "support" => activeSlate.support ?? Array.Empty<StudioCastingSlateReadSnapshot>(),
            _ => Array.Empty<StudioCastingSlateReadSnapshot>(),
        };

        private static string RoleLabelFor(string roleKey)
        {
            var index = Array.IndexOf(SelectableRoleKeys, roleKey);
            return index >= 0 ? SelectableRoleLabels[index] : roleKey;
        }

        private static string ScreenTestRoleLabelFor(string roleKey)
        {
            var index = Array.IndexOf(ScreenTestRoleKeys, roleKey);
            return index >= 0 ? ScreenTestRoleLabels[index] : roleKey;
        }

        private static string BadgeText(string contractBadge) =>
            string.Equals(contractBadge, "studio", StringComparison.Ordinal) ? "Studio" : "Freelancer";

        private static StudioCastingSignalSnapshot StrongestSignal(StudioCastingCandidateSnapshot candidate)
        {
            if (candidate.signals == null) return null;
            for (var index = 0; index < candidate.signals.Length; index++)
                if (candidate.signals[index] != null &&
                    string.Equals(candidate.signals[index].kind, "positive", StringComparison.Ordinal))
                    return candidate.signals[index];
            return candidate.signals.Length > 0 ? candidate.signals[0] : null;
        }

        private static RoleRow BuildRoleRow(string roleKey, string label)
        {
            var element = new VisualElement { name = $"casting-role-{roleKey}" };
            element.AddToClassList("casting-role-row");
            var text = new Label(label ?? roleKey);
            element.Add(text);
            return new RoleRow { Element = element, Text = text, RoleKey = roleKey };
        }

        // ── Wave 4: slate/quote helpers ───────────────────────────────────────

        private List<string> SlateFor(string roleKey) => roleKey switch
        {
            "lead" => context?.SlateLead,
            "antagonist" => context?.SlateAntagonist,
            "support" => context?.SlateSupport,
            _ => null,
        };

        private int UniquePeopleCount()
        {
            if (context == null) return 0;
            var seen = new HashSet<string>(StringComparer.Ordinal);
            AddAllTo(seen, context.SlateLead);
            AddAllTo(seen, context.SlateAntagonist);
            AddAllTo(seen, context.SlateSupport);
            return seen.Count;
        }

        private static void AddAllTo(HashSet<string> set, List<string> values)
        {
            if (values == null) return;
            foreach (var value in values)
                if (!string.IsNullOrEmpty(value))
                    set.Add(value);
        }

        /// <summary>
        /// Names the gap rather than rendering a generic disabled control:
        /// the first role short of two readers ("Choose 2 for Lead"), else
        /// the first chosen reader who has since become ineligible ("Replace
        /// ... — {the authority's own availabilityLabel}"). Null means the
        /// slate is fully eligible and complete — the only state a quote may
        /// be requested from.
        /// </summary>
        private string CompletenessGapMessage()
        {
            if (context == null) return $"Choose {ScreenTestSlateSizePerRole} for {ScreenTestRoleLabels[0]}";
            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var slate = SlateFor(ScreenTestRoleKeys[index]);
                var remaining = ScreenTestSlateSizePerRole - (slate?.Count ?? 0);
                if (remaining > 0) return $"Choose {remaining} for {ScreenTestRoleLabels[index]}";
            }
            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var roleKey = ScreenTestRoleKeys[index];
                var slate = SlateFor(roleKey);
                foreach (var talentId in slate)
                {
                    var candidate = FindCandidateInPool(roleKey, talentId);
                    if (candidate == null)
                        return $"Replace a {ScreenTestRoleLabels[index]} pick — no longer offered";
                    if (!candidate.available)
                        return $"Replace {candidate.name} for {ScreenTestRoleLabels[index]} — {candidate.availabilityLabel}";
                }
            }

            // SMALL FIX C (charter Q7's named-copy gap): every role now has
            // its 2 picks and every pick is still available/offered, but
            // cross-role duplicates are legal (the same person may read for
            // two roles) — so the six reads can still collapse to fewer than
            // 3 distinct people. The server still revalidates this
            // independently; this is the honest, named client-side message
            // for the same rule, closing the gap rather than silently
            // letting an under-broad slate through as "complete".
            var uniqueOverall = new HashSet<string>(StringComparer.Ordinal);
            for (var index = 0; index < ScreenTestRoleKeys.Length; index++)
            {
                var slate = SlateFor(ScreenTestRoleKeys[index]);
                if (slate == null) continue;
                foreach (var talentId in slate) uniqueOverall.Add(talentId);
            }
            if (uniqueOverall.Count < 3)
                return "Need at least 3 different people across the six reads.";

            return null;
        }

        private StudioCastingDraftPayload BuildScreenTestDraftIfComplete()
        {
            if (project == null || context == null) return null;
            if (CompletenessGapMessage() != null) return null;
            return new StudioCastingDraftPayload
            {
                kind = StudioCastingDraftPayloadKindValues.ScreenTest,
                projectId = project.projectId,
                slateLead = context.SlateLead.ToArray(),
                slateAntagonist = context.SlateAntagonist.ToArray(),
                slateSupport = context.SlateSupport.ToArray(),
            };
        }

        /// <summary>Invalidates any held/pending quote — the MaintainQuote precedent's own reaction to a draft edit.</summary>
        private void SlateChanged()
        {
            pendingScreenTestQuote = null;
            pendingScreenTestQuoteCommandId = null;
            screenTestQuoteDirty = true;
            screenTestQuoteNotice = null;
        }

        private static StudioCastingEvidenceSnapshot[] ResultsFor(StudioCastingResultsSnapshot results, string roleKey)
        {
            if (results == null) return Array.Empty<StudioCastingEvidenceSnapshot>();
            return roleKey switch
            {
                "lead" => results.lead ?? Array.Empty<StudioCastingEvidenceSnapshot>(),
                "antagonist" => results.antagonist ?? Array.Empty<StudioCastingEvidenceSnapshot>(),
                "support" => results.support ?? Array.Empty<StudioCastingEvidenceSnapshot>(),
                _ => Array.Empty<StudioCastingEvidenceSnapshot>(),
            };
        }

        // ══════════════════════════════════════════════════════════════════
        // Wave 5: the package draft — Choose/Replace/Remove, the duplicate-
        // person Move law, budgets, readiness, compare, and the Review
        // Greenlight navigation placeholder. Every mutating method below
        // touches ONLY the retained context's draft fields (or transient
        // same-session UI state) and NEVER calls any outward delegate — no
        // submit, no quote, ever fires from a draft edit itself.
        // ══════════════════════════════════════════════════════════════════

        private string GetDraftValue(string roleKey) => roleKey switch
        {
            "director" => context?.DirectorId,
            "lead" => context?.LeadId,
            "antagonist" => context?.AntagonistId,
            "support" => context?.SupportId,
            "craft" => context?.CraftLeadId,
            _ => null,
        };

        private void SetDraftValue(string roleKey, string talentId)
        {
            if (context == null) return;
            switch (roleKey)
            {
                case "director": context.DirectorId = talentId; break;
                case "lead": context.LeadId = talentId; break;
                case "antagonist": context.AntagonistId = talentId; break;
                case "support": context.SupportId = talentId; break;
                case "craft": context.CraftLeadId = talentId; break;
            }
        }

        /// <summary>The OTHER role (if any) this talentId currently occupies in the draft. Null = no conflict.</summary>
        private string FindOccupiedRole(string talentId, string excludingRoleKey)
        {
            for (var index = 0; index < SelectableRoleKeys.Length; index++)
            {
                var roleKey = SelectableRoleKeys[index];
                if (string.Equals(roleKey, excludingRoleKey, StringComparison.Ordinal)) continue;
                if (string.Equals(GetDraftValue(roleKey), talentId, StringComparison.Ordinal)) return roleKey;
            }
            return null;
        }

        /// <summary>
        /// The explicit control: fills roleKey's draft slot with talentId,
        /// UNLESS that person already occupies a different draft slot — in
        /// which case NOTHING is mutated yet and a Move conflict is armed for
        /// the dossier to render (see <see cref="ConfirmMoveForRole"/>).
        /// Never reachable from row activation/double-click.
        /// </summary>
        public bool ChooseForRole(string roleKey, string talentId)
        {
            if (context == null || project == null || string.IsNullOrEmpty(talentId)) return false;
            if (Array.IndexOf(SelectableRoleKeys, roleKey) < 0) return false;
            if (!PoolContains(roleKey, talentId)) return false;

            var occupiedRole = FindOccupiedRole(talentId, roleKey);
            if (occupiedRole != null)
            {
                pendingMoveTalentId = talentId;
                pendingMoveTargetRole = roleKey;
                pendingMoveFromRole = occupiedRole;
                RenderAll();
                return false;
            }

            ClearPendingMove();
            SetDraftValue(roleKey, talentId);
            GreenlightDraftChanged();
            RenderAll();
            return true;
        }

        /// <summary>
        /// The duplicate-person law's ONE complete local edit: clears the old
        /// slot and fills the new one together, so the person is NEVER
        /// observed occupying both (or neither) in between.
        /// </summary>
        public bool ConfirmMoveForRole()
        {
            if (context == null || pendingMoveTalentId == null) return false;
            var talentId = pendingMoveTalentId;
            var targetRole = pendingMoveTargetRole;
            var fromRole = pendingMoveFromRole;
            ClearPendingMove();
            SetDraftValue(fromRole, null);
            SetDraftValue(targetRole, talentId);
            GreenlightDraftChanged();
            RenderAll();
            return true;
        }

        /// <summary>
        /// P04A.2 §13: the sentence a pending move owes the player about the
        /// person it will DISPLACE. <see cref="ConfirmMoveForRole"/> fills the
        /// target slot outright, so if a DIFFERENT person already holds that
        /// role they leave the draft in the same one atomic edit. Naming both
        /// ends of the move ("MOVE FROM LEAD TO ANTAGONIST") never said that.
        /// This does, in words, BEFORE the control is pressed.
        ///
        /// Null when nothing is displaced — an empty target role, or the
        /// mover already standing in it. This is DISCLOSURE only: it does not
        /// block the move, does not add a second confirmation, and introduces
        /// no uniqueness rule of its own. applyGreenlight remains the sole
        /// uniqueness authority; the move stays one atomic local edit.
        /// </summary>
        private string PendingMoveEvictionLine()
        {
            if (pendingMoveTalentId == null || string.IsNullOrEmpty(pendingMoveTargetRole)) return null;
            var displacedId = GetDraftValue(pendingMoveTargetRole);
            if (string.IsNullOrEmpty(displacedId)) return null;
            if (string.Equals(displacedId, pendingMoveTalentId, StringComparison.Ordinal)) return null;
            return $"{DraftOccupantName(pendingMoveTargetRole, displacedId)} leaves " +
                   $"{RoleLabelFor(pendingMoveTargetRole)}.";
        }

        /// <summary>
        /// One draft occupant's display name: the live pool entry, the
        /// last-known cache once they have left the pool, and only then the
        /// raw id. Never invents a name, and never hides a filled slot.
        /// </summary>
        private string DraftOccupantName(string roleKey, string talentId)
        {
            var live = FindCandidateInPool(roleKey, talentId);
            if (live != null) return live.name;
            return lastKnownCandidates.TryGetValue(talentId, out var cached) ? cached.name : talentId;
        }

        /// <summary>"...or choose another": dismisses the conflict prompt without touching either slot.</summary>
        public bool CancelPendingMove()
        {
            if (pendingMoveTalentId == null) return false;
            ClearPendingMove();
            RenderAll();
            return true;
        }

        private void ClearPendingMove()
        {
            pendingMoveTalentId = null;
            pendingMoveTargetRole = null;
            pendingMoveFromRole = null;
        }

        /// <summary>
        /// P04A.2 (FINDING 3): may the armed Move prompt survive this snapshot
        /// rebind? True only when EVERY sentence the prompt is showing is still
        /// true of the live draft and of the NEW snapshot's pools:
        ///
        ///   (a) the mover is still OFFERED for the role the prompt would move
        ///       them into — otherwise the control would promise a seat the
        ///       authority no longer offers;
        ///   (b) the mover still OCCUPIES the role the prompt names as their
        ///       current one ("Already cast as Lead." / "MOVE FROM LEAD …");
        ///   (c) if the prompt names someone who LEAVES, that person still
        ///       holds the target role and is still nameable from this snapshot
        ///       (live pool, else the last-known cache CacheKnownCandidates has
        ///       just refreshed) — a departure line that degraded to a raw id,
        ///       or named a person no longer being displaced, would be a lie.
        ///
        /// Everything is re-derived here; nothing is read back from a rendered
        /// string. False restores the pre-P04A.2 behaviour exactly: the caller
        /// clears the prompt. This is a local read only — no delegate, no
        /// quote, no command, and no new uniqueness rule (applyGreenlight
        /// remains the sole uniqueness authority).
        /// </summary>
        private bool PendingMoveSurvivesRebind()
        {
            if (pendingMoveTalentId == null) return false;
            if (Array.IndexOf(SelectableRoleKeys, pendingMoveTargetRole) < 0) return false;
            if (Array.IndexOf(SelectableRoleKeys, pendingMoveFromRole) < 0) return false;
            if (string.Equals(pendingMoveTargetRole, pendingMoveFromRole, StringComparison.Ordinal)) return false;

            if (!PoolContains(pendingMoveTargetRole, pendingMoveTalentId)) return false;
            if (!string.Equals(GetDraftValue(pendingMoveFromRole), pendingMoveTalentId, StringComparison.Ordinal))
                return false;

            var displacedId = GetDraftValue(pendingMoveTargetRole);
            if (string.IsNullOrEmpty(displacedId)) return true;
            // The mover holding BOTH ends is the duplicate occupancy the whole
            // §13 law exists to prevent; a prompt describing it is incoherent,
            // so it is cleared rather than preserved.
            if (string.Equals(displacedId, pendingMoveTalentId, StringComparison.Ordinal)) return false;
            return FindCandidateInPool(pendingMoveTargetRole, displacedId) != null ||
                   lastKnownCandidates.ContainsKey(displacedId);
        }

        /// <summary>Explicit [Remove]: clears one role's draft slot. The original candidate remains freely choosable afterward.</summary>
        public bool RemoveFromRole(string roleKey)
        {
            if (context == null) return false;
            if (Array.IndexOf(SelectableRoleKeys, roleKey) < 0) return false;
            if (string.IsNullOrEmpty(GetDraftValue(roleKey))) return false;
            SetDraftValue(roleKey, null);
            if (pendingMoveTargetRole == roleKey || pendingMoveFromRole == roleKey) ClearPendingMove();
            GreenlightDraftChanged();
            RenderAll();
            return true;
        }

        /// <summary>
        /// The role rail's own honest read of one selectable role's draft
        /// fill state: unfilled, filled+eligible, or filled+blocked (the
        /// candidate is no longer available, or no longer offered at all).
        /// Rejoins against the LIVE pool every call — never caches a stale
        /// verdict — and falls back to the last-seen name only when the
        /// person has left the pool entirely.
        /// </summary>
        private (bool filled, bool blocked, string line) RoleRailStatus(string roleKey, int index)
        {
            var talentId = GetDraftValue(roleKey);
            if (string.IsNullOrEmpty(talentId)) return (false, false, string.Empty);

            var live = FindCandidateInPool(roleKey, talentId);
            if (live != null)
            {
                return live.available
                    ? (true, false, $"{live.name} · Fit {live.fit} · Package draft — not committed")
                    : (true, true, $"{live.name} · Unavailable now — {live.availabilityLabel}");
            }

            var cachedName = lastKnownCandidates.TryGetValue(talentId, out var cached) ? cached.name : talentId;
            return (true, true, $"{cachedName} · Unavailable now — no longer offered for this role");
        }

        /// <summary>
        /// Every reason [Review Greenlight] is not yet enabled: an unfilled
        /// role, a filled-but-now-unavailable role, or an unset budget.
        /// Empty = the draft is fully ready. The single source of truth for
        /// both the readiness strip's text and the button's enabled state.
        /// </summary>
        private List<string> DraftGaps()
        {
            var gaps = new List<string>();
            for (var index = 0; index < SelectableRoleKeys.Length; index++)
            {
                var roleKey = SelectableRoleKeys[index];
                var status = RoleRailStatus(roleKey, index);
                if (!status.filled) gaps.Add($"Choose {SelectableRoleLabels[index]}");
                else if (status.blocked) gaps.Add($"Replace {SelectableRoleLabels[index]} — unavailable");
            }
            if (context == null || !context.NegativeAmount.HasValue) gaps.Add("Choose negative budget");
            if (context == null || !context.MarketingAmount.HasValue) gaps.Add("Choose marketing budget");
            return gaps;
        }

        private void RenderReadiness(bool visible)
        {
            readinessRoot.style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;
            if (!visible)
            {
                reviewGreenlightButton.SetEnabled(false);
                return;
            }

            var gaps = DraftGaps();
            var filledRoles = 0;
            for (var index = 0; index < SelectableRoleKeys.Length; index++)
                if (!string.IsNullOrEmpty(GetDraftValue(SelectableRoleKeys[index]))) filledRoles++;

            // A4: the persistent next-action region, never below the fold —
            // a section-size headline answering "what remains" at a glance,
            // and a body-size guidance line under it naming exactly why
            // (DraftGaps()'s own truth, never invented copy) and what to do
            // next. Both derive from the same gap list the button's enabled
            // state uses, so they can never disagree with each other.
            readinessHeadlineLabel.text = gaps.Count == 0
                ? "PACKAGE READY"
                : $"{filledRoles} OF {SelectableRoleKeys.Length} ROLES FILLED";

            readinessLabel.text = gaps.Count == 0
                ? "Every role and budget is set. Review Greenlight to continue."
                : $"Missing: {string.Join(", ", gaps)}";

            // Lead fix, found by the packaged owner-input proof: at 1440x900 the
            // body needs ~443px of scrolling, and scrolling far enough to reach
            // a candidate takes the ROLE RAIL completely off screen — measured,
            // every rail row clipped to a zero rect. At that moment nothing
            // visible answered charter §9's first question, "WHAT ROLE AM I
            // CASTING?", even though the player was in the middle of casting it.
            // The readiness region lives outside the scroll, so the active role
            // belongs here, where it cannot scroll away.
            nowCastingLabel.text = string.IsNullOrEmpty(context?.Role)
                ? string.Empty
                : $"NOW CASTING · {RoleLabelFor(context.Role).ToUpperInvariant()}";
            nowCastingLabel.style.display =
                string.IsNullOrEmpty(nowCastingLabel.text) ? DisplayStyle.None : DisplayStyle.Flex;

            // P04A.2 §14: name every role's occupant, or say Empty — the
            // count and the gap list above answer "how much remains", never
            // "who is cast where". Rebuilt from the SAME RoleRailStatus()/
            // GetDraftValue() truth DraftGaps() reads, on every render, so
            // Choose, Replace, Remove and Move each update it immediately and
            // a stale entry cannot survive a single frame.
            for (var index = 0; index < SelectableRoleKeys.Length; index++)
                roleSummaryRows[index].text =
                    $"{RoleSummaryLabels[index]} · {RoleSummaryOccupant(SelectableRoleKeys[index], index)}";

            reviewGreenlightButton.SetEnabled(gaps.Count == 0);
        }

        /// <summary>
        /// P04A.2 §14: one role's occupant for the pinned summary — the live
        /// name, the last-known name once the person has left the pool
        /// entirely, or "Empty". Never invents a fact: filled/blocked comes
        /// straight from <see cref="RoleRailStatus"/>, the same read the role
        /// rail and DraftGaps() use, so the summary can never disagree with
        /// either. A blocked (no-longer-available) occupant is still NAMED —
        /// hiding them would make a filled slot read as empty — with the
        /// authority's own unavailability stated after the name.
        /// </summary>
        private string RoleSummaryOccupant(string roleKey, int index)
        {
            var status = RoleRailStatus(roleKey, index);
            if (!status.filled) return "Empty";

            var talentId = GetDraftValue(roleKey);
            var live = FindCandidateInPool(roleKey, talentId);
            var name = live != null
                ? live.name
                : lastKnownCandidates.TryGetValue(talentId, out var cached) ? cached.name : talentId;
            return status.blocked ? $"{name} · Unavailable" : name;
        }

        // ── Wave 5: budget pickers — published-menu amounts only ─────────────

        private void RenderBudgetPickers(bool visible)
        {
            budgetSectionRoot.style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;
            if (!visible) return;
            BuildBudgetOptions(budgetNegativeRoot, "casting-budget-negative", project?.negativeOptions, context?.NegativeAmount, ChooseNegativeBudget);
            BuildBudgetOptions(budgetMarketingRoot, "casting-budget-marketing", project?.marketingOptions, context?.MarketingAmount, ChooseMarketingBudget);
        }

        private static void BuildBudgetOptions(
            VisualElement root, string namePrefix, StudioBudgetOptionSnapshot[] options, int? selected, Func<int, bool> pick)
        {
            root.Clear();
            if (options == null) return;
            foreach (var option in options)
            {
                if (option == null) continue;
                var amount = option.amount;
                var row = new Button(() => pick(amount)) { name = $"{namePrefix}-option-{amount}", text = option.label };
                if (selected.HasValue && selected.Value == amount) row.AddToClassList("selected");
                root.Add(row);
            }
        }

        /// <summary>Only a published menu amount is ever accepted — never an arbitrary number.</summary>
        public bool ChooseNegativeBudget(int amount)
        {
            if (context == null || project == null) return false;
            if (!MenuContains(project.negativeOptions, amount)) return false;
            context.NegativeAmount = amount;
            GreenlightDraftChanged();
            RenderAll();
            return true;
        }

        /// <summary>Only a published menu amount is ever accepted — never an arbitrary number.</summary>
        public bool ChooseMarketingBudget(int amount)
        {
            if (context == null || project == null) return false;
            if (!MenuContains(project.marketingOptions, amount)) return false;
            context.MarketingAmount = amount;
            GreenlightDraftChanged();
            RenderAll();
            return true;
        }

        private static bool MenuContains(StudioBudgetOptionSnapshot[] options, int amount)
        {
            if (options == null) return false;
            foreach (var option in options)
                if (option != null && option.amount == amount) return true;
            return false;
        }

        // ── Wave 5: compare — non-mutating, scoped to the selected role ──────

        private void RenderCompareBar(bool visible)
        {
            var showBar = visible && context != null && context.ComparePins.Count > 0;
            compareBar.style.display = showBar ? DisplayStyle.Flex : DisplayStyle.None;
            if (!showBar) return;
            compareBarLabel.text = $"Pinned to compare ({context.ComparePins.Count}/4)";
            compareOpenButton.SetEnabled(context.ComparePins.Count >= 2);
        }

        /// <summary>[Compare pinned]: requires >=2 pins (up to 4). Opening/closing never mutates a pin.</summary>
        public bool OpenCompare()
        {
            if (context == null || context.ComparePins.Count < 2) return false;
            context.CompareOpen = true;
            RenderAll();
            return true;
        }

        public bool CloseCompare()
        {
            if (context == null || !context.CompareOpen) return false;
            context.CompareOpen = false;
            RenderAll();
            return true;
        }

        private void RenderCompare(bool visible)
        {
            compareRoot.style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;
            compareColumnsContainer.Clear();
            if (!visible || context == null) return;

            var roleKey = context.Role;
            var pins = context.ComparePins;

            MinMax(pins, roleKey, c => c.fit, out var fitMin, out var fitMax);
            MinMax(pins, roleKey, c => c.ovr, out var ovrMin, out var ovrMax);
            MinMax(pins, roleKey, c => c.epExpected, out var epMin, out var epMax);
            MinMax(pins, roleKey, c => c.starPower, out var starMin, out var starMax);

            foreach (var talentId in pins)
            {
                var live = FindCandidateInPool(roleKey, talentId);
                var column = live != null
                    ? BuildCompareColumn(live, roleKey, fitMin, fitMax, ovrMin, ovrMax, epMin, epMax, starMin, starMax)
                    : BuildUnavailableCompareColumn(talentId);
                compareColumnsContainer.Add(column);
            }
        }

        private void MinMax(List<string> pins, string roleKey, Func<StudioCastingCandidateSnapshot, int> selector, out int min, out int max)
        {
            min = int.MaxValue;
            max = int.MinValue;
            foreach (var talentId in pins)
            {
                var candidate = FindCandidateInPool(roleKey, talentId);
                if (candidate == null) continue;
                var value = selector(candidate);
                if (value < min) min = value;
                if (value > max) max = value;
            }
        }

        /// <summary>Factual higher/lower — text/weight, never color alone; no combined score, no "Recommended".</summary>
        private static string Mark(int value, int min, int max)
        {
            if (min > max || min == max) return string.Empty;
            if (value == max) return " (higher)";
            if (value == min) return " (lower)";
            return string.Empty;
        }

        /// <summary>
        /// One aligned column, in the frozen row order: portrait-block/name/
        /// contract/availability header, then Availability/current work,
        /// Role Fit, Camera-test Est+range (this role only), Role OVR,
        /// Expected performance, Genre experience, Star Power, Fee/payroll
        /// status, Top strength/concern.
        /// </summary>
        private VisualElement BuildCompareColumn(
            StudioCastingCandidateSnapshot candidate, string roleKey,
            int fitMin, int fitMax, int ovrMin, int ovrMax, int epMin, int epMax, int starMin, int starMax)
        {
            var column = new VisualElement { name = $"casting-compare-col-{candidate.talentId}" };
            column.AddToClassList("casting-compare-column");

            var portrait = new VisualElement { name = $"casting-compare-portrait-{candidate.talentId}" };
            portrait.AddToClassList("casting-dossier-portrait");
            column.Add(portrait);
            column.Add(new Label($"{candidate.name} — {candidate.professionLabel}") { name = $"casting-compare-name-{candidate.talentId}" });
            column.Add(new Label(BadgeText(candidate.contractBadge)) { name = $"casting-compare-contract-{candidate.talentId}" });
            column.Add(new Label(candidate.available ? "Available" : "Unavailable")
            {
                name = $"casting-compare-availbadge-{candidate.talentId}",
            });
            // P04A.2 (2): the comparison view never read the draft at all —
            // an actor already cast could be compared with no sign of it.
            AddCompareDraftBadge(column, candidate.talentId, roleKey);

            column.Add(new Label(candidate.available
                ? candidate.availabilityLabel
                : $"{candidate.availabilityLabel} · {candidate.currentWorkLabel}"));
            column.Add(new Label($"Fit {candidate.fit}{Mark(candidate.fit, fitMin, fitMax)}"));
            column.Add(new Label(candidate.evidence != null
                ? $"Tested: ~{candidate.evidence.estimate} (range {candidate.evidence.low}–{candidate.evidence.high})"
                : $"Not tested for {RoleLabelFor(roleKey)}"));
            column.Add(new Label($"OVR {candidate.ovr}{Mark(candidate.ovr, ovrMin, ovrMax)}"));
            column.Add(new Label(
                $"EP {candidate.epLow}–{candidate.epHigh} · expected {candidate.epExpected}{Mark(candidate.epExpected, epMin, epMax)}"));
            column.Add(new Label(candidate.genreExperienceLabel));
            column.Add(new Label($"Star Power {candidate.starPower}{Mark(candidate.starPower, starMin, starMax)}"));
            column.Add(new Label(candidate.projectCostLabel));
            var strongest = StrongestPositiveSignal(candidate);
            var concern = StrongestConcernSignal(candidate);
            column.Add(new Label($"{(strongest != null ? strongest.text : "No standout strength noted")} / " +
                                  $"{(concern != null ? concern.text : "No concerns noted")}"));

            column.Add(BuildUnpinButton(candidate.talentId));
            return column;
        }

        /// <summary>A pinned candidate who left the pool: read-only, identity from the last-known cache, until unpinned.</summary>
        private VisualElement BuildUnavailableCompareColumn(string talentId)
        {
            var column = new VisualElement { name = $"casting-compare-col-{talentId}" };
            column.AddToClassList("casting-compare-column");
            column.AddToClassList("blocked");
            var cachedName = lastKnownCandidates.TryGetValue(talentId, out var cached) ? cached.name : talentId;
            column.Add(new Label(cachedName) { name = $"casting-compare-name-{talentId}" });
            var note = new Label("Unavailable now — no longer offered") { name = $"casting-compare-unavailable-{talentId}" };
            note.AddToClassList("blocked");
            column.Add(note);
            // P04A.2 (2): a departed candidate can still hold a draft slot —
            // the assignment text must survive their leaving the live pool,
            // exactly as the role rail's own last-known identity does.
            AddCompareDraftBadge(column, talentId, context?.Role);
            column.Add(BuildUnpinButton(talentId));
            return column;
        }

        /// <summary>
        /// P04A.2 (2): mirrors the candidate row's assignment badges into the
        /// comparison view, exactly — the occupant of the role being compared
        /// reads "SELECTED FOR &lt;ROLE&gt;", anyone cast in a DIFFERENT draft
        /// role reads "CAST AS &lt;ROLE&gt;". Text, never colour alone, and
        /// visible without opening a dossier or clicking anything. The writer
        /// is structurally excluded here too: <see cref="GetDraftValue"/> and
        /// <see cref="FindOccupiedRole"/> both walk SelectableRoleKeys only,
        /// and a screenplay credit is never a Production seat.
        /// </summary>
        private void AddCompareDraftBadge(VisualElement column, string talentId, string roleKey)
        {
            if (string.IsNullOrEmpty(talentId) || string.IsNullOrEmpty(roleKey)) return;

            if (string.Equals(GetDraftValue(roleKey), talentId, StringComparison.Ordinal))
            {
                var selectedBadge = new Label($"SELECTED FOR {RoleLabelFor(roleKey).ToUpperInvariant()}")
                {
                    name = $"casting-compare-selected-{talentId}",
                };
                selectedBadge.AddToClassList("casting-row-selected-badge");
                column.Add(selectedBadge);
                return;
            }

            var castElsewhereRole = FindOccupiedRole(talentId, roleKey);
            if (castElsewhereRole == null) return;
            var castAsBadge = new Label($"CAST AS {RoleLabelFor(castElsewhereRole).ToUpperInvariant()}")
            {
                name = $"casting-compare-castas-{talentId}",
            };
            castAsBadge.AddToClassList("casting-row-castas-badge");
            column.Add(castAsBadge);
        }

        /// <summary>
        /// P04A.2 (2): the dossier's own copy of the same two facts, in the
        /// same words as the row and the comparison column — the occupant of
        /// the role being cast reads "SELECTED FOR &lt;ROLE&gt;", anyone
        /// holding a DIFFERENT draft role reads "CAST AS &lt;ROLE&gt;". TEXT,
        /// never colour alone, and present the moment the dossier renders —
        /// no further click, no tooltip, no hover.
        ///
        /// Deliberately distinct element names (casting-dossier-selected-{id}
        /// / casting-dossier-castas-{id}) so no frozen row or compare name
        /// assertion is disturbed. The Writer is structurally excluded here as
        /// everywhere else: <see cref="GetDraftValue"/> and
        /// <see cref="FindOccupiedRole"/> walk SelectableRoleKeys only, and
        /// under P04A.2 product law a screenplay CREDIT is never a Production
        /// Company seat, never an availability claim.
        /// </summary>
        private void AddDossierDraftBadge(string talentId, string roleKey)
        {
            if (string.IsNullOrEmpty(talentId) || string.IsNullOrEmpty(roleKey)) return;

            if (string.Equals(GetDraftValue(roleKey), talentId, StringComparison.Ordinal))
            {
                var selectedBadge = new Label($"SELECTED FOR {RoleLabelFor(roleKey).ToUpperInvariant()}")
                {
                    name = $"casting-dossier-selected-{talentId}",
                };
                selectedBadge.AddToClassList("casting-row-selected-badge");
                dossier.Add(selectedBadge);
                return;
            }

            var castElsewhereRole = FindOccupiedRole(talentId, roleKey);
            if (castElsewhereRole == null) return;
            var castAsBadge = new Label($"CAST AS {RoleLabelFor(castElsewhereRole).ToUpperInvariant()}")
            {
                name = $"casting-dossier-castas-{talentId}",
            };
            castAsBadge.AddToClassList("casting-row-castas-badge");
            dossier.Add(castAsBadge);
        }

        private Button BuildUnpinButton(string talentId) =>
            new(() => UnpinFromCompare(talentId)) { name = $"casting-compare-unpin-{talentId}", text = "Remove from compare" };

        public bool UnpinFromCompare(string talentId)
        {
            if (context == null) return false;
            var removed = context.ComparePins.Remove(talentId);
            if (removed)
            {
                if (context.ComparePins.Count == 0) context.CompareOpen = false;
                RenderAll();
            }
            return removed;
        }

        /// <summary>Dossier's [Pin to compare]/[Unpin from compare] toggle. Never mutates the draft. Capped at 4.</summary>
        public bool TogglePinForCompare(string talentId)
        {
            if (context == null || string.IsNullOrEmpty(talentId)) return false;
            if (context.ComparePins.Contains(talentId))
            {
                context.ComparePins.Remove(talentId);
                if (context.ComparePins.Count == 0) context.CompareOpen = false;
            }
            else
            {
                // Unpinning a departed pin is always legal (that IS the "until
                // unpinned" law); ADDING a new pin still requires the person
                // to be a member of the currently selected role's live pool.
                if (!PoolContains(context.Role, talentId)) return false;
                if (context.ComparePins.Count >= 4) return false;
                context.ComparePins.Add(talentId);
            }
            RenderAll();
            return true;
        }

        private static StudioCastingSignalSnapshot StrongestPositiveSignal(StudioCastingCandidateSnapshot candidate)
        {
            if (candidate.signals == null) return null;
            foreach (var signal in candidate.signals)
                if (signal != null && string.Equals(signal.kind, "positive", StringComparison.Ordinal))
                    return signal;
            return null;
        }

        private static StudioCastingSignalSnapshot StrongestConcernSignal(StudioCastingCandidateSnapshot candidate)
        {
            if (candidate.signals == null) return null;
            foreach (var signal in candidate.signals)
                if (signal != null && string.Equals(signal.kind, "concern", StringComparison.Ordinal))
                    return signal;
            return null;
        }

        // ── Wave 6: [Review Greenlight] — the real review, its quote/commit
        // lifecycle, and the post-commit receipt ─────────────────────────────

        private static readonly string[] CompanyRoleKeys = { "writer", "director", "lead", "antagonist", "support", "craft" };
        private static readonly string[] CompanyRoleLabels = { "Writer", "Director", "Lead", "Antagonist", "Support", "Craft" };

        /// <summary>
        /// The one render entry point for the whole casting-greenlight-review
        /// panel and its sticky footer. `open` covers both the live review
        /// AND the receipt (the receipt is a takeover of the SAME panel);
        /// `showReceipt` distinguishes which of the two is showing.
        /// </summary>
        private void RenderGreenlightReview(bool open, bool showReceipt)
        {
            greenlightReviewRoot.style.display = open ? DisplayStyle.Flex : DisplayStyle.None;
            // Mode-exclusive bottom bands: while the review (or its receipt)
            // owns the panel, the base action bar stands down — one Back
            // affordance, one commit region, no stacked footers.
            actionBarRoot.style.display = open ? DisplayStyle.None : DisplayStyle.Flex;
            if (!open)
            {
                glFooter.style.display = DisplayStyle.None;
                return;
            }

            if (project == null && !showReceipt)
            {
                // A greenlight commit this workspace submitted is in flight
                // and the successor snapshot has already removed the project
                // from the board (the common FORMED case), but
                // HandleGreenlightCommitAccepted/Rejected has not resolved it
                // yet. Keep the panel open (never flash closed) and offer no
                // controls until it resolves.
                glFooter.style.display = DisplayStyle.None;
                glReceipt.style.display = DisplayStyle.None;
                glReviewBody.style.display = DisplayStyle.Flex;
                return;
            }

            glFooter.style.display = showReceipt ? DisplayStyle.None : DisplayStyle.Flex;
            // Paint order guarantee: the footer band always draws over any
            // content row scrolled beneath its zone.
            if (!showReceipt) glFooter.BringToFront();
            glReceipt.style.display = showReceipt ? DisplayStyle.Flex : DisplayStyle.None;
            glReviewBody.style.display = showReceipt ? DisplayStyle.None : DisplayStyle.Flex;

            if (showReceipt)
            {
                glReceiptLabel.text = greenlightReceiptCopy ?? string.Empty;
                return;
            }

            glHeadline.text = $"Greenlight review · {project.title}";
            RenderGlCompany();

            var heldQuote = pendingGreenlightQuote?.quote as StudioCastingQuoteSnapshot;
            RenderGlPackage(heldQuote);
            RenderGlCommitment(heldQuote);
            RenderGlCapacity(heldQuote);
            RenderGlBlockers();

            glNotice.text = greenlightQuoteNotice ?? string.Empty;
            glNotice.style.display = greenlightQuoteNotice != null ? DisplayStyle.Flex : DisplayStyle.None;

            var revision = liveStateRevision();
            var quoteFresh = heldQuote != null &&
                (!revision.HasValue || pendingGreenlightQuote.stateRevision == revision.Value);
            glCommitButton.text = heldQuote?.commitLabel ?? "Confirm Greenlight";
            glCommitButton.SetEnabled(quoteFresh && screenTestActionsEnabled() && GreenlightCommitArmed);
        }

        /// <summary>
        /// casting-gl-company: the Greenlight review's own reading of the
        /// company, in TWO labelled groups.
        ///
        /// P04A.2 §11: the Writer used to be the FIRST OF SIX visually
        /// identical rows here, which made the review read as if the Writer
        /// were a sixth staffing requirement. Under P04A.2 product law the
        /// author of a screenplay stays attached by exact stable id as the
        /// credited Writer permanently — the credit survives Development,
        /// Casting, Greenlight, Production, Post, Release, contract expiry and
        /// off-lot status — but it is NEVER an availability blocker and NEVER
        /// a world-presence claim. So the credit is presented as a credit,
        /// under SCREENPLAY, and the five real seats governed by Production
        /// exclusivity are presented under PRODUCTION COMPANY.
        ///
        /// The credit is NOT removed, nothing implies the Writer reports to
        /// the Stage, and no on-set rewrite mechanic is added. Every element
        /// name the previous shape published (casting-gl-company-{roleKey} and
        /// casting-gl-company-name-{roleKey}, including the writer's) is kept
        /// exactly — only the grouping around them is new.
        /// </summary>
        private void RenderGlCompany()
        {
            glCompany.Clear();
            if (project == null) return;

            var screenplayGroup = new VisualElement { name = "casting-gl-screenplay" };
            var screenplayHeading = new Label("SCREENPLAY") { name = "casting-gl-screenplay-heading" };
            screenplayHeading.AddToClassList("casting-gl-group-heading");
            screenplayGroup.Add(screenplayHeading);

            var writerCreditRow = new VisualElement { name = $"casting-gl-company-{CastingRoleKey}" };
            writerCreditRow.AddToClassList("casting-gl-company-row");
            writerCreditRow.Add(new Label($"{CompanyRoleLabels[0]} · {project.writerName}")
            {
                name = $"casting-gl-company-name-{CastingRoleKey}",
            });
            screenplayGroup.Add(writerCreditRow);

            var creditNote = new Label("Screenplay credit locked · Not an active Production assignment")
            {
                name = "casting-gl-screenplay-credit-note",
            };
            creditNote.AddToClassList("meta");
            screenplayGroup.Add(creditNote);
            glCompany.Add(screenplayGroup);

            var productionGroup = new VisualElement { name = "casting-gl-production-company" };
            var productionHeading = new Label("PRODUCTION COMPANY") { name = "casting-gl-production-company-heading" };
            productionHeading.AddToClassList("casting-gl-group-heading");
            productionGroup.Add(productionHeading);

            for (var index = 0; index < CompanyRoleKeys.Length; index++)
            {
                var roleKey = CompanyRoleKeys[index];
                // The Writer is not a seat in the company — already rendered
                // above, as a credit.
                if (roleKey == CastingRoleKey) continue;

                var row = new VisualElement { name = $"casting-gl-company-{roleKey}" };
                row.AddToClassList("casting-gl-company-row");

                var talentId = GetDraftValue(roleKey);
                StudioCastingCandidateSnapshot candidate = null;
                if (!string.IsNullOrEmpty(talentId))
                {
                    candidate = FindCandidateInPool(roleKey, talentId);
                    if (candidate == null) lastKnownCandidates.TryGetValue(talentId, out candidate);
                }

                if (candidate == null)
                {
                    row.Add(new Label($"{CompanyRoleLabels[index]} · Unfilled") { name = $"casting-gl-company-name-{roleKey}" });
                }
                else
                {
                    row.Add(new Label($"{CompanyRoleLabels[index]} · {candidate.name} — {candidate.professionLabel}")
                    {
                        name = $"casting-gl-company-name-{roleKey}",
                    });
                    if (candidate.evidence != null)
                    {
                        var evidenceLabel = new Label(
                            $"Camera-tested · est ~{candidate.evidence.estimate} (range {candidate.evidence.low}–{candidate.evidence.high})")
                        {
                            name = $"casting-gl-evidence-{roleKey}",
                        };
                        evidenceLabel.AddToClassList("meta");
                        row.Add(evidenceLabel);
                    }
                }
                productionGroup.Add(row);
            }

            glCompany.Add(productionGroup);
        }

        /// <summary>casting-gl-package: strengths/weaknesses/forecast/set-demand — every line the quote's own text, verbatim.</summary>
        private void RenderGlPackage(StudioCastingQuoteSnapshot quote)
        {
            glStrongestLabel.text = quote?.strongestAssignmentLine ?? string.Empty;
            glWeakestLabel.text = quote?.weakestAssignmentLine ?? string.Empty;
            glForecastLabel.text = quote?.forecastLine ?? string.Empty;
            glSetDemandLabel.text = quote?.setDemandLine ?? string.Empty;
        }

        /// <summary>
        /// casting-gl-commitment: the exact spend — every number the quote's
        /// own, never recomputed. Wave 7B visual-defect fix (FIX 4 —
        /// currency formatting): these six lines used to render each int
        /// plain (e.g. "$3104322") while the budget menus above already show
        /// the authority's own comma-formatted label text (e.g.
        /// "$3,104,322 ..."). <see cref="FormatDollars"/> applies ONLY
        /// thousands-separator presentation to the quote's own verbatim
        /// integer — the number itself is never touched, so this stays a
        /// client-side formatting concern, not a recompute.
        /// </summary>
        private void RenderGlCommitment(StudioCastingQuoteSnapshot quote)
        {
            glNegativeLabel.text = quote?.negative != null ? $"Negative: {FormatDollars(quote.negative.Value)}" : string.Empty;
            glMarketingLabel.text = quote?.marketing != null ? $"Marketing: {FormatDollars(quote.marketing.Value)}" : string.Empty;
            glFreelancerFeesLabel.text = quote?.freelancerFees != null ? $"Freelancer fees: {FormatDollars(quote.freelancerFees.Value)}" : string.Empty;
            glTotalImmediateLabel.text = quote?.totalImmediate != null ? $"Total immediate: {FormatDollars(quote.totalImmediate.Value)}" : string.Empty;
            glCashBeforeLabel.text = quote?.cashBefore != null ? $"Cash before: {FormatDollars(quote.cashBefore.Value)}" : string.Empty;
            glCashAfterLabel.text = quote?.cashAfter != null ? $"Cash after: {FormatDollars(quote.cashAfter.Value)}" : string.Empty;
            // `affordable` is a bare bool with no TS-authored line of its own
            // — styled only (never a fabricated sentence) so no client copy
            // is invented where no TS text exists for it.
            if (quote?.affordable == false) glCashAfterLabel.AddToClassList("blocked");
            else glCashAfterLabel.RemoveFromClassList("blocked");
        }

        /// <summary>
        /// Wave 7B visual-defect fix (FIX 4): thousands-separator currency
        /// presentation for a quote's own verbatim integer — culture-fixed
        /// (invariant) so the separator is always a comma regardless of the
        /// player's system locale, matching the budget menus' own
        /// server-authored "$3,104,322" style. Formats, never recomputes.
        /// </summary>
        private static string FormatDollars(int amount) =>
            $"${amount.ToString("N0", System.Globalization.CultureInfo.InvariantCulture)}";

        /// <summary>casting-gl-capacity: the board's own capacity fact plus the commit-time queue/starts-now framing — information, never a gate.</summary>
        private void RenderGlCapacity(StudioCastingQuoteSnapshot quote)
        {
            glCapacityBoardLabel.text = boardCapacityLine ?? string.Empty;
            glCapacityBoardLabel.style.display = string.IsNullOrEmpty(boardCapacityLine) ? DisplayStyle.None : DisplayStyle.Flex;

            if (quote == null)
            {
                glQueueFramingLabel.text = string.Empty;
                glQueueNoteLabel.text = string.Empty;
                glQueueNoteLabel.style.display = DisplayStyle.None;
                return;
            }

            glQueueFramingLabel.text = quote.queues ? "WILL QUEUE" : "Starts immediately";
            var showQueueNote = quote.queues && !string.IsNullOrEmpty(quote.queueNote);
            glQueueNoteLabel.text = showQueueNote ? quote.queueNote : string.Empty;
            glQueueNoteLabel.style.display = showQueueNote ? DisplayStyle.Flex : DisplayStyle.None;
        }

        /// <summary>casting-gl-blockers: the package readiness's own blocker sentences — informational, never a client-side gate on the commit control.</summary>
        private void RenderGlBlockers()
        {
            glBlockers.Clear();
            var blockers = project?.packageReadiness?.blockers;
            if (blockers == null) return;
            foreach (var blocker in blockers)
            {
                if (blocker == null) continue;
                var row = new VisualElement { name = $"casting-gl-blocker-{blocker.role}-{blocker.code}" };
                row.AddToClassList("casting-gl-blocker-row");
                var message = new Label(blocker.message) { name = $"casting-gl-blocker-message-{blocker.role}-{blocker.code}" };
                message.AddToClassList("blocked");
                var remedy = new Label(blocker.remedy) { name = $"casting-gl-blocker-remedy-{blocker.role}-{blocker.code}" };
                remedy.AddToClassList("meta");
                row.Add(message);
                row.Add(remedy);
                glBlockers.Add(row);
            }
        }

        /// <summary>Enabled only once DraftGaps() is empty. Entering always re-arms and re-asks fresh — never reuses a stale or rejected quote.</summary>
        public bool OpenGreenlightReview()
        {
            if (context == null || project == null) return false;
            if (DraftGaps().Count > 0) return false;
            context.GreenlightReviewOpen = true;
            GreenlightDraftChanged();
            greenlightArmedAtRealtime = Time.realtimeSinceStartup;
            RenderAll();
            return true;
        }

        public bool CloseGreenlightReview()
        {
            if (context == null || !context.GreenlightReviewOpen) return false;
            context.GreenlightReviewOpen = false;
            RenderAll();
            return true;
        }

        /// <summary>[Close] on the receipt: returns to the lot-facing workspace root (closes the whole workspace).</summary>
        public bool CloseGreenlightReceipt()
        {
            if (!greenlightReceiptShowing) return false;
            greenlightReceiptShowing = false;
            greenlightReceiptCopy = null;
            closeRequested();
            return true;
        }

        /// <summary>Invalidates any held/pending greenlight quote — the MaintainQuote precedent's own reaction to a draft/budget edit.</summary>
        private void GreenlightDraftChanged()
        {
            pendingGreenlightQuote = null;
            pendingGreenlightQuoteCommandId = null;
            greenlightQuoteDirty = true;
            greenlightQuoteNotice = null;
        }

        private StudioCastingDraftPayload BuildGreenlightDraftIfComplete()
        {
            if (project == null || context == null) return null;
            if (DraftGaps().Count > 0) return null;
            return new StudioCastingDraftPayload
            {
                kind = StudioCastingDraftPayloadKindValues.GreenlightPackage,
                projectId = project.projectId,
                directorId = context.DirectorId,
                castLead = context.LeadId,
                castAntagonist = context.AntagonistId,
                castSupport = context.SupportId,
                craftLeadId = context.CraftLeadId,
                budgetNegative = context.NegativeAmount,
                budgetMarketing = context.MarketingAmount,
            };
        }

        /// <summary>
        /// The MaintainQuote-precedent poll for the greenlight package,
        /// mirroring MaintainScreenTestQuote exactly: invalidate on a
        /// revision change, then — while the review is open, nothing else is
        /// already in flight, and the draft is complete — ask fresh. Reuses
        /// the SAME single-flight request/in-flight seams Configure wires
        /// (RequestCastingQuote dispatches by the draft's own `kind`, so no
        /// separate request delegate exists for this second draft kind).
        /// </summary>
        public void MaintainGreenlightQuote()
        {
            if (context == null || project == null) return;
            if (greenlightReceiptShowing || greenlightCommitInFlight) return;
            if (!(CurrentMode() == CastingWorkspaceMode.Base && context.GreenlightReviewOpen)) return;

            var revision = liveStateRevision();
            if (pendingGreenlightQuote != null && revision.HasValue && pendingGreenlightQuote.stateRevision != revision.Value)
            {
                pendingGreenlightQuote = null;
                greenlightQuoteDirty = true;
                RenderGreenlightReview(true, false);
            }

            if (!greenlightQuoteDirty || screenTestQuoteInFlight()) return;
            var draft = BuildGreenlightDraftIfComplete();
            if (draft == null) return;
            var commandId = requestScreenTestQuoteFor(draft);
            if (commandId == null) return;
            pendingGreenlightQuoteCommandId = commandId;
            greenlightQuoteDirty = false;
        }

        /// <summary>Forwards an accepted casting quote. Ignored unless it matches OUR held commandId (the screen-test handler ignores it symmetrically).</summary>
        public void HandleGreenlightQuoteAccepted(StudioBridgeQuoteResponse quoted)
        {
            if (quoted == null || quoted.commandId != pendingGreenlightQuoteCommandId) return;
            if (!(quoted.quote is StudioCastingQuoteSnapshot member) || member.kind != StudioCastingQuoteSnapshotKindValues.GreenlightPicture) return;
            var revision = liveStateRevision();
            if (revision.HasValue && quoted.stateRevision != revision.Value)
            {
                greenlightQuoteDirty = true;
                return;
            }
            pendingGreenlightQuote = quoted;
            greenlightQuoteNotice = null;
            // A fresh quote re-arms the commit — the control that appears (or
            // relabels) under it cannot swallow a stray click that landed on
            // whatever revealed it.
            greenlightArmedAtRealtime = Time.realtimeSinceStartup;
            if (context != null && context.GreenlightReviewOpen && !greenlightReceiptShowing)
                RenderGreenlightReview(true, false);
        }

        /// <summary>Forwards the authority's structured refusal of the greenlight QUOTE (not the commit). Preserves every draft/budget choice — only the quote dies.</summary>
        public void HandleGreenlightQuoteRejected(StudioBridgeRejectedResponse rejected)
        {
            if (rejected == null || rejected.commandId != pendingGreenlightQuoteCommandId) return;
            pendingGreenlightQuoteCommandId = null;
            pendingGreenlightQuote = null;
            // P04A.2 — two KINDS of refusal arrive here, and the re-arm follows
            // the kind, never the count of reason codes:
            //
            //   ENVELOPE refusals — the authority never looked at the draft.
            //     Bridge session.ts `quoteGuard` emits exactly two, from the one
            //     guard: SESSION_MISMATCH (the ask names a bridge session that
            //     is no longer the authority's) and STALE_REVISION (the ask
            //     carried expectedStateRevision N; the authority has moved past
            //     it). `rejectionFor` gives them the parallel envelope
            //     categories "session-mismatch" and "state-stale". Living Time
            //     makes STALE_REVISION ordinary — the week turns while the ask
            //     is in flight — and either one would otherwise latch the poll
            //     off for good: MaintainGreenlightQuote's revision-invalidation
            //     branch only re-arms while a quote is HELD, and this handler
            //     has just cleared it, so no later week roll could revive the
            //     ask and Confirm Greenlight would stay dead until the player
            //     edited the draft or left and reopened. Re-arm and the next
            //     tick asks again at the CURRENT revision and session.
            //     Re-arming SESSION_MISMATCH cannot spin:
            //     StudioBridgeClient.RequestCastingQuote returns null without
            //     posting unless ConnectionState is Live with no casting quote
            //     in flight, and on null MaintainGreenlightQuote returns with
            //     the dirty flag still SET — so the re-arm only means "ask
            //     again once the session is healthy".
            //
            //   DRAFT refusals — ENGINE_REJECTED, the authority reading THIS
            //     draft and refusing it. Unchanged (Wave 7A-fix, see
            //     StudioCastingJourneyProofRunner): never re-ask the same
            //     refused draft in a loop. Change an occupant or a budget
            //     (GreenlightDraftChanged re-arms), or leave and reopen.
            if (string.Equals(
                    rejected.reasonCode,
                    StudioBridgeRejectedResponseReasonCodeValues.STALEREVISION,
                    StringComparison.Ordinal) ||
                string.Equals(
                    rejected.reasonCode,
                    StudioBridgeRejectedResponseReasonCodeValues.SESSIONMISMATCH,
                    StringComparison.Ordinal))
                greenlightQuoteDirty = true;
            greenlightQuoteNotice = rejected.rejection != null
                ? rejected.rejection.blocker + " " + rejected.rejection.remedy
                : rejected.message;
            if (context != null && context.GreenlightReviewOpen && !greenlightReceiptShowing)
                RenderGreenlightReview(true, false);
        }

        /// <summary>An unresolved greenlight quote simply re-asks; nothing about the draft changes.</summary>
        public void HandleGreenlightQuoteUnresolved(string message)
        {
            pendingGreenlightQuoteCommandId = null;
            greenlightQuoteDirty = true;
            greenlightQuoteNotice = message;
            if (context != null && context.GreenlightReviewOpen && !greenlightReceiptShowing)
                RenderGreenlightReview(true, false);
        }

        /// <summary>True once the shared 0.7s arm window has passed since the commit control last (re)appeared.</summary>
        public bool GreenlightCommitArmed =>
            StudioFoundingCardContracts.CommitArmed(greenlightArmedAtRealtime, Time.realtimeSinceStartup);

        /// <summary>
        /// Commits the held quoted greenlight intent through the ordinary
        /// submit path, exactly once, and only while armed with a
        /// current-revision quote. Captures the quote's OWN facts (queues/
        /// title/projectId/totalImmediate) and the pre-commit productions
        /// list BEFORE dispatch, so the receipt can resolve truthfully even
        /// once the bound project itself may have left the live board.
        /// </summary>
        public bool CommitGreenlightQuote()
        {
            if (context == null || project == null) return false;
            if (!(CurrentMode() == CastingWorkspaceMode.Base && context.GreenlightReviewOpen)) return false;
            if (greenlightReceiptShowing || greenlightCommitInFlight) return false;
            if (!GreenlightCommitArmed) return false;
            var quoted = pendingGreenlightQuote;
            if (quoted == null) return false;
            var revision = liveStateRevision();
            if (!revision.HasValue || quoted.stateRevision != revision.Value)
            {
                pendingGreenlightQuote = null;
                greenlightQuoteDirty = true;
                RenderGreenlightReview(true, false);
                return false;
            }

            if (!(quoted.quote is StudioCastingQuoteSnapshot quote) || quote.kind != StudioCastingQuoteSnapshotKindValues.GreenlightPicture) return false;
            greenlightExpectedQueues = quote.queues;
            greenlightExpectedTitle = quote.title;
            greenlightExpectedProjectId = quote.projectId;
            greenlightExpectedTotalImmediate = quote.totalImmediate;
            preCommitProductionIds = CapturePreCommitProductionIds();

            // Consumed immediately: even a second activation landing in the
            // same frame finds no quote and refuses, guaranteeing exactly
            // one dispatch per accepted quote regardless of click cadence.
            pendingGreenlightQuote = null;
            greenlightCommitInFlight = true;
            var dispatched = commitGreenlightQuoteFor(quote);
            if (!dispatched)
            {
                greenlightCommitInFlight = false;
                greenlightQuoteDirty = true;
            }
            RenderGreenlightReview(true, greenlightReceiptShowing);
            return dispatched;
        }

        private HashSet<string> CapturePreCommitProductionIds()
        {
            var ids = new HashSet<string>(StringComparer.Ordinal);
            var productions = currentActiveProductionsProvider();
            if (productions == null) return ids;
            foreach (var production in productions)
                if (production != null && !string.IsNullOrEmpty(production.id)) ids.Add(production.id);
            return ids;
        }

        /// <summary>
        /// The successor snapshot arrives bundled with the acceptance event
        /// itself (Host forwards StudioBridgeClient's generic CommandAccepted
        /// here). RECEIPT LAW: expectation = the quote's own startsNow/queues
        /// captured at commit time; queued always resolves to the fixed
        /// zero-commitment copy (true the instant the commit was accepted —
        /// nothing further to verify); formed is verified from the successor
        /// snapshot (the project's board entry gone, and/or a new production
        /// entry) — unambiguous only if that check confirms it, else the
        /// neutral copy, never a fabricated formation claim. Closes ONLY the
        /// review layer; never moves a camera.
        /// </summary>
        public void HandleGreenlightCommitAccepted(StudioBridgeSnapshotResponse response)
        {
            if (!greenlightCommitInFlight) return;
            greenlightCommitInFlight = false;

            string copy;
            if (greenlightExpectedQueues)
            {
                copy = "Greenlight queued — no production, budget, slot, or talent commitment exists until admission" +
                    (string.IsNullOrEmpty(greenlightExpectedTitle) ? string.Empty : $" · {greenlightExpectedTitle}");
            }
            else
            {
                var successorBoard = response?.snapshot?.casting?.casting?.board;
                var stillOnBoard = FindProjectInBoard(successorBoard, greenlightExpectedProjectId) != null;
                var gainedProduction = HasNewProduction(response);
                // Wave 7B visual-defect fix (FIX 4): same verbatim quote
                // amount captured at commit time, now thousands-separated
                // like every other workspace-rendered currency line.
                copy = (!stillOnBoard || gainedProduction)
                    ? $"{greenlightExpectedTitle} greenlit — production formed · " +
                      $"{FormatDollars(greenlightExpectedTotalImmediate.GetValueOrDefault())} committed"
                    : $"Committed — studio records updated · {greenlightExpectedTitle}";
            }

            greenlightReceiptCopy = copy;
            greenlightReceiptShowing = true;
            // The authority accepted the commit: this package is no longer a
            // pending choice. The ids stay for the receipt, but the close path
            // must stop calling them an uncommitted draft.
            if (context != null) context.GreenlightCommitted = true;
            if (context != null) context.GreenlightReviewOpen = false;
            RenderAll();
        }

        /// <summary>
        /// The authority's structured refusal of the COMMIT (not the quote
        /// ask). No local mutation: the full draft/pins/budgets/scroll
        /// survive untouched, the review stays open, and the held quote dies
        /// so the next MaintainGreenlightQuote tick asks fresh.
        /// </summary>
        public void HandleGreenlightCommitRejected(StudioBridgeRejectedResponse rejected)
        {
            if (!greenlightCommitInFlight) return;
            greenlightCommitInFlight = false;
            greenlightQuoteDirty = true;
            greenlightQuoteNotice = rejected?.rejection != null
                ? rejected.rejection.blocker + " " + rejected.rejection.remedy
                : rejected?.message;
            RenderGreenlightReview(true, false);
        }

        private bool HasNewProduction(StudioBridgeSnapshotResponse response)
        {
            var successorProductions = response?.snapshot?.productions?.activeProductions;
            if (successorProductions == null) return false;
            foreach (var production in successorProductions)
            {
                if (production == null || string.IsNullOrEmpty(production.id)) continue;
                if (preCommitProductionIds == null || !preCommitProductionIds.Contains(production.id)) return true;
            }
            return false;
        }

        private static StudioCastingProjectSnapshot FindProjectInBoard(StudioCastingBoardSnapshot board, string projectId)
        {
            if (board?.projects == null || string.IsNullOrEmpty(projectId)) return null;
            foreach (var candidateProject in board.projects)
                if (candidateProject != null && string.Equals(candidateProject.projectId, projectId, StringComparison.Ordinal))
                    return candidateProject;
            return null;
        }

        /// <summary>Wiped whenever Bind() sees a brand-new context instance (a fresh OpenCasting) — never on an ordinary same-session rebind.</summary>
        private void ResetGreenlightTransientState()
        {
            pendingGreenlightQuote = null;
            pendingGreenlightQuoteCommandId = null;
            greenlightQuoteDirty = true;
            greenlightQuoteNotice = null;
            greenlightArmedAtRealtime = float.NegativeInfinity;
            greenlightCommitInFlight = false;
            greenlightReceiptShowing = false;
            greenlightReceiptCopy = null;
            greenlightExpectedQueues = false;
            greenlightExpectedTitle = null;
            greenlightExpectedProjectId = null;
            greenlightExpectedTotalImmediate = null;
            preCommitProductionIds = null;
        }

        // ── Wave 5: last-known-candidate identity cache ──────────────────────

        private void CacheKnownCandidates()
        {
            if (project == null) return;
            CacheAll(project.directorCandidates);
            CacheAll(project.leadCandidates);
            CacheAll(project.antagonistCandidates);
            CacheAll(project.supportCandidates);
            CacheAll(project.craftCandidates);
        }

        private void CacheAll(StudioCastingCandidateSnapshot[] pool)
        {
            if (pool == null) return;
            foreach (var candidate in pool)
                if (candidate != null && !string.IsNullOrEmpty(candidate.talentId))
                    lastKnownCandidates[candidate.talentId] = candidate;
        }
    }
}
