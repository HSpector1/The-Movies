# Coherent61 compiler correction R2

KEEP sparse3file fix for installation and mandatory canonical regeneration. SOURCE4545a08a802277ed88f4621bcdda61ccc119b43c0a0726f9692b1333c00d185f/MANIFEST14143c3aeb8ba6adecd4bb2023f61f12a863e083e79ecdbcb8897ad656637d54 verified; all declared pre/post hashes verified.

Actual gate root2/48s, UI2/90s, Bridge2/57s: no checks/runtime assertions executed. Parent independent PASS1617sources245inputs/6strictchecks0errors retained. All diagnostics inspected: duplicate Production import; includes receiver narrower foreign result (required participants) than own ReleaseRecord (optional historical participants); string-only numeric enumeration causing schema and paidReports return incompatibility. Preserve failed gate; initial static source review missed these type-composition issues.

rights removes only duplicate import, retaining Production from first import. Tick types actual shared Standing records with Pick<ReleaseRecord,filmResult|benchmarks|ctx> and uses the same alias for combined list and includes receiver. Addresses actual failing receiver without cast, cloned records, fabricated broadcast/develop, participant weakening, order or membership behavior change.

PaidReportReceipt policy becomes nullable(integer(min0,max1)). DSL integer emits JSON typeinteger: exactly numeric0/1 plusnull, no fraction/widerint. Inferred number|null matches actual policy producer. No core/parser/emitter change; other fields unchanged. Prior generated61 string-type numeric-enum output is superseded: fresh canonical outputs/identity and checks are mandatory before retry. Projection61/protocol4 unchanged; no next hash invented.

Static only; no compiler/generator/runtime or K/R writes. Positive/refusal/rollback and original5s remain pending; zero runtime credit from failed gate.
