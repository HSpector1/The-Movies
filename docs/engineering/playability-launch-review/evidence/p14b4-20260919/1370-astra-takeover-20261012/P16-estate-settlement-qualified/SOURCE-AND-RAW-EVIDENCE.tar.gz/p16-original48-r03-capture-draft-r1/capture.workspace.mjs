export default [{
 root: "/Users/zacheryspector/The-Movies-headless-program",
 resolve: {alias: {vitest: "/Users/zacheryspector/The-Movies-headless-program/node_modules/vitest/dist/index.js"}},
 test: {name:'original48-r03-capture',environment:'node',include:["/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-r03-capture-draft-r1/capture.test.ts"],fileParallelism:false,testTimeout:5000},
}]
