// Source parser only: never invokes TypeScript compiler/checker or Vitest.
const ts=require('/Users/zacheryspector/The-Movies-headless-program/node_modules/typescript/lib/typescript.js');
const fs=require('fs'); const crypto=require('crypto');
const entries=[["tests/p16-estate-join.test.ts", "/Users/zacheryspector/studio-specialists/p16/tests/p16-estate-join.test.ts"], ["tests/p16a-save-v46.test.ts", "/Users/zacheryspector/studio-specialists/p16/tests/p16a-save-v46.test.ts"], ["tests/p16-estate-d-ceremony.test.ts", "/Users/zacheryspector/studio-specialists/p16/tests/p16-estate-d-ceremony.test.ts"], ["tests/p16-estate-observed-migration.test.ts", "/Users/zacheryspector/studio-specialists/p16/tests/p16-estate-observed-migration.test.ts"], ["tests/p16-estate-current49-rollback.test.ts", "/Users/zacheryspector/studio-specialists/p16/tests/p16-estate-current49-rollback.test.ts"]];
const rows=entries.map(([file,input])=>{
 const text=fs.readFileSync(input,'utf8'),sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true),names=[];
 if(sf.parseDiagnostics.length)throw Error('source parse diagnostics '+file);
 function walk(n,groups){
  if(ts.isCallExpression(n)){
   const expression=n.expression.getText(sf);
   if(/^(describe|it|test)(\.|$)/.test(expression)){
    if(!['describe','it','test'].includes(expression))throw Error('unsupported test wrapper '+expression);
    const label=n.arguments[0];if(!label||!ts.isStringLiteralLike(label))throw Error('dynamic test identity');
    if(expression!=='describe')names.push([...groups,label.text].join(' '));
    else {const callback=n.arguments.find(a=>ts.isArrowFunction(a)||ts.isFunctionExpression(a));if(!callback)throw Error('missing describe callback');walk(callback,[...groups,label.text]);}
    return;
   }
  }
  ts.forEachChild(n,c=>walk(c,groups));
 }
 walk(sf,[]);return {file,sourceSHA256:crypto.createHash('sha256').update(text).digest('hex'),names};
});fs.writeFileSync(__dirname+'/EXPECTED-IDENTITIES.json',JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows.map(r=>({file:r.file,count:r.names.length,sha:r.sourceSHA256}))));
