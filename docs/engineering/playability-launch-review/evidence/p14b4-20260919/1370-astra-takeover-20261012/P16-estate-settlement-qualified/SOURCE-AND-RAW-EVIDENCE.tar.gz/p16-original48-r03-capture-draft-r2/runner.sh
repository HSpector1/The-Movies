#!/bin/bash
# UNRUN: parent-bound original48 single capture, no source candidate or compiler.
set -u
C=/Users/zacheryspector/The-Movies-headless-program
R="$C"
D=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-r03-capture-draft-r2
OUT=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-r03-capture-wrapper-r2-run
SCRIPT="$D/runner.sh"; AUTO_HELPER="$D/auto_freeze.py"; SELECTION="$D/SELECTION.json"; BINDINGS="$D/BINDINGS.json"
DRIVER="$D/capture.test.ts"; WORKSPACE="$D/capture.workspace.mjs"; DRIVER_PINS="$D/PINS.json"
export OUT SCRIPT AUTO_HELPER SELECTION BINDINGS DRIVER WORKSPACE DRIVER_PINS
export P16_ORIGINAL48_CAPTURE_OUT=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-r03-capture-r2-run
export PATH=/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin:$R/.venv/bin:$PATH GIT_OPTIONAL_LOCKS=0
cd "$C" || exit 90
disk_floor() {
  local need=$1 avail
  avail=$(df -Pk "$R" | awk 'NR==2 {print $4}')
  [[ "$avail" =~ ^[0-9]+$ ]] && [ "$avail" -ge "$need" ] || { echo "STOP: disk below ${need}KiB" >&2; return 97; }
}
freeze_snapshot() {
python3 -I - "$C" <<'SNAP'
import os,sys,json,hashlib,subprocess,pathlib,uuid
r=pathlib.Path(sys.argv[1]);g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(r)]
def git(*a):return subprocess.check_output(g+list(a))
def digest(q):
 q=pathlib.Path(q)
 if q.is_symlink():return ['symlink',os.readlink(q)]
 if q.is_file():return ['file',hashlib.sha256(q.read_bytes()).hexdigest(),q.stat().st_mode&0o777]
 return ['missing']
binding=json.loads(pathlib.Path(os.environ['BINDINGS']).read_text())
tracked={x.decode() for x in git('ls-files','-z').split(b'\0') if x};untracked={x.decode() for x in git('ls-files','--others','--exclude-standard','-z').split(b'\0') if x}
def scoped(x):
 q=pathlib.PurePosixPath(x)
 if q.suffix in ('.ts','.tsx','.mts','.cts','.js','.mjs','.cjs','.d.ts') and q.parts[0] in ('src','tests','ui','bridge','generated','scripts','tools'):return True
 if q.parts[0] in ('src','ui','bridge','scripts','tools') and 'public' not in q.parts and q.suffix in ('.json','.yaml','.yml'):return True
 return len(q.parts)==1 and q.suffix in ('.json','.js','.mjs','.cjs','.yaml','.yml')
paths={x for x in tracked|untracked if scoped(x)}
d={'HEAD':git('rev-parse','HEAD').decode().strip(),'index':hashlib.sha256(git('ls-files','--stage','-z')).hexdigest(),'cached':hashlib.sha256(git('diff','--cached','--binary')).hexdigest(),'diff':hashlib.sha256(git('diff','--binary')).hexdigest(),'status':git('status','--porcelain=v1','-z','--untracked-files=all').hex(),'untrackedPaths':sorted(untracked),'files':{x:digest(r/x) for x in sorted(paths)},'inputs':{}}
inputs=[pathlib.Path(os.environ[k]) for k in ('SCRIPT','AUTO_HELPER','SELECTION','BINDINGS','DRIVER','WORKSPACE','DRIVER_PINS')]
inputs += [r/'package-lock.json',r/'package.json']+[r/x for x in binding['inputs']]
for q in inputs:
 value=digest(q)
 if value[0]!='file':raise SystemExit('STOP: missing/unsafe compiled input '+str(q))
 d['inputs'][str(q)]=value
receipt=pathlib.Path(os.environ['OUT'])/('metadata-'+uuid.uuid4().hex)
d['autoMetadata']=json.loads(subprocess.check_output([sys.executable,'-I',os.environ['AUTO_HELPER'],'capture',str(r),str(receipt)]))
print(json.dumps(d,sort_keys=True))
SNAP
}
check_freeze() {
  freeze_snapshot > "$OUT/freeze-current.json" || return 98
  python3 -I "$AUTO_HELPER" check "$OUT/freeze.json" "$OUT/freeze-current.json" >> "$OUT/metadata-checks.jsonl" 2>> "$OUT/metadata-checks-errors.log" || return 98
}
require_lane() {
python3 -I - <<'LANE'
import os,pathlib,subprocess,shlex
p=pathlib.Path('/Users/zacheryspector/studio-scratch/HEAVY-LANE-LOCK')
if p.is_symlink() or not p.is_file() or p.stat().st_nlink!=1:raise SystemExit('STOP: unsafe or absent lane lock')
marker=p.read_text().strip();pid=os.getppid();found=False
while pid>1:
 args=subprocess.check_output(['ps','-p',str(pid),'-o','args='],text=True).strip();parts=shlex.split(args)
 for i,x in enumerate(parts):
  if x.endswith('/lane-run-r8.sh') and len(parts)>i+2 and marker.startswith('lane-run '+parts[i+2]+' token='):found=True
 pid=int(subprocess.check_output(['ps','-p',str(pid),'-o','ppid='],text=True).strip())
if not found:raise SystemExit('STOP: gate must be child of owned existing lane')
LANE
}
require_lane || exit 99
[ "$(node --version)" = v20.20.2 ] || exit 90
[ "$(command -v python3)" = "$R/.venv/bin/python3" ] || exit 90
disk_floor 3670016 || exit 97
[ ! -e "$OUT" ] && [ ! -L "$OUT" ] && [ ! -e "$P16_ORIGINAL48_CAPTURE_OUT" ] && [ ! -L "$P16_ORIGINAL48_CAPTURE_OUT" ] || exit 90
python3 -I - "$C" <<'ADMIT'
import pathlib,json,os,sys,subprocess,hashlib
r=pathlib.Path(sys.argv[1]);g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(r)]
def need(ok,msg):
 if not ok:raise SystemExit('STOP: '+msg)
for key in ('SCRIPT','AUTO_HELPER','SELECTION','BINDINGS','DRIVER','WORKSPACE','DRIVER_PINS'):
 q=pathlib.Path(os.environ[key]);pin=os.environ.get('CAPTURE_BOOTSTRAP_'+key+'_SHA256','PENDING');need(len(pin)==64 and q.is_file() and not q.is_symlink() and hashlib.sha256(q.read_bytes()).hexdigest()==pin,'external '+key+' pin')
b=json.loads(pathlib.Path(os.environ['BINDINGS']).read_text());p=json.loads(pathlib.Path(os.environ['DRIVER_PINS']).read_text())
need('PENDING' not in b['HEAD'] and p['HEAD']==b['HEAD'],'explicit current HEAD binding');need(subprocess.check_output(g+['rev-parse','HEAD']).decode().strip()==b['HEAD'],'HEAD');need(subprocess.check_output(g+['rev-parse','HEAD:src']).decode().strip()==b['sourceTree']==p['sourceTree'],'actual48 source tree')
need(not subprocess.check_output(g+['diff','--cached','--name-only']),'staged changes');need(not subprocess.check_output(g+['ls-files','--unmerged','-z']),'unmerged');need(not subprocess.check_output(g+['ls-files','--others','--exclude-standard','-z']),'foreign untracked')
changed={x.decode() for x in subprocess.check_output(g+['diff','--name-only','-z']).split(b'\0') if x};need(changed<={'HANDOFF.md'},'foreign unstaged')
for name,pin in p['files'].items():need(hashlib.sha256((r/name).read_bytes()).hexdigest()==pin,'original owner/helper '+name)
need(json.loads(pathlib.Path(os.environ['SELECTION']).read_text())==['node','node_modules/vitest/vitest.mjs','run','--workspace',os.environ['WORKSPACE'],'--project','original48-r03-capture','--no-file-parallelism','--no-cache','--reporter=default','--reporter=json','--outputFile.json='+str(pathlib.Path(os.environ['OUT'])/'results.json')],'literal one capture command')
ADMIT
[ "$?" = 0 ] || exit 98
mkdir "$OUT" || exit 90
run() {
 local name=$1 ec start end; shift
 check_freeze || return 98
 disk_floor 3145728 || return 97
 start=$(date +%s)
 nice -n 10 "$@" > "$OUT/$name.log" 2>&1
 ec=$?;end=$(date +%s)
 python3 -I - "$OUT" "$name" "$ec" "$start" "$end" "$@" <<'RECORD'
import json,pathlib,sys
out,name,ec,start,end,*cmd=sys.argv[1:]
r={'name':name,'exit':int(ec),'startEpoch':int(start),'endEpoch':int(end),'seconds':int(end)-int(start),'node':'v20.20.2','command':cmd,'log':str(pathlib.Path(out)/(name+'.log'))}
with (pathlib.Path(out)/'results.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
print(json.dumps({k:r[k] for k in ['name','exit','seconds']}),flush=True)
RECORD
 [ "$?" = 0 ] || return 98
 check_freeze || return 98
 disk_floor 3145728 || return 97
 return "$ec"
}
# All terminal paths after this point retain serial group statuses and child exit.
export FOLLOWUP_GROUPS_JSON='{}'
finish() {
 local exit_code=$?
 trap - EXIT
 python3 -I - "$OUT" "$exit_code" <<'TERMINAL'
import json,os,pathlib,sys
out=pathlib.Path(sys.argv[1]);code=int(sys.argv[2])
r={'overallExit':code,'groups':json.loads(os.environ['FOLLOWUP_GROUPS_JSON']),
'scope':'original48 capture producer only; default5s leaf remains binding; no49 qualification',
'identityAccounting':'parent independent complete reporter identity validation required',
'freezeQualification':'see preserved before/post snapshots and metadata checks; no blanket success on abnormal stop'}
with (out/'terminal.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
TERMINAL
 [ "$?" = 0 ] || exit 98
 exit "$exit_code"
}
trap finish EXIT
remember() {
 FOLLOWUP_GROUPS_JSON=$(python3 -I - "$FOLLOWUP_GROUPS_JSON" "$1" "$2" <<'STATUS'
import json,sys
r=json.loads(sys.argv[1]);r[sys.argv[2]]=int(sys.argv[3]);print(json.dumps(r))
STATUS
 ) || exit 98
 export FOLLOWUP_GROUPS_JSON
}
freeze_snapshot > "$OUT/freeze.json" || exit 98
run capture node node_modules/vitest/vitest.mjs run --workspace "$WORKSPACE" --project original48-r03-capture --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json"
ec=$?;remember capture "$ec"
[ "$ec" -le 1 ] || exit "$ec"
python3 -I - "$OUT" "$ec" "$P16_ORIGINAL48_CAPTURE_OUT" <<'REPORT'
import pathlib,json,sys,hashlib
out=pathlib.Path(sys.argv[1]);ec=int(sys.argv[2]);capture=pathlib.Path(sys.argv[3]);d=json.loads((out/'results.json').read_text());files=d['testResults'];a=[x for f in files for x in f['assertionResults']]
assert len(files)==1 and len(a)==1 and a[0]['status'] in ('passed','failed')
assert a[0]['fullName']=='original48 one retained R03 estate route captures130/131/132/134/144 with positiveclaims and active132run'
assert d['numTotalTests']==1 and d['numPassedTests']==sum(x['status']=='passed' for x in a) and d['numFailedTests']==sum(x['status']=='failed' for x in a) and d['numPendingTests']==d['numTodoTests']==0
assert d['success']==(ec==0)==(a[0]['status']=='passed')
budget=(a[0].get('duration') is not None and a[0]['duration']<=5000)
if ec==0:
 import os
 assert capture.is_dir() and not capture.is_symlink()
 manifest=capture/'CAPTURE-MANIFEST.json';assert manifest.is_file() and not manifest.is_symlink()
 m=json.loads(manifest.read_text());expected={'r04-pre162.save48.json':162,'r04-actual163.save48.json':163,'r04-archived176.save48.json':176}
 assert len(m['files'])==3 and {x['name'] for x in m['files']}==set(expected)
 assert {x.name for x in capture.iterdir()}==set(expected)|{'CAPTURE-MANIFEST.json'}
 assert m['source']==json.loads(pathlib.Path(os.environ['DRIVER_PINS']).read_text())
 for row in m['files']:
  p=capture/row['name'];assert p.is_file() and not p.is_symlink()
  b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['bytes']
  raw=json.loads(b);assert raw['saveVersion']==48 and raw['state']['market']['tick']==row['week']==expected[row['name']]
(out/'qualification.json').write_text(json.dumps({'childExit':ec,'reportedStatus':a[0]['status'],'durationMs':a[0].get('duration'),'budgetQualified':budget,'scope':'captureproducer, not49 semanticqualification'},indent=2)+'\n')
if ec==0 and not budget:raise SystemExit(3)
REPORT
proof=$?
[ "$proof" = 0 ] || [ "$proof" = 3 ] || exit 98
check_freeze || exit 98
disk_floor 3145728 || exit 97
[ "$ec" = 0 ] && [ "$proof" = 0 ] || exit 1
exit 0
