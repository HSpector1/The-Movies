#!/bin/bash
# UNRUN, fail-closed compiler diagnostic. Parent alone binds and launches.
set -u
C=/Users/zacheryspector/studio-specialists/p16
R="$C"
D=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-estate-d-success-runner-r2
OUT=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-estate-d-success-r2-run
SCRIPT="$D/runner.sh"; AUTO_HELPER="$D/auto_freeze.py"; SELECTION="$D/SELECTION.json"; BINDINGS="$D/BINDINGS.json"
export OUT SCRIPT AUTO_HELPER SELECTION BINDINGS
export P16_ORIGINAL48_CAPTURE_ROOT=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-closure-capture-r2-run
export P16_JOIN_PREC48_PATH=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-closure-capture-r2-run/r04-pre162.save48.json
export P16_JOIN_PREC48_SHA256=cd11f369558e09f1d65d8e848374ea028f4c5f666c168b5527e48c098cfdfb19
export P16_JOIN_CLOSED48_PATH=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-closure-capture-r2-run/r04-actual163.save48.json
export P16_JOIN_CLOSED48_SHA256=c17b7aa82bd09e6988867e149ed0266803d8e432cfcd8842d9c2aca1f7ace8ad
export PATH=/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin:/Users/zacheryspector/The-Movies-headless-program/.venv/bin:$PATH GIT_OPTIONAL_LOCKS=0
cd "$C" || exit 90
disk_floor() {
  local need=$1 avail
  avail=$(df -Pk "$R" | awk 'NR==2 {print $4}')
  [[ "$avail" =~ ^[0-9]+$ ]] && [ "$avail" -ge "$need" ] || { echo "STOP: disk below ${need}KiB" >&2; return 97; }
}
freeze_snapshot() {
python3 -I - "$C" <<'SNAP'
import os,sys,json,hashlib,subprocess,pathlib,uuid
r=pathlib.Path(sys.argv[1]);g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(r)]
def git(*a):return subprocess.check_output(g+list(a))
def digest(q):
 q=pathlib.Path(q)
 if q.is_symlink():return ['symlink',os.readlink(q)]
 if q.is_file():return ['file',hashlib.sha256(q.read_bytes()).hexdigest(),q.stat().st_mode&0o777]
 return ['missing']
binding=json.loads(pathlib.Path(os.environ['BINDINGS']).read_text());p=pathlib.Path(binding['package']);m=json.loads((p/'MANIFEST.json').read_text())
tracked={x.decode() for x in git('ls-files','-z').split(b'\0') if x};untracked={x.decode() for x in git('ls-files','--others','--exclude-standard','-z').split(b'\0') if x}
def scoped(x):
 q=pathlib.PurePosixPath(x)
 if x in {f['path'] for f in m['files']}:return True
 if q.suffix in ('.ts','.tsx','.mts','.cts','.js','.mjs','.cjs','.d.ts') and q.parts[0] in ('src','tests','ui','bridge','generated','scripts','tools'):return True
 if q.parts[0] in ('src','ui','bridge','scripts','tools') and 'public' not in q.parts and q.suffix in ('.json','.yaml','.yml'):return True
 return len(q.parts)==1 and q.suffix in ('.json','.js','.mjs','.cjs','.yaml','.yml')
paths={x for x in tracked|untracked if scoped(x)}
d={'HEAD':git('rev-parse','HEAD').decode().strip(),'index':hashlib.sha256(git('ls-files','--stage','-z')).hexdigest(),'cached':hashlib.sha256(git('diff','--cached','--binary')).hexdigest(),'diff':hashlib.sha256(git('diff','--binary')).hexdigest(),'status':git('status','--porcelain=v1','-z','--untracked-files=all').hex(),'untrackedPaths':sorted(untracked),'files':{x:digest(r/x) for x in sorted(paths)},'inputs':{}}
inputs=[p/'PATCH.diff',p/'MANIFEST.json',*[pathlib.Path(os.environ[k]) for k in ('SCRIPT','AUTO_HELPER','SELECTION','BINDINGS')],r/'package-lock.json',r/'package.json',r/'node_modules/.package-lock.json',r/'node_modules/typescript/package.json',r/'node_modules/typescript/bin/tsc',r/'node_modules/typescript/lib/tsc.js']
inputs += [r/x for x in binding['compilerInputs']]
for row in binding['artifacts']:
 q=pathlib.Path(row['path']);value=digest(q)
 if value[0]!='file' or value[1]!=row['sha256']:raise SystemExit('STOP: capture/proof input drift '+str(q))
 inputs.append(q)
for env,path,hashkey in [('P16_JOIN_PREC48_PATH','r04-pre162.save48.json','P16_JOIN_PREC48_SHA256'),('P16_JOIN_CLOSED48_PATH','r04-actual163.save48.json','P16_JOIN_CLOSED48_SHA256')]:
 q=pathlib.Path(os.environ[env]);value=digest(q)
 if q.name!=path or value[0]!='file' or value[1]!=os.environ[hashkey]:raise SystemExit('STOP: capture env binding')
 d['inputs'][env]={str(q):value}
captureRoot=pathlib.Path(os.environ['P16_ORIGINAL48_CAPTURE_ROOT'])
if str(captureRoot)!=binding['captureRoot'] or captureRoot.is_symlink() or not captureRoot.is_dir() or (captureRoot.stat().st_mode&0o777)!=binding['captureRootMode']:raise SystemExit('STOP: capture root path/type/mode')
if sorted(x.name for x in captureRoot.iterdir())!=binding['captureInventory']:raise SystemExit('STOP: capture root inventory')
named={}
for name in ['r04-pre162.save48.json','r04-actual163.save48.json','r04-archived176.save48.json','CAPTURE-MANIFEST.json']:
 value=digest(captureRoot/name)
 if value[0]!='file':raise SystemExit('STOP: capture root named input '+name)
 named[name]=value
d['inputs'][str(captureRoot)]=named
for q in inputs:
 value=digest(q)
 if value[0]!='file':raise SystemExit('STOP: missing/unsafe compiled input '+str(q))
 d['inputs'][str(q)]=value
receipt=pathlib.Path(os.environ['OUT'])/('metadata-'+uuid.uuid4().hex)
d['autoMetadata']=json.loads(subprocess.check_output([sys.executable,'-I',os.environ['AUTO_HELPER'],'capture',str(r),str(receipt)]))
print(json.dumps(d,sort_keys=True))
SNAP
}
check_freeze() {
  freeze_snapshot > "$OUT/freeze-current.json" || return 98
  python3 -I "$AUTO_HELPER" check "$OUT/freeze.json" "$OUT/freeze-current.json" >> "$OUT/metadata-checks.jsonl" 2>> "$OUT/metadata-checks-errors.log" || return 98
}
require_lane() {
python3 -I - <<'LANE'
import os,pathlib,subprocess,shlex
p=pathlib.Path('/Users/zacheryspector/studio-scratch/HEAVY-LANE-LOCK')
if p.is_symlink() or not p.is_file() or p.stat().st_nlink!=1:raise SystemExit('STOP: unsafe or absent lane lock')
marker=p.read_text().strip();pid=os.getppid();found=False
while pid>1:
 args=subprocess.check_output(['ps','-p',str(pid),'-o','args='],text=True).strip();parts=shlex.split(args)
 for i,x in enumerate(parts):
  if x.endswith('/lane-run-r8.sh') and len(parts)>i+2 and marker.startswith('lane-run '+parts[i+2]+' token='):found=True
 pid=int(subprocess.check_output(['ps','-p',str(pid),'-o','ppid='],text=True).strip())
if not found:raise SystemExit('STOP: gate must be child of owned existing lane')
LANE
}
require_lane || exit 99
[ "$(node --version)" = v20.20.2 ] || exit 90
[ "$(command -v python3)" = /Users/zacheryspector/The-Movies-headless-program/.venv/bin/python3 ] || exit 90
disk_floor 3670016 || exit 97
[ ! -e "$OUT" ] && [ ! -L "$OUT" ] || exit 90
python3 -I - "$C" <<'ADMIT'
import pathlib,json,os,sys,subprocess,hashlib
c=pathlib.Path(sys.argv[1]);g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(c)]
def need(ok,msg):
 if not ok:raise SystemExit('STOP: '+msg)
def sha(q):return hashlib.sha256(pathlib.Path(q).read_bytes()).hexdigest()
for key in ('SCRIPT','AUTO_HELPER','SELECTION','BINDINGS'):
 q=pathlib.Path(os.environ[key]);expected=os.environ.get('P16_BOOTSTRAP_'+key+'_SHA256','PENDING');need(len(expected)==64 and sha(q)==expected,'external '+key+' pin')
b=json.loads(pathlib.Path(os.environ['BINDINGS']).read_text());need(all('PENDING' not in str(b[k]) for k in ('package','patchSHA256','manifestSHA256','pathCount')),'final packet bindings pending')
need(subprocess.check_output(g+['rev-parse','HEAD']).decode().strip()==b['HEAD'],'HEAD')
p=pathlib.Path(b['package']);need(sha(p/'PATCH.diff')==b['patchSHA256'] and sha(p/'MANIFEST.json')==b['manifestSHA256'],'package bytes');m=json.loads((p/'MANIFEST.json').read_text());need(len(m['files'])==int(b['pathCount']),'path count')
def paths(*a):return {x.decode() for x in subprocess.check_output(g+list(a)).split(b'\0') if x}
need(paths('diff','--cached','--name-only','-z')=={f['path'] for f in m['files']},'staged path set');need(paths('diff','--name-only','-z')<={'HANDOFF.md'},'foreign unstaged change');need(not paths('ls-files','--others','--exclude-standard','-z'),'foreign untracked');need(not subprocess.check_output(g+['ls-files','--unmerged','-z']),'unmerged')
for f in m['files']:
 q=c/f['path'];need(q.is_file() and not q.is_symlink(),'candidate file');need(sha(q)==f['sha256'] and oct(q.stat().st_mode&0o777)==f['mode'],'actual clone bytes/mode '+f['path']);need(hashlib.sha256(subprocess.check_output(g+['show',':'+f['path']])).hexdigest()==f['sha256'],'index bytes '+f['path'])
 entry=subprocess.check_output(g+['ls-files','--stage','--',f['path']]).decode().split()[0];need(entry==('100755' if int(f['mode'],8)&0o111 else '100644'),'index executable mode')
commands=[['node', 'node_modules/typescript/bin/tsc', '--noEmit'], ['node', 'node_modules/vitest/vitest.mjs', 'run', '--project', 'core', '--no-file-parallelism', '--no-cache', '--reporter=default', '--reporter=json', '--outputFile.json=/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-estate-d-success-r2-run/results.json', 'tests/p16-estate-d-ceremony.test.ts']]
need(json.loads(pathlib.Path(os.environ['SELECTION']).read_text())==commands,'literal root+oneDsuccessfile commands')
for path,pin in b['expectedCompiledTests'].items():need(sha(c/path)==pin,'exact reviewedD harness '+path)

subprocess.run(g+['diff','--check'],check=True);subprocess.run(g+['apply','--check','--reverse',str(p/'PATCH.diff')],check=True)
ADMIT
[ "$?" = 0 ] || exit 98
mkdir "$OUT" || exit 90
run() {
 local name=$1 ec start end; shift
 check_freeze || return 98
 disk_floor 3145728 || return 97
 start=$(date +%s)
 nice -n 10 "$@" > "$OUT/$name.log" 2>&1
 ec=$?;end=$(date +%s)
 python3 -I - "$OUT" "$name" "$ec" "$start" "$end" "$@" <<'RECORD'
import json,pathlib,sys
out,name,ec,start,end,*cmd=sys.argv[1:]
r={'name':name,'exit':int(ec),'startEpoch':int(start),'endEpoch':int(end),'seconds':int(end)-int(start),'node':'v20.20.2','command':cmd,'log':str(pathlib.Path(out)/(name+'.log'))}
with (pathlib.Path(out)/'results.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
print(json.dumps({k:r[k] for k in ['name','exit','seconds']}),flush=True)
RECORD
 [ "$?" = 0 ] || return 98
 check_freeze || return 98
 disk_floor 3145728 || return 97
 return "$ec"
}
# All terminal paths after this point retain serial group statuses and child exit.
export FOLLOWUP_GROUPS_JSON='{}'
finish() {
 local exit_code=$?
 trap - EXIT
 python3 -I - "$OUT" "$exit_code" <<'TERMINAL'
import json,os,pathlib,sys
out=pathlib.Path(sys.argv[1]);code=int(sys.argv[2])
r={'overallExit':code,'groups':json.loads(os.environ['FOLLOWUP_GROUPS_JSON']),
'scope':'rootcompiler and onecompleteDsuccess harnessr2; priorDtimingOPEN; noacceptance claim',
'identityAccounting':'parent independent complete reporter identity validation required',
'freezeQualification':'see preserved before/post snapshots and metadata checks; no blanket success on abnormal stop'}
with (out/'terminal.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
TERMINAL
 [ "$?" = 0 ] || exit 98
 exit "$exit_code"
}
trap finish EXIT
remember() {
 FOLLOWUP_GROUPS_JSON=$(python3 -I - "$FOLLOWUP_GROUPS_JSON" "$1" "$2" <<'STATUS'
import json,sys
r=json.loads(sys.argv[1]);r[sys.argv[2]]=int(sys.argv[3]);print(json.dumps(r))
STATUS
 ) || exit 98
 export FOLLOWUP_GROUPS_JSON
}
freeze_snapshot > "$OUT/freeze.json" || exit 98
run tsc-root node node_modules/typescript/bin/tsc --noEmit
ec=$?;remember tsc-root "$ec";[ "$ec" = 0 ] || exit "$ec"
run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" tests/p16-estate-d-ceremony.test.ts
ec=$?;remember estate-red "$ec";[ "$ec" -le 1 ] || exit "$ec"
python3 -I "$D/account-results.py" "$OUT" "$ec" "$D/EXPECTED-IDENTITIES.json"
proof=$?;[ "$proof" = 0 ] || [ "$proof" = 3 ] || exit 98
check_freeze || exit 98
disk_floor 3145728 || exit 97
[ "$ec" = 0 ] && [ "$proof" = 0 ] || exit 1
exit 0
