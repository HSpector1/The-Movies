// Existing admitted R03 transaction premise, not natural history or a new scenario search.
import { expect,it } from '/Users/zacheryspector/The-Movies-headless-program/node_modules/vitest/dist/index.js'
import { readFileSync,mkdirSync,writeFileSync,lstatSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { resolve,join } from 'node:path'
import { performance } from 'node:perf_hooks'
import { base,forgedEstateRoute,R03,closureOf,claimsOf } from '/Users/zacheryspector/The-Movies-headless-program/tests/helpers/p15b-live.js'
import { makeSave,validateSaveP15B,exportSave,stableStringify,LIVE_SAVE_VERSION } from '/Users/zacheryspector/The-Movies-headless-program/src/core/save.js'
const R='/Users/zacheryspector/The-Movies-headless-program'
const D='/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-r03-capture-draft-r1'
const A='/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012'
const sha=(bytes:string|Buffer)=>createHash('sha256').update(bytes).digest('hex')
const git=(...args:string[])=>execFileSync('git',['-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',R,...args],{encoding:'utf8'}).trim()
it('original48 one retained R03 estate route captures130/131/132/134/144 with positiveclaims and active132run',()=>{
 const started=performance.now(),pins=JSON.parse(readFileSync(join(D,'PINS.json'),'utf8'))
 const sourceCheck=()=>{
  expect(git('rev-parse','HEAD')).toBe(pins.HEAD);expect(git('rev-parse','HEAD:src')).toBe(pins.sourceTree)
  for(const [path,hash] of Object.entries(pins.files))expect(sha(readFileSync(join(R,path)))).toBe(hash)
  expect(git('diff','HEAD','--','src','tests/helpers/p15b-live.ts','tests/p14d1-rival-shelving-fixtures.ts','tests/fixtures/p14/genuine-v42-pre-shelving')).toBe('')
 }
 sourceCheck();expect(LIVE_SAVE_VERSION).toBe(48)
 const original=base(),before=stableStringify(original)
 validateSaveP15B(makeSave(original))
 // Exactly the existing documented constructor; no field/date/amount edits in this producer.
 const route=forgedEstateRoute(144)
 expect(stableStringify(original)).toBe(before)
 const selected=[130,131,132,134,144] as const
 for(const week of selected){
  const state=route.get(week)!
  expect(state?.market.tick).toBe(week)
  const bytes=stableStringify(state)
  validateSaveP15B(makeSave(state));expect(stableStringify(state)).toBe(bytes)
 }
 const initial=route.get(130)!,closed=route.get(131)!,paid=route.get(132)!,settled=route.get(134)!,archived=route.get(144)!
 expect(closureOf(initial,R03)).toBeUndefined()
 const closure=closureOf(closed,R03)!
 expect(closure).toBeDefined();expect(closure.closureWeek).toBe(131)
 expect(closure.estate).toMatchObject({opensWeek:131,closesWeek:144})
 expect(closure.cash.closing).toBeLessThan(0);expect(closure.cash.closing).toBeGreaterThan(-300001)
 expect(closure.cash.distributable).toBe(0);expect(closure.receipts).toEqual([])
 const filmId=R03+':film:13'
 const business=(state:typeof initial)=>state.hollywood!.businesses.find(b=>b.studioId===R03)!
 const runBefore=business(initial).runs.find(r=>r.productionId===filmId)!
 expect(runBefore).toBeDefined();expect(runBefore).toMatchObject({weekIndex:2,totalWeeks:6,releaseTick:128})
 expect(closure.dispositions.filter(d=>d.subjectKind==='theatricalRun')).toMatchObject([{subjectId:filmId,status:'applied'}])
 const receipts=paid.studioClosure.estateEvents.filter(e=>e.closureId===closure.closureId&&e.kind==='runReceipt')
 expect(receipts).toHaveLength(1);expect(receipts[0]).toMatchObject({week:132,reference:filmId+':due:131'})
 expect(receipts[0]!.amount).toBeCloseTo(runBefore.weeklyGross[3]!*runBefore.studioShare,6)
 expect(receipts[0]!.amount).toBeGreaterThan(0)
 expect(business(paid).runs.some(r=>r.productionId===filmId)).toBe(true)
 const film=paid.hollywood!.films.find(f=>f.filmId===filmId)!
 expect(film.provenance).toBe('simulation/v1');expect('settledWeek' in film&&film.settledWeek).toBeNull()
 const claims=claimsOf(paid,closure.closureId)
 expect(claims).toHaveLength(6)
 const payments=claims.flatMap(c=>c.payments.filter(p=>p.week===132))
 expect(payments.length).toBeGreaterThan(0)
 const paidTotal=payments.reduce((n,p)=>n+p.amount,0)
 expect(paidTotal).toBeGreaterThan(0)
 const distribution=paid.studioClosure.estateEvents.filter(e=>e.closureId===closure.closureId&&e.kind==='distribution'&&e.week===132)
 expect(distribution).toHaveLength(1)
 expect(distribution[0]!.amount).toBe(paidTotal)
 expect(paidTotal).toBe(Math.floor(Math.max(0,closure.cash.closing+receipts[0]!.amount)))
 expect(payments.every(p=>p.reference===distribution[0]!.eventId)).toBe(true)
 expect(claims.every(c=>c.original===c.paid+c.unpaid)).toBe(true)
 const claimMovement=business(paid).account.periods.reduce((n,p)=>n+p.movements.claimPayment,0)
 expect(claimMovement).toBe(-paidTotal)
 expect(business(settled).runs.some(r=>r.productionId===filmId)).toBe(false)
 const finalFilm=settled.hollywood!.films.find(f=>f.filmId===filmId)!
 expect('settledWeek' in finalFilm&&finalFilm.settledWeek).toBe(133)
 const archives=archived.studioClosure.estateEvents.filter(e=>e.closureId===closure.closureId&&e.kind==='archival')
 expect(archives).toHaveLength(1);expect(archives[0]).toMatchObject({week:144,amount:0,reference:closure.closureId,studioId:R03})
 expect(closureOf(archived,R03)).toEqual(closure)
 const results=selected.map(week=>{
  const state=route.get(week)!,input=stableStringify(state),save=makeSave(state),text=exportSave(save)
  expect(save.saveVersion).toBe(48);expect('rights' in save.state).toBe(false)
  validateSaveP15B(JSON.parse(text));expect(stableStringify(state)).toBe(input)
  return {name:'r03-week'+week+'.save48.json',text,sha256:sha(text),bytes:Buffer.byteLength(text),week}
 })
 sourceCheck();expect(stableStringify(original)).toBe(before)
 expect(performance.now()-started,'unchanged5s captureproducer elapsed').toBeLessThanOrEqual(5000)
 const out=process.env.P16_ORIGINAL48_CAPTURE_OUT
 expect(out,'parentbindfreshA output').toBeTruthy()
 expect(resolve(out!)).toBe(join(A,'p16-original48-r03-capture-r1-run'))
 mkdirSync(out!,{recursive:false});expect(lstatSync(out!).isSymbolicLink()).toBe(false)
 for(const row of results)writeFileSync(join(out!,row.name),row.text,{flag:'wx'})
 writeFileSync(join(out!,'CAPTURE-MANIFEST.json'),JSON.stringify({source:pins,scope:'existing disclosedcondition/finance R03transaction fixture; notnaturalcampaign',closureId:closure.closureId,archivalEventId:archives[0]!.eventId,positive132:{paidTotal,claimPaymentMovement:claimMovement,runReceipt:receipts[0],distribution:distribution[0],filmId},elapsedMsBeforeManifestWrite:performance.now()-started,files:results.map(({text,...row})=>row)},null,2)+'\n',{flag:'wx'})
})
