from pathlib import Path
import hashlib, json, os, subprocess

A = Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K = Path('/Users/zacheryspector/studio-specialists/p16')
old = A/'p16-work-release61-integration-runner-r16'
dest = A/'p16-work-release61-integration-runner-r17'
package = A/'p16-initial-shooting5-baseline-integration-r1'
tests = A/'p16-initial-shooting5-baseline-tests-r1'
out = A/'p16-work-release61-integration-r17-run'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
assert not dest.exists() and not out.exists()
assert sha(old/'runner.sh') == '24843b3d693769c2b6884f0d07f02f6ecd50f220c02a161ba6b74849cf739e74'
assert sha(old/'BINDINGS.json') == 'b08aa5e6f9aaa5af7a9dc008af02d317b2ab229be71ba91ff354da36610950c8'
receipt = json.loads((package/'INSTALL-RECEIPT.json').read_text())
assert receipt['pathCount'] == 193
assert sha(package/'PATCH.diff') == receipt['patchSHA256'] == '2bdda4dba3868333973282a1905f5a56d79b8e73bc1838066255eeb63f695f95'
assert sha(package/'MANIFEST.json') == receipt['manifestSHA256'] == 'a5ef15adf25a4184e34306d6c21435bdb8de75d0f654134c9003b78a4942c473'
g = ['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary']) == (package/'PATCH.diff').read_bytes()
scope = 'Fresh root and complete initialshooting5 diagnostic1/default5000ms; genuine actual163 plus two ordinary ticks and expected current refusal only; no positive feature acceptance'
def relocate(s):
    return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r16-run','p16-work-release61-integration-r17-run')
script = relocate((old/'runner.sh').read_text()).replace('tests/p16-continued-work-shooting4.test.ts','tests/p16-continued-work-shooting5-baseline.test.ts')
script = script.replace('literal root compiler then complete shooting4 three-leaf command','literal root compiler then complete initialshooting5 diagnostic command')
script = script.replace('fresh root compiler and complete shooting4 file3; actual source-owned completed take and lock, native wrap and explicit release; all original budgets and prior failures retained',scope)
selection = json.loads(relocate((old/'SELECTION.json').read_text()))
selection[-1][-1] = 'tests/p16-continued-work-shooting5-baseline.test.ts'
raw = json.loads((tests/'EXPECTED-IDENTITIES.json').read_text())
assert raw['count'] == 1 and raw['budgetMs'] == 5000
assert raw['sourceSHA256'] == sha(K/raw['file']) == 'c454d85dfbeb61584fc505ea491fe34b236e1093f56ffce4dff5892ce569c1eb'
expected = [dict(file=raw['file'],sourceSHA256=raw['sourceSHA256'],count=1,names=raw['identities'],leaves=[dict(fullName=n,budgetMs=5000,budgetSource='unchanged core default; complete setup inside test') for n in raw['identities']])]
dest.mkdir()
(dest/'runner.sh').write_text(script)
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace('complete shooting4 file3; original5000ms budgets and all failures retained',scope))
for name, value in [('SELECTION.json',selection),('EXPECTED-IDENTITIES.json',expected)]:
    (dest/name).write_text(json.dumps(value,indent=2)+'\n')
b = json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],pathCount=193,plannedPathCount=193,installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={raw['file']:raw['sourceSHA256']},finalCleanTestAdmission='Independent diagnostic KEEP; exact parent193 baseline test-only installation, no prospective initial5 implementation; final runner review required')
for row in b['artifacts']:
    p = Path(row['path'])
    if p.parent == dest: row['sha256'] = sha(p)
    else: assert sha(p) == row['sha256'], str(p)
for p in [package/'INSTALL-RECEIPT.json',tests/'SOURCE.patch',tests/'MANIFEST.json',tests/'EXPECTED-IDENTITIES.json',A/'P16-INITIAL-SHOOTING5-BASELINE-INSTALL-SPEC.json',A/'P16-INITIAL-SHOOTING5-BASELINE-TESTS-R1-INDEPENDENT-REVIEW.md',A/'P16-WORK-RELEASE61-INTEGRATION-R16-PARENT-RESULT.json',A/'P16-COMPLETED-TAKE-SHOOTING-R16-ACTUAL-REVIEW.md']:
    b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles'] = {p.name:sha(p) for p in old.iterdir() if p.is_file()}
assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']: os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins = {p.name:sha(p) for p in dest.iterdir() if p.is_file()}
(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(dest/'README.md').write_text(scope+'. UNRUN pending independent final runner review and existing preflight.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins),indent=2))
