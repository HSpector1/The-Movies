from pathlib import Path
import hashlib, json, os, re, subprocess

A = Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K = Path('/Users/zacheryspector/studio-specialists/p16')
old = A/'p16-work-release61-integration-runner-r17'
dest = A/'p16-work-release61-integration-runner-r18'
package = A/'p16-initial-shooting5-final-integration-r1'
tests = A/'p16-initial-shooting5-final-tests-r2-bound'
out = A/'p16-work-release61-integration-r18-run'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
assert not dest.exists() and not out.exists()
assert sha(old/'runner.sh') == '6bc6cf689676c70d833f16e75ef34196379e2f3923aa06d6513cb6d42166c28a'
assert sha(old/'BINDINGS.json') == '2cf3628b7433904c99ad88385701bc53012b44f91d83388a6448837a2d1d55bb'
baseline = json.loads((A/'P16-WORK-RELEASE61-INTEGRATION-R17-PARENT-RESULT.json').read_text())
assert baseline['counts'] == {'passed':1} and baseline['allBudgetQualified'] and baseline['independentFinalFreeze'] == 'PASS'
receipt = json.loads((package/'INSTALL-RECEIPT.json').read_text())
assert receipt['pathCount'] == 193
assert sha(package/'PATCH.diff') == receipt['patchSHA256'] == '57e2d97f1ae21eb2a84de3df2f7185fc2e2175520c6657c7d3d37ad6359b8045'
assert sha(package/'MANIFEST.json') == receipt['manifestSHA256'] == 'a0fb24da937649e3d4eceb2383bd8be54d970dbc599229efc2fecceb311d2910'
g = ['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary']) == (package/'PATCH.diff').read_bytes()
scope = 'Fresh root and coherent six complete silent-work files22/default5000ms: initial5 final3 plus early8/7/6, completed4, manual cancellation and latepost regressions; original failures retained; no whole-P16 or native acceptance'
expected = json.loads((A/'p16-work-release61-integration-runner-r13/EXPECTED-IDENTITIES.json').read_text())[:4]
assert [len(r['names']) for r in expected] == [4,6,3,3]
expected += json.loads((A/'p16-work-release61-integration-runner-r16/EXPECTED-IDENTITIES.json').read_text())
raw = json.loads((tests/'EXPECTED-IDENTITIES.json').read_text())
assert raw['count'] == 3 and raw['budgetMs'] == 5000
expected += [dict(file=raw['file'],sourceSHA256=raw['sourceSHA256'],count=3,names=raw['identities'],leaves=[dict(fullName=n,budgetMs=5000,budgetSource='unchanged core default; complete setup inside test') for n in raw['identities']])]
assert len(expected) == 6 and sum(len(r['names']) for r in expected) == 22
for row in expected:
    assert sha(K/row['file']) == row['sourceSHA256']
    assert all(leaf['budgetMs'] == 5000 for leaf in row['leaves'])
paths = [r['file'] for r in expected]
def relocate(s): return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r17-run','p16-work-release61-integration-r18-run')
selection = json.loads(relocate((old/'SELECTION.json').read_text()))
selection[-1] = selection[-1][:10] + paths
script = relocate((old/'runner.sh').read_text())
script,n = re.subn(r'^commands=.+$', 'commands='+repr(selection), script, count=1, flags=re.M); assert n==1
script,n = re.subn(r'^run estate-red .+$','run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(paths),script,count=1,flags=re.M); assert n==1
old_scope = json.loads((old/'BINDINGS.json').read_text())['executionScope']
script = script.replace(old_scope,scope).replace('literal root compiler then complete initialshooting5 diagnostic command','literal root compiler then complete silent-work six-file22 selection')
dest.mkdir()
(dest/'runner.sh').write_text(script)
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace(old_scope,scope))
for name,value in [('SELECTION.json',selection),('EXPECTED-IDENTITIES.json',expected)]: (dest/name).write_text(json.dumps(value,indent=2)+'\n')
b = json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],pathCount=193,plannedPathCount=193,installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},finalCleanTestAdmission='Measured R17 diagnostic prerequisite; independent source and final3 KEEP; exact parent source2/test1 replacement. Six complete coherent files22 with original budgets; final runner independent review required')
for row in b['artifacts']:
    p = Path(row['path'])
    if p.parent == dest: row['sha256'] = sha(p)
    else: assert sha(p) == row['sha256'], str(p)
extra = [package/'INSTALL-RECEIPT.json',tests/'SOURCE.patch',tests/'MANIFEST.json',tests/'EXPECTED-IDENTITIES.json',A/'P16-INITIAL-SHOOTING5-FINAL-INSTALL-SPEC.json',A/'P16-INITIAL-SHOOTING5-R17-ACTUAL-REVIEW.md',A/'P16-WORK-RELEASE61-INTEGRATION-R17-PARENT-RESULT.json',A/'P16-INITIAL-TAKE-SILENT-HANDOFF-R1-INDEPENDENT-REVIEW.md',A/'p16-initial-take-silent-handoff-r1/SOURCE.patch',A/'p16-initial-take-silent-handoff-r1/MANIFEST.json',A/'p16-initial-shooting5-baseline-to-final-r1/DELTA.diff',A/'p16-initial-shooting5-baseline-to-final-r1/MANIFEST.json',A/'p16-work-release61-integration-runner-r13/EXPECTED-IDENTITIES.json',A/'p16-work-release61-integration-runner-r16/EXPECTED-IDENTITIES.json']
for p in extra: b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles'] = {p.name:sha(p) for p in old.iterdir() if p.is_file()}
assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']: os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(dest/'README.md').write_text(scope+'. UNRUN pending independent final runner review and existing preflight.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins),indent=2))
