# Completed-take null lock refusal — STATIC / UNRUN

Actual R14 root compiler TS2531 at continuedWork54/continuedWorkValidation114; runtime did not start and no assertions qualified. Both new completed-take guards must explicitly refuse nullable lockedWeek before comparing actual date. Two expressions now add lockedWeek===null refusal, preserving current source/acquisition upper bound and reader cutover upper bound, method/studio/adoption/exactcount and all other checks. No casts/non-null assertion added to silence the type error; original array-nonempty proof/assertion stays unchanged.

Existing tests/p16-continued-work-shooting4.test.ts:95 positively pins real lockedWeek160; hostile at145 changes studio tobuyer, but no null-lockedWeek hostile currently exists. Independent test owner owns any additive null mutant. Existing source4 packet and actual failed R14 remain preserved. No compiler/test/runtime or K/R/index writes. Sparsepatch + completepre/posthashes only.
