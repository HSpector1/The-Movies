from pathlib import Path
import hashlib, json, os, subprocess
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r14'; new=A/'p16-work-release61-integration-runner-r15'
oldout=A/'p16-work-release61-integration-r14-run'; newout=A/'p16-work-release61-integration-r15-run'
package=A/'p16-completed-take-shooting-integration-r2'; test=A/'p16-completed-take-shooting-tests-r3-null-lock'
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not new.exists() and not newout.exists()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(old/'runner.sh')=='edf9e33d6a0ce5031b4c7e4cdd6e9d0347bbff4894e02648b8f37acaedf03b11'
assert sha(old/'BINDINGS.json')=='091f2d6d378ca62da2611812fd9e1d7aa39da56b83daaa708eb91c138c13b028'
assert sha(package/'PATCH.diff')=='03559ffb85c2561aca0aa9f11bce4258f0497c2c9f0bb7cd3698675befc1a00a'
assert sha(package/'MANIFEST.json')=='5a452ac950d35366227a479f0c569ad9a78bcab265b8dd7a49424b6077516bea'
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary'])==(package/'PATCH.diff').read_bytes()
def relocate(s): return s.replace(str(old),str(new)).replace(str(oldout),str(newout))
new.mkdir()
for name in ['runner.sh','auto_freeze.py','account-results.py','SELECTION.json']:
    (new/name).write_text(relocate((old/name).read_text()))
    os.chmod(new/name,(old/name).stat().st_mode&0o777)
expected=json.loads((old/'EXPECTED-IDENTITIES.json').read_text()); raw=json.loads((test/'EXPECTED-IDENTITIES.json').read_text())
assert raw['count']==3 and raw['allUnique'] is True
assert expected[0]['names']==[r['fullName'] for r in raw['identities']]
assert all(r['budgetMs']==5000 for r in raw['identities'])
expected[0]['sourceSHA256']=raw['sourceSha256']
assert sha(K/expected[0]['file'])==raw['sourceSha256']=='2df4cf22b81d2a9ace1c199ea43b7c4ba9b3ed55a0587789b8c6ec0c7310324b'
(new/'EXPECTED-IDENTITIES.json').write_text(json.dumps(expected,indent=2)+'\n')
b=json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),patchSHA256=sha(package/'PATCH.diff'),manifestSHA256=sha(package/'MANIFEST.json'),pathCount=192,
         installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),
         finalCleanTestAdmission='Parent exact192-r2 two explicit null-lock refusals and additive missing/null controls, independent R14 actual/source/test KEEP; final runner review required',
         executionScope='Fresh root then complete shooting4 file3 with original5000ms and additive missing/null lock controls; original R14 compiler2 and zero runtime retained; no whole-P16/native acceptance')
b['expectedCompiledTests'][expected[0]['file']]=raw['sourceSha256']
for row in b['artifacts']:
    if row['path']==str(new/'EXPECTED-IDENTITIES.json'): row['sha256']=sha(new/'EXPECTED-IDENTITIES.json')
additional=[package/'INSTALL-RECEIPT.json',A/'P16-COMPLETED-TAKE-LOCK-NULL-INSTALL-SPEC.json',A/'P16-COMPLETED-TAKE-SHOOTING-R14-ACTUAL-REVIEW.md',A/'P16-WORK-RELEASE61-INTEGRATION-R14-PARENT-RESULT.json']
additional += [A/'p16-completed-take-lock-null-guard-r1'/n for n in ['SOURCE.patch','MANIFEST.json']]
additional += [test/n for n in ['DELTA.diff','MANIFEST.json','SOURCE-BINDING.json','EXPECTED-IDENTITIES.json']]
for p in additional: b['artifacts'].append({'path':str(p),'sha256':sha(p)})
for row in b['artifacts']: assert sha(Path(row['path']))==row['sha256'],row['path']
assert 'PENDING' not in json.dumps(b)
(new/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
pins={p.name:sha(p) for p in sorted(new.iterdir())}
(new/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(new/'README.md').write_text('R15 unrun successor: exact192-r2 explicit source null-lock refusal plus additive independent missing/null controls; fresh root then unchanged complete3/default5000. Original R14 root2/50s and zero runtime preserved. Requires final independent runner review and normal preflight. No whole-P16 or native acceptance.\n')
print(json.dumps(pins,indent=2))
