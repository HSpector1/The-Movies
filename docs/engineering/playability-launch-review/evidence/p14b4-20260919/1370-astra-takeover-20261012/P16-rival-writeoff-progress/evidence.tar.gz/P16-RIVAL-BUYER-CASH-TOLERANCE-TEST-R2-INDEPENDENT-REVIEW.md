# Cash replay hostile R2

KEEP static/UNRUN. Exact test0ef3b43d8207a83efe01cec4156e3554fd14e765b2292d0d6bbaf5ba5461fd21 / DELTA7e5011bfa05b09f40aac0dc1c264b9fee5e9841203e079c8c7d8105a7e5ed686 / MANIFESTd1377dd638dc8c718be997dda15cb3a85afad7e77ae42d4f77a6c5ef65722d4c verified.

Only failed cent mutant changes to an above-tolerance perturbation derived from actual admitted buyer cash: max1, twice ceil(abs(cash)*1e-7). Explicit inequality checks drift against existing relative comparator using both original and changed cash magnitudes, avoiding fixed-dollar/cent assumptions. Exact cash-diff reconciliation category applies only to this case; all other hostile expectations remain. No successful cash/title equations or product tolerance changes. Actual first owner remains a measured prerequisite; replay-rounding baseline is not invented.

All mutation/fullreader/caller-purity assertions, three identities/default5000ms, setup/ordinaryticks/reload/replay/realpublicationfault remain unchanged. R24 failed1 and positive5332/player8031 overruns stay retained. This delta does not remove redundant admissions or claim timing improvement; further justified harness change requires separate review. No runtime/K/R edits or broader qualification.
