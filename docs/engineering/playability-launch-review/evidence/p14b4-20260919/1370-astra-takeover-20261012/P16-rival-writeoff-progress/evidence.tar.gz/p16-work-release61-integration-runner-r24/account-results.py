import json,pathlib,sys,collections
out=pathlib.Path(sys.argv[1]);child=int(sys.argv[2]);expected=json.loads(pathlib.Path(sys.argv[3]).read_text());d=json.loads((out/'results.json').read_text());files=d['testResults'];total=sum(len(row['names']) for row in expected)
assert expected and total > 0 and len(files)==len(expected)
seen=set();rows=[]
for want in expected:
 found=[f for f in files if f['name'].endswith('/'+want['file'])];assert len(found)==1
 f=found[0];a=f['assertionResults'];assert sorted(x['fullName'] for x in a)==sorted(want['names'])
 budgets={leaf['fullName']:leaf['budgetMs'] for leaf in want['leaves']}
 assert set(budgets)==set(want['names'])
 for x in a:
  assert x['status'] in ('passed','failed')
  identity=(want['file'],x['fullName']);assert identity not in seen;seen.add(identity)
  rows.append({'file':want['file'],'fullName':x['fullName'],'status':x['status'],'durationMs':x.get('duration'),'budgetMs':budgets[x['fullName']],'budgetQualified':x.get('duration') is not None and x['duration']<=budgets[x['fullName']],'failureMessages':x.get('failureMessages',[])})
 assert f['status']==('failed' if any(x['status']=='failed' for x in a) else 'passed')
c=collections.Counter(x['status'] for x in rows)
assert d['numTotalTests']==total and d['numPassedTests']==c['passed'] and d['numFailedTests']==c['failed'] and d['numPendingTests']==d['numTodoTests']==0
assert d['success']==(child==0)==(c['failed']==0)
assert d['numTotalTestSuites']==d['numPassedTestSuites']+d['numFailedTestSuites']+d['numPendingTestSuites']
(out/'identity-accounting.json').write_text(json.dumps({'childExit':child,'files':len(expected),'identities':total,'rows':rows,'scope':'Fresh root and two complete files6/default5000ms: real rival163 nonretention close3 plus prior player shooting5 writeoff3 regression; actual money/title/paid work/ordinary replay/hostile reader/full publication rollback; original R23 refusals retained, no whole-P16 or wider rival work/run acceptance'},indent=2)+'\n')
if any(not r['budgetQualified'] for r in rows):raise SystemExit(3)
