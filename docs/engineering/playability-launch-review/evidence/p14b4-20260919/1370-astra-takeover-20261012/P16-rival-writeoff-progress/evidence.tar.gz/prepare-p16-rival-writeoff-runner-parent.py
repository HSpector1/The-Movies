from pathlib import Path
import hashlib,json,os,subprocess,re
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r23';dest=A/'p16-work-release61-integration-runner-r24'
package=A/'p16-rival-buyer-writeoff-integration-r1';tests=A/'p16-rival-buyer-absorption163-final-tests-r1';source=A/'p16-rival-buyer-writeoff-r1'
out=A/'p16-work-release61-integration-r24-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not dest.exists() and not out.exists()
assert sha(old/'runner.sh')=='9228c3cf9e58a51ce9256dff59baf85d53d52accb4de8e520ccb2246e45fb6da'
assert sha(old/'BINDINGS.json')=='aef10512b85404d71623b747ab37ed2d83d036feda5218ae441922dfaa373da7'
previous=json.loads((A/'P16-WORK-RELEASE61-INTEGRATION-R23-PARENT-RESULT.json').read_text())
assert previous['terminal']['overallExit']==0 and previous['counts']=={'passed':2} and previous['allBudgetQualified'] and previous['independentFinalFreeze']=='PASS'
receipt=json.loads((package/'INSTALL-RECEIPT.json').read_text());assert receipt['pathCount']==197
assert sha(package/'PATCH.diff')==receipt['patchSHA256'] and sha(package/'MANIFEST.json')==receipt['manifestSHA256']
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary'])==(package/'PATCH.diff').read_bytes()
raw=json.loads((tests/'EXPECTED-IDENTITIES.json').read_text());assert raw['count']==3 and raw['budgetMs']==5000
assert raw['sourceSHA256']==sha(K/raw['file'])=='d8b44b55d7b2b008bab93484dd90432fbe181365cd8d61f44ca8ac1c1a521a67'
expected=[dict(file=raw['file'],sourceSHA256=raw['sourceSHA256'],count=3,names=raw['identities'],leaves=[dict(fullName=name,budgetMs=5000,budgetSource='unchanged core default; all genuine setup inside test') for name in raw['identities']])]
prior=json.loads((A/'p16-work-release61-integration-runner-r21/EXPECTED-IDENTITIES.json').read_text());assert len(prior)==1 and prior[0]['count']==3
expected+=prior
for row in expected:
 assert sha(K/row['file'])==row['sourceSHA256']
 text=(K/row['file']).read_text();describes=re.findall(r"describe\('([^']+)'",text);leaves=re.findall(r"\bit\('([^']+)'",text)
 assert len(describes)==1 and len(leaves)==3 and row['names']==[describes[0]+' '+leaf for leaf in leaves]
 assert all(leaf['budgetMs']==5000 for leaf in row['leaves'])
binding=json.loads((A/'P16-RIVAL-BUYER-FINAL3-SOURCE-BINDING.json').read_text())
assert binding['testSHA256']==raw['sourceSHA256'] and binding['sourcePatchSHA256']==sha(source/'SOURCE.patch')
for row in binding['sourceFiles']:assert sha(K/row['path'])==row['postimageSHA256']
files=[r['file'] for r in expected]
scope='Fresh root and two complete files6/default5000ms: real rival163 nonretention close3 plus prior player shooting5 writeoff3 regression; actual money/title/paid work/ordinary replay/hostile reader/full publication rollback; original R23 refusals retained, no whole-P16 or wider rival work/run acceptance'
old_scope=json.loads((old/'BINDINGS.json').read_text())['executionScope']
def relocate(s):return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r23-run','p16-work-release61-integration-r24-run')
selection=json.loads(relocate((old/'SELECTION.json').read_text()));selection[-1]=selection[-1][:10]+files
assert selection[0]==['node','node_modules/typescript/bin/tsc','--noEmit']
script=relocate((old/'runner.sh').read_text()).replace(old_scope,scope)
lines=script.splitlines();positions=[i for i,s in enumerate(lines) if s.startswith('commands=')];assert len(positions)==1;lines[positions[0]]='commands='+repr(selection)
positions=[i for i,s in enumerate(lines) if s.startswith('run estate-red ')];assert len(positions)==1
lines[positions[0]]='run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(files)
script='\n'.join(lines)+'\n';script=script.replace('complete fixed171 and rival163 diagnostic2 selection','complete rival163 final3 and playerwriteoff3 selection')
dest.mkdir();(dest/'runner.sh').write_text(script);(dest/'SELECTION.json').write_text(json.dumps(selection,indent=2)+'\n')
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes());(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace(old_scope,scope));(dest/'EXPECTED-IDENTITIES.json').write_text(json.dumps(expected,indent=2)+'\n')
b=json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),pathCount=197,patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},finalCleanTestAdmission='Independent concrete rival source and final3 reviewed; immutable prospective note resolved by exact four-file SOURCE-BINDING receipt; unchanged qualified playerwriteoff3 regression; six original5s budgets; final runner review required')
for row in b['artifacts']:
 p=Path(row['path'])
 if p.parent==dest:row['sha256']=sha(p)
 else:assert sha(p)==row['sha256'],str(p)
for p in [package/'INSTALL-RECEIPT.json',source/'SOURCE.patch',source/'MANIFEST.json',tests/'DELTA.diff',tests/'MANIFEST.json',tests/'EXPECTED-IDENTITIES.json',A/'P16-RIVAL-BUYER-FINAL3-SOURCE-BINDING.json',A/'P16-RIVAL-BUYER-WRITEOFF-INSTALL-SPEC.json',A/'P16-WORK-RELEASE61-INTEGRATION-R23-PARENT-RESULT.json',A/'P16-DRAFT171-RIVAL163-R23-ACTUAL-REVIEW.md',A/'P16-RIVAL-BUYER-WRITEOFF-R1-INDEPENDENT-REVIEW.md']:
 b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles']={p.name:sha(p) for p in old.iterdir() if p.is_file()};assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']:os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins={p.name:sha(p) for p in dest.iterdir() if p.is_file()};(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n');(dest/'README.md').write_text(scope+'. UNRUN pending final independent admission and actual preflight.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins),indent=2))
