from pathlib import Path
import datetime, hashlib, json, subprocess, sys

R = Path('/Users/zacheryspector/The-Movies-headless-program')
A = Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
runner, receipt = map(Path,sys.argv[1:])
assert runner.is_file() and not runner.is_symlink()
assert not receipt.exists() and not (A.parent/'HEAVY-LANE-LOCK').exists()
def read(*args):
    return subprocess.check_output(args,text=True)
free = int(read('df','-Pk',str(R)).splitlines()[1].split()[3])
power = read('pmset','-g','batt')
processes = read('ps','-axo','pid=,ppid=,comm=,args=')
heavy=[]
for line in processes.splitlines():
    fields=line.split(None,3)
    if len(fields)==4 and Path(fields[2]).name=='node' and any(token in fields[3] for token in ('vitest','/bin/tsc','/lib/tsc.js','DIAGNOSTIC.ts')):
        heavy.append(line)
paths=[runner,runner.parent/'SELECTION.json',A/'p15b-auto-recorder-r4r2-draft/auto_freeze.py',A/'p15b-d16-ui-r5-draft/RUNTIME-INPUTS.json',A.parent/'1370-c0-stage41-heavy-lane-recovery-proposal-r8/lane-run-r8.sh']
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
allowed=free>=3670016 and 'AC Power' in power and not heavy
r=dict(at=datetime.datetime.now().astimezone().isoformat(),freeKiB=free,launchMinimumKiB=3670016,runtimeFloorKiB=3145728,powerLOCAL=power,memoryLOCAL=read('memory_pressure','-Q'),swapLOCAL=read('sysctl','vm.swapusage'),loadLOCAL=read('sysctl','vm.loadavg'),processInventoryLOCAL=processes,heavyLOCAL=heavy,pins=pins,laneAbsent=True,launchAllowed=allowed)
receipt.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(freeKiB=free,launchAllowed=allowed,competingHeavy=len(heavy),pins=pins)))
assert allowed
