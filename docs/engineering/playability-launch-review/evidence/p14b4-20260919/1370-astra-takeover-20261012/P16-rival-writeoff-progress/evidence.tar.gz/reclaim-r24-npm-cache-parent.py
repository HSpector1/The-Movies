from pathlib import Path
import datetime, json, os, runpy, stat, subprocess

A = Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
R = Path('/Users/zacheryspector/The-Movies-headless-program')
TARGET = Path('/Users/zacheryspector/.npm/_cacache')
RECEIPT = A/'P16-R24-NPM-CACHE-RECEIPT.json'
INVENTORY = A/'P16-R24-NPM-CACHE-TARGET.LOCAL.json'
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
assert not RECEIPT.exists() and not INVENTORY.exists()
for p in [TARGET, *TARGET.parents]:
    assert not p.is_symlink(), str(p)
assert TARGET.is_dir() and TARGET.stat().st_uid == os.getuid()
detect = runpy.run_path(str(A/'equipment-run-preflight-r2.py'))['intensive']
commands = subprocess.check_output(['ps','-ww','-axo','pid=,comm='],text=True)
arguments = subprocess.check_output(['ps','-ww','-axo','pid=,args='],text=True)
args = dict(line.split(None,1) for line in arguments.splitlines() if len(line.split(None,1)) == 2)
for line in commands.splitlines():
    fields = line.split(None,1)
    if len(fields) == 2:
        assert not detect(fields[1],args.get(fields[0],'')), 'competing intensive process '+fields[0]
handles = subprocess.run(['/usr/sbin/lsof','-nP','+D',str(TARGET)],text=True,capture_output=True)
assert handles.returncode == 1 and not handles.stdout and not handles.stderr, 'cache has open handles or inspection failed'
def free():
    return int(subprocess.check_output(['df','-Pk',str(R)],text=True).splitlines()[1].split()[3])
files=[]; dirs=[]; skipped=[]
def visit(p):
    s=p.lstat()
    if s.st_uid!=os.getuid() or stat.S_ISLNK(s.st_mode):
        skipped.append(str(p)); return
    if stat.S_ISDIR(s.st_mode):
        dirs.append((p,s.st_ino))
        try:
            children=list(p.iterdir())
        except PermissionError:
            skipped.append(str(p)); return
        for q in children: visit(q)
    elif stat.S_ISREG(s.st_mode) and s.st_nlink==1:
        files.append((p,s.st_ino,s.st_size,s.st_mtime_ns,s.st_blocks*512))
    else:
        skipped.append(str(p))
visit(TARGET)
before=free()
inventory={'at':datetime.datetime.now().astimezone().isoformat(),'target':str(TARGET),'ownerUid':os.getuid(),'purpose':'Regenerable npm package download cache; installed _npx tools and dependencies excluded','beforeFreeKiB':before,'files':[{'path':str(p),'inode':ino,'size':size,'mtimeNs':mtime,'allocatedBytes':allocated} for p,ino,size,mtime,allocated in files],'skipped':skipped,'openHandles':'lsof exit1 with empty stdout and stderr','noCompetingIntensiveProcesses':True,'symlinksFollowed':False}
with INVENTORY.open('x') as f:json.dump(inventory,f,indent=2);f.write('\n')
removed=0; allocated=0
for p,ino,size,mtime,blocks in files:
    s=p.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==os.getuid() and (s.st_ino,s.st_size,s.st_mtime_ns)==(ino,size,mtime), 'cache changed '+str(p)
    try:p.unlink()
    except PermissionError:skipped.append(str(p));continue
    removed+=1;allocated+=blocks
for p,ino in reversed(dirs):
    if p==TARGET:continue
    s=p.lstat()
    assert stat.S_ISDIR(s.st_mode) and s.st_uid==os.getuid() and s.st_ino==ino
    try:p.rmdir()
    except OSError:pass  # Preserve nonempty or permission-protected directories.
after=free()
receipt={k:inventory[k] for k in ['at','target','ownerUid','purpose','beforeFreeKiB','openHandles','noCompetingIntensiveProcesses','symlinksFollowed']}
receipt.update(removedFiles=removed,estimatedAllocatedBytes=allocated,afterFreeKiB=after,actualNetRecoveredKiB=after-before,remainingLaunchShortfallKiB=max(0,3670016-after),skipped=skipped,normalMaintenanceChoice='npm normal cache clean previously failed on root-owned remnants; exact user-owned cache contents only, no escalation',protectedItemsPreserved=['root-owned cache subtrees','node_modules and installed _npx tools','live VSCode updater','project files, evidence, saves, assets, Git and toolchains','Desktop, Documents, Downloads, Trash and cloud archives'])
with RECEIPT.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
