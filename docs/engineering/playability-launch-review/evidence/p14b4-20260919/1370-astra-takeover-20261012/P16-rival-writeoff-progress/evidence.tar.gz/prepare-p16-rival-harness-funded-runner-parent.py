from pathlib import Path
import hashlib,json,os,re,subprocess
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r24';dest=A/'p16-work-release61-integration-runner-r25';out=A/'p16-work-release61-integration-r25-run'
package=A/'p16-rival-buyer-writeoff-integration-r2';h=A/'p16-writeoff-reader-harness-r1';d=A/'p16-healthy-drafting171-funded-baseline-tests-r2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not dest.exists() and not out.exists()
assert sha(old/'runner.sh')=='312bb728282d1e7517d98586028ee4f2cf9aa65ebdcefa392fe89d18af23491e'
assert sha(old/'BINDINGS.json')=='50b2485136f92745d90219dfd645e209df4c11cec14fbab554ae2818433dd28d'
previous=json.loads((A/'P16-WORK-RELEASE61-INTEGRATION-R24-PARENT-RESULT.json').read_text())
assert previous['terminal']['overallExit']==1 and previous['counts']=={'passed':5,'failed':1} and previous['independentFinalFreeze']=='PASS' and len(previous['overBudget'])==2
receipt=json.loads((package/'INSTALL-RECEIPT.json').read_text());assert receipt['pathCount']==198
assert sha(package/'PATCH.diff')==receipt['patchSHA256']=='315b9e86170ef3bec16ec06da9c7d63f8ebc4a40e0135feb7d2e46338969982f'
assert sha(package/'MANIFEST.json')==receipt['manifestSHA256']=='3cfe21c4170a0b205161b071cd1d32ed62b4ee1c5b54b8e54f06704a2a864c71'
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary'])==(package/'PATCH.diff').read_bytes()
raw=json.loads((h/'EXPECTED-IDENTITIES.json').read_text())+[json.loads((d/'EXPECTED-IDENTITIES.json').read_text())]
assert [r['count'] for r in raw]==[3,3,1]
assert [r['sourceSHA256'] for r in raw]==['0e18140198c43ed14312bc8c53ef38e913f5a3e13e52281c285c11a383cba724','2ac0824121bf4f13bbd9e04741cfa62d97fa5f245f4edadd6f85a42b99924f69','6758bf66ab75ebd4230fe75b81869ca81b5fb3b0c0d3478d39a46b124cb39f28']
expected=[]
for row in raw:
    assert row['budgetMs']==5000 and sha(K/row['file'])==row['sourceSHA256']
    text=(K/row['file']).read_text();describes=re.findall(r"describe\('([^']+)'",text);leaves=re.findall(r"\bit\('([^']+)'",text)
    assert len(describes)==1 and len(leaves)==row['count'] and row['identities']==[describes[0]+' '+leaf for leaf in leaves]
    expected.append(dict(file=row['file'],sourceSHA256=row['sourceSHA256'],count=row['count'],names=row['identities'],leaves=[dict(fullName=name,budgetMs=5000,budgetSource='unchanged core default; all genuine setup inside test') for name in row['identities']]))
source=json.loads((A/'P16-RIVAL-BUYER-FINAL3-SOURCE-BINDING.json').read_text())
for row in source['sourceFiles']:assert sha(K/row['path'])==row['postimageSHA256']
bindingPath=A/'P16-RIVAL-WRITEOFF-R25-SOURCE-BINDING.json'
with bindingPath.open('x') as f:json.dump(dict(sourceFiles=source['sourceFiles'],sourcePatchSHA256=source['sourcePatchSHA256'],compiledTests={r['file']:r['sourceSHA256'] for r in expected},testOnlyCorrectionSHA256=sha(h/'SOURCE.patch'),fundedDiagnosticSHA256=sha(d/'SOURCE.patch'),status='Reviewed current198 test-only correction and genuine funded-route diagnostic; source unchanged from R24; measurement pending'),f,indent=2);f.write('\n')
files=[r['file'] for r in expected]
scope='Fresh root and three complete files7/default5000ms: corrected rival163 final3, player shooting5 writeoff3 with three repeated admissions removed, fixed genuine171 funded drafting diagnostic1; original R24 failure and both overruns retained; no broader P16 acceptance'
old_scope=json.loads((old/'BINDINGS.json').read_text())['executionScope']
def relocate(s):return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r24-run','p16-work-release61-integration-r25-run')
selection=json.loads(relocate((old/'SELECTION.json').read_text()));selection[-1]=selection[-1][:10]+files
script=relocate((old/'runner.sh').read_text()).replace(old_scope,scope)
lines=script.splitlines();positions=[i for i,s in enumerate(lines) if s.startswith('commands=')];assert len(positions)==1;lines[positions[0]]='commands='+repr(selection)
positions=[i for i,s in enumerate(lines) if s.startswith('run estate-red ')];assert len(positions)==1
lines[positions[0]]='run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(files)
script='\n'.join(lines)+'\n';script=script.replace('complete rival163 final3 and playerwriteoff3 selection','complete corrected writeoff6 and funded171 diagnostic1 selection')
dest.mkdir();(dest/'runner.sh').write_text(script);(dest/'SELECTION.json').write_text(json.dumps(selection,indent=2)+'\n')
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes());(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace(old_scope,scope));(dest/'EXPECTED-IDENTITIES.json').write_text(json.dumps(expected,indent=2)+'\n')
b=json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),pathCount=198,patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},finalCleanTestAdmission='Reviewed cash hostile premise above existing relative tolerance; three duplicate same-output reads only; all unique checks and original5s retained; funded171 diagnostic reviewed; final runner review required')
for row in b['artifacts']:
    p=Path(row['path'])
    if p.parent==dest:row['sha256']=sha(p)
    else:assert sha(p)==row['sha256'],str(p)
for p in [package/'INSTALL-RECEIPT.json',h/'SOURCE.patch',h/'MANIFEST.json',h/'HARNESS-ONLY.diff',h/'EXPECTED-IDENTITIES.json',d/'SOURCE.patch',d/'MANIFEST.json',d/'EXPECTED-IDENTITIES.json',bindingPath,A/'P16-RIVAL-WRITEOFF-HARNESS-DRAFTING-INSTALL-SPEC.json',A/'P16-WORK-RELEASE61-INTEGRATION-R24-PARENT-RESULT.json',A/'P16-RIVAL-BUYER-R24-ACTUAL-REVIEW.md',A/'P16-WRITEOFF-READER-HARNESS-R1-INDEPENDENT-REVIEW.md',A/'P16-DRAFTING171-FUNDED-BASELINE-R2-INDEPENDENT-REVIEW.md',A/'P16-RIVAL-BUYER-CASH-TOLERANCE-TEST-R2-INDEPENDENT-REVIEW.md']:
    b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles']={p.name:sha(p) for p in old.iterdir() if p.is_file()};assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']:os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins={p.name:sha(p) for p in dest.iterdir() if p.is_file()};(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n');(dest/'README.md').write_text(scope+'. UNRUN pending final admission and actual preflight.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins),indent=2))
