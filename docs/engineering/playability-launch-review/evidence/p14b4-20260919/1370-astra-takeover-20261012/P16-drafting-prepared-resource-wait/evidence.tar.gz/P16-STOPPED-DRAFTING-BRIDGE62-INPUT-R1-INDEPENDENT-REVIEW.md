# Bridge62 input overlay

Conditional KEEP static/UNRUN. Exact SOURCEd713d6afd1b67ce0082d2b08e375adb21e095a2de2c984912b6c18bb6ac1fb25 / MANIFEST403ae161468dd5b5fc93038575daddb6462a002d936c5f869057ae6e5aaa47cf verified. Schema preimage8c74bf4c… is exact reviewed stopped-drafting source postimage, not current61; apply six-source packet before overlay. Registry preimage matches actual current source. No silent overwrite of newer source intended.

Only projection constant61→62 and actual literal outgoing61 prior-registry entry are changed. OUTGOING61 receipt hash matches retained actual R5 parent result; all four current generated file bytes agree earned hashes. Outgoing schemaId sha256:7d23fdb9a710175afb88208170cfe5692510febe06fb898a3ccd95edc9c53306 is actual earned identity, not current62 guessed identity. Existing prior entries/frozen bodies/protocol4/Save49 remain unchanged. Adding supported prior ID does not weaken prior checkpoint slot validation or journal reset.

Canonical command pair remains installed vite-node scripts/generate-bridge-contract.ts and generate-bridge-contract-fixtures.ts, with corresponding --check afterward. Allowed outputs remain only schemaJSON/C#DTO/contractmanifest/unionfixtureCS, all explicit before/post including byte-identical output/mode handling. Parent must derive immutable coherent-source generation runner and real output identities; this source overlay itself performs no generation/qualification. No62 hash supplied is correct because none earned yet.

Named ScriptVerdict/ref-array in reviewed source avoids earlier anonymous-object/union emitter constraint. Full typed quote and generated consumers must now represent required scripts[]/actual verdicts; exact current version/hash/registry-count/digest expectations need earned62 outputs, while historical eras remain pinned. Frozen61 output identities remain retained, current62 must not appear in prior-ID map. Native C# consumer compilation/fullquote parity remains separate, no acceptance from source.

Funded171 prerequisite still unrun and resource/Owner pause persists. No runtime/helper/generation/K/R/index/HANDOFF edits, new dependencies or whole-P16/native waiver.
