# Canonical Bridge62 input overlay — STATIC / UNRUN

This TWO-file overlay follows the immutable six-source stopped-drafting packet d3db0e3569b5b8bc0e6263aa771ac03e775ebe2fa93b9e4f65d5d4858a31f903. Its bridge-schema preimage is THAT packet's postimage, not current K61; apply six-source packet FIRST, then overlay. Registry preimage is exact current K. Fullpre/postimages and manifest bind both. Nothing changes original preserved61 source or generated bodies.

Only projection constant61→62/comment and exact outgoing61 prior-map entry are changed. Literal outgoing schemaId is sha256:7d23fdb9a710175afb88208170cfe5692510febe06fb898a3ccd95edc9c53306, independently repeated in actual generated C# header, current contractmanifest and measured R5 parent result. Four actual generated file hashes match that recorded result, bound in OUTGOING61.json. No invented62 hash or generated file edit. Prior protocol4 path retains actual two-slot validation/migration and opaque journal reset; no session/replay/discard policy change.

Parent single-lane generation commands (existing Node20 installation, only after funded171 prerequisite+review/source integration):
node node_modules/vite-node/vite-node.mjs scripts/generate-bridge-contract.ts
node node_modules/vite-node/vite-node.mjs scripts/generate-bridge-contract-fixtures.ts
Existing checks add --check respectively; no new scripts/deps/timeouts. Existing generation runner must be rebound to coherent sourcepacket/preimages/actual4outputs, not launched from this note. Allowed four output paths exactly:
bridge/schema/project-studio-bridge.schema.json
generated/unity/StudioBridgeDtos.Generated.cs
generated/unity/project-studio-bridge.contract-manifest.json
generated/unity/tests/StudioBridgeUnionFixtures.Generated.cs

The six-source packet adds named StudioAbsorptionScriptVerdict/ref-array and actual scripts projection; output62 must carry it, and native generated DTO/manifest import remains parent-owned later. Exact current schema/hash/version assertions must use ACTUAL generated62 identity after canonical generation; none is supplied here. Protocol remains4, Save49/rightsroot2 unchanged. Existing dynamic PROJECTION_VERSION/SNAPSHOT_VERSION/SCHEMA_ID imports update through canonical owner. Historical numeric weeks61 are not version pins.

Concrete affected existing complete tests: bridge-runtime-checkpoint.test.ts951/982 exact registry list and generated it.each membership; bridge-p14b4-runtime47-compatibility.test.ts225 exact prior IDs; bridge-p14p4p5-opportunities.test.ts520 sorted older count/digest excluding54; bridge-p14r2r3-prior55.test.ts204 sorted older count/digest excluding55. Their current older expected lists still stop before P16 and must account for REAL58/59/60 as well as61 when parent qualifies this group; preserve literal old eras and exact assertions, no mass baseline waiver. New62 membership of current identity remains false. Exact typed quote term expectations/literals in Bridge absorption consumers must include scripts[] or actual verdicts; no omitted-field weakening. Compiler/generator/consumer checks must run coherently after actualoutputs. No runtime/generation/K/R/input/index/HANDOFF mutation performed.

Static literal map after this overlay contains 47 distinct entries (not a runtime acceptance claim). No test edits are in this source-only packet.
