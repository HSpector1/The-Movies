# Shooting4 independent tests

Conditional KEEP static/UNRUN against reviewed completed-take source. Exact test69539a7f9b0fc775ce71430677e1dfd88900f186b5352dcc9951eb14f3cc4b22 / SOURCE0ea2bd0e5dfabd7bf65ff3abbfa447db5864bc50dc2cd5bf3b92faba67c5f9f8 / MANIFEST403008e3b20a172d2c436ddc7b51bbd30e84cac104fa0833a3ff936084222c90 verified.

Three default5s leaves use fixed genuine pre162 R02 remaining4, real paidDD/public ask/retain6/quote/close with mandatory positive premises. Positive proves original event45/week162, source silentlock160, completed source task/paid snapshot unchanged; real buyer reservation allocation; native wrap input162 observed163; post/ready165, hold166, publiccommit166/release observed167; source creator film and buyer title/run, full save/reload/replay and caller purity. No source history or lock is invented.

Hostile leaf establishes positive full save first, then wrong buyer take, wrong buyer silent lock and altered original snapshot. Lock mutant is consequential: current technology validator may accept acquired buyer owner, but new completedTake reader explicitly requires retained source owner, so the joined full-reader test distinguishes that law. Existing typed Production snapshot field is writable; no validator-skipping cast introduced. Exact first-owner regex expectations remain prospective and actual next causes must be retained if different.

Rollback calls real makeSave admission before unique marker, restores spy and proves original caller unchanged; no successful validation stub. No setup outside leaf/cache/new route/budget expansion. Complete type/route/first-owner/timing qualification pending, original earlier controls untouched. No runtime/K/R writes.
