# Completed-take shooting4 source

KEEP static/UNRUN. Exact SOURCEd0979f693b49c8e59ec5918d1e0c789b31090516e41f071db71675610ac45dfa / MANIFESTc9f40406613fcb3e415080267c3218447aa082023826770f3af86a2c6aee268b verified.

Only original shooting phase/remaining4 is added. Producer requires actual creator first take, completed original task with locked director, no setup/Set requirement, exactly one original creator silent lock/adoptionnull dated no later than acquisition. Initial shooting5, sound/selected technology and setup/Set-required remain refused. Full input admission establishes source task/stage/take/cast and lock chronology before trusted quote/close.

Real addManagedProductionWorkflow still allocates buyer stage/scenery under one actual occupancy pool. Its tasknull draft is completed only for this admitted shooting4 case using canonical task ID, locked director and actual returned buyer stage, with bindings heldSinceWeek at acquisition. Existing operations validator accepts completed task with null next-phase blocker and requires task destination match real soundstage reservation. Source workflow removal and buyer workflow/capacity use remain once; no copied facilities, second first take, technology lock or historical event is minted.

Current reader agrees on completed4, actual original task/creator lock and exact native4→3 input-week wrap proof. Existing non-unshot firstTake path requires creator owner, actual participants/date and source paid screenplay/snapshot; complete counters, ready/release/public commitment/Standing/revenue joins stay. Frozen/default reader and conservative allocator unchanged. The new source lock-owner requirement remains distinguishing even when the lower current technology acquired-owner context permits a buyer-owned lock; joined reader refuses that reassignment.

Real eligibility/retention/affordability/capacity/publication and all later release timings remain UNRUN. No wider shooting/setup support or whole-P16/native acceptance. No runtime/K/R edits.
