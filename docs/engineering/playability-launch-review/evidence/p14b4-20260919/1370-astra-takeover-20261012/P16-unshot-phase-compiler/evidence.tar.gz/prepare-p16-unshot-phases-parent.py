from pathlib import Path
import json,hashlib,os,re,difflib
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r11';D=A/'p16-work-release61-integration-runner-r12';out=A/'p16-work-release61-integration-r12-run';p=A/'p16-unshot-silent-phase-integration-r1'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
def row(folder,file):return next(x for x in read(A/folder/'EXPECTED-IDENTITIES.json') if x['file']==file)
m=read(p/'MANIFEST.json');D.mkdir()
inv=read(A/'P16-SILENT-PHASES76-R2-EXPECTED-IDENTITIES.json')
new=dict(file=inv['identities'][0]['file'],sourceSHA256=inv['sourceSha256'],count=inv['count'],names=[x['fullName'] for x in inv['identities']],leaves=[dict(fullName=x['fullName'],budgetMs=x['budgetMs'],budgetSource=x['budgetOrigin']) for x in inv['identities']])
expected=[row(old.name,'tests/p16-continued-work-silent-early.test.ts'),new,row('p16-work-release61-integration-runner-r7','tests/p16-continued-work-cancel.test.ts'),row('p16-work-release61-integration-runner-r3','tests/p16-absorption-continued-production.test.ts'),row('p16-manual-cancel-companion-selection-format-r2','tests/p13b-s5-save-v24.test.ts')]
for r in expected:
 r['sourceSHA256']=sha(K/r['file']);r['count']=len(r['names'])
 if 'leaves' not in r:r['leaves']=[dict(fullName=n,budgetMs=5000,budgetSource='unchanged core default; setup inside test') for n in r['names']]
 assert {x['fullName'] for x in r['leaves']}==set(r['names']) and all(x['budgetMs']==5000 for x in r['leaves'])
assert len(expected)==5 and sum(len(x['names']) for x in expected)==31
write('EXPECTED-IDENTITIES.json',expected)
commands=read(old/'SELECTION.json');commands[-1]=commands[-1][:10]+[r['file'] for r in expected];commands[-1][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
for name in ['auto_freeze.py','account-results.py']:(D/name).write_bytes((old/name).read_bytes())
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(A/'p16-work-release61-integration-r11-run'),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root compiler then relationships53 and early SILENT final4 commands','literal root compiler then complete early4 phases6 cancellation3 latepost3 save15 commands')
s=re.sub(r'^run estate-red .*$', 'run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(r['file'] for r in expected),s,flags=re.M)
s=s.replace('fresh root compiler; unchanged complete57 after exact input-week wrap joins and strict inline historical test projection correction; all prior and inherited failures retained','fresh root compiler; complete31 early SILENT initial8/7/6, cancellation, latepost and S5 save compatibility; all original budgets and prior failures retained')
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=read(old/'BINDINGS.json');b.update(package=str(p),patchSHA256=sha(p/'PATCH.diff'),manifestSHA256=sha(p/'MANIFEST.json'),pathCount=len(m['files']),plannedPathCount=len(m['files']),expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},installedSourceReceiptSHA256=sha(p/'INSTALL-RECEIPT.json'),scope='Shared native unshot SILENT initial phase predicate plus reviewed same-caller and strict export harness corrections',executionScope='Fresh root compiler and complete5 files31 with unchanged5000ms per-leaf budgets; all original fixtures, native ticks, caller purity, full validation, canonical crossproducer output, rollback and save/replay assertions retained; no wholeP16/native/player claim',finalCleanTestAdmission='Independent source/tests/harness/install KEEP; original R11 early positive5394ms and R8 S5middeployment10767ms retained, no unmodified retry')
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',p/'INSTALL-RECEIPT.json',A/'P16-UNSHOT-SILENT-PHASES-INSTALL-SPEC.json',A/'P16-UNSHOT-SILENT-PHASES-INSTALL-INDEPENDENT-REVIEW.md',A/'P16-SILENT-PHASES76-R2-EXPECTED-IDENTITIES.json',A/'P16-CONTINUED-WORK-SILENT-PHASES76-TESTS-R1-INDEPENDENT-REVIEW.md',A/'P16-WORK-RELEASE61-INTEGRATION-R11-PARENT-RESULT.json',A/'P16-SILENT-WRAP-CORRECTION-R11-ACTUAL-REVIEW.md']
for spec in read(A/'P16-UNSHOT-SILENT-PHASES-INSTALL-SPEC.json'):
 paths += [A/spec['patch'],A/spec['review'],(A/spec['patch']).parent/'MANIFEST.json']
for q in paths:
 assert q.is_file()
 if str(q) not in {r['path'] for r in b['artifacts']}:b['artifacts'].append(dict(path=str(q),sha256=sha(q)))
write('BINDINGS.json',b)
(D/'DELTA-vs-r11-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r11/runner.sh',tofile='r12/runner.sh')))
(D/'README.md').write_text('UNRUN: fresh root compiler and complete five files31, each unchanged5000ms budget. Genuine unshot initial8/7/6 acquisition through firsttake/wrap/explicitrelease, refusal/rollback, existing latepost/cancellation and strict S5 saves. Three source paths share phase classification; caller-only JSON snapshots and three existing strict export helper uses remove redundant work without waived assertions or setup ticks. Preserve all original failures/timings. No runtime claim before actual measurement and independent reconciliation.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
