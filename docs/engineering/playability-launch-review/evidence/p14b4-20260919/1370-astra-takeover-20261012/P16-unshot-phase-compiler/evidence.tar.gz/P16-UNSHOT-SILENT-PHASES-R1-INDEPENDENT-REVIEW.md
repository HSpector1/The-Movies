# Common unshot SILENT phase predicate

KEEP static/UNRUN. SOURCE0cbf129c and MANIFESTfff30c31 identify the reviewed sparse three-file patch. The shared predicate accepts exactly development/preProduction/rehearsal (native remaining8/7/6). Producer and current reader consistently use it; current reader applies original unshot exact wrap proof to all three. Shooting5, setup/Set-selected, sound and writing remain unsupported rather than silently cancelled.

Existing real source workflow/phase, no actual first take at acquisition, setupnull, no required Set and no preselected technology producer gates remain. Current reader retains paid screenplay/cost/source snapshot, exact initial workflow and complete step sequence, real buyer lock on6→5, take on5→4, original creator subject and input-week4→3 wrap proof. No allocator, producer clock, frozen/default reader or public action semantics are broadened. Shared predicate does not substitute for these domain gates.

Independent initial7/6 tests are reviewed separately and remain mandatory prospective premises: genuine actual163 then optional one ordinary tick164, no forged counters. No runtime/type compilation or timing is claimed; original8 assertions and all earlier failures remain retained.
