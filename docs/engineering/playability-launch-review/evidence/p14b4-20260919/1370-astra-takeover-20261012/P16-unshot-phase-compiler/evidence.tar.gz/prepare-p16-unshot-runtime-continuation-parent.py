from pathlib import Path
import json,hashlib,re,os,difflib
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
old=A/'p16-work-release61-integration-runner-r12';D=A/'p16-work-release61-integration-runner-r13';out=A/'p16-work-release61-integration-r13-run'
prior=A/'p16-work-release61-integration-r12-run';audit=A/'p16-work-release61-integration-r12-parent-reconciliation'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK');D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
commands=json.loads((old/'SELECTION.json').read_text())[1:];assert len(commands)==1
commands[0][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
for n in ['EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']:(D/n).write_bytes((old/n).read_bytes())
reuse={'priorRun':str(prior),'baseFreeze':str(prior/'freeze.json'),'independentFreeze':str(audit/'independent-freeze.json'),'parentResult':str(A/'P16-WORK-RELEASE61-INTEGRATION-R12-PARENT-RESULT.json'),'originalWrapperExit':97,'reusedChild':'tsc-root','requiredChildExit':0,'seconds':161,'rule':'Exact original compiler/source/index/HEAD/metadata/input equality against independently reconciled prior run; additional pinned continuation artifacts only. Original wrapper97 remains failed; complete31 runtime unexecuted until this run.'}
write('ROOT-REUSE.json',reuse)
helper=(A/'p16-work-release61-integration-runner-r6/root-reuse.py').read_text();assert "child['seconds']==62" in helper
(D/'root-reuse.py').write_text(helper.replace("child['seconds']==62","child['seconds']==161"))
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(prior),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root compiler then complete early4 phases6 cancellation3 latepost3 save15 commands','literal runtime-only complete31 commands; actual root child reused by strict equality')
s=s.replace('fresh root compiler; complete31 early SILENT initial8/7/6, cancellation, latepost and S5 save compatibility; all original budgets and prior failures retained','exact actual root0 reused; complete31 early SILENT initial8/7/6, cancellation, latepost and S5 save compatibility; all original budgets and prior failures retained')
start=s.index('# Fresh compiler prerequisites,');end=s.index('run estate-red ',start)
s=s[:start]+'python3 -I -B "$D/root-reuse.py" "$OUT/freeze.json" > "$OUT/root-reuse.json" || exit 98\n'+s[end:]
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text());b.update(scope='Runtime-only continuation of actual r12 root0/wrapper97; complete31 unchanged',executionScope='Reuse actual root compiler0/161s only after exact full original freeze/input equality; run complete31 unchanged5000ms; no original failure or timing waiver, no wholeP16 acceptance',rootReuse=reuse)
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
oldfreeze=json.loads((prior/'freeze.json').read_text())
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',D/'ROOT-REUSE.json',D/'root-reuse.py',prior/'freeze.json',audit/'independent-freeze.json',Path(reuse['parentResult']),prior/'terminal.json',prior/'results.jsonl',prior/'tsc-root.log',A/'P16-UNSHOT-SILENT-PHASES-R12-ACTUAL-REVIEW.md',A/'P16-UNSHOT-SILENT-PHASES-R12-RUNNER-INDEPENDENT-REVIEW.md']
paths += [Path(p) for p,v in oldfreeze['inputs'].items() if isinstance(v,list) and v[0]=='file']
existing={r['path']:r['sha256'] for r in b['artifacts']}
for q in paths:
 if str(q) in existing:assert existing[str(q)]==sha(q)
 else:b['artifacts'].append({'path':str(q),'sha256':sha(q)});existing[str(q)]=sha(q)
write('BINDINGS.json',b)
(D/'DELTA-vs-r12-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r12/runner.sh',tofile='r13/runner.sh')))
(D/'README.md').write_text('UNRUN runtime-only continuation. Actual r12 compiler child passed0/161s; wrapper stopped97 at unchanged runtime floor before any test. Retain exact prior/current source/index/metadata/original input equality and independent reconciliation. Same complete31 and all original5000ms budgets, same lane/floors/bootstrap/freeze/accountant. No K/source edits and no compiler rerun. Preserve original97.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
