from pathlib import Path
import hashlib, json, os, re, subprocess
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r18'
dest=A/'p16-work-release61-integration-runner-r19'
package=A/'p16-rival-buyer-rights-integration-r1'
tests=A/'p16-rival-buyer-rights-tests-r2'
out=A/'p16-work-release61-integration-r19-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not dest.exists() and not out.exists()
assert sha(old/'runner.sh')=='cc4a780f8c3edcb79365dc7ea957e847375ff517c473c7b883e7828dc3ae0097'
assert sha(old/'BINDINGS.json')=='8539ae2601672ee086fb87ef9ae37af65fc58fdc3f72bc6164d0f7d094ea2605'
receipt=json.loads((package/'INSTALL-RECEIPT.json').read_text());assert receipt['pathCount']==194
assert sha(package/'PATCH.diff')==receipt['patchSHA256']
assert sha(package/'MANIFEST.json')==receipt['manifestSHA256']
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary'])==(package/'PATCH.diff').read_bytes()
scope='Fresh root and complete rival-buyer rights file3/default5000ms; actual pre162 R01 sale to R03, paid recipient DD, direct-answer parity and real cash-owner atomic refusal; no native or whole-P16 acceptance'
raw=json.loads((tests/'EXPECTED-IDENTITIES.json').read_text())
assert raw['count']==3 and raw['budgetMs']==5000
assert raw['sourceSHA256']==sha(K/raw['file'])=='d551bb772005a52eec177c14f1aeb600cc0976f665cab2604fab1170dafec987'
expected=[dict(file=raw['file'],sourceSHA256=raw['sourceSHA256'],count=3,names=raw['identities'],leaves=[dict(fullName=n,budgetMs=5000,budgetSource='unchanged core default; complete setup inside test') for n in raw['identities']])]
def relocate(s):return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r18-run','p16-work-release61-integration-r19-run')
selection=json.loads(relocate((old/'SELECTION.json').read_text()));selection[-1]=selection[-1][:10]+[raw['file']]
script=relocate((old/'runner.sh').read_text())
script,n=re.subn(r'^commands=.+$','commands='+repr(selection),script,count=1,flags=re.M);assert n==1
script,n=re.subn(r'^run estate-red .+$','run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+raw['file'],script,count=1,flags=re.M);assert n==1
old_scope=json.loads((old/'BINDINGS.json').read_text())['executionScope']
script=script.replace(old_scope,scope).replace('literal root compiler then complete silent-work six-file22 selection','literal root compiler then complete rival-buyer rights file3 selection')
dest.mkdir();(dest/'runner.sh').write_text(script)
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace(old_scope,scope))
for name,value in [('SELECTION.json',selection),('EXPECTED-IDENTITIES.json',expected)]:(dest/name).write_text(json.dumps(value,indent=2)+'\n')
b=json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],pathCount=194,plannedPathCount=194,installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={raw['file']:raw['sourceSHA256']},finalCleanTestAdmission='Independent test3 static KEEP, actual parent SOURCE-BINDING resolves prospective draft note, exact194 test-only install; final runner independent review required')
for row in b['artifacts']:
 p=Path(row['path'])
 if p.parent==dest:row['sha256']=sha(p)
 else:assert sha(p)==row['sha256'],str(p)
for p in [package/'INSTALL-RECEIPT.json',tests/'SOURCE.patch',tests/'MANIFEST.json',tests/'EXPECTED-IDENTITIES.json',tests/'SOURCE-BINDING.json',A/'P16-RIVAL-BUYER-RIGHTS-INSTALL-SPEC.json',A/'P16-RIVAL-BUYER-RIGHTS-TESTS-R2-INDEPENDENT-REVIEW.md',A/'P16-WORK-RELEASE61-INTEGRATION-R18-PARENT-RESULT.json',A/'P16-INITIAL-SHOOTING5-R18-ACTUAL-REVIEW.md']:
 b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles']={p.name:sha(p) for p in old.iterdir() if p.is_file()}
assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']:os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n');(dest/'README.md').write_text(scope+'. UNRUN pending final independent admission and existing preflight.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins,package=receipt['package'],patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256']),indent=2))
