// ── P16C: estates — the typed P15 handoff, clean lots, sealed bids and the close ceremony at D ──
//
// Authority: P16 integration contract §4 (the handoff admits lots; P16 cannot declare a studio
// terminal; half-open window [opensWeek, closesWeek) closes once; unsold lots archive; no free claim;
// estate staff are free agents and a purchase buys no people), §6 (sealed one-shot comparison at the
// recorded close, descending amount then ascending reserved identity order, no RNG; revalidate
// eligibility/reserved cash/lot authority before resolution and fall back to the next valid bid;
// consideration to the estate once; archival freezes unsold rights; repeat close is an explicit
// refusal or policy no-op), §7 group E; 1367-G timing amendment (bids only before D; pre-D sealed
// bids resolve exactly once at D; new bids at D refuse; ESTATE_WINDOW_WEEKS = 13); 1362-O §5.1/§5.3.
//
// ADAPTER POINT: `EstateHandoff` is what P16 needs from P15B Wave 4's actual closure result. The
// parent wires the real producer at landing (`openEstate(state, handoff, week, readers)` in the closure
// week) IN THE SAME CHANGE that binds the P15B condition readers: an estate neither opens nor closes
// under the unbound sentinel, whose fail-closed answers would disqualify every bid and archive every
// lot for good (r2, review F60). Until then estates open only from hand-built handoffs in tests.
// Proceeds are recorded on the estate record for P15's claims distribution and are never credited to
// any studio.
//
// r2 (review F4/F29/F39, contract §3/§4): handoff v2 disposes of EVERY right the closed studio holds —
// each one in exactly one lot or in `pending` with its reason — and carries each lot's licence
// encumbrance references and the closure's claim references. A lot may not hold a right the sale law
// refuses to transfer (an R2 film in an active run, an R1 property with an active production); the
// ceremony checks it again at D. Pending rights freeze at closure and archive at D.

import { blockingEncumbrance } from './licence.js'
import { corporateConditionReaders, moveStudioCash, permittedBidderRefusal, postPurchaseReserve, spendableCash, affordabilityRefusal,
  UNBOUND_CORPORATE_CONDITION_READERS, type CorporateConditionReaders } from './rightsFinance.js'
import { allocateRightsId, appendTitleEvent, currentHolder, ESTATE_PENDING_REASONS, estateHolderId, materializeLegacyTitles, resolveTitles, subjectKey,
  subjectsHeldBy, type EstateBid, type EstateLot, type EstatePendingReason, type EstateRecord, type RightSubject, type RightsTransaction } from './rights.js'
import { TUNING } from './tuning.js'
import type { GameState } from './types.js'

/** What an estate needs from a closed studio (P15B Wave 4 produces it; P16 only consumes it). */
export type EstateHandoff = {
  version: 2
  /** P15's closure record identity. */
  closureId: string
  /** Stable estate identity, chosen by the producer (e.g. `estate-<studioId>-<closureWeek>`). */
  estateId: string
  /** The closed studio: a reserved identity (player or rival). */
  studioId: string
  /** The terminal week: the first nonoperating boundary. */
  closureWeek: number
  /** The disposal window [opensWeek, closesWeek): opensWeek is the closure week, closesWeek = opensWeek + ESTATE_WINDOW_WEEKS. */
  opensWeek: number
  closesWeek: number
  /** Clean, explicitly identified, non-overlapping lots of rights the studio held at closure, each naming the licences
   * (`licence:<id>`, live or future on its subjects) it is sold subject to. */
  lots: EstateLot[]
  /** Every other right the studio held at closure, with why it is not offered. */
  pending: { subject: RightSubject; reason: EstatePendingReason }[]
  /** References into P15's claims context: P15 owns class, priority and payment. */
  claimsContext: { priorityVersion: string; claimIds: string[] }
  /** P15's terminal cash reconciliation; unpaid loan remainder stays visible and unpaid. */
  cashReconciliation: { terminalCash: number; loanRemainder: number }
}

export type EstateBidInput = { estateId: string; lotId: string; bidderId: string; amount: number }

/** The licence references a lot of these subjects is sold subject to: every licence not yet ended at `week`, sorted. */
export function lotEncumbranceRefs(state: GameState, subjects: readonly RightSubject[], week: number): string[] {
  const keys = new Set(subjects.map(subjectKey))
  return state.rights.licences.filter((l) => keys.has(subjectKey(l.subject)) && week < l.endWeekExclusive).map((l) => `licence:${l.id}`).sort()
}

const sameList = (a: readonly string[], b: readonly string[]): boolean => a.length === b.length && a.every((x, i) => x === b[i])

export function estateHandoffRefusal(state: GameState, handoff: EstateHandoff, week: number): string | null {
  const h = state.hollywood
  if (!h) return 'noIndustry'
  if (handoff.version !== 2) return 'unknownVersion'
  if (!h.identities.some((i) => i.studioId === handoff.studioId)) return 'unknownStudio'
  if (state.rights.estates.some((e) => e.studioId === handoff.studioId || e.estateId === handoff.estateId)) return 'duplicateEstate'
  if (typeof handoff.estateId !== 'string' || handoff.estateId.length === 0 || typeof handoff.closureId !== 'string' || handoff.closureId.length === 0) return 'invalidIdentity'
  const { closureWeek, opensWeek, closesWeek } = handoff
  if (![closureWeek, opensWeek, closesWeek].every(Number.isSafeInteger) || opensWeek !== closureWeek || closesWeek !== opensWeek + TUNING.ESTATE_WINDOW_WEEKS) return 'invalidWindow'
  // r2 (F18): the estate opens in the closure week itself, on the state of that week.
  if (week !== closureWeek || week !== state.market.tick) return 'notClosureWeek'
  if (!Array.isArray(handoff.lots) || !Array.isArray(handoff.pending)) return 'invalidDispositions'
  const disposed = new Set<string>()
  const lotIds = new Set<string>()
  for (const lot of handoff.lots) {
    if (typeof lot.lotId !== 'string' || lot.lotId.length === 0 || lotIds.has(lot.lotId)) return 'duplicateLotId'
    lotIds.add(lot.lotId)
    if (!Number.isSafeInteger(lot.minimumBid) || lot.minimumBid < 0) return 'invalidMinimumBid'
    if (!Array.isArray(lot.subjects) || lot.subjects.length === 0) return 'emptyLot'
    for (const subject of lot.subjects) {
      const key = subjectKey(subject)
      if (disposed.has(key)) return 'lotOverlap'
      disposed.add(key)
      const holder = currentHolder(state, subject, closureWeek)
      if (holder.kind !== 'holder' || holder.holderId !== handoff.studioId || holder.archived || holder.estate !== undefined) return 'lotSubjectNotHeld'
      const blocked = blockingEncumbrance(state, subject)
      if (blocked !== null) return `lotEncumbered:${blocked}:${key}`
    }
    if (!Array.isArray(lot.encumbrances) || !sameList(lot.encumbrances, lotEncumbranceRefs(state, lot.subjects, week))) return `encumbranceMismatch:${lot.lotId}`
  }
  for (const pending of handoff.pending) {
    if (!(ESTATE_PENDING_REASONS as readonly string[]).includes(pending.reason)) return 'invalidPendingReason'
    const key = subjectKey(pending.subject)
    if (disposed.has(key)) return `dispositionDuplicate:${key}`
    disposed.add(key)
    const holder = currentHolder(state, pending.subject, closureWeek)
    if (holder.kind !== 'holder' || holder.holderId !== handoff.studioId || holder.archived || holder.estate !== undefined) return `pendingSubjectNotHeld:${key}`
  }
  // r2 (F39): every right the studio holds at closure gets exactly one disposition.
  for (const subject of subjectsHeldBy(resolveTitles(state), state.rights.estates, handoff.studioId, closureWeek)) {
    if (!disposed.has(subjectKey(subject))) return `dispositionMissing:${subjectKey(subject)}`
  }
  const claims = handoff.claimsContext
  if (typeof claims?.priorityVersion !== 'string' || claims.priorityVersion.length === 0 || !Array.isArray(claims.claimIds)
    || claims.claimIds.some((c) => typeof c !== 'string' || c.length === 0) || new Set(claims.claimIds).size !== claims.claimIds.length) return 'invalidClaimsContext'
  if (!Number.isFinite(handoff.cashReconciliation?.terminalCash) || !Number.isFinite(handoff.cashReconciliation?.loanRemainder)) return 'invalidCashReconciliation'
  return null
}

/** r2 (F60): the unbound P15B sentinel can certify no bidder, so it may neither open an estate nor run its ceremony. */
function requireBoundReaders(readers: CorporateConditionReaders, what: string): void {
  if (readers === UNBOUND_CORPORATE_CONDITION_READERS) {
    throw new Error(`estate: ${what} refused: conditionReadersUnbound (bind the P15B readers in rightsFinance.ts in the same change that wires the closure producer)`)
  }
}

/** Opens the estate: every disposed title is materialized so every later event has a persisted chain. Moves no money, touches no person. */
export function openEstate(state: GameState, handoff: EstateHandoff, week: number, readers: CorporateConditionReaders = corporateConditionReaders): { state: GameState; estate: EstateRecord } {
  requireBoundReaders(readers, 'opening an estate')
  const refusal = estateHandoffRefusal(state, handoff, week)
  if (refusal !== null) throw new Error(`estate handoff refused: ${refusal}`)
  let next = state
  for (const subject of [...handoff.lots.flatMap((lot) => lot.subjects), ...handoff.pending.map((p) => p.subject)]) next = materializeLegacyTitles(next, subject)
  const estate: EstateRecord = {
    estateId: handoff.estateId, closureId: handoff.closureId, studioId: handoff.studioId, closureWeek: handoff.closureWeek,
    opensWeek: handoff.opensWeek, closesWeek: handoff.closesWeek,
    lots: handoff.lots.map((lot) => ({ lotId: lot.lotId, subjects: lot.subjects.map((s) => ({ ...s })), minimumBid: lot.minimumBid, encumbrances: [...lot.encumbrances],
      status: 'open', winningBidId: null, transactionId: null })),
    bids: [], proceeds: [], closedWeek: null,
    pending: handoff.pending.map((p) => ({ subject: { ...p.subject }, reason: p.reason, status: 'pending' })),
    claimsContext: { priorityVersion: handoff.claimsContext.priorityVersion, claimIds: [...handoff.claimsContext.claimIds] },
    cashReconciliation: { ...handoff.cashReconciliation },
  }
  return { state: { ...next, rights: { ...next.rights, estates: [...next.rights.estates, estate] } }, estate }
}

export function estateBidRefusal(state: GameState, input: EstateBidInput, week: number, readers: CorporateConditionReaders = corporateConditionReaders): string | null {
  const estate = state.rights.estates.find((e) => e.estateId === input.estateId)
  if (estate === undefined) return 'unknownEstate'
  if (estate.closedWeek !== null || week >= estate.closesWeek) return 'estateClosed'
  if (week < estate.opensWeek) return 'estateNotOpen'
  const lot = estate.lots.find((l) => l.lotId === input.lotId)
  if (lot === undefined || lot.status !== 'open') return 'unknownLot'
  if (input.bidderId === estate.studioId) return 'selfDealing'
  if (!Number.isSafeInteger(input.amount) || input.amount < 1) return 'invalidBid'
  if (input.amount < lot.minimumBid) return 'belowMinimumBid'
  const permitted = permittedBidderRefusal(state, input.bidderId, week, readers)
  if (permitted !== null) return `bidderNotPermitted:${permitted}`
  if (estate.bids.some((b) => b.status === 'sealed' && b.lotId === input.lotId && b.bidderId === input.bidderId)) return 'duplicateBid'
  return affordabilityRefusal(state, input.bidderId, input.amount)
}

/** A sealed bid: admitted only before D, reserving its amount until the ceremony. */
export function submitEstateBid(state: GameState, input: EstateBidInput, week: number, readers: CorporateConditionReaders = corporateConditionReaders): { state: GameState; bid: EstateBid } {
  const refusal = estateBidRefusal(state, input, week, readers)
  if (refusal !== null) throw new Error(`estate bid refused: ${refusal}`)
  const allocated = allocateRightsId(state.rights, 'estate-bid')
  const bid: EstateBid = { id: allocated.id, estateId: input.estateId, lotId: input.lotId, bidderId: input.bidderId, amount: input.amount, week, status: 'sealed', disqualification: null }
  const estates = allocated.root.estates.map((e) => (e.estateId === input.estateId ? { ...e, bids: [...e.bids, bid] } : e))
  return { state: { ...state, rights: { ...allocated.root, estates } }, bid }
}

function withEstate(state: GameState, estate: EstateRecord): GameState {
  return { ...state, rights: { ...state.rights, estates: state.rights.estates.map((e) => (e.estateId === estate.estateId ? estate : e)) } }
}

/**
 * The close ceremony, exactly once at D: per lot, sealed bids compare by descending amount then
 * ascending reserved identity row; each candidate is revalidated (the lot's encumbrances, permitted
 * bidder, lot authority, reserved cash after its earlier wins) and the first valid one wins; the rest
 * lose. Unsold lots and pending rights archive. No RNG is drawn.
 */
export function resolveEstate(state: GameState, estateId: string, week: number, readers: CorporateConditionReaders = corporateConditionReaders): GameState {
  const h = state.hollywood
  if (!h) throw new Error('estate: no industry')
  const found = state.rights.estates.find((e) => e.estateId === estateId)
  if (found === undefined) throw new Error(`estate: unknown estate ${estateId}`)
  if (found.closedWeek !== null) throw new Error(`estate: ${estateId} is already closed (week ${found.closedWeek})`)
  if (week < found.closesWeek) throw new Error(`estate: ${estateId} cannot resolve before its close boundary ${found.closesWeek}`)
  requireBoundReaders(readers, `the close ceremony of ${estateId}`)
  const row = (studioId: string): number => h.identities.find((i) => i.studioId === studioId)?.row ?? Number.MAX_SAFE_INTEGER
  let next = state
  let estate: EstateRecord = { ...found, lots: found.lots.map((l) => ({ ...l })), bids: found.bids.map((b) => ({ ...b })), proceeds: [...found.proceeds],
    pending: found.pending.map((p) => ({ ...p })) }
  for (const lot of estate.lots) {
    const candidates = estate.bids.filter((b) => b.lotId === lot.lotId && b.status === 'sealed')
      .sort((a, b) => b.amount - a.amount || row(a.bidderId) - row(b.bidderId) || (a.id < b.id ? -1 : 1))
    // r2 (F4/F29): the sale law's encumbrances hold again at D; an encumbered lot cannot sell and archives.
    const encumbered = lot.subjects.map((s) => { const b = blockingEncumbrance(next, s); return b === null ? null : `lotEncumbered:${b}:${subjectKey(s)}` }).find((r) => r !== null) ?? null
    let winner: EstateBid | null = null
    for (const bid of candidates) {
      const permitted = permittedBidderRefusal(next, bid.bidderId, week, readers)
      const authority = lot.subjects.every((s) => { const hd = currentHolder(next, s, week); return hd.kind === 'holder' && hd.holderId === estate.studioId })
      // Lots resolve in order and debit as they go: this estate's own sealed bids are not reservations here,
      // while open bilateral offers and sealed bids on OTHER estates still are.
      const ownSealedHere = estate.bids.filter((b) => b.bidderId === bid.bidderId && b.status === 'sealed').reduce((s, b) => s + b.amount, 0)
      const available = spendableCash(next, bid.bidderId) + ownSealedHere
      const refusal = encumbered !== null ? encumbered : permitted !== null ? `bidderNotPermitted:${permitted}` : !authority ? 'lotAuthorityLost'
        : available - bid.amount < postPurchaseReserve(next, bid.bidderId) ? 'insufficientCashAfterReserve' : null
      if (refusal !== null) {
        bid.status = 'disqualified'
        bid.disqualification = refusal
        next = withEstate(next, estate)
        continue
      }
      winner = bid
      break
    }
    if (winner === null) {
      for (const s of lot.subjects) {
        next = appendTitleEvent(next, { subject: s, priorHolder: estate.studioId, newHolder: estateHolderId(estate.studioId), cause: 'archive',
          date: { kind: 'campaign', week }, source: { kind: 'estate', estateId } }).state
      }
      lot.status = 'archived'
      next = withEstate(next, estate)
      continue
    }
    const txAllocated = allocateRightsId(next.rights, 'rights-tx')
    next = { ...next, rights: txAllocated.root }
    const titleEventIds: string[] = []
    for (const s of lot.subjects) {
      const appended = appendTitleEvent(next, { subject: s, priorHolder: estate.studioId, newHolder: winner.bidderId, cause: 'estateSale',
        date: { kind: 'campaign', week }, source: { kind: 'transaction', transactionId: txAllocated.id } })
      next = appended.state
      titleEventIds.push(appended.event.id)
    }
    winner.status = 'won'
    for (const bid of estate.bids) if (bid.lotId === lot.lotId && bid.status === 'sealed') bid.status = 'lost'
    lot.status = 'sold'
    lot.winningBidId = winner.id
    lot.transactionId = txAllocated.id
    estate.proceeds.push({ transactionId: txAllocated.id, lotId: lot.lotId, amount: winner.amount })
    next = withEstate(next, estate)
    next = moveStudioCash(next, winner.bidderId, 'rightsConsideration', -winner.amount, week, txAllocated.id)
    const transaction: RightsTransaction = { id: txAllocated.id, week, kind: 'estateSale', payerId: winner.bidderId, payeeId: null, estateId, amount: winner.amount,
      subject: null, licenceId: null, offerId: null, lotId: lot.lotId, bidId: winner.id, titleEventIds }
    next = { ...next, rights: { ...next.rights, transactions: [...next.rights.transactions, transaction] } }
  }
  // Pending rights archive with the unsold lots: frozen, nontradeable, never a free asset.
  for (const pending of estate.pending) {
    next = appendTitleEvent(next, { subject: pending.subject, priorHolder: estate.studioId, newHolder: estateHolderId(estate.studioId), cause: 'archive',
      date: { kind: 'campaign', week }, source: { kind: 'estate', estateId } }).state
    pending.status = 'archived'
  }
  estate = { ...estate, closedWeek: week }
  return withEstate(next, estate)
}

/** The tick-side policy: every estate whose boundary D has arrived closes once; closed estates are left alone. */
export function closeDueEstates(state: GameState, week: number, readers: CorporateConditionReaders = corporateConditionReaders): GameState {
  let next = state
  for (const estate of state.rights.estates) {
    if (estate.closedWeek === null && week >= estate.closesWeek) next = resolveEstate(next, estate.estateId, week, readers)
  }
  return next
}

/** Build the standard window from a closure week (the producer's convenience; ESTATE_WINDOW_WEEKS is adopted law). */
export function estateWindow(closureWeek: number): { opensWeek: number; closesWeek: number } {
  return { opensWeek: closureWeek, closesWeek: closureWeek + TUNING.ESTATE_WINDOW_WEEKS }
}
