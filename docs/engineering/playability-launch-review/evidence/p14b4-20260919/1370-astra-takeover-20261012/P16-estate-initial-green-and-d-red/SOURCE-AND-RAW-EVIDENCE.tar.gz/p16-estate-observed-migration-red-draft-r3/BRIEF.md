# Complementary observed48 migration RED preparation — GPT-6.1 Sol

UNRUN/A-only, four new default5s leaves, no ticks or current campaign mutation. Exact captured public original48 C163/D176 hash pins; eventual runner must freeze both files/manifest and bind P16_ORIGINAL48_CAPTURE_ROOT. Six unpaid claims/nonzero stopped loan/whole corporate-condition+closure+Legacy bytes (including run/archive/payment facts) preserved; C/D closed status, all retained ten films nontradeable at archivedD, original archival one/no new title events/transactions, same-observation-boundary full public49→48 export byte roundtrip; fixed first real lot/player public bid blocks discard after whole current save admission. Bid prerequisites UNMEASURED, fail honestly/no alternate chooser or substituted reader. This is original48 transaction-capture migration, not natural/current-D-sale acceptance.

F30 distinction: actualR04 capture has rival loanPrincipal3198000 and loanInstallment−1653120, but claimPayment0 and player loan/claim rows0. Full roots remain exact; this does NOT provide nonzero claimPayment F30 witness. No money/history is invented to fill that gap. Dsale/run collection/claim allocation remains later.

Separate bounded ROOT-VERSION-NEGATIVE.diff repairs the existing wrong-version mutant2 (actual valid RIGHTS_ROOT_VERSION2) to3. No source reader weakening, test-body changes elsewhere or runtime claim; existing source preimage pinned. Four leaves and repair require parent independent review and installation. Source implementation may still reject observations/roundtrip/new bid; these are distinguishing RED premises, not measured GREEN.

R2 changes only new-bid downgrade expected message to reviewed observedEstateDowngradeRefusal exact first reason; originalR1 preserved, no execution.

R3 changes exactly live bid amount to Math.max(1,lot.minimumBid), the legal positive minimum for the same fixed first lot. No amount/lot search or engine change. Archived estateClosed predicate is unchanged. R2 preserved; all public eligibility/reserve/admission/purity checks and budgets remain unrun.
