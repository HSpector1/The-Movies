import type { GameState, ScriptDevelopment, ScriptProject } from './types.js'
import type { AbsorptionRecord, AbsorptionScriptCompletion } from './rights.js'
import { allocateRightsId } from './rights.js'
import { allocateScriptReservation, completeDueScriptWork, assertScriptDevelopmentInvariants, assessFirstDraft, scriptRewriteDelta } from './scriptDevelopment.js'
import { buyerOperationsForAllWork, buyerOperatedProductions } from './continuedWork.js'
import { closedWeekOf } from './operatingState.js'
import { SCRIPT_DEVELOPMENT_OFFICE_TIER_2_EST_UPLIFT, SCRIPT_DEVELOPMENT_OFFICE_TIER_3_EST_UPLIFT, FACILITY_BLUEPRINTS } from './tuning.js'
import { developmentOfficeEstUplift } from './facilityEffects.js'

type Owner=Extract<AbsorptionRecord,{producerVersion:'absorption-scripts/v3'}>
function fail(why:string):never{throw new Error(`continued script: ${why}`)}
const exact=(x:object,keys:string[])=>Object.keys(x).sort().join()===keys.sort().join()
function same(a:unknown,b:unknown):boolean{
 if(a===b)return true
 if(a===null||b===null||typeof a!=='object'||typeof b!=='object')return false
 if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>same(v,b[i]))
 const x=a as Record<string,unknown>,y=b as Record<string,unknown>,keys=Object.keys(x).sort()
 return keys.join()===Object.keys(y).sort().join()&&keys.every(k=>same(x[k],y[k]))
}
function owners(state:GameState):Owner[]{
 return (state.rights?.absorptions??[]).filter((a):a is Owner=>a.producerVersion==='absorption-scripts/v3')
}
export function continuedScriptOwner(state:GameState,id:string){
 for(const a of owners(state)){const row=a.continuedScripts.find(r=>r.project.id===id);if(row)return {a,row}}
 return null
}
export function buyerScriptDevelopment(state:GameState):ScriptDevelopment{
 const player=state.hollywood?.playerStudioId
 const projects=owners(state).filter(a=>a.buyerId===player).flatMap(a=>a.continuedScripts.map(r=>r.project))
 return projects.length===0?state.scriptDevelopment:{...state.scriptDevelopment,projects:[...state.scriptDevelopment.projects,...projects]}
}
export function buyerScriptConcepts(state:GameState){
 const ids=new Set(owners(state).filter(a=>a.buyerId===state.hollywood?.playerStudioId).flatMap(a=>a.continuedScripts.map(r=>r.originalScript.conceptId)))
 return [...state.concepts,...(state.hollywood?.concepts??[]).filter(c=>ids.has(c.id)&&!state.concepts.some(own=>own.id===c.id))]
}
/** Bind actual native reservations after production allocation, using the SAME buyer facility pool. */
export function bindContinuedScripts(state:GameState,id:string,occupied:ReadonlySet<string>):GameState{
 let next=state
 const original=owners(state).find(a=>a.id===id)
 if(!original)return state
 if(original.buyerId!==state.hollywood?.playerStudioId)fail('rival buyer drafting producer required')
 for(const originalRow of original.continuedScripts){
  const allocated=allocateRightsId(next.rights,'absorbed-script')
  const boundPool=buyerScriptDevelopment(next)
  const pool={...boundPool,projects:boundPool.projects.filter(p=>!original.continuedScripts.some(r=>r.project.id===p.id&&r.project.id===r.sourceScriptProjectId))}
  const reservation=allocateScriptReservation(buyerOperationsForAllWork(next),pool,allocated.id,occupied)
  if(!reservation)fail('buyer native development capacity unavailable')
  next={...next,rights:{...allocated.root,absorptions:allocated.root.absorptions.map(a=>a.id===id&&a.producerVersion==='absorption-scripts/v3'?{...a,
   continuedScripts:a.continuedScripts.map(r=>r.sourceScriptProjectId===originalRow.sourceScriptProjectId?{...r,reservationAtClose:reservation,
    project:{...r.originalScript,id:allocated.id,reservation}}:r)}:a)}}
 }
 return next
}
/** ONE native script-work pass for own and continued work, in stored order. */
export function advanceBuyerScriptWork(state:GameState,arrivalWeek:number,estUplift:number):{state:GameState;development:ScriptDevelopment}{
 const before=buyerScriptDevelopment(state)
 const foreign=owners(state).filter(a=>a.buyerId===state.hollywood?.playerStudioId).flatMap(a=>a.continuedScripts.map(row=>({a,row})))
 if(foreign.length&&closedWeekOf(state).has(state.hollywood!.playerStudioId))fail('closed buyer cannot advance writing')
 const completed=completeDueScriptWork(before,arrivalWeek,{concepts:buyerScriptConcepts(state),talent:state.talent,estUplift})
 let rights=state.rights
 for(const {a,row} of foreign){
  const project=completed.projects.find(p=>p.id===row.project.id)!
  if(project===row.project)continue
  if((row.project.status!=='drafting'&&row.project.status!=='rewriting')||project.status!=='review'||project.assessment===null)fail('unexpected native script transition')
  if(a.scriptCompletions.some(r=>r.projectId===project.id))fail('completion replay')
  const writer=state.talent.find(t=>t.id===project.writerId)!
  const rewriting=writer.skills.writing.rewriting
  if(row.project.status==='rewriting'&&!rewriting)fail('native rewrite skill context missing')
  const writerRewriting=row.project.status==='rewriting'&&rewriting?{actual:rewriting.actual,perceived:rewriting.perceived}:null
  const allocated=allocateRightsId(rights,'script-completion')
  const receipt:AbsorptionScriptCompletion={id:allocated.id,projectId:project.id,week:arrivalWeek,inputWeek:state.market.tick,estUplift,writerRewriting,assessment:{...project.assessment},developmentContext:{facilities:structuredClone(state.operations.facilities),placements:structuredClone(state.placement.facilities),paidRows:state.ledger.filter(r=>r.kind==='constructionCapex'&&r.week<=state.market.tick&&state.placement.facilities.some(p=>p.projectId===r.constructionProjectId)).map(r=>({projectId:r.constructionProjectId!,week:r.week,amount:r.amount}))}}
  rights={...allocated.root,absorptions:allocated.root.absorptions.map(r=>r.id===a.id&&r.producerVersion==='absorption-scripts/v3'?{...r,
   continuedScripts:r.continuedScripts.map(s=>s.project.id===project.id?{...s,project}:s),scriptCompletions:[...r.scriptCompletions,receipt]}:r)}
 }
 const own=new Set(state.scriptDevelopment.projects.map(p=>p.id))
 return {state:{...state,rights},development:{...state.scriptDevelopment,projects:completed.projects.filter(p=>own.has(p.id))}}
}
/** Exact current owner proof. No caller-supplied ID exemption reaches a save reader. */
export function validateContinuedScripts(state:GameState):void{
 const player=state.hollywood?.playerStudioId
 const current=owners(state)
 const nativeIds=state.scriptDevelopment.projects.map(p=>p.id)
 const seen=new Set(nativeIds)
 for(const a of current){
  if(a.buyerId!==player||!Array.isArray(a.continuedScripts)||a.continuedScripts.length===0||!Array.isArray(a.scriptCompletions))fail('unknown native writing owner')
  const source=state.hollywood!.businesses.find(b=>b.studioId===a.targetId)!
  const still=source.development.projects.filter(p=>p.status==='drafting'||p.status==='rewriting')
  const stopped=new Set(a.stoppedScripts.map(p=>p.scriptProjectId))
  if(!same(a.continuedScripts.map(r=>r.sourceScriptProjectId),still.filter(p=>!stopped.has(p.id)).map(p=>p.id)))fail('source continuation bijection/order differs')
  const expectedReceipts:{projectId:string;week:number}[]=[]
  for(const row of a.continuedScripts){
   if(!exact(row,['sourceScriptProjectId','sourceContractIds','buyerContractIds','originalScript','originalCosts','reservationAtClose','project']))fail('unknown continuation fields')
   const original=source.development.projects.find(p=>p.id===row.sourceScriptProjectId)
   const cost=source.projects.find(p=>p.scriptProjectId===row.sourceScriptProjectId)
   if(!original||!same(original,row.originalScript)||!cost||!same(cost,row.originalCosts)||original.productionId!==null||cost.productionId!==null
    ||original.dueWeek===null||original.dueWeek<=a.week||original.commissionedWeek>a.week||original.reservation===null)fail('original paid creator/script history differs')
   const project=row.project
   if(!/^absorbed-script-[1-9][0-9]*$/.test(project.id)||seen.has(project.id))fail('native work identity collision')
   seen.add(project.id);nativeIds.push(project.id)
   const writers=[...new Set(original.writerIds)]
   const links=writers.map(id=>a.contracts.find(c=>c.talentId===id))
   if(writers.length===0||links.some(c=>!c||c.buyerContractId===null)
    ||!same(row.sourceContractIds,links.map(c=>c!.sourceContractId))||!same(row.buyerContractIds,links.map(c=>c!.buyerContractId)))fail('partial or missing retained writer team')
   for(const link of links){
    const old=state.hollywood!.employment.find(e=>e.contractId===link!.sourceContractId)!
    const kept=state.hollywood!.employment.find(e=>e.contractId===link!.buyerContractId)!
    if(!old||!kept||old.studioId!==a.targetId||old.terms.startWeek>original.commissionedWeek||old.terms.endWeekExclusive<=a.week||old.endedWeek!==a.week
     ||kept.studioId!==a.buyerId||kept.reason!=='absorptionContinuation'||kept.terms.startWeek!==a.week||kept.terms.endWeekExclusive<original.dueWeek
     ||!same(kept.terms,{...old.terms,startWeek:a.week,termWeeks:old.terms.endWeekExclusive-a.week}))fail('original source and actual buyer writing bargain differ')
   }
   const until=Math.min(state.market.tick,closedWeekOf(state).get(a.buyerId)??Infinity)
   const receipts=a.scriptCompletions.filter(r=>r.projectId===project.id)
   const due=original.dueWeek<=until
   if(receipts.length!==(due?1:0))fail('native completion/actual due boundary bijection differs')
   let expected:ScriptProject={...original,id:project.id,reservation:row.reservationAtClose}
   if(due){
    const r=receipts[0]!
    if(!exact(r,['id','projectId','week','inputWeek','estUplift','developmentContext','writerRewriting','assessment'])||!/^script-completion-[1-9][0-9]*$/.test(r.id)
     ||r.week!==original.dueWeek||r.inputWeek!==r.week-1||r.inputWeek<a.week||![0,SCRIPT_DEVELOPMENT_OFFICE_TIER_2_EST_UPLIFT,SCRIPT_DEVELOPMENT_OFFICE_TIER_3_EST_UPLIFT].includes(r.estUplift))fail('completion observation differs')
    const ctx=r.developmentContext
    if(!ctx||!exact(ctx,['facilities','placements','paidRows'])||!Array.isArray(ctx.facilities)||!Array.isArray(ctx.placements)||!Array.isArray(ctx.paidRows))fail('native facility observation missing')
    const placementIds=new Set<number>()
    for(const p of ctx.placements){
     if(!p||!exact(p,['id','blueprintId','parcelId','origin','cells','facilityId','projectId','status','placedWeek','completesWeek','cancellation',...(Object.hasOwn(p,'installation')?['installation']:[])])||placementIds.has(p.id)||!Number.isInteger(p.id)||p.id<1||!FACILITY_BLUEPRINTS.some(b=>b.id===p.blueprintId)
      ||!Number.isInteger(p.placedWeek)||p.placedWeek<0||p.placedWeek>r.inputWeek||!Number.isInteger(p.completesWeek)||p.completesWeek<p.placedWeek
      ||!['operational','underConstruction','cancelled'].includes(p.status)||p.status==='operational'&&p.completesWeek>r.inputWeek
      ||p.status==='underConstruction'&&p.completesWeek<=r.inputWeek)fail('native facility observation timing differs')
     placementIds.add(p.id)
     const retained=state.placement.facilities.find(now=>now.id===p.id)
     if(retained&&(retained.blueprintId!==p.blueprintId||retained.projectId!==p.projectId||retained.facilityId!==p.facilityId||retained.placedWeek!==p.placedWeek||retained.completesWeek!==p.completesWeek||!same(retained.installation,p.installation)))fail('native facility observation source differs')
     const paid=state.ledger.filter(l=>l.kind==='constructionCapex'&&l.constructionProjectId===p.projectId&&l.week===p.placedWeek)
     if(paid.length===0||paid.some(l=>!Number.isFinite(l.amount)||l.amount>=0))fail('native facility observation has no paid source')
    }
    const paidRows=state.ledger.filter(l=>l.kind==='constructionCapex'&&l.week<=r.inputWeek&&ctx.placements.some(p=>p.projectId===l.constructionProjectId)).map(l=>({projectId:l.constructionProjectId!,week:l.week,amount:l.amount}))
    if(!same(ctx.paidRows,paidRows))fail('native facility paid observation differs')
    const facilities=new Set<string>()
    for(const f of ctx.facilities){
     if(!f||!exact(f,['id','name','capability','capacity'])||facilities.has(f.id)||typeof f.id!=='string'||typeof f.name!=='string'||!Number.isInteger(f.capacity)||f.capacity<0||!['development-casting','soundstage','set-scenery','post','laboratory'].includes(f.capability))fail('native facility registry observation differs')
     facilities.add(f.id)
     const retained=state.operations.facilities.find(now=>now.id===f.id)
     if(retained&&retained.capability!==f.capability)fail('native facility registry source differs')
     if(!retained&&!ctx.placements.some(p=>p.facilityId===f.id&&p.status==='operational'))fail('native facility registry observation has no source')
    }
    const observed={...state,operations:{...state.operations,facilities:ctx.facilities},placement:{...state.placement,facilities:ctx.placements}}
    if(r.estUplift!==developmentOfficeEstUplift(observed))fail('native facility assessment effect differs')
    const concept=state.hollywood!.concepts.find(c=>c.id===original.conceptId)!
    let assessment
    if(original.status==='drafting'){
     if(r.writerRewriting!==null)fail('first draft invents rewrite context')
     assessment=assessFirstDraft(concept,r.estUplift)
    }else{
     const profile=r.writerRewriting
     if(!original.assessment||!profile||!exact(profile,['actual','perceived'])||![profile.actual,profile.perceived].every(n=>Number.isFinite(n)&&n>=0&&n<=100))fail('rewrite observation missing')
     const clamp=(n:number)=>Math.max(0,Math.min(100,n))
     assessment={actualStrength:clamp(original.assessment!.actualStrength+scriptRewriteDelta(original.assessment!.actualStrength,profile!.actual)),
      perceivedStrength:clamp(original.assessment!.perceivedStrength+scriptRewriteDelta(original.assessment!.perceivedStrength,profile!.perceived))}
    }
    if(!same(r.assessment,assessment))fail('native earned assessment differs')
    expected={...expected,status:'review',dueWeek:null,reservation:null,assessment}
    expectedReceipts.push({projectId:project.id,week:r.week})
   }
   if(!same(project,expected)||!exact(row.reservationAtClose,['projectId','facilityId','capability','slot'])||row.reservationAtClose.projectId!==project.id)fail('native buyer project differs from original work/earned completion')
  }
  if(!same(a.scriptCompletions.map(r=>r.projectId),expectedReceipts.sort((x,y)=>x.week-y.week).map(r=>r.projectId)))fail('completion receipt order or unknown subject differs')
 }
 if(current.length===0)return
 const closed=closedWeekOf(state).get(player!)
 const productionScripts=new Map<string,ScriptProject>()
 for(const a of state.rights.absorptions.filter(a=>a.buyerId===player)){
  const source=state.hollywood!.businesses.find(b=>b.studioId===a.targetId)!
  for(const row of a.continuedProductions){
   const script=source.development.projects.find(p=>p.productionId===row.productionId&&p.status==='inProduction')
   if(script)productionScripts.set(row.productionId,script)
  }
 }
 assertScriptDevelopmentInvariants(buyerScriptDevelopment(state),{current49ProjectIds:nativeIds,current49ProductionScripts:productionScripts,studioId:player,
  currentWeek:Math.min(state.market.tick,closed??Infinity),concepts:buyerScriptConcepts(state),talent:state.talent,contracts:state.contracts,
  operations:buyerOperationsForAllWork(state),activeProductions:buyerOperatedProductions(state),releasedFilms:state.studio.releasedFilms})
}
