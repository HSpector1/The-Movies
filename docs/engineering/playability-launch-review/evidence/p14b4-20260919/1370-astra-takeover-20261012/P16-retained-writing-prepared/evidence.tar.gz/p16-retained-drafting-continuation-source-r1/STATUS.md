STATIC / UNRUN. Frozen source-only review packet. No installation or acceptance claim. See BRIEF.md.
