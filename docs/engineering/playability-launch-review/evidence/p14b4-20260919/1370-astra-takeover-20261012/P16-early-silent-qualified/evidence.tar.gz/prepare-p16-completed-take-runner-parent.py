from pathlib import Path
import json, hashlib, os, re, subprocess

A = Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K = Path('/Users/zacheryspector/studio-specialists/p16')
draft = A/'p16-completed-take-shooting-runner-r2'
dest = A/'p16-work-release61-integration-runner-r14'
package = A/'p16-completed-take-shooting-integration-r1'
out = A/'p16-work-release61-integration-r14-run'
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
assert not dest.exists() and not out.exists()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(draft/'runner.sh') == 'a142321144bf587c263d8caec72c354206ffd9f6b0d3107b64a5ef26380154b7'
assert sha(draft/'BINDINGS.json') == '0c14ac0f20961ba984ff108bc9c2fa9a39ff8419a314abd97f41b89236f602ab'
assert sha(draft/'SELECTION.json') == '3695889ab92bdbc80db538c51b21fa36eacc8caed9828a10812459bca7f24850'
receipt = json.loads((package/'INSTALL-RECEIPT.json').read_text())
assert receipt['pathCount'] == 192
assert sha(package/'PATCH.diff') == receipt['patchSHA256'] == 'd55e2862b869f9eea6bd1dddfc63415621efae0ac8b894d3d4ef213c2f82c42f'
assert sha(package/'MANIFEST.json') == receipt['manifestSHA256'] == '6ad6248db0589534b748d7aaee13085aac9946e62d2f030fc351dc4d0eb83063'
g = ['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary']) == (package/'PATCH.diff').read_bytes()
script = (draft/'runner.sh').read_text()
old_out = re.search(r'^OUT=(.+)$', script, re.M).group(1)
def relocate(text): return text.replace(str(draft),str(dest)).replace(old_out,str(out))
dest.mkdir()
for name in ['runner.sh','auto_freeze.py','account-results.py','EXPECTED-IDENTITIES.json','SELECTION.json']:
    p = draft/name
    (dest/name).write_text(relocate(p.read_text()))
    os.chmod(dest/name,p.stat().st_mode & 0o777)
b = json.loads(relocate((draft/'BINDINGS.json').read_text()))
b.update(HEAD=subprocess.check_output(g+['rev-parse','HEAD'],text=True).strip(),
         package=str(package),patchSHA256=receipt['patchSHA256'],
         manifestSHA256=receipt['manifestSHA256'],pathCount=receipt['pathCount'],
         installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),
         finalCleanTestAdmission='Parent exact192 source2/test1 pre/post/index installation; independent source KEEP and source-bound test3 KEEP; final runner independent review required before launch')
for p in [package/'INSTALL-RECEIPT.json', A/'P16-UNSHOT-SILENT-PHASES-R13-ACTUAL-REVIEW.md', A/'P16-WORK-RELEASE61-INTEGRATION-R13-PARENT-RESULT.json']:
    b['artifacts'].append({'path':str(p),'sha256':sha(p)})
for row in b['artifacts']:
    assert sha(Path(row['path'])) == row['sha256'], row['path']
assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
expected = json.loads((dest/'EXPECTED-IDENTITIES.json').read_text())
assert len(expected)==1 and len(expected[0]['names'])==3
pins = {p.name:sha(p) for p in sorted(dest.iterdir()) if p.is_file()}
(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(dest/'README.md').write_text('Parent-bound R14: fresh root compiler then complete independent shooting4 file3, unchanged5000ms, actual installed192. All prior failures and budget limits retained. UNRUN until independent final runner review and fresh existing preflight. No native or whole-P16 acceptance.\n')
print(json.dumps({'runner':str(dest),'output':str(out),'pins':pins},indent=2))
