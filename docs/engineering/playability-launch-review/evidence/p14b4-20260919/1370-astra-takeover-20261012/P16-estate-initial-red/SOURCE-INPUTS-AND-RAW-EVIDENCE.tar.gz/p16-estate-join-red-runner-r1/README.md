# Initial P16 estate RED parent runner — UNRUN

Root compiler followed by ONLY complete tests/p16-estate-join.test.ts, five exact names. No UI/Bridge/generators/unrelatedruntime. Expected semantic failures remain child1/overall1; reporter completeness/fullmessages/budgets are independently accounted, malformed98, guard97/98. Passedcounter is notacceptance. Default5s unchanged; overrun writes budgetunqualified and overall1 even reporterPASS.

Parent must install exact reviewedr3test then bind fresh extended candidate K-specific packet/count/actualmodes/patch/manifest in BINDINGS. Pendingfields failclosed; existing four external P16_BOOTSTRAP_{SCRIPT,AUTO_HELPER,SELECTION,BINDINGS}_SHA256 pins required. Candidate WT/index/pathset/HEAD/reverse exact; source/config/index/status/inputs/AUTO strictbeforeafter. Existing lane/Node20.20.2/productionvenv/floors3670016/3145728 unchanged. FreshOUT A/p16-estate-join-red-r1-run only.

Captured pre162/C163 public48 JSON paths+hashes envbound, frozen capturemanifest and original terminal/child/metadata/error/qualification/freeze receipts supply measured actualsource provenance. Normalweek53gzip explicitly frozen; TS helpers/loader code part ofsourcefreeze. No otherfixturepayloaddirectorycrawl. Installedlock/package-lock/TypeScript/Vitest/Vite versions+entrypoints frozen; no wholedependencytreehashclaim. Archived176 notconsumedbyinitial5, remains originalcapture evidence forlaterarchivedmigrationRED.

Rootreuse is deliberately absent because newTSsource requires compiler. New5test draft stillunderindependentreview; runner doesnotauthorizeinstall/launch. Parentindependentreview/binding/oneownedlane alone. No K/R edits/execution or originaltoolchanges.
