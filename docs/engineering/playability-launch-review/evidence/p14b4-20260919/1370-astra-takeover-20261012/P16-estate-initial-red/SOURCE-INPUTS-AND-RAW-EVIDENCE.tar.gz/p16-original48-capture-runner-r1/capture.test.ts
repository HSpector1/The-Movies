// Original48 public producer, not a49 projection or natural campaign acceptance.
import { expect,it } from '/Users/zacheryspector/The-Movies-headless-program/node_modules/vitest/dist/index.js'
import { readFileSync,mkdirSync,writeFileSync,lstatSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { resolve,join } from 'node:path'
import { performance } from 'node:perf_hooks'
import { base,rivalClosure,R04,closureOf } from '/Users/zacheryspector/The-Movies-headless-program/tests/helpers/p15b-live.js'
import { makeSave,validateSaveP15B,exportSave,stableStringify,LIVE_SAVE_VERSION } from '/Users/zacheryspector/The-Movies-headless-program/src/core/save.js'
const R='/Users/zacheryspector/The-Movies-headless-program'
const D='/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012/p16-original48-capture-runner-r1'
const A='/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012'
const sha=(bytes:string|Buffer)=>createHash('sha256').update(bytes).digest('hex')
const git=(...args:string[])=>execFileSync('git',['-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',R,...args],{encoding:'utf8'}).trim()
it('original48 one retained R04 route captures preclosure162, actual163 and archived176 with admitted public bytes',()=>{
 const started=performance.now(),pins=JSON.parse(readFileSync(join(D,'PINS.json'),'utf8'))
 expect(git('rev-parse','HEAD')).toBe(pins.HEAD);expect(git('rev-parse','HEAD:src')).toBe(pins.sourceTree)
 expect(LIVE_SAVE_VERSION).toBe(48)
 for(const [path,hash] of Object.entries(pins.files))expect(sha(readFileSync(join(R,path)))).toBe(hash)
 expect(git('diff','HEAD','--','src','tests/helpers/p15b-live.ts','tests/p14d1-rival-shelving-fixtures.ts','tests/fixtures/p14/genuine-v42-pre-shelving')).toBe('')
 const original=base(),before=stableStringify(original)
 validateSaveP15B(makeSave(original))
 const route=rivalClosure(176)
 expect(stableStringify(original)).toBe(before)
 for(const week of [130,162,163,175,176]){
  const state=route.get(week)!
  expect(state?.market.tick).toBe(week)
  const bytes=stableStringify(state)
  validateSaveP15B(makeSave(state))
  expect(stableStringify(state)).toBe(bytes)
 }
 const prior=route.get(162)!,live=route.get(163)!,archived=route.get(176)!,closure=closureOf(live,R04)!
 expect(closureOf(prior,R04)).toBeUndefined()
 expect(closure).toBeDefined();expect(closure.closureWeek).toBe(163)
 expect(closure.estate).toMatchObject({opensWeek:163,closesWeek:176})
 expect(live.studioClosure.estateEvents.filter(e=>e.closureId===closure.closureId&&e.kind==='archival')).toHaveLength(0)
 const archives=archived.studioClosure.estateEvents.filter(e=>e.closureId===closure.closureId&&e.kind==='archival')
 expect(archives).toHaveLength(1);expect(archives[0]).toMatchObject({week:176,amount:0,reference:closure.closureId,studioId:R04})
 expect(closureOf(archived,R04)).toEqual(closure)
 const results=[{name:'r04-pre162.save48.json',state:prior},{name:'r04-actual163.save48.json',state:live},{name:'r04-archived176.save48.json',state:archived}].map(({name,state})=>{
  const input=stableStringify(state),save=makeSave(state),text=exportSave(save)
  expect(save.saveVersion).toBe(48);expect('rights' in save.state).toBe(false)
  validateSaveP15B(JSON.parse(text));expect(stableStringify(state)).toBe(input)
  return {name,text,sha256:sha(text),bytes:Buffer.byteLength(text),week:state.market.tick}
 })
 // Same5s producer/test budget; synchronous reporterPASS alone cannot qualify an overrun.
 expect(performance.now()-started,'original5s elapsed producer budget').toBeLessThanOrEqual(5000)
 const out=process.env.P16_ORIGINAL48_CAPTURE_OUT
 expect(out,'parent must bind fresh explicitA output').toBeTruthy()
 expect(resolve(out!)).toBe(join(A,'p16-original48-closure-capture-r2-run'))
 mkdirSync(out!,{recursive:false});expect(lstatSync(out!).isSymbolicLink()).toBe(false)
 for(const row of results)writeFileSync(join(out!,row.name),row.text,{flag:'wx'})
 writeFileSync(join(out!,'CAPTURE-MANIFEST.json'),JSON.stringify({source:pins,scope:'disclosed existingdrainedR04 transactionroute; no naturalcampaign acceptance',closureId:closure.closureId,archivalEventId:archives[0]!.eventId,elapsedBeforeWriteMs:performance.now()-started,files:results.map(({text,...row})=>row)},null,2)+'\n',{flag:'wx'})
})
