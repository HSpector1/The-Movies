import json,pathlib,sys,collections
out=pathlib.Path(sys.argv[1]);child=int(sys.argv[2]);expected=json.loads(pathlib.Path(sys.argv[3]).read_text());d=json.loads((out/'results.json').read_text());f=d['testResults'];a=[x for row in f for x in row['assertionResults']]
assert len(f)==1 and f[0]['name'].endswith('/tests/p16-estate-join.test.ts') and len(a)==5
assert sorted(x['fullName'] for x in a)==sorted(expected)
c=collections.Counter(x['status'] for x in a);assert set(c)<={'passed','failed'}
assert d['numTotalTests']==5 and d['numPassedTests']==c['passed'] and d['numFailedTests']==c['failed'] and d['numPendingTests']==d['numTodoTests']==0
assert d['success']==(child==0)==(c['failed']==0)
assert d['numTotalTestSuites']==d['numPassedTestSuites']+d['numFailedTestSuites']+d['numPendingTestSuites']
rows=[{'fullName':x['fullName'],'status':x['status'],'durationMs':x.get('duration'),'budgetQualified':x.get('duration') is not None and x['duration']<=5000,'failureMessages':x.get('failureMessages',[])} for x in a]
(out/'identity-accounting.json').write_text(json.dumps({'childExit':child,'rows':rows,'scope':'initial5estateRED; failure is notacceptance'},indent=2)+'\n')
if any(not r['budgetQualified'] for r in rows):raise SystemExit(3)
