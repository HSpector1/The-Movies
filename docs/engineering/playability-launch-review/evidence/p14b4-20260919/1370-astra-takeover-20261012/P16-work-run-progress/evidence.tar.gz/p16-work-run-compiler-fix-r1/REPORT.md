# Two measured source compiler repairs — UNRUN

Actual167 root compiler failed at absorbedRuns.ts32 TS2322 and historical engagement table7170/7173; preserve raw29949 log. Parent separately owns byte-identical finance-test domain rename correcting171TS5097, not this source patch.

The run owner terminal guard was an inferred const arrow returning never. TypeScript does not use that inferred variable as the declared terminal function needed to narrow the film union. Replace only its declaration with function fail(why):never, preserving the identical thrown error and all proof/refusal behavior. No cast, authored-film allowance or unknown source branch is added.

The exhaustive LedgerKind table drives frozen V5→V6 reconstruction, not modern income or engagement policy. Its existing comment explicitly preserves formerly-falsy lookups for modern P16 rows. Add only absorbedRunRevenue:false, with a matching caption. No tolerant V5 reader, current engagement flag, finance category, cash row or original epoch law changes.

Two actualcurrent167 preimages/full postimages and exact diff are bound. Original R7/R8 drafts remain immutable. No K/R/index/HANDOFF write or compiler/test/runtime occurred. Parent must rebind and rerun three compilers before interpreting the pending runtime groups. R9 coupled real production owner remains independent ongoing A-only work.
