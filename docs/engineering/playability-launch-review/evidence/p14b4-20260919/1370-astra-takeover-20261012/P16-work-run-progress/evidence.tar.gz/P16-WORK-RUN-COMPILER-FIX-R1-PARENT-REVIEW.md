# Parent independent static review — KEEP for qualification

SOURCE9d1a696cc59bf6c077236697444e2495e0f4508c189df4d30d0fb411b0b13686 replaces the never-returning inferred const helper with an explicit function declaration, retaining the exact throw/guard and providing real discriminant narrowing. No authored-film cast or softened owner check. CurrentLedgerKind exhaustiveness adds absorbedRunRevenue:false to frozen V5→V6 classification, preserving prior falsy historical lookup; modern run income classification remains unchanged.

The 170 root TS5097 diagnostics are introduced by the finance test importing real Bridge under the core filename. Existing root explicitly excludes tests/bridge*.test.ts while existing Bridge compiler includes them with allowed TS extensions. Rename wholefile tests/p16-absorption-finance.test.ts to tests/bridge-p16-absorption-finance.test.ts, exact bytes62e2ecd26fa50f5f3e805c3cd6ffa55d091d6e0b3578a67b6b944910e2d69e4a and both test identities unchanged. No config/flag/assertion relaxation. Core Vitest still discovers tests/**/*.test.ts.

Original29949 threecompiler2/no runtime/0 assertions preserved; complete same25-runtime selection plus3compilers remains UNRUN after correction.
