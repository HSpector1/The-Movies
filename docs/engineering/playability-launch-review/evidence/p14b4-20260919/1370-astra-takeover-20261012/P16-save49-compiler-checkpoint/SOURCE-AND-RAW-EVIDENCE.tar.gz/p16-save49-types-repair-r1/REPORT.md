# Six-file compiler composition repair (GPT-6.1 Sol)

UNRUN. Original root compiler2/40s/29diagnostics preserved. No Git/index/HANDOFF or R writes, compiler/tests performed.

The new rights-instrument guard now narrows the actual V45|V49 union with `rights in state`, leaving historical45 comparison legal. Restored exact actual Save48 Args tuple and business helper accidentally removed with the unused P16-only arrow helper; added missing GameState type import; removed only duplicated identical zero-rights-money keys in four expected-value objects.

Modern terminal downward-control now admits the actual current49 envelope, preserves its bytes, and uses existing guarded rightsStripped to obtain a fully validated48 operand before four existing P15B/lower converters. Every original modern official/ended/closure/frozen2040 refusal and whole-operand purity assertion remains; current49 purity is additional. rightsStripped itself proves real public49→48 first refusal for recorded titles and refuses instruments or nonzero rights money. If actual P16 estate instruments prevent this observation, that is an unmet prerequisite, not permission to erase them or weaken validation. All other test bodies/identities/budgets unchanged.

Preimages/ six postimage hashes and exact patch are retained here. Parent must repackage/stage/freeze and compile; no GREEN inferred.

Final same-file semantic completion: the three current49 whole-envelope positive/mutant reader calls now use validateSaveV49. The real validateSaveP15B reference and vi.spyOn private publication fault seam remain unchanged. This prevents current-envelope version refusal from masking the modern end-link/tamper assertions. Final manifest and patch supersede intermediate c63bc9 bytes; original six-file preimages/frozen failed compiler unchanged. No execution.
