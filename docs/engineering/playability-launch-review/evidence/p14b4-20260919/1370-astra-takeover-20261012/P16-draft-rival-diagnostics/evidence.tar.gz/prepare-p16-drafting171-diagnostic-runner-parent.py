from pathlib import Path
import hashlib,json,os,subprocess,re
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r21'
dest=A/'p16-work-release61-integration-runner-r22'
package=A/'p16-healthy-new-drafting171-integration-r1'
tests=A/'p16-healthy-new-drafting171-diagnostic-r1'
out=A/'p16-work-release61-integration-r22-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not dest.exists() and not out.exists()
assert sha(old/'runner.sh')=='8a7f8305d9a1ab124d646e4cf568e01c5b40422873471f3c7d5a6c2c07694977'
assert sha(old/'BINDINGS.json')=='1aacd6faca3cf1afb8067a19049bc73ff92aa9b6b8b8f45aa3bd7bd572f8e066'
previous=json.loads((A/'P16-WORK-RELEASE61-INTEGRATION-R21-PARENT-RESULT.json').read_text())
assert previous['terminal']['overallExit']==0 and previous['counts']=={'passed':3}
assert previous['allBudgetQualified'] and previous['independentFinalFreeze']=='PASS'
receipt=json.loads((package/'INSTALL-RECEIPT.json').read_text());assert receipt['pathCount']==196
assert sha(package/'PATCH.diff')==receipt['patchSHA256'] and sha(package/'MANIFEST.json')==receipt['manifestSHA256']
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary'])==(package/'PATCH.diff').read_bytes()
raw=json.loads((tests/'EXPECTED-IDENTITIES.json').read_text())
assert raw['count']==1 and raw['budgetMs']==5000
assert sha(K/raw['file'])==raw['sourceSHA256']=='a2f78fe0554cd1eed9e096bf3984d968f5f1cecce47d1776c3ed5434baa590a8'
source=(K/raw['file']).read_text();describes=re.findall(r"describe\('([^']+)'",source);leaves=re.findall(r"\bit\('([^']+)'",source)
assert len(describes)==len(leaves)==1 and raw['identities']==[describes[0]+' '+leaves[0]]
names=raw['identities']
expected=[dict(file=raw['file'],sourceSHA256=raw['sourceSHA256'],count=1,names=names,leaves=[dict(fullName=names[0],budgetMs=5000,budgetSource='unchanged core default; all eight ticks and admission inside test')])]
scope='Fresh root and complete fixed actual163 plus eight ordinary ticks171 diagnostic1/default5000ms; require genuinely new drafting commissioned170 before existing capability refusal; no search, invented history, funded closing or feature acceptance'
old_scope=json.loads((old/'BINDINGS.json').read_text())['executionScope']
old_test='tests/p16-initial-shooting5-writeoff.test.ts'
def relocate(s):return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r21-run','p16-work-release61-integration-r22-run').replace(old_test,raw['file'])
script=relocate((old/'runner.sh').read_text()).replace(old_scope,scope).replace('complete initial5 writeoff file3 selection','complete fixed171 diagnostic1 selection')
selection=json.loads(relocate((old/'SELECTION.json').read_text()))
assert selection[0]==['node','node_modules/typescript/bin/tsc','--noEmit'] and selection[-1][10:]==[raw['file']]
dest.mkdir()
(dest/'runner.sh').write_text(script)
(dest/'SELECTION.json').write_text(json.dumps(selection,indent=2)+'\n')
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace(old_scope,scope))
(dest/'EXPECTED-IDENTITIES.json').write_text(json.dumps(expected,indent=2)+'\n')
b=json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),pathCount=196,patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={raw['file']:raw['sourceSHA256']},finalCleanTestAdmission='Selected independent diagnostic R1 exact source and names, fixed163-to171 route, original5s, no premise substitution; final runner review required')
for row in b['artifacts']:
 p=Path(row['path'])
 if p.parent==dest:row['sha256']=sha(p)
 else:assert sha(p)==row['sha256'],str(p)
for p in [package/'INSTALL-RECEIPT.json',tests/'SOURCE.patch',tests/'MANIFEST.json',tests/'EXPECTED-IDENTITIES.json',A/'P16-DRAFTING171-INSTALL-SPEC.json',A/'P16-WORK-RELEASE61-INTEGRATION-R21-PARENT-RESULT.json',A/'P16-INITIAL-SHOOTING5-WRITEOFF-R21-ACTUAL-REVIEW.md',A/'P16-HEALTHY-NEW-DRAFTING171-DIAGNOSTIC-R1-INDEPENDENT-REVIEW.md']:
 b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles']={p.name:sha(p) for p in old.iterdir() if p.is_file()}
assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']:os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(dest/'README.md').write_text(scope+'. UNRUN pending independent final admission and actual preflight. Preserve first absent premise; no alternate date/source search.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins),indent=2))
