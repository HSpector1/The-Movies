from pathlib import Path
import hashlib,json,os,subprocess,re
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r22'
dest=A/'p16-work-release61-integration-runner-r23'
package=A/'p16-drafting171-rival163-diagnostics-integration-r1'
draft=A/'p16-healthy-new-drafting171-diagnostic-r3-concurrent'
rival=A/'p16-rival-buyer-absorption163-baseline-tests-r1'
out=A/'p16-work-release61-integration-r23-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not dest.exists() and not out.exists()
assert sha(old/'runner.sh')=='ab32a06ed8a26afd45ba6447f334a3ca2486a3b35a6a6ec8bf1487e2da7ed47f'
assert sha(old/'BINDINGS.json')=='72d6b09d97c69f99111dd1d25ab1495e4c72e4b85f1359430c323c1fcf122005'
previous=json.loads((A/'P16-WORK-RELEASE61-INTEGRATION-R22-PARENT-RESULT.json').read_text())
assert previous['terminal']['overallExit']==1 and previous['counts']=={'failed':1} and previous['independentFinalFreeze']=='PASS'
assert 'no concurrent production' in previous['failures'][0]['failureMessages'][0]
receipt=json.loads((package/'INSTALL-RECEIPT.json').read_text());assert receipt['pathCount']==197
assert sha(package/'PATCH.diff')==receipt['patchSHA256'] and sha(package/'MANIFEST.json')==receipt['manifestSHA256']
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary'])==(package/'PATCH.diff').read_bytes()
expected=[]
for packet,pin in [(draft,'8a223b43816ae482a492e7183574cf2b2a856f7bdea2c74cadb0c22bfd899da1'),(rival,'65555bf4f49d8f81d7af159f053efdd0c5f88f6b04085e55388636b5ff81c260')]:
 raw=json.loads((packet/'EXPECTED-IDENTITIES.json').read_text())
 assert raw['count']==1 and raw['budgetMs']==5000 and raw['sourceSHA256']==sha(K/raw['file'])==pin
 source=(K/raw['file']).read_text();describes=re.findall(r"describe\('([^']+)'",source);leaves=re.findall(r"\bit\('([^']+)'",source)
 assert len(describes)==len(leaves)==1 and raw['identities']==[describes[0]+' '+leaves[0]]
 names=raw['identities'];expected.append(dict(file=raw['file'],sourceSHA256=pin,count=1,names=names,leaves=[dict(fullName=names[0],budgetMs=5000,budgetSource='unchanged core default; all genuine setup inside test')]))
files=[r['file'] for r in expected]
scope='Fresh root and two complete diagnostic files2/default5000ms: fixed actual163-to171 newdraft plus exact concurrent paidfilm12 and fixed actual163 R02buyer-to-R01target funded explicit nonretention quote before current producer refusals; original R22 failure retained, no search, invented history or feature acceptance'
old_scope=json.loads((old/'BINDINGS.json').read_text())['executionScope']
def relocate(s):return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r22-run','p16-work-release61-integration-r23-run')
selection=json.loads(relocate((old/'SELECTION.json').read_text()));selection[-1]=selection[-1][:10]+files
assert selection[0]==['node','node_modules/typescript/bin/tsc','--noEmit']
script=relocate((old/'runner.sh').read_text()).replace(old_scope,scope)
lines=script.splitlines();positions=[i for i,s in enumerate(lines) if s.startswith('commands=')];assert len(positions)==1
lines[positions[0]]='commands='+repr(selection)
positions=[i for i,s in enumerate(lines) if s.startswith('run estate-red ')];assert len(positions)==1
assert lines[positions[0]].endswith(' '+files[0]);lines[positions[0]]+=' '+files[1]
script='\n'.join(lines)+'\n';script=script.replace('complete fixed171 diagnostic1 selection','complete fixed171 and rival163 diagnostic2 selection')
dest.mkdir();(dest/'runner.sh').write_text(script)
(dest/'SELECTION.json').write_text(json.dumps(selection,indent=2)+'\n')
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace(old_scope,scope))
(dest/'EXPECTED-IDENTITIES.json').write_text(json.dumps(expected,indent=2)+'\n')
b=json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),pathCount=197,patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},finalCleanTestAdmission='Independent exact concurrent171 correction and genuine rival163 baseline KEEP; exact two source identities and original5s; final runner review required')
for row in b['artifacts']:
 p=Path(row['path'])
 if p.parent==dest:row['sha256']=sha(p)
 else:assert sha(p)==row['sha256'],str(p)
for p in [package/'INSTALL-RECEIPT.json',draft/'DELTA.diff',draft/'MANIFEST.json',draft/'EXPECTED-IDENTITIES.json',rival/'SOURCE.patch',rival/'MANIFEST.json',rival/'EXPECTED-IDENTITIES.json',A/'P16-DRAFT171-RIVAL163-INSTALL-SPEC.json',A/'P16-WORK-RELEASE61-INTEGRATION-R22-PARENT-RESULT.json',A/'P16-HEALTHY-NEW-DRAFTING171-R22-ACTUAL-REVIEW.md',A/'P16-R22-PRESTART-GUARD-RECEIPT.json',A/'P16-DRAFTING171-CONCURRENT-R3-INDEPENDENT-REVIEW.md',A/'P16-RIVAL-BUYER-ABSORPTION163-BASELINE-R1-INDEPENDENT-REVIEW.md']:
 b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles']={p.name:sha(p) for p in old.iterdir() if p.is_file()}
assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']:os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(dest/'README.md').write_text(scope+'. UNRUN pending independent final admission and actual preflight. Diagnostic success establishes authentic premises/refusals, not completed acquisition or drafting features.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins),indent=2))
