UNRUN independent completed-knowledge controls. Three new leaves; all setup remains inside default 5s tests. No candidate or runtime edits.

One fixed retained genuine45 baseline280 input is publicly imported/migrated, then ordinarily evaluated at281. Full admission, real stable records, no loans, real paid diligence and public quote/close are mandatory. Its unfinished target sound adoption is retained; r5 refuses it, so r6 is a genuine producer prerequisite. A fresh ordinary decision may introduce another actual prerequisite: fail immediately, never delete work, retime, patch cash or choose a replacement route.

Positive knowledge/access/source-history joins, one ordinary commercial equipment adoption (no inventor advantage), public save/reload, bidirectional omission/source-history mutants and a money-conserved inventor-discount mutant are drafted. The discounted cash-minus-equipment-ledger invariant independently preserves the pre-equipment balance. Existing buyer grant/alreadyHeld is not qualified by this missing-buyer-grant witness. All route affordability/placement/first-throw premises are UNRUN.

Source: frozen r5 technology.ts acquired adoption refusal precedes prototype entitlement validation; equipmentPlan grants inventor price only to research routes. Fixed input hashes are embedded; no fixture payload copied. Intended command: Vitest core complete tests/p16-absorption-knowledge.test.ts, no timeout override or filters, after source/test admission and parent lane scheduling.

Lesson: an earned invention is not a clean-target fixture when its genuine deployment is still pending. Preserve the deployment and require its real disposition producer before claiming knowledge qualification.
