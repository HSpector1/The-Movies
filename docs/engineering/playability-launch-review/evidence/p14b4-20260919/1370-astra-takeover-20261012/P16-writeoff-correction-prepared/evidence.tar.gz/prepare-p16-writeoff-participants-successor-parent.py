from pathlib import Path
import hashlib,json,os,subprocess
A=Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
K=Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r20'
dest=A/'p16-work-release61-integration-runner-r21'
package=A/'p16-initial-shooting5-writeoff-integration-r2'
tests=A/'p16-initial-shooting5-writeoff-tests-r2-participants'
out=A/'p16-work-release61-integration-r21-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not os.path.lexists(A.parent/'HEAVY-LANE-LOCK') and not dest.exists() and not out.exists()
assert sha(old/'runner.sh')=='6557daaaccfa4fd9e7c33beeeece29b4d0d10150aa73e5d072ff21c9ed57586a'
assert sha(old/'BINDINGS.json')=='7d0f8a262c2013b935da35d49d2245de4f4bc3607c02abacafe5b7845f6f2f39'
receipt=json.loads((package/'INSTALL-RECEIPT.json').read_text());assert receipt['pathCount']==195
assert sha(package/'PATCH.diff')==receipt['patchSHA256'] and sha(package/'MANIFEST.json')==receipt['manifestSHA256']
g=['git','-c','gc.auto=0','-c','maintenance.auto=0','--no-optional-locks','-C',str(K)]
assert subprocess.check_output(g+['diff','--cached','--binary'])==(package/'PATCH.diff').read_bytes()
scope='Fresh root and complete initial5 explicit-nonretention writeoff file3/default5000ms after exact writer-director-craft-cast expectation repair; original R20 failed3 retained, no source law change or whole-P16 acceptance'
raw=json.loads((tests/'EXPECTED.json').read_text())
if isinstance(raw,list):
 assert len(raw)==1;raw=raw[0]
prior=json.loads((old/'EXPECTED-IDENTITIES.json').read_text());assert len(prior)==1
source=(K/raw['file']).read_text()
import re
describes=re.findall(r"describe\('([^']+)'",source);assert len(describes)==1
names=[describes[0]+' '+leaf for leaf in raw['testNames']]
assert names==prior[0]['names'] and raw['file']==prior[0]['file']
manifest=json.loads((tests/'MANIFEST.json').read_text())
raw['sourceSHA256']=manifest['postimageSHA256']
assert raw['sourceSHA256']==sha(K/raw['file'])=='f6e73c4b7969fee51d8ffa9895ed431250694be1826004dfb87a341483b7ad56'
assert raw['budgetMs']==5000 and raw['budgetOverride'] is False
assert len(names)==3
expected=[dict(file=raw['file'],sourceSHA256=raw['sourceSHA256'],count=3,names=names,leaves=prior[0]['leaves'])]
assert all(leaf['budgetMs']==5000 for leaf in expected[0]['leaves'])
def relocate(s):return s.replace(str(old),str(dest)).replace('p16-work-release61-integration-r20-run','p16-work-release61-integration-r21-run')
old_scope=json.loads((old/'BINDINGS.json').read_text())['executionScope']
dest.mkdir()
(dest/'runner.sh').write_text(relocate((old/'runner.sh').read_text()).replace(old_scope,scope))
(dest/'SELECTION.json').write_text(relocate((old/'SELECTION.json').read_text()))
(dest/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
(dest/'account-results.py').write_text((old/'account-results.py').read_text().replace(old_scope,scope))
(dest/'EXPECTED-IDENTITIES.json').write_text(json.dumps(expected,indent=2)+'\n')
b=json.loads(relocate((old/'BINDINGS.json').read_text()))
b.update(package=str(package),patchSHA256=receipt['patchSHA256'],manifestSHA256=receipt['manifestSHA256'],installedSourceReceiptSHA256=sha(package/'INSTALL-RECEIPT.json'),scope=scope,executionScope=scope,expectedCompiledTests={raw['file']:raw['sourceSHA256']},finalCleanTestAdmission='Independent exact participant expectation correction KEEP, original R20 preserved; parent exact195-r2 test-only install; complete3 and original budgets unchanged; final runner review required; immutable sidecar describe is stale, exact names derived from actual test describe and original R20 names with updated source hash')
for row in b['artifacts']:
 p=Path(row['path'])
 if p.parent==dest:row['sha256']=sha(p)
 else:assert sha(p)==row['sha256'],str(p)
for p in [package/'INSTALL-RECEIPT.json',tests/'DELTA.diff',tests/'MANIFEST.json',tests/'EXPECTED.json',A/'P16-WRITEOFF-PARTICIPANTS-INSTALL-SPEC.json',A/'P16-WORK-RELEASE61-INTEGRATION-R20-PARENT-RESULT.json',A/'P16-INITIAL-SHOOTING5-WRITEOFF-R20-ACTUAL-REVIEW.md',A/'P16-INITIAL-SHOOTING5-WRITEOFF-PARTICIPANTS-R2-INDEPENDENT-REVIEW.md']:
 b['artifacts'].append(dict(path=str(p),sha256=sha(p)))
b['immediatePredecessorRunnerFiles']={p.name:sha(p) for p in old.iterdir() if p.is_file()}
assert 'PENDING' not in json.dumps(b)
(dest/'BINDINGS.json').write_text(json.dumps(b,indent=2)+'\n')
for name in ['runner.sh','auto_freeze.py','account-results.py']:os.chmod(dest/name,(old/name).stat().st_mode&0o777)
pins={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
(dest/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n');(dest/'README.md').write_text(scope+'. UNRUN pending final independent admission and existing preflight.\n')
print(json.dumps(dict(runner=str(dest),output=str(out),pins=pins),indent=2))
