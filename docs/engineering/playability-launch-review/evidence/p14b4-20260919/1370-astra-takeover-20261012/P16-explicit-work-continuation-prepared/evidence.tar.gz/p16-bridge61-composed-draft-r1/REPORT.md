# Grouped Bridge61 source — UNRUN

Ten sparse paths: seven exact reviewed Bridge producer/readback postimages, the current checkpoint prior-schema registry, and unchanged independent parity7/readback2. Only grouping edits are projection60→61 and registering the exact earned outgoing60 schema from its real generated manifest. The current core Action seam already exists and remains untouched; older whole-file postimages would discard newer work.

No K/R source or index changed, no generated output edited, no tests/compiler executed. The current167 work/run continuation remains the next gate. After it qualifies, install this coherent wire group, generate canonically using the existing tooling under the parent lane, then qualify parser/serialization, full selected tests, historical checkpoint/fixtures, and the real native consumer. New schema identity must come from actual generation. All older failures and acceptance limits remain.
