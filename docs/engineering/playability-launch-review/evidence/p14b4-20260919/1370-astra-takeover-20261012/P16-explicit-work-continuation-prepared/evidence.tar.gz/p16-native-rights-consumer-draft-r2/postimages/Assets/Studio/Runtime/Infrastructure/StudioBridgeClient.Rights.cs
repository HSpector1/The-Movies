using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Studio.Runtime.Data;
using UnityEngine;

namespace Studio.Runtime.Infrastructure
{
    // Prospective canonical61 consumer. No wire shape is guessed or accepted without schema validation.
    public sealed partial class StudioBridgeClient
    {
        private bool rightsOpen, rightsQuoteInFlight, rightsReadInFlight;
        private string rightsSession, rightsDigest, rightsTarget, rightsTargetName, rightsReportId;
        private int rightsRevision = -1, rightsReportsPage;
        private string rightsMessage = "Choose a studio, pay for a scoped report, then price its acquisition.";
        private string rightsConsideration = "0", rightsPendingCommand, rightsPendingReport;
        private StudioIndustryResponse rightsStudios, rightsStudio, rightsReports;
        private StudioBridgeQuoteResponse rightsQuote;
        private readonly HashSet<string> rightsRetention = new(StringComparer.Ordinal);

        private bool RightsReadEnabled => current != null && !terminalConnectionFailure &&
            ConnectionState == StudioBridgeConnectionState.Live && runtimeContinuity.MatchesApplied(current);

        private bool RightsFrameMatches(string session, int revision, string digest) =>
            RightsReadEnabled && String.Equals(current.sessionId, session, StringComparison.Ordinal) &&
            current.stateRevision == revision && String.Equals(current.stateDigest, digest, StringComparison.Ordinal);

        public string RequestPaidDiligenceQuote(StudioDiligenceDraftPayload draft)
        {
            if (!ActionsEnabled || rightsQuoteInFlight || draft == null) return null;
            var id = Guid.NewGuid().ToString("N");
            var json = JsonConvert.SerializeObject(new StudioQuoteDiligenceRequest {
                protocolVersion=StudioBridgeContract.ProtocolVersion, schemaId=StudioBridgeContract.SchemaId,
                sessionId=current.sessionId, commandId=id, expectedStateRevision=current.stateRevision,
                draft=draft
            }, Formatting.None, StudioBridgeContract.CreateStrictJsonSettings());
            StartCoroutine(PostRightsQuote(json,id,"requestDueDiligence",current.sessionId,current.stateRevision,current.stateDigest));
            return id;
        }

        public string RequestHealthyAbsorptionQuote(StudioAbsorptionDraftPayload draft)
        {
            if (!ActionsEnabled || rightsQuoteInFlight || draft == null) return null;
            var id = Guid.NewGuid().ToString("N");
            var json = JsonConvert.SerializeObject(new StudioQuoteAbsorptionRequest {
                protocolVersion=StudioBridgeContract.ProtocolVersion, schemaId=StudioBridgeContract.SchemaId,
                sessionId=current.sessionId, commandId=id, expectedStateRevision=current.stateRevision,
                draft=draft
            }, Formatting.None, StudioBridgeContract.CreateStrictJsonSettings());
            StartCoroutine(PostRightsQuote(json,id,"absorbStudio",current.sessionId,current.stateRevision,current.stateDigest));
            return id;
        }

        private IEnumerator PostRightsQuote(string json,string id,string kind,string session,int revision,string digest)
        {
            rightsQuoteInFlight=true;rightsQuote=null;
            try {
                using var request=transport.PostUtf8("/quote",Encoding.UTF8.GetBytes(json));
                yield return request.SendWebRequest();
                if(IsTerminalBoundaryFailure(request)){HandleTransportFailure(request,"business quote");yield break;}
                if(IsAmbiguousPostFailure(request)){rightsMessage="The preview was not resolved. Refresh and request it again; no purchase was confirmed.";yield break;}
                if(!RightsFrameMatches(session,revision,digest)){rightsMessage="The studio changed. Request a new quote.";yield break;}
                if(request.responseCode<200 || request.responseCode>=300) {
                    StudioBridgeRejectedResponse rejected;
                    try {rejected=StudioBridgeJson.ParseRejectedResponse(request.downloadHandler?.text);}
                    catch(StudioSnapshotFormatException error){SetProtocolMismatch(error.Message);yield break;}
                    if(rejected.commandId==id && rejected.sessionId==session)rightsMessage=rejected.message;
                    yield break;
                }
                StudioBridgeQuoteResponse response;
                try {
                    // Existing old commission/casting normalizer is not a fallback for a rights DTO.
                    response=StudioBridgeWireValidator.Parse<StudioBridgeQuoteResponse>(request.downloadHandler?.text,"StudioBridgeQuoteResponse",false);
                    if(response.commandId!=id || response.sessionId!=session || response.stateRevision!=revision || response.stateDigest!=digest || RightsQuoteKind(response.quote)!=kind)
                        throw new StudioSnapshotFormatException("Business quote does not belong to this exact request and studio state.");
                    if(kind=="requestDueDiligence" && !(response.quote is StudioDiligenceQuoteSnapshot) || kind=="absorbStudio" && !(response.quote is StudioAbsorptionQuoteSnapshot))
                        throw new StudioSnapshotFormatException("Business quote has the wrong canonical member.");
                } catch(StudioSnapshotFormatException error){SetProtocolMismatch(error.Message);yield break;}
                rightsQuote=response;rightsMessage="Review the dated terms before committing.";
            } finally {rightsQuoteInFlight=false;}
        }

        public string RequestPaidReports(string reportId=null,int page=0) => RequestRightsIndustry("diligence",reportId,page);

        private string RequestRightsIndustry(string view,string target,int page=0)
        {
            if(!RightsReadEnabled || rightsReadInFlight)return null;
            var id=Guid.NewGuid().ToString("N");
            var session=current.sessionId;var revision=current.stateRevision;var digest=current.stateDigest;
            var json=JsonConvert.SerializeObject(new StudioIndustryRequest {
                protocolVersion=StudioBridgeContract.ProtocolVersion,schemaId=StudioBridgeContract.SchemaId,
                sessionId=session,requestId=id,expectedStateRevision=revision,type="industryQuery",view=view,targetId=target,
                page=page,pageSize=50,lane="audienceAwareness",period="all",historyPage=0
            },Formatting.None,StudioBridgeContract.CreateStrictJsonSettings());
            StartCoroutine(PostRightsIndustry(json,id,view,target,page,session,revision,digest));return id;
        }

        private IEnumerator PostRightsIndustry(string json,string id,string view,string target,int page,string session,int revision,string digest)
        {
            rightsReadInFlight=true;
            try {
                using var request=transport.PostUtf8("/industry",Encoding.UTF8.GetBytes(json));
                yield return request.SendWebRequest();
                if(IsTerminalBoundaryFailure(request)){HandleTransportFailure(request,"paid report");yield break;}
                if(IsAmbiguousPostFailure(request)){rightsMessage="The report read was not resolved. Refresh it; no payment was made by this read.";yield break;}
                if(!RightsFrameMatches(session,revision,digest)){rightsMessage="The studio changed. Refresh the report.";yield break;}
                if(request.responseCode<200 || request.responseCode>=300) {
                    StudioBridgeRejectedResponse rejected;
                    try {rejected=StudioBridgeJson.ParseRejectedResponse(request.downloadHandler?.text);}
                    catch(StudioSnapshotFormatException error){SetProtocolMismatch(error.Message);yield break;}
                    rightsMessage=rejected.message;yield break;
                }
                StudioIndustryResponse response;
                try {
                    response=StudioBridgeWireValidator.Parse<StudioIndustryResponse>(request.downloadHandler?.text,"StudioIndustryResponse",true);
                    if(response.requestId!=id || response.sessionId!=session || response.stateRevision!=revision || response.stateDigest!=digest || response.view!=view || response.targetId!=target || response.page!=page)
                        throw new StudioSnapshotFormatException("Paid report response does not match this exact read.");
                    if(view=="diligence" && response.diligence==null)throw new StudioSnapshotFormatException("Current paid-report page is missing.");
                } catch(StudioSnapshotFormatException error){SetProtocolMismatch(error.Message);yield break;}
                if(view=="studios")rightsStudios=response;
                else if(view=="studio")rightsStudio=response;
                else {rightsReports=response;rightsReportsPage=page;rightsReportId=response.diligence.selectedReport?.receipt.id;}
            } finally {rightsReadInFlight=false;}
        }

        private static string RightsQuoteKind(StudioQuoteSnapshot quote)
        {
            if(quote is StudioDiligenceQuoteSnapshot paid)return paid.kind;
            if(quote is StudioAbsorptionQuoteSnapshot absorption)return absorption.kind;
            throw new StudioSnapshotFormatException("Unrecognized canonical rights quote member.");
        }

        private string RightsPersonName(string id) => rightsStudio?.people?.FirstOrDefault(p=>p.talentId==id)?.name ?? "Employment bargain";
        private string RightsFilmTitle(string id) => rightsStudio?.films?.FirstOrDefault(f=>f.filmId==id)?.title ?? "Film right";
        private static string RightsMoney(double amount) => amount.ToString("C2",CultureInfo.CurrentCulture);

        private void MaintainRightsFrame()
        {
            if(current==null)return;
            // Completion can arrive after SnapshotApplied on an otherwise unchanged frame.
            // Check actual scoped receipt every render, not only on a revision transition.
            var completed=false;
            if(rightsPendingCommand!=null && !PendingPost) {
                var accepted=LastPlayerWorkflowAccepted;
                if(accepted.HasValue && accepted.Value.CommandId==rightsPendingCommand && accepted.Value.SessionId==current.sessionId) {
                    rightsReportId=rightsPendingReport;
                    rightsMessage="The authority confirmed the transaction. Read its current record.";
                } else rightsMessage="No confirmed receipt for this request. Refresh the current record before trying again.";
                rightsPendingCommand=null;rightsPendingReport=null;completed=true;
            }
            if(rightsSession==current.sessionId && rightsRevision==current.stateRevision && rightsDigest==current.stateDigest)return;
            rightsSession=current.sessionId;rightsRevision=current.stateRevision;rightsDigest=current.stateDigest;
            rightsQuote=null;rightsReports=null;rightsStudio=null;rightsStudios=null;rightsRetention.Clear();
            if(!completed)rightsMessage="The studio changed. Refresh the report and quote before a new commitment.";
        }

        private void DrawRightsPanel()
        {
            MaintainRightsFrame();
            if(GUILayout.Button(rightsOpen?"Close business transactions":"Paid reports and studio acquisition",workflowButtonStyle))rightsOpen=!rightsOpen;
            if(!rightsOpen)return;
            GUILayout.Label("PAID REPORTS AND STUDIO ACQUISITION",headlineStyle);
            GUILayout.Label(rightsMessage,bodyStyle);
            var enabled=GUI.enabled;
            GUI.enabled=enabled && RightsReadEnabled && !rightsReadInFlight;
            if(GUILayout.Button("Refresh available studios",workflowButtonStyle))RequestRightsIndustry("studios",null);
            if(rightsStudios!=null)foreach(var studio in rightsStudios.studios.Where(s=>!s.player)) {
                if(GUILayout.Button(studio.name,workflowButtonStyle)) {
                    rightsTarget=studio.studioId;rightsTargetName=studio.name;rightsReportId=null;rightsQuote=null;rightsRetention.Clear();
                    RequestRightsIndustry("studio",rightsTarget);
                }
            }
            if(GUILayout.Button("Read my paid reports",workflowButtonStyle))RequestPaidReports(rightsReportId,rightsReportsPage);
            if(rightsReports!=null) {
                GUILayout.Label($"Reports: {rightsReports.totalRows} · Page {rightsReports.page+1} of {Math.Max(1,rightsReports.pageCount)}",mutedStyle);
                foreach(var report in rightsReports.diligence.receipts)if(GUILayout.Button($"{report.targetLabel} · Week {report.week} · {RightsMoney(report.fee)}",workflowButtonStyle))RequestPaidReports(report.id,rightsReports.page);
                if(rightsReports.page>0 && GUILayout.Button("Previous report page",workflowButtonStyle))RequestPaidReports(rightsReportId,rightsReports.page-1);
                if(rightsReports.page+1<rightsReports.pageCount && GUILayout.Button("Next report page",workflowButtonStyle))RequestPaidReports(rightsReportId,rightsReports.page+1);
            }
            GUI.enabled=enabled;
            var detail=rightsReports?.diligence?.selectedReport;
            if(detail!=null) {
                GUILayout.Label(detail.receipt.targetLabel+" · paid report",headlineStyle);
                GUILayout.Label(detail.receipt.freshnessLine,bodyStyle);
                foreach(var right in detail.body.rights) {
                    var name=right.subject is StudioPaidReportFilm film?RightsFilmTitle(film.filmId):"Story right";
                    GUILayout.Label(name+" · "+(right.value.HasValue?RightsMoney(right.value.Value):"Value not recorded")+$" · {right.encumbrances.Length} encumbrances",bodyStyle);
                }
                if(detail.body.liabilities!=null)GUILayout.Label($"Disclosed cash {RightsMoney(detail.body.liabilities.cash)} · weekly fixed cost {RightsMoney(detail.body.liabilities.weeklyFixedCost)} · "+(detail.body.liabilities.hasOutstandingLoan?"outstanding loan":"no outstanding loan"),bodyStyle);
                if(detail.body.employment!=null)foreach(var contract in detail.body.employment) {
                    var was=rightsRetention.Contains(contract.contractId);
                    var keep=GUILayout.Toggle(was,$"Keep {RightsPersonName(contract.talentId)} · annual salary {RightsMoney(contract.annualSalary)} · current exit charge {RightsMoney(contract.exitCost)}");
                    if(keep!=was){if(keep)rightsRetention.Add(contract.contractId);else rightsRetention.Remove(contract.contractId);rightsQuote=null;}
                }
            }
            GUI.enabled=enabled && ActionsEnabled && !rightsQuoteInFlight && !rightsReadInFlight;
            if(rightsTarget!=null) {
                GUILayout.Label(rightsTargetName,headlineStyle);
                if(GUILayout.Button("Preview the full paid report fee",workflowButtonStyle))RequestPaidDiligenceQuote(new StudioDiligenceDraftPayload {
                    target=new StudioDiligenceStudioTarget {studioId=rightsTarget},scope=new[]{"rights","employment","liabilities"}
                });
                GUILayout.Label("Purchase consideration",bodyStyle);
                var text=GUILayout.TextField(rightsConsideration);if(text!=rightsConsideration){rightsConsideration=text;rightsQuote=null;}
                var matching=detail?.receipt.target is StudioPaidReportStudioTarget st && st.studioId==rightsTarget && detail.receipt.fresh;
                GUI.enabled=GUI.enabled && matching;
                if(GUILayout.Button("Quote acquisition from this paid report",workflowButtonStyle)) {
                    if(double.TryParse(rightsConsideration,NumberStyles.Number,CultureInfo.CurrentCulture,out var amount))RequestHealthyAbsorptionQuote(new StudioAbsorptionDraftPayload {
                        targetId=rightsTarget,consideration=amount,disclosureId=detail.receipt.id,
                        retention=new StudioAbsorptionExplicitRetention {contractIds=rightsRetention.ToArray()}
                    });else rightsMessage="Enter a purchase consideration amount.";
                }
            }
            GUI.enabled=enabled;
            if(rightsQuote!=null && RightsFrameMatches(rightsQuote.sessionId,rightsQuote.stateRevision,rightsQuote.stateDigest)) {
                bool legal;string pendingReport=null;
                if(rightsQuote.quote is StudioDiligenceQuoteSnapshot paid) {
                    legal=paid.ok;pendingReport=paid.disclosureId;
                    GUILayout.Label("Report fee: "+RightsMoney(paid.fee),headlineStyle);
                    GUILayout.Label("Preview has paid nothing and holds no report. Confirm to pay once.",bodyStyle);
                    if(!legal)GUILayout.Label(paid.refusalReason,bodyStyle);
                } else if(rightsQuote.quote is StudioAbsorptionQuoteSnapshot absorption) {
                    legal=absorption.ok;
                    if(absorption.terms!=null) {
                        var terms=absorption.terms;
                        GUILayout.Label($"Consideration {RightsMoney(terms.consideration)} · capped target exits {RightsMoney(terms.exitCharges)}",bodyStyle);
                        GUILayout.Label($"Target cash after exits {RightsMoney(terms.postExitCash)} · net cash outlay {RightsMoney(terms.outlay)}",bodyStyle);
                        GUILayout.Label($"Remaining salary guarantees {RightsMoney(terms.guarantees)} · post-deal reserve {RightsMoney(terms.reserveAfter)}",bodyStyle);
                        GUILayout.Label($"Keep {terms.retainedContracts.Length} bargains · end {terms.exitedContracts.Length} · transfer {terms.rightsCount} rights",bodyStyle);
                    }
                    if(!legal)GUILayout.Label(absorption.refusalReason,bodyStyle);
                } else {SetProtocolMismatch("Unrecognized current business quote member.");GUI.enabled=enabled;return;}
                GUI.enabled=enabled && legal && ActionsEnabled && !rightsQuoteInFlight && !rightsReadInFlight;
                if(PlayerWorkflowButton(rightsQuote.quote.commitLabel,workflowButtonStyle,out var rectangle)) {
                    var option=new StudioBridgeIntentOption {intentId=rightsQuote.quote.intentId,kind=RightsQuoteKind(rightsQuote.quote),label=rightsQuote.quote.commitLabel,detail=string.Empty,projectId=null,castingSessionId=null,productionId=null};
                    if(SubmitPlayerWorkflowIntent(option,rectangle)) {
                        rightsPendingCommand=LastPlayerWorkflowAttempt?.CommandId;rightsPendingReport=pendingReport;
                        rightsQuote=null;rightsMessage="Awaiting the authority’s durable receipt; do not repeat this commitment.";
                    }
                }
            }
            GUI.enabled=enabled;
        }
    }
}
