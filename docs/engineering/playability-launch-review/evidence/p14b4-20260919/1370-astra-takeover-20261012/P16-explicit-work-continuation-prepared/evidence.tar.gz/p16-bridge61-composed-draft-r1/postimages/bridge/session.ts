import { diligenceDraftCopy, absorptionDraftCopy, diligenceDraftApply, absorptionDraftApply, diligenceQuoteSnapshot, absorptionQuoteSnapshot } from './rights.ts'
import { QUOTE_AGE_POLICY_VERSION } from '../src/core/quoteAge.js'
import { loanQuoteSnapshot, loanDraftApply } from './loan.ts'
import { createHash, randomUUID } from 'node:crypto'
import { performance } from 'node:perf_hooks'

import {
  acknowledgeCastingSessionAction,
  advanceWeek,
  castingSessionsBoard,
  commissionScriptAction,
  financeCard,
  findConcept,
  findTalent,
  foundManagedStudioAction,
  foundingApplicantCards,
  foundingApplicantRows,
  foundingBudgetRemaining,
  foundingProgress,
  foundingRunwayPreview,
  greenlightScriptProject,
  newGame,
  nextIncompleteProfession,
  offerObligation,
  payrollSummary,
  requiredNegative,
  runProductionCommand,
  runScriptProjectAction,
  scriptProjectsBoard,
  signContractAction,
  startCastingSessionAction,
  productionBoard,
  startDevelopmentCastingAnnexAction,
  studioDecision,
  studioDevelopment,
  studioPool,
} from '../ui/src/engine/adapter.ts'
import type {
  ActionOutcome,
  DraftPackage,
  FoundingApplicantRow,
  GameState,
} from '../ui/src/engine/adapter.ts'
import { applyActions, importSave, LIVE_SAVE_VERSION, migrateToLive } from '../src/core/index.js'
import { studioRemedies } from '../src/core/corporateConditionLive.js'
import { isOperatingStudio } from '../src/core/studioClosure.js'
import { studioWeeklyFixedCost } from '../src/core/powerRankingArchive.js'
import { contractLoan, loanMaxPrincipal } from '../src/core/studioLoan.js'
import type { FoundingRegime } from '../src/core/index.js'
import {
  PROTOCOL_VERSION,
  SCHEMA_ID,
  SNAPSHOT_VERSION,
  type AvailableIntent,
  type ControlEnvelope,
  type Rejection,
  type RejectionCode,
  type SubmitIntentCommand,
} from './protocol.ts'
import {
  BridgeRuntimeCheckpointCapacityError,
  BridgeRuntimeCheckpointHistoryFullError,
  createEncodedBridgeRuntimeCheckpoint,
  DEFAULT_BRIDGE_RUNTIME_CHECKPOINT_LIMITS,
  type BridgeRuntimeCheckpointLimits,
  type BridgeRuntimeCheckpointV1,
  type EncodedBridgeRuntimeCheckpoint,
  type BridgeRuntimeJournalEntryV1,
  type BridgeRuntimeJournalRoute,
  type HydratedBridgeRuntimeCheckpoint,
  type HydratedBridgeRuntimeJournalEntry,
} from './runtime-checkpoint.ts'
import { canonicalJson } from './schema/canonical.ts'
import { snapshotBuildContextFor } from './snapshot-build-context.ts'
import {industryPage} from './industry.ts'
import {isCancellationAction} from './cancellation.ts'
import {laboratoryActionSpecs,type LaboratoryIntent} from './laboratory.ts'
import {isPhysicalPlanAction,planActionSpecs,type PlanIntent} from './plans.ts'
import {applyOfficeAction,officeActionSpecs,type OfficeIntent} from './office.ts'
import {setupRecipeActionSpecs,withProductionSetupRows,type ProductionSetupIntent} from './productionSetup.ts'
import {sameNativeCampaignOrigin} from './campaign-origin.ts'
import type {IndustryQuery} from './schema/industry-schema.ts'
import type {
  BridgeAcceptedCommandResponse,
  BridgeAcceptedSaveResponse,
  BridgeCastingDraftPayload,
  BridgeCastingQuoteSnapshot,
  BridgeCommissionDraftPayload,
  BridgeCommissionQuoteSnapshot,
  BridgeFoundingArrivalSnapshot,
  BridgeFoundingSnapshot,
  BridgeQuoteCastingRequest,
  BridgeQuoteCommissionRequest,
  BridgeQuoteRequest,
  BridgeQuoteResponse,
  BridgeRejectedResponse,
  BridgeSnapshotEnvelope,
  BridgeTreasurySnapshot,
  BridgePlacementDraftPayload,
  BridgeQuotePlacementRequest,
  BridgePlacementQuoteSnapshot,
  BridgeSetCommissionDraftPayload,
  BridgeQuoteSetCommissionRequest,
  BridgeSetCommissionQuoteSnapshot,
  BridgeDiligenceDraftPayload, BridgeQuoteDiligenceRequest, BridgeDiligenceQuoteSnapshot,
  BridgeAbsorptionDraftPayload, BridgeQuoteAbsorptionRequest, BridgeAbsorptionQuoteSnapshot,
  BridgeLoanDraftPayload,
  BridgeQuoteLoanRequest,
  BridgeLoanQuoteSnapshot,
  BridgeContractDraftPayload,
  BridgeQuoteContractRequest,
  BridgeContractQuoteSnapshot,
  BridgeMarketProposalDraftPayload,
  BridgeQuoteMarketProposalRequest,
  BridgeMarketProposalQuoteSnapshot,
  BridgePromiseWaiverDraftPayload,
  BridgeQuoteWaivePromiseRequest,
  BridgePromiseWaiverQuoteSnapshot,
} from './schema/bridge-schema.ts'
import { projectStudioProjectionBundle } from './schema/runtime.ts'
import {
  commissionQuoteSnapshot,
  draftToEngine,
} from './development.ts'
import { castingDraftToEngine, castingQuoteSnapshot } from './casting.ts'
import { placementDraftToEngine, placementQuoteSnapshot } from './placement.ts'
import { setCommissionDraftToEngine, setCommissionQuoteSnapshot } from './setCommission.ts'
import {
  contractDraftToEngine, contractQuoteSnapshot,
  marketProposalDraftToEngine, marketProposalQuoteSnapshot, playerProposalDraft,
} from './contract.ts'
import { promiseWaiverDraftToEngine, promiseWaiverQuoteSnapshot } from './promises.ts'

type ImportOutcome =
  | { ok: true; state: GameState; converted: boolean }
  | { ok: false; error: string }

// P06A (charter W1): the bridge's live-boundary save import, routed to the
// live V16 migrator — every pre-P06 envelope (including every Release Ready
// picture in it) arrives EXPLICITLY uncommitted. Same `ImportOutcome` shape
// and semantics as every prior live wrapper.
// P08A: the live save version is V17; every prior version live-migrates through
// the canonical chain (the same two-step the ui adapter's importSaveJson mirrors).
// P13B-S5-R07-T3: `converted` means "this envelope was NOT already the live
// version", so it compares against `LIVE_SAVE_VERSION` — the constant beside
// `makeSave` — instead of a literal (23) that went stale at V24 and V25 and made
// every genuine current checkpoint report itself as a migration.
function importSaveJsonCurrent(json: string): ImportOutcome {
  try {
    const save = importSave(json)
    const converted = save.saveVersion !== LIVE_SAVE_VERSION
    return { ok: true, state: migrateToLive(save).state, converted }
  } catch (error) {
    return { ok: false, error: (error as Error).message }
  }
}

type IntentApplication = {
  option: AvailableIntent
  apply: (state: GameState) => ActionOutcome
}

export type SnapshotMetrics = BridgeSnapshotEnvelope['metrics']
export type SnapshotEnvelope = BridgeSnapshotEnvelope
type SavedSlotMetadata = NonNullable<SnapshotEnvelope['savedSlot']>
export type AcceptedCommandResponse = BridgeAcceptedCommandResponse
export type RejectedResponse = BridgeRejectedResponse

export type CommandResponse = AcceptedCommandResponse | RejectedResponse

export type AcceptedSaveResponse = BridgeAcceptedSaveResponse

export type SaveResponse = AcceptedSaveResponse | RejectedResponse
type CachedResponse = CommandResponse | SaveResponse

// Exists only on the stack of one synchronous dispatch. No public callback,
// cross-call cache or escaped parsed state can populate or reuse this handoff.
type RuntimeCheckpointPreparation = {
  limits: BridgeRuntimeCheckpointLimits
  result?: { state: GameState; prepared: EncodedBridgeRuntimeCheckpoint }
}

export type AcceptedQuoteResponse = BridgeQuoteResponse
export type QuoteResponse = AcceptedQuoteResponse | RejectedResponse
/** The accepted quote envelope, narrowed to exactly one family's `quote` payload. */
export type AcceptedQuoteResponseFor<TQuote> = Omit<BridgeQuoteResponse, 'quote'> & { quote: TQuote }

/**
 * One minted quote: valid for exactly the state that quoted it. A single
 * cap-16 map shared by both families — `quotedIntentFor()`/clear-on-command/
 * clear-on-load stay generic over intentId regardless of which family minted it.
 */
type PendingQuote =
  | { family:'diligence'; draft:BridgeDiligenceDraftPayload; stateDigest:string; kind:'requestDueDiligence'; commitLabel:string }
  | { family:'absorption'; draft:BridgeAbsorptionDraftPayload; quotedAtWeek:number; quoteAgePolicyVersion:typeof QUOTE_AGE_POLICY_VERSION; stateDigest:string; kind:'absorbStudio'; commitLabel:string }
  | { family: 'loan'; draft: BridgeLoanDraftPayload; stateDigest: string; kind: 'takeLoan'; commitLabel: string }
  | {
      family: 'commission'
      draft: BridgeCommissionDraftPayload
      stateDigest: string
      kind: 'commissionScreenplay' | 'commissionOriginalScreenplay'
      commitLabel: string
    }
  | {
      family: 'casting'
      draft: BridgeCastingDraftPayload
      stateDigest: string
      kind: 'startAuditions' | 'greenlightPicture' | 'signContract'
      commitLabel: string
    }
  | {
      // P09 §18: a LEGAL placement preview mints the one construction commit.
      family: 'placement'
      draft: BridgePlacementDraftPayload
      stateDigest: string
      kind: 'placeFacility'
      commitLabel: string
    }
  | {
      // P09A W5: a LEGAL Set preview mints the one Set commission commit.
      family: 'setCommission'
      draft: BridgeSetCommissionDraftPayload
      stateDigest: string
      kind: 'commissionSet'
      commitLabel: string
    }
  | {
      // P10-R1: a LEGAL contract preview (renewal / early release) mints the one commit.
      family: 'contract'
      draft: BridgeContractDraftPayload
      stateDigest: string
      kind: 'renewContract' | 'releaseTalent'
      commitLabel: string
    }
  | {
      // P14A.1: a LEGAL market-proposal preview (propose/revise/withdraw) mints the one commit.
      family: 'marketProposal'
      draft: BridgeMarketProposalDraftPayload
      stateDigest: string
      kind: 'marketProposalAction'
      commitLabel: string
    }
  | {
      // P14B.8: a LEGAL waiver preview mints the one waiver commit. The family
      // discriminant is INTERNAL and deliberately differs from the wire intent kind,
      // exactly as `marketProposal` differs from `marketProposalAction`.
      family: 'promiseWaiver'
      draft: BridgePromiseWaiverDraftPayload
      stateDigest: string
      kind: 'waivePromise'
      commitLabel: string
    }

type RuntimeEntry = {
  entry: BridgeRuntimeJournalEntryV1
}

type BridgeSessionRuntimeState = {
  revision: number
  journal: readonly HydratedBridgeRuntimeJournalEntry[]
  limits: BridgeRuntimeCheckpointLimits
}

export type PlayedIntent = {
  option: AvailableIntent
  beforeWeek: number
  afterWeek: number
  beforeDigest: string
  afterDigest: string
}

type JourneyIntentContext = {
  next: { kind: string } | null
  scriptProjectId: string | null
  productionId: string | null
}

/** Follow the authoritative journey while other legal concurrent choices remain visible. */
export function selectJourneyIntent(
  candidates: readonly AvailableIntent[],
  journey: JourneyIntentContext | null | undefined,
): AvailableIntent | undefined {
  if (journey?.next === null || journey?.next === undefined) return undefined
  const project = (kind: AvailableIntent['kind']) => candidates.find(
    (candidate) => candidate.kind === kind && candidate.projectId === journey.scriptProjectId,
  )
  switch (journey.next.kind) {
    case 'commission':
      return candidates.find((candidate) => candidate.kind === 'commissionScreenplay')
    case 'advance-week':
      return candidates.find((candidate) => candidate.kind === 'advanceWeek')
    case 'script-review':
      return project('acceptScreenplay') ?? project('requestRewrite')
    case 'plan-auditions':
      return project('startAuditions')
    case 'audition-review':
      return project('acknowledgeAuditions')
    case 'open-package':
      return project('greenlightPicture')
    case 'resolve-production':
      return candidates.find(
        (candidate) =>
          candidate.kind === 'resolveProductionBlocker' &&
          candidate.productionId === journey.productionId,
      )
    // P06A W2: the journey's release-review step selects the EXACT-ID commit
    // intent — the same exact-id discipline resolve-production already keeps.
    case 'release-review':
      return candidates.find(
        (candidate) =>
          candidate.kind === 'commitPictureToRelease' &&
          candidate.productionId === journey.productionId,
      )
    default:
      return undefined
  }
}

function requireSuccess(outcome: ActionOutcome, operation: string): GameState {
  if (!outcome.ok) throw new Error(`${operation}: ${outcome.error}`)
  return outcome.next
}

/** A real player founding path: public applicant cards, offers, and managed founding action. */
export function createManagedBridgeState(seed = 'current-game-unity-adoption-v2'): GameState {
  let state = newGame(seed)
  for (let guard = 0; guard < 64; guard++) {
    const role = nextIncompleteProfession(state)
    if (role === null) break
    const card = foundingApplicantCards(state).find(
      (candidate) => candidate.profile.role === role &&
        !state.contracts.some((contract) => contract.talentId === candidate.profile.id),
    )
    if (card === undefined) throw new Error(`Bridge founding has no available ${role} applicant.`)
    const offer = [...card.employment.offerOptions].sort((a, b) => b.termWeeks - a.termWeeks)[0]
    if (offer === undefined) throw new Error(`Bridge founding applicant ${card.profile.id} has no legal offer.`)
    state = requireSuccess(
      signContractAction(state, card.profile.id, offer.termWeeks),
      `sign ${card.profile.id}`,
    )
  }
  if (nextIncompleteProfession(state) !== null) throw new Error('Bridge founding did not reach required coverage.')

  // The gate's two-picture proof crosses a freelancer-market refresh between Movie #2's
  // camera tests and package.  Found one additional Actor through the same public offer
  // action so all three named roles remain genuinely contract-backed; the bridge still
  // asks the engine to validate the offer and later re-reads availability before greenlight.
  const additionalActor = foundingApplicantCards(state).find(
    (candidate) => candidate.profile.role === 'actor' &&
      !state.contracts.some((contract) => contract.talentId === candidate.profile.id),
  )
  if (additionalActor === undefined) {
    throw new Error('Bridge founding has no additional Actor applicant for the two-picture proof.')
  }
  const actorOffer = [...additionalActor.employment.offerOptions]
    .sort((a, b) => b.termWeeks - a.termWeeks)[0]
  if (actorOffer === undefined) {
    throw new Error(`Bridge founding applicant ${additionalActor.profile.id} has no legal offer.`)
  }
  state = requireSuccess(
    signContractAction(state, additionalActor.profile.id, actorOffer.termWeeks),
    `sign additional Actor ${additionalActor.profile.id}`,
  )
  return requireSuccess(foundManagedStudioAction(state), 'found managed studio')
}

// W0 (CF-07): digest, canonical save JSON, the lot selector, and the two board
// projections are shared through one per-state build context instead of being
// recomputed by every consumer in the same request/poll. Values are unchanged —
// the context runs exactly the same pure functions, at most once per state.
export function authoritativeDigest(state: GameState): string {
  return snapshotBuildContextFor(state).stateDigest()
}

function opaqueIntentId(stateDigest: string, descriptor: unknown): string {
  return `intent-v${String(PROTOCOL_VERSION)}-${createHash('sha256')
    .update(stateDigest)
    .update('\0')
    .update(JSON.stringify(descriptor))
    .digest('hex')}`
}

function option(
  stateDigest: string,
  fields: Omit<AvailableIntent, 'intentId'>,
  hiddenAction: unknown,
): AvailableIntent {
  return {
    intentId: opaqueIntentId(stateDigest, { fields, hiddenAction }),
    ...fields,
  }
}

function caught(operation: () => ActionOutcome): ActionOutcome {
  try {
    return operation()
  } catch (error) {
    return { ok: false, error: (error as Error).message }
  }
}

function advanceOutcome(state: GameState): ActionOutcome {
  return caught(() => ({ ok: true, next: advanceWeek(state).next }))
}

function allCastingProjects(state: GameState) {
  const board = castingSessionsBoard(state)
  return [
    ...board.sections.readyToPlan,
    ...board.sections.auditioning,
    ...board.sections.needsReview,
    ...board.sections.history,
  ]
}

function castsFromReviewedAuditions(state: GameState, projectId: string) {
  const project = allCastingProjects(state).find((candidate) => candidate.projectId === projectId)
  if (project?.results === null || project?.results === undefined || project.sessionId === null) return []
  const results = project.results
  const casts: Array<{
    lead: (typeof results.lead)[number]
    antagonist: (typeof results.antagonist)[number]
    support: (typeof results.support)[number]
    sessionId: string
  }> = []
  const seen = new Set<string>()
  for (const lead of results.lead.filter((entry) => entry.available)) {
    for (const antagonist of results.antagonist.filter((entry) => entry.available)) {
      for (const support of results.support.filter((entry) => entry.available)) {
        if (
          lead.talentId === antagonist.talentId ||
          lead.talentId === support.talentId ||
          antagonist.talentId === support.talentId
        ) continue
        const identity = `${lead.talentId}\0${antagonist.talentId}\0${support.talentId}`
        if (seen.has(identity)) continue
        seen.add(identity)
        casts.push({ lead, antagonist, support, sessionId: project.sessionId })
      }
    }
  }
  return casts
}

function auditionEvidenceLine(
  role: 'Lead' | 'Antagonist' | 'Support',
  evidence: {
    name: string
    estimate: number
    low: number
    high: number
    fit: { score: number }
    strengths: string[]
    concerns: string[]
  },
): string {
  const observations: string[] = []
  if (evidence.strengths[0] !== undefined) observations.push(`Strength: ${evidence.strengths[0]}`)
  if (evidence.concerns[0] !== undefined) observations.push(`Concern: ${evidence.concerns[0]}`)
  if (observations.length === 0) {
    observations.push('This camera test is evidence, not a performance guarantee.')
  }
  return `${role} ${evidence.name}: Est. ${String(evidence.estimate)}, observed range ` +
    `${String(evidence.low)}-${String(evidence.high)}, Fit ${String(evidence.fit.score)}. ` +
    observations.join(' ')
}

function hasOnlyQueueableCapacityBlockers(
  blockers: readonly { kind: string }[],
): boolean {
  return blockers.length > 0 && blockers.every((blocker) => blocker.kind === 'facility-capacity')
}

function pushIfAccepted(
  state: GameState,
  resolved: IntentApplication[],
  candidate: IntentApplication,
): void {
  if (candidate.apply(state).ok) resolved.push(candidate)
}

function acceptedIntentMessage(
  fallback: string,
  before: GameState,
  after: GameState,
): string {
  const priorOrdinals = new Set(before.productionQueue.map((entry) => entry.ordinal))
  const admitted = after.productionQueue.find((entry) => !priorOrdinals.has(entry.ordinal))
  if (admitted === undefined) return fallback
  switch (admitted.kind) {
    case 'commissionScript':
    case 'commissionOriginalScreenplay':
      return 'Screenplay commission joined the Development & Casting queue. No writer, project identity, or cost is committed until capacity reaches it and TypeScript revalidates it.'
    case 'startCastingSession':
      return 'Auditions joined the Development & Casting queue. No actor was reserved or paid while the camera-test request waits.'
    case 'greenlightScriptProject':
      return 'Greenlight joined the Development & Casting queue. No production identity, budget, or talent commitment exists until capacity reaches the package and TypeScript revalidates it.'
  }
}

const FOUNDING_OFFER_TERM_WEEKS = 104

function exactDollars(value: number): string {
  const rounded = Math.round(value)
  const sign = rounded < 0 ? '-' : ''
  const digits = String(Math.abs(rounded)).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  return `${sign}$${digits}`
}

function foundingRoleLabel(role: FoundingApplicantRow['role']): string {
  switch (role) {
    case 'actor': return 'actor'
    case 'director': return 'director'
    case 'writer': return 'writer'
    case 'craft': return 'production/craft lead'
    case 'scientist': return 'scientist'
  }
}

function foundingRunwayLabel(state: GameState): string {
  const runway = foundingRunwayPreview(state)
  return runway.infinite ? 'unlimited at current commitments' : `${String(runway.weeks)} weeks`
}

function foundingOfferDetail(
  row: FoundingApplicantRow,
  offer: FoundingApplicantRow['card']['employment']['offerOptions'][number],
  after: GameState,
): string {
  const obligation = offerObligation(offer)
  const strengths = row.topStrengths.length > 0
    ? row.topStrengths.join(', ')
    : 'No standout signal surfaced'
  const concern = row.primaryConcern ?? 'No primary concern surfaced'
  return `Perceived OVR ${String(row.ovr)} (${row.ovrTier}); potential ` +
    `${row.potentialTier} up to ${String(row.potentialHigh)}; work ethic ${row.workEthicLabel}. ` +
    `Strengths: ${strengths}. Concern: ${concern}. ` +
    `Annual salary ${exactDollars(offer.annualSalary)}; signing bonus ` +
    `${exactDollars(offer.signingBonus)}; guaranteed salary ` +
    `${exactDollars(obligation.guaranteedComp)}; total obligation ` +
    `${exactDollars(obligation.total)}; weekly salary ${exactDollars(obligation.weeklySalary)}. ` +
    `Projected weekly payroll after signing ${exactDollars(payrollSummary(after).weeklyPayroll)}; ` +
    `recruitment fund after signing ${exactDollars(foundingBudgetRemaining(after))}; ` +
    `projected founding runway ${foundingRunwayLabel(after)}.`
}

type FoundingResolution = {
  intents: IntentApplication[]
  projection: BridgeFoundingSnapshot
}

/**
 * LL-CP9. Founding intents and the read-only founding-arrival view come from ONE
 * resolution pass, so every projected arrival's intentId matches an emitted intent
 * by construction — Unity never parses prose to bind an offer to a person.
 *
 * THE PLAYER'S FOUNDING LAW IS THE ENGINE'S: Core coverage (3 Actors / 1 Director /
 * 1 Writer / 1 Production-Craft Lead) makes foundStudio legal, and the bridge emits
 * it the moment coverage is met. The reserve Actor the automated two-picture proof
 * wants is an OPTIONAL post-coverage offer wave — automation that needs a reserve
 * signs one deliberately; a player may found without it.
 */
function resolveFounding(
  state: GameState,
  stateDigest: string,
): FoundingResolution | null {
  if (state.founding === null) return null

  const progress = foundingProgress(state)
  const requiredRole = progress.find((entry) => !entry.met)?.role ?? null
  const actorProgress = progress.find((entry) => entry.role === 'actor')
  if (actorProgress === undefined) throw new Error('Founding progress omitted Actors.')

  const resolved: IntentApplication[] = []
  const arrivals: BridgeFoundingArrivalSnapshot[] = []
  const reserveWave = requiredRole === null && actorProgress.extra === 0
  const offerRole = requiredRole ?? (reserveWave ? 'actor' : null)
  if (offerRole !== null) {
    for (const row of foundingApplicantRows(state, offerRole)) {
      if (row.signed) continue
      const offer = row.card.employment.offerOptions.find(
        (candidate) => candidate.termWeeks === FOUNDING_OFFER_TERM_WEEKS,
      )
      if (offer === undefined) continue
      const preview = signContractAction(state, row.id, FOUNDING_OFFER_TERM_WEEKS)
      if (!preview.ok) continue
      const fields: Omit<AvailableIntent, 'intentId'> = {
        kind: 'signFoundingContract',
        label: `Offer ${row.name} a 2-year ${foundingRoleLabel(row.role)} contract`,
        detail:
          (reserveWave
            ? 'Optional reserve Actor: founding is already legal without this signing. '
            : '') + foundingOfferDetail(row, offer, preview.next),
        projectId: null,
        castingSessionId: null,
        productionId: null,
      }
      const intentOption = option(stateDigest, fields, {
        kind: 'signContract',
        talentId: row.id,
        termWeeks: FOUNDING_OFFER_TERM_WEEKS,
      })
      resolved.push({
        option: intentOption,
        apply: (current) => signContractAction(current, row.id, FOUNDING_OFFER_TERM_WEEKS),
      })
      const obligation = offerObligation(offer)
      const after = preview.next
      const runwayAfter = foundingRunwayPreview(after)
      arrivals.push({
        talentId: row.id,
        name: row.name,
        role: row.role,
        roleLabel: foundingRoleLabel(row.role),
        ovr: row.ovr,
        ovrTier: row.ovrTier,
        fame: row.fame,
        potentialTier: row.potentialTier,
        potentialHigh: row.potentialHigh,
        workEthic: row.workEthic,
        workEthicLabel: row.workEthicLabel,
        standingPct: row.standingPct,
        standingTier: row.standing,
        // P14C.1 (758 A14): the engine no longer ages talent continuously — `Talent.age`
        // is materialized to completed years at the tick that produces a birthday week,
        // so this floor is now a no-op on every live state. Kept, not removed: the
        // projection must not start depending on the writer's rounding, and the frozen
        // historical control still carries pre-C.1 fractional ages.
        age: Math.floor(row.age),
        topStrengths: row.topStrengths,
        primaryConcern: row.primaryConcern,
        topGenreLabel: row.topGenreLabel,
        topGenreExperience: row.topGenreExperience,
        topGenreTied: row.topGenreTied,
        secondGenreLabel: row.secondGenreLabel,
        secondGenreExperience: row.secondGenreExperience,
        weeklySalary: obligation.weeklySalary,
        annualSalary: offer.annualSalary,
        signingBonus: offer.signingBonus,
        guaranteedComp: obligation.guaranteedComp,
        totalObligation: obligation.total,
        termWeeks: offer.termWeeks,
        reserve: reserveWave,
        intentId: intentOption.intentId,
        payrollAfterWeekly: payrollSummary(after).weeklyPayroll,
        fundAfter: foundingBudgetRemaining(after),
        runwayAfterWeeks: runwayAfter.weeks,
        runwayAfterInfinite: runwayAfter.infinite,
      })
    }
  }

  if (requiredRole === null) {
    const rosterSentence = actorProgress.extra > 0
      ? 'The roster includes a reserve Actor for two-picture continuity. '
      : ''
    const fields: Omit<AvailableIntent, 'intentId'> = {
      kind: 'foundStudio',
      label: 'START A STUDIO',
      detail:
        `Founding coverage: ${progress.map((entry) =>
          `${entry.label} ${String(entry.count)}/${String(entry.min)}`).join('; ')}. ` +
        `Weekly payroll ${exactDollars(payrollSummary(state).weeklyPayroll)}; recruitment fund ` +
        `${exactDollars(foundingBudgetRemaining(state))}; projected runway ` +
        `${foundingRunwayLabel(state)}. ${rosterSentence}Accepting opens the operational studio lot.`,
        projectId: null,
        castingSessionId: null,
        productionId: null,
    }
    pushIfAccepted(state, resolved, {
      option: option(stateDigest, fields, { kind: 'foundManagedStudio' }),
      apply: (current) => foundManagedStudioAction(current),
    })
  }

  const projectedRunway = foundingRunwayPreview(state)
  // The signed roster, in signing order — the engine's contracts joined to
  // its own talent records. A missing talent record is a structural fault;
  // fail closed to the id rather than inventing a name.
  const signed = state.contracts.map((contract) => {
    const talent = findTalent(state, contract.talentId)
    return {
      name: talent?.name ?? contract.talentId,
      roleLabel: talent === undefined ? 'unknown' : foundingRoleLabel(talent.role),
    }
  })
  const projection: BridgeFoundingSnapshot = {
    waveRole: offerRole,
    waveRoleLabel: offerRole === null ? null : foundingRoleLabel(offerRole),
    waveReserve: reserveWave,
    arrivals,
    signed,
    progress: progress.map((entry) => ({
      role: entry.role,
      label: entry.label,
      count: entry.count,
      min: entry.min,
      met: entry.met,
    })),
    recruitmentFund: foundingBudgetRemaining(state),
    projectedWeeklyPayroll: payrollSummary(state).weeklyPayroll,
    projectedRunwayWeeks: projectedRunway.weeks,
    projectedRunwayInfinite: projectedRunway.infinite,
    readyToFound: requiredRole === null,
  }
  return { intents: resolved, projection }
}

function treasuryOf(state: GameState): BridgeTreasurySnapshot {
  const finance = financeCard(state)
  return {
    cash: finance.cash,
    weeklyBurn: finance.weeklyBurn,
    weeklyPayroll: finance.weeklyPayroll,
    netWeeklyCash: finance.netWeeklyCash,
    runwayWeeks: finance.runway.weeks,
    runwayInfinite: finance.runway.infinite,
  }
}

function resolveStudioIntents(state: GameState): IntentApplication[] {
  const stateDigest = authoritativeDigest(state)
  const founding = resolveFounding(state, stateDigest)
  if (founding !== null) return founding.intents
  const snapshot = snapshotBuildContextFor(state).lotSnapshot()
  const journey = snapshot.firstFilmJourney
  if (journey === undefined) throw new Error('Current studio lot snapshot omitted firstFilmJourney.')
  const resolved: IntentApplication[] = []
  const board = scriptProjectsBoard(state)
  const castingProjects = allCastingProjects(state)
  const queuedCommissionConceptIds = new Set(
    state.productionQueue.flatMap((entry) =>
      entry.kind === 'commissionScript' ? [entry.payload.conceptId] : [],
    ),
  )
  const queuedCommissionWriterIds = new Set(
    state.productionQueue.flatMap((entry) =>
      entry.kind === 'commissionScript' || entry.kind === 'commissionOriginalScreenplay'
        ? [entry.payload.writerId]
        : [],
    ),
  )
  const queuedCastingProjectIds = new Set(
    state.productionQueue.flatMap((entry) =>
      entry.kind === 'startCastingSession' ? [entry.payload.projectId] : [],
    ),
  )
  const queuedGreenlightProjectIds = new Set(
    state.productionQueue.flatMap((entry) =>
      entry.kind === 'greenlightScriptProject' ? [entry.scriptProjectId] : [],
    ),
  )

  const construction = studioDevelopment(state)
  if (construction.canStart) {
    const fields: Omit<AvailableIntent, 'intentId'> = {
      kind: 'startConstruction',
      label: `Start ${construction.name}`,
      detail: construction.consequence,
      projectId: null,
      castingSessionId: null,
      productionId: null,
    }
    resolved.push({
      option: option(stateDigest, fields, { kind: 'startDevelopmentCastingAnnex' }),
      apply: (current) => startDevelopmentCastingAnnexAction(current),
    })
  }

  // Front-door choices are independent of the one guided picture. The read model
  // says what is actionable; the discarded preflight lets the authoritative action
  // distinguish the one queueable capacity refusal from every real illegality.
  const commissionCapacityOnly = hasOnlyQueueableCapacityBlockers(board.commission.blockers)
  const concept = board.commission.concepts.find(
    (candidate) => !queuedCommissionConceptIds.has(candidate.id),
  )
  const availableWriters = board.commission.writers.filter(
    (candidate) =>
      candidate.available &&
      !queuedCommissionWriterIds.has(candidate.id),
  )
  // Prefer the usual discipline, but credit/commission eligibility belongs to
  // the read model: another contracted writing-capable person is a legal remedy.
  const writer = availableWriters.find(candidate => candidate.primaryRole === 'writer') ?? availableWriters[0]
  if (
    (board.commission.canStart || commissionCapacityOnly) &&
    concept !== undefined &&
    writer !== undefined
  ) {
    const payload = {
      conceptId: concept.id,
      writerId: writer.id,
      shape: { opening: 'slowSetup', midpoint: 'revelation', ending: 'bittersweet' } as const,
      promise: {
        genre: concept.genre,
        intendedSegments: ['adult', 'prestige'] as Array<'adult' | 'prestige'>,
        ranges: {
          intimacy: [-0.4, 0.6] as [number, number],
          tonalWeight: [0, 0.8] as [number, number],
          kineticEnergy: [-0.7, 0.2] as [number, number],
        },
      },
    }
    const capacityDetail = commissionCapacityOnly
      ? board.commission.blockers[0]?.detail ?? ''
      : ''
    const fields: Omit<AvailableIntent, 'intentId'> = {
      kind: 'commissionScreenplay',
      label:
        journey.next?.kind === 'commission'
          ? journey.next.label
          : `Commission ${concept.title}`,
      detail: commissionCapacityOnly
        ? `${concept.title} · ${writer.name}. If accepted, this commission joins the ` +
          `Development & Casting queue and holds nothing until revalidation. ${capacityDetail}`
        : `${concept.title} · ${writer.name} · ${board.commission.consequence}`,
      projectId: null,
      castingSessionId: null,
      productionId: null,
    }
    pushIfAccepted(state, resolved, {
      option: option(stateDigest, fields, { kind: 'commissionScript', payload }),
      apply: (current) => commissionScriptAction(current, payload),
    })
  }

  for (const project of castingProjects) {
    if (
      queuedCastingProjectIds.has(project.projectId) ||
      !project.legalActions.some((action) => action.kind === 'planAuditions')
    ) continue
    // This is a fixed bootstrap player choice, not a legality rule. Prefer the public
    // read model's contract-backed availability presentation so a one-week camera test
    // does not knowingly rely on a transient freelancer-market appearance.
    const candidates = project.candidates.lead
      .filter((candidate) => candidate.available)
      .map((candidate, ordinal) => ({ candidate, ordinal }))
      .sort((left, right) => {
        const leftContracted = left.candidate.availabilityLabel.startsWith('Studio-contracted')
        const rightContracted = right.candidate.availabilityLabel.startsWith('Studio-contracted')
        return leftContracted === rightContracted
          ? left.ordinal - right.ordinal
          : leftContracted ? -1 : 1
      })
      .slice(0, 3)
      .map(({ candidate }) => candidate)
    if (candidates.length !== 3) continue
    const payload = {
      projectId: project.projectId,
      slate: {
        lead: [candidates[0]!.id, candidates[1]!.id] as [string, string],
        antagonist: [candidates[0]!.id, candidates[2]!.id] as [string, string],
        support: [candidates[1]!.id, candidates[2]!.id] as [string, string],
      },
    }
    const fields: Omit<AvailableIntent, 'intentId'> = {
      kind: 'startAuditions',
      label:
        journey.next?.kind === 'plan-auditions' && journey.scriptProjectId === project.projectId
          ? journey.next.label
          : `Plan auditions for ${project.title}`,
      detail:
        `Camera-test slate: ${candidates.map((candidate) => candidate.name).join(', ')}.` +
        (project.blockers.length === 0 ? '' : ` ${project.blockers.join(' ')}`),
      projectId: project.projectId,
      castingSessionId: null,
      productionId: null,
    }
    pushIfAccepted(state, resolved, {
      option: option(stateDigest, fields, { kind: 'startCastingSession', payload }),
      apply: (current) => startCastingSessionAction(current, payload),
    })
  }

  for (const packageView of board.packages) {
    if (queuedGreenlightProjectIds.has(packageView.projectId)) continue
    const capacityOnly = hasOnlyQueueableCapacityBlockers(packageView.availability.blockers)
    if (
      packageView.openAction === null ||
      (!packageView.availability.knownGatesClear && !capacityOnly)
    ) continue
    const casts = castsFromReviewedAuditions(state, packageView.projectId)
    const director = studioPool(state, 'director').find((candidate) => candidate.available)
    const craft = studioPool(state, 'craft').find((candidate) => candidate.available)
    const packageConcept = findConcept(state, packageView.concept.id)
    if (
      casts.length === 0 || director === undefined || craft === undefined || packageConcept === undefined
    ) continue
    const capacityDetail = capacityOnly ? packageView.availability.blockers[0]?.detail ?? '' : ''
    for (const cast of casts) {
      const pkg: DraftPackage = {
        conceptId: packageView.concept.id,
        shape: packageView.lockedShape,
        promise: packageView.lockedPromise,
        writerId: packageView.writer.id,
        directorId: director.id,
        craftIds: [craft.id],
        cast: {
          lead: cast.lead.talentId,
          antagonist: cast.antagonist.talentId,
          support: cast.support.talentId,
        },
        budget: {
          negative: requiredNegative(packageConcept, packageView.lockedShape, state),
          marketing: 0,
        },
      }
      const fields: Omit<AvailableIntent, 'intentId'> = {
        kind: 'greenlightPicture',
        label:
          `Lead ${cast.lead.name} / Antagonist ${cast.antagonist.name} / ` +
          `Support ${cast.support.name} - greenlight ${packageView.concept.title}`,
        detail:
          `${auditionEvidenceLine('Lead', cast.lead)} ` +
          `${auditionEvidenceLine('Antagonist', cast.antagonist)} ` +
          `${auditionEvidenceLine('Support', cast.support)} ` +
          `Director ${director.name}; Production/Craft ${craft.name}.` +
          (capacityDetail === '' ? '' : ` ${capacityDetail}`),
        projectId: packageView.projectId,
        castingSessionId: cast.sessionId,
        productionId: null,
      }
      pushIfAccepted(state, resolved, {
        option: option(stateDigest, fields, { kind: 'greenlightScriptProject', pkg }),
        apply: (current) => greenlightScriptProject(current, packageView.projectId, pkg),
      })
    }
  }

  // ── P05A W2: ALL active exact-ID Production decisions publish (recon §6.2) ──
  //
  // The bridge no longer narrows Production commands to the one guided picture:
  // every active production whose board card carries a current command emits its
  // own digest-bound intent, in ascending exact-productionId order. The guided
  // journey's `resolve-production` step selects from this same family (see
  // `selectJourneyIntent`), so guidance and availability can never disagree.
  if (state.operations.mode === 'managed') {
    const commandCards = productionBoard(state)
      .cards.filter((card) => card.command !== null)
      .sort((left, right) =>
        left.productionId < right.productionId ? -1 : left.productionId > right.productionId ? 1 : 0,
      )
    for (const card of commandCards) {
      const command = card.command!
      const fields: Omit<AvailableIntent, 'intentId'> = {
        kind: 'resolveProductionBlocker',
        label: command.label,
        detail: card.blocker?.detail ?? card.statusLabel,
        projectId: null,
        castingSessionId: null,
        productionId: card.productionId,
      }
      pushIfAccepted(state, resolved, {
        option: option(stateDigest, fields, command),
        apply: (current) => runProductionCommand(current, command),
      })
    }
  }

  // ── P06A W2 — the explicit release commitment, per exact picture ──────────
  // One intent per UNCOMMITTED Release Ready production, ascending exact id.
  // The option's productionId is ALWAYS non-empty for this kind; the applied
  // action is the ONE core `commitPictureToRelease` — legality lives there,
  // never here. Published in managed AND legacy worlds (the hold law binds
  // both arms), and never gated by `studioDecision` — the release decision IS
  // the decision this intent resolves.
  {
    const committedIds = new Set(
      state.releaseAuthority.commitments.map((row) => row.productionId),
    )
    const readyUncommitted = state.studio.activeProductions
      .filter(
        (production) => production.remainingTicks === 1 && !committedIds.has(production.id),
      )
      .sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
    for (const production of readyUncommitted) {
      const concept = state.concepts.find(
        (candidate) => candidate.id === production.conceptId,
      )
      const title = concept?.title ?? production.id
      const fields: Omit<AvailableIntent, 'intentId'> = {
        kind: 'commitPictureToRelease',
        label: `Commit ${title} to release`,
        detail:
          'Irreversible. Advances no time; the picture releases on the next studio week.',
        projectId: null,
        castingSessionId: null,
        productionId: production.id,
      }
      pushIfAccepted(state, resolved, {
        option: option(stateDigest, fields, {
          kind: 'commitPictureToRelease',
          productionId: production.id,
        }),
        apply: (current) =>
          caught(() => ({
            ok: true,
            next: applyActions(current, [
              { kind: 'commitPictureToRelease', productionId: production.id },
            ]),
          })),
      })
    }
  }

  const next = journey.next
  if (next === null) return resolved

  // Commission guidance and the ready-to-package family must not stop a lawful
  // manual week while receipts or construction continue. The screenplay is
  // accepted and camera tests have not
  // been planned (`plan-auditions`), the finished package has not been opened
  // (`open-package`), or packaging is blocked (`review-casting-blocker`). The
  // guided next step above still points at Casting — that guidance is untouched —
  // but Living Time's one authoritative clock must not go dead here: a player
  // legitimately wants a week to pass while browsing candidates (weekly
  // freelancer-market rotation), while a queued greenlight ages toward admission,
  // or during the P04A staleness window. The ordinary advanceWeek control is
  // published alongside the casting-oriented intents above, gated by the same
  // decision-pause law every other branch below already honors: nothing publishes
  // while the studio is actually stopped on a decision (`studioDecision`).
  if (
    next.kind === 'commission' ||
    next.kind === 'plan-auditions' ||
    next.kind === 'open-package' ||
    next.kind === 'review-casting-blocker'
  ) {
    if (studioDecision(state) === null) {
      const fields: Omit<AvailableIntent, 'intentId'> = {
        kind: 'advanceWeek',
        label: 'No action is required this week — advance the week',
        detail: journey.waiting?.reason ?? journey.detail ?? 'Advance the authoritative studio week.',
        projectId: journey.scriptProjectId,
        castingSessionId: null,
        productionId: journey.productionId,
      }
      resolved.push({
        option: option(stateDigest, fields, { kind: 'advanceWeek' }),
        apply: advanceOutcome,
      })
    }
    return resolved
  }

  if (next.kind === 'advance-week') {
    const fields: Omit<AvailableIntent, 'intentId'> = {
      kind: 'advanceWeek',
      label: next.label,
      detail: journey.waiting?.reason ?? journey.detail ?? 'Advance the authoritative studio week.',
      projectId: journey.scriptProjectId,
      castingSessionId: null,
      productionId: journey.productionId,
    }
    resolved.push({
      option: option(stateDigest, fields, { kind: 'advanceWeek' }),
      apply: advanceOutcome,
    })
    return resolved
  }

  // ── P06A W1 — THE MANUAL-ADVANCE CARVE-OUT (charter W1 / hostile F7) ────────
  // The release-review decision pauses everything automatic (`studioDecision`
  // is non-null, so no other branch publishes `advanceWeek`), but HOLDING is a
  // lawful player choice: explicit manual Advance Week stays published, with
  // hold-honest copy. This is the ONE deliberate exception to the
  // decision-suppresses-advance rule; every other decision kind keeps it.
  // The commit intent itself arrives with W2's schema — until then the direct
  // core action and this hold path are the interface.
  if (next.kind === 'release-review') {
    const fields: Omit<AvailableIntent, 'intentId'> = {
      kind: 'advanceWeek',
      label: `Hold ${journey.pictureTitle ?? 'the picture'} at Release Ready — advance the week`,
      detail:
        'Holding is a choice: payroll and overhead continue and the company stays busy. The picture releases only after you commit it.',
      projectId: journey.scriptProjectId,
      castingSessionId: null,
      productionId: journey.productionId,
    }
    resolved.push({
      option: option(stateDigest, fields, { kind: 'advanceWeek' }),
      apply: advanceOutcome,
    })
    return resolved
  }

  if (next.kind === 'script-review' && journey.scriptProjectId !== null) {
    const decision = board.nextDecision
    if (decision?.projectId === journey.scriptProjectId) {
      for (const action of decision.legalActions) {
        const kind = action.kind === 'acceptScript' ? 'acceptScreenplay' : 'requestRewrite'
        const fields: Omit<AvailableIntent, 'intentId'> = {
          kind,
          label: action.label,
          detail: `${decision.title} · ${journey.whyItMatters}`,
          projectId: action.projectId,
          castingSessionId: null,
          productionId: null,
        }
        resolved.push({
          option: option(stateDigest, fields, action),
          apply: (current) => runScriptProjectAction(current, action),
        })
      }
    }
    return resolved
  }

  if (next.kind === 'audition-review' && journey.scriptProjectId !== null) {
    const project = castingProjects.find(
      (candidate) => candidate.projectId === journey.scriptProjectId && candidate.status === 'review',
    )
    const action = project?.legalActions.find(
      (candidate) => candidate.kind === 'acknowledgeCastingSession',
    )
    if (project !== undefined && action?.kind === 'acknowledgeCastingSession') {
      const reads = project.results === null
        ? 0
        : Object.values(project.results).reduce((sum, entries) => sum + entries.length, 0)
      const fields: Omit<AvailableIntent, 'intentId'> = {
        kind: 'acknowledgeAuditions',
        label: action.label,
        detail: `${String(reads)} authoritative camera-test reads reviewed for ${project.title}.`,
        projectId: action.projectId,
        castingSessionId: action.sessionId,
        productionId: null,
      }
      resolved.push({
        option: option(stateDigest, fields, action),
        apply: (current) => acknowledgeCastingSessionAction(current, action.sessionId),
      })
    }
    return resolved
  }

  // P05A W2: `resolve-production` intents are published for EVERY active
  // production above; the journey's own step selects the matching one by exact
  // productionId in `selectJourneyIntent`, so no separate journey-bound
  // emission remains (a second emission would mint a duplicate intentId).
  return resolved
}

/**
 * P13B-S5: an `adopt-*` row moves equipment and physical plant, not research, so both
 * adoption verbs — the retained `adoptSynchronizedSound` and the per-technology
 * `adoptTechnology` — publish the SAME `adoptTechnology` kind. Every other Laboratory
 * verb keeps `researchAction`; the plan companions keep `physicalPlanAction`.
 */
function resolveLaboratoryIntents(state: GameState): Array<IntentApplication & LaboratoryIntent> {
  const stateDigest = authoritativeDigest(state)
  return laboratoryActionSpecs(state).filter(spec => spec.enabled).map(spec => ({
    spec,
    option: option(stateDigest, {kind:isCancellationAction(spec.action)?'cancellationAction':isPhysicalPlanAction(spec.action)?'physicalPlanAction':spec.action.kind==='adoptTechnology'||spec.action.kind==='adoptSynchronizedSound'?'adoptTechnology':'researchAction',label:spec.label,detail:spec.detail,
      projectId:'projectId' in spec.action?spec.action.projectId:null,castingSessionId:null,
      productionId:'productionId' in spec.action?spec.action.productionId:null}, spec.action),
    apply: current => caught(() => ({ok:true,next:applyActions(current,[spec.action])})),
  }))
}

/** P13B-S3: the five plan verbs on the plans page. A plan is not research: its own kind. */
function resolvePlanIntents(state: GameState): Array<IntentApplication & PlanIntent> {
  const stateDigest = authoritativeDigest(state)
  return planActionSpecs(state).filter(spec => spec.enabled).map(spec => ({
    spec,
    option: option(stateDigest, {kind:isCancellationAction(spec.action)?'cancellationAction':'physicalPlanAction',label:spec.label,detail:spec.detail,
      projectId:'projectId' in spec.action?spec.action.projectId:null,castingSessionId:null,productionId:null}, spec.action),
    apply: current => caught(() => ({ok:true,next:applyActions(current,[spec.action])})),
  }))
}

/**
 * P13B-S4: the office rows. The plan companions are plan verbs and say so; the
 * immediate conversion is P09's own installation quote/commit pair — no new ENGINE
 * action kind (plan §S4) — and carries `installationAction`, because calling a
 * building conversion a research action would make the wire lie about what it moves.
 */
function resolveOfficeIntents(state: GameState): Array<IntentApplication & OfficeIntent> {
  const stateDigest = authoritativeDigest(state)
  return officeActionSpecs(state).filter(spec => spec.enabled).map(spec => ({
    spec,
    option: option(stateDigest, {kind:isCancellationAction(spec.action)?'cancellationAction':isPhysicalPlanAction(spec.action)?'physicalPlanAction':'installationAction',label:spec.label,detail:spec.detail,
      projectId:'projectId' in spec.action?spec.action.projectId:null,castingSessionId:null,productionId:null}, spec.action),
    apply: current => caught(() => ({ok:true,next:applyOfficeAction(current,spec.action)})),
  }))
}

/**
 * P13B-S5-R07: one row per reachable setup recipe on one exact pre-Shooting
 * picture. Its own kind: a setup plan is not research, not a physical plan and
 * not an installation — it moves that picture's preparation schedule and nothing
 * else. Only rows the engine's own dry run accepted are published.
 */
function resolveProductionSetupIntents(state: GameState): Array<IntentApplication & ProductionSetupIntent> {
  const stateDigest = authoritativeDigest(state)
  return setupRecipeActionSpecs(state).filter(spec => spec.enabled).map(spec => ({
    spec,
    option: option(stateDigest, {kind:'productionSetupAction',label:spec.label,detail:spec.detail,
      projectId:null,castingSessionId:null,productionId:spec.productionId}, spec.action),
    apply: current => caught(() => ({ok:true,next:applyActions(current,[spec.action])})),
  }))
}

/**
 * P15B Wave5 compatibility maximum shortcut, offered exactly when the live remedy list holds
 * LOAN (warning or distress, no loan outstanding, max ≥ LOAN_AMOUNT_STEP), at the lawful maximum. The
 * action revalidates the law at commit; the option carries the whole schedule in words.
 * quoteLoan separately admits a player-chosen legal principal without expanding this bounded list.
 */
function resolveLoanIntents(state: GameState): IntentApplication[] {
  const h = state.hollywood
  if (h === null || state.founding === null && !studioRemedies(state, h.playerStudioId).includes('LOAN')) return []
  if (state.founding !== null) return []
  const principal = loanMaxPrincipal(studioWeeklyFixedCost(state, h.playerStudioId))
  const terms = contractLoan(principal, studioWeeklyFixedCost(state, h.playerStudioId), state.market.tick)
  const fields: Omit<AvailableIntent, 'intentId'> = {
    kind: 'takeLoan',
    label: `Take a studio loan of ${exactDollars(principal)}`,
    detail: `Flat interest brings the total to ${exactDollars(terms.total)}, repaid over ${terms.installments.length} weeks at ${exactDollars(terms.installments[0]!)}/week from Week ${state.market.tick + 1}, charged with payroll whatever the cash. One loan at a time; no early repayment.`,
    projectId: null,
    castingSessionId: null,
    productionId: null,
  }
  const action = { kind: 'takeLoan' as const, principal }
  return [{ option: option(authoritativeDigest(state), fields, action), apply: (current) => caught(() => ({ ok: true, next: applyActions(current, [action]) })) }]
}

function resolveAvailableIntents(state: GameState): IntentApplication[] {
  // P15B Wave 4 (closure/v1; 1362-O §5.2): a closed player studio is read-only history and offers nothing.
  if (state.hollywood !== null && !isOperatingStudio(state, state.hollywood.playerStudioId)) return []
  return [...resolveStudioIntents(state), ...resolveLoanIntents(state), ...resolveLaboratoryIntents(state), ...resolvePlanIntents(state), ...resolveOfficeIntents(state), ...resolveProductionSetupIntents(state)]
}

export function availableIntents(state: GameState): AvailableIntent[] {
  return resolveAvailableIntents(state).map((entry) => entry.option)
}

export function applyAvailableIntent(state: GameState, intentId: string): ActionOutcome {
  const resolved = resolveAvailableIntents(state).find((entry) => entry.option.intentId === intentId)
  return resolved === undefined
    ? { ok: false, error: 'Intent is not available in the current authoritative state.' }
    : caught(() => resolved.apply(state))
}

export function playNextMovieThroughAvailableIntents(
  initial: GameState,
): { state: GameState; played: PlayedIntent[] } {
  let state = initial
  const releasedBefore = state.studio.releasedFilms.length
  const played: PlayedIntent[] = []
  for (let guard = 0; guard < 128; guard++) {
    if (state.studio.releasedFilms.length > releasedBefore) return { state, played }
    const candidates = availableIntents(state).filter((candidate) => candidate.kind !== 'startConstruction')
    const journey = snapshotBuildContextFor(state).lotSnapshot().firstFilmJourney
    const selected = selectJourneyIntent(candidates, journey)
    if (selected === undefined) {
      throw new Error(
        `Bridge autoplay found no legal movie intent at Week ${String(state.market.tick)}: ` +
          journey?.headline,
      )
    }
    const beforeWeek = state.market.tick
    const beforeDigest = authoritativeDigest(state)
    state = requireSuccess(applyAvailableIntent(state, selected.intentId), selected.kind)
    played.push({
      option: selected,
      beforeWeek,
      afterWeek: state.market.tick,
      beforeDigest,
      afterDigest: authoritativeDigest(state),
    })
  }
  throw new Error('Bridge autoplay exceeded its bounded Movie release guard.')
}

export function createBridgeBootstrap(seed = 'current-game-unity-adoption-v2'): {
  state: GameState
  movieOneIntents: PlayedIntent[]
} {
  const managed = createManagedBridgeState(seed)
  const movieOne = playNextMovieThroughAvailableIntents(managed)
  return { state: movieOne.state, movieOneIntents: movieOne.played }
}

export function createBridgeInitialState(seed = 'current-game-unity-adoption-v2'): GameState {
  return createBridgeBootstrap(seed).state
}

function rejectionFacts(
  reasonCode: RejectionCode,
): Rejection {
  switch (reasonCode) {
    case 'INVALID_JSON':
      return {
        category: 'request-invalid',
        blocker: 'The request body is not valid JSON.',
        currentHolder: null,
        remedy: 'Reconnect to the local engine. If this repeats, relaunch the documented compatible build and inspect the bridge log.',
      }
    case 'INVALID_COMMAND':
    case 'INVALID_CONTROL':
      return {
        category: 'request-invalid',
        blocker: 'The request does not match the current closed bridge envelope.',
        currentHolder: null,
        remedy: 'Reconnect to the local engine. If this repeats, relaunch the documented compatible build and inspect the bridge log.',
      }
    case 'PROTOCOL_MISMATCH':
    case 'SCHEMA_MISMATCH':
      return {
        category: 'contract-incompatible',
        blocker: 'The client contract is incompatible with the running TypeScript authority.',
        currentHolder: null,
        remedy: 'Stop both local processes and launch the documented compatible Project: Studio engine and client pair.',
      }
    case 'SESSION_MISMATCH':
      return {
        category: 'session-mismatch',
        blocker: 'The request belongs to a different bridge session.',
        currentHolder: null,
        remedy: 'Reconnect to the local engine and retry from the current studio state.',
      }
    case 'STALE_REVISION':
      return {
        category: 'state-stale',
        blocker: 'The authoritative state changed after this command was prepared.',
        currentHolder: null,
        remedy: 'Refresh the studio and try the action again from the current state.',
      }
    case 'COMMAND_ID_REUSE':
      return {
        category: 'command-conflict',
        blocker: 'This commandId is already bound to a different request envelope.',
        currentHolder: null,
        remedy: 'Wait for the original action result. If the interface remains out of sync, reconnect to the local engine.',
      }
    case 'INTENT_NOT_AVAILABLE':
      return {
        category: 'intent-unavailable',
        blocker: 'This exact intent is not available in the current authoritative state.',
        currentHolder: null,
        remedy: 'Refresh the studio and choose one of the actions available in the current state.',
      }
    case 'ENGINE_REJECTED':
      return {
        category: 'authority-refusal',
        blocker: 'The authoritative TypeScript engine refused the submitted intent.',
        currentHolder: null,
        remedy: 'Follow the current blocker guidance, refresh the studio, and try the action again.',
      }
    case 'NO_SAVE':
      return {
        category: 'save-state',
        blocker: 'No authoritative bridge save exists.',
        currentHolder: null,
        remedy: 'Create an authoritative save before requesting a load.',
      }
    case 'CAMPAIGN_CONFLICT': case 'CAMPAIGN_NOT_FOUND': case 'INVALID_CAMPAIGN_LABEL':
    case 'UNSAVED_PROGRESS': case 'STORAGE_UNAVAILABLE':
    case 'SAVE_REJECTED':
      return {
        category: 'save-state',
        blocker: 'The stored authoritative save did not pass TypeScript validation.',
        currentHolder: null,
        remedy: 'Keep the current studio state and load a compatible Project: Studio save.',
      }
  }
}

export class BridgeSession {
  readonly sessionId: string
  private state: GameState
  private revision: number
  /**
   * P03A commission quotes, keyed by minted intentId. Session-transient by
   * design: every entry is digest-bound to the exact state that quoted it, so
   * any accepted command or load invalidates the whole map, and a process
   * restart simply forgets quotes the client must re-request. Never journaled.
   */
  private readonly pendingQuotes = new Map<string, PendingQuote>()
  private readonly processed = new Map<string, RuntimeEntry>()
  private readonly journal: BridgeRuntimeJournalEntryV1[]
  private savedJson: string | null
  private savedSlotCache: {
    saveJson: string
    metadata: SavedSlotMetadata | null
  } | null = null
  private readonly runtimeLimits: BridgeRuntimeCheckpointLimits

  constructor(
    state = createBridgeInitialState(),
    sessionId: string = randomUUID(),
    savedJson: string | null = null,
    runtime: Partial<BridgeSessionRuntimeState> = {},
  ) {
    this.state = state
    this.sessionId = sessionId
    this.savedJson = savedJson
    this.revision = runtime.revision ?? 0
    this.runtimeLimits = runtime.limits ?? DEFAULT_BRIDGE_RUNTIME_CHECKPOINT_LIMITS
    this.journal = []
    for (const hydrated of runtime.journal ?? []) {
      const entry = {
        route: hydrated.route,
        commandId: hydrated.commandId,
        requestJson: hydrated.requestJson,
        responseJson: hydrated.responseJson,
      }
      this.journal.push(entry)
      this.processed.set(entry.commandId, { entry })
    }
  }

  static fromSaveJson(saveJson: string, sessionId: string = randomUUID(), limits: BridgeRuntimeCheckpointLimits = DEFAULT_BRIDGE_RUNTIME_CHECKPOINT_LIMITS): BridgeSession {
    const imported = importSaveJsonCurrent(saveJson)
    if (!imported.ok) throw new Error(imported.error)
    return new BridgeSession(
      imported.state,
      sessionId,
      snapshotBuildContextFor(imported.state).saveJson(),
      { limits },
    )
  }

  static createRuntime(
    limits: BridgeRuntimeCheckpointLimits = DEFAULT_BRIDGE_RUNTIME_CHECKPOINT_LIMITS,
    regime: FoundingRegime = 'endowed',
    seed: string = randomUUID(),
  ): BridgeSession {
    // P09 §16: the regime is written at creation, from the runtime's explicit
    // configuration — never inferred, never applied to an existing profile.
    return new BridgeSession(newGame(seed, { regime }), undefined, null, { limits })
  }

  static fromRuntimeCheckpoint(
    hydrated: HydratedBridgeRuntimeCheckpoint,
    limits: BridgeRuntimeCheckpointLimits = DEFAULT_BRIDGE_RUNTIME_CHECKPOINT_LIMITS,
  ): BridgeSession {
    const imported = importSaveJsonCurrent(hydrated.checkpoint.currentSaveJson)
    if (!imported.ok) throw new Error(imported.error)
    return new BridgeSession(
      imported.state,
      hydrated.checkpoint.sessionId,
      hydrated.checkpoint.savedSaveJson,
      {
        revision: hydrated.checkpoint.stateRevision,
        journal: hydrated.journal,
        limits,
      },
    )
  }

  get stateRevision(): number { return this.revision }
  get gameState(): GameState { return this.state }
  get runtimeJournalSize(): number { return this.journal.length }

  snapshot(): SnapshotEnvelope {
    return this.snapshotFor(this.state, this.revision)
  }

  industry(request:IndustryQuery) {
    if(request.sessionId!==this.sessionId)return this.protocolReject(request.requestId,'SESSION_MISMATCH','The active campaign changed. Refresh Industry.')
    if(request.expectedStateRevision!==this.stateRevision)return this.protocolReject(request.requestId,'STALE_REVISION','The studio advanced. Refresh this Industry page before continuing.')
    try{return industryPage(this.state,this.sessionId,this.stateRevision,request,request.view==='laboratory'?resolveLaboratoryIntents(this.state):[],request.view==='plans'?resolvePlanIntents(this.state):[],request.view==='office'?resolveOfficeIntents(this.state):[])}
    catch(error){return this.protocolReject(request.requestId,'INVALID_CONTROL',(error as Error).message)}
  }

  exportRuntimeCheckpoint(): BridgeRuntimeCheckpointV1 {
    return this.exportRuntimeCheckpointEncoded().checkpoint
  }

  exportRuntimeCheckpointEncoded(
    callerLimits: BridgeRuntimeCheckpointLimits = this.runtimeLimits,
  ): EncodedBridgeRuntimeCheckpoint {
    return createEncodedBridgeRuntimeCheckpoint({
      sessionId: this.sessionId,
      stateRevision: this.revision,
      currentSaveJson: snapshotBuildContextFor(this.state).saveJson(),
      savedSaveJson: this.savedJson,
      journal: this.journal,
    }, this.runtimeLimits, callerLimits)
  }

  dispatchWithRuntimeCheckpoint(
    route: 'save', request: ControlEnvelope, callerLimits?: BridgeRuntimeCheckpointLimits,
  ): { response: SaveResponse; prepared: EncodedBridgeRuntimeCheckpoint | null }
  dispatchWithRuntimeCheckpoint(
    route: 'command' | 'load', request: SubmitIntentCommand | ControlEnvelope, callerLimits?: BridgeRuntimeCheckpointLimits,
  ): { response: CommandResponse; prepared: EncodedBridgeRuntimeCheckpoint | null }
  dispatchWithRuntimeCheckpoint(
    route: BridgeRuntimeJournalRoute, request: SubmitIntentCommand | ControlEnvelope, callerLimits?: BridgeRuntimeCheckpointLimits,
  ): { response: CachedResponse; prepared: EncodedBridgeRuntimeCheckpoint | null }
  dispatchWithRuntimeCheckpoint(
    route: BridgeRuntimeJournalRoute,
    request: SubmitIntentCommand | ControlEnvelope,
    callerLimits: BridgeRuntimeCheckpointLimits = this.runtimeLimits,
  ): { response: CachedResponse; prepared: EncodedBridgeRuntimeCheckpoint | null } {
    const preparation: RuntimeCheckpointPreparation = { limits: callerLimits }
    let response: CachedResponse
    switch (route) {
      case 'command': response = this.executeCommand(request as SubmitIntentCommand, preparation); break
      case 'save': response = this.executeSave(request as ControlEnvelope, preparation); break
      case 'load': response = this.executeLoad(request as ControlEnvelope, preparation); break
      default: throw new Error('Unknown runtime journal route')
    }
    const result = preparation.result
    if (result === undefined) return { response, prepared: null } // replay or unjournaled refusal
    const checkpoint = result.prepared.checkpoint
    if (result.state !== this.state || checkpoint.sessionId !== this.sessionId ||
        checkpoint.stateRevision !== this.revision || checkpoint.savedSaveJson !== this.savedJson ||
        checkpoint.journal.length !== this.journal.length || checkpoint.journal.some((entry, index) => {
          const actual = this.journal[index]!
          return entry.route !== actual.route || entry.commandId !== actual.commandId ||
            entry.requestJson !== actual.requestJson || entry.responseJson !== actual.responseJson
        })) {
      throw new Error('Prepared checkpoint does not match the completed runtime dispatch')
    }
    return { response, prepared: result.prepared }
  }

  rolloverRuntime(
    limits: BridgeRuntimeCheckpointLimits = this.runtimeLimits,
  ): BridgeSession {
    const currentSaveJson = snapshotBuildContextFor(this.state).saveJson()
    const imported = importSaveJsonCurrent(currentSaveJson)
    if (!imported.ok) throw new Error(imported.error)
    return new BridgeSession(imported.state, randomUUID(), this.savedJson, { limits })
  }

  private savedSlotFor(savedJson: string | null): SavedSlotMetadata | null {
    if (savedJson === null) return null
    if (this.savedSlotCache === null || this.savedSlotCache.saveJson !== savedJson) {
      // The saved checkpoint can differ from the current game without changing
      // its revision. Key this derived metadata by the actual slot bytes.
      const imported = importSaveJsonCurrent(savedJson)
      const lot = imported.ok
        ? snapshotBuildContextFor(imported.state).lotSnapshot()
        : null
      this.savedSlotCache = {
        saveJson: savedJson,
        // The existing selector owns the fixed brand and saved game week.
        // Null means no readable metadata; never replace or repair saved bytes.
        metadata: lot === null ? null : {
          studioName: lot.studioName,
          gameWeek: lot.week,
        },
      }
    }
    const metadata = this.savedSlotCache.metadata
    // No served envelope may alias the retained cache object.
    return metadata === null ? null : { ...metadata }
  }

  private snapshotFor(state: GameState, revision: number): SnapshotEnvelope {
    const started = performance.now()
    const context = snapshotBuildContextFor(state)
    // P03A/P04A: the Development and Casting boards ride the broad selector
    // result into the bundle at the bridge boundary, so the browser's own
    // snapshot stays untouched. The bundle projection deep-copies every input,
    // so the shared context facts never reach a served envelope by reference.
    const lot = context.lotSnapshot()
    const snapshot = projectStudioProjectionBundle({
      industry:context.industry(),
      // P07A W2 — `results` now rides inside context.lotSnapshot() (the builder owns the
      // derivation, mirroring releasedFilms), so the projection partition invariant holds.
      ...lot,
      // P13B-S5-R07 (projection 38): the setup plan, its recipe rows and the
      // setup-aware wait ride the SAME production rows, composed here rather than
      // inside the broad lot selector the browser also reads.
      productionOperations: withProductionSetupRows(
        state,
        lot.productionOperations ?? [],
        resolveProductionSetupIntents(state),
      ),
      development: context.development(),
      casting: context.casting(),
      release: context.release(),
      // P08A W2: the Standing & Studio History section rides the same context.
      history: context.history(),
      // R3-N7-SIM-01: the read-only operating ledger, beside history and disjoint from it.
      operationsEvents: context.operationsEvents(),
      finance: context.finance(),
      // P10A W0: the player-safe Talent section (profiles / roster / grouped attention).
      talent: context.people(),
    })
    const stateDigest = context.stateDigest()
    // One founding resolution serves both surfaces, so an arrival's intentId can
    // never disagree with the availableIntents list of the same envelope.
    const founding = resolveFounding(state, stateDigest)
    const intents = founding === null
      ? availableIntents(state)
      : founding.intents.map((entry) => entry.option)
    const partial = {
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      snapshotVersion: SNAPSHOT_VERSION,
      sessionId: this.sessionId,
      stateRevision: revision,
      gameWeek: state.market.tick,
      stateDigest,
      snapshot,
      founding: founding === null ? null : founding.projection,
      savedSlot: this.savedSlotFor(this.savedJson),
      treasury: treasuryOf(state),
      availableIntents: intents,
    }
    const serializationMs = performance.now() - started
    const payloadBytes = Buffer.byteLength(JSON.stringify(partial), 'utf8')
    return { ...partial, metrics: { payloadBytes, serializationMs } }
  }

  command(command: SubmitIntentCommand): CommandResponse {
    return this.executeCommand(command)
  }

  private executeCommand(command: SubmitIntentCommand, preparation?: RuntimeCheckpointPreparation): CommandResponse {
    const started = performance.now()
    if (command.sessionId !== this.sessionId) {
      return this.reject(command.commandId, 'SESSION_MISMATCH', 'Command belongs to a different bridge session.', started)
    }
    const prior = this.priorResponse('command', command, started)
    if (prior !== null) return prior as CommandResponse
    if (command.expectedStateRevision !== this.revision) {
      const rejected = this.reject(
        command.commandId,
        'STALE_REVISION',
        `Intent expected revision ${String(command.expectedStateRevision)}; authority is revision ${String(this.revision)}.`,
        started,
      )
      this.remember('command', command, rejected, preparation)
      return rejected
    }
    const resolved =
      resolveAvailableIntents(this.state).find(
        (candidate) => candidate.option.intentId === command.payload.intentId,
      ) ?? this.quotedIntentFor(command.payload.intentId)
    if (resolved === undefined) {
      const rejected = this.reject(
        command.commandId,
        'INTENT_NOT_AVAILABLE',
        'Intent was not emitted by the current authoritative TypeScript state.',
        started,
      )
      this.remember('command', command, rejected, preparation)
      return rejected
    }
    const before = this.state
    const outcome = caught(() => resolved.apply(before))
    if (!outcome.ok) {
      const rejected = this.reject(command.commandId, 'ENGINE_REJECTED', outcome.error, started)
      this.remember('command', command, rejected, preparation)
      return rejected
    }
    const nextRevision = this.revision + 1
    const accepted: AcceptedCommandResponse = {
      ...this.snapshotFor(outcome.next, nextRevision),
      commandId: command.commandId,
      accepted: true,
      message: acceptedIntentMessage(resolved.option.label, before, outcome.next),
      processingMs: performance.now() - started,
    }
    const entry = this.prepareEntry(
      'command',
      command,
      accepted,
      outcome.next,
      nextRevision,
      this.savedJson,
      preparation,
    )
    this.state = outcome.next
    this.revision = nextRevision
    // Every quote was digest-bound to the state this command just replaced.
    this.pendingQuotes.clear()
    this.commitEntry(entry)
    return accepted
  }

  /**
   * Resolve a quote-minted commission OR casting intent. The quote is honored
   * only against the EXACT state that minted it (digest equality on top of the
   * revision guard the caller already passed); the draft is re-converted
   * against the live board so the engine's own front doors decide legality at
   * commit time. C# never sees or constructs the payload.
   */
  private quotedIntentFor(intentId: string): IntentApplication | undefined {
    const pending = this.pendingQuotes.get(intentId)
    if (pending === undefined) return undefined
    if (pending.stateDigest !== authoritativeDigest(this.state)) return undefined
    if (pending.family === 'diligence' || pending.family === 'absorption') {
      return {option:{intentId,kind:pending.kind,label:pending.commitLabel,detail:'',projectId:null,castingSessionId:null,productionId:null},
        apply:current=>authoritativeDigest(current)!==pending.stateDigest
          ? {ok:false,error:'Quoted rights intent no longer matches the authoritative state.'}
          : pending.family==='diligence'?diligenceDraftApply(current,pending.draft)
            : absorptionDraftApply(current,pending.draft,pending.quotedAtWeek,pending.quoteAgePolicyVersion)}
    }
    if (pending.family === 'loan') {
      // Resolve to a live action, never to the preflight successor captured at quote time.
      return { option: { intentId, kind: pending.kind, label: pending.commitLabel, detail: '',
        projectId: null, castingSessionId: null, productionId: null },
        apply: current => loanDraftApply(current, pending.draft) }
    }
    const fields = {
      kind: pending.kind,
      label: pending.commitLabel,
      detail: '',
      projectId: pending.family === 'casting' ? pending.draft.projectId : null,
      castingSessionId: null,
      productionId: null,
    } as const
    const conversion = pending.family === 'commission'
      ? draftToEngine(this.state, pending.draft)
      : pending.family === 'casting'
        ? castingDraftToEngine(this.state, pending.draft)
        : pending.family === 'placement'
          ? placementDraftToEngine(this.state, pending.draft)
          : pending.family === 'setCommission'
            ? setCommissionDraftToEngine(this.state, pending.draft)
            : pending.family === 'marketProposal'
              ? marketProposalDraftToEngine(this.state, playerProposalDraft(this.state, pending.draft))
              : pending.family === 'promiseWaiver'
                ? promiseWaiverDraftToEngine(this.state, pending.draft)
                : contractDraftToEngine(this.state, pending.draft)
    if (!conversion.ok) {
      return {
        option: { intentId, ...fields },
        apply: () => ({ ok: false, error: conversion.error }),
      }
    }
    // P09 §18 (commit revalidates): a placement quote that is no longer legal
    // on the live state must fail closed at commit, never charge, never build.
    if (conversion.kind === 'placeFacility' && !conversion.quote.ok) {
      const reason = conversion.quote.primary ?? 'illegal placement'
      return {
        option: { intentId, ...fields },
        apply: () => ({ ok: false, error: `This placement is no longer legal (${reason}).` }),
      }
    }
    // P10-R1: a contract quote that is no longer legal on the live state fails closed at
    // commit the same way — never charges, never renews, never releases.
    if ((conversion.kind === 'renewContract' || conversion.kind === 'releaseTalent') && conversion.refusal !== null) {
      return {
        option: { intentId, ...fields },
        apply: () => ({ ok: false, error: `This contract action is no longer legal (${conversion.refusal!.code}): ${conversion.refusal!.reason}` }),
      }
    }
    // P14A.1: a market proposal that is no longer legal on the live state fails closed at
    // commit the same way — the case may have settled, closed or moved out of reach.
    if (conversion.kind === 'marketProposalAction'
      && (conversion.refusal !== null || conversion.promise?.ok === false)) {
      const reason = conversion.refusal !== null
        ? `This proposal is no longer legal (${conversion.refusal.code}): ${conversion.refusal.reason}`
        : conversion.promise?.message ?? 'This promise is no longer offerable.'
      return {
        option: { intentId, ...fields },
        apply: () => ({ ok: false, error: reason }),
      }
    }
    // P14B.8: THE OWNERSHIP GATE, again at COMMIT. The conversion above re-resolves
    // the promise on the LIVE state and returns `ok:false` for any id the player's own
    // studio does not hold, so the `!conversion.ok` arm already refuses a rival's
    // promise even if the board moved between the quote and the confirmation. Today no
    // public sequence reaches this arm, because the quote is the only route to a
    // registered waiver intent and it refuses first; an unreachable guard now is a
    // reachable hole after the next change.
    // AND the acceptance re-check (744 §11 A6): a substitute the person no longer
    // accepts fails closed with CURATED copy. Letting `waivePromise` throw instead
    // would publish `promises: this person did not accept the substitute — …`
    // verbatim, since `caught` returns the raw message and `reject` republishes it.
    if (conversion.kind === 'waivePromise' && conversion.refusal !== null) {
      const refusal = conversion.refusal
      return {
        option: { intentId, ...fields },
        apply: () => ({ ok: false, error: `This substitute is no longer accepted: ${refusal}.` }),
      }
    }
    // P09A W5: a Set quote that is no longer legal fails closed at commit the same way.
    if (conversion.kind === 'commissionSet' && conversion.refusal !== null) {
      return {
        option: { intentId, ...fields },
        apply: () => ({ ok: false, error: `This Set commission is no longer legal (${conversion.refusal!.code}).` }),
      }
    }
    // Called as a METHOD, never detached: the market-proposal conversion's `apply` reads its
    // own draft off `this` (ONE shared function, so re-quoting the same draft on the same
    // state stays deeply equal — the accepted "asking again is deterministic" invariant).
    return { option: { intentId, ...fields }, apply: (current) => conversion.apply(current) }
  }

  /** Session-mismatch/stale-revision envelope guard shared by both quote families. */
  private quoteGuard(
    request: { sessionId: string; commandId: string; expectedStateRevision: number },
    started: number,
  ): RejectedResponse | null {
    if (request.sessionId !== this.sessionId) {
      return this.reject(
        request.commandId,
        'SESSION_MISMATCH',
        'Quote belongs to a different bridge session.',
        started,
      )
    }
    if (request.expectedStateRevision !== this.revision) {
      return this.reject(
        request.commandId,
        'STALE_REVISION',
        `Quote expected revision ${String(request.expectedStateRevision)}; authority is revision ${String(this.revision)}.`,
        started,
      )
    }
    return null
  }

  /** A small bound keeps an abandoned workspace from growing the map; the oldest quote is the least likely to be committed. */
  private capPendingQuotes(): void {
    if (this.pendingQuotes.size > 16) {
      const oldest = this.pendingQuotes.keys().next().value
      if (oldest !== undefined) this.pendingQuotes.delete(oldest)
    }
  }

  private mintQuoteResponse<TQuote>(
    request: { commandId: string },
    started: number,
    stateDigest: string,
    quote: TQuote,
  ): AcceptedQuoteResponseFor<TQuote> {
    return {
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      sessionId: this.sessionId,
      commandId: request.commandId,
      accepted: true,
      stateRevision: this.revision,
      gameWeek: this.state.market.tick,
      stateDigest,
      quote,
      processingMs: performance.now() - started,
    }
  }

  /**
   * Validate a commission or casting draft against the live state, mint the
   * ONE opaque commit intent, and answer with the TypeScript-authored
   * consequence summary. A quote mutates nothing — the revision is unchanged,
   * nothing is journaled, and the preflight successor is discarded whole.
   * Dispatches on `request.type`; overloaded so a caller that already knows
   * which family it asked for gets that family's quote type back narrowed,
   * with no cast.
   */
  quote(request: BridgeQuoteDiligenceRequest): AcceptedQuoteResponseFor<BridgeDiligenceQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteAbsorptionRequest): AcceptedQuoteResponseFor<BridgeAbsorptionQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteLoanRequest): AcceptedQuoteResponseFor<BridgeLoanQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteCommissionRequest): AcceptedQuoteResponseFor<BridgeCommissionQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteCastingRequest): AcceptedQuoteResponseFor<BridgeCastingQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuotePlacementRequest): AcceptedQuoteResponseFor<BridgePlacementQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteSetCommissionRequest): AcceptedQuoteResponseFor<BridgeSetCommissionQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteContractRequest): AcceptedQuoteResponseFor<BridgeContractQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteMarketProposalRequest): AcceptedQuoteResponseFor<BridgeMarketProposalQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteWaivePromiseRequest): AcceptedQuoteResponseFor<BridgePromiseWaiverQuoteSnapshot> | RejectedResponse
  quote(request: BridgeQuoteRequest): QuoteResponse
  quote(request: BridgeQuoteRequest): QuoteResponse {
    const started = performance.now()
    const { commandId } = request
    const guarded = this.quoteGuard(request, started)
    if (guarded !== null) return guarded
    if(request.type==='quotePaidDueDiligence') {
      const draft=diligenceDraftCopy(request.draft),stateDigest=authoritativeDigest(this.state)
      const intentId=opaqueIntentId(stateDigest,{diligenceDraft:draft}),quote=diligenceQuoteSnapshot(this.state,draft,intentId)
      if(quote.ok){this.pendingQuotes.set(intentId,{family:'diligence',draft,stateDigest,kind:'requestDueDiligence',commitLabel:quote.commitLabel});this.capPendingQuotes()}
      return this.mintQuoteResponse(request,started,stateDigest,quote)
    }
    if(request.type==='quoteHealthyAbsorption') {
      const draft=absorptionDraftCopy(request.draft),stateDigest=authoritativeDigest(this.state)
      const intentId=opaqueIntentId(stateDigest,{absorptionDraft:draft}),quote=absorptionQuoteSnapshot(this.state,draft,intentId)
      if(quote.ok){this.pendingQuotes.set(intentId,{family:'absorption',draft,quotedAtWeek:quote.quotedAtWeek,quoteAgePolicyVersion:quote.quoteAgePolicyVersion,
        stateDigest,kind:'absorbStudio',commitLabel:quote.commitLabel});this.capPendingQuotes()}
      return this.mintQuoteResponse(request,started,stateDigest,quote)
    }
    if (request.type === 'quoteLoan') {
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { loanDraft: request.draft })
      const quote = loanQuoteSnapshot(this.state, request.draft, intentId)
      if (quote.ok) {
        this.pendingQuotes.set(intentId, { family: 'loan', draft: { ...request.draft }, stateDigest,
          kind: 'takeLoan', commitLabel: quote.commitLabel })
        this.capPendingQuotes()
      }
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }
    if (request.type === 'quotePlacement') {
      // P09 §18: a PREVIEW is a first-class answer. The engine's legality
      // authority never throws; an illegal spot is an ACCEPTED quote with
      // `ok:false`, per-cell verdicts and the ordered reasons — and no
      // REGISTERED intent (the id it carries is never accepted for commit).
      // Only a legal quote is preflighted (the commit path must succeed on the
      // state that quoted it) and registered for the digest-bound commit.
      const conversion = placementDraftToEngine(this.state, request.draft)
      if (!conversion.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', conversion.error, started)
      }
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { placementDraft: request.draft })
      if (!conversion.quote.ok) {
        // Illegal preview: an accepted answer, NOT a registered intent — the id
        // is never accepted by the authority if a client submits it anyway.
        return this.mintQuoteResponse(
          request, started, stateDigest,
          placementQuoteSnapshot(this.state, request.draft, conversion, intentId),
        )
      }
      const preflight = caught(() => conversion.apply(this.state))
      if (!preflight.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', preflight.error, started)
      }
      const quote = placementQuoteSnapshot(this.state, request.draft, conversion, intentId)
      this.pendingQuotes.set(intentId, {
        family: 'placement',
        draft: request.draft,
        stateDigest,
        kind: 'placeFacility',
        commitLabel: quote.commitLabel,
      })
      this.capPendingQuotes()
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }

    if (request.type === 'quoteSetCommission') {
      // P09A W5: a refused Set preview is an ACCEPTED answer (`ok:false`, the engine's
      // own reason + remedy); only a legal one is preflighted and registered for commit.
      const conversion = setCommissionDraftToEngine(this.state, request.draft)
      if (!conversion.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', conversion.error, started)
      }
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { setCommissionDraft: request.draft })
      if (conversion.refusal !== null) {
        return this.mintQuoteResponse(
          request, started, stateDigest,
          setCommissionQuoteSnapshot(this.state, request.draft, conversion, intentId),
        )
      }
      const preflight = caught(() => conversion.apply(this.state))
      if (!preflight.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', preflight.error, started)
      }
      const quote = setCommissionQuoteSnapshot(this.state, request.draft, conversion, intentId)
      this.pendingQuotes.set(intentId, {
        family: 'setCommission',
        draft: request.draft,
        stateDigest,
        kind: 'commissionSet',
        commitLabel: quote.commitLabel,
      })
      this.capPendingQuotes()
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }

    if (request.type === 'quoteContract') {
      // P10-R1: a refused contract preview is an ACCEPTED answer (`ok:false`, the engine's
      // own reason + remedy); only a legal one is preflighted and registered for commit.
      const conversion = contractDraftToEngine(this.state, request.draft)
      if (!conversion.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', conversion.error, started)
      }
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { contractDraft: request.draft })
      if (conversion.refusal !== null) {
        return this.mintQuoteResponse(
          request, started, stateDigest,
          contractQuoteSnapshot(this.state, request.draft, conversion, intentId),
        )
      }
      const preflight = caught(() => conversion.apply(this.state))
      if (!preflight.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', preflight.error, started)
      }
      const quote = contractQuoteSnapshot(this.state, request.draft, conversion, intentId, preflight.next)
      this.pendingQuotes.set(intentId, {
        family: 'contract',
        draft: request.draft,
        stateDigest,
        kind: conversion.kind,
        commitLabel: quote.commitLabel,
      })
      this.capPendingQuotes()
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }

    if (request.type === 'quoteCommission') {
      const conversion = draftToEngine(this.state, request.draft)
      if (!conversion.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', conversion.error, started)
      }
      const preflight = caught(() => conversion.apply(this.state))
      if (!preflight.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', preflight.error, started)
      }
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { commissionDraft: request.draft })
      const quote = commissionQuoteSnapshot(
        this.state,
        request.draft,
        conversion,
        preflight.next,
        intentId,
      )
      this.pendingQuotes.set(intentId, {
        family: 'commission',
        draft: request.draft,
        stateDigest,
        kind: conversion.kind,
        commitLabel: quote.commitLabel,
      })
      this.capPendingQuotes()
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }

    if (request.type === 'quoteMarketProposal') {
      // P14A.1: a refused proposal preview is an ACCEPTED answer (`ok:false`, the engine's
      // own reason + remedy); only a legal one is preflighted and registered for commit.
      // The issuer is ALWAYS the player's own studio — no client authors a rival proposal.
      // Quote identity and pending authorization retain the same detached VALUES,
      // including the nested promise, never a caller-owned mutable payload.
      const payload = structuredClone(request.draft)
      const draft = playerProposalDraft(this.state, payload)
      const conversion = marketProposalDraftToEngine(this.state, draft)
      if (!conversion.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', conversion.error, started)
      }
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { marketProposalDraft: payload })
      const quote = marketProposalQuoteSnapshot(this.state, draft, conversion, intentId)
      if (!quote.ok) return this.mintQuoteResponse(request, started, stateDigest, quote)
      const preflight = caught(() => conversion.apply(this.state))
      if (!preflight.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', preflight.error, started)
      }
      this.pendingQuotes.set(intentId, {
        family: 'marketProposal',
        draft: payload,
        stateDigest,
        kind: 'marketProposalAction',
        commitLabel: quote.commitLabel,
      })
      this.capPendingQuotes()
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }

    if (request.type === 'quoteWaivePromise') {
      // P14B.8: a substitute this person would refuse is an ACCEPTED answer carrying
      // `ok:false` and `waiverAccepted`'s bare sentence; only an accepted one is
      // preflighted and registered for the digest-bound commit. A promise id this
      // studio does not own — and one no promise exists for — are BOTH conversion
      // refusals, with one identical sentence, so the answer never confirms a rival's
      // promise exists. Detached VALUES, never a caller-owned mutable payload.
      const draft = structuredClone(request.draft)
      const conversion = promiseWaiverDraftToEngine(this.state, draft)
      if (!conversion.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', conversion.error, started)
      }
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { promiseWaiverDraft: draft })
      const quote = promiseWaiverQuoteSnapshot(conversion, intentId)
      if (!quote.ok) return this.mintQuoteResponse(request, started, stateDigest, quote)
      const preflight = caught(() => conversion.apply(this.state))
      if (!preflight.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', preflight.error, started)
      }
      this.pendingQuotes.set(intentId, {
        family: 'promiseWaiver',
        draft,
        stateDigest,
        kind: 'waivePromise',
        commitLabel: quote.commitLabel,
      })
      this.capPendingQuotes()
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }

    if (request.type === 'quoteCasting') {
      const conversion = castingDraftToEngine(this.state, request.draft)
      if (!conversion.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', conversion.error, started)
      }
      const preflight = caught(() => conversion.apply(this.state))
      if (!preflight.ok) {
        return this.reject(request.commandId, 'ENGINE_REJECTED', preflight.error, started)
      }
      const stateDigest = authoritativeDigest(this.state)
      const intentId = opaqueIntentId(stateDigest, { castingDraft: request.draft })
      const quote = castingQuoteSnapshot(
        this.state,
        request.draft,
        conversion,
        preflight.next,
        intentId,
      )
      this.pendingQuotes.set(intentId, {
        family: 'casting',
        draft: request.draft,
        stateDigest,
        kind: conversion.kind,
        commitLabel: quote.commitLabel,
      })
      this.capPendingQuotes()
      return this.mintQuoteResponse(request, started, stateDigest, quote)
    }

    // FAIL LOUD (P14A.1): every family above is explicit, so an unrecognized `type`
    // is refused as an invalid command. It used to fall through into the casting
    // handler, which would silently misread another family's draft and answer with an
    // unrelated casting error.
    return this.reject(
      commandId,
      'INVALID_COMMAND',
      `Unknown quote type ${JSON.stringify((request as { type: string }).type)}.`,
      started,
    )
  }

  save(control: ControlEnvelope): SaveResponse {
    return this.executeSave(control)
  }

  private executeSave(control: ControlEnvelope, preparation?: RuntimeCheckpointPreparation): SaveResponse {
    const started = performance.now()
    const guarded = this.guardControl('save', control, started, preparation)
    if (guarded !== null) return guarded as SaveResponse
    const savedJson = snapshotBuildContextFor(this.state).saveJson()
    const accepted: AcceptedSaveResponse = {
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      sessionId: this.sessionId,
      commandId: control.commandId,
      accepted: true,
      message: 'Authoritative TypeScript save captured.',
      stateRevision: this.revision,
      gameWeek: this.state.market.tick,
      stateDigest: authoritativeDigest(this.state),
      saveJson: savedJson,
      // This receipt describes the prospective bytes committed below, not the
      // previous slot. A replay returns this historical receipt unchanged.
      savedSlot: this.savedSlotFor(savedJson),
      processingMs: performance.now() - started,
    }
    const entry = this.prepareEntry(
      'save',
      control,
      accepted,
      this.state,
      this.revision,
      savedJson,
      preparation,
    )
    this.savedJson = savedJson
    this.commitEntry(entry)
    return accepted
  }

  load(control: ControlEnvelope): CommandResponse {
    return this.executeLoad(control)
  }

  private executeLoad(control: ControlEnvelope, preparation?: RuntimeCheckpointPreparation): CommandResponse {
    const started = performance.now()
    const guarded = this.guardControl('load', control, started, preparation)
    if (guarded !== null) return guarded as CommandResponse
    if (this.savedJson === null) {
      const rejected = this.reject(control.commandId, 'NO_SAVE', 'No authoritative bridge save exists.', started)
      this.remember('load', control, rejected, preparation)
      return rejected
    }
    const loaded = importSaveJsonCurrent(this.savedJson)
    if (!loaded.ok) {
      const rejected = this.reject(control.commandId, 'SAVE_REJECTED', loaded.error, started)
      this.remember('load', control, rejected, preparation)
      return rejected
    }
    if (this.state.hollywood !== null && !sameNativeCampaignOrigin(this.state, loaded.state)) {
      const rejected = this.reject(control.commandId, 'SAVE_REJECTED', 'The saved slot belongs to another campaign or is missing Hollywood authority.', started)
      this.remember('load', control, rejected, preparation)
      return rejected
    }
    const nextRevision = this.revision + 1
    const accepted: AcceptedCommandResponse = {
      ...this.snapshotFor(loaded.state, nextRevision),
      commandId: control.commandId,
      accepted: true,
      message: loaded.converted
        ? 'Authoritative save loaded and migrated by TypeScript.'
        : 'Authoritative TypeScript save loaded.',
      processingMs: performance.now() - started,
    }
    const entry = this.prepareEntry(
      'load',
      control,
      accepted,
      loaded.state,
      nextRevision,
      this.savedJson,
      preparation,
    )
    this.state = loaded.state
    this.revision = nextRevision
    // Loading replaces the state every pending quote was digest-bound to.
    this.pendingQuotes.clear()
    this.commitEntry(entry)
    return accepted
  }

  protocolReject(
    commandId: string | null,
    reasonCode: RejectionCode,
    message: string,
    started = performance.now(),
  ): RejectedResponse {
    return this.reject(commandId, reasonCode, message, started)
  }

  private guardControl(
    route: 'save' | 'load',
    control: ControlEnvelope,
    started: number,
    preparation?: RuntimeCheckpointPreparation,
  ): CachedResponse | null {
    if (control.sessionId !== this.sessionId) {
      return this.reject(control.commandId, 'SESSION_MISMATCH', 'Control belongs to a different bridge session.', started)
    }
    const prior = this.priorResponse(route, control, started)
    if (prior !== null) return prior
    if (control.expectedStateRevision !== this.revision) {
      const rejected = this.reject(
        control.commandId,
        'STALE_REVISION',
        `Control expected revision ${String(control.expectedStateRevision)}; authority is revision ${String(this.revision)}.`,
        started,
      )
      if (route === 'save') this.remember('save', control, rejected, preparation)
      else this.remember('load', control, rejected, preparation)
      return rejected
    }
    return null
  }

  private reject(
    commandId: string | null,
    reasonCode: RejectionCode,
    message: string,
    started: number,
  ): RejectedResponse {
    const diagnosticMessage = message.trim().length === 0
      ? 'The TypeScript authority rejected the request.'
      : message
    return {
      protocolVersion: PROTOCOL_VERSION,
      schemaId: SCHEMA_ID,
      sessionId: this.sessionId,
      commandId,
      accepted: false,
      reasonCode,
      rejection: rejectionFacts(reasonCode),
      message: diagnosticMessage,
      stateRevision: this.revision,
      gameWeek: this.state.market.tick,
      stateDigest: authoritativeDigest(this.state),
      processingMs: performance.now() - started,
    }
  }

  private priorResponse(
    route: BridgeRuntimeJournalRoute,
    request: SubmitIntentCommand | ControlEnvelope,
    started: number,
  ): CachedResponse | null {
    const prior = this.processed.get(request.commandId)
    if (prior === undefined) return null
    if (prior.entry.route !== route || prior.entry.requestJson !== canonicalJson(request)) {
      return this.reject(
        request.commandId,
        'COMMAND_ID_REUSE',
        'commandId was already used for a different envelope.',
        started,
      )
    }
    return JSON.parse(prior.entry.responseJson) as CachedResponse
  }

  private remember(
    route: 'command',
    request: SubmitIntentCommand,
    response: CommandResponse,
    preparation?: RuntimeCheckpointPreparation,
  ): void
  private remember(
    route: 'save',
    request: ControlEnvelope,
    response: SaveResponse,
    preparation?: RuntimeCheckpointPreparation,
  ): void
  private remember(
    route: 'load',
    request: ControlEnvelope,
    response: CommandResponse,
    preparation?: RuntimeCheckpointPreparation,
  ): void
  private remember(
    route: BridgeRuntimeJournalRoute,
    request: SubmitIntentCommand | ControlEnvelope,
    response: CachedResponse,
    preparation?: RuntimeCheckpointPreparation,
  ): void {
    const entry = this.prepareEntry(
      route,
      request,
      response,
      this.state,
      this.revision,
      this.savedJson,
      preparation,
    )
    this.commitEntry(entry)
  }

  private prepareEntry(
    route: BridgeRuntimeJournalRoute,
    request: SubmitIntentCommand | ControlEnvelope,
    response: CachedResponse,
    nextState: GameState,
    nextRevision: number,
    nextSavedJson: string | null,
    preparation?: RuntimeCheckpointPreparation,
  ): BridgeRuntimeJournalEntryV1 {
    // This private candidate is never committed directly. The complete strict
    // checkpoint boundary below validates canonical request/response schemas,
    // correlation and all authority joins before returning normalized entries.
    const entry: BridgeRuntimeJournalEntryV1 = {
      route,
      commandId: request.commandId,
      requestJson: canonicalJson(request),
      responseJson: canonicalJson(response),
    }
    const checkpointInput = {
      sessionId: this.sessionId,
      stateRevision: nextRevision,
      currentSaveJson: snapshotBuildContextFor(nextState).saveJson(),
      savedSaveJson: nextSavedJson,
    }
    let prospective: EncodedBridgeRuntimeCheckpoint
    try {
      prospective = createEncodedBridgeRuntimeCheckpoint({
        ...checkpointInput,
        journal: [...this.journal, entry],
      }, this.runtimeLimits, preparation?.limits ?? this.runtimeLimits)
    } catch (error) {
      if (!(error instanceof BridgeRuntimeCheckpointCapacityError) || this.journal.length === 0) {
        throw error
      }

      // Only history pressure is recoverable by rollover. Prove the candidate fits alone first.
      createEncodedBridgeRuntimeCheckpoint({
        ...checkpointInput,
        journal: [entry],
      }, this.runtimeLimits, preparation?.limits ?? this.runtimeLimits)
      throw new BridgeRuntimeCheckpointHistoryFullError(error)
    }
    if (preparation !== undefined) preparation.result = { state: nextState, prepared: prospective }
    // The returned artifact may escape to a caller. Its normalized entries must
    // never become the private replay journal's mutable objects.
    return { ...prospective.checkpoint.journal[prospective.checkpoint.journal.length - 1]! }
  }

  private commitEntry(entry: BridgeRuntimeJournalEntryV1): void {
    this.journal.push(entry)
    this.processed.set(entry.commandId, { entry })
  }
}
