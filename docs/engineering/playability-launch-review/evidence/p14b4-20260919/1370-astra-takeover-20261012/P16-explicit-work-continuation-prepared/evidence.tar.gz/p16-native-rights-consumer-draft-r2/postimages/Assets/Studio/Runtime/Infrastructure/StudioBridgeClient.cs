using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Studio.Runtime.Data;
using UnityEngine;
using UnityEngine.Networking;
using Debug = UnityEngine.Debug;

namespace Studio.Runtime.Infrastructure
{
    public enum StudioBridgeConnectionState
    {
        Connecting,
        Live,
        Reconnecting,
        BridgeUnavailable,
        ConfigurationError,
        AuthorizationFailed,
        ProtocolMismatch,
    }

    public readonly struct StudioBridgePlayerWorkflowFact
    {
        internal StudioBridgePlayerWorkflowFact(
            StudioBridgePendingPostOperation operation,
            string commandId,
            string sessionId,
            int attemptRevision,
            string intentKind,
            string intentId,
            Rect buttonScreenRect,
            long uiLayoutRepaintNonce,
            int expectedResponseRevision)
        {
            Operation = operation;
            CommandId = commandId;
            SessionId = sessionId;
            AttemptRevision = attemptRevision;
            IntentKind = intentKind;
            IntentId = intentId;
            ButtonScreenRect = buttonScreenRect;
            UiLayoutRepaintNonce = uiLayoutRepaintNonce;
            ExpectedResponseRevision = expectedResponseRevision;
        }

        public StudioBridgePendingPostOperation Operation { get; }
        public string CommandId { get; }
        public string SessionId { get; }
        public int AttemptRevision { get; }
        public string IntentKind { get; }
        public string IntentId { get; }
        public Rect ButtonScreenRect { get; }
        public long UiLayoutRepaintNonce { get; }
        public int ExpectedResponseRevision { get; }
    }

    [DisallowMultipleComponent]
    public sealed partial class StudioBridgeClient : MonoBehaviour
    {
        private sealed class DeferredPostCompletion
        {
            public StudioBridgePendingPost post;
            public StudioBridgeAcceptedCommandResponse accepted;
            public StudioBridgeSaveResponse saved;
            public StudioBridgeRejectedResponse rejected;
        }

        public const string DefaultBaseUrl = "http://127.0.0.1:4317";

        [SerializeField] private StudioSnapshotProvider provider;
        [SerializeField] private string baseUrl = DefaultBaseUrl;
        [SerializeField, Min(0.25f)] private float pollingSeconds = 1f;
        [SerializeField] private bool showWorkflowPanel = true;

        private bool requestInFlight;
        private bool terminalConnectionFailure;
        private bool sessionHandshakeSucceeded;
        private readonly StudioProjectionStore store = new();
        private readonly StudioRejectionRetention rejectionRetention = new();
        private readonly StudioBridgeRuntimeContinuity runtimeContinuity = new();
        private readonly StudioBridgeSnapshotJoinPolicy snapshotJoinPolicy = new(5);
        private readonly StudioBridgePendingPostLifecycle pendingPostLifecycle = new();
        private StudioBridgeTransport transport;
        private StudioBridgeSnapshotResponse current;
        private DeferredPostCompletion deferredPostCompletion;
        private StudioBridgePendingPost pendingPlayerWorkflowPost;
        private long playerWorkflowUiLayoutRepaintNonce;
        private string feedback = "Connecting to your studio...";
        private Vector2 workflowScroll;
        private float workflowPanelContentHeight;
        private bool worldTimeOwnerPresent;
        private bool castingOwnerPresent;
        private bool systemOwnerPresent;
        // P04A: the one registry of ceded wire-intent kinds. Every declared
        // presentation owner (the Living Time chip for advanceWeek; the
        // casting workspace for startAuditions/acknowledgeAuditions/
        // greenlightPicture) toggles its own kinds here; the memo's NEXT
        // STEPS loop consults it wherever a cede already happens today.
        // Membership only silences a memo BUTTON — the wire intent itself is
        // never removed.
        private readonly HashSet<string> presentIntentOwners = new(StringComparer.Ordinal);
        private StudioBridgeIntentOption[] lastRenderedWorkflowOptions = Array.Empty<StudioBridgeIntentOption>();
        private bool lastWorkflowTimePointerShown;
        private Texture2D workflowPanelSurfaceTexture;
        private GUIStyle panelSurfaceStyle;
        private GUIStyle workflowButtonStyle;
        private GUIStyle titleStyle;
        private GUIStyle headlineStyle;
        private GUIStyle bodyStyle;
        private GUIStyle mutedStyle;
        private GUIStyle blockerStyle;
        private GUIStyle castChoiceButtonStyle;
        private GUIStyle primaryWorkflowButtonStyle;
        private float workflowStylesScale;

        public StudioBridgeConnectionState ConnectionState { get; private set; } = StudioBridgeConnectionState.Connecting;
        public StudioBridgeSnapshotResponse Current => current;
        public StudioRejectionNotice CurrentRejection => rejectionRetention.Visible;
        public StudioProjectionStore Store => store;
        public double LastRoundTripMs { get; private set; }
        public double LastParseMs { get; private set; }
        public double LastApplyMs { get; private set; }
        public int SuccessfulSnapshotPollCount { get; private set; }
        public string Feedback => feedback;
        public bool RequestInFlight => requestInFlight;
        public bool ActionsEnabled =>
            !terminalConnectionFailure && !requestInFlight && !pendingPostLifecycle.HasPending &&
            ConnectionState == StudioBridgeConnectionState.Live &&
            runtimeContinuity.MatchesApplied(current);
        public string RuntimeInstanceId => runtimeContinuity.RuntimeInstanceId;
        public int RuntimeReplacementCount => runtimeContinuity.RuntimeReplacementCount;
        public int TransportOutageCount { get; private set; }
        public int TornReadCount => snapshotJoinPolicy.TornReadCount;
        public bool PendingPost => pendingPostLifecycle.HasPending;
        public string PendingPostRoute => pendingPostLifecycle.Pending?.Route;
        public string PendingPostCommandId => pendingPostLifecycle.Pending?.CommandId;
        public string PendingPostRequestSha256 => pendingPostLifecycle.Pending?.RequestSha256;
        public int AmbiguousPostRetryCount => pendingPostLifecycle.AmbiguousRetryCount;
        public int RecoveredPostCount => pendingPostLifecycle.RecoveredPostCount;
        public string LastRecoveredPostRoute => pendingPostLifecycle.LastRecoveredRoute;
        public string LastRecoveredPostCommandId => pendingPostLifecycle.LastRecoveredCommandId;
        public string LastRecoveredRequestSha256 => pendingPostLifecycle.LastRecoveredRequestSha256;
        public string LastRecoveredResponseSha256 => pendingPostLifecycle.LastRecoveredResponseSha256;
        public bool WorkflowPanelVisible => showWorkflowPanel;
        public int PlayerWorkflowAttemptCount { get; private set; }
        public int PlayerWorkflowAcceptedCount { get; private set; }
        public StudioBridgePlayerWorkflowFact? LastPlayerWorkflowAttempt { get; private set; }
        public StudioBridgePlayerWorkflowFact? LastPlayerWorkflowAccepted { get; private set; }
        public event Action<StudioBridgeSnapshotResponse> SnapshotApplied;
        public event Action<StudioBridgeSnapshotResponse> CommandAccepted;
        public event Action<StudioBridgeRejectedResponse> CommandRejected;
        public event Action<string> SaveCompleted;
        public event Action<StudioBridgeSnapshotResponse> LoadCompleted;

        public void Configure(StudioSnapshotProvider snapshotProvider, string endpoint = null)
        {
            provider = snapshotProvider;
            if (!string.IsNullOrWhiteSpace(endpoint))
            {
                baseUrl = endpoint.TrimEnd('/');
                transport = null;
            }
        }

        public void RecordApplyMilliseconds(double milliseconds) => LastApplyMs = milliseconds;

        public void SetWorkflowPanelVisible(bool visible)
        {
            showWorkflowPanel = visible;
            // P03A.2: hidden memo, honest evidence — a panel that renders
            // nothing must not keep reporting the buttons of its last
            // visible frame.
            if (!visible)
            {
                lastRenderedWorkflowOptions = Array.Empty<StudioBridgeIntentOption>();
                lastWorkflowTimePointerShown = false;
            }
        }

        /// <summary>
        /// P03A.2: true while the persistent Living Time chip — the accepted
        /// world/HUD owner of authoritative time — is lawfully on screen. The
        /// owner declares presence every frame and withdraws it on disable;
        /// while declared, the memo cedes its time verb and only points at
        /// the clock. Fail closed toward playability: with no declared owner
        /// (narrow viewports suppress the chip; legacy scenes never install
        /// it), the memo keeps its classic manual verbs so no viewport is
        /// ever left without a way to advance the week.
        /// </summary>
        public bool WorldTimeOwnerPresent => worldTimeOwnerPresent;

        public void SetWorldTimeOwnerPresent(bool present)
        {
            worldTimeOwnerPresent = present;
            // P04A: the registry becomes the one place cede membership lives;
            // the public getter and the memo's own time-cede line above are
            // untouched, so behavior stays byte-equivalent to before.
            SetIntentCeded(StudioBridgeIntentOptionKindValues.AdvanceWeek, present);
        }

        /// <summary>
        /// P04A: true while a casting workspace declares presence over
        /// startAuditions, acknowledgeAuditions, and greenlightPicture
        /// together. Mirrors WorldTimeOwnerPresent's contract exactly, one
        /// level up: fail closed toward playability — with no declared
        /// owner, the memo keeps its classic manual casting verbs.
        /// </summary>
        public bool CastingOwnerPresent => castingOwnerPresent;

        public void SetCastingOwnerPresent(bool present)
        {
            castingOwnerPresent = present;
            SetIntentCeded(StudioBridgeIntentOptionKindValues.StartAuditions, present);
            SetIntentCeded(StudioBridgeIntentOptionKindValues.AcknowledgeAuditions, present);
            SetIntentCeded(StudioBridgeIntentOptionKindValues.GreenlightPicture, present);
        }

        private void SetIntentCeded(string kind, bool ceded)
        {
            if (ceded) presentIntentOwners.Add(kind);
            else presentIntentOwners.Remove(kind);
        }

        /// <summary>
        /// P04A.1: true while the Studio Menu — the global Resume / Save Game
        /// / Load Game / Quit to Desktop owner (the Owner's missing exit
        /// affordance) — declares itself present and usable. Mirrors
        /// WorldTimeOwnerPresent/CastingOwnerPresent's contract exactly: while
        /// declared, the memo cedes its "Save Studio" / "Load Studio"
        /// buttons; with no declared owner (a disabled or destroyed HUD
        /// withdraws in OnDisable/OnDestroy), the memo keeps them as fallback
        /// — no viewport is ever left without a way to save or load. Save/Load
        /// are POST routes, not wire intents, so unlike the two ceders above
        /// this touches no presentIntentOwners membership.
        /// </summary>
        public bool SystemOwnerPresent => systemOwnerPresent;

        public void SetSystemOwnerPresent(bool present) => systemOwnerPresent = present;

        /// <summary>
        /// P03A.2 proof seam: the intent kinds the memo actually rendered as
        /// buttons on its last repaint. Diagnostics for the journey proofs —
        /// never consulted by gameplay code.
        /// </summary>
        public string[] LastRenderedWorkflowIntentKinds
        {
            get
            {
                var options = lastRenderedWorkflowOptions;
                var kinds = new string[options.Length];
                for (var index = 0; index < options.Length; index++)
                    kinds[index] = options[index]?.kind;
                return kinds;
            }
        }

        /// <summary>P03A.2 proof seam: the memo's clock pointer line rendered on its last repaint.</summary>
        public bool WorkflowTimePointerShown => lastWorkflowTimePointerShown;

        public bool WorkflowPanelContainsScreenPoint(Vector2 screenPoint)
        {
            if (!showWorkflowPanel) return false;
            var guiPoint = new Vector2(screenPoint.x, Screen.height - screenPoint.y);
            // LL-CP7: the panel only swallows pointer input where it actually
            // renders content — the empty envelope below the card belongs to
            // the world again.
            var rect = WorkflowPanelRect();
            if (workflowPanelContentHeight > 0f)
                rect.height = Mathf.Min(rect.height, workflowPanelContentHeight);
            return rect.Contains(guiPoint);
        }

        private void Awake()
        {
            if (provider == null) provider = GetComponent<StudioSnapshotProvider>();
            var environmentUrl = Environment.GetEnvironmentVariable("PROJECT_STUDIO_BRIDGE_URL");
            if (!string.IsNullOrWhiteSpace(environmentUrl)) baseUrl = environmentUrl.TrimEnd('/');
            var args = Environment.GetCommandLineArgs();
            for (var index = 0; index < args.Length - 1; index++)
                if (string.Equals(args[index], "-studioBridgeUrl", StringComparison.OrdinalIgnoreCase))
                    baseUrl = args[index + 1].TrimEnd('/');
        }

        private IEnumerator Start()
        {
            if (!TryConfigureTransport()) yield break;
            while (!terminalConnectionFailure)
            {
                if (!requestInFlight) yield return RefreshAuthority();
                yield return new WaitForSecondsRealtime(pollingSeconds);
            }
        }

        private bool TryConfigureTransport()
        {
            var capability = Environment.GetEnvironmentVariable(
                StudioBridgeTransport.CapabilityEnvironmentVariable);
            Environment.SetEnvironmentVariable(
                StudioBridgeTransport.CapabilityEnvironmentVariable,
                null);
            if (StudioBridgeTransport.TryCreate(baseUrl, capability, out transport, out var error))
                return true;

            terminalConnectionFailure = true;
            ConnectionState = StudioBridgeConnectionState.ConfigurationError;
            feedback = "Studio could not connect. Restart it from the trusted launcher.";
            Debug.LogError($"[Studio Bridge] {error}", this);
            return false;
        }

        public void RequestAdvanceWeek(bool deliberatelyStale = false)
        {
            RequestFirstIntent("advanceWeek", deliberatelyStale);
        }

        public void RequestSuggestedConstruction()
        {
            RequestFirstIntent("startConstruction");
        }

        public StudioBridgeIntentOption FindFirstIntent(string kind)
        {
            if (current?.availableIntents == null || string.IsNullOrWhiteSpace(kind)) return null;
            for (var index = 0; index < current.availableIntents.Length; index++)
            {
                var option = current.availableIntents[index];
                if (option != null && string.Equals(option.kind, kind, StringComparison.Ordinal)) return option;
            }
            return null;
        }

        public bool RequestFirstIntent(string kind, bool deliberatelyStale = false)
        {
            if (!ActionsEnabled)
            {
                feedback = "Your studio is refreshing; actions are temporarily paused.";
                return false;
            }
            var option = FindFirstIntent(kind);
            if (option == null)
            {
                feedback = "That action is not available right now.";
                return false;
            }
            return SubmitIntent(option, deliberatelyStale);
        }

        public bool SubmitIntent(
            StudioBridgeIntentOption option,
            bool deliberatelyStale = false,
            string commandId = null)
        {
            if (!TryCreateIntentPost(option, deliberatelyStale, commandId, out var post)) return false;
            StartCoroutine(PostPending(post, false));
            return true;
        }

        // ── P03A: the commission quote ───────────────────────────────────────
        //
        // A quote is a READ plus a TypeScript-side mint: it mutates no game
        // state, advances no revision, and is never journaled, so it rides its
        // own lightweight single-flight path beside the hardened mutation
        // lifecycle rather than through it. The card submits the eventual
        // commit through the ordinary SubmitIntent path with the quote's own
        // opaque intentId — C# never sees or assembles the engine payload.

        /// <summary>Fired with the validated quote when the authority accepts a draft.</summary>
        public event Action<StudioBridgeQuoteResponse> QuoteAccepted;

        /// <summary>Fired with the authority's structured refusal of a draft.</summary>
        public event Action<StudioBridgeRejectedResponse> QuoteRejected;

        /// <summary>Fired when a quote's outcome could not be resolved; request again.</summary>
        public event Action<string> QuoteUnresolved;

        private bool quoteInFlight;

        public bool QuoteInFlight => quoteInFlight;

        /// <summary>The TypeScript-authored message of the last accepted command.</summary>
        public string LastAcceptedCommandMessage { get; private set; }

        // ── P04A: the casting quote ───────────────────────────────────────
        //
        // Same law as the commission quote above (non-mutating, single-flight,
        // never journaled), asked for a StudioCastingDraftPayload (screen-test
        // slate or greenlight package) instead. It gets its own in-flight
        // guard so a casting ask never blocks, or is blocked by, a commission
        // ask riding the same /quote route at the same time.

        /// <summary>Fired with the validated quote when the authority accepts a casting draft.</summary>
        public event Action<StudioBridgeQuoteResponse> CastingQuoteAccepted;

        /// <summary>Fired with the authority's structured refusal of a casting draft.</summary>
        public event Action<StudioBridgeRejectedResponse> CastingQuoteRejected;

        /// <summary>Fired when a casting quote's outcome could not be resolved; request again.</summary>
        public event Action<string> CastingQuoteUnresolved;

        private bool castingQuoteInFlight;

        public bool CastingQuoteInFlight => castingQuoteInFlight;

        /// <summary>
        /// Posts the player's current commission draft for an authoritative
        /// quote. Returns the minted commandId, or null when the client cannot
        /// ask right now (not live, another quote in flight, or no draft).
        /// </summary>
        public string RequestCommissionQuote(StudioCommissionDraftPayload draft, string commandId = null)
        {
            if (commandId != null && string.IsNullOrWhiteSpace(commandId))
                throw new ArgumentException("Injected bridge commandId cannot be blank.", nameof(commandId));
            if (draft == null || quoteInFlight || terminalConnectionFailure ||
                ConnectionState != StudioBridgeConnectionState.Live || current == null)
                return null;
            commandId ??= Guid.NewGuid().ToString("N");
            var json = StudioBridgeJson.Quote(current.sessionId, commandId, current.stateRevision, draft);
            StartCoroutine(PostQuote(json, commandId));
            return commandId;
        }

        private IEnumerator PostQuote(string json, string commandId)
        {
            quoteInFlight = true;
            using var request = transport.PostUtf8("/quote", System.Text.Encoding.UTF8.GetBytes(json));
            yield return request.SendWebRequest();
            quoteInFlight = false;
            if (IsTerminalBoundaryFailure(request))
            {
                HandleTransportFailure(request, "commission quote");
                yield break;
            }
            if (IsAmbiguousPostFailure(request))
            {
                // Non-mutating by law: nothing to reconcile, simply ask again.
                QuoteUnresolved?.Invoke("The quote could not be resolved; the studio will re-ask.");
                yield break;
            }
            var body = request.downloadHandler?.text;
            if (request.responseCode >= 200 && request.responseCode < 300)
            {
                StudioBridgeQuoteResponse quoted;
                try
                {
                    quoted = StudioBridgeJson.ParseQuoteResponse(body);
                    if (quoted.commandId != commandId)
                        throw new StudioSnapshotFormatException("Bridge quote answered a different commandId.");
                }
                catch (StudioSnapshotFormatException formatFailure)
                {
                    SetProtocolMismatch(formatFailure.Message);
                    yield break;
                }
                QuoteAccepted?.Invoke(quoted);
                yield break;
            }
            StudioBridgeRejectedResponse rejected;
            try
            {
                rejected = StudioBridgeJson.ParseRejectedResponse(body);
            }
            catch (StudioSnapshotFormatException formatFailure)
            {
                SetProtocolMismatch(formatFailure.Message);
                yield break;
            }
            if (rejected.commandId == commandId) QuoteRejected?.Invoke(rejected);
        }

        /// <summary>
        /// Posts the player's current casting draft (screen-test slate or
        /// greenlight package) for an authoritative quote. Mirrors
        /// RequestCommissionQuote's contract exactly. The generated
        /// StudioBridgeQuoteRequest.draft field is typed to the commission
        /// payload only (a union-merge artifact that keeps the first
        /// member's shape), so the envelope here is built directly from the
        /// correctly-generated standalone StudioQuoteCastingRequest instead
        /// — never the generated file itself, only how it is used.
        /// </summary>
        public string RequestCastingQuote(StudioCastingDraftPayload draft, string commandId = null)
        {
            if (commandId != null && string.IsNullOrWhiteSpace(commandId))
                throw new ArgumentException("Injected bridge commandId cannot be blank.", nameof(commandId));
            if (draft == null || castingQuoteInFlight || terminalConnectionFailure ||
                ConnectionState != StudioBridgeConnectionState.Live || current == null)
                return null;
            commandId ??= Guid.NewGuid().ToString("N");
            var json = JsonConvert.SerializeObject(
                new StudioQuoteCastingRequest
                {
                    protocolVersion = StudioBridgeContract.ProtocolVersion,
                    schemaId = StudioBridgeContract.SchemaId,
                    sessionId = current.sessionId,
                    commandId = commandId,
                    expectedStateRevision = current.stateRevision,
                    type = StudioBridgeQuoteRequestTypeValues.QuoteCasting,
                    draft = draft,
                },
                Formatting.None,
                StudioBridgeContract.CreateStrictJsonSettings());
            StartCoroutine(PostCastingQuote(json, commandId));
            return commandId;
        }

        private IEnumerator PostCastingQuote(string json, string commandId)
        {
            castingQuoteInFlight = true;
            using var request = transport.PostUtf8("/quote", System.Text.Encoding.UTF8.GetBytes(json));
            yield return request.SendWebRequest();
            castingQuoteInFlight = false;
            if (IsTerminalBoundaryFailure(request))
            {
                HandleTransportFailure(request, "casting quote");
                yield break;
            }
            if (IsAmbiguousPostFailure(request))
            {
                // Non-mutating by law: nothing to reconcile, simply ask again.
                CastingQuoteUnresolved?.Invoke("The quote could not be resolved; the studio will re-ask.");
                yield break;
            }
            var body = request.downloadHandler?.text;
            if (request.responseCode >= 200 && request.responseCode < 300)
            {
                StudioBridgeQuoteResponse quoted;
                try
                {
                    // StudioBridgeQuoteResponse.quote is StudioQuoteSnapshot —
                    // the generator's flattened member-union of
                    // StudioCommissionQuoteSnapshot and
                    // StudioCastingQuoteSnapshot, not a discriminated type.
                    // Every casting field (negative, marketing,
                    // freelancerFees, totalImmediate, cashBefore, cashAfter,
                    // affordable, strongestAssignmentLine,
                    // weakestAssignmentLine, forecastLine, setDemandLine,
                    // weekLine, slotLine, noFeeLine, noHoldLine,
                    // uniquePeople, queueNote) already lives directly on
                    // quoted.quote; callers branch on quoted.quote.kind.
                    quoted = StudioBridgeJson.ParseQuoteResponse(body);
                    if (quoted.commandId != commandId)
                        throw new StudioSnapshotFormatException("Bridge quote answered a different commandId.");
                }
                catch (StudioSnapshotFormatException formatFailure)
                {
                    SetProtocolMismatch(formatFailure.Message);
                    yield break;
                }
                CastingQuoteAccepted?.Invoke(quoted);
                yield break;
            }
            StudioBridgeRejectedResponse rejected;
            try
            {
                rejected = StudioBridgeJson.ParseRejectedResponse(body);
            }
            catch (StudioSnapshotFormatException formatFailure)
            {
                SetProtocolMismatch(formatFailure.Message);
                yield break;
            }
            if (rejected.commandId == commandId) CastingQuoteRejected?.Invoke(rejected);
        }

        private bool TryCreateIntentPost(
            StudioBridgeIntentOption option,
            bool deliberatelyStale,
            string commandId,
            out StudioBridgePendingPost post)
        {
            post = null;
            if (commandId != null && string.IsNullOrWhiteSpace(commandId))
                throw new ArgumentException("Injected bridge commandId cannot be blank.", nameof(commandId));
            if (!ActionsEnabled || option == null || string.IsNullOrWhiteSpace(option.intentId)) return false;
            // C# echoes the opaque TypeScript-issued identity. It never reconstructs an
            // engine payload from the label, title, role, or presentation fields.
            var revision = deliberatelyStale ? Math.Max(0, current.stateRevision - 1) : current.stateRevision;
            commandId ??= Guid.NewGuid().ToString("N");
            var json = StudioBridgeJson.SubmitIntent(current.sessionId, commandId, revision, option.intentId);
            post = BeginPendingPost(
                StudioBridgePendingPostOperation.Command,
                json,
                commandId,
                revision);
            return true;
        }

        public bool RequestStaleIntent()
        {
            if (current?.availableIntents == null || current.availableIntents.Length == 0)
            {
                feedback = "No studio action is available right now.";
                return false;
            }
            return SubmitIntent(current.availableIntents[0], true);
        }

        public bool SaveAuthoritativeGame() => StartSimple(false, null);
        public bool SaveAuthoritativeGame(string commandId) => StartSimple(false, commandId);
        public bool LoadAuthoritativeGame() => StartSimple(true, null);
        public bool LoadAuthoritativeGame(string commandId) => StartSimple(true, commandId);

        private bool StartSimple(bool load, string commandId)
        {
            if (!TryCreateSimplePost(load, commandId, out var post)) return false;
            StartCoroutine(PostPending(post, false));
            return true;
        }

        private bool TryCreateSimplePost(
            bool load,
            string commandId,
            out StudioBridgePendingPost post)
        {
            post = null;
            if (commandId != null && string.IsNullOrWhiteSpace(commandId))
                throw new ArgumentException("Injected bridge commandId cannot be blank.", nameof(commandId));
            if (!ActionsEnabled) return false;
            var operation = load
                ? StudioBridgePendingPostOperation.Load
                : StudioBridgePendingPostOperation.Save;
            commandId ??= Guid.NewGuid().ToString("N");
            var json = StudioBridgeJson.Control(current.sessionId, commandId, current.stateRevision);
            post = BeginPendingPost(operation, json, commandId, current.stateRevision);
            return true;
        }

        private static bool PlayerWorkflowButton(
            string label,
            GUIStyle style,
            out Rect buttonScreenRect,
            params GUILayoutOption[] options)
        {
            var content = new GUIContent(label);
            var guiRect = GUILayoutUtility.GetRect(content, style, options);
            var screenPosition = GUIUtility.GUIToScreenPoint(guiRect.position);
            buttonScreenRect = new Rect(screenPosition, guiRect.size);
            return GUI.Button(guiRect, content, style);
        }

        private bool SubmitPlayerWorkflowIntent(
            StudioBridgeIntentOption option,
            Rect buttonScreenRect)
        {
            if (!TryCapturePlayerWorkflowButtonEvidence(buttonScreenRect, out var uiNonce))
                return false;
            var commandId = Guid.NewGuid().ToString("N");
            if (!TryCreateIntentPost(option, false, commandId, out var post)) return false;
            CapturePlayerWorkflowAttempt(post, option.kind, option.intentId, buttonScreenRect, uiNonce);
            StartCoroutine(PostPending(post, false));
            return true;
        }

        private bool SavePlayerWorkflow(Rect buttonScreenRect)
        {
            if (!TryCapturePlayerWorkflowButtonEvidence(buttonScreenRect, out var uiNonce))
                return false;
            var commandId = Guid.NewGuid().ToString("N");
            if (!TryCreateSimplePost(false, commandId, out var post)) return false;
            CapturePlayerWorkflowAttempt(post, null, null, buttonScreenRect, uiNonce);
            StartCoroutine(PostPending(post, false));
            return true;
        }

        private bool LoadPlayerWorkflow(Rect buttonScreenRect)
        {
            if (!TryCapturePlayerWorkflowButtonEvidence(buttonScreenRect, out var uiNonce))
                return false;
            var commandId = Guid.NewGuid().ToString("N");
            if (!TryCreateSimplePost(true, commandId, out var post)) return false;
            CapturePlayerWorkflowAttempt(post, null, null, buttonScreenRect, uiNonce);
            StartCoroutine(PostPending(post, false));
            return true;
        }

        private bool TryCapturePlayerWorkflowButtonEvidence(
            Rect buttonScreenRect,
            out long uiLayoutRepaintNonce)
        {
            uiLayoutRepaintNonce = playerWorkflowUiLayoutRepaintNonce;
            return IsValidPlayerWorkflowButtonRect(buttonScreenRect, Screen.width, Screen.height) &&
                   uiLayoutRepaintNonce > 0;
        }

        private void CapturePlayerWorkflowAttempt(
            StudioBridgePendingPost post,
            string intentKind,
            string intentId,
            Rect buttonScreenRect,
            long uiLayoutRepaintNonce)
        {
            if (post == null) throw new ArgumentNullException(nameof(post));
            if (pendingPlayerWorkflowPost != null)
                throw new InvalidOperationException("A player workflow action is already pending.");
            if (!IsValidPlayerWorkflowButtonRect(buttonScreenRect, Screen.width, Screen.height))
                throw new ArgumentOutOfRangeException(nameof(buttonScreenRect));
            if (uiLayoutRepaintNonce <= 0)
                throw new ArgumentOutOfRangeException(nameof(uiLayoutRepaintNonce));

            var expectedResponseRevision = post.Operation == StudioBridgePendingPostOperation.Save
                ? post.ExpectedStateRevision
                : post.ExpectedStateRevision + 1;
            pendingPlayerWorkflowPost = post;
            PlayerWorkflowAttemptCount++;
            LastPlayerWorkflowAttempt = new StudioBridgePlayerWorkflowFact(
                post.Operation,
                post.CommandId,
                post.OriginatingSessionId,
                post.ExpectedStateRevision,
                intentKind,
                intentId,
                buttonScreenRect,
                uiLayoutRepaintNonce,
                expectedResponseRevision);
        }

        private bool TryAcceptPlayerWorkflowPost(
            StudioBridgePendingPost post,
            string responseCommandId,
            string responseSessionId,
            int responseRevision)
        {
            if (pendingPlayerWorkflowPost == null)
                return true;
            if (!ReferenceEquals(post, pendingPlayerWorkflowPost) ||
                !LastPlayerWorkflowAttempt.HasValue)
            {
                SetProtocolMismatch("Accepted player workflow response did not match its retained action.");
                return false;
            }

            var attempt = LastPlayerWorkflowAttempt.Value;
            if (attempt.Operation != post.Operation ||
                !string.Equals(attempt.CommandId, responseCommandId, StringComparison.Ordinal) ||
                !string.Equals(attempt.SessionId, responseSessionId, StringComparison.Ordinal) ||
                attempt.ExpectedResponseRevision != responseRevision)
            {
                SetProtocolMismatch("Accepted player workflow response changed its command, session, or revision.");
                return false;
            }

            pendingPlayerWorkflowPost = null;
            PlayerWorkflowAcceptedCount++;
            LastPlayerWorkflowAccepted = attempt;
            return true;
        }

        private void AbandonPendingPlayerWorkflow(StudioBridgePendingPost post = null)
        {
            if (post == null || ReferenceEquals(post, pendingPlayerWorkflowPost))
                pendingPlayerWorkflowPost = null;
        }

        private static bool IsValidPlayerWorkflowButtonRect(Rect rect, int screenWidth, int screenHeight) =>
            screenWidth > 0 &&
            screenHeight > 0 &&
            IsFinite(rect.xMin) &&
            IsFinite(rect.yMin) &&
            IsFinite(rect.xMax) &&
            IsFinite(rect.yMax) &&
            rect.xMin >= 0f &&
            rect.yMin >= 0f &&
            rect.width > 1f &&
            rect.height > 1f &&
            rect.xMax <= screenWidth &&
            rect.yMax <= screenHeight;

        private static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        private StudioBridgePendingPost BeginPendingPost(
            StudioBridgePendingPostOperation operation,
            string json,
            string commandId,
            int expectedRevision) => pendingPostLifecycle.Begin(
                operation,
                StudioBridgePendingPostLifecycle.RouteFor(operation),
                Encoding.UTF8.GetBytes(json),
                commandId,
                current.sessionId,
                expectedRevision,
                current.stateRevision,
                current.gameWeek,
                current.stateDigest);

        private IEnumerator RefreshAuthority()
        {
            sessionHandshakeSucceeded = false;
            yield return FetchSession();
            if (!sessionHandshakeSucceeded || terminalConnectionFailure) yield break;

            var pendingDecision = pendingPostLifecycle.ObserveSession(
                runtimeContinuity.SessionId,
                out var retry);
            if (pendingDecision == StudioBridgePendingPostSessionDecision.DiscardSessionChanged)
            {
                deferredPostCompletion = null;
                AbandonPendingPlayerWorkflow();
                feedback = "The authoritative session changed; the unresolved action was not retried.";
            }
            else if (pendingDecision == StudioBridgePendingPostSessionDecision.RetryExactEnvelope)
            {
                yield return PostPending(retry, true);
                if (terminalConnectionFailure ||
                    pendingPostLifecycle.AwaitingSessionValidation ||
                    !sessionHandshakeSucceeded)
                    yield break;
            }

            yield return FetchSnapshot();
            if (!terminalConnectionFailure &&
                ConnectionState == StudioBridgeConnectionState.Live &&
                deferredPostCompletion != null)
                FinalizeDeferredPostCompletion();
        }

        private IEnumerator FetchSession()
        {
            requestInFlight = true;
            ConnectionState = current == null
                ? StudioBridgeConnectionState.Connecting
                : StudioBridgeConnectionState.Reconnecting;
            using var request = transport.Get("/session");
            request.timeout = 3;
            var clock = Stopwatch.StartNew();
            yield return request.SendWebRequest();
            clock.Stop();
            LastRoundTripMs = clock.Elapsed.TotalMilliseconds;
            requestInFlight = false;
            if (request.result != UnityWebRequest.Result.Success)
            {
                HandleTransportFailure(request, "session handshake");
                yield break;
            }

            try
            {
                var response = StudioBridgeJson.ParseSession(request.downloadHandler.text);
                var transition = runtimeContinuity.Observe(response);
                if (transition == StudioBridgeRuntimeTransition.RuntimeAndSessionChanged ||
                    transition == StudioBridgeRuntimeTransition.SessionChanged)
                    rejectionRetention.OnAuthoritySessionChanged();
                if (transition == StudioBridgeRuntimeTransition.RuntimeReplaced ||
                    transition == StudioBridgeRuntimeTransition.RuntimeAndSessionChanged)
                    feedback = "The studio service restarted; your view is refreshing.";
                else if (transition == StudioBridgeRuntimeTransition.SessionChanged)
                    feedback = "The authoritative studio session changed; presentation is refreshing.";
                sessionHandshakeSucceeded = true;
            }
            catch (StudioSnapshotFormatException exception)
            {
                SetProtocolMismatch(exception.Message);
            }
        }

        private IEnumerator FetchSnapshot()
        {
            requestInFlight = true;
            if (current == null) ConnectionState = StudioBridgeConnectionState.Connecting;
            else ConnectionState = StudioBridgeConnectionState.Reconnecting;
            using var request = transport.Get("/snapshot");
            request.timeout = 3;
            var clock = Stopwatch.StartNew();
            yield return request.SendWebRequest();
            clock.Stop();
            LastRoundTripMs = clock.Elapsed.TotalMilliseconds;
            requestInFlight = false;
            if (request.result != UnityWebRequest.Result.Success)
            {
                HandleTransportFailure(request, "snapshot refresh");
                yield break;
            }
            ApplySnapshotJson(request.downloadHandler.text);
        }

        private IEnumerator PostPending(StudioBridgePendingPost post, bool exactRetry)
        {
            requestInFlight = true;
            feedback = exactRetry
                ? $"Recovering unresolved {OperationName(post.Operation)}…"
                : $"Submitting {OperationName(post.Operation)}…";
            using var request = transport.PostUtf8(post.Route, post.CopyRequestBodyUtf8());
            var clock = Stopwatch.StartNew();
            yield return request.SendWebRequest();
            clock.Stop();
            LastRoundTripMs = clock.Elapsed.TotalMilliseconds;
            requestInFlight = false;

            if (IsTerminalBoundaryFailure(request))
            {
                pendingPostLifecycle.Abandon(post);
                AbandonPendingPlayerWorkflow(post);
                HandleTransportFailure(request, OperationName(post.Operation));
                yield break;
            }
            if (IsAmbiguousPostFailure(request))
            {
                pendingPostLifecycle.MarkTransportLost(post);
                HandleTransportFailure(request, OperationName(post.Operation));
                feedback = "The action outcome is unresolved; reconnecting safely before retrying.";
                yield break;
            }

            var responseBody = request.downloadHandler?.data;
            if (request.responseCode >= 200 && request.responseCode < 300)
            {
                HandleAcceptedPost(post, request.downloadHandler.text, responseBody, exactRetry);
                yield break;
            }

            if (exactRetry)
                HandleRecoveredRejection(post, request.downloadHandler?.text, responseBody);
            else
            {
                pendingPostLifecycle.CompleteInitialResponse(post);
                AbandonPendingPlayerWorkflow(post);
                HandleRejection(
                    request.downloadHandler?.text,
                    request.error,
                    post.OriginatingSessionId,
                    post.CommandId);
            }
        }

        private void HandleAcceptedPost(
            StudioBridgePendingPost post,
            string json,
            byte[] responseBody,
            bool exactRetry)
        {
            try
            {
                if (post.Operation == StudioBridgePendingPostOperation.Save)
                {
                    var saved = StudioBridgeJson.ParseSaveResponse(json);
                    RequireMatchingSaveResponse(post, saved);
                    if (exactRetry)
                    {
                        var join = ReconcileRetryResponse(post, saved, true);
                        if (!RequireNonFatalJoin(join)) return;
                        deferredPostCompletion = new DeferredPostCompletion
                        {
                            post = post,
                            saved = saved,
                        };
                        pendingPostLifecycle.RecordRetryResponse(post, responseBody);
                        feedback = "Save recovered; refreshing your studio.";
                        return;
                    }

                    pendingPostLifecycle.CompleteInitialResponse(post);
                    if (!TryAcceptPlayerWorkflowPost(
                            post,
                            saved.commandId,
                            saved.sessionId,
                            saved.stateRevision))
                        return;
                    feedback = "Studio saved.";
                    rejectionRetention.OnSaveAccepted();
                    SaveCompleted?.Invoke(saved.stateDigest);
                    return;
                }

                var accepted = StudioBridgeJson.ParseAcceptedCommand(json);
                RequireMatchingAcceptedResponse(post, accepted);
                // P03A: the authority's own acceptance sentence survives the
                // snapshot conversion for any card that wants to speak it.
                LastAcceptedCommandMessage = accepted.message;
                var acceptedSnapshot = accepted.ToSnapshotResponse();
                if (exactRetry)
                {
                    var join = ReconcileRetryResponse(post, accepted, true);
                    if (!RequireNonFatalJoin(join)) return;
                    if (join.Disposition != StudioBridgePendingPostResponseDisposition.HistoricalCompletion)
                    {
                        runtimeContinuity.AcceptAuthoritativeResponse(acceptedSnapshot);
                        ApplySnapshot(acceptedSnapshot);
                    }
                    deferredPostCompletion = new DeferredPostCompletion
                    {
                        post = post,
                        accepted = accepted,
                    };
                    pendingPostLifecycle.RecordRetryResponse(post, responseBody);
                    feedback = "Action recovered; refreshing your studio.";
                    return;
                }

                runtimeContinuity.AcceptAuthoritativeResponse(acceptedSnapshot);
                ApplySnapshot(acceptedSnapshot);
                pendingPostLifecycle.CompleteInitialResponse(post);
                if (!TryAcceptPlayerWorkflowPost(
                        post,
                        accepted.commandId,
                        accepted.sessionId,
                        accepted.stateRevision))
                    return;
                if (post.Operation == StudioBridgePendingPostOperation.Command)
                {
                    rejectionRetention.OnCommandAccepted();
                    feedback = "Studio action completed.";
                    CommandAccepted?.Invoke(acceptedSnapshot);
                }
                else
                {
                    rejectionRetention.OnLoadAccepted();
                    feedback = "Studio loaded.";
                    LoadCompleted?.Invoke(acceptedSnapshot);
                }
            }
            catch (StudioSnapshotFormatException exception)
            {
                SetProtocolMismatch(exception.Message);
            }
        }

        private void HandleRecoveredRejection(
            StudioBridgePendingPost post,
            string json,
            byte[] responseBody)
        {
            StudioBridgeRejectedResponse rejected;
            try
            {
                rejected = StudioBridgeJson.ParseRejectedResponse(json);
            }
            catch (StudioSnapshotFormatException exception)
            {
                SetProtocolMismatch(exception.Message);
                return;
            }

            if (!string.Equals(rejected.commandId, post.CommandId, StringComparison.Ordinal))
            {
                SetProtocolMismatch("Recovered rejection commandId does not match the retained POST.");
                return;
            }
            AbandonPendingPlayerWorkflow(post);
            if (string.Equals(
                rejected.reasonCode,
                StudioBridgeRejectedResponseReasonCodeValues.SESSIONMISMATCH,
                StringComparison.Ordinal))
            {
                pendingPostLifecycle.Abandon(post);
                rejectionRetention.OnAuthoritySessionChanged();
                sessionHandshakeSucceeded = false;
                ConnectionState = StudioBridgeConnectionState.Reconnecting;
                feedback = "The authoritative session changed; the unresolved action was not retried again.";
                CommandRejected?.Invoke(rejected);
                return;
            }
            if (string.Equals(
                rejected.reasonCode,
                StudioBridgeRejectedResponseReasonCodeValues.COMMANDIDREUSE,
                StringComparison.Ordinal))
            {
                SetProtocolMismatch("Exact bridge retry conflicted with the durable command identity.");
                return;
            }
            if (!string.Equals(rejected.sessionId, post.OriginatingSessionId, StringComparison.Ordinal))
            {
                SetProtocolMismatch("Recovered rejection changed logical session identity.");
                return;
            }

            var join = ReconcileRetryResponse(post, rejected, false, rejected.reasonCode);
            if (!RequireNonFatalJoin(join)) return;
            deferredPostCompletion = new DeferredPostCompletion
            {
                post = post,
                rejected = rejected,
            };
            pendingPostLifecycle.RecordRetryResponse(post, responseBody);
            if (join.Disposition == StudioBridgePendingPostResponseDisposition.AuthorityAdvancedRejection)
                sessionHandshakeSucceeded = false;
            feedback = "Action outcome recovered; refreshing your studio.";
        }

        private void RequireMatchingAcceptedResponse(
            StudioBridgePendingPost post,
            StudioBridgeAcceptedCommandResponse accepted)
        {
            if (!string.Equals(accepted.sessionId, post.OriginatingSessionId, StringComparison.Ordinal))
                throw new StudioSnapshotFormatException("Accepted action response changed bridge session identity.");
            if (!string.Equals(accepted.commandId, post.CommandId, StringComparison.Ordinal))
                throw new StudioSnapshotFormatException(
                    "Accepted action response commandId does not match the retained POST.");
            if (accepted.stateRevision != post.ExpectedStateRevision + 1)
                throw new StudioSnapshotFormatException(
                    $"Accepted action revision must be {post.ExpectedStateRevision + 1}; " +
                    $"received {accepted.stateRevision}.");
        }

        private void RequireMatchingSaveResponse(
            StudioBridgePendingPost post,
            StudioBridgeSaveResponse saved)
        {
            if (!string.Equals(saved.sessionId, post.OriginatingSessionId, StringComparison.Ordinal) ||
                !string.Equals(saved.commandId, post.CommandId, StringComparison.Ordinal) ||
                saved.stateRevision != post.ExpectedStateRevision ||
                saved.gameWeek != post.OriginatingGameWeek ||
                !string.Equals(saved.stateDigest, post.OriginatingStateDigest, StringComparison.Ordinal) ||
                string.IsNullOrWhiteSpace(saved.saveJson))
                throw new StudioSnapshotFormatException(
                    "TypeScript save response failed retained authority validation.");
        }

        private StudioBridgePendingPostResponseJoin ReconcileRetryResponse(
            StudioBridgePendingPost post,
            StudioBridgeAcceptedCommandResponse response,
            bool accepted) => ReconcileRetryResponse(
                post,
                response.sessionId,
                response.stateRevision,
                response.gameWeek,
                response.stateDigest,
                accepted);

        private StudioBridgePendingPostResponseJoin ReconcileRetryResponse(
            StudioBridgePendingPost post,
            StudioBridgeSaveResponse response,
            bool accepted) => ReconcileRetryResponse(
                post,
                response.sessionId,
                response.stateRevision,
                response.gameWeek,
                response.stateDigest,
                accepted);

        private StudioBridgePendingPostResponseJoin ReconcileRetryResponse(
            StudioBridgePendingPost post,
            StudioBridgeRejectedResponse response,
            bool accepted,
            string reasonCode) => ReconcileRetryResponse(
                post,
                response.sessionId,
                response.stateRevision,
                response.gameWeek,
                response.stateDigest,
                accepted,
                reasonCode);

        private StudioBridgePendingPostResponseJoin ReconcileRetryResponse(
            StudioBridgePendingPost post,
            string sessionId,
            int stateRevision,
            int gameWeek,
            string stateDigest,
            bool accepted,
            string reasonCode = null) => StudioBridgePendingPostLifecycle.ReconcileRetryResponse(
                post,
                new StudioBridgeAuthorityStamp(
                    runtimeContinuity.SessionId,
                    runtimeContinuity.StateRevision,
                    runtimeContinuity.GameWeek,
                    runtimeContinuity.StateDigest),
                new StudioBridgeAuthorityStamp(sessionId, stateRevision, gameWeek, stateDigest),
                accepted,
                reasonCode);

        private bool RequireNonFatalJoin(StudioBridgePendingPostResponseJoin join)
        {
            if (join.Disposition != StudioBridgePendingPostResponseDisposition.FatalContradiction)
                return true;
            SetProtocolMismatch(join.Error ?? "Recovered bridge response contradicted its session handshake.");
            return false;
        }

        private void FinalizeDeferredPostCompletion()
        {
            var completion = deferredPostCompletion;
            if (completion == null || current == null) return;

            if (completion.rejected != null && RejectionMatchesCurrent(completion.rejected))
            {
                var guidance = completion.rejected.rejection;
                var notice = new StudioRejectionNotice(
                    completion.rejected.sessionId,
                    completion.rejected.stateRevision,
                    completion.rejected.stateDigest,
                    completion.rejected.reasonCode,
                    guidance.category,
                    completion.rejected.message,
                    guidance.blocker,
                    guidance.currentHolder,
                    guidance.remedy);
                if (!rejectionRetention.TryRetain(notice))
                {
                    SetProtocolMismatch("Recovered rejection could not join the refreshed authoritative state.");
                    return;
                }
            }

            pendingPostLifecycle.CompleteRecoveredResponse(completion.post);
            deferredPostCompletion = null;
            if (completion.saved != null)
            {
                if (!TryAcceptPlayerWorkflowPost(
                        completion.post,
                        completion.saved.commandId,
                        completion.saved.sessionId,
                        completion.saved.stateRevision))
                    return;
                rejectionRetention.OnSaveAccepted();
                feedback = "Studio save recovered after reconnecting.";
                SaveCompleted?.Invoke(completion.saved.stateDigest);
                return;
            }
            if (completion.accepted != null)
            {
                if (!TryAcceptPlayerWorkflowPost(
                        completion.post,
                        completion.accepted.commandId,
                        completion.accepted.sessionId,
                        completion.accepted.stateRevision))
                    return;
                LastAcceptedCommandMessage = completion.accepted.message;
                var eventSnapshot = StudioBridgePendingPostLifecycle.SelectFreshCompletionSnapshot(
                    completion.accepted.ToSnapshotResponse(),
                    current);
                if (completion.post.Operation == StudioBridgePendingPostOperation.Command)
                {
                    rejectionRetention.OnCommandAccepted();
                    feedback = "Studio action recovered after reconnecting.";
                    CommandAccepted?.Invoke(eventSnapshot);
                }
                else
                {
                    rejectionRetention.OnLoadAccepted();
                    feedback = "Studio load recovered after reconnecting.";
                    LoadCompleted?.Invoke(eventSnapshot);
                }
                return;
            }

            var rejected = completion.rejected;
            if (rejected == null)
            {
                SetProtocolMismatch("Recovered bridge completion has no authoritative response.");
                return;
            }
            if (RejectionMatchesCurrent(rejected))
            {
                feedback = "The studio could not carry out the recovered action.";
                Debug.LogWarning(
                    $"[Studio Bridge] recovered rejection {rejected.rejection.category}/{rejected.reasonCode}: " +
                    rejected.message,
                    this);
                CommandRejected?.Invoke(rejected);
            }
            else
            {
                feedback = "The prior action outcome was recovered; your studio has since moved forward.";
            }
        }

        private bool RejectionMatchesCurrent(StudioBridgeRejectedResponse rejected) =>
            rejected != null && current != null &&
            StudioBridgePendingPostLifecycle.MatchesAuthority(
                new StudioBridgeAuthorityStamp(
                    rejected.sessionId,
                    rejected.stateRevision,
                    rejected.gameWeek,
                    rejected.stateDigest),
                new StudioBridgeAuthorityStamp(
                    current.sessionId,
                    current.stateRevision,
                    current.gameWeek,
                    current.stateDigest));

        private static string OperationName(StudioBridgePendingPostOperation operation)
        {
            switch (operation)
            {
                case StudioBridgePendingPostOperation.Command:
                    return "intent submission";
                case StudioBridgePendingPostOperation.Save:
                    return "save";
                case StudioBridgePendingPostOperation.Load:
                    return "load";
                default:
                    return "bridge action";
            }
        }

        private void ApplySnapshotJson(string json)
        {
            var parse = Stopwatch.StartNew();
            try
            {
                var response = StudioBridgeJson.ParseSnapshot(json);
                var join = snapshotJoinPolicy.Observe(runtimeContinuity.MatchesHandshake(response));
                if (join != StudioBridgeSnapshotJoinDecision.Apply)
                {
                    parse.Stop();
                    if (join == StudioBridgeSnapshotJoinDecision.Fatal)
                        SetProtocolMismatch(
                            "The local engine repeatedly changed authority between its session and snapshot responses.");
                    else
                    {
                        ConnectionState = StudioBridgeConnectionState.Reconnecting;
                        feedback = "The authoritative studio state advanced during refresh; retrying before actions resume.";
                    }
                    return;
                }
                parse.Stop();
                LastParseMs = parse.Elapsed.TotalMilliseconds;
                ApplySnapshot(response);
                SuccessfulSnapshotPollCount++;
            }
            catch (StudioSnapshotFormatException exception)
            {
                parse.Stop();
                SetProtocolMismatch(exception.Message);
            }
        }

        private void ApplySnapshot(StudioBridgeSnapshotResponse response)
        {
            var delta = store.Apply(response);
            current = store.Current;
            rejectionRetention.ObserveSnapshot(
                current.sessionId,
                current.stateRevision,
                current.stateDigest);
            ConnectionState = StudioBridgeConnectionState.Live;
            feedback = $"Ready · Week {response.gameWeek}";
            if (delta.applied) SnapshotApplied?.Invoke(response);
        }

        private void HandleRejection(
            string json,
            string fallback,
            string expectedSessionId = null,
            string expectedCommandId = null)
        {
            StudioBridgeRejectedResponse rejected = null;
            if (!string.IsNullOrWhiteSpace(json))
            {
                try
                {
                    rejected = StudioBridgeJson.ParseRejectedResponse(json);
                }
                catch (StudioSnapshotFormatException exception)
                {
                    SetProtocolMismatch(exception.Message);
                    return;
                }
            }
            if (rejected == null)
            {
                SetProtocolMismatch(fallback ?? "Bridge returned an empty rejection response.");
                return;
            }
            if (string.Equals(
                rejected.reasonCode,
                StudioBridgeRejectedResponseReasonCodeValues.SESSIONMISMATCH,
                StringComparison.Ordinal))
            {
                if (expectedCommandId != null &&
                    !string.Equals(rejected.commandId, expectedCommandId, StringComparison.Ordinal))
                {
                    SetProtocolMismatch("Session-mismatch response commandId does not match the submitted request.");
                    return;
                }
                rejectionRetention.OnAuthoritySessionChanged();
                pendingPostLifecycle.AbandonAll();
                deferredPostCompletion = null;
                AbandonPendingPlayerWorkflow();
                sessionHandshakeSucceeded = false;
                ConnectionState = StudioBridgeConnectionState.Reconnecting;
                feedback = "The authoritative studio session changed; the previous action was discarded while truth refreshes.";
                CommandRejected?.Invoke(rejected);
                return;
            }
            if (rejected.protocolVersion != StudioBridgeContract.ProtocolVersion ||
                !string.Equals(rejected.schemaId, StudioBridgeContract.SchemaId, StringComparison.Ordinal) ||
                (expectedSessionId != null && !string.Equals(rejected.sessionId, expectedSessionId, StringComparison.Ordinal)) ||
                (expectedCommandId != null && !string.Equals(rejected.commandId, expectedCommandId, StringComparison.Ordinal)) ||
                current == null ||
                !string.Equals(rejected.sessionId, current.sessionId, StringComparison.Ordinal) ||
                rejected.stateRevision != current.stateRevision ||
                rejected.gameWeek != current.gameWeek ||
                !string.Equals(rejected.stateDigest, current.stateDigest, StringComparison.Ordinal))
            {
                SetProtocolMismatch("Rejected intent response failed protocol/session/command/state validation");
                return;
            }
            var guidance = rejected.rejection;
            var notice = new StudioRejectionNotice(
                rejected.sessionId,
                rejected.stateRevision,
                rejected.stateDigest,
                rejected.reasonCode,
                guidance.category,
                rejected.message,
                guidance.blocker,
                guidance.currentHolder,
                guidance.remedy);
            if (!rejectionRetention.TryRetain(notice))
            {
                SetProtocolMismatch("Rejected intent response could not join the current authoritative state");
                return;
            }
            feedback = "The studio could not carry out the last action.";
            Debug.LogWarning(
                $"[Studio Bridge] rejected {guidance.category}/{rejected.reasonCode}: {rejected.message}",
                this);
            CommandRejected?.Invoke(rejected);
        }

        private static bool IsTerminalBoundaryFailure(UnityWebRequest request) =>
            request.responseCode == 401 || request.responseCode == 403 || request.responseCode == 415;

        private static bool IsAmbiguousPostFailure(UnityWebRequest request) =>
            request.responseCode == 0 || request.responseCode >= 500 ||
            request.result == UnityWebRequest.Result.ConnectionError ||
            request.result == UnityWebRequest.Result.DataProcessingError;

        private void HandleTransportFailure(UnityWebRequest request, string operation)
        {
            if (request.responseCode == 401 || request.responseCode == 403 || request.responseCode == 415)
            {
                pendingPostLifecycle.AbandonAll();
                deferredPostCompletion = null;
                AbandonPendingPlayerWorkflow();
                terminalConnectionFailure = true;
                ConnectionState = StudioBridgeConnectionState.AuthorizationFailed;
                feedback = "Studio could not authorize this launch. Restart it from the trusted launcher.";
                Debug.LogError($"[Studio Bridge] local transport boundary rejected {operation}.", this);
                return;
            }
            if (request.responseCode >= 400 && request.responseCode < 500)
            {
                SetProtocolMismatch($"The local bridge does not support the required {operation} route.");
                return;
            }

            ConnectionState = current == null
                ? StudioBridgeConnectionState.BridgeUnavailable
                : StudioBridgeConnectionState.Reconnecting;
            TransportOutageCount++;
            feedback = "Studio connection unavailable; your last view is retained and actions are paused.";
        }

        private void SetProtocolMismatch(string message)
        {
            pendingPostLifecycle.AbandonAll();
            deferredPostCompletion = null;
            AbandonPendingPlayerWorkflow();
            terminalConnectionFailure = true;
            ConnectionState = StudioBridgeConnectionState.ProtocolMismatch;
            feedback = "Studio data is incompatible. Restart it from the trusted launcher.";
            Debug.LogError($"[Studio Bridge] {message}", this);
        }

        private void OnGUI()
        {
            if (!showWorkflowPanel) return;
            var guiEvent = Event.current;
            if (guiEvent != null &&
                (guiEvent.type == EventType.Layout || guiEvent.type == EventType.Repaint))
                playerWorkflowUiLayoutRepaintNonce = checked(playerWorkflowUiLayoutRepaintNonce + 1);

            EnsureWorkflowStyles();
            var workflowUiScale = StudioLegacyUiMetrics.ScaleFor(Screen.width, Screen.height);
            GUILayout.BeginArea(WorkflowPanelRect());
            workflowScroll = GUILayout.BeginScrollView(workflowScroll);
            GUILayout.BeginVertical(panelSurfaceStyle);
            GUILayout.Label("PROJECT: STUDIO", titleStyle);
            GUILayout.Label(current == null
                ? PlayerConnectionLabel(ConnectionState)
                : $"WEEK {current.gameWeek} · {PlayerConnectionLabel(ConnectionState)}", mutedStyle);
            GUILayout.Label(feedback, bodyStyle);
#if UNITY_EDITOR
            GUILayout.Label(
                $"EDITOR DIAGNOSTICS · {ConnectionState} · REVISION {current?.stateRevision ?? -1} · " +
                $"TypeScript authority · RTT {LastRoundTripMs:F1} ms · parse {LastParseMs:F2} ms · apply {LastApplyMs:F2} ms",
                mutedStyle);
#endif
            if (current != null && !ActionsEnabled)
                GUILayout.Label("LAST STUDIO VIEW · ACTIONS PAUSED WHILE YOUR STUDIO REFRESHES", blockerStyle);
            var journey = current?.snapshot?.journeyNotices?.firstFilmJourney;
            var foundingOpen = PlayerHasFoundingWorkflow(journey, current?.availableIntents);
            if (foundingOpen)
            {
                // LL-CP9: the memo GUIDES founding; it no longer operates it.
                // Offers are read on the people at the gate and the company is
                // founded at Administration — out on the lot.
                GUILayout.Space(8f * workflowUiScale);
                GUILayout.Label("START A STUDIO", titleStyle);
                GUILayout.Label(
                    current?.founding?.readyToFound == true
                        ? "Your founding team is complete. Open Administration on the lot to found the studio."
                        : "Meet the applicants waiting at the studio gate. Click a person to read their offer.",
                    bodyStyle);
            }
            else if (journey != null)
            {
                GUILayout.Space(8f * workflowUiScale);
                GUILayout.Label(
                    journey.ordinal > 0 ? $"PICTURE {journey.ordinal}" : "PICTURE JOURNEY",
                    mutedStyle);
#if UNITY_EDITOR
                GUILayout.Label($"EDITOR JOURNEY BEAT · {journey.beat}", mutedStyle);
#endif
                if (!string.IsNullOrWhiteSpace(journey.pictureTitle)) GUILayout.Label(journey.pictureTitle, titleStyle);
                GUILayout.Label(journey.headline ?? "Picture journey", headlineStyle);
                if (!string.IsNullOrWhiteSpace(journey.whatHappened)) GUILayout.Label(journey.whatHappened, bodyStyle);
                if (!string.IsNullOrWhiteSpace(journey.whyItMatters)) GUILayout.Label(journey.whyItMatters, bodyStyle);
                if (!string.IsNullOrWhiteSpace(journey.detail)) GUILayout.Label(journey.detail, bodyStyle);
                if (journey.waiting != null && !string.IsNullOrWhiteSpace(journey.waiting.reason))
                    GUILayout.Label(journey.waiting.reason, bodyStyle);
                if (journey.blocked != null && !string.IsNullOrWhiteSpace(journey.blocked.reason))
                    GUILayout.Label("ATTENTION · " + journey.blocked.reason, blockerStyle);
                var reception = PlayerReleaseReceptionLabel(
                    journey,
                    current.snapshot.releaseResults?.releasedFilms);
                if (reception != null)
                {
                    GUILayout.Space(8f * workflowUiScale);
                    GUILayout.Label("CRITICAL RECEPTION · " + reception, headlineStyle);
                    GUILayout.Label(PlayerReleaseReceptionSummary(reception), bodyStyle);
                }
#if UNITY_EDITOR
                GUILayout.Label(
                    $"Authority IDs · screenplay {journey.scriptProjectId ?? "—"} · production {journey.productionId ?? "—"}",
                    mutedStyle);
#endif
            }

            var rejectedNotice = CurrentRejection;
            if (rejectedNotice != null)
            {
                GUILayout.Space(10f * workflowUiScale);
                GUILayout.Label("ACTION NEEDS ATTENTION", mutedStyle);
                GUILayout.Label("WHAT HAPPENED", headlineStyle);
                GUILayout.Label(rejectedNotice.Happened, blockerStyle);
                if (rejectedNotice.Holder != null)
                {
                    GUILayout.Label("CURRENT HOLDER", headlineStyle);
                    GUILayout.Label(rejectedNotice.Holder, bodyStyle);
                }
                GUILayout.Label("HOW TO CONTINUE", headlineStyle);
                GUILayout.Label(rejectedNotice.Next, bodyStyle);
#if UNITY_EDITOR
                GUILayout.Label(
                    $"{rejectedNotice.Category} · {rejectedNotice.ReasonCode}",
                    mutedStyle);
#endif
            }

            GUILayout.Space(10f * workflowUiScale);
            if (!foundingOpen && current != null) DrawRightsPanel();
            GUILayout.Label("NEXT STEPS", headlineStyle);
            var choosingCast = !foundingOpen && PlayerHasCastChoice(journey, current?.availableIntents);
            if (choosingCast)
            {
                GUILayout.Label("CHOOSE LEAD / ANTAGONIST / SUPPORT", headlineStyle);
                GUILayout.Label(
                    "Compare each camera-test estimate, observed range, fit, strengths, and concerns, then choose the cast to greenlight.",
                    bodyStyle);
            }
            var enabled = ActionsEnabled;
            GUI.enabled = enabled;
            var renderedOptions = new List<StudioBridgeIntentOption>();
            var timeCededToClock = false;
            if (current?.availableIntents != null)
            {
                var groupCount = choosingCast ? 2 : 1;
                for (var group = 0; group < groupCount; group++)
                {
                    if (group == 1 && PlayerHasOtherStudioAction(journey, current.availableIntents, worldTimeOwnerPresent))
                    {
                        GUILayout.Space(8f * workflowUiScale);
                        GUILayout.Label("OTHER STUDIO ACTIONS", headlineStyle);
                    }
                    for (var index = 0; index < current.availableIntents.Length; index++)
                    {
                        var option = current.availableIntents[index];
                        if (option == null) continue;
                        // LL-CP9: founding actions belong to the world — the
                        // gate applicants and Administration — never to memo
                        // buttons.
                        if (PlayerIsFoundingOption(option)) continue;
                        // P03A: screenplay development belongs to the world —
                        // the Development office and its retained workspaces —
                        // never to memo buttons. The intents themselves remain
                        // on the wire for automation, fallback, and diagnostics.
                        if (PlayerIsDevelopmentOption(option)) continue;
                        // P03A.2: while the Living Time chip is on screen the
                        // clock owns authoritative time — the memo cedes its
                        // advance verb and only points at the owner. Where the
                        // chip is lawfully suppressed (narrow viewports), the
                        // classic manual verb remains: no viewport is ever
                        // left without time.
                        if (worldTimeOwnerPresent && PlayerIsTimeOption(option))
                        {
                            timeCededToClock = true;
                            continue;
                        }
                        // P04A: the casting workspace cedes startAuditions,
                        // acknowledgeAuditions, and greenlightPicture together
                        // while it declares presence — consulted through the
                        // same shared registry the time cede above also
                        // routes through. The intent stays on the wire; only
                        // the memo button goes quiet.
                        if (PlayerIsCededOption(option))
                        {
                            continue;
                        }
                        var isCastChoice = choosingCast && PlayerIsCastChoiceOption(journey, option);
                        if (choosingCast && isCastChoice != (group == 0)) continue;
                        renderedOptions.Add(option);
                        if (PlayerWorkflowButton(
                            option.label,
                            isCastChoice ? castChoiceButtonStyle : workflowButtonStyle,
                            out var buttonScreenRect,
                            GUILayout.MinHeight((isCastChoice ? 54f : 34f) * workflowUiScale)))
                        {
                            SubmitPlayerWorkflowIntent(option, buttonScreenRect);
                        }
                        // LL-CP7: the journey block above already tells this
                        // story — never print the same sentence twice.
                        var detailAlreadyTold = !foundingOpen && journey != null &&
                            (string.Equals(option.detail, journey.detail, StringComparison.Ordinal) ||
                             string.Equals(option.detail, journey.waiting?.reason, StringComparison.Ordinal));
                        if (!string.IsNullOrWhiteSpace(option.detail) && !detailAlreadyTold)
                            GUILayout.Label(option.detail, bodyStyle);
#if UNITY_EDITOR
                        GUILayout.Label(
                            $"{option.kind} · intent {option.intentId} · project {option.projectId ?? "—"} · " +
                            $"session {option.castingSessionId ?? "—"} · production {option.productionId ?? "—"}",
                            mutedStyle);
#endif
                        GUILayout.Space(5f * workflowUiScale);
                    }
                }
                // P03A.2: the memo may inform — one restrained pointer at the
                // owner, never a competing verb.
                if (timeCededToClock)
                    GUILayout.Label("Time runs from the studio clock above — press 1×, 2×, or 4×.", mutedStyle);
            }
            if (guiEvent != null && guiEvent.type == EventType.Repaint)
            {
                lastRenderedWorkflowOptions = renderedOptions.ToArray();
                lastWorkflowTimePointerShown = timeCededToClock;
            }
            GUI.enabled = enabled;
            // P04A.1: while the Studio Menu declares itself present and
            // usable it owns Save/Load — the memo cedes its own buttons and
            // only points at the owner, the same cede shape
            // SetWorldTimeOwnerPresent/SetCastingOwnerPresent already use.
            // Fail closed toward playability: with no declared owner (a
            // disabled/destroyed HUD, or a legacy scene that never installs
            // one), the classic manual Save Studio / Load Studio buttons
            // remain — no viewport is ever left without a way to save.
            if (systemOwnerPresent)
            {
                // The memo sits top-LEFT and the MENU control top-RIGHT, so
                // "above" would be a small lie in a line whose whole job is to
                // point somewhere. Name the place and the key.
                GUILayout.Label("Save Game and Load Game are in the Studio Menu — MENU, top right, or press Esc.", mutedStyle);
            }
            else
            {
                GUILayout.BeginHorizontal();
                if (PlayerWorkflowButton(
                        "Save Studio",
                        workflowButtonStyle,
                        out var saveButtonScreenRect))
                {
                    SavePlayerWorkflow(saveButtonScreenRect);
                }
                if (PlayerWorkflowButton(
                        "Load Studio",
                        workflowButtonStyle,
                        out var loadButtonScreenRect))
                {
                    LoadPlayerWorkflow(loadButtonScreenRect);
                }
                GUILayout.EndHorizontal();
            }
            if (current?.snapshot != null)
            {
                var lot = current.snapshot.lot;
                var people = current.snapshot.people;
                GUILayout.Label(
                    $"{lot.property?.buildings?.Length ?? lot.buildings.Length} buildings · {lot.stages.Length} stages · " +
                    $"{lot.sets.Length} sets · {(people.people.Length == 1 ? "1 person" : $"{people.people.Length} people")} on the lot",
                    mutedStyle);
            }
#if UNITY_EDITOR
            if (GUILayout.Button("Prove Stale Revision Rejection")) RequestStaleIntent();
#endif
            GUI.enabled = true;
            GUILayout.EndVertical();
            if (guiEvent != null && guiEvent.type == EventType.Repaint)
                workflowPanelContentHeight = GUILayoutUtility.GetLastRect().height;
            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }

        private static string PlayerConnectionLabel(StudioBridgeConnectionState state)
        {
            switch (state)
            {
                case StudioBridgeConnectionState.Connecting:
                case StudioBridgeConnectionState.Reconnecting:
                    return "CONNECTING";
                case StudioBridgeConnectionState.Live:
                    return "READY";
                case StudioBridgeConnectionState.BridgeUnavailable:
                    return "OFFLINE";
                default:
                    return "NEEDS ATTENTION";
            }
        }

        private static bool PlayerHasCastChoice(
            StudioFirstFilmJourneySnapshot journey,
            StudioBridgeIntentOption[] options)
        {
            if (journey == null || options == null ||
                !string.Equals(
                    journey.stage,
                    StudioFirstFilmJourneySnapshotStageValues.ReadyToPackage,
                    StringComparison.Ordinal) ||
                !string.Equals(
                    journey.beat,
                    StudioFirstFilmJourneySnapshotBeatValues.AuditionsReviewed,
                    StringComparison.Ordinal) ||
                string.IsNullOrWhiteSpace(journey.scriptProjectId)) return false;

            var identities = new HashSet<string>(StringComparer.Ordinal);
            foreach (var option in options)
            {
                if (!PlayerIsCastChoiceOption(journey, option) ||
                    string.IsNullOrWhiteSpace(option.intentId)) continue;
                identities.Add(option.intentId);
            }
            return identities.Count >= 2;
        }

        private static bool PlayerHasFoundingWorkflow(
            StudioFirstFilmJourneySnapshot journey,
            StudioBridgeIntentOption[] options)
        {
            if (options != null && options.Any(option => option != null &&
                    (string.Equals(
                         option.kind,
                         StudioBridgeIntentOptionKindValues.SignFoundingContract,
                         StringComparison.Ordinal) ||
                     string.Equals(
                         option.kind,
                         StudioBridgeIntentOptionKindValues.FoundStudio,
                         StringComparison.Ordinal)))) return true;

            return journey != null && journey.ordinal == 1 &&
                string.Equals(
                    journey.stage,
                    StudioFirstFilmJourneySnapshotStageValues.NoPicture,
                    StringComparison.Ordinal) &&
                string.Equals(
                    journey.beat,
                    StudioFirstFilmJourneySnapshotBeatValues.NoPicture,
                    StringComparison.Ordinal) &&
                journey.scriptProjectId == null && journey.productionId == null &&
                journey.pictureTitle == null && journey.blocked != null;
        }

        /// <summary>
        /// LL-CP9: founding actions never render as memo buttons — signing
        /// happens on the person at the gate and founding at Administration.
        /// </summary>
        private static bool PlayerIsFoundingOption(StudioBridgeIntentOption option) =>
            option != null &&
            (string.Equals(
                 option.kind,
                 StudioBridgeIntentOptionKindValues.SignFoundingContract,
                 StringComparison.Ordinal) ||
             string.Equals(
                 option.kind,
                 StudioBridgeIntentOptionKindValues.FoundStudio,
                 StringComparison.Ordinal));

        /// <summary>
        /// P03A: screenplay development is operated at the Development office —
        /// commissioning, review, and the one final rewrite never render as
        /// memo buttons. The wire keeps the intents for automation and
        /// diagnostics; the memo keeps only its announcement voice.
        /// </summary>
        internal static bool PlayerIsDevelopmentOption(StudioBridgeIntentOption option) =>
            option != null &&
            (string.Equals(
                 option.kind,
                 StudioBridgeIntentOptionKindValues.CommissionScreenplay,
                 StringComparison.Ordinal) ||
             string.Equals(
                 option.kind,
                 StudioBridgeIntentOptionKindValues.CommissionOriginalScreenplay,
                 StringComparison.Ordinal) ||
             string.Equals(
                 option.kind,
                 StudioBridgeIntentOptionKindValues.AcceptScreenplay,
                 StringComparison.Ordinal) ||
             string.Equals(
                 option.kind,
                 StudioBridgeIntentOptionKindValues.RequestRewrite,
                 StringComparison.Ordinal));

        /// <summary>
        /// P03A.2: the memo's time verb. While a world/HUD time owner (the
        /// persistent Living Time chip) declares presence, advanceWeek never
        /// renders as a memo button — the clock is the ONE authoritative time
        /// control. The intent stays on the wire for the clock itself,
        /// automation, and the narrow-viewport fallback where the chip is
        /// lawfully suppressed.
        /// </summary>
        internal static bool PlayerIsTimeOption(StudioBridgeIntentOption option) =>
            option != null &&
            string.Equals(
                option.kind,
                StudioBridgeIntentOptionKindValues.AdvanceWeek,
                StringComparison.Ordinal);

        /// <summary>
        /// P04A: true while ANY declared presentation owner — the Living
        /// Time chip for advanceWeek, or the casting workspace for
        /// startAuditions/acknowledgeAuditions/greenlightPicture — has
        /// ceded this option's kind. presentIntentOwners is the one
        /// registry every owner's Set*OwnerPresent toggles; this is its
        /// only consumer outside those setters.
        /// </summary>
        private bool PlayerIsCededOption(StudioBridgeIntentOption option) =>
            option != null && presentIntentOwners.Contains(option.kind);

        private static bool PlayerIsCastChoiceOption(
            StudioFirstFilmJourneySnapshot journey,
            StudioBridgeIntentOption option) =>
            journey != null && option != null &&
            !string.IsNullOrWhiteSpace(journey.scriptProjectId) &&
            string.Equals(option.projectId, journey.scriptProjectId, StringComparison.Ordinal) &&
            string.Equals(
                option.kind,
                StudioBridgeIntentOptionKindValues.GreenlightPicture,
                StringComparison.Ordinal);

        private static bool PlayerHasOtherStudioAction(
            StudioFirstFilmJourneySnapshot journey,
            StudioBridgeIntentOption[] options,
            bool timeOwnerPresent)
        {
            if (options == null) return false;
            foreach (var option in options)
            {
                if (option == null) continue;
                if (PlayerIsCastChoiceOption(journey, option)) continue;
                // P03A: world-owned options never render here, so they must not
                // summon the header either.
                if (PlayerIsFoundingOption(option) || PlayerIsDevelopmentOption(option)) continue;
                // P03A.2: a time verb ceded to the clock must not summon it either.
                if (timeOwnerPresent && PlayerIsTimeOption(option)) continue;
                return true;
            }
            return false;
        }

        private static string PlayerReleaseReceptionLabel(
            StudioFirstFilmJourneySnapshot journey,
            StudioReleasedFilmSnapshot[] releases)
        {
            if (journey == null || releases == null ||
                !string.Equals(
                    journey.stage,
                    StudioFirstFilmJourneySnapshotStageValues.Released,
                    StringComparison.Ordinal) ||
                !string.Equals(
                    journey.beat,
                    StudioFirstFilmJourneySnapshotBeatValues.Released,
                    StringComparison.Ordinal) ||
                string.IsNullOrWhiteSpace(journey.productionId)) return null;

            StudioReleasedFilmSnapshot exact = null;
            foreach (var release in releases)
            {
                if (release == null ||
                    !string.Equals(release.id, journey.productionId, StringComparison.Ordinal)) continue;
                if (exact != null) return null;
                exact = release;
            }
            if (exact == null) return null;

            switch (exact.reception)
            {
                case StudioReleasedFilmSnapshotReceptionValues.Flop: return "FLOP";
                case StudioReleasedFilmSnapshotReceptionValues.Mixed: return "MIXED";
                case StudioReleasedFilmSnapshotReceptionValues.Hit: return "HIT";
                case StudioReleasedFilmSnapshotReceptionValues.Smash: return "SMASH";
                default: return null;
            }
        }

        private static string PlayerReleaseReceptionSummary(string reception)
        {
            switch (reception)
            {
                case "FLOP": return "Reviews landed poorly.";
                case "MIXED": return "Reviews were divided.";
                case "HIT": return "Critics greeted the picture as a hit.";
                case "SMASH": return "Critics hailed the picture as a smash.";
                default: return string.Empty;
            }
        }

        private static void ApplyButtonInk(GUIStyle style, Color ink)
        {
            style.normal.textColor = ink;
            style.hover.textColor = ink;
            style.active.textColor = ink;
            style.focused.textColor = ink;
        }

        private static Rect WorkflowPanelRect()
        {
            // LL-CP7: the envelope the panel may occupy. The card inside sizes
            // itself to its content; this is a maximum, not a slab. P03A.3:
            // the envelope now reads the ONE shared metrics source (the same
            // numbers the presentation floors dodge) times the legacy UI
            // scale — identity at and below the 1720×1045 reference.
            var s = StudioLegacyUiMetrics.ScaleFor(Screen.width, Screen.height);
            var inset = StudioLegacyUiMetrics.WorkflowPanelInset * s;
            var width = Mathf.Min(StudioLegacyUiMetrics.WorkflowPanelMaximumWidth * s, Screen.width - inset * 2f);
            var height = Mathf.Max(240f * s, Screen.height - inset * 2f);
            return new Rect(inset, inset, width, height);
        }

        private void EnsureWorkflowStyles()
        {
            // P03A.3: styles rebuild whenever the legacy UI scale changes so a
            // fullscreen viewport rasterizes true-size crisp glyphs; at the
            // reference scale every face is byte-identical to the sealed memo.
            var scale = StudioLegacyUiMetrics.ScaleFor(Screen.width, Screen.height);
            if (titleStyle != null && Mathf.Approximately(workflowStylesScale, scale)) return;
            workflowStylesScale = scale;
            // LL-CP7: the panel reads as a studio production memo — warm paper
            // card, dark period ink — instead of an engineering overlay.
            if (workflowPanelSurfaceTexture == null)
            {
                workflowPanelSurfaceTexture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                workflowPanelSurfaceTexture.SetPixel(0, 0, new Color(0.93f, 0.89f, 0.79f, 0.95f));
                workflowPanelSurfaceTexture.Apply();
                workflowPanelSurfaceTexture.hideFlags = HideFlags.HideAndDontSave;
            }
            panelSurfaceStyle = new GUIStyle(GUI.skin.box)
            {
                padding = new RectOffset(
                    Mathf.RoundToInt(14 * scale),
                    Mathf.RoundToInt(14 * scale),
                    Mathf.RoundToInt(12 * scale),
                    Mathf.RoundToInt(14 * scale)),
                normal = { background = workflowPanelSurfaceTexture },
            };
            titleStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(20, scale),
                fontStyle = FontStyle.Bold,
                wordWrap = true,
                normal = { textColor = new Color(0.43f, 0.16f, 0.10f) },
            };
            headlineStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(14, scale),
                fontStyle = FontStyle.Bold,
                wordWrap = true,
                normal = { textColor = new Color(0.20f, 0.16f, 0.12f) },
            };
            bodyStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(13, scale),
                wordWrap = true,
                normal = { textColor = new Color(0.26f, 0.23f, 0.18f) },
            };
            mutedStyle = new GUIStyle(bodyStyle)
            {
                fontSize = StudioLegacyUiMetrics.ScaledFont(11, scale),
                normal = { textColor = new Color(0.48f, 0.44f, 0.37f) },
            };
            blockerStyle = new GUIStyle(bodyStyle)
            {
                fontStyle = FontStyle.Bold,
                normal = { textColor = new Color(0.62f, 0.14f, 0.10f) },
            };
            // The controls carry the same period ink as the labels — the
            // built-in skin's light button text was only ever legible against
            // the dark slab this card replaced.
            var buttonInk = new Color(0.20f, 0.16f, 0.12f);
            // At the reference scale the buttons keep the skin's own face
            // exactly as sealed (fontSize 0 = skin default); above it they
            // rasterize at the scaled size so hit targets grow with the text.
            var scaledButtonFont = scale > 1f ? StudioLegacyUiMetrics.ScaledFont(13, scale) : 0;
            workflowButtonStyle = new GUIStyle(GUI.skin.button)
            {
                fontSize = scaledButtonFont,
                wordWrap = true,
            };
            ApplyButtonInk(workflowButtonStyle, buttonInk);
            castChoiceButtonStyle = new GUIStyle(GUI.skin.button)
            {
                alignment = TextAnchor.MiddleLeft,
                fontSize = scaledButtonFont,
                fontStyle = FontStyle.Bold,
                wordWrap = true,
            };
            ApplyButtonInk(castChoiceButtonStyle, buttonInk);
            primaryWorkflowButtonStyle = new GUIStyle(castChoiceButtonStyle)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = StudioLegacyUiMetrics.ScaledFont(14, scale),
            };
            ApplyButtonInk(primaryWorkflowButtonStyle, buttonInk);
        }
    }
}
