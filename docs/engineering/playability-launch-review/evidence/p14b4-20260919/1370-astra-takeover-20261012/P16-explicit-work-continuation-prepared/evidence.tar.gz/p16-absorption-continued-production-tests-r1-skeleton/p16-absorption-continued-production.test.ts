// INCOMPLETE UNRUN public-owner skeleton; NOT admitted for installation until frozen R9 joins are bound.
// UNRUN source-grounded clean-target transaction controls. Original48 capture has an explicitly
// disclosed R04 condition/finance constructor; R03 is unchanged. This is not natural campaign proof.
// No STABLE readers, new cash/history/work, clock changes, seed/retention/price fallback or wider timeout.
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import * as saves from '../src/core/save.js'
import * as acquisition from '../src/core/acquisition.js'
import { requestDiligence } from '../src/core/dueDiligence.js'
import { conditionRecord, outstandingLoan } from '../src/core/corporateConditionLive.js'
import { terminationCost } from '../src/core/employment.js'
import { libraryValuationV1 } from '../src/core/propertyValuation.js'
import { resolveTitles, subjectsHeldBy } from '../src/core/rights.js'
import { tick } from '../src/core/tick.js'
const TARGET='studio-aca408ec-r02',FILM=TARGET+':film:14'
const PIN='c17b7aa82bd09e6988867e149ed0266803d8e432cfcd8842d9c2aca1f7ace8ad'

function prepared() {
 const root=process.env.P16_ORIGINAL48_CAPTURE_ROOT;expect(root).toBeTruthy()
 const bytes=readFileSync(root+'/r04-actual163.save48.json')
 expect(createHash('sha256').update(bytes).digest('hex')).toBe(PIN)
 const raw=JSON.parse(bytes.toString()),rawBefore=saves.stableStringify(raw)
 const old=saves.validateSaveP15B(raw);expect(old.saveVersion).toBe(48)
 const oldBefore=saves.stableStringify(old)
 const current=saves.convertV48ToV49(old),initial=current.state
 expect(current.saveVersion).toBe(49);expect(initial.market.tick).toBe(163)
 const player=initial.hollywood!.playerStudioId,source=initial.hollywood!.businesses.find(b=>b.studioId===TARGET)!
 expect(source,'fixed retained R03 prerequisite').toBeDefined()
 expect(source.account.cash).toBe(13824449.654646564)
 expect(source.productions).toHaveLength(1);expect(source.productions[0]).toMatchObject({id:FILM,startTick:157,remainingTicks:3});expect(source.runs).toHaveLength(0)
 expect(conditionRecord(initial,player)?.condition).toMatchObject({stage:'stable',week:163})
 expect(conditionRecord(initial,TARGET)?.condition).toMatchObject({stage:'stable',week:163})
 expect(outstandingLoan(initial,player,163)).toBeUndefined();expect(outstandingLoan(initial,TARGET,163)).toBeUndefined()
 expect(acquisition.absorptionProducerRefusal(initial,{buyerId:player,targetId:TARGET,consideration:1,retention:{kind:'default'},disclosureId:null})).toBeNull()
 const original=initial.hollywood!.activeEmploymentOrdinals.map(i=>initial.hollywood!.employment[i]!)
  .filter(e=>e.studioId===TARGET&&e.endedWeek===null&&e.terms.startWeek<=163&&163<e.terms.endWeekExclusive)
 expect(original).toHaveLength(6);expect(original.every(e=>e.terms.endWeekExclusive===208)).toBe(true)
 // ONE fixed explicit choice: the first authoritative target interval; fail if that person cannot lawfully continue.
 const retention={kind:'explicit' as const,contractIds:original.map(e=>e.contractId)}
 const initialBefore=saves.stableStringify(initial)
 const diligence=requestDiligence(initial,{recipientId:player,target:{kind:'studio',studioId:TARGET},scope:['rights','employment','liabilities']},163)
 expect(saves.stableStringify(initial)).toBe(initialBefore);saves.makeSave(diligence.state)
 expect(diligence.record).toMatchObject({week:163,recipientId:player,target:{kind:'studio',studioId:TARGET}})
 expect(diligence.state.studio.cash).toBe(initial.studio.cash-diligence.record.fee)
 expect(diligence.record.fee).toBeGreaterThan(0)
 const expectedExits=original.filter(e=>!retention.contractIds.includes(e.contractId)).reduce((sum,e)=>sum+terminationCost(e.terms,163),0)
 const postExitCash=source.account.cash-expectedExits
 const library=libraryValuationV1(diligence.state,TARGET,163);expect(library.kind).toBe('available')
 if(library.kind!=='available')throw new Error('fixed R03 library valuation premise absent')
 // The single lawful whole consideration at the public ask; not an amount sweep or edited account.
 const consideration=Math.ceil(acquisition.absorptionAsk(library.total,postExitCash))
 const previewInput={buyerId:player,targetId:TARGET,consideration,retention,disclosureId:diligence.record.id}
 const quote=acquisition.quoteAbsorption(diligence.state,previewInput,163)
 expect(quote.kind,'actual person/willingness/reserve/retention premise, no fallback').toBe('quote')
 if(quote.kind!=='quote')throw new Error(quote.refusal)
 expect(quote.affordable).toBe(true)
 expect(quote.contracts.filter(c=>c.retained).map(c=>c.contractId)).toEqual(retention.contractIds)
 expect(quote.contracts.filter(c=>!c.retained)).toHaveLength(0);expect(quote.productions).toHaveLength(1);expect(quote.productions[0]).toMatchObject({productionId:FILM,remainingTicks:3,phase:'postProduction',disposition:'continues'})
 expect(quote.exitCharges).toBe(expectedExits);expect(expectedExits).toBe(0)
 expect(quote.targetCashBeforeExits).toBe(source.account.cash);expect(quote.postExitCash).toBe(postExitCash)
 expect(quote.quoteAgePolicyVersion).toBe(1);expect(quote.quotedAtWeek).toBe(163)
 const input={...previewInput,quotedAtWeek:quote.quotedAtWeek,quoteAgePolicyVersion:quote.quoteAgePolicyVersion}
 const state=diligence.state,before=saves.stableStringify(state)
 const subjects=subjectsHeldBy(resolveTitles(state),state.rights.estates,TARGET,163)
 expect(subjects.length,'real nonempty held-title transition required').toBeGreaterThan(0)
 return {raw,rawBefore,old,oldBefore,initial,initialBefore,state,before,player,source,original,quote,input,subjects}
}
function originalUnchanged(p:ReturnType<typeof prepared>) {
 expect(saves.stableStringify(p.state)).toBe(p.before)
 expect(saves.stableStringify(p.initial)).toBe(p.initialBefore)
 expect(saves.stableStringify(p.old)).toBe(p.oldBefore)
 expect(saves.stableStringify(p.raw)).toBe(p.rawBefore)
}
function complete(p:ReturnType<typeof prepared>) {
 const result=acquisition.closeAbsorption(p.state,p.input,163)
 originalUnchanged(p)
 const record=result.rights.absorptions.find(a=>a.targetId===TARGET)!
 expect(record).toBeDefined();expect(record.week).toBe(163)
 expect(record.quotedAtWeek).toBe(p.input.quotedAtWeek);expect(record.quotedAtWeek).toBe(163)
 expect(record.quoteAgePolicyVersion).toBe(p.input.quoteAgePolicyVersion);expect(record.quoteAgePolicyVersion).toBe(1)
 return {result,record}
}

describe('P16 genuine163 R02 paid post-production healthy continuation',()=>{
 it('real quoted continuation retains paid creator history and actual linked participants through three native ordinary post steps and public save replay',()=>{
  const p=prepared(),{result,record}=complete(p)
  expect(record.contracts.filter(c=>c.buyerContractId!==null)).toHaveLength(6)
  for(const old of p.original) {
   const link=record.contracts.find(c=>c.sourceContractId===old.contractId)!
   const live=result.hollywood!.employment.find(e=>e.contractId===link.buyerContractId)!
   expect(live.studioId).toBe(p.player);expect(live.reason).toBe('absorptionContinuation')
   expect(live.terms).toEqual({...old.terms,startWeek:163,termWeeks:45})
  }
  expect(result.hollywood!.businesses.find(b=>b.studioId===TARGET)!.projects).toEqual(p.source.projects)
  const firstTake=p.state.firstTakes.find(e=>e.productionId===FILM)!
  expect(firstTake).toMatchObject({week:162,studioId:TARGET})
  expect(result.firstTakes.find(e=>e.productionId===FILM)).toEqual(firstTake)
  const text=saves.exportCurrentState(result),reload=saves.migrateToLive(saves.importSave(text)).state
  expect(saves.exportCurrentState(reload)).toBe(text)
  let state=result,replay=reload
  for(let week=164;week<=166;week++) {
   const before=JSON.stringify(state),replayBefore=JSON.stringify(replay),prior=state,priorReplay=replay
   state=tick(prior);replay=tick(priorReplay)
   expect(JSON.stringify(prior)).toBe(before);expect(JSON.stringify(priorReplay)).toBe(replayBefore)
   expect(state.market.tick).toBe(week)
  }
  expect(saves.exportCurrentState(state)).toBe(saves.exportCurrentState(replay))
  const film=state.hollywood!.films.find(f=>f.filmId===FILM)!
  expect(film).toBeDefined();expect(film.provenance).toBe('simulation/v1')
  if(film.provenance!=='simulation/v1')throw new Error('actual creator film required')
  expect(film.studioId).toBe(TARGET);expect(film.result.releaseTick).toBe(165)
  expect(state.firstTakes.find(e=>e.productionId===FILM)).toEqual(firstTake)
  // PENDING frozen R9: exact combined-buyer allocator/native remaining steps, retained script/workflow snapshots,
  // one actual buyer R2 release cause, Standing delta and locked future-run beneficiary/receipts/full-reader mutants.
  // Their omission is an explicit draft prerequisite, NOT a passing qualification or optional acceptance residual.
  originalUnchanged(p)
 })
 it('real joined publication failure leaves public current163 source unchanged after actual full current reader',()=>{
  const p=prepared(),positive=complete(p)
  expect(positive.record.contracts.filter(c=>c.buyerContractId!==null)).toHaveLength(6)
  const real=saves.makeSave,marker='R9_CONTINUATION_REAL_JOINED_PUBLICATION_FAULT';let output=0
  const spy=vi.spyOn(saves,'makeSave').mockImplementation(state=>{
   const saved=real(state)
   if(saved.state.rights.absorptions.some(a=>a.targetId===TARGET)) {output++;throw new Error(marker)}
   return saved
  })
  try {expect(()=>acquisition.closeAbsorption(p.state,p.input,163)).toThrow(marker);expect(output).toBe(1)}
  finally {spy.mockRestore();originalUnchanged(p)}
 })
})
