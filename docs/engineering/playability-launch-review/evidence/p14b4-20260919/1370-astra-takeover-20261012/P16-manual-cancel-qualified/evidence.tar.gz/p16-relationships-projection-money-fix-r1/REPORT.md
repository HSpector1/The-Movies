# Relationship historical-projection compatibility repair — STATIC / UNRUN

Observed r8 family1 and family10 failures share `rightsStripped` -> public validateSaveV48 -> frozen V37..V24 exact-movements refusal. The helper removes only the original three P16 movements; actual current migration adds fourth `estateSaleProceeds` on every rival period (hollywoodTypes.ts:68; save.ts:11822). The zero fourth key survives the test projection and is illegal in frozen48. This is test-helper compatibility, not a product/frozen reader defect.

One constant gains the exact fourth rival money kind. The existing per-period guard first refuses NONZERO values, then deletes the zero key; public Save48 admission remains mandatory. Its ledger guard also refuses a real estate proceeds row. withP16Era now mirrors the genuine four-zero migration shape. No digest, relationship assertion, downgrade message, frozen schema or runtime budget changes. No absorbedRunRevenue rival key is added: it is a player ledger kind, not P16_RIVAL_MONEY_KINDS.

Family1 reaches this helper via historicalSave45Comparison -> predecessorSave; family10 calls it directly before migrateToV30. Both originally fail before their named assertion. The inherited three rival film6/take/release failures are unrelated. The complete relationships file should be remeasured by parent after review; this source inspection is not a pass claim. Existing helper general absorption/ledger projection scope is not expanded here.

K/R untouched; no tests/compiler/simulation executed. Exact original/postimage hashes are in MANIFEST.json; sparse patch only.
