import pathlib,json,hashlib,re,difflib,os
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r4';D=A/'p16-work-release61-integration-runner-r5';out=A/'p16-work-release61-integration-r5-run';p=A/'p16-work-release-cancel-baseline-r1';test=A/'p16-continued-work-cancel-tests-r1-baseline'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK');D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
files=['tests/p16-continued-work-cancel.test.ts'];previous=json.loads((old/'SELECTION.json').read_text());commands=[previous[0],previous[-1][:10]+files];commands[-1][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
ids=json.loads((test/'EXPECTED-IDENTITIES.json').read_text());expect=[dict(file=ids['file'],sourceSHA256=sha(K/ids['file']),names=ids['identities'],budgetMs=5000)]
assert len(expect[0]['names'])==2;write('EXPECTED-IDENTITIES.json',expect)
for n in ['auto_freeze.py','account-results.py']:(D/n).write_bytes((old/n).read_bytes())
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(A/'p16-work-release61-integration-r4-run'),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root compiler then three complete files commands','literal root compiler then one complete baseline file commands')
s=s.replace('focused root compiler then estate/quote three complete files11 identities; no whole gate or P16 acceptance','fresh root compiler then manual-cancel baseline complete2; expected real current failure remains RED, no success or rollback assertions credited if unreached')
s=re.sub(r'^run estate-red .*$', 'run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(files),s,flags=re.M)
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text());m=json.loads((p/'MANIFEST.json').read_text())
b.update(package=str(p),patchSHA256=sha(p/'PATCH.diff'),manifestSHA256=sha(p/'MANIFEST.json'),pathCount=len(m['files']),plannedPathCount=len(m['files']),scope='Measure genuine current own-only manual cancel failure before source correction; complete baseline2',executionScope='root compiler then new public-cancel baseline complete2; expected RED retained as failure, not gameplay acceptance',expectedCompiledTests={row['file']:row['sourceSHA256'] for row in expect},finalCleanTestAdmission='Independent baseline2 KEEP; genuine actual163 paid R02 retained production reaches full positive close then public cancel; no future receipt API, default5s; later assertions unreached if first action throws',installedSourceReceiptSHA256=sha(p/'INSTALL-RECEIPT.json'))
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',p/'INSTALL-RECEIPT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R4-PARENT-RESULT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R4-INDEPENDENT-RESULT-REVIEW.md',test/'SOURCE.patch',test/'MANIFEST.json',A/'P16-CONTINUED-WORK-CANCEL-BASELINE-R1-INDEPENDENT-REVIEW.md']
for q in paths:
 if str(q) not in {r['path'] for r in b['artifacts']}:b['artifacts'].append(dict(path=str(q),sha256=sha(q)))
write('BINDINGS.json',b)
(D/'DELTA-vs-r4-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r4/runner.sh',tofile='r5/runner.sh')))
(D/'README.md').write_text('Measure genuine baseline before manual-cancel source. Fresh root compiler; complete baseline2, default5s and genuine163R02 route. No future cancellation fields. Expected own-only action refusal remains terminal1/failed tests; later success/purity/rollback assertions receive zero credit if unreached. Existing strict source/index/input/AUTO freeze and lane/floors unchanged. No source correction installed. Parent external four-file bootstrap pins required.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
