# Public-cancel baseline R1

KEEP independent tests-only baseline for parent RED measurement. Testfb278ea1aac3eb21e21ec71292c333fb8938cadf22d7ca151c3d795e8928b6dd/SOURCEcd56961ee8f05255dcaaad002a88dc4c8cc488fc9338f2cf72cc6dc87b5083a9; all artifact hashes verified. Two complete identities/default5s/setupinside, existing actual163 capture/public48→49/full priced six-retained absorption and actual continued live workflow prerequisites first.

Baseline has no forthcoming workCancellations field access and uses current available API/export types. Existing public cancel own-only lookup should refuse actual acquired FILM after genuine positive close; this distinguishes dispatcher gap rather than an invented cancellation route. Actual compiler/runtime first boundary remains unmeasured. If both stop there, post-cancel preservation, ordinary stop/replay and rollback assertions do not execute and cannot be credited. The baseline input-purity assertion after call likewise is not reached on initial throw; no RED purity claim inferred.

Final3 relationship consequence refinement is separate and does not block measuring this independent baseline. No newsource installed/reader weakened or budgets altered; no reviewer runtime/K/R writes. Preserve any actual refusal/premise/timing result.
