// Source syntax only: never imports test/engine/Vitest or collects tests.
const ts=require('/Users/zacheryspector/studio-specialists/p16/node_modules/typescript');
const fs=require('fs'),crypto=require('crypto');
const root='/Users/zacheryspector/studio-specialists/p16/';
const files=['tests/actions.test.ts','tests/p14b5-relationships.test.ts','tests/p14b4-cancel-causal-proof.test.ts','tests/p13b-s5-save-v24.test.ts','tests/p16a-save-v46.test.ts'];
const rows=[];
for(const file of files){
 const bytes=fs.readFileSync(root+file),sf=ts.createSourceFile(file,bytes.toString(),ts.ScriptTarget.Latest,true),variables=new Map();
 function scalar(n){if(!n)return undefined;if(ts.isAsExpression(n)||ts.isParenthesizedExpression(n))return scalar(n.expression);if(ts.isStringLiteral(n)||ts.isNoSubstitutionTemplateLiteral(n))return n.text;if(ts.isNumericLiteral(n))return Number(n.text);if(ts.isArrayLiteralExpression(n))return n.elements.map(scalar);if(ts.isObjectLiteralExpression(n))return Object.fromEntries(n.properties.filter(ts.isPropertyAssignment).map(p=>[p.name.getText(sf),scalar(p.initializer)]));if(ts.isIdentifier(n))return variables.get(n.text);return undefined;}
 function collect(n){if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name))variables.set(n.name.text,scalar(n.initializer));ts.forEachChild(n,collect);}collect(sf);
 const leaves=[],hooks=[];
 function visit(n,groups=[]){if(ts.isCallExpression(n)){
 let name=n.expression.getText(sf),each;
 if(ts.isCallExpression(n.expression)&&ts.isPropertyAccessExpression(n.expression.expression)&&n.expression.expression.name.text==='each'){name=n.expression.expression.expression.getText(sf);each=scalar(n.expression.arguments[0]);if(!Array.isArray(each))throw Error('unresolved each '+file);}
 if(['describe','it','test','beforeAll','beforeEach','afterAll','afterEach'].includes(name)){
  const line=sf.getLineAndCharacterOfPosition(n.getStart(sf)).line+1,title=scalar(n.arguments[0]);
  if(name==='describe'){if(typeof title!=='string')throw Error('unresolved describe');ts.forEachChild(n.arguments[1],x=>visit(x,[...groups,title]));return;}
  if(name==='it'||name==='test'){
   let titles;
   if(each)titles=each.map(row=>title.replace(/\$([A-Za-z][\w]*)/g,(_,key)=>{if(typeof row[key]!=='string')throw Error('unresolved field '+key);return row[key];}));
   else if(typeof title==='string')titles=[title];
   else {const literal=n.arguments[0].getText(sf);if(file!=='tests/actions.test.ts'||literal!=='`one talent in both ${occupied} and ${stolen} throws (single-role uniqueness)`')throw Error('unresolved title '+literal);const seats=variables.get('SEATS');if(!Array.isArray(seats)||seats.length!==6)throw Error('seat source changed');titles=seats.flatMap((a,i)=>seats.slice(i+1).map(b=>`one talent in both ${a} and ${b} throws (single-role uniqueness)`));}
   const explicit=n.arguments[2]!==undefined,budget=explicit?scalar(n.arguments[2]):5000;if(!Number.isFinite(budget))throw Error('unresolved budget');
   for(const title of titles)leaves.push({fullName:[...groups,title].join(' '),line,budgetMs:budget,budgetSource:explicit?'explicit source leaf argument':'unchanged Vitest core default'});return;
  }
  hooks.push({name,line,budget:n.arguments[1]?.getText(sf)??'default'});return;
 }
 }ts.forEachChild(n,x=>visit(x,groups));}
 visit(sf);if(new Set(leaves.map(r=>r.fullName)).size!==leaves.length)throw Error('duplicate identities');
 rows.push({file,sourceSHA256:crypto.createHash('sha256').update(bytes).digest('hex'),count:leaves.length,names:leaves.map(x=>x.fullName),leaves,hooks});
}
const out=__dirname+'/EXPECTED-IDENTITIES.json';fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(rows.map(r=>({file:r.file,count:r.count,budgets:[...new Set(r.leaves.map(l=>l.budgetMs))]}))));
