import pathlib,json,importlib.util,sys
D=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('auto_freeze',D/'auto_freeze.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=json.loads((D/'ROOT-REUSE.json').read_text());old=json.loads(pathlib.Path(r['baseFreeze']).read_text());post=json.loads(pathlib.Path(r['independentFreeze']).read_text());current=json.loads(pathlib.Path(sys.argv[1]).read_text())
m.compare_envelopes(old,post)
result=json.loads(pathlib.Path(r['parentResult']).read_text())
assert result['terminal']['overallExit']==97 and result['independentFinalFreeze']=='PASS'
assert result['strictErrorsBytes']==0 and result['sourceCount']==len(old['files']) and result['inputCount']==len(old['inputs'])
assert len(result['children'])==1
child=result['children'][0]
assert child['name']=='tsc-root' and child['exit']==0 and child['seconds']==62 and child['node']=='v20.20.2'
assert child['command']==['node','node_modules/typescript/bin/tsc','--noEmit']
assert json.loads((pathlib.Path(r['priorRun'])/'terminal.json').read_text())==result['terminal']
assert [json.loads(x) for x in (pathlib.Path(r['priorRun'])/'results.jsonl').read_text().splitlines()]==result['children']
assert pathlib.Path(child['log']).read_bytes()==b''
# Keep every original compiler/input binding. Additional continuation artifacts are independently pinned by runner admission.
assert set(old['inputs'])<=set(current['inputs'])
restricted=dict(current);restricted['inputs']={p:current['inputs'][p] for p in old['inputs']}
m.compare_envelopes(old,restricted)
print(json.dumps({'rootChildReused':True,'rootChildExit':0,'originalWrapperExit':97,'sourceCount':len(old['files']),'originalInputCount':len(old['inputs']),'strictSourceAndInputs':'PASS','newRuntimeResults':'NONE AT ADMISSION'}))
