import pathlib,json,hashlib,re,os,difflib
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012')
old=A/'p16-work-release61-integration-runner-r5';D=A/'p16-work-release61-integration-runner-r6';out=A/'p16-work-release61-integration-r6-run'
prior=A/'p16-work-release61-integration-r5-run';audit=A/'p16-work-release61-integration-r5-parent-reconciliation'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK');D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
commands=json.loads((old/'SELECTION.json').read_text())[1:];assert len(commands)==1
commands[0][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
for n in ['EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']:(D/n).write_bytes((old/n).read_bytes())
reuse={'priorRun':str(prior),'baseFreeze':str(prior/'freeze.json'),'independentFreeze':str(audit/'independent-freeze.json'),'parentResult':str(A/'P16-WORK-RELEASE61-INTEGRATION-R5-PARENT-RESULT.json'),'originalWrapperExit':97,'reusedChild':'tsc-root','requiredChildExit':0,'seconds':62,'rule':'Exact original compiler/source/index/HEAD/metadata/input equality against independently reconciled prior run; additional pinned continuation artifacts only. Original wrapper97 remains failed; runtime2 unexecuted until this run.'}
write('ROOT-REUSE.json',reuse)
helper=(A/'p16-work-run-continuation-runner-r3/root-reuse.py').read_text()
assert "child['seconds']==46" in helper
(D/'root-reuse.py').write_text(helper.replace("child['seconds']==46","child['seconds']==62"))
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(prior),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root compiler then one complete baseline file commands','literal runtime-only complete baseline file command; original compiler reused by strict equality')
s=s.replace('fresh root compiler then manual-cancel baseline complete2; expected real current failure remains RED, no success or rollback assertions credited if unreached','exact prior root0 reused; complete manual-cancel baseline2; expected own-only failure stays RED, no unreached assertions credited')
start=s.index('# Fresh compiler prerequisites,')
end=s.index('run estate-red ',start)
s=s[:start]+'python3 -I -B "$D/root-reuse.py" "$OUT/freeze.json" > "$OUT/root-reuse.json" || exit 98\n'+s[end:]
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text())
b.update(scope='Runtime-only continuation of actual r5 root0/wrapper97; complete baseline2 unchanged',executionScope='Reuse actual root compiler0/62s only after exact full original freeze/input equality; run complete baseline2 unchanged5s; expected RED is not acceptance',rootReuse=reuse)
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
oldfreeze=json.loads((prior/'freeze.json').read_text())
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',D/'ROOT-REUSE.json',D/'root-reuse.py',prior/'freeze.json',audit/'independent-freeze.json',pathlib.Path(reuse['parentResult']),prior/'terminal.json',prior/'results.jsonl',prior/'tsc-root.log']
paths += [pathlib.Path(p) for p,v in oldfreeze['inputs'].items() if isinstance(v,list) and v[0]=='file']
existing={r['path']:r['sha256'] for r in b['artifacts']}
for q in paths:
 if str(q) in existing:assert existing[str(q)]==sha(q)
 else:b['artifacts'].append({'path':str(q),'sha256':sha(q)});existing[str(q)]=sha(q)
write('BINDINGS.json',b)
(D/'DELTA-vs-r5-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r5/runner.sh',tofile='r6/runner.sh')))
(D/'README.md').write_text('UNRUN runtime-only continuation. The actual r5 compiler passed in62s; its wrapper stopped97 at the unchanged runtime floor before tests. Reuse only after exact old/independent/current source, index, metadata and original input equality. Complete two-test baseline and default5s unchanged; later assertions not credited if public cancel refuses. No manual-cancel source installed. Same lane, floors, freeze and four external bootstrap pins. Original r5 retained.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()})
print((D/'PINS.json').read_text())
