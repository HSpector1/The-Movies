# Manual-cancel consequence controls R3

KEEP additive test refinement, UNRUN. Test14503e96a73b8492fb50c355eeca3ad301170f783259afd2ee4e672bb214956e/DELTA009669ae34f87380d57f59487783067f3cb5ff73057f0f28d78bc923d303bada; all artifact hashes verified, R2 retained.

Actual existing firsttake supplies director and three cast seats; unique seats imply its canonical unordered pairs, mandatory existing counted shared edges. For exactly that nonempty pairset the actual cancellation driver must appear once with FILM/week163 and -RELATIONSHIP_CANCEL_DELTA, and sharedCancellations increments once. Existing driverGain currently returns the same delta; no copied arbitrary expected history or invented edge. This distinguishes removal of recordCancelledAfterFirstTake and catches missing/extra affected pair.

Fixed original director has a real retained buyer contract. Public releaseTalent must refuse before cancel with actual seated-production sentence, then after cancel use real terminationCost at163, exact actual termination ledger/cash and absence of active contract, full public save and caller/title purity. Current releaseRefusal uses real seating selector; activeContract and cost API shapes match. This is actual staffing release proof rather than selector-only claim, still not a second production allocation campaign.

All original3names/default5s/setupinside, paid preservation, public ordinary stop/replay, receipt hostiles, irreversiblecommit and realwriterrollback stay unchanged. Real pair/staffing positive and timing remain unmeasured; fixed first unmet premise must remain failed. No runtime/K/R edits.
