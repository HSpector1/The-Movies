import pathlib,json,hashlib,re,difflib,os
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r5';D=A/'p16-work-release61-integration-runner-r7';out=A/'p16-work-release61-integration-r7-run';p=A/'p16-work-release-manual-cancel-r1';test=A/'p16-continued-work-cancel-tests-r3-relationships'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK')
baseline=json.loads((A/'P16-WORK-RELEASE61-INTEGRATION-R6-PARENT-RESULT.json').read_text())
assert baseline['terminal']['overallExit']==1 and baseline['independentFinalFreeze']=='PASS' and baseline['counts']=={'failed':2}
D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
files=['tests/p16-continued-work-cancel.test.ts'];commands=json.loads((old/'SELECTION.json').read_text());commands[-1][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
ids=json.loads((test/'EXPECTED-IDENTITIES.json').read_text());expect=[dict(file=ids['file'],sourceSHA256=sha(K/ids['file']),names=ids['identities'],budgetMs=5000)]
assert len(expect[0]['names'])==3 and expect[0]['sourceSHA256']=='14503e96a73b8492fb50c355eeca3ad301170f783259afd2ee4e672bb214956e';write('EXPECTED-IDENTITIES.json',expect)
for n in ['auto_freeze.py','account-results.py']:(D/n).write_bytes((old/n).read_bytes())
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(A/'p16-work-release61-integration-r5-run'),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root compiler then one complete baseline file commands','literal root compiler then complete manual-cancel three-test file commands')
s=s.replace('fresh root compiler then manual-cancel baseline complete2; expected real current failure remains RED, no success or rollback assertions credited if unreached','fresh root compiler then complete manual-cancel3 with actual relationships/staffing/reader/publication rollback; original failed baseline retained')
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text());m=json.loads((p/'MANIFEST.json').read_text())
b.update(package=str(p),patchSHA256=sha(p/'PATCH.diff'),manifestSHA256=sha(p/'MANIFEST.json'),pathCount=len(m['files']),plannedPathCount=len(m['files']),scope='Reviewed existing public-action cancellation for actual buyer-owned absorbed unfinished production',executionScope='Fresh root compiler and complete independent3 default5s; real relationship driver, retained-workforce release, frozen source/payment history, save/replay, hostile reader and actual final-publication rollback. No native or whole-P16 acceptance.',expectedCompiledTests={row['file']:row['sourceSHA256'] for row in expect},finalCleanTestAdmission='Independent manual source8 and testR3 KEEP; original baseline2 actual failure preserved; real upstream no stubs or budget changes',installedSourceReceiptSHA256=sha(p/'INSTALL-RECEIPT.json'))
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',p/'INSTALL-RECEIPT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R6-PARENT-RESULT.json',A/'P16-CONTINUED-WORK-CANCEL-BASELINE-R6-ACTUAL-REVIEW.md',A/'P16-MANUAL-CANCEL-SOURCE-R1-INSTALL-SPEC.json',A/'p16-continued-work-manual-cancel-r1/SOURCE.patch',A/'p16-continued-work-manual-cancel-r1/MANIFEST.json',A/'P16-CONTINUED-WORK-MANUAL-CANCEL-R1-INDEPENDENT-REVIEW.md',test/'DELTA.patch',test/'MANIFEST.json',A/'p16-continued-work-cancel-baseline-to-r3-parent/DELTA.patch',A/'p16-continued-work-cancel-baseline-to-r3-parent/MANIFEST.json',A/'P16-CONTINUED-WORK-CANCEL-TESTS-R3-INDEPENDENT-REVIEW.md']
for q in paths:
 if str(q) not in {r['path'] for r in b['artifacts']}:b['artifacts'].append(dict(path=str(q),sha256=sha(q)))
write('BINDINGS.json',b)
(D/'DELTA-vs-r5-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r5/runner.sh',tofile='r7/runner.sh')))
(D/'README.md').write_text('UNRUN: reviewed source8/final independent3 installed only after actual baseline2RED and independent freeze/result review. Fresh root compiler, complete final3 unchanged5s. Exact paid source/history/cancel receipt/current reader, true relationship effects, actual retained-worker release and full final-publication rollback; no adapter or native acceptance. Existing lane, floors, freeze and external four bootstrap pins unchanged.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
