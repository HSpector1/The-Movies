import pathlib,json,hashlib,re,difflib,os
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r3';D=A/'p16-work-release61-integration-runner-r4';out=A/'p16-work-release61-integration-r4-run';p=A/'p16-work-release-estate-quote-harness-r1'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK');D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
files=['tests/p16-estate-d-ceremony.test.ts','tests/p16-estate-d-join-negative.test.ts','tests/p16-quote-age.test.ts']
previous=json.loads((old/'SELECTION.json').read_text());commands=[previous[0],previous[-1][:10]+files];commands[-1][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
expect=json.loads((A/'p16-work-release61-integration-runner-r2/EXPECTED-IDENTITIES.json').read_text());expect=[next(row for row in expect if row['file']==f) for f in files]
for row in expect:row['sourceSHA256']=sha(K/row['file'])
assert sum(len(row['names']) for row in expect)==11;write('EXPECTED-IDENTITIES.json',expect)
for n in ['auto_freeze.py','account-results.py']:(D/n).write_bytes((old/n).read_bytes())
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(A/'p16-work-release61-integration-r3-run'),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root and Bridge compilers then three complete files commands','literal root compiler then three complete files commands')
s=s.replace('focused root and Bridge compilers then three complete files12 identities; no whole gate or P16 acceptance','focused root compiler then estate/quote three complete files11 identities; no whole gate or P16 acceptance')
s=re.sub(r'^run tsc-bridge .*\n.*\n','',s,flags=re.M)
s=re.sub(r'^run estate-red .*$', 'run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(files),s,flags=re.M)
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text());m=json.loads((p/'MANIFEST.json').read_text())
b.update(package=str(p),patchSHA256=sha(p/'PATCH.diff'),manifestSHA256=sha(p/'MANIFEST.json'),pathCount=len(m['files']),plannedPathCount=len(m['files']),scope='Focused existing estate/quote tests with same-caller purity snapshot overhead correction;11 identities',executionScope='root compiler then complete estate ceremony, estate hostile joins and quote age11; no fresh UI/Bridge/generator/broad claim',expectedCompiledTests={row['file']:row['sourceSHA256'] for row in expect},finalCleanTestAdmission='Reviewed sparse test-only same-caller native JSON snapshots; all cross-producer canonical equality, real13ticks, full readers and unchanged11 identities/5s/setup retained',installedSourceReceiptSHA256=sha(p/'INSTALL-RECEIPT.json'))
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',p/'INSTALL-RECEIPT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R3-PARENT-RESULT.json',A/'P16-WORK-RELEASE61-INTEGRATION-R3-INDEPENDENT-RESULT-REVIEW.md',A/'p16-estate-quote-harness-r1/DELTA.patch',A/'p16-estate-quote-harness-r1/MANIFEST.json',A/'P16-ESTATE-QUOTE-HARNESS-R1-INDEPENDENT-REVIEW.md']
for q in paths:
 if str(q) not in {r['path'] for r in b['artifacts']}:b['artifacts'].append(dict(path=str(q),sha256=sha(q)))
write('BINDINGS.json',b)
(D/'DELTA-vs-r3-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r3/runner.sh',tofile='r4/runner.sh')))
(D/'README.md').write_text('Focused estate/quote harness correction. Fresh root compiler; complete existing ceremony/hostile joins/quote-age3files11identities. Default5s/setup placement/13real ticks/full readers preserved. Source and all generated artifacts unchanged from qualified183; prior Bridge/UI/generator proofs remain separate. Existing strict source/index/input/AUTO freeze and lane/floors unchanged. Original overrun results preserved. Parent external four-file bootstrap pins required.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
