# Manual-cancel tests R2

REFINE one meaningful consequence assertion before final qualification. Test4f373e0af0157bde2ee778052f8659392a0acf82c23378474fb01475632b3651/SOURCEd9487b055fab7e43c0a01a45fa96e8f5e6205650d1a6d06d8c20cbe1d157aa6b and all artifact hashes verified. Original baseline2 remains UNRUN separately.

Fixed actual163 paid post3 transaction, public cancel, source paid production/script/firsttake/employment/title/cash preservation, busy/workflow release, ordinary166 stop/save/replay, real fullwriter rollback and receipt completeness/foreign/date/counter/replay/ready-commit irreversibility controls are meaningful. API/refusal matches inspected actualsource; no fabricated positive/root/clock/cash. Default3leaves5s/setupinside unchanged.

Missing consequence coverage: no assertion proves recordCancelledAfterFirstTake actually executes. Removing that call could pass every current check. Add actual take-derived sixpair driver/reference/week163/delta and sharedCancellations changes using existing relationship owner/constant. Preserve source input purity/paid-history assertions and originalbudget. A selector showing released people/workflow establishes inventory release; actual subsequent public staffing action/native reused capacity is not measured here and should remain a disclosed gap until fixed supported control qualifies.

No positive or RED execution credited; source requires new current49 receipt fields, final reader first causes may be earlier allocator/workflow guards, preserve actual messages. No reviewer runtime/K/R edits.
