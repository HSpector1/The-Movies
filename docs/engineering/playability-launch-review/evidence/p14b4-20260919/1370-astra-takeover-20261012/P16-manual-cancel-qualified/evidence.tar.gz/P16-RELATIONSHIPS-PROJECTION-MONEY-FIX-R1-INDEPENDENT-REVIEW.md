# Relationships zero-money predecessor projection

KEEP oneconstant test-helper correction, UNRUN. SOURCEee68f462005cdfbffa03ec41ae36e2e2172136332183b4889a5207286c78a863/MANIFEST0dee146fa965fc1a4d020771ede4873a2358e6b05eaecd9c2292a8ebadbfdee7 verified. Adds only estateSaleProceeds to existing P16_MONEY_KINDS exactlist.

Actual current49 fourth rival money key must be zero before predecessor projection. rightsStripped retains existing nonzero refusal then deletes the zero key before real frozen48 validation; withP16Era likewise adds the actual current zero field to expected era shape. Existing rights instrument/root/ledger/nonzero money refusals unchanged; no reader keys widened, real money dropped, or production source changed. Thus source-grounded fix for two additional R8 early projection failures, not generic regex/guard weakening or waiver of inherited three. Actual complete relationships qualification remains required; no result manufactured or runtime performed.
