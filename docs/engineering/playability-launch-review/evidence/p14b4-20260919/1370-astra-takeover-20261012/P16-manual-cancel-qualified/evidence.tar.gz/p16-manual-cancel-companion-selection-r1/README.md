UNRUN source-only companion inventory: COMPLETE5 files154identities (49+53+22+15+15). Exact fullnames/staticeach fixtures and six-seat15pair expansion parsed with installedTypeScript syntax only; no test/engine/Vitest imported or collected. Currentsourcehashes/lineRefs/budgets in EXPECTED-IDENTITIES.

Budgets preserved: actions49/cancelcausal22/S5save15/Save49save15 coredefault5000. Relationships53 includes actualexplicit60000 and120000 leaves plusdefault5000; no template5s imposed. No hooks/budgetoverride introduced. Allsetup/cache/assertions unchanged.

Evidence available (fullselectedrows/messages/durations retained INHERITED-OBSERVATIONS):
Save47: tests/actions.test.ts {'passed': 49}, tests/p13b-s5-save-v24.test.ts {'passed': 15}, tests/p14b4-cancel-causal-proof.test.ts {'passed': 22}, tests/p14b5-relationships.test.ts {'passed': 50, 'failed': 3}
P15B-original159: tests/actions.test.ts {'passed': 49}, tests/p13b-s5-save-v24.test.ts {'passed': 15}, tests/p14b4-cancel-causal-proof.test.ts {'passed': 22}, tests/p14b5-relationships.test.ts {'passed': 50, 'failed': 3}
P16-coherent181-r2: tests/p16a-save-v46.test.ts {'passed': 15}

Known inherited relationships family2 firstpostmigrationrival take/repetition andfamily5rivalrelease fail expected film6 but actual[] in originalSave47 andP15Bcore; this is prior reachedpremise failure, not permission to acceptnewchanges. Existing S5save middeployment reportsPASS at7662.00282ms in qualifiedP15Breadercontinuation, versusSave47samefullname6606.952032ms; source noexplicitoverride/default5000. TimingOPEN despite reportedPASS, perexisting P15B-FINAL204-R2-TECHNICAL-CHECKPOINT-REVIEW.md. Preserve these exactlimits and futurecompleteactualoutcomes, never infer greenfrominheritedlabel. Save49save15 alreadyincluded currentcoherent76; parent can decide constituent reuse onexactsource/input invariance, but requestedcompletecompanionselection includes it unchanged. No broaderallcore/acceptance claim.

Next parent gate afterfocusedmanual3qualification: admit exactcurrent source plus mandatory actualfixture/dependency inputs and runcompletefive selection with originalbudgets/solelane. This directory is selection metadata, not executionauthorization or boundrunner. No K/R/index/HANDOFF/source edits, newfixtures/captures/hydration/tests/compiler/runtime.
