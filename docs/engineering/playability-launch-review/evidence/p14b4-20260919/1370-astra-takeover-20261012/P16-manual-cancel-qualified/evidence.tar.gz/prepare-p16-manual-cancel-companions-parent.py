import pathlib,json,hashlib,re,os,difflib
A=pathlib.Path('/Users/zacheryspector/studio-scratch/1370-astra-takeover-20261012');K=pathlib.Path('/Users/zacheryspector/studio-specialists/p16')
old=A/'p16-work-release61-integration-runner-r7';D=A/'p16-work-release61-integration-runner-r8';out=A/'p16-work-release61-integration-r8-run';selection=A/'p16-manual-cancel-companion-selection-r1'
prior=A/'p16-work-release61-integration-r7-run';audit=A/'p16-work-release61-integration-r7-parent-reconciliation'
assert not D.exists() and not os.path.lexists(A.parent/'HEAVY-LANE-LOCK');D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
expected=json.loads((selection/'EXPECTED-IDENTITIES.json').read_text());assert len(expected)==5 and sum(len(x['names']) for x in expected)==154
for row in expected:
 assert sha(K/row['file'])==row['sourceSHA256']
 assert set(row['names'])=={x['fullName'] for x in row['leaves']}
 assert len(row['names'])==len(row['leaves']) and all(x['budgetMs'] in [5000,60000,120000] for x in row['leaves'])
write('EXPECTED-IDENTITIES.json',expected)
files=[x['file'] for x in expected];commands=[json.loads((old/'SELECTION.json').read_text())[-1][:10]+files];commands[0][9]='--outputFile.json='+str(out/'results.json');write('SELECTION.json',commands)
(D/'auto_freeze.py').write_bytes((old/'auto_freeze.py').read_bytes())
account=(old/'account-results.py').read_text()
account=account.replace(" for x in a:\n", " budgets={leaf['fullName']:leaf['budgetMs'] for leaf in want['leaves']}\n assert set(budgets)==set(want['names'])\n for x in a:\n")
account=account.replace("'budgetQualified':x.get('duration') is not None and x['duration']<=5000", "'budgetMs':budgets[x['fullName']],'budgetQualified':x.get('duration') is not None and x['duration']<=budgets[x['fullName']]")
account=account.replace('coherent rights/save and absorption/F17; research included; notbroadgate','complete five manual-cancel companion files; exact original per-leaf budgets and inherited failures remain visible')
assert "x['duration']<=5000" not in account
(D/'account-results.py').write_text(account)
reuse={'priorRun':str(prior),'baseFreeze':str(prior/'freeze.json'),'independentFreeze':str(audit/'independent-freeze.json'),'parentResult':str(A/'P16-WORK-RELEASE61-INTEGRATION-R7-PARENT-RESULT.json'),'originalWrapperExit':0,'reusedChild':'tsc-root','requiredChildExit':0,'seconds':48,'rule':'Exact original compiler/source/index/HEAD/metadata/input equality against independently reconciled prior run; additional pinned companion fixtures/runner artifacts only. Prior focused3 result does not imply companion acceptance.'}
write('ROOT-REUSE.json',reuse)
helper=(A/'p16-work-release61-integration-runner-r6/root-reuse.py').read_text()
helper=helper.replace("result['terminal']['overallExit']==97", "result['terminal']['overallExit']==0")
helper=helper.replace("assert len(result['children'])==1", "assert len(result['children'])==2 and all(c['exit']==0 for c in result['children'])")
helper=helper.replace("child['seconds']==62", "child['seconds']==48").replace("'originalWrapperExit':97", "'originalWrapperExit':0")
(D/'root-reuse.py').write_text(helper)
s=(old/'runner.sh').read_text().replace(str(old),str(D)).replace(str(prior),str(out))
s=re.sub(r'^commands=.*$', 'commands='+repr(commands),s,flags=re.M)
s=s.replace('literal root compiler then complete manual-cancel three-test file commands','literal complete five-file companion command; prior root compiler reused after strict equality')
s=s.replace('fresh root compiler then complete manual-cancel3 with actual relationships/staffing/reader/publication rollback; original failed baseline retained','strictly reuse actual root0/48s; complete154 companion identities with original per-leaf budgets; all failures retained including inherited')
start=s.index('# Fresh compiler prerequisites,');end=s.index('run estate-red ',start)
s=s[:start]+'python3 -I -B "$D/root-reuse.py" "$OUT/freeze.json" > "$OUT/root-reuse.json" || exit 98\n'+s[end:]
s=re.sub(r'^run estate-red .*$', 'run estate-red node node_modules/vitest/vitest.mjs run --project core --no-file-parallelism --no-cache --reporter=default --reporter=json --outputFile.json="$OUT/results.json" '+' '.join(files),s,flags=re.M)
(D/'runner.sh').write_text(s);os.chmod(D/'runner.sh',0o755)
b=json.loads((old/'BINDINGS.json').read_text())
b.update(scope='Complete existing manual-cancel companions on qualified185',executionScope='Strict exact root0/48s reuse, complete5 files154identities; original per-leaf5s/60s/120s budgets, no waived inherited failures or wholeP16 acceptance',expectedCompiledTests={r['file']:r['sourceSHA256'] for r in expected},finalCleanTestAdmission='Independent complete5 source-derived identities/original budgets; qualified manual3 and predecessor compiler retained, actualcompanion outcome pending',rootReuse=reuse)
b['predecessorRunnerFiles']={n:sha(old/n) for n in ['runner.sh','BINDINGS.json','SELECTION.json','EXPECTED-IDENTITIES.json','auto_freeze.py','account-results.py']}
paths=[D/'EXPECTED-IDENTITIES.json',D/'account-results.py',D/'ROOT-REUSE.json',D/'root-reuse.py',prior/'freeze.json',audit/'independent-freeze.json',pathlib.Path(reuse['parentResult']),prior/'terminal.json',prior/'results.jsonl',prior/'tsc-root.log',A/'P16-CONTINUED-WORK-MANUAL-CANCEL-R7-ACTUAL-REVIEW.md']
paths += [q for q in selection.iterdir() if q.is_file()]
freeze=json.loads((prior/'freeze.json').read_text());paths += [pathlib.Path(p) for p,v in freeze['inputs'].items() if isinstance(v,list) and v[0]=='file']
text=(K/'tests/p13b-s5-save-v24.test.ts').read_text()
fixturePaths=re.findall(r"file: '(\./fixtures/[^']+)'",text)
paths += [K/'tests'/p[2:] for p in fixturePaths]
paths += [K/'tests/fixtures/p14/legacy-v28-shooting-5.json.gz']
paths += [K/'tests/fixtures/p14/genuine-v30-pre-b5'/('genuine-v30-'+n+'.json.gz') for n in ['first-take-at-five','rival-current-p1-and-p2','current-p1']]
paths += [K/'tests/fixtures/p14/genuine-v30-pre-b5/MANIFEST.json']
existing={r['path']:r['sha256'] for r in b['artifacts']}
for q in paths:
 assert q.is_file() and not q.is_symlink(),str(q)
 if str(q) in existing:assert existing[str(q)]==sha(q)
 else:b['artifacts'].append({'path':str(q),'sha256':sha(q)});existing[str(q)]=sha(q)
write('BINDINGS.json',b)
(D/'DELTA-vs-r7-runner.patch').write_text(''.join(difflib.unified_diff((old/'runner.sh').read_text().splitlines(True),s.splitlines(True),fromfile='r7/runner.sh',tofile='r8/runner.sh')))
(D/'README.md').write_text('UNRUN complete5/154 companion gate. Root0/48s reused only after exact full original/independent/current source/index/metadata and original inputs equality. Genuine V20/21/22/23/28/30 and prior45 fixtures pinned as actually used. All154 identities/per-leaf budgets remain original:139x5s,3x60s,12x120s. Three inherited relationship failures and S5 timing remain explicit observations, not waivers. No new source or assertions, no wholeP16/native claim. Lane/floors/freeze/four-bootstrap unchanged.\n')
write('PINS.json',{q.name:sha(q) for q in sorted(D.iterdir()) if q.is_file()});print((D/'PINS.json').read_text())
