# R6 P15 rank capture r2 executable static review

Disposition: PROCEED with isolated assembly, fresh C0 types and the bounded historical capture when existing lane/power/disk/source prerequisites permit. No blocking static finding. Independent measured capture review and explicit parent acceptance remain mandatory before current consumption. Fresh ABC types and independent measured current-boundary review remain separate gates. No runtime success, final ranking patch, NEW-failure resolution, landing or promotion is established here.

Reviewed exact manifest `36d7e09cb618ec6892489794971bae03a74c7b3eb060056009ff5657229418dd` (25 members) on 2026-10-05. All manifest member/reference hashes match. Statically parsed Python; read consequential assembler, guard, lifecycle and consumer code. Verified all non-payload origin hashes and descriptor maps, intentionally without reading the compressed fixture. No assembly, Node/compiler/test/game runtime, fixture payload read, moving current104 output inspection, nested delegation or live/frozen/index/HANDOFF mutation. Only this new review file was written.

## Immutable source and output boundaries

C0 producer is byte-identical to approved r1 `985eaecd6a2f3ae79cae8536b411d8e7127a29337ad0c157763d7f32005b5614`. The common TypeScript helper changes only its exclusive output namespace. Cleanup is byte-identical to reviewed ledger-r4 `4698b610b50289fd289e3235c564c087774b443422ca7e0ac6635284babc49e4`. Prior conceptual/producer review stands; no duplicated general review is needed.

ORIGINS exactly matches templates: C0199 files and ABC198 files, each with188 production files equal to its pinned historical/R6 source descriptor. Historical source remains HEAD `2eaa697effc38538c37da28b486786ce267a2284`; ABC production remains frozen R6 `a59301c631531d9189aef5ee1827d6886db78f45`. Assembly creates only a new fixed scratch namespace and refuses preexisting output. Mandatory `cp -c -p`, inode/link-count checks and exact hashes provide independent clones; no fallback/hardlink, patch replay or Git mutation. Origins are checked before/after. Only the declared dependency-directory symlink is allowed; source traversal rejects extra/missing regular files, symlinks/special source entries and byte drift. Full kit enumeration rejects extra/missing kit files. Descriptor bytes and all fixed references stay pinned. Empty extra directories do not add consumed source and are not represented as new file coverage.

## Executable binding and lifecycle

Runner requires the expected immediate heavy-lane parent/log/lock, actual working branch and explicit remote HEAD, clean bounded live source, raw index/stage/diff identity, pinned recorder/manual guard, exact source/kit/assembly, Node20.20.2, AC and at least5GiB available. It records the consumed environment subset and executable entrypoint hashes; NODE_OPTIONS/NODE_PATH preload overrides are refused. Explicit mode-specific RANK variables override inherited values. Parent no-writer/one-heavy-lane discipline remains necessary; the existing lane wrapper is not newly claimed to provide a general atomic scheduler.

Capture and consume require successful types with all current pins equal, including arm, source, kit, publicationHEAD/index/environment/tool identities. Completed-receipt validation rechecks artifact bytes, binding, exact formal child command, original formal HEAD and pre/post manual/index/source checks. Prior publication types cannot silently qualify a new coordinator. Historical accepted capture may retain its original coordinator, while ABC types must match the current one.

Owned Node group launch is recorded before waiting. Test limit remains300seconds and owned-group wait330seconds; no retry or broadened PID discovery. Unchanged cleanup treats EPERM/UNKNOWN as failure, stops escalation and preserves actual child exit, timeout, cleanup and reporting errors separately. Formal recorded child exit is reconciled with this disposition. Missing CHILD, missing producer RESULT, failed source postflight, absent success output or malformed proof cannot produce accepted completion; wrapper failure preserves available raw/formal facts and unknowns. Setup/preflight failures before the wrapper try block can terminate with a traceback and partial files rather than WRAPPER-FAILURE; they still lack an accepted completed receipt and must be preserved as refusals/incomplete attempts. Filesystem failure can prevent any receipt write, as already acknowledged. This is honest failure handling, not a claim of unconditional receipt availability.

## Capture acceptance and current consumer

Consumer cannot start solely from capture files: it requires a separately supplied exact parent acceptance object, nonempty independently hashed review, completed C0 capture receipt and its artifact/formal identity. It checks kit/source/assembly, original45 engine identity, original42 input pins, seed, exactly130..135 six boundaries/five default ticks, writer45, own-era root130→135 proof and actual gzip hash. Capture report/data must show complete1PASS0FAIL. Review meaning is an explicit parent decision, not machine inference from arbitrary prose. No automatic capture-to-consumer continuation exists.

The ABC consumer imports no tick and performs zero current ticks. It verifies capture manifest/gzip/raw pins, strict current validateSaveV45 admission, week135 and original root130/empty snapshots, exact original serialized45 bytes, then current public45→44→45. It requires root135/empty snapshots, downgrade identity, full non-P15 state equality and original/down input neutrality. `stripP15` is used only in comparisons; projected objects never feed production. Separate migrateToLive/strict46/empty-only46→45 must reproduce the genuine45 bytes and leave historical/live inputs unchanged. PROOF booleans are emitted only after the assertions; success-output checks require the completed proof. Any sibling refusal remains failed evidence.

Original current130→135 recovery-refusal failure remains unchanged and historical capture cannot be relabeled as R6 gameplay. After independent capture and consumer measurement, final reviewed test integration must retain both current refusal/neutrality and original positive claims-less obligation, execute the complete modified ranking file and reconcile new/unmasked failures against both baselines. Preparation alone does not remove the existing NEW blocker.

## Exact reviewed artifact pins

All paths below are within S=`/Users/zacheryspector/studio-scratch`. Manifest transitively pins the entire25-member kit and FIXED-PINS binds the reused dependencies/reviews.

| Artifact | SHA-256 |
| --- | --- |
| `S/1368-r6-p15-rank-capture-prep-r2/MANIFEST.json` | `36d7e09cb618ec6892489794971bae03a74c7b3eb060056009ff5657229418dd` |
| `S/1368-r6-p15-rank-capture-prep-r2/assemble.py` | `4497b9269a75234f48c467f5aa1e82fbb2e6b44d9a9e7518abd5b3dadf0ed503` |
| `S/1368-r6-p15-rank-capture-prep-r2/common.py` | `2ccd21e79fac77379b938d340652e4566f5c4fef898f8405e5a239e1e73591ed` |
| `S/1368-r6-p15-rank-capture-prep-r2/run.py` | `663cdf822d7d0919d341454931174a044bccbe3614a70776a29c307155681558` |
| `S/1368-r6-p15-rank-capture-prep-r2/cleanup.py` | `4698b610b50289fd289e3235c564c087774b443422ca7e0ac6635284babc49e4` |
| `S/1368-r6-p15-rank-capture-prep-r2/FIXED-PINS.json` | `d364e3c101bd20bb3ea6f618d3449da0b963c6cae7717b0d3aec0f311cdb0f87` |
| `S/1368-r6-p15-rank-capture-prep-r2/ORIGINS.json` | `006eee46f32b4a45823683e6f3defcec2c9d8a83d62603f426d8e710f66d4b1e` |
| `S/1368-r6-p15-rank-capture-prep-r2/templates/ASSEMBLY.json` | `7fcd151d025c4e834afc7086a818c314226ccf4bd77561d8a892ac2835351878` |
| `S/1368-r6-p15-rank-capture-prep-r2/templates/C0-SOURCE-PINS.json` | `ac6bedc73bfecf0bc268acea6cad030e1168bf1b5f858277a2eeafbf1aa938a5` |
| `S/1368-r6-p15-rank-capture-prep-r2/templates/ABC-SOURCE-PINS.json` | `64444842bc40ca6fba76664760bf277e942044632af64adea1eec5de08794d56` |
| `S/1368-r6-p15-rank-capture-prep-r2/files/C0/tests/1368-rank-capture.test.ts` | `985eaecd6a2f3ae79cae8536b411d8e7127a29337ad0c157763d7f32005b5614` |
| `S/1368-r6-p15-rank-capture-prep-r2/files/ABC/tests/1368-rank-capture.test.ts` | `b6250a94e17440b97086d007febe8e7d7aa7dfd5bfab4018af8f64e7f39749e5` |
| `S/1368-r6-p15-rank-capture-prep-r2/files/common/tests/1368-rank-common.ts` | `b34ed51e97e033125f472ccab99d3d3f916c3a220cc827f04836de49d4e95253` |
| `S/1368-independent-review/R6-P15-RANK-DIAGNOSIS-STATIC.md` | `5db68e45073cf0b38ef61f8d1a0a88401520313d8b1d0092fc70b27a4d98b44c` |
