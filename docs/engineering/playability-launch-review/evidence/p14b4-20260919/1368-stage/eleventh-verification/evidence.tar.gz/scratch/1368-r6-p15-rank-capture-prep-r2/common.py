"""Pinned input/source and exclusive-output utilities; no import-time IO or runtime."""
import hashlib, json, os, re, subprocess
from pathlib import Path
R=Path('/Users/zacheryspector/The-Movies-headless-program')
S=Path('/Users/zacheryspector/studio-scratch')
P=S/'1368-r6-p15-rank-capture-prep-r2'
A=S/'1368-r6-p15-rank-capture-arms-r2'
RUNS=S/'1368-r6-p15-rank-capture-runs-r2'
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
NODE=Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
BRANCH='refs/heads/wip/headless-program-20260916-ts'
SCOPE=['src','bridge','tests','ui','generated','scripts','package.json','package-lock.json','vitest.config.ts','vitest.workspace.ts','tsconfig.json','tsconfig.bridge.json','tsconfig.src.json',':(exclude)tests/fixtures',':(exclude)ui/e2e',':(exclude)ui/public']
SUFFIXES=['.json','.patch','.txt','-preflight.json','-postflight.json']
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(p): return digest(p.read_bytes())
def safe(p):
    assert p.is_absolute() and str(p)==os.path.abspath(p),str(p)
    for q in [p,*p.parents]: assert not q.is_symlink(),str(q)
def exclusive(p): safe(p); assert not os.path.lexists(p),'existing output '+str(p)
def write(p,obj):
    safe(p)
    with p.open('x') as f: json.dump(obj,f,indent=2);f.write('\n')
def read(p): safe(p);return json.loads(p.read_text())
def artifact(p): safe(p);assert p.is_file();return {'sha256':sha(p),'bytes':p.stat().st_size}
def check_artifacts(rows):
    for name,row in rows.items(): assert artifact(Path(name))==row,name
def environment():
    prefix=[str(NODE.parent),str(R/'.venv/bin')]
    remainder=[entry for entry in os.environ.get('PATH','').split(':') if entry not in prefix]
    return dict(os.environ,PATH=':'.join(prefix+remainder),GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args): return subprocess.check_output(['git',*args],cwd=R,env=environment())
def kit(pin):
    assert re.fullmatch('[0-9a-f]{64}',pin)
    assert sha(P/'MANIFEST.json')==pin
    m=read(P/'MANIFEST.json')
    for name,row in m['files'].items(): assert artifact(P/name)==row,name
    all_paths=list(P.rglob('*'))
    for item in all_paths:
        safe(item);assert item.is_file() or item.is_dir(),'special kit entry '+str(item)
    actual=sorted(str(p.relative_to(P)) for p in all_paths if p.is_file() and p!=P/'MANIFEST.json')
    assert actual==sorted(m['files']),'extra/missing kit files'
    check_artifacts(read(P/'FIXED-PINS.json'))
    return m

def source(arm,pin):
    kit(pin);assert arm in ['C0','ABC']
    expected=read(P/'templates'/f'{arm}-SOURCE-PINS.json')
    assert read(A/arm/'SOURCE-PINS.json')==expected
    assert read(A/'ASSEMBLY.json')==read(P/'templates/ASSEMBLY.json')
    assert read(A/arm/'ASSEMBLY.json')==read(P/'templates'/f'{arm}-ASSEMBLY.json')
    T=A/arm/'tree';safe(T);actual=[]
    for root,dirs,files in os.walk(T,followlinks=False):
        root=Path(root)
        if root==T:
            assert 'node_modules' in dirs;dirs.remove('node_modules')
        for name in dirs:safe(root/name)
        for name in files:
            f=root/name;safe(f);assert f.is_file() and f.stat().st_nlink==1
            rel=f.relative_to(T).as_posix();assert rel in expected and sha(f)==expected[rel],rel
            actual.append(rel)
    assert sorted(actual)==sorted(expected)
    assert (T/'node_modules').is_symlink() and (T/'node_modules').resolve()==(R/'node_modules').resolve()
    assert sum(n.startswith('src/') for n in expected)==188
    return expected

def verify(head,pin,arm):
    assert re.fullmatch('[0-9a-f]{40}',head)
    assert git('rev-parse','HEAD').decode().strip()==head
    assert git('symbolic-ref','HEAD').decode().strip()==BRANCH
    assert git('ls-remote','--exit-code','origin',BRANCH).decode().split()==[head,BRANCH]
    assert git('diff','--name-only','HEAD','--',*SCOPE)==b''
    assert git('ls-files','--others','--exclude-standard','--',*SCOPE)==b''
    expected=source(arm,pin)
    assert not os.environ.get('NODE_OPTIONS') and not os.environ.get('NODE_PATH'),'unbound Node preload/search options'
    env=environment()
    consumed_env={key:env.get(key) for key in ['PATH','NODE_OPTIONS','NODE_PATH','NODE_ENV','TZ','LANG','LC_ALL','CI','VITEST','PYTHONHASHSEED','PYTHONDONTWRITEBYTECODE']}
    assert subprocess.check_output([str(NODE),'--version'],text=True).strip()=='v20.20.2'
    index=Path(git('rev-parse','--path-format=absolute','--git-path','index').decode().strip())
    entries=[NODE,R/'node_modules/typescript/bin/tsc',R/'node_modules/vitest/vitest.mjs']
    return {'arm':arm,'publicationHead':head,'publicationIndexSha256':sha(index),
      'publicationStageSha256':digest(git('ls-files','--stage','-z')),
      'boundedDiffSha256':digest(git('diff','HEAD','--',*SCOPE)),
      'sourcePinsSha256':sha(A/arm/'SOURCE-PINS.json'),'assemblySha256':sha(A/'ASSEMBLY.json'),
      'kitManifestSha256':pin,'regularFiles':len(expected),'environment':consumed_env,'entrypoints':{str(p):sha(p) for p in entries}}
