import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { lstatSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, isAbsolute, resolve } from 'node:path'
export const sha = (v: string | Uint8Array) => createHash('sha256').update(v).digest('hex')
export function snap(value: unknown): string {
  const ancestors = new Set<object>()
  const visit = (v: unknown): unknown => {
    if (v === null) return ['null']
    if (v === undefined) return ['undefined']
    if (typeof v === 'number') return ['number', Object.is(v, -0) ? '-0' : String(v)]
    if (typeof v === 'string' || typeof v === 'boolean' || typeof v === 'bigint') return [typeof v, String(v)]
    assert(typeof v === 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) return ['Map', [...v].map(([k, x]) => [visit(k), visit(x)])]
      if (v instanceof Set) return ['Set', [...v].map(visit)]
      if (v instanceof Date) return ['Date', v.toISOString()]
      if (ArrayBuffer.isView(v)) return [v.constructor.name, Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64')]
      if (v instanceof ArrayBuffer) return ['ArrayBuffer', Buffer.from(v).toString('base64')]
      if (Array.isArray(v)) return ['Array', Array.from({ length: v.length }, (_, i) => i in v ? visit(v[i]) : ['hole'])]
      const proto: unknown = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      const record = v as Record<string, unknown>
      return [proto === null ? 'null-object' : 'object', Object.keys(record).sort().map(k => [k, visit(record[k])])]
    } finally { ancestors.delete(v) }
  }
  return JSON.stringify(visit(value))
}
export function ordinary(path: string): void {
  assert(isAbsolute(path))
  for (let p = path; ; p = dirname(p)) { assert(!lstatSync(p).isSymbolicLink(), `symlink ${p}`); if (p === dirname(p)) break }
}
export function setup() {
  const out = process.env.RANK_OUTPUT, pinsPath = process.env.RANK_SOURCE_PINS
  assert(out && pinsPath && isAbsolute(out) && isAbsolute(pinsPath))
  ordinary(dirname(out)); ordinary(pinsPath)
  assert(out.startsWith('/Users/zacheryspector/studio-scratch/1368-r6-p15-rank-capture-runs-r1/'))
  mkdirSync(out) // exclusive, including dangling symlinks
  const raw = readFileSync(pinsPath); assert.equal(sha(raw), process.env.RANK_SOURCE_PINS_SHA)
  const pins = JSON.parse(raw.toString()) as Record<string, string>
  const check = () => { for (const [name, hash] of Object.entries(pins)) { const p = resolve(name); ordinary(p); assert.equal(sha(readFileSync(p)), hash, name) } }
  check()
  return { out, pins, check, write: (name: string, value: unknown) => writeFileSync(resolve(out, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' }) }
}
