"""Exclusive independently cloned exact199/198-file historical/current arms; no Git or runtime."""
import sys
sys.dont_write_bytecode=True
import argparse,os,subprocess
from common import P,A,R,kit,read,safe,exclusive,sha,source,artifact

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--manifest-sha256',required=True);a=ap.parse_args()
    assert __file__==str(P/'assemble.py');kit(a.manifest_sha256)
    origins=read(P/'ORIGINS.json')
    for arm,rows in origins.items():
        for name,row in rows.items():assert artifact(__import__('pathlib').Path(row['path']))=={k:row[k] for k in ['sha256','bytes']},name
    exclusive(A);A.mkdir()
    for arm,rows in origins.items():
        T=A/arm/'tree';T.mkdir(parents=True)
        for name,row in rows.items():
            src=__import__('pathlib').Path(row['path']);dst=T/name;safe(src);exclusive(dst);dst.parent.mkdir(parents=True,exist_ok=True)
            subprocess.run(['/bin/cp','-c','-p',str(src),str(dst)],check=True)
            assert sha(dst)==row['sha256'] and dst.stat().st_nlink==1 and dst.stat().st_ino!=src.stat().st_ino
        assert (R/'node_modules').is_dir();(T/'node_modules').symlink_to(R/'node_modules',target_is_directory=True)
        for name in ['SOURCE-PINS.json','ASSEMBLY.json']:
            dst=A/arm/name;exclusive(dst);dst.write_bytes((P/'templates'/f'{arm}-{name}').read_bytes())
    (A/'ASSEMBLY.json').write_bytes((P/'templates/ASSEMBLY.json').read_bytes())
    for arm,rows in origins.items():
        source(arm,a.manifest_sha256)
        for name,row in rows.items():assert artifact(__import__('pathlib').Path(row['path']))=={k:row[k] for k in ['sha256','bytes']},name
    print({'assemblySha256':sha(A/'ASSEMBLY.json'),'runtimeExecuted':False})
if __name__=='__main__':main()
