"""Local ledger cleanup/reporting repair. No discovery or signals outside the launched PGID."""
import os
import signal
import time


def error_row(operation, error):
    return {'operation': operation, 'type': type(error).__name__, 'errno': getattr(error, 'errno', None), 'message': str(error)}


def owned_group_status(pgid, errors):
    try:
        os.killpg(pgid, 0)
        return 'PRESENT'
    except ProcessLookupError:
        return 'ABSENT'
    except OSError as error:
        # EPERM is UNKNOWN, never evidence that a group disappeared.
        errors.append(error_row('probe', error))
        return 'UNKNOWN'


def cleanup_owned_group(proc):
    pgid = proc.pid
    assert pgid > 1 and pgid != os.getpgrp()
    errors, signals, attempts = [], [], []
    def poll():
        try:
            return proc.poll()
        except OSError as error:
            errors.append(error_row('leader-poll', error))
            return None
    code = poll()
    state = owned_group_status(pgid, errors)
    initial = state
    # Any uncertain identity/permission result stops escalation. No broad ps/kill fallback.
    for sig, label in [(signal.SIGTERM, 'TERM'), (signal.SIGKILL, 'KILL')]:
        if state != 'PRESENT' or errors:
            break
        attempts.append(label)
        try:
            os.killpg(pgid, sig)
            signals.append(label)
        except ProcessLookupError:
            state = 'ABSENT'
            break
        except OSError as error:
            errors.append(error_row(label, error))
            state = 'UNKNOWN'
            break
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            code = poll()
            state = owned_group_status(pgid, errors)
            if state != 'PRESENT' or errors:
                break
            time.sleep(0.1)
    code = poll()
    # Do not turn an earlier UNKNOWN into a later unrecorded success.
    if state != 'UNKNOWN' and not errors:
        state = owned_group_status(pgid, errors)
    return code, {'ownedProcessGroup': pgid, 'statusBeforeCleanup': initial,
                  'statusAfterCleanup': state, 'signals': signals, 'signalAttempts': attempts,
                  'errors': errors, 'noSurvivors': state == 'ABSENT' and not errors,
                  'leaderReaped': code is not None,
                  'cleanupVerified': state == 'ABSENT' and code is not None and not errors}


def child_exit(receipt):
    if receipt['timedOut'] is True:
        return 124
    group = receipt['processGroup']
    if receipt['reportingErrors'] or not receipt['allGuardsExact'] or not group['cleanupVerified'] or not group['noSurvivors'] or not group['leaderReaped']:
        return 1
    code = receipt['actualChildExit']
    return code if isinstance(code, int) and code >= 0 else 1


def finish_child(proc, timed_out, started, command, check_source, write_receipt, wait_error=None):
    """Always attempt an honest receipt, including when cleanup raises before returning."""
    errors = [] if wait_error is None else [error_row('wait', wait_error)]
    code = None
    group = {'ownedProcessGroup': proc.pid, 'statusBeforeCleanup': 'UNKNOWN',
             'statusAfterCleanup': 'UNKNOWN', 'signals': [], 'signalAttempts': [],
             'errors': [], 'noSurvivors': False, 'leaderReaped': False, 'cleanupVerified': False}
    try:
        code, group = cleanup_owned_group(proc)
    except Exception as error:
        errors.append(error_row('cleanup', error))
        try:
            code = proc.poll()
            group['leaderReaped'] = code is not None
        except Exception as poll_error:
            errors.append(error_row('leader-poll-after-cleanup-error', poll_error))
    exact = False
    try:
        exact = check_source() is True
        if not exact:
            errors.append({'operation': 'source-check', 'type': 'GuardMismatch', 'errno': None, 'message': 'source/binding comparison was not true'})
    except Exception as error:
        errors.append(error_row('source-check', error))
    receipt = {'actualChildExit': code, 'timedOut': timed_out, 'processGroup': group,
               'elapsedSeconds': time.monotonic() - started, 'allGuardsExact': exact,
               'command': command, 'reportingErrors': errors}
    # Filesystem failure can still prevent this write; caller must preserve its formal record.
    write_receipt(receipt)
    return child_exit(receipt)
