# R6 Scientist residual static review

Disposition: REFINE one coverage comment before adopting this exact candidate; executable test changes are statically acceptable within the requested two-S10-leaf scope. All runtime/type/premise success remains unmeasured. Original current-r1 failures must remain immutable; this review does not close either NEW identity or authorize broader acceptance/landing.

Exact proposal manifest `84cf52216da015b5819c6be6e75d2159bb01d64b4d8a4059ae3ff22109e54c3f`; patch `da860681833c14330ec09adbd1bd8347ef50564e4f6932291fd2a6ff1f614cd8`. Independently verified full preimage/postimage and exact generated unified diff, every source/evidence pin, fixture manifest/producer provenance and compressed-byte hash/size without decompression. The two extracted raw failure blocks exactly match the immutable current-r1 original blocks. No tests, Node/compiler, game/producer execution, fixture payload decompression, nested delegation or live/frozen/index/HANDOFF mutation. Only this new review file was written.

## Required narrow correction

The new comment `P15's own V45 tests retain the ranking boundary` ambiguously describes the accepted controls as historicalV45 inputs. Replace it with an explicit description of `rank-root-downgrade-recorded-quarter-refuses` and `rank-root-downgrade-frozen-builders-refuse`: both use fresh current week13 state and test the public downgrade/frozen-builder ranking refusal. They were measured passing in P15-r2 on R6, as independently recorded in R6-P15-MEASURED. They are not genuine historicalV45 fixture executions. No behavioral change is requested for this correction. Pin the resulting editorial revision; the source approval below applies when only that comment changes, without requiring a new general audit.

## Executable scope and historical substitution

The entire diff is the two NEW S10 leaf bodies and removal of their unused stripP15 import. No production, fixture, helper, seed, horizon, timeout, sibling test or remaining assertions are changed.

The first leaf retains the original live hardResearch566 route and import/admission assertion. It checks each of the three actual recovery categories, requires the full anchored exact first-refusal message for both public migrateToV36 and migrateToV35, and checks complete serialized live/state neutrality after each call. It removes no current recovery/history/fund/receipt authority. The genuine V37 Scientist converter rejection remains separately reached through strict validated existing scientistRaw, now with explicit week670/retired-Scientist premises and preserved historical bytes. The first refusal and all three categories are supported by the measured guard/error; the second call and later assertions were masked and remain unmeasured until execution.

The second leaf replaces the former current hardIdle566-derived old-shape schema probe with an existing strictly validated genuine Save37week670-derived schema probe. This deliberately changes only the synthetic reader-control source, not a historical gameplay claim or governed downgrade. Source 48a76a87bca624d6dff81118d5ecb6df56ca00d2, exact original producer and fixture hashes are established. The inspected producer uses genuine V33Scientist520, real continuation617/618/669/670, unchanged provenance and strict whole-save roundtrips; its historical record is announced618/effective670/retired670. Producer/source inspection and compressed pin verification do not prove the newly proposed reader controls pass.

StrictV37 admission precedes every clone. Explicit Scientist retirement/unused-extension/no-extension-case premises prevent removing its positive-control row from stranding its own extension case. V37 shares V36 shape under a changed Scientist policy. Only the existing version34/35/36 shape changes remain: extension flags and case variants for versions below36, cohorts only for34, plus the deliberate envelope version. No current recovery, accounting, disposition, P15, relationship, writing or other later history is stripped to invent an old world. The historical input itself remains unchanged.

For each of34,35,36, the positive clone removes only t-sci-00's Scientist record and must pass the complete public import reader before the full record-bearing envelope must fail with the existing Scientist-record regex. All three whole-envelope positives and all three Scientist negatives remain. The regex is not broadened. Positive and negative clones remain synthetic schema controls, never played/exported or passed through a pretend downgrade. Original genuine historical input and all clones are serialized for neutrality checks. Frozen validator source confirms Scientist-law refusal is separate from live tuning; cohort-request semantics exclude Scientists, so retaining genuine film cohort facts is consistent with the stated control construction. Actual whole-envelope success remains a measured gate, not a static promise.

This substitution preserves the intended frozen-reader Scientist-law coverage while dropping the invalid implication that the current hardIdle566 world can be projected back through lossless historical schemas. It does not establish that old current-world projection now works and makes no such claim. Other live Scientist validity/corruption tests remain unchanged.

## Required verification and evidence limits

After the one comment correction and exact integration, use fresh candidate-bound types and the parent’s original full-file selection/recording policy. Verify both current downgrade calls, all3whole-envelope positive/Scientist-negative pairs, genuineV37 converter refusal, historical premises and every previously masked trailing assertion. Preserve and classify any new failure rather than broadening regexes or deleting history to obtain a pass. Existing source/failed evidence and genuine fixture remain immutable. No rank-boundary, Scientist-reader, production or broad acceptance is inferred from preparation success.

## Exact inspected pins

S=`/Users/zacheryspector/studio-scratch`.

| Artifact | SHA-256 |
| --- | --- |
| `S/1368-r6-scientist-residual-prep/MANIFEST.json` | `84cf52216da015b5819c6be6e75d2159bb01d64b4d8a4059ae3ff22109e54c3f` |
| `S/1368-r6-scientist-residual-prep/scientist-residual.patch` | `da860681833c14330ec09adbd1bd8347ef50564e4f6932291fd2a6ff1f614cd8` |
| `S/1368-r6-scientist-residual-prep/preimages/tests/p14c2s-scientist-retirement.test.ts` | `98e866e3f689590124d96a0ca40253efb1bd82ba880ace43dd961bd24ece1668` |
| `S/1368-r6-scientist-residual-prep/tree/tests/p14c2s-scientist-retirement.test.ts` | `7b6893f136015a59cb1465e06c547790e078e010b07b8751c8ba3906c4334bcd` |
| `S/1368-r6-scientist-residual-prep/EVIDENCE.md` | `ec74cb54bebad2ebe8ccd136e9b8edff92a69004f230de5653db81070ac3c9bd` |
| `S/1368-r6-scientist-residual-prep/failure-evidence.json` | `b37f55751cab22ec59201b88925cc9a74a0dfa786aae1d058dc333d33683e2ff` |
| `S/1368-save46-swept-proposal-r6/tree/tests/helpers/p14c3-fixtures.ts` | `786062c921a3d8a32728b90aeee0d037fca7f28555dcd7eeec32f84f6f3b3708` |
| `S/1368-save46-swept-proposal-r6/tree/tests/fixtures/p14/genuine-projection51-runtime-c2rm/MANIFEST.json` | `9c6dc13f98ee5b1f17864ea35afca6dfca5c7b08740f2612ab33dc56e1587e47` |
| `S/1368-independent-review/R6-P15-MEASURED.md` | `d1f8105ee0e5aa58dbd3e1c4aab623d657dc0ad4b40211193dca2f5a32019585` |
