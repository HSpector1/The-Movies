# R6 current expectation residual: independent static review

Disposition: **PROCEED with bounded parent integration and fresh verification** of this exact proposal. No revision is required by this static review. This does not accept modified-source behavior, current104 GREEN, closure, landing or promotion. No modified-source runtime receipt exists.

Reviewed 2026-10-05 under the parent's bounded independent-review assignment. Read HANDOFF, adopted1363-N, draft1368-K, completed R6-CURRENT-MEASURED and exact proposal/source/evidence. Only this new report was written. No Git command, game runtime, Node, compiler, tests, fixture decompression, nested delegation, live/frozen-source or HANDOFF/index write was performed. Disk/process/launch safety and remote reconciliation remain parent-owned.

## Exact scope and pins

S=`/Users/zacheryspector/studio-scratch`. Proposal is `S/1368-r6-current-expectation-residual-prep`.

- MANIFEST `f98dfd7f8c3ce081aba33f6142963cd6717cf2b0ec15252a06c9268bdd2ad917`.
- PATCH `02eaf6bfcf7a469ba692f3cf462de47239fd17ed0300f3219e06ea3d1cbcf87c`.
- INPUT-PINS `da5c26172ff4981b9d3e3f806a8649d63568a67a61e4f006d9a387addb11f349`.
- OPERAND-DIFFS `d263656e00706552319a593d131404fbd725bca013bdfcf1690af826862a29ae`.
- PER-LEAF-EVIDENCE `275e3d1736b8e033cbcb1191bd71afa257ba0e7ba65ef8b2d3fbb0ef354e4dee`.
- Frozen R6 SOURCE-PINS `2d92af276435275d7ec45554e188962780f0e08467a17dbe42d7ced5f6c85f64`; source root `S/1368-save46-swept-proposal-r6/tree`.
- Existing current-r1 RESULT `303d64a9d9c990cea5556f403a9039d71f5488112fb9363d246dbdf107b38c02`; binding `78c340496c30ca4aec6a791639d327b4340f24868613a32978e0055b00fd0cb6`.
- Current attribution MANIFEST `148aca0c8f5e49644ce9522a15f6f052f1732017e1b4a5731ffd92df0592e217`; raw-failure-blocks `55109ae75fcd44ef31c4b79077cf8dc3bbae074385b6758a9573576440303c54`.
- Unchanged helper `tests/helpers/recovery-migration-expectation.ts` SHA `4f2d8ebdec18d854a0db8e2101ebc28654ba495e8f9e6e0f951471a7165effa1`.
- Reviewed production migration source `src/core/save.ts` SHA `cd4a1d42d02fee6280e2a658ba304448c0ab93c0e57fd8866ef5a65e0072c035`.

Independently rehashed all52 MANIFEST-member and INPUT-PINS references, checked every byte count and proposal MANIFEST SHA. All match. Each of seven complete preimages equals its frozen R6 file. Independently regenerated the unified diff, which equals PATCH byte-for-byte, and inverted precisely the declared edits to restore all seven complete preimages. Thus all other lines, literals, old helper composition, admissions, fixtures, protected hashes, historical producer provenance, full comparisons, slots, trailing assertions, test declarations, caps and deadlines remain byte-identical. Independently compared every64-hex literal sequence as an additional pin check. This is a bounded source review, not a repeat of the prior complete1626-source measured audit.

Exactly13 proposed identities are NEW versus accepted M3:12 expected-state identities across six files, plus one current-writer literal identity. Each proposal rawFailure row exactly matches the original raw-failure rows. The two Scientist-retirement NEW identities are excluded. The three CHANGED ledger/Save38 identities are untouched. No production/helper/fixture input changes are present.

## Independent complete operand analysis

I did not execute the proposal's analyzer. An independent lexer converted only unquoted pretty-format Object/Array tokens and trailing commas, preserving string tokens and rejecting unsupported/unconsumed text and duplicate object keys; canonical operand strings were parsed directly. Every complete displayed expected/actual pair was reconstructed from its original raw block and checked against recorded text and block hashes. Only the two recovery fields were removed from a detached actual for type-aware recursive equality against the complete expected value, including all object keys, primitive values, list lengths and list order. This proves no other old field/history differs in these displayed operands. Nothing was fed into production.

| Raw block | Displayed week | Null cutting additions | Zero refund additions | Header identities |
| --- | ---: | ---: | ---: | ---: |
|13 RM current|670|5|55|1|
|14 RM saved LOAD|669|5|55|1|
|15 Scientist grouped|521|5|45|2|
|18 D15/D16 memo|45|4|4|2|
|19 D17 outgoing53|208|4|20|1|
|20 B55-1/B55-2 memo|45|4|4|2|
|21 B55-3 outgoing54|61|4|8|1|
|22 outgoing55|111|4|12|1|
|38 Q17|45|4|4|1|

Every cutting value is exactly `{version:1,since:null}`; each refund is integer0 in a historical period's movements. Counts are measured per displayed state and are not generalized to a fixed rival count. All nine full displayed comparisons differ only by those additions.

**Scientist824 qualification:** block15 groups842 and824 failure headers but prints842's week521 operands. There is no separately printed824 week53 operand pair, and no independent measured53 difference/count is claimed. The unchanged shared `it.each(CASES)` code strictly reads the genuine36 old slot, admits the migrated current46 slot, and constructs the same expected old-state projection at that slot's own week. The public45→46 migration explicitly initializes these exact fields for every business/period and fully admits46. This source evidence supports the shared expected-expression correction while retaining full equality; it does not prove824 current53/saved52 or842 saved520/trailing checks pass. Likewise grouped memo errors do not prove independently completed D15/D16 or B55-1/B55-2 continuations.

## Why the edit preserves the boundary

The existing helper spreads every old root/business/account/period/movement and asserts the expected input does not already own either recovery field. It returns a detached expected projection, adding only empty recovery values; historical inputs and actual migrated states are not normalized or stripped. All eight new calls wrap independently constructed expected expressions only. Every old migration helper, canonical/full equality and firstTakeSubjects/lifecycle assertion remains. The preexisting prior55 expected-side cast is unchanged; no new cast bypasses admission.

The single45→46 literal follows `current = migrateToLive(old)` where old is strictly admitted37. `LIVE_SAVE_VERSION` and public current migration route are46; the earlier full expected-state comparison already includes empty recovery. The historical37 input/version, byte/provenance/digest checks and current/saved independence stay unchanged. Newly reachable serialized-slot/digest/journal checks must still run. Historical names/comments are not current runtime version assertions and are not globally replaced.

## Required parent execution and acceptance

Parent may integrate only these exact seven file deltas into a NEW isolated candidate, record complete source/preimage/production identity, and preserve frozen R6 and current-r1 results. Run fresh appropriate root/Bridge/UI/producer types and generators with the actual candidate and publication binding; old types are not a modified-source receipt. Then run **all seven complete modified files** below with no leaf filter and unchanged budgets/timeouts/configurations. Preserve raw, formal, attribution and guards and obtain independent measured review.

Exercise both current/saved slots,842 and824 continuations, D15/D16 and B55-1/B55-2 memo continuations, D17 natural/waiver branches, strict admissions and byte/history neutrality, restart/replay authority and Q17's original zero-advance/six-quote limits. Every newly exposed failure retains its identity and complete message and is compared against both accepted M3 and unswept1368-E. No inherited label or downstream pass follows merely from fixing the first assertion. Separate Scientist-retirement, ledger/Save38, ranking and remaining broad/final gates remain open.

| Required whole file | R6 preimage SHA-256 | Proposed SHA-256 |
| --- | --- | --- |
| `tests/bridge-p14c2rm-runtime.test.ts` | `cacc8913c6041488b1e0f0485e0304be2c0f12ca6b84a61a68382ff981a1a271` | `56ed6545d0f5f496cd77970df5a4457f1702262e4fb429b2619369120d7fc190` |
| `tests/bridge-p14c2s-scientist-runtime.test.ts` | `120d9296ae094347bbf93b81c700ffe8e263be07beb0741a3cb47e38c605dc1a` | `504cd1d7c52d5f98d96264c562fd5c21db83687a37ca90c6f439782ad0503ab0` |
| `tests/bridge-p14p3-directing-promises.test.ts` | `95ad3a75f07e7aad118723f8941a65201dab6c9cc95086cfc3a1c068b19c9268` | `77e79156ff2a341d0f7f8a1f8ff9b38f404fd44c06835330b3b614e3eea7334f` |
| `tests/bridge-p14p4p5-opportunities.test.ts` | `fb20d0fbbecd9be51e87b9b6b7be13b0be7922cad733f46167d5e4f252d7f7b0` | `1e6535c76a391133ce8bcc9b6170b4e09d4ea835263f6b55478aa8df3502a27e` |
| `tests/bridge-p14r2r3-prior55.test.ts` | `7a5ad1794442475badf87d1006df82c83e015546c1146dfff10bc5fff7c44de1` | `0cacf0fb0b8d7a64f0e9a00a4e5ac37be792bbb6627e1133d38ae44851de4d25` |
| `tests/p14p4p5-cross-owner.test.ts` | `b73a41d0d97f0ad8a1638101547c77ec5fc26169082c913d2e2c512e67b29680` | `c4d52b190504ed317726990600fe0a67e4fcb89e8b6b59a711e20060c4e120d5` |
| `tests/bridge-p14c3-promise-digest-continuity.test.ts` | `0671844abde4560fde76120f6cb882b98f795b2fd12e61f7cd6a02a82a19ed61` | `114146cbcb5852db182956c932fee4823f424b3e54b1d840b2983f80d59abaed` |
