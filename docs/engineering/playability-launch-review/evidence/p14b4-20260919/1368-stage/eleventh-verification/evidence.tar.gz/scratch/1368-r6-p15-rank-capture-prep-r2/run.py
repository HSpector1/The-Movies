"""Recorded types, historical five-tick capture, or separately accepted current owning-step proof."""
import sys
sys.dont_write_bytecode=True
import argparse, importlib.util, json, os, re, shutil, subprocess, time
from pathlib import Path
from common import R,S,P,A,RUNS,E,NODE,BRANCH,SUFFIXES,sha,safe,exclusive,read,write,artifact,check_artifacts,environment,verify

def command_for(mode,out):
    if mode=='types':return [str(NODE),'node_modules/typescript/bin/tsc','--noEmit','-p','tsconfig.1368-rank-capture.json']
    assert mode in ['capture','consume']
    return [str(NODE),'node_modules/vitest/vitest.mjs','run','--workspace','vitest.1368-rank-capture.workspace.ts','--config','vitest.1368-rank-capture.config.ts','--maxWorkers','1','--minWorkers','1','--no-file-parallelism','--reporter=verbose','--reporter=json','--outputFile.json='+str(out/'vitest.json')]

def completed(path,pin,mode,arm):
    assert artifact(path)['sha256']==pin
    r=read(path)
    assert r['mode']==mode and r['arm']==arm
    assert r['command']==command_for(mode,path.parent)
    assert r['actualChildExit']==r['recorderChildExit']==0 and r['timedOut'] is False
    assert r['allGuardsExact'] and r['livePostflightExact'] and not r['reportingErrors']
    assert all(r['processGroup'][k] is True for k in ['cleanupVerified','noSurvivors','leaderReaped'])
    check_artifacts(r['artifacts'])
    # Binding and original formal command/HEAD/index/manual checks cannot be replaced by a summary.
    bpath=path.parent/'binding.json';assert str(bpath) in r['artifacts'];b=read(bpath)
    assert r['pins']==b['pins'] and r['command']==b['command'] and b['mode']==mode and b['arm']==arm
    stem=b['formalStem'];record=read(E/(stem+'.json'));post=read(E/(stem+'-postflight.json'));pre=read(E/(stem+'-preflight.json'))
    assert record['command']==[sys.executable,str(P/'run.py'),'--child',str(path.parent),sha(bpath)]
    assert record['exitCode']==post['exitCode']==0 and record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
    assert record['sourceSha']==record['sourceShaAtEnd']==post['head']==pre['head']==b['publicationHead']
    for key in ['guardScope','head','sourcePaths','sourceFiles','sourceInventory','manual','index','stageEntries']:assert pre[key]==post[key]
    for suffix in SUFFIXES:assert str(E/(stem+suffix)) in r['artifacts']
    return r

def prior_types(path,pin,current):
    r=completed(path,pin,'types',current['arm'])
    assert r['pins']==current,'fresh types must match exact source, kit, publication HEAD and index'


def capture_inputs(path,pin,kit_pin):
    assert artifact(path)['sha256']==pin
    a=read(path)
    assert set(a)=={'decision','captureManifest','captureManifestSha256','captureReceipt','captureReceiptSha256','reviewPath','reviewSha256'}
    assert a['decision']=='ACCEPT_GENUINE_ORIGINAL45_RANK_CAPTURE_FOR_CURRENT_BOUNDARY'
    paths={str(path):pin}
    for name in ['captureManifest','captureReceipt','reviewPath']:
        p=Path(a[name]);assert artifact(p)['sha256']==a[name+'Sha256'];paths[str(p)]=sha(p)
    assert Path(a['reviewPath']).stat().st_size>0
    receipt=completed(Path(a['captureReceipt']),a['captureReceiptSha256'],'capture','C0')
    assert receipt['pins']['kitManifestSha256']==kit_pin
    assert receipt['pins']['sourcePinsSha256']==sha(P/'templates/C0-SOURCE-PINS.json')
    assert receipt['pins']['assemblySha256']==sha(P/'templates/ASSEMBLY.json')
    mp=Path(a['captureManifest']);assert mp==Path(a['captureReceipt']).parent/'data/MANIFEST.json'
    assert str(mp) in receipt['artifacts'];m=read(mp)
    assert m['kind']=='genuine-original42-to-original45-rank-130-135'
    assert m['originalEngineHead']=='2eaa697effc38538c37da28b486786ce267a2284' and m['originalSrcTree']=='88d0197645b3a5bd69d73ebff0c5c1c9ff0aa837'
    assert m['coordinatorHead']==receipt['pins']['publicationHead']
    assert m['sourcePinsSha256']==receipt['pins']['sourcePinsSha256'] and m['kitManifestSha256']==kit_pin
    assert m['seed']=='p13a-core-causal-01' and m['inputSaveVersion']==42 and m['saveVersion']==45
    assert (m['startWeek'],m['endWeek'],m['ticks'])==(130,135,5)
    assert m['options']=='default tick(state), no options'
    assert m['input']=={'gzipSha256':'af45c8a0efb9a56ac9ff4c16244509d59b49a02370f8390769c79b133d7238f6','rawSha256':'f0bf1f76552347f590b54cafefc5704a436f63de49c6782e9bb9a582f28f1425','manifestSha256':'35f281f6a56190b422c44d16838290a977a595db7e3ad3ace7c4d72cafb74f3f'}
    assert [r['week'] for r in m['boundaries']]==list(range(130,136))
    assert m['ownEraRoundtrip']=={'before':{'version':1,'recordedFromWeek':130,'snapshots':[]},'after':{'version':1,'recordedFromWeek':135,'snapshots':[]}}
    assert m['file']['path']=='original42-week130-to-original45-week135.json.gz'
    gz=mp.parent/m['file']['path'];assert artifact(gz)=={'sha256':m['file']['sha256'],'bytes':m['file']['bytes']}
    assert str(gz) in receipt['artifacts'];paths[str(gz)]=sha(gz)
    data=read(mp.parent/'RESULT.json');assert data=={'completed':True,'mode':'capture','sourcePostflight':True,'startWeek':130,'endWeek':135,'boundaries':6}
    report=read(mp.parent.parent/'vitest.json');assert report['numTotalTests']==report['numPassedTests']==1 and report['numFailedTests']==0
    return {'pins':paths,'manifest':str(mp),'manifestSha256':sha(mp)}

def lane_preflight(log):
    safe(log);assert log.parent==S/'heavy-queue' and log.is_file()
    lock=S/'HEAVY-LANE-LOCK';safe(lock)
    assert lock.read_text().startswith('lane-run '+log.name+', started ')
    parent=subprocess.check_output(['ps','-p',str(os.getppid()),'-o','command='],text=True).strip()
    assert 'lane-run.sh' in parent and str(log) in parent,'runner must be launched by parent heavy lane'
    return {'lockPath':str(lock),'lockSha256':sha(lock),'laneParentPid':os.getppid(),'laneParentCommand':parent,'log':str(log)}

def prerequisites(b):
    assert b['mode'] in ['types','capture','consume'] and b['arm'] in ['C0','ABC']
    assert b['mode']=='types' or (b['mode']=='capture' and b['arm']=='C0') or (b['mode']=='consume' and b['arm']=='ABC')
    assert b['outerCapSeconds']==330 and b['probeTestSeconds']==300
    assert b['route']=={'startWeek':130,'endWeek':135,'ticks':5,'seed':'p13a-core-causal-01','options':'default tick(state), no options'}
    assert sha(Path(b['lane']['lockPath']))==b['lane']['lockSha256']
    assert verify(b['publicationHead'],b['manifestPin'],b['arm'])==b['pins']
    if b['mode']!='types':prior_types(Path(b['typesReceipt']),b['typesReceiptSha256'],b['pins'])
    if b['mode']=='consume':assert capture_inputs(Path(b['acceptance']),b['acceptanceSha256'],b['manifestPin'])==b['captureInputs']


def child(out,binding_pin):
    assert sha(out/'binding.json')==binding_pin;b=read(out/'binding.json');prerequisites(b)
    assert b['command']==command_for(b['mode'],out)
    assert sha(P/'cleanup.py')=='4698b610b50289fd289e3235c564c087774b443422ca7e0ac6635284babc49e4'
    spec=importlib.util.spec_from_file_location('reviewed_cleanup',P/'cleanup.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    env=environment();env.update(RANK_MODE=b['mode'],RANK_OUTPUT=str(out/'data'),RANK_SOURCE_PINS=str(A/b['arm']/'SOURCE-PINS.json'),RANK_SOURCE_PINS_SHA=b['pins']['sourcePinsSha256'],RANK_COORDINATOR_HEAD=b['publicationHead'],RANK_KIT_SHA=b['manifestPin'])
    if b['mode']=='consume':env.update(RANK_CAPTURE_MANIFEST=b['captureInputs']['manifest'],RANK_CAPTURE_MANIFEST_SHA=b['captureInputs']['manifestSha256'])
    start=time.monotonic();timed_out=False;wait_error=None
    with (out/'stdout.txt').open('x') as stdout,(out/'stderr.txt').open('x') as stderr:
        proc=subprocess.Popen(b['command'],cwd=A/b['arm']/'tree',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            write(out/'LAUNCH.json',{'nodePid':proc.pid,'ownedProcessGroup':proc.pid,'startNewSession':True,'monotonicStarted':start,'command':b['command'],'bindingSha256':binding_pin})
            try:proc.wait(timeout=330)
            except subprocess.TimeoutExpired:timed_out=True
        except Exception as error:wait_error=error
        finally:
            def check_source():
                prerequisites(b)
                return sha(out/'binding.json')==binding_pin
            def write_receipt(row):
                row.update(stdoutSha256=sha(out/'stdout.txt'),stderrSha256=sha(out/'stderr.txt'))
                write(out/'CHILD.json',row)
            exit_code=helper.finish_child(proc,timed_out,start,b['command'],check_source,write_receipt,wait_error)
    return exit_code


def mode_data(out,mode):
    if mode=='types':return
    data=read(out/'data/RESULT.json')
    assert data['completed'] is True and data['mode']==mode and data['sourcePostflight'] is True
    assert (data['startWeek'],data['endWeek'])==(130,135)
    report=read(out/'vitest.json');assert report['numTotalTests']==report['numPassedTests']==1 and report['numFailedTests']==0
    if mode=='capture':
        assert data['boundaries']==6
        m=read(out/'data/MANIFEST.json');assert [r['week'] for r in m['boundaries']]==list(range(130,136))
        assert (m['startWeek'],m['endWeek'],m['ticks'])==(130,135,5)
        assert m['file']['path']=='original42-week130-to-original45-week135.json.gz'
        assert artifact(out/'data'/m['file']['path'])=={'sha256':m['file']['sha256'],'bytes':m['file']['bytes']}
    else:
        assert data['currentTicks']==0
        proof=read(out/'data/PROOF.json')
        assert proof['before']=={'version':1,'recordedFromWeek':130,'snapshots':[]} and proof['after']=={'version':1,'recordedFromWeek':135,'snapshots':[]}
        assert proof['nonP15Unchanged'] and proof['inputNeutral'] and proof['currentMigrationNeutral'] and proof['currentTicks']==0


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode',choices=['types','capture','consume']);ap.add_argument('--arm',required=True,choices=['C0','ABC'])
    for name in ['head','manifest-sha256','leaf','lane-log']:ap.add_argument('--'+name,required=True)
    for name in ['types-receipt','types-receipt-sha256','acceptance','acceptance-sha256']:ap.add_argument('--'+name)
    a=ap.parse_args();assert Path(__file__)==P/'run.py';assert re.fullmatch('[a-z0-9-]+',a.leaf)
    assert a.mode=='types' or (a.mode=='capture' and a.arm=='C0') or (a.mode=='consume' and a.arm=='ABC')
    pins=verify(a.head,a.manifest_sha256,a.arm)
    lane=lane_preflight(Path(a.lane_log));power=subprocess.check_output(['pmset','-g','batt'],text=True);assert 'AC Power' in power
    assert shutil.disk_usage(R).free>=5368709120
    if a.mode!='types':
        assert a.types_receipt and a.types_receipt_sha256;prior_types(Path(a.types_receipt),a.types_receipt_sha256,pins)
    else:assert not a.types_receipt and not a.types_receipt_sha256
    capture=None
    if a.mode=='consume':
        assert a.acceptance and a.acceptance_sha256;capture=capture_inputs(Path(a.acceptance),a.acceptance_sha256,a.manifest_sha256)
    else:assert not a.acceptance and not a.acceptance_sha256
    tag=a.arm+'-'+a.mode+'-'+a.leaf;out=RUNS/tag;exclusive(out);stem='1368-rank-capture-r2-'+tag.lower()
    for suffix in SUFFIXES:exclusive(E/(stem+suffix))
    safe(RUNS);RUNS.mkdir(exist_ok=True);out.mkdir()
    command=command_for(a.mode,out)
    b={'mode':a.mode,'arm':a.arm,'publicationHead':a.head,'manifestPin':a.manifest_sha256,'pins':pins,'command':command,
      'formalStem':stem,'lane':lane,'outerCapSeconds':330,'probeTestSeconds':300,
      'route':{'startWeek':130,'endWeek':135,'ticks':5,'seed':'p13a-core-causal-01','options':'default tick(state), no options'},
      'typesReceipt':a.types_receipt,'typesReceiptSha256':a.types_receipt_sha256,'acceptance':a.acceptance,'acceptanceSha256':a.acceptance_sha256,'captureInputs':capture,
      'sourceStatus':'C0 original45 2eaa697e; ABC frozen R6 production Save46. Historical capture is not current-world measurement.'}
    write(out/'binding.json',b);(out/'power.txt').write_text(power)
    subprocess.Popen(['caffeinate','-is','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    guard=[sys.executable,str(E/'run-bounded-source-guards.py')]
    subprocess.run([*guard,'pre',stem,'0'],cwd=R,env=environment(),check=True)
    recorder=None;post_code=None;record=None;post=None
    try:
        try:recorder=subprocess.run([str(NODE),str(E/'run-bounded-source-c2.mjs'),stem,sys.executable,str(P/'run.py'),'--child',str(out),sha(out/'binding.json')],cwd=R,env=environment()).returncode
        finally:post_code=subprocess.run([*guard,'post',stem],cwd=R,env=environment()).returncode
        record=read(E/(stem+'.json'));post=read(E/(stem+'-postflight.json'))
        assert recorder==post_code==0
        assert record['command']==[sys.executable,str(P/'run.py'),'--child',str(out),sha(out/'binding.json')]
        assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
        assert record['sourceSha']==record['sourceShaAtEnd']==post['head']==a.head
        prerequisites(b)
        c=read(out/'CHILD.json');assert c['command']==command
        assert c['actualChildExit'] is None or type(c['actualChildExit']) is int
        assert type(c['timedOut']) is bool and type(c['allGuardsExact']) is bool and isinstance(c['reportingErrors'],list)
        group=c['processGroup'];assert all(type(group[k]) is bool for k in ['cleanupVerified','noSurvivors','leaderReaped'])
        failure=bool(c['reportingErrors']) or not c['allGuardsExact'] or not all(group[k] for k in ['cleanupVerified','noSurvivors','leaderReaped'])
        expected=124 if c['timedOut'] else (1 if failure else (c['actualChildExit'] if isinstance(c['actualChildExit'],int) and c['actualChildExit']>=0 else 1))
        assert record['exitCode']==post['exitCode']==expected
        if expected==0:mode_data(out,a.mode)
        paths=[p for p in out.rglob('*') if p.is_file()]+[E/(stem+s) for s in SUFFIXES]
        write(out/'RESULT.json',{**c,'mode':a.mode,'arm':a.arm,'pins':pins,'recorderChildExit':record['exitCode'],'livePostflightExact':True,'artifacts':{str(p):artifact(p) for p in sorted(paths)},'interpretation':'Original historical proof or separate current conversion proof only; no current-world gameplay acceptance.'})
        print(json.dumps({'receipt':str(out/'RESULT.json'),'receiptSha256':sha(out/'RESULT.json'),'actualChildExit':c['actualChildExit'],'timedOut':c['timedOut']}))
        return expected
    except Exception as error:
        # Preserve partial child/formal facts; no guessed Node exit, timeout or cleanup.
        paths=[p for p in out.rglob('*') if p.is_file()]+[E/(stem+s) for s in SUFFIXES if (E/(stem+s)).is_file()]
        write(out/'WRAPPER-FAILURE.json',{'status':'INCOMPLETE_OR_FAILED_VERIFICATION','actualChildExit':None,'timedOut':None,'noSurvivors':None,
          'recorderProcessExit':recorder,'postflightProcessExit':post_code,'recorderChildExit':record.get('exitCode') if record else None,
          'errorType':type(error).__name__,'error':str(error),'artifacts':{str(p):artifact(p) for p in paths}})
        return 1
if __name__=='__main__':
    if len(sys.argv)==4 and sys.argv[1]=='--child':sys.exit(child(Path(sys.argv[2]),sys.argv[3]))
    sys.exit(main())
