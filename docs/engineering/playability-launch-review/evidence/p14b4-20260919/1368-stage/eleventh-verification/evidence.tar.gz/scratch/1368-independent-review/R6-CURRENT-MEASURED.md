# R6 current104 measured review

Disposition: ACCEPT the completed exact-source measurement and attribution as bounded evidence: **1381 PASS / 60 FAIL / 1 TODO across104 complete files**. Against accepted M3, **15 NEW and3 CHANGED failures remain unresolved**. This is not current-selection GREEN, an inherited-failure waiver, broad acceptance, recovery closure, landing or promotion.

Independent read-only review on2026-10-05. No runtime/compiler/tests, nested delegation, live/frozen/index/HANDOFF writes or source diagnosis. Only this new review file was written. Disk headroom and future launches are parent-owned checks, not independently remeasured here.

## Source, prerequisite and formal closure

Run-current-r1 binds coordinator `45bcb9359eeecdcaa92020746a0af35150167eb7`, frozen R6 scratch HEAD `a59301c631531d9189aef5ee1827d6886db78f45`, tree `80919a922661f9202bc64ad43ef93da3f8472b7c`. Reverified all1626 consumed source hashes, exact regular inventory, scratch HEAD/tree/index/stage, both reviewed preparation packages, attribution output manifest members and every SUMMARY-pinned input/result artifact. All match;1770 hash checks including repeated prerequisite pins. Fresh types-r2 has the same complete source/tool binding and coordinator, six actual commands0, and its exact binding/result/raw/formal prerequisite hashes match this run.

The command selects all104 original files without leaf filtering; actual Vitest filenames match the reviewed selection exactly. Formal start/end source SHA and pre/post HEAD/preflight remote equal the coordinator. Source inventory, index, staged entries, manual inputs and guard scope match pre/post. Both diff pins identify the empty formal patch, and untracked-source lists are empty. Recorded signal/error are null, Node20.20.2 and AC power recorded. Actual child, recorder and recorded postflight exit codes are1 with complete exact guards. Child duration is1888.471473495seconds. RESULT is `303d64a9d9c990cea5556f403a9039d71f5488112fb9363d246dbdf107b38c02`.

These are the existing integration runner's completed receipts; no additional owned-process cleanup/watchdog capability is inferred from them. Wrapper success is not substituted for the recorded failed child.

## Occurrence and error reconciliation

Every one of1442 original Vitest assertions matches its case-row locator, identity, status, full original assertion and failure messages. All1442 identities are unique; no multiplicity loss or display-title collision. Each of60 raw FAIL headers matches the failed-JSON identity multiset exactly. No raw-only/JSON-only failure, file-level error message, suite error, unhandled/uncaught/worker error or separate failed-suite section was found. Raw terminal summary is17failed/87passed files and60failed/1381passed/1todo tests. Nested suite aggregate failures are not additional standalone suite errors.

The single TODO is the existing Bridge world player-arrival clause, with the identical TODO identity in the unswept case rows; it is not a pass. The sole timeout is C.3 runtime R8's5000ms timeout: SAME versus M3, CHANGED versus unswept's earlier version assertion. This identity classification does not diagnose timeout causality or waive it.

## Failure attribution and limits

Original pinned baseline partitions and every raw-primary comparison were independently recomputed:

| Baseline within104files | Before / after failures | SAME | NEW | CHANGED | GONE | Outside selection |
| --- | --- | --- | --- | --- | --- | --- |
| Accepted1361-M3 |45 /60|42|15|3|0|88|
| Unswept1368-E |547 /60|41|0|19|487|380|

All487 unswept GONE dispositions individually map to exactly one current original Vitest assertion, passed with no failure message. Every `EXECUTED_PASS` disposition is justified; none rests on absence, renaming, TODO or duplicate collapse. This says nothing about unselected global failures, and overlapping selections cannot be summed as unique coverage.

The three CHANGED failures versus M3 remain explicitly changed:

- Commercial-adoption ledger: current42rows versus expected48 replaces the prior digest mismatch.
- Core-causal ledger: current18rows versus expected40 replaces the prior digest mismatch.
- C.3 strictSave38 opening: the current serialized version46 versus38 comparison replaces the prior version45 versus38 comparison.

Neither recurring identity nor an earlier failed premise establishes inherited equivalence. Exact before/after primary messages and complete current assertion messages are retained; any explanation, expected-value amendment or acceptance requires separate source/causal evidence and review. The19 CHANGED versus unswept likewise cannot be automatically waived as newly exposed inherited failures. SAME only means exact raw-primary equality under the approved attribution rule; it does not claim byte-identical full stacks or equivalent unexecuted downstream behavior.

The15 NEW versus M3 are distributed as follows; this is an identity inventory, not a causal diagnosis:

| File | NEW identities |
| --- | --- |
| `tests/bridge-p14c2rm-runtime.test.ts` |2|
| `tests/bridge-p14c2s-scientist-runtime.test.ts` |2|
| `tests/bridge-p14c3-promise-digest-continuity.test.ts` |1|
| `tests/bridge-p14p3-directing-promises.test.ts` |3|
| `tests/bridge-p14p4p5-opportunities.test.ts` |3|
| `tests/bridge-p14r2r3-prior55.test.ts` |1|
| `tests/p14c2s-scientist-retirement.test.ts` |2|
| `tests/p14p4p5-cross-owner.test.ts` |1|

The exact15 titles and3 changed pairs are preserved in comparison-vs1361M3.json. Zero NEW against unswept is not acceptance against the accepted M3 baseline. Parent diagnosis/correction, newly unmasked assertion review and fresh bounded verification remain required. This review does not inspect or claim helper/UI/ledger/new historical capture completion and does not remove the separately preserved P15 ranking NEW blocker.

## Exact artifact pins

S=`/Users/zacheryspector/studio-scratch`; E is the live repository's `docs/engineering/playability-launch-review/evidence/p14b4-20260919`. Attribution MANIFEST transitively binds all output files; SUMMARY binds original baseline inputs and completed raw/formal artifacts, all independently hash-verified.

| Artifact | SHA-256 |
| --- | --- |
| `S/1368-r6-integration-prep/MANIFEST.json` | `fd4251831e6e8241a3bafe913cc04039a629107b192ab70522845fcebb62bf31` |
| `S/1368-r6-fallout-comparison-prep/MANIFEST.json` | `713acfbe028d198944f36c5d55df94d236115caff5c989530efe01d5bfbb7cbf` |
| `S/1368-save46-swept-proposal-r6/SOURCE-PINS.json` | `2d92af276435275d7ec45554e188962780f0e08467a17dbe42d7ced5f6c85f64` |
| `S/1368-r6-integration-prep/run-types-r2/RESULT.json` | `6d487059dfee5b4d87d2a7c77930ecc0cf235a7f289d23a65843376bf63e0230` |
| `S/1368-r6-integration-prep/run-current-r1/binding.json` | `78c340496c30ca4aec6a791639d327b4340f24868613a32978e0055b00fd0cb6` |
| `S/1368-r6-integration-prep/run-current-r1/RESULT.json` | `303d64a9d9c990cea5556f403a9039d71f5488112fb9363d246dbdf107b38c02` |
| `S/1368-r6-integration-prep/run-current-r1/current.txt` | `d3addf8f9874cb63b87147f7f76e97d863ce8ca5420ff31935e801c721f4b8ca` |
| `S/1368-r6-integration-prep/run-current-r1/vitest.json` | `89573f9dd335e37bd93a1fd265368e8846586a7284318753fd1c076125cecffe` |
| `S/1368-r6-attribution-current-r1/MANIFEST.json` | `148aca0c8f5e49644ce9522a15f6f052f1732017e1b4a5731ffd92df0592e217` |
| `S/1368-r6-attribution-current-r1/SUMMARY.json` | `a5a1f877a0745452e873d8b741753510b5ba541acbf60a2cc02095a2dbd4c4de` |
| `S/1368-r6-attribution-current-r1/case-rows.json` | `41c0583d7bcf1e795cf1d9bf0c3e73797edc258d31cf60467cc5ba4ac168830a` |
| `S/1368-r6-attribution-current-r1/comparison-vs1361M3.json` | `990980cab80d40ac6ece23e52b077db0e259e1bc98994e1916e52f905051c564` |
| `S/1368-r6-attribution-current-r1/comparison-vsunswept1368E.json` | `cdd66b38e15db1ee9a867ae2307699ba48cdad31fb4ab5a711eb906845b42f36` |
| `S/1368-r6-attribution-current-r1/raw-failure-rows.json` | `082b8165e2403c4f33d1929e7a1034d01a427638e1af4bbb40e3a9829eaa3542` |
| `S/1368-r6-attribution-current-r1/raw-json-identity-difference.json` | `7e09a9cc21af36905142ef0023a8cae0aa245f19568b94417618fbbffcda5732` |
| `E/1368-swept-r6-current-r1.json` | `a761ef65708d7134a85e640b0fc99f69c6a8f27555d0c38c224ea1aa6706e752` |
| `E/1368-swept-r6-current-r1.patch` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `E/1368-swept-r6-current-r1.txt` | `ec1bce1ace3ef5fca551a70f2cad4bb622ef0a1453a73e00b3c3c84c37693524` |
| `E/1368-swept-r6-current-r1-preflight.json` | `ca8db8c954b8300e3f136b78a6e537eb05a31b2ea2978c331b00b2668e1e4abf` |
| `E/1368-swept-r6-current-r1-postflight.json` | `1f1522ad4bb84eb3986286f21a5d7de3d38d0607c0f005f97d88eaf316f8ee2e` |
