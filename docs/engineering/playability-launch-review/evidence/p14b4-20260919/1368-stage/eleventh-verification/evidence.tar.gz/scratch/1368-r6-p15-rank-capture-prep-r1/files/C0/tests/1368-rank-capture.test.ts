import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { gzipSync, gunzipSync } from 'node:zlib'
import { it } from 'vitest'
import { tick } from '../src/core/tick.js'
import { LIVE_SAVE_VERSION, convertV45ToV44, convertV44ToV45, exportSave, importSave,
  makeSave, migrateToLive, stableStringify, validateSaveV45 } from '../src/core/save.js'
import type { GameState } from '../src/core/types.js'
import { setup, sha, snap } from './1368-rank-common.js'

it('captures genuine original45 continuation of the original42 ranking input from130 through135', () => {
  assert.equal(process.env.RANK_MODE, 'capture')
  assert.equal(LIVE_SAVE_VERSION, 45)
  const io = setup(), boundaries: { week: number; stateSha256: string; saveSha256: string }[] = []
  let completed = false
  try {
    // Exactly the existing genuineV42Week130 loader bytes and pins; no synthetic state.
    const fixtureDir = resolve('tests/fixtures/p14/genuine-v42-pre-shelving')
    const manifest = readFileSync(resolve(fixtureDir, 'MANIFEST.json'))
    assert.equal(manifest.length, 1113)
    assert.equal(sha(manifest), '35f281f6a56190b422c44d16838290a977a595db7e3ad3ace7c4d72cafb74f3f')
    const inputGzip = readFileSync(resolve(fixtureDir, 'genuine-v42-rival-stall-week-130.json.gz'))
    assert.equal(inputGzip.length, 121262)
    assert.equal(sha(inputGzip), 'af45c8a0efb9a56ac9ff4c16244509d59b49a02370f8390769c79b133d7238f6')
    const inputRaw = gunzipSync(inputGzip).toString('utf8')
    assert.equal(Buffer.byteLength(inputRaw), 1096270)
    assert.equal(sha(inputRaw), 'f0bf1f76552347f590b54cafefc5704a436f63de49c6782e9bb9a582f28f1425')
    const historical = importSave(inputRaw), historicalBefore = snap(historical)
    assert.equal(historical.saveVersion, 42)
    const migrated = migrateToLive(historical)
    assert.equal(snap(historical), historicalBefore)
    assert.equal(migrated.saveVersion, 45)
    let state = structuredClone(migrated.state)
    assert.equal(state.seed, 'p13a-core-causal-01')
    assert.equal(state.market.tick, 130)
    const origin130 = { version: 1, recordedFromWeek: 130, snapshots: [] }
    assert.equal(stableStringify(state.powerRanking), stableStringify(origin130))
    const admit = (s: GameState) => {
      const before = snap(s), save = makeSave(s), input = structuredClone(save), inputBefore = snap(input)
      assert.equal(save.saveVersion, 45)
      assert.equal(stableStringify(validateSaveV45(input)), stableStringify(save))
      assert.equal(snap(input), inputBefore); assert.equal(snap(s), before)
      boundaries.push({ week: s.market.tick, stateSha256: sha(snap(s)), saveSha256: sha(stableStringify(save)) })
      return save
    }
    let saved = admit(state)
    for (let week = 130; week < 135; week++) {
      const before = snap(state), next = tick(state) // unchanged default options, exactly five ticks
      assert.equal(snap(state), before); assert.equal(next.market.tick, week + 1)
      state = next; saved = admit(state)
    }
    assert.deepEqual(boundaries.map(b => b.week), [130, 131, 132, 133, 134, 135])
    assert.equal(stableStringify(state.powerRanking), stableStringify(origin130))
    // Own-era positive proof is necessary, but does not replace separate current-reader proof.
    const savedBefore = snap(saved), down = convertV45ToV44(saved), downBefore = snap(down)
    const again = convertV44ToV45(down)
    assert.equal(snap(saved), savedBefore); assert.equal(snap(down), downBefore)
    assert.equal(stableStringify(again.state.powerRanking), stableStringify({ version: 1, recordedFromWeek: 135, snapshots: [] }))
    assert.equal(stableStringify(convertV45ToV44(again)), stableStringify(down))
    const raw = exportSave(saved), parsed = importSave(raw), parsedBefore = snap(parsed)
    assert.equal(stableStringify(validateSaveV45(parsed)), stableStringify(saved))
    assert.equal(snap(parsed), parsedBefore); assert.equal(snap(saved), savedBefore)
    const compressed = gzipSync(Buffer.from(raw)); assert.equal(gunzipSync(compressed).toString('utf8'), raw)
    const filename = 'original42-week130-to-original45-week135.json.gz'
    writeFileSync(resolve(io.out, filename), compressed, { flag: 'wx' })
    io.check()
    io.write('MANIFEST.json', { version: 1, kind: 'genuine-original42-to-original45-rank-130-135',
      originalEngineHead: '2eaa697effc38538c37da28b486786ce267a2284', originalSrcTree: '88d0197645b3a5bd69d73ebff0c5c1c9ff0aa837',
      coordinatorHead: process.env.RANK_COORDINATOR_HEAD, sourcePinsSha256: process.env.RANK_SOURCE_PINS_SHA,
      kitManifestSha256: process.env.RANK_KIT_SHA, seed: 'p13a-core-causal-01', inputSaveVersion: 42,
      saveVersion: 45, startWeek: 130, endWeek: 135, ticks: 5, options: 'default tick(state), no options',
      input: { gzipSha256: sha(inputGzip), rawSha256: sha(inputRaw), manifestSha256: sha(manifest) },
      file: { path: filename, sha256: sha(compressed), bytes: compressed.length, rawSha256: sha(raw), rawBytes: Buffer.byteLength(raw) },
      boundaries, ownEraRoundtrip: { before: origin130, after: { version: 1, recordedFromWeek: 135, snapshots: [] } } })
    completed = true
  } finally { io.check(); io.write('RESULT.json', { completed, mode: 'capture', sourcePostflight: true, startWeek: 130, endWeek: 135, boundaries: boundaries.length }) }
}, 300_000)
