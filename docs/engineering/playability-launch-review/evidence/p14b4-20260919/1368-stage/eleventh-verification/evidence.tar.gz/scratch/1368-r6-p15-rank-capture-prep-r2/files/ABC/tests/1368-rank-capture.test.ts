import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { gunzipSync } from 'node:zlib'
import { it } from 'vitest'
import { LIVE_SAVE_VERSION, validateSaveV45, validateSaveV46, convertV45ToV44, convertV44ToV45,
  migrateToLive, convertV46ToV45, stableStringify, exportSave } from '../src/core/save.js'
import { stripP15 } from './helpers/p15-roots.js'
import { setup, sha, snap, ordinary } from './1368-rank-common.js'

it('current public readers preserve the genuine historical130-to135 claims-less boundary', () => {
  assert.equal(process.env.RANK_MODE, 'consume'); assert.equal(LIVE_SAVE_VERSION, 46)
  const io = setup(); let completed = false
  try {
    // Wrapper independently verifies completed capture, actual child/recorder, and review hashes.
    const path = process.env.RANK_CAPTURE_MANIFEST, pin = process.env.RANK_CAPTURE_MANIFEST_SHA
    assert(path && pin); ordinary(path)
    const manifestRaw = readFileSync(path); assert.equal(sha(manifestRaw), pin)
    const m = JSON.parse(manifestRaw.toString('utf8')) as {
      kind: string; originalEngineHead: string; startWeek: number; endWeek: number; ticks: number;
      file: { path: string; sha256: string; bytes: number; rawSha256: string; rawBytes: number }
    }
    assert.equal(m.kind, 'genuine-original42-to-original45-rank-130-135')
    assert.equal(m.originalEngineHead, '2eaa697effc38538c37da28b486786ce267a2284')
    assert.deepEqual([m.startWeek,m.endWeek,m.ticks], [130,135,5])
    assert.equal(m.file.path, 'original42-week130-to-original45-week135.json.gz')
    const gzPath = resolve(dirname(path), m.file.path); ordinary(gzPath)
    const gz = readFileSync(gzPath); assert.equal(sha(gz), m.file.sha256); assert.equal(gz.length,m.file.bytes)
    const raw = gunzipSync(gz).toString('utf8'); assert.equal(sha(raw),m.file.rawSha256); assert.equal(Buffer.byteLength(raw),m.file.rawBytes)
    const input: unknown = JSON.parse(raw), inputBefore = snap(input)
    const historical = validateSaveV45(input)
    assert.equal(snap(input),inputBefore); assert.equal(historical.saveVersion,45); assert.equal(historical.state.market.tick,135)
    assert.equal(exportSave(historical),raw)
    assert.equal(stableStringify(historical.state.powerRanking),stableStringify({version:1,recordedFromWeek:130,snapshots:[]}))
    const down = convertV45ToV44(historical), downBefore = snap(down)
    assert.equal(down.saveVersion,44)
    // Comparisons only; no projected object is supplied to a reader, converter or writer.
    assert.equal(stableStringify(down.state),stableStringify(stripP15(historical.state)))
    const again = convertV44ToV45(down)
    assert.equal(again.saveVersion,45)
    assert.equal(stableStringify(again.state.powerRanking),stableStringify({version:1,recordedFromWeek:135,snapshots:[]}))
    assert.equal(stableStringify(stripP15(again.state)),stableStringify(stripP15(historical.state)))
    assert.equal(stableStringify(convertV45ToV44(again)),stableStringify(down))
    assert.equal(snap(input),inputBefore); assert.equal(snap(down),downBefore)
    // Separate ordinary current migration/admission: this is not current tick measurement.
    const live = migrateToLive(historical), liveBefore = snap(live)
    assert.equal(live.saveVersion,46); assert.equal(validateSaveV46(live),live)
    assert.equal(exportSave(convertV46ToV45(live)),raw)
    assert.equal(snap(live),liveBefore); assert.equal(snap(input),inputBefore)
    assert.equal(sha(readFileSync(path)),pin); assert.equal(sha(readFileSync(gzPath)),m.file.sha256)
    io.write('PROOF.json',{captureManifestSha256:pin,historicalSaveSha256:sha(raw),
      before:{version:1,recordedFromWeek:130,snapshots:[]},after:{version:1,recordedFromWeek:135,snapshots:[]},
      nonP15Unchanged:true,inputNeutral:true,currentMigrationNeutral:true,currentTicks:0})
    completed=true
  } finally { io.check(); io.write('RESULT.json',{completed,mode:'consume',sourcePostflight:true,startWeek:130,endWeek:135,currentTicks:0}) }
},300_000)
