import { defineWorkspace } from 'vitest/config'
export default defineWorkspace(['./vitest.1368-rank-capture.config.ts'])
