# R6 P15 measured review

Disposition: ACCEPT the exact fresh types-r2 receipt and completed P15-r2 measurement/attribution as bounded evidence. P15 remains **124 PASS / 41 FAIL**, with **one unresolved NEW failure versus accepted 1361-M3**. This review does not approve a fix, waive failure, authorize landing/promotion or claim P15/recovery completion.

Independent read-only review on 2026-10-05, using the previously reviewed R6 runner/attribution packages. No runtime/compiler/tests, nested agents, live/frozen source/index/HANDOFF writes or moving current-run inspection. Only this new review artifact was written.

## Exact-source closure

Both runs bind coordinator `45bcb9359eeecdcaa92020746a0af35150167eb7` and frozen R6 scratch HEAD `a59301c631531d9189aef5ee1827d6886db78f45`, tree `80919a922661f9202bc64ad43ef93da3f8472b7c`. Independently verified all 1,626 source-file hashes and exact regular-file inventory, scratch HEAD/tree/index/stage hashes, both reviewed preparation packages and members, attribution MANIFEST members and every artifact in its SUMMARY (1,808 hash checks including repeated prerequisite pins). No source or package drift found.

Types-r2 performs the unchanged four typechecks and two generators; each actual child exits 0. P15-r2 consumes exactly that types-r2 binding/result/six raw outputs/five formal records, all hash-matched. Both bindings carry identical tool/source/fixture pins. P15 selects four whole original files without leaf filtering: market integration, power-ranking archive, campaign-legacy integration and campaign-legacy sibling.

For both runs, formal start/end source SHA and pre/post HEAD/preflight remote equal the coordinator; pre/post source inventories, manual inputs, index, staged entries and guard scopes match. Patches and untracked-source lists are empty. Actual formal record/raw/patch bytes match postflight hashes; fixedSource/allGuardsExact are true, signal/error null, Node v20.20.2 and AC power recorded. Actual child, formal recorder and postflight recorded exit codes are 0 for types and 1 for P15. P15 child duration is 198.725390653 seconds. These are completed failure receipts, not wrapper-based success.

## Assertion and baseline reconciliation

Directly reconciled all 165 original Vitest assertions with case rows: 165 unique identities, 124 passed, 41 failed, no duplicated display identity, no pending/TODO. Every raw FAIL header matches the failed JSON identity multiset. Raw summary is two passed / two failed files. No file-level error message, unhandled/uncaught/worker error or separate failed-suite section was found; attribution suite/unhandled reports are empty. Full failure messages remain retained.

Accepted M3 comparison is exactly 40 SAME / 1 NEW / 0 CHANGED / 0 GONE. Unswept 1368-E comparison is 40 SAME / 0 NEW / 1 CHANGED / 14 GONE. Independently checked original pinned baseline partitions and each primary-message classification; M3 has 93 outside-selection failures, unswept 872. SAME uses the reviewed raw-primary identity law, not complete-stack equality or a waiver.

The NEW identity against M3 is `rank-root-downgrade-round-trip-claims-less`. It fails at conversion before its final historical-claim assertion with `migrateToV45: cannot downgrade or discard recovery authority: costCutting.since, facilityDemolitionRefund, facilityDisposed`. It is SAME against unswept. The different CHANGED identity against unswept is the market old-save first-batches-after-migration leaf: its former `expected 44 to be 45` assertion is replaced by `studio-315405e1-r03:film:2 is assessed within 26 weeks of the migration: expected undefined to be defined`. That market failure is SAME against M3. These classifications must not be conflated.

All 14 unswept GONE dispositions were individually reconciled to exactly one current original Vitest assertion with passed status and no failure messages. Thus all 14 `EXECUTED_PASS` claims hold; none depends on a missing/renamed identity. No global GONE or combined unique-coverage claim follows.

## Named ranking controls and remaining limit

Both required week-13 controls, `rank-root-downgrade-recorded-quarter-refuses` and `rank-root-downgrade-frozen-builders-refuse`, passed as complete leaves. Pinned source retains the live quarter premise, exact ranking-refusal expectation, at-least-30 older migrators check and at-least-18 frozen-builder check. This discharges those two previously unmeasured controls on this exact R6 source.

Their success does not discharge the separate NEW round-trip failure. Diagnosis/correction and fresh exact-source verification remain required before any no-NEW gate can pass. This review makes no causal diagnosis or proposed test/production change and does not inspect current/helper/UI/ledger results or establish broad acceptance. Original P15-r1 disk refusal remains historical and was not reused.

## Exact artifact pins

S is `/Users/zacheryspector/studio-scratch`; E is the live repository's `docs/engineering/playability-launch-review/evidence/p14b4-20260919`. Attribution MANIFEST transitively pins all output files; SUMMARY pins the original inputs and completed raw/formal receipts, all independently verified.

| Artifact | SHA-256 |
| --- | --- |
| `S/1368-r6-integration-prep/MANIFEST.json` | `fd4251831e6e8241a3bafe913cc04039a629107b192ab70522845fcebb62bf31` |
| `S/1368-r6-fallout-comparison-prep/MANIFEST.json` | `713acfbe028d198944f36c5d55df94d236115caff5c989530efe01d5bfbb7cbf` |
| `S/1368-save46-swept-proposal-r6/SOURCE-PINS.json` | `2d92af276435275d7ec45554e188962780f0e08467a17dbe42d7ced5f6c85f64` |
| `S/1368-save46-swept-proposal-r6/ASSEMBLY.json` | `b3dcf41960c58528339415fa822cc3e8555738225275ae5f9ff107b68e28b508` |
| `S/1368-r6-integration-prep/run-types-r2/binding.json` | `754262eebd0b408a65421bfab794c6538a1a2872b135bdc3c34a85210fafe8b3` |
| `S/1368-r6-integration-prep/run-types-r2/RESULT.json` | `6d487059dfee5b4d87d2a7c77930ecc0cf235a7f289d23a65843376bf63e0230` |
| `S/1368-r6-integration-prep/run-p15-r2/binding.json` | `075835bcba916767c02ef17ceb1f4b82ee79e7080288ad70cb09f05d670c831f` |
| `S/1368-r6-integration-prep/run-p15-r2/RESULT.json` | `93bd3e568990c075fbdfb918425e5aef03c32e6c88673b79806c92211fb109ba` |
| `S/1368-r6-integration-prep/run-p15-r2/p15.txt` | `56637f2b8fab4906353044e2522a3692d7eb94c63af41e29c205a96345964ca8` |
| `S/1368-r6-integration-prep/run-p15-r2/vitest.json` | `0d11ef06565b847068d0a60458606daac7b091500df899c40edf3d0576bb1155` |
| `S/1368-r6-attribution-p15-r2/MANIFEST.json` | `1d317e72e1a2180d88adb15e46350d4a4bd1d86947b770fd6aac3deda8f9b9cb` |
| `S/1368-r6-attribution-p15-r2/SUMMARY.json` | `9bf6d9e96cec36231b67a8b3354a78492b7aa5a729f3d5e29a1893920a575d9c` |
| `S/1368-r6-attribution-p15-r2/comparison-vs1361M3.json` | `8512b82e30a0f22c216cf41cdb58d75eebbfeab743cf0c7725263f3e03c17064` |
| `S/1368-r6-attribution-p15-r2/comparison-vsunswept1368E.json` | `36525a87b9128f474c07ec5c11ba70862a6da1e0e353ea468472eb7694a11d26` |
| `E/1368-swept-r6-types-r2.json` | `d8a4e5b144b276a8122f9ff19e265c5e6ba2fb74cc74d836e623b61297a6cab9` |
| `E/1368-swept-r6-types-r2.patch` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `E/1368-swept-r6-types-r2.txt` | `35f5fae9773a874933addc43fe1234c5b2066bb9d16e2e761987504220e8fb98` |
| `E/1368-swept-r6-types-r2-preflight.json` | `d749080e8b332258302db6af7aead6b9483fcbb241bf30a161a0f130d47cbf0b` |
| `E/1368-swept-r6-types-r2-postflight.json` | `a43cd3fb93947f83d32f5df1d41847368c0dd9a028f75847f5d9e071bc72ba7e` |
| `E/1368-swept-r6-p15-r2.json` | `31ba1814f2cf97c815bc2ad55ddc83c14229b251de3aa17b4e0f608f01305506` |
| `E/1368-swept-r6-p15-r2.patch` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `E/1368-swept-r6-p15-r2.txt` | `41dc88313e078c7c32ae6c75a0f89f0ec835a56a0bc0ab981268e8ebe1eba7ba` |
| `E/1368-swept-r6-p15-r2-preflight.json` | `72800b2e7dbdf1b39ec8c645cf0334ba0a8d2a2777fa1b73aad07b10c2ab7e20` |
| `E/1368-swept-r6-p15-r2-postflight.json` | `073d84aff9e3cf2759fa70fee84c4655a3b3fbeb74b94b8fde84e9cac7295e78` |
