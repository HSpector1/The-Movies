"""Static analysis of existing printed operands; never executes game code or reads fixture payloads."""
import copy,hashlib,json,re
from pathlib import Path
P=Path('/Users/zacheryspector/studio-scratch/1368-r6-current-expectation-residual-prep')
A=Path('/Users/zacheryspector/studio-scratch/1368-r6-attribution-current-r1')
FILES=['bridge-p14c2rm-runtime.test.ts','bridge-p14c2s-scientist-runtime.test.ts','bridge-p14p3-directing-promises.test.ts','bridge-p14p4p5-opportunities.test.ts','bridge-p14r2r3-prior55.test.ts','p14p4p5-cross-owner.test.ts']
def sha(b):return hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
class Pretty:
    def __init__(self,text):self.text=text;self.i=0;self.decoder=json.JSONDecoder()
    def ws(self):
        while self.i<len(self.text) and self.text[self.i].isspace():self.i+=1
    def expect(self,t):
        self.ws();assert self.text.startswith(t,self.i),(self.i,self.text[self.i:self.i+100],t);self.i+=len(t)
    def parse(self):
        self.ws()
        for prefix in ['Object ','Array ']:
            if self.text.startswith(prefix,self.i):self.i+=len(prefix);break
        self.ws();c=self.text[self.i]
        if c=='{':
            self.i+=1;v={};self.ws()
            while self.text[self.i]!='}':
                k=self.parse();assert isinstance(k,str) and k not in v;self.expect(':');v[k]=self.parse();self.ws()
                if self.text[self.i]==',':self.i+=1;self.ws()
                else:assert self.text[self.i]=='}'
            self.i+=1;return v
        if c=='[':
            self.i+=1;v=[];self.ws()
            while self.text[self.i]!=']':
                v.append(self.parse());self.ws()
                if self.text[self.i]==',':self.i+=1;self.ws()
                else:assert self.text[self.i]==']'
            self.i+=1;return v
        v,end=self.decoder.raw_decode(self.text,self.i);self.i=end
        assert isinstance(v,(str,int,float,bool)) or v is None
        return v
    def all(self):
        v=self.parse();self.ws();assert self.i==len(self.text),(self.i,self.text[self.i:self.i+100]);return v

def changes(a,b,path='$'):
    if type(a)!=type(b):return [{'path':path,'kind':'type','before':a,'after':b}]
    if isinstance(a,dict):
        result=[]
        for k in sorted(set(a)|set(b)):
            if k not in a:result.append({'path':path+'.'+k,'kind':'added','after':b[k]})
            elif k not in b:result.append({'path':path+'.'+k,'kind':'removed','before':a[k]})
            else:result.extend(changes(a[k],b[k],path+'.'+k))
        return result
    if isinstance(a,list):
        assert len(a)==len(b),'array length changed: '+path
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in changes(x,y,path+'['+str(i)+']')]
    return [] if a==b else [{'path':path,'kind':'changed','before':a,'after':b}]

def main():
    blocks=json.loads((A/'raw-failure-blocks.json').read_text());out=[]
    for index,block in enumerate(blocks):
        if not any(h.split(' > ')[0].removeprefix('tests/') in FILES for h in block['headers']):continue
        body=block['rawBody'];lines=body.splitlines()
        minus=[l[2:] for l in lines if l.startswith('- {')];plus=[l[2:] for l in lines if l.startswith('+ {')]
        if minus:
            assert len(minus)==len(plus)==1
            et,at=minus[0],plus[0];expected,actual=json.loads(et),json.loads(at);fmt='canonical-json strings'
        else:
            start=lines.index('  Object {');end=next(i for i in range(start,len(lines)) if lines[i].startswith(' ❯'))
            diff=lines[start:end]
            assert all(not l or l.startswith(('  ','+ ','- ')) for l in diff)
            et='\n'.join(l[2:] for l in diff if l and l[:2] in ['  ','- ']);at='\n'.join(l[2:] for l in diff if l and l[:2] in ['  ','+ '])
            expected,actual=Pretty(et).all(),Pretty(at).all();fmt='full pretty-format Object/Array operands'
        delta=changes(expected,actual)
        wanted=copy.deepcopy(expected);businesses=wanted['hollywood']['businesses'];count=0
        for b in businesses:
            assert 'costCutting' not in b;b['costCutting']={'version':1,'since':None}
            for period in b['account']['periods']:
                assert 'facilityDemolitionRefund' not in period['movements'];period['movements']['facilityDemolitionRefund']=0;count+=1
        assert canon(wanted)==canon(actual),'difference beyond exact empty recovery'
        assert len(delta)==len(businesses)+count and all(d['kind']=='added' for d in delta)
        assert all(re.fullmatch(r'\$\.hollywood\.businesses\[\d+\]\.(costCutting|account\.periods\[\d+\]\.movements\.facilityDemolitionRefund)',d['path']) for d in delta)
        out.append({'rawBlockIndex':index,'headers':block['headers'],'format':fmt,'rawBodySha256':sha(body),'expectedTextSha256':sha(et),'actualTextSha256':sha(at),'expectedCanonicalSha256':sha(canon(expected)),'actualCanonicalSha256':sha(canon(actual)),'week':actual['market']['tick'],'businesses':len(businesses),'costCuttingAdditions':len(businesses),'zeroRefundAdditions':count,'allOtherValuesIdentical':True,'expectedPlusEmptyRecoveryEqualsActual':True,'differences':delta,'qualification':'Reporter shares this one block among listed headers; distinct operands for each grouped identity are not inferred.'})
    assert len(out)==9 and sum(len(x['headers']) for x in out)==12
    target=P/'OPERAND-DIFFS.json'
    with target.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps([{'headers':x['headers'],'week':x['week'],'costCutting':x['costCuttingAdditions'],'refund':x['zeroRefundAdditions']} for x in out],indent=2))
if __name__=='__main__':main()
