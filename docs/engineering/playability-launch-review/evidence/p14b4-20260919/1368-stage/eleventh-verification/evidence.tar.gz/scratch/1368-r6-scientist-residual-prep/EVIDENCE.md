# Scientist S10 residual proposal — static only

Prepared only in this scratch directory, against the frozen R6 source tree named in MANIFEST.json. Two NEW S10 leaves are the entire scope, plus removal of their unused stripP15 import. No live/frozen source, production code, historical fixture or coordinator Git state changed. No Node, tests, typechecks, producer execution or payload decompression occurred. Compressed fixture bytes were hashed without opening their payload.

## Measured starting failures

The existing current-r1 raw report records the first live downgrade call (migrateToV36) refusing with exactly `migrateToV45: cannot downgrade or discard recovery authority: costCutting.since, facilityDemolitionRefund, facilityDisposed`. The second call and following genuine Scientist assertion were masked. They are not claimed measured. The other leaf stopped at its V34 whole-envelope positive control, whose frozen Hollywood reader rejected the business exact keys. The proposed historical route has not run.

## Static source reasoning

- src/core/save.ts:10504 and :10264 send Save46 inputs to convertV46ToV45 before older converters. Lines 11118–11127 collect the three nonempty recovery categories in fixed order; :11150–11154 validate and refuse before any empty-field stripping. The patch pins all three actual premises, exact full refusal and complete live/state neutrality after each call. No recovery fact is removed to expose an older refusal.
- src/core/save.ts:10553–10565 refuses a genuine V37 Scientist record by subject name. This separate boundary remains tested on validated scientistRaw(), with explicit week670/retired Scientist premises and unchanged input. Older Power Ranking behavior remains separate coverage, as instructed by coordinator (its pass claim was not independently measured here).
- tests/helpers/p14c3-fixtures.ts:97–134 defines readRecorded and scientistRaw. It verifies compressed and uncompressed hashes when later executed, reading existing genuine-v37-scientist-week670.json.gz from the preserved manifest. The manifest pins source48a76a87, Save37, current670 and the producer; both current compressed fixture hash and producer source hash matched that manifest in this static preparation.
- The original producer 872-mint-outgoing-runtime51.ts asserts qualified Save37/projection51, imports genuine V33 scientist at520 with unchanged provenance, advances to617/618/669/670, asserts announced618/effective670/retired670 and whole-save round trips, then writes gzip artifacts. No age/history edits or new recovery authority appear in that production route. These are inspected producer assertions, not a new producer run or payload verification.
- Save37 differs semantically from Save36 for Scientist retirement; it shares the shape (save.ts:10535 delegates to V36 with the Scientist window). V36 strips extensionUsed/extendedFromWeek and market-case variant for its frozen V35 validation (:10350–10365). V35 strips cohorts for V34 (:10212–10223). The proposed reader controls retain exactly these already-established version-specific schema mutations and no later root/history stripping.
- V34's frozen Scientist window is null and the named Scientist-record refusal precedes age/status/binding checks (:9845 onward, especially :9940). Whole-envelope positive controls remain before each negative assertion, so a malformed old envelope cannot masquerade as a successful Scientist-law test.
- Cohort admission re-derives requests from film professions only (careerLifecycle.ts:291,307–337); the Scientist is not one of those professions. The proposal explicitly pins unused Scientist extension/no Scientist extension case, preserving the premise that removing just this row for the positive control does not strand an extension case. All cohort/film facts stay intact for versions which define them.

## Deliberate scope classification

The former live hardIdle566 synthetic old-shape reader control becomes a historical Save37-derived synthetic old-shape reader control. This is not evidence that the original current hardIdle566 world can be admitted under old schemas. Neither old-shaped object is a historical fixture, playable world, save export or governed downgrade. The historical source remains unchanged; each version receives a detached clone. Only the positive clone omits the Scientist row, and each complete envelope must then pass the public old reader before the full row is tested for the named Scientist refusal. Current live-world Scientist validity, exact recovery refusal, source neutrality, and the real V37 Scientist downgrade refusal remain independently exercised.

## Required before adoption or success claims

1. Independent reviewer must accept this bounded historical-control substitution and confirm it preserves the intended Scientist law and complete-envelope positive controls.
2. Run the two modified S10 leaves on a separately assembled source snapshot under the coordinator's existing harness/resource policy. Verify both live migrate calls, all three old-reader positive/negative pairs, historical validity/premises, and every input-neutrality assertion. No result has been predicted as measured.
3. Typecheck as required by the parent workflow. Historical types expose extension and market-case fields, but this patch has only been inspected statically.
4. If any new historical premise/control fails, retain the actual refusal and diagnose it. Do not broaden the refusal regex or remove recovery/accounting/disposition/history to force a pass.

The exact preimage/postimage/patch hashes are in MANIFEST.json. The original two measured failure bodies are preserved in failure-evidence.json. The patch and full proposed/preimage file allow independent review without modifying either source tree.
