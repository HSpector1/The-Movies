from pathlib import Path
import hashlib,json,tarfile
r=Path('/Users/zacheryspector/The-Movies-headless-program');s=Path('/Users/zacheryspector/studio-scratch')
e=r/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';out=e/'1368-stage/eleventh-verification'
assert not out.exists()
files={}
dirs=['1368-r6-integration-prep/run-types-r2','1368-r6-integration-prep/run-p15-r2','1368-r6-integration-prep/run-current-r1','1368-r6-attribution-p15-r2','1368-r6-attribution-current-r1','1368-r6-p15-rank-residual-prep','1368-r6-p15-rank-capture-prep-r1','1368-r6-p15-rank-capture-prep-r2','1368-r6-selected-followup-publication','1368-r6-current-expectation-residual-prep','1368-r6-scientist-residual-prep','1368-r6-scientist-residual-prep-r2']
for rel in dirs:
 p=s/rel;assert p.is_dir()
 for f in sorted(p.rglob('*')):
  assert not f.is_symlink()
  if f.is_file():files['scratch/'+f.relative_to(s).as_posix()]=f
for name in ['R6-P15-MEASURED.md','R6-CURRENT-MEASURED.md','R6-P15-RANK-DIAGNOSIS-STATIC.md','R6-P15-RANK-CAPTURE-R2-STATIC.md','R6-CURRENT-EXPECTATION-STATIC.md','R6-SCIENTIST-RESIDUAL-STATIC.md','R6-SCIENTIST-RESIDUAL-R2-STATIC.md']:
 f=s/'1368-independent-review'/name;assert f.is_file();files['scratch/'+f.relative_to(s).as_posix()]=f
for mode,rid in [('types','r2'),('p15','r2'),('current','r1')]:
 for suffix in ['.log','.log.meta']:
  f=s/'heavy-queue'/('1368-r6-'+mode+'-'+rid+'-resume'+suffix);assert f.is_file();files['scratch/'+f.relative_to(s).as_posix()]=f
 for suffix in ['.json','.txt','.patch','-preflight.json','-postflight.json']:
  f=e/('1368-swept-r6-'+mode+'-'+rid+suffix);assert f.is_file();files['repo/'+f.relative_to(r).as_posix()]=f
 post=json.loads((e/('1368-swept-r6-'+mode+'-'+rid+'-postflight.json')).read_text());assert post['allGuardsExact']
 assert (s/'1368-r6-integration-prep'/('run-'+mode+'-'+rid)/'RESULT.json').is_file()
members={n:{'source':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for n,f in sorted(files.items())}
out.mkdir(parents=True);a=out/'evidence.tar.gz'
with tarfile.open(a,'x:gz') as tf:
 for n,f in sorted(files.items()):tf.add(f,arcname=n,recursive=False)
with tarfile.open(a,'r:gz') as tf:
 assert sorted(tf.getnames())==sorted(members)
 for n,row in members.items():
  b=tf.extractfile(n).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert b==Path(row['source']).read_bytes()
m={'scope':'Completed R6 types/P15/current selected verification and attribution, independent measured reviews, preserved ranking residual diagnosis and reviewed unexecuted capture and current-test correction preparation. No landing or closure.','coordinatorHead':'45bcb9359eeecdcaa92020746a0af35150167eb7','archive':{'path':str(a.relative_to(r)),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size},'memberCount':len(members),'logicalBytes':sum(x['bytes'] for x in members.values()),'members':members,'originalsRetained':True,'priorSources':'Original45 production is pinned historicalGit2eaa697e; R6 full source/root and approved runner/parser are already preserved in earlier publications. New preparation origin maps and all added source/configs are included; existing inputs are not regenerated.'}
(out/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({k:v for k,v in m.items() if k!='members'},indent=2));print('Manifest SHA256',hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest())
