# R7 clean/observed descriptive comparator r3

Prepared only. **Do not run until the R7 r2 observed route and its independent audit are fully closed.** This is a separate extended-wall-clock `EXPLORATORY_NOT_ACCEPTANCE` diagnostic, not the unchanged 300/330 ledger comparator, a causal conclusion, or gameplay acceptance. A timeout or missing `data.json` is ineligible.

`compare.py` takes the exact full SHA256 of fresh same-package R7 r2 types, clean and observed `RESULT.json` files. It also requires an independently written scratch JSON acceptance document, supplied with its own full SHA256, of the form:

```json
{"decision":"ACCEPT","resultSha256":"<full R7 observed RESULT SHA256>","classification":"EXPLORATORY_NOT_ACCEPTANCE","complete":true,"reviewPath":"<absolute independent REVIEW.md>","reviewSha256":"<full SHA256>","receiptPath":"<absolute independent RECEIPT.json>","receiptSha256":"<full SHA256>"}
```

An audit that accepts an *incomplete timeout receipt* must not set `complete:true`; the comparator also requires child and recorder exit 0, so such a receipt is rejected. This simple acceptance file is a gate and provenance pointer, not a cryptographic signature. It must be produced by the independent auditor, not by the comparator operator. The document must live directly under a `1368-ledger-r7-*independent*` scratch directory, bind separate review/receipt files by full SHA256, and the review text must name the exact observed RESULT SHA and `EXPLORATORY_NOT_ACCEPTANCE`. This is a provenance check, not proof of authorship; parent still decides whether that reviewer is independent.

Before opening either R7 `data.json`, the script checks the pinned R7 r2 package/runner/source identities and every 219 package member plus all 197 source-file hashes, exact three RESULT hashes, exploratory classification, arm/seed, actual child and recorder 0, no timeout, guards and formal postflight, cleanup/no survivors, every non-data RESULT artifact hash, RESULT/launch-command parity, binding 416/600/630 values, and types→clean→observed exact same-package receipt paths and SHAs. It checks the independent complete-observed acceptance path/SHA and its bound RESULT. Only then does it hash and parse the two data files, requiring completed 416-week ABC/p13a records and exact field sets.

Every shared data field is compared recursively. Weekly rows are compared by week; each differing top-level field gets its first differing path, bounded value preview, byte count and SHA256. The report names the first differing weekly week. It explicitly compares `finalStateDigest`, `actualPins`, `rows`, `finalMarket`, `finalEmployment`, `finalIndustryReceipts`, `finalRetirements`, and all other shared fields. `phaseRows` and `industryRows` are recorded as separate count/week/digest diagnostics because clean has empty arrays and observed is expected to populate them. Optional exact-hash R5 clean and R4 C0 inputs provide only `actualPins`, row-count and final-digest context; they are not part of R7 acceptance or a source-matched causal attribution.

The output path must be a fresh absolute scratch path and is created exclusively. Example after independent complete-observed audit (values deliberately omitted):

```sh
python3 -B compare.py \
  --types-result-sha '<full accepted R7 types SHA>' \
  --clean-result-sha '<full accepted R7 clean SHA>' \
  --observed-result-sha '<full accepted R7 observed SHA>' \
  --observed-audit '/Users/zacheryspector/studio-scratch/<independent-audit>/COMPARATOR-ACCEPTANCE.json' \
  --observed-audit-sha '<full acceptance-file SHA>' \
  --output '/Users/zacheryspector/studio-scratch/<new-output-dir>/RESULT.json'
```

`--r5-clean-result-sha 64c942ae10bd4648ee2269a4453980fb0ea77f8e75e289d00874c15aae5225a6` and `--r4-c0-result-sha cfdf38f6462e01937ca11217eb1bd0c6f09c7461097583661e79a34eb3531dc6` are optional context switches. Their outputs remain distinct source histories. Preparation validation: Python syntax passed. R1 is preserved as a weaker draft: it did not rehash actual source members or bind the acceptance document to independent review/receipt hashes. No R7 fixture was read, comparator result written, heavy lane launched or tracked file edited.

R3 correction: r2 used a nonexistent optional R4 C0 leaf `C0-clean-p13a-r1`; r3 uses the admitted `C0-clean-p13a-baseline-r1`. The required R7 source, receipt, audit and shared-field logic is byte-identical except the versioned output path. R2 is preserved as a draft.
