from pathlib import Path
import hashlib,json,subprocess,tempfile,os
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');P=S/'1368-ledger-r6-state-capture-proposal-20261005-r1';B=S/'1368-ledger-r5-profile-proposal-20261005-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'README.md')=='5ea33ae75f3be2f5789f2e794cfa539f3a8f9ae04e66bc19737b2d20b419f5fe'
assert sha(P/'MANIFEST.json')=='3671e0b599c59def8a1e326750edd458689f31dd6bdefbbd067f176717cc4622'
assert sha(P/'runner/run.py')=='ca496e9d52c33318cb79a2a873b304d684fd05adbc781620245f7cea788769a5'
assert sha(P/'PROBE.diff')=='d145786ff1a2a2bbbddf72dfdd83d0935d3e1f54cf0ef37388b97fdc6fc28775'
assert sha(P/'RUNNER.diff')=='9f5dbc9f1993010354b4594443941ee57a5b9fec9b2e1243793e87dd64b410db'
m=json.loads((P/'MANIFEST.json').read_text());assert len(m['files'])==216
for name,row in m['files'].items():
 f=P/name;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
assert m['runnerSha256']==sha(P/'runner/run.py') and m['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and m['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and m['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
assert m['baseR5ManifestSha256']==sha(B/'MANIFEST.json') and m['baseR5RunnerSha256']==sha(B/'runner/run.py')
a=json.loads((P/'arm/SOURCE-PINS.json').read_text());b=json.loads((B/'arm/SOURCE-PINS.json').read_text())
assert len(a)==len(b)==197
assert {n for n in a if a[n]!=b[n]}=={'tests/1368-ledger-attribution.test.ts'}
assert all(a[n]==b[n] for n in a if n.startswith('src/'))
assert all(sha(P/'arm/tree'/n)==a[n] for n in a)
assert set(n.removeprefix('arm/tree/') for n in m['files'] if n.startswith('arm/tree/'))==set(a)
assert (P/'arm/tree/node_modules').is_symlink() and (P/'arm/tree/node_modules').resolve()==(R/'node_modules').resolve()
for base,target,diff in [(B/'arm/tree/tests/1368-ledger-attribution.test.ts',P/'arm/tree/tests/1368-ledger-attribution.test.ts',P/'PROBE.diff'),(B/'runner/run.py',P/'runner/run.py',P/'RUNNER.diff')]:
 with tempfile.TemporaryDirectory() as td:
  out=Path(td)/'patched';result=subprocess.run(['patch','-s','-o',str(out),str(base),str(diff)],capture_output=True)
  assert result.returncode==0 and out.read_bytes()==target.read_bytes(),str(diff)
old=(B/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text();new=(P/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text()
for frag in ['}, 300_000)', 'phaseRows.push(', 'industryRows.push(', 'weekly.push(', 'admit(input,', 'admit(answer,']:
 assert old.count(frag)==new.count(frag)==1,frag
assert old.count('appendFileSync(progress,')==new.count('appendFileSync(progress,')==1
assert old.count('appendFileSync(profile,')==new.count('appendFileSync(profile,')==1
assert 'assert.equal(restoredSnapshot, finalSnapshot' in new and 'writeFileSync(capture, stateBytes' in new
runner=(P/'runner/run.py').read_text()
for frag in ["'outerCapSeconds': 330", "'probeTestSeconds': 300", 'proc.wait(timeout=330)', "LEDGER_CAPTURE=b['capturePath'] or ''", 'captureStatus', "prior_types(Path(b['typesReceipt'])", "prior_clean(Path(b['cleanReceipt'])"]:assert frag in runner,frag
report={'decision':'ACCEPT','manifestSha256':sha(P/'MANIFEST.json'),'runnerSha256':sha(P/'runner/run.py'),'membersVerified':216,'armFiles':197,'productionFilesExact':188,'onlyChangedArmFile':'tests/1368-ledger-attribution.test.ts','probeAndRunnerPatchReconstructionExact':True,'originalRouteCallsitesAndCapsPreserved':True,'heavyRunPerformed':False,'independentTypecheckExit':0,'roundtripCheckerExit':0,'readOnlyRunnerVerifyExit':0,'captureScope':'clean p13a final GameState at week 416','observedRepresentativenessProven':False,'liveRoundTripProven':False}
out=Path(__file__).with_name('RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
