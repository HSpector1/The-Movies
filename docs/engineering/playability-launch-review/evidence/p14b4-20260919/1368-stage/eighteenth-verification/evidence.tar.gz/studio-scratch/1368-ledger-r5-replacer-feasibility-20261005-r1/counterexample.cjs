const log=[]
const obj={}
Object.defineProperty(obj,'b',{enumerable:true,get(){log.push('get:b');obj.a=2;return 3}})
obj.a=1
console.log('frozen-sorted-read',JSON.stringify(Object.keys(obj).sort().map(k=>[k,obj[k]])),log.join(','))
obj.a=1;log.length=0
console.log('native-replacer',JSON.stringify(obj,(_k,v)=>v),log.join(','))
const calls=[]
const x={a:1,toJSON(){calls.push('toJSON');return {a:9}}}
console.log('toJSON-before-replacer',JSON.stringify(x,(_k,v)=>{calls.push('replacer:'+_k);return v}),calls.join(','))
console.log('native-map',JSON.stringify(new Map([['first',1],['second',2]]),(_k,v)=>v))
