# Independent R6 types-to-clean gate

Decision: **ACCEPT for one R6 ABC clean p13a capture run**, subject to fresh live HEAD/remote, lane, disk and power checks. This receipt does not launch clean or prove a live V8 roundtrip.

The frozen R6 manifest (`3671e0b599c59def8a1e326750edd458689f31dd6bdefbbd067f176717cc4622`) rehashes across all 216 listed members. Runner, arm source, assembly and kit hashes agree with its pins. The types RESULT SHA is `765b0b8ef28573e367cce57d703891e1916eab82206a7ad4d908f26f7be4ba62`; it binds the same package, runner and 197-file arm. Actual child and recorder both exited 0 with no timeout, exact source guards and postflight, empty reporting errors, verified process-group cleanup and no survivors. Every one of its 11 artifact hashes and byte lengths matches its source. Formal record SHA is `ff59d6860d2108aa2d6b28b79cbbeff83b5674dd43794c02da80bdee58d82007`; postflight SHA is `6dfbff383080ed26ac8af7808ebd0aac3505972b504ed90c6c01de9453725f6a`. Wrapper meta ended exit 0. Profile and capture sidecars are absent as required in types mode.

A future clean binding must cite this exact types RESULT hash. Its result must separately prove full 416-week output equality with accepted R5 clean, 8 profile marks, a successful live `rawSnap` roundtrip, exclusive `state.v8` identity and formal cleanup. A failed capture cannot be treated as a usable fixture.

`verify.py` and `RECEIPT.json` are the independent read-only receipt. No heavy run or tracked/frozen edit was made by this review.
