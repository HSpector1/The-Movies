from pathlib import Path
from hashlib import sha256
import json,difflib
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
P=S/'1368-ledger-r7-exploratory-proposal-20261005-r2';C=S/'1368-ledger-r7-descriptive-comparator-20261005-r3';O=S/'1368-ledger-r7-descriptive-comparison-20261005-r3/RESULT.json';A=S/'1368-ledger-r7-observed-independent-audit-20261005/COMPARATOR-ACCEPTANCE.json'
H=lambda p:sha256(p.read_bytes()).hexdigest()
pins={'code':'fe33b120a17d4231481706222a5997ca7c216887379415bb9a05614f0b6b1f80','output':'8444532713d18e6dda6472d1c49dc1679fb5a9d6ff921222b6a49facf067da63','manifest':'855eae61224f7211999795437fd19c9ae32f6f797548161b6e64a3373c4f8bc6','runner':'c99a2d7c6ec23c2548974378e94a8afdacd631855daf27382682ab75102ddb10','source':'89048717737f6a792324f00418f416d5890a94adb131547c3dfcc9fc0ab3cc67','types':'8280f61a97fb0c01813790ce73167b4f7f12f84e86181a60c362c9bc896ea2fc','clean':'dfbcb7d4d2f62a24b48f59faefa556b20c8d4526f35ecc4e8378a6aae2f4a6d1','observed':'f32372702e7f391570accc6c9eba98c349feca6ca602aaac8d819c4d75742e07','audit':'1996432820c0b145ee74cf822ca66fafa5946e6774d108a20150398f597950e1','r5':'64c942ae10bd4648ee2269a4453980fb0ea77f8e75e289d00874c15aae5225a6','c0':'cfdf38f6462e01937ca11217eb1bd0c6f09c7461097583661e79a34eb3531dc6'}
assert H(C/'compare.py')==pins['code'] and H(O)==pins['output']
old=(S/'1368-ledger-r7-descriptive-comparator-20261005-r2/compare.py').read_text().splitlines(True);new=(C/'compare.py').read_text().splitlines(True)
diff=''.join(difflib.unified_diff(old,new,fromfile='comparator-r2/compare.py',tofile='comparator-r3/compare.py'))
assert diff==(C/'R2-TO-R3.diff').read_text()
assert H(P/'MANIFEST.json')==pins['manifest'] and H(P/'runner/run.py')==pins['runner'] and H(P/'arm/SOURCE-PINS.json')==pins['source']
manifest=json.loads((P/'MANIFEST.json').read_text());source=json.loads((P/'arm/SOURCE-PINS.json').read_text());assert len(manifest['files'])==219 and len(source)==197
for rel,row in manifest['files'].items():
 q=P/rel;assert q.is_file() and not q.is_symlink() and H(q)==row['sha256'] and q.stat().st_size==row['bytes'],rel
for rel,pin in source.items():assert H(P/'arm/tree'/rel)==pin,rel
runs=S/'1368-ledger-recorded-runs-r7-exploratory-r2';leaves={'types':'ABC-types-source-r1','clean':'ABC-clean-p13a-r1','observed':'ABC-observed-p13a-r1'};records={};bindings={};artifact_count={}
for mode,leaf in leaves.items():
 d=runs/leaf;q=d/'RESULT.json';assert H(q)==pins[mode];row=json.loads(q.read_text());records[mode]=row
 assert row['classification']=='EXPLORATORY_NOT_ACCEPTANCE' and row['mode']==mode and row['arm']=='ABC' and row['seed']==(None if mode=='types' else 'p13a-core-causal-01')
 assert row['actualChildExit']==row['recorderChildExit']==0 and row['timedOut'] is False and row['allGuardsExact'] and row['livePostflightExact'] and row['reportingErrors']==[]
 assert all(row['processGroup'][k] is True for k in ['cleanupVerified','noSurvivors','leaderReaped'])
 assert row['pins']['runnerManifestSha256']==pins['manifest'] and row['pins']['selfRunnerSha256']==pins['runner'] and row['pins']['sourcePinsSha256']==pins['source']
 for name,art in row['artifacts'].items():
  f=Path(name);assert f.is_file() and not f.is_symlink() and H(f)==art['sha256'] and f.stat().st_size==art['bytes'],name
 artifact_count[mode]=len(row['artifacts'])
 b=json.loads((d/'binding.json').read_text());bindings[mode]=b;assert b['classification']=='EXPLORATORY_NOT_ACCEPTANCE' and b['horizon']==416 and b['probeTestSeconds']==600 and b['outerCapSeconds']==630
 assert b['manifestPin']==pins['manifest'] and b['selfRunnerSha256']==pins['runner'] and b['command']==row['command']
 stem='1368-ledger-r7-exploratory-r2-abc-'+('types-source' if mode=='types' else mode+'-p13a')+'-r1';formal=json.loads((E/(stem+'.json')).read_text());post=json.loads((E/(stem+'-postflight.json')).read_text())
 assert formal['fixedSource'] and post['fixedSource'] and post['allGuardsExact'] and formal['exitCode']==post['exitCode']==0
 assert formal['sourceSha']==formal['sourceShaAtEnd']==post['head']==row['pins']['publicationHead']
assert bindings['clean']['typesReceipt']==str(runs/leaves['types']/'RESULT.json') and bindings['clean']['typesReceiptSha256']==pins['types']
assert bindings['observed']['typesReceipt']==str(runs/leaves['types']/'RESULT.json') and bindings['observed']['typesReceiptSha256']==pins['types']
assert bindings['observed']['cleanReceipt']==str(runs/leaves['clean']/'RESULT.json') and bindings['observed']['cleanReceiptSha256']==pins['clean']
for key in ['sourcePinsSha256','assemblySha256','kitManifestSha256','inputPinsSha256','runnerManifestSha256','selfRunnerSha256','entrypoints','regularFiles']:
 assert records['types']['pins'][key]==records['clean']['pins'][key]==records['observed']['pins'][key]
assert H(A)==pins['audit'];audit=json.loads(A.read_text());assert audit['decision']=='ACCEPT' and audit['resultSha256']==pins['observed'] and audit['complete'] is True and audit['classification']=='EXPLORATORY_NOT_ACCEPTANCE'
for label in ['review','receipt']:
 q=Path(audit[label+'Path']);assert H(q)==audit[label+'Sha256']
assert pins['observed'] in Path(audit['reviewPath']).read_text() and 'EXPLORATORY_NOT_ACCEPTANCE' in Path(audit['reviewPath']).read_text()
report=json.loads(O.read_text());assert report['classification']=='DESCRIPTIVE_ONLY_NOT_ACCEPTANCE' and report['r7Classification']=='EXPLORATORY_NOT_ACCEPTANCE'
assert report['inputs']=={'typesResultSha256':pins['types'],'cleanResultSha256':pins['clean'],'observedResultSha256':pins['observed'],'observedAuditSha256':pins['audit'],'cleanDataSha256':H(runs/leaves['clean']/'data.json'),'observedDataSha256':H(runs/leaves['observed']/'data.json')}
clean=json.loads((runs/leaves['clean']/'data.json').read_text());observed=json.loads((runs/leaves['observed']/'data.json').read_text())
expected={'completed','arm','mode','seed','horizon','sourcePins','originalPins','weekly','phaseRows','industryRows','actualPins','pinComparisons','rows','finalStateDigest','finalMarket','finalEmployment','finalIndustryReceipts','finalRetirements','sourcePostflight'}
assert set(clean)==set(observed)==expected
for name,data in [('clean',clean),('observed',observed)]:
 assert data['completed'] and data['sourcePostflight'] and data['arm']=='ABC' and data['mode']==name and data['seed']=='p13a-core-causal-01' and data['horizon']==416
 assert len(data['weekly'])==416 and [r['week'] for r in data['weekly']]==list(range(1,417)) and len(data['rows'])==data['actualPins']['rows']
assert clean['sourcePins']==observed['sourcePins']
assert clean['originalPins']==observed['originalPins']
shared=expected-{'mode','phaseRows','industryRows'};equal={field:clean[field]==observed[field] for field in shared}
assert all(equal.values()) and report['firstDifferingWeeklyWeek'] is None
assert report['sharedFieldComparisons']=={field:{'equal':True,'firstDifference':None} for field in sorted(shared)}
assert report['equalSharedFields']==sorted(shared) and report['differingSharedFields']==[]
def diag(rows):
 w=[x.get('week') for x in rows if isinstance(x,dict)];raw=json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode();return {'count':len(rows),'firstWeek':w[0] if w else None,'lastWeek':w[-1] if w else None,'digest':sha256(raw).hexdigest()}
assert report['observedOnlyDiagnostics']=={k:diag(observed[k]) for k in ['phaseRows','industryRows']}
assert report['cleanModeDiagnostics']=={k:diag(clean[k]) for k in ['phaseRows','industryRows']}
assert len(clean['phaseRows'])==len(clean['industryRows'])==0 and len(observed['phaseRows'])==len(observed['industryRows'])==416
contexts={
 'r5Clean':(S/'1368-ledger-recorded-runs-r5-profile-r1/ABC-clean-p13a-r1/RESULT.json','ABC',pins['r5']),
 'r4C0':(S/'1368-ledger-recorded-runs-r4-lowspace-r2/C0-clean-p13a-baseline-r1/RESULT.json','C0',pins['c0'])}
for label,(q,arm,pin) in contexts.items():
 assert H(q)==pin;row=json.loads(q.read_text());assert row['arm']==arm and row['mode']=='clean' and row['seed']=='p13a-core-causal-01' and row['actualChildExit']==row['recorderChildExit']==0 and not row['timedOut']
 datafile=q.parent/'data.json';raw=datafile.read_bytes();assert row['artifacts'][str(datafile)]['sha256']==sha256(raw).hexdigest();data=json.loads(raw)
 assert report['optionalContext'][label]=={'resultSha256':pin,'dataSha256':sha256(raw).hexdigest(),'arm':arm,'mode':'clean','actualPins':data['actualPins'],'rowCount':len(data['rows']),'finalStateDigest':data['finalStateDigest']}
assert report['optionalContext']['r5Clean']['dataSha256']==report['inputs']['cleanDataSha256']
assert report['interpretation']=='Field differences are descriptive under separately extended 600/630 diagnostic bounds; no causal, unchanged-comparator, gameplay or original-route acceptance claim.'
receipt={'decision':'ACCEPT','classification':'DESCRIPTIVE_ONLY_NOT_ACCEPTANCE','codeSha256':pins['code'],'resultSha256':pins['output'],'r2ToR3PatchExact':True,'packageMembers':219,'armMembers':197,'r7ArtifactCounts':artifact_count,'r7FormalAndCleanupExact':True,'receiptLinkageExact':True,'independentObservedAuditBound':True,'sharedFieldsChecked':sorted(shared),'allSharedFieldsEqual':True,'observedPhaseRows':416,'observedIndustryRows':416,'optionalContextHashesExact':True,'sourceHistoriesDistinct':True,'heavyRunPerformed':False}
out=S/'1368-ledger-r7-comparator-independent-audit-20261005/RECEIPT.json';out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
