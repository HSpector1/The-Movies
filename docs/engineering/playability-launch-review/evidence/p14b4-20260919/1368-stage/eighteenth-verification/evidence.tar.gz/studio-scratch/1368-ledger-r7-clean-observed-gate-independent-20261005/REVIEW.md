# Independent R7 r2 clean-to-observed gate

Decision: **ACCEPT for one same-R7 exploratory ABC observed p13a run**, subject to fresh live HEAD/remote, lane, disk and power checks. This remains `EXPLORATORY_NOT_ACCEPTANCE` under 600/630 limits and cannot serve as the original 300/330 bounded-route result or unchanged comparator input.

R7 clean RESULT SHA `dfbcb7d4d2f62a24b48f59faefa556b20c8d4526f35ecc4e8378a6aae2f4a6d1` binds the frozen 219-member R7 r2 package, runner and exact fresh R7 types RESULT `8280f61a97fb0c01813790ce73167b4f7f12f84e86181a60c362c9bc896ea2fc`. I rehashed all package members and all 15 RESULT artifacts. Actual child and recorder exited 0 without timeout; formal record SHA `4ab59115a6401f1035baf02f61bb02f8c0a6ee267e086b38ffe4cd030b835a09` and postflight SHA `e9cddd72386726f3639f33ba62580eeea78d9d245807f5e96877fa435730985a` agree on fixed source and exact guards. Process-group cleanup is verified with no survivors, and wrapper meta ended exit 0.

Clean p13a completed 416 ordered weeks, eight ordered progress/profile checkpoints and one Vitest PASS. Profile cumulative schema and final clean call counts are exact. Its `data.json` is byte-for-byte identical to accepted R5 ABC clean p13a, SHA `18f1a6b913061f92a43f0ab432fff159714afadc0e781b62cadf6e923d01c108`, including all ordinary fields. The observed binding must cite this exact R7 clean RESULT SHA and same-R7 types SHA. The runner's observed prerequisite will rehash both receipts and repeat the R5 clean-data equality check.

`verify.py` and `RECEIPT.json` are the independent read-only receipt. No heavy task or tracked/frozen edit was made by this review.
