from pathlib import Path
from hashlib import sha256
import importlib.util,json,ast
ROOT=Path('/Users/zacheryspector/studio-scratch')
P=ROOT/'1368-ledger-r7-descriptive-comparator-20261005-r2/compare.py'
spec=importlib.util.spec_from_file_location('r7_comparator_under_self_review',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
text=P.read_text();ast.parse(text)
assert m.SHARED_FIELDS==m.EXPECTED_FIELDS-{'mode','phaseRows','industryRows'}
for key in ('weekly','finalStateDigest','actualPins','rows','finalMarket','finalEmployment','finalIndustryReceipts','finalRetirements'):
    assert key in m.SHARED_FIELDS
left={'z':[{'week':1,'owners':[1]},{'week':2,'owners':[1]}],'a':1}
right={'a':1,'z':[{'owners':[1],'week':1},{'owners':[2],'week':2}]}
diff=m.first_diff(left,right)
assert diff['path']=='$.z[1].owners[0]' and len(diff['left']['preview'])<=180 and len(diff['right']['preview'])<=180
assert m.first_diff({'a':1,'b':2},{'b':2,'a':1}) is None
assert m.first_diff([1,2],[1,2,3])['path']=='$.length'
assert m.first_diff({'a':1},{'b':1})['path']=='$.a'
assert len(json.dumps(m.diagnostic_rows([{'week':2},{'week':3}])))<300
main_text=text[text.index('def main():'):]
assert main_text.index("pinned(P/'MANIFEST.json'")<main_text.index('items={name:receipt')<main_text.index('audit_path=Path(args.observed_audit)')<main_text.index("raw=artifact(row,path.parent/'data.json',True)")
assert "audit_dir.name.startswith('1368-ledger-r7-') and 'independent' in audit_dir.name" in text
assert "pinned(q,audit[label+'Sha256'])" in text
assert 'args.observed_result_sha in review' in text
assert "row['command']==binding['command']" in text
assert 'for rel,expected in source.items()' in text and 'pinned(P/\'arm/tree\'/rel,expected)' in text
pkg=json.loads((m.P/'MANIFEST.json').read_text());assert len(pkg['files'])==219
for rel,pin in pkg['files'].items():
 q=m.regular(m.P/rel);assert q.stat().st_size==pin['bytes'] and m.digest(q)==pin['sha256']
source=json.loads((m.P/'arm/SOURCE-PINS.json').read_text());assert len(source)==197
for rel,pin in source.items():m.pinned(m.P/'arm/tree'/rel,pin)
receipts={}
for mode in ('types','clean'):
 q=m.RUNS/m.LEAVES[mode]/'RESULT.json';pin=m.digest(q)
 path,row,binding=m.receipt(mode,pin)
 receipts[mode]={'sha256':pin,'classification':row['classification'],'sourcePinsSha256':row['pins']['sourcePinsSha256']}
assert receipts['types']['sourcePinsSha256']==receipts['clean']['sourcePinsSha256']==m.SOURCE_SHA
clean=json.loads((m.RUNS/m.LEAVES['clean']/'binding.json').read_text())
assert clean['typesReceipt']==str(m.RUNS/m.LEAVES['types']/'RESULT.json') and clean['typesReceiptSha256']==receipts['types']['sha256']
report={'classification':'SELF_REVIEW_NOT_INDEPENDENT','codeSha256':sha256(P.read_bytes()).hexdigest(),
        'checks':['219 package hashes','197 source hashes','actual R7 types and clean non-data receipt/formal/cleanup gates','same-R7 clean types binding','synthetic recursive path/key-order/length/bounded preview','audit-before-data source ordering'],
        'typesAndClean':receipts,'observedDataRead':False,'observedAuditClaim':False,
        'limits':'Self-review of own comparator; source ordering/static assertions and synthetic pure fixtures cannot replace independent observed audit or review of a future complete result.'}
out=ROOT/'1368-ledger-r7-comparator-self-review-20261005-r1/RECEIPT.json'
with out.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'status':'PASS','receiptSha256':sha256(out.read_bytes()).hexdigest(),'observedDataRead':False}))
