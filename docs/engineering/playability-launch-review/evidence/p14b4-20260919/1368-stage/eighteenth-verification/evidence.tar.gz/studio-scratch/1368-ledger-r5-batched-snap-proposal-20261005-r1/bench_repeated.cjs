const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),ts=require('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/tree/node_modules/typescript')
const root='/Users/zacheryspector/studio-scratch/1368-ledger-r5-batched-snap-proposal-20261005-r1'
function load(name){const js=ts.transpileModule(fs.readFileSync(`${root}/${name}`,'utf8')+'\nexports.snap=snap',{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;const c={exports:{},assert,Buffer,Map,Set,Date,Object,ArrayBuffer,JSON,String,Number};vm.runInNewContext(js,c);return c.exports.snap}
const frozen=load('snap-frozen.ts'),candidate=load('snap-candidate.ts')
const data=JSON.parse(fs.readFileSync('/Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4-lowspace-r2/ABC-clean-p13a-r1/data.json','utf8'))
const samples={weekly208:data.weekly[207],recordedCleanData:data}
function median(a){const s=[...a].sort((x,y)=>x-y);return (s[3]+s[4])/2}
function timed(fn,v,reps){const start=process.hrtime.bigint();for(let i=0;i<reps;i++)fn(v);return Number(process.hrtime.bigint()-start)/1e6/reps}
const output={node:process.version,v8:process.versions.v8,rounds:8,samples:{}}
for(const [name,value] of Object.entries(samples)){
  assert.equal(frozen(value),candidate(value),name)
  for(let i=0;i<3;i++){frozen(value);candidate(value)}
  const frozenMs=[],candidateMs=[],reps=name==='recordedCleanData'?1:20
  for(let round=0;round<8;round++){
    if(round%2===0){frozenMs.push(timed(frozen,value,reps));candidateMs.push(timed(candidate,value,reps))}
    else{candidateMs.push(timed(candidate,value,reps));frozenMs.push(timed(frozen,value,reps))}
  }
  output.samples[name]={repsPerRound:reps,frozenMs,candidateMs,medianFrozenMs:median(frozenMs),medianCandidateMs:median(candidateMs),speedRatio:median(frozenMs)/median(candidateMs)}
}
fs.writeFileSync(`${root}/REPEATED-BENCH.json`,JSON.stringify(output,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(Object.fromEntries(Object.entries(output.samples).map(([k,v])=>[k,{frozen:v.medianFrozenMs,candidate:v.medianCandidateMs,ratio:v.speedRatio}]))))
