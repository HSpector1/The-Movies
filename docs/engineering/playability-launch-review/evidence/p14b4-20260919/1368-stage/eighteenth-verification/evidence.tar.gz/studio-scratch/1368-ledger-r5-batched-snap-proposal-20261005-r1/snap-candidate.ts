function snap(value: unknown): string {
  const ancestors = new Set<object>()
  const chunks: string[] = []
  let pending = ''
  const emit = (part: string) => {
    pending += part
    if (pending.length >= 65536) { chunks.push(pending); pending = '' }
  }
  const string = (part: string) => emit(JSON.stringify(part))
  const pair = (kind: string, payload: string) => { emit('["' + kind + '",'); string(payload); emit(']') }
  const visit = (v: unknown): void => {
    if (v === null) { emit('["null"]'); return }
    if (v === undefined) { emit('["undefined"]'); return }
    if (typeof v === 'number') { pair('number', Object.is(v, -0) ? '-0' : String(v)); return }
    if (typeof v === 'string') { pair('string', v); return }
    if (typeof v === 'boolean') { pair('boolean', String(v)); return }
    if (typeof v === 'bigint') { pair('bigint', String(v)); return }
    assert(typeof v === 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) {
        const entries = [...v]
        emit('["Map",[')
        for (let i = 0; i < entries.length; i++) {
          if (i) emit(',')
          const [k, x] = entries[i]!
          emit('['); visit(k); emit(','); visit(x); emit(']')
        }
        emit(']]'); return
      }
      if (v instanceof Set) {
        const entries = [...v]
        emit('["Set",[')
        for (let i = 0; i < entries.length; i++) { if (i) emit(','); visit(entries[i]) }
        emit(']]'); return
      }
      if (v instanceof Date) { pair('Date', v.toISOString()); return }
      if (ArrayBuffer.isView(v)) { const name = v.constructor.name; const bytes = Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64'); emit('['); string(name); emit(','); string(bytes); emit(']'); return }
      if (v instanceof ArrayBuffer) { pair('ArrayBuffer', Buffer.from(v).toString('base64')); return }
      if (Array.isArray(v)) {
        const length = v.length
        emit('["Array",[')
        for (let i = 0; i < length; i++) { if (i) emit(','); if (i in v) visit(v[i]); else emit('["hole"]') }
        emit(']]'); return
      }
      const proto: unknown = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      const record = v as Record<string, unknown>
      const keys = Object.keys(record).sort()
      emit(proto === null ? '["null-object",[' : '["object",[')
      for (let i = 0; i < keys.length; i++) { if (i) emit(','); const key = keys[i]!; emit('['); string(key); emit(','); visit(record[key]); emit(']') }
      emit(']]')
    } finally { ancestors.delete(v) }
  }
  visit(value)
  chunks.push(pending)
  return chunks.join('')
}
