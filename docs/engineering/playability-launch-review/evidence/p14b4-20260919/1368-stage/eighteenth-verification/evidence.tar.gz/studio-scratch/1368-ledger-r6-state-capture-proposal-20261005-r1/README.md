# R6 representative-state capture proposal (static only)

This scratch package derives from the frozen R5 ABC profile package. It retains the 188 production source files, original ledger helper/seed, 416-week horizon, seven phase snapshot traversals, 417 admissions, 300-second Vitest timeout, 330-second outer cap, source guards, recorder, cleanup, output data shape, and eight progress/profile checkpoints. The only test change at successful final completion serializes the full `GameState` with Node `v8.serialize`, deserializes it immediately, and requires byte-identical `rawSnap` tagged output and matching SHA-256 digest before creating the exclusive `state.v8` sidecar. `data.json` fields and values are unchanged on success. The runner binds the sidecar path in `binding.json`, verifies it was absent at launch, and records SHA-256, size, seed, week 416, source pin, and usable status in `RESULT.json`. Timeout/failure keeps the exact partial evidence and marks the sidecar unusable. The sidecar is capped at 64 MiB.

V8 serialization is **not yet proven to support the live final state**. Node 20.20.2 turns null-prototype objects into ordinary objects on deserialization; `rawSnap` distinguishes these. The included isolated checker verifies this negative control. Any such difference in the live state fails the probe and cannot produce a usable fixture. Capture also adds time after week 416 and may push a run beyond unchanged caps; there is no speed or completion claim.

Base R5 manifest and runner pins are in `MANIFEST.json`. `PROBE.diff` and `RUNNER.diff` show every test and runner edit. The new kit and arm pin records bind the changed probe; all production hashes and the original `1368-ledger-original.ts` remain identical to R5. `arm/tree/node_modules` is a local symlink only and is excluded from manifest membership.

Static verification, no route run:

```
/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node check_roundtrip.cjs
/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node arm/tree/node_modules/typescript/bin/tsc --noEmit -p arm/tree/tsconfig.1368-ledger.json
python3 -B runner/run.py --help
```

Any later launch requires independent review and fresh HEAD/remote, idle lane, power, >=3 GiB, package/runner pins, unique run/formal/log namespace, then a new R6 `types` receipt followed by one `clean` p13a run using that receipt. No R5 RESULT is silently reused. There is no authorization in this proposal to launch either step.
