from pathlib import Path
import hashlib,json,re,subprocess
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');P=S/'1368-ledger-r6-state-capture-proposal-20261005-r1';RUNS=S/'1368-ledger-recorded-runs-r6-capture-r1';OUT=RUNS/'ABC-clean-p13a-r1';E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';STEM='1368-ledger-r6-capture-r1-abc-clean-p13a-r1';HERE=Path(__file__).parent
NODE=Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest='3671e0b599c59def8a1e326750edd458689f31dd6bdefbbd067f176717cc4622';runner='ca496e9d52c33318cb79a2a873b304d684fd05adbc781620245f7cea788769a5'
assert sha(P/'MANIFEST.json')==manifest and sha(P/'runner/run.py')==runner
m=read(P/'MANIFEST.json');assert len(m['files'])==216
for name,row in m['files'].items():
 f=P/name;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
assert m['runnerSha256']==runner and m['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and m['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and m['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
rp=OUT/'RESULT.json';r=read(rp);b=read(OUT/'binding.json')
assert (r['mode'],r['arm'],r['seed'])==('clean','ABC','p13a-core-causal-01')
assert (b['mode'],b['arm'],b['seed'],b['horizon'])==('clean','ABC','p13a-core-causal-01',416)
assert r['pins']==b['pins'] and b['manifestPin']==manifest and b['selfRunnerSha256']==runner and b['outerCapSeconds']==330 and b['probeTestSeconds']==300
assert b['profilePath']==str(OUT/'profile.jsonl') and b['capturePath']==str(OUT/'state.v8')
assert b['typesReceipt']==str(RUNS/'ABC-types-source-r1/RESULT.json') and b['typesReceiptSha256']==sha(RUNS/'ABC-types-source-r1/RESULT.json')=='765b0b8ef28573e367cce57d703891e1916eab82206a7ad4d908f26f7be4ba62'
assert r['pins']['runnerManifestSha256']==manifest and r['pins']['selfRunnerSha256']==runner and r['pins']['regularFiles']==197
assert r['pins']['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and r['pins']['assemblySha256']==sha(P/'arm/ASSEMBLY.json')
assert r['allGuardsExact'] and r['livePostflightExact'] and r['reportingErrors']==[]
g=r['processGroup'];assert g['cleanupVerified'] and g['noSurvivors'] and g['leaderReaped'] and not g['errors']
for name,row in r['artifacts'].items():
 f=Path(name);assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
pre=read(E/(STEM+'-preflight.json'));record=read(E/(STEM+'.json'));post=read(E/(STEM+'-postflight.json'))
head=r['pins']['publicationHead'];assert pre['head']==record['sourceSha']==record['sourceShaAtEnd']==post['head']==head
assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
assert record['exitCode']==post['exitCode']==r['recorderChildExit']
assert record['command']==[record['command'][0],str(P/'runner/run.py'),'--child',str(OUT),sha(OUT/'binding.json')]
assert read(OUT/'CHILD.json')['actualChildExit']==r['actualChildExit']
meta=(S/'heavy-queue/1368-ledger-r6-capture-clean-p13a-r1.log.meta').read_text();match=re.search(r'end, exit (\d+);',meta);assert match
wrapper=int(match.group(1));assert wrapper==r['recorderChildExit']
profile=OUT/'profile.jsonl';state=OUT/'state.v8';data=OUT/'data.json';vitest=OUT/'vitest.json'
ps=r['profileStatus'];cs=r['captureStatus']
assert ps['expected'] and ps['present']==profile.is_file() and ps['sha256']==(sha(profile) if profile.is_file() else None)
assert cs['expected'] and cs['present']==state.is_file() and cs['sha256']==(sha(state) if state.is_file() else None) and cs['bytes']==(state.stat().st_size if state.is_file() else None)
assert cs['seed']=='p13a-core-causal-01' and cs['sourcePinsSha256']==r['pins']['sourcePinsSha256']
report={'decision':'REFINE','resultSha256':sha(rp),'packageManifestSha256':manifest,'runnerSha256':runner,'packageMembersVerified':216,'artifactsVerified':len(r['artifacts']),'formalRecordSha256':sha(E/(STEM+'.json')),'formalPostflightSha256':sha(E/(STEM+'-postflight.json')),'actualChildExit':r['actualChildExit'],'recorderChildExit':r['recorderChildExit'],'wrapperExit':wrapper,'timedOut':r['timedOut'],'formalAndCleanupExact':True,'captureStatus':cs,'profileStatus':ps,'dataPresent':data.is_file(),'vitestPresent':vitest.is_file()}
if r['actualChildExit']==r['recorderChildExit']==wrapper==0 and not r['timedOut']:
 assert cs['usable'] and cs['week']==416 and state.is_file() and 0<state.stat().st_size<=64*1024*1024
 assert data.is_file() and vitest.is_file() and profile.is_file()
 d=read(data);assert d['completed'] and d['sourcePostflight'] and (d['arm'],d['mode'],d['seed'],d['horizon'])==('ABC','clean','p13a-core-causal-01',416)
 assert len(d['weekly'])==416 and [x['week'] for x in d['weekly']]==list(range(1,417))
 old=S/'1368-ledger-recorded-runs-r5-profile-r1/ABC-clean-p13a-r1/data.json';assert sha(data)==sha(old) and data.read_bytes()==old.read_bytes()
 progress=[json.loads(x) for x in (OUT/'progress.jsonl').read_text().splitlines()];profiles=[json.loads(x) for x in profile.read_text().splitlines()]
 weeks=list(range(52,417,52));assert [x['week'] for x in progress]==[x['week'] for x in profiles]==weeks
 assert ps=={'expected':True,'present':True,'sha256':sha(profile),'rows':weeks,'parseError':None}
 names={'snap','admit','owners','windowFacts','changedCases'}
 for x in profiles:
  assert set(x['functions'])==names and all(set(v)=={'calls','inclusiveNs','exclusiveNs'} and type(v['calls'])==int and int(v['inclusiveNs'])>=int(v['exclusiveNs'])>=0 for v in x['functions'].values())
 last=profiles[-1]['functions'];assert {n:last[n]['calls'] for n in ['admit','owners','windowFacts','changedCases']}=={'admit':417,'owners':416,'windowFacts':0,'changedCases':416}
 v=read(vitest);assert v['numTotalTests']==v['numPassedTests']==1 and v['numFailedTests']==0
 replay=subprocess.run([str(NODE),str(HERE/'replay.cjs'),str(state),d['finalStateDigest']],capture_output=True,text=True,check=True)
 replayed=json.loads(replay.stdout);assert replayed['week']==416 and replayed['digest']==d['finalStateDigest']
 report.update(decision='ACCEPT',stateSha256=sha(state),stateBytes=state.stat().st_size,dataSha256=sha(data),r5DataByteExact=True,weeklyRows=416,progressRows=8,profileRows=8,vitestPass=1,independentReplay=replayed)
 (HERE/'ACCEPTANCE.json').write_text(json.dumps({'decision':'ACCEPT','resultSha256':sha(rp),'stateSha256':sha(state)},indent=2)+'\n')
else:
 assert not cs['usable']
 report['reason']='No successful clean capture; retain exact timeout/failure evidence and do not issue acceptance for benchmark.'
assert not (HERE/'ACCEPTANCE.json').exists() or report['decision']=='ACCEPT'
(HERE/'RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['profileStatus','captureStatus']},indent=2))
