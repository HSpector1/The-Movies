from pathlib import Path
import hashlib,json,subprocess,tempfile
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');P=S/'1368-ledger-r7-exploratory-proposal-20261005-r2';B=S/'1368-ledger-r5-profile-proposal-20261005-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'README.md')=='da6701b80828951c91354db95ff1a8721262ba7c41db56a2863f56de2b9d3cf8'
assert sha(P/'MANIFEST.json')=='855eae61224f7211999795437fd19c9ae32f6f797548161b6e64a3373c4f8bc6'
assert sha(P/'runner/run.py')=='c99a2d7c6ec23c2548974378e94a8afdacd631855daf27382682ab75102ddb10'
assert sha(P/'arm/tree/tests/1368-ledger-attribution.test.ts')=='ea0127ce13babce69789c3293367b6a5355cb351dceb2447279adaf1a6436be2'
assert sha(P/'arm/tree/vitest.1368-ledger.config.ts')=='1c5996bf59686c136c4c30b886676f4b2d054f02e7b26588d99c638afca7c04e'
assert sha(P/'PROBE.diff')=='d00703caa591af9ee0ecae936c74f7d30d918e6100b00e2e1a0fddd4ea8759e9'
assert sha(P/'CONFIG.diff')=='36c0d4de9ae9da29908b71ad85d6bf6aa0316bf7ba6dcd68ad0cf38e77859834'
assert sha(P/'RUNNER.diff')=='a28dc880ac826f782353a84b0b952a6301ab1562c487e3a670312d7ffdb8764b'
m=json.loads((P/'MANIFEST.json').read_text());assert len(m['files'])==219 and m['status']=='EXPLORATORY_NOT_ACCEPTANCE; scratch proposal; no heavy run'
for name,row in m['files'].items():
 f=P/name;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
assert m['baseR5ManifestSha256']==sha(B/'MANIFEST.json')
assert m['runnerSha256']==sha(P/'runner/run.py') and m['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and m['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and m['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
a=json.loads((P/'arm/SOURCE-PINS.json').read_text());b=json.loads((B/'arm/SOURCE-PINS.json').read_text());assert len(a)==len(b)==197
assert {k for k in a if a[k]!=b[k]}=={'tests/1368-ledger-attribution.test.ts','vitest.1368-ledger.config.ts'}
assert all(a[k]==b[k] for k in a if k.startswith('src/')) and all(sha(P/'arm/tree'/k)==a[k] for k in a)
assert set(n.removeprefix('arm/tree/') for n in m['files'] if n.startswith('arm/tree/'))==set(a)
old=(B/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text();new=(P/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text();assert old.replace('}, 300_000)','}, 600_000)')==new and old.count('}, 300_000)')==1
oldcfg=(B/'arm/tree/vitest.1368-ledger.config.ts').read_text();newcfg=(P/'arm/tree/vitest.1368-ledger.config.ts').read_text();assert oldcfg.replace('testTimeout: 300_000','testTimeout: 600_000')==newcfg and oldcfg.count('testTimeout: 300_000')==1
assert (P/'kit/files/vitest.1368-ledger.config.ts').read_text()==newcfg
assert (P/'kit/files/tsconfig.1368-ledger.json').read_bytes()==(B/'kit/files/tsconfig.1368-ledger.json').read_bytes()
for base,target,diff in [(B/'arm/tree/tests/1368-ledger-attribution.test.ts',P/'arm/tree/tests/1368-ledger-attribution.test.ts',P/'PROBE.diff'),(B/'arm/tree/vitest.1368-ledger.config.ts',P/'arm/tree/vitest.1368-ledger.config.ts',P/'CONFIG.diff'),(B/'runner/run.py',P/'runner/run.py',P/'RUNNER.diff')]:
 with tempfile.TemporaryDirectory() as td:
  out=Path(td)/'patched';x=subprocess.run(['patch','-s','-o',str(out),str(base),str(diff)],capture_output=True)
  assert x.returncode==0 and out.read_bytes()==target.read_bytes(),str(diff)
run=(P/'runner/run.py').read_text()
for frag in ["'outerCapSeconds': 630", "'probeTestSeconds': 600", 'proc.wait(timeout=630)', 'EXPLORATORY_NOT_ACCEPTANCE', "prior_types(Path(b['typesReceipt'])", "prior_clean(Path(b['cleanReceipt'])", "(path.parent / 'data.json').read_bytes() == baseline_data.read_bytes()", "R5_CLEAN_SHA = '64c942ae10bd4648ee2269a4453980fb0ea77f8e75e289d00874c15aae5225a6'", "R5_DATA_SHA = '18f1a6b913061f92a43f0ab432fff159714afadc0e781b62cadf6e923d01c108'", "RUNS = S / '1368-ledger-recorded-runs-r7-exploratory-r2'", "stem = '1368-ledger-r7-exploratory-r2-'"]:
 assert frag in run,frag
assert '1368-ledger-r7-exploratory-proposal-20261005-r1' not in run
assert '1368-ledger-recorded-runs-r7-exploratory-r1' not in run
assert '1368-ledger-r7-exploratory-r1-' not in run
report={'decision':'ACCEPT','manifestSha256':sha(P/'MANIFEST.json'),'runnerSha256':sha(P/'runner/run.py'),'membersVerified':219,'armFiles':197,'productionFilesExact':188,'armChanges':['tests/1368-ledger-attribution.test.ts inline timeout 300000→600000','vitest.1368-ledger.config.ts testTimeout 300000→600000'],'kitConfig600000':True,'allThreePatchesReconstruct':True,'classification':'EXPLORATORY_NOT_ACCEPTANCE','outerCapSeconds':630,'probeTestSeconds':600,'freshR7TypesAndCleanPrerequisites':True,'r5CleanByteEqualityObservedGate':True,'r1IdentityLeak':False,'heavyRunPerformed':False,'independentTypecheckExit':0,'accountingFixtureExit':0,'readOnlyRunnerVerifyExit':0}
out=Path(__file__).with_name('R2-RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
