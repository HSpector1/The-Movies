from pathlib import Path
import hashlib,json,subprocess,tempfile
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');P=S/'1368-ledger-r7-exploratory-proposal-20261005-r1';B=S/'1368-ledger-r5-profile-proposal-20261005-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'README.md')=='10051760e8e487a997bf2e8a7b3960bb6b790c1c45973523885e306d350ddc5d'
assert sha(P/'MANIFEST.json')=='a686290d2acbfb7f041752393bb77bba67eb7106aef00b697dc0db29d0b40f50'
assert sha(P/'runner/run.py')=='aad6ba37e05b07b5334a39f0369b4d925d8897e4f1c7070ffe91175d6dcf196a'
assert sha(P/'arm/tree/tests/1368-ledger-attribution.test.ts')=='ea0127ce13babce69789c3293367b6a5355cb351dceb2447279adaf1a6436be2'
assert sha(P/'PROBE.diff')=='d00703caa591af9ee0ecae936c74f7d30d918e6100b00e2e1a0fddd4ea8759e9'
assert sha(P/'RUNNER.diff')=='a4fad9ab0805fcd5afaa922da5c910cf06a4279e222dc70c9c72ae4a4298c662'
m=json.loads((P/'MANIFEST.json').read_text());assert len(m['files'])==218 and m['status']=='EXPLORATORY_NOT_ACCEPTANCE; scratch proposal; no heavy run'
for name,row in m['files'].items():
 f=P/name;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
assert m['runnerSha256']==sha(P/'runner/run.py') and m['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and m['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and m['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
a=json.loads((P/'arm/SOURCE-PINS.json').read_text());b=json.loads((B/'arm/SOURCE-PINS.json').read_text());assert len(a)==len(b)==197
assert {k for k in a if a[k]!=b[k]}=={'tests/1368-ledger-attribution.test.ts'}
assert all(a[k]==b[k] for k in a if k.startswith('src/'))
assert all(sha(P/'arm/tree'/k)==a[k] for k in a)
assert set(n.removeprefix('arm/tree/') for n in m['files'] if n.startswith('arm/tree/'))==set(a)
old=(B/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text();new=(P/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text();assert old.replace('}, 300_000)','}, 600_000)')==new
assert old.count('}, 300_000)')==1 and new.count('}, 600_000)')==1
oldkit=(B/'kit/files/vitest.1368-ledger.config.ts').read_text();newkit=(P/'kit/files/vitest.1368-ledger.config.ts').read_text();assert oldkit.replace('testTimeout: 300_000','testTimeout: 600_000')==newkit
for base,target,diff in [(B/'arm/tree/tests/1368-ledger-attribution.test.ts',P/'arm/tree/tests/1368-ledger-attribution.test.ts',P/'PROBE.diff'),(B/'runner/run.py',P/'runner/run.py',P/'RUNNER.diff')]:
 with tempfile.TemporaryDirectory() as td:
  out=Path(td)/'patched';x=subprocess.run(['patch','-s','-o',str(out),str(base),str(diff)],capture_output=True)
  assert x.returncode==0 and out.read_bytes()==target.read_bytes(),str(diff)
runner=(P/'runner/run.py').read_text()
for text in ["'outerCapSeconds': 630", "'probeTestSeconds': 600", 'proc.wait(timeout=630)', 'EXPLORATORY_NOT_ACCEPTANCE', "prior_types(Path(b['typesReceipt'])", "prior_clean(Path(b['cleanReceipt'])", "(path.parent / 'data.json').read_bytes() == baseline_data.read_bytes()", "R5_CLEAN_SHA = '64c942ae10bd4648ee2269a4453980fb0ea77f8e75e289d00874c15aae5225a6'", "R5_DATA_SHA = '18f1a6b913061f92a43f0ab432fff159714afadc0e781b62cadf6e923d01c108'"]:
 assert text in runner,text
assert "RUNS = S / '1368-ledger-recorded-runs-r7-exploratory-r1'" in runner
assert "stem = '1368-ledger-r7-exploratory-r1-'" in runner
report={'decision':'ACCEPT','manifestSha256':sha(P/'MANIFEST.json'),'runnerSha256':sha(P/'runner/run.py'),'membersVerified':218,'armFiles':197,'productionFilesExact':188,'onlyArmChange':'one final test timeout 300000 to 600000','kitConfigOnlyChange':'testTimeout 300000 to 600000','runnerPatchReconstructionExact':True,'classification':'EXPLORATORY_NOT_ACCEPTANCE','outerCapSeconds':630,'probeTestSeconds':600,'freshR7TypesAndCleanPrerequisites':True,'r5CleanByteEqualityObservedGate':True,'heavyRunPerformed':False}
out=Path(__file__).with_name('RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
