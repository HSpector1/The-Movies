const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const ts = require('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/tree/node_modules/typescript')
const root = '/Users/zacheryspector/studio-scratch/1368-ledger-r5-batched-snap-proposal-20261005-r1'
function load(file) {
  const source = fs.readFileSync(`${root}/${file}`, 'utf8')
  const js = ts.transpileModule(source + '\nexports.snap = snap', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText
  const context = { exports: {}, assert, Buffer, Map, Set, Date, Object, ArrayBuffer, JSON, String, Number }
  vm.runInNewContext(js, context)
  return context.exports.snap
}
const frozen = load('snap-frozen.ts'), candidate = load('snap-candidate.ts')
const cases = {
  alias(log) { const child={v:1}; return {a:child,b:child} },
  getterMutation(log) { const child={v:1}; return {a:child,b:Object.defineProperty({},'x',{enumerable:true,get(){log.push('get:b.x');child.v=2;return child}})} },
  getterThrow(log) { return {a:1,b:Object.defineProperty({},'x',{enumerable:true,get(){log.push('get:b.x');throw new RangeError('boom')}})} },
  getterOrder(log) { const a={};Object.defineProperty(a,'z',{enumerable:true,get(){log.push('get:z');return 1}});Object.defineProperty(a,'a',{enumerable:true,get(){log.push('get:a');return 2}});return a },
  cycle(log) { const a={};a.self=a;return a },
  mapMutation(log) { const target=new Map();const first={};Object.defineProperty(first,'x',{enumerable:true,get(){log.push('get:map.x');target.set('later',3);return 1}});target.set('first',first);target.set('second',2);return target },
  setMutation(log) { const target=new Set();const first={};Object.defineProperty(first,'x',{enumerable:true,get(){log.push('get:set.x');target.add('later');return 1}});target.add(first);target.add('second');return target },
  sparseInherited(log) { const a=[,2,]; Object.setPrototypeOf(a,Object.assign(Object.create(Array.prototype),{0:-0}));return a },
  typedSlice(log) { const b=new ArrayBuffer(6);new Uint8Array(b).set([1,2,3,4,5,6]);return new Uint16Array(b,2,2) },
  dataView(log) { const b=new ArrayBuffer(6);new Uint8Array(b).set([1,2,3,4,5,6]);return new DataView(b,1,3) },
  invalidDate(log) { return new Date(NaN) },
  nullProto(log) { return Object.assign(Object.create(null),{z:undefined,a:-0}) },
  symbolKeys(log) { return {[Symbol('x')]:1,a:2} },
  customProto(log) { return new (class C { constructor(){this.x=1} })() },
  unsupported(log) { return ()=>1 },
  unicode(log) { return { '\ud800':'x', key:'\u2028\u2029\n\t"\\' } },
}
const results={}
for(const [name,make] of Object.entries(cases)){
  function run(fn){const events=[];const input=make(events);let bytes=null,error=null;try{bytes=fn(input)}catch(e){error={name:e.name,message:e.message}}return {events,bytes,error}}
  const a=run(frozen),b=run(candidate)
  assert.deepEqual(b,a,name)
  results[name]={equal:true,error:a.error,eventCount:a.events.length,bytes:a.bytes?.length ?? null}
}
fs.writeFileSync(`${root}/ADVERSARIAL.json`,JSON.stringify({count:Object.keys(cases).length,results},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({count:Object.keys(cases).length,status:'PASS'}))
