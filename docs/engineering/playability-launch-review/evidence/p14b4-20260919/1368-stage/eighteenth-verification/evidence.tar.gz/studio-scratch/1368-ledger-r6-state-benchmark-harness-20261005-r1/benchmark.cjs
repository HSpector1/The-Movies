'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const vm = require('node:vm')
const v8 = require('node:v8')
const ROOT = '/Users/zacheryspector/studio-scratch'
const PKG = `${ROOT}/1368-ledger-r6-state-capture-proposal-20261005-r1`
const RUNS = `${ROOT}/1368-ledger-recorded-runs-r6-capture-r1`
const NODE = '/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node'
const EXPECT = {
  packageManifest: '3671e0b599c59def8a1e326750edd458689f31dd6bdefbbd067f176717cc4622',
  sourcePins: '533adb2793a2578fc635873da13dae1fb07ef681bdee2ac2dd8d56a83e8e6dbd',
  frozen: '24f961760749b22b9de901fc90708db464fb5fefffe75856729b467d96de3d15',
  r2: '7153dbbadc3fb8ccaf9fb31ecee24763f78464708df8536a2d160428f454baee',
  batched: '56336cbd815ecbde6f42ed7e8acf5c40ca649dd517591dfc6fd4c65b3ec8dfbe',
}
const IMPLEMENTATIONS = {
  frozen: `${ROOT}/1368-ledger-r5-snap-optimization-proposal-20261005-r1/snap-frozen.ts`,
  r2: `${ROOT}/1368-ledger-r5-snap-optimization-proposal-20261005-r2/snap-candidate.ts`,
  batched: `${ROOT}/1368-ledger-r5-batched-snap-proposal-20261005-r1/snap-candidate.ts`,
}
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
const read = p => { assert(fs.lstatSync(p).isFile(), `not a regular file: ${p}`); return fs.readFileSync(p) }
const fileSha = p => sha(read(p))
const checkHash = (p, expected) => assert.equal(fileSha(p), expected, `SHA256 mismatch: ${p}`)
const hex = value => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value)
function args(argv) {
  if (argv.length === 1 && argv[0] === '--help') return null
  const out = {}
  for (let i=0;i<argv.length;i+=2) {
    const key=argv[i]
    assert(['--result','--result-sha','--acceptance','--acceptance-sha','--output'].includes(key), `bad argument ${key}`)
    assert(i+1<argv.length && !(key in out), `missing/duplicate ${key}`)
    out[key]=argv[i+1]
  }
  for (const key of ['--result','--result-sha','--acceptance','--acceptance-sha','--output']) assert(out[key], `required ${key}`)
  assert(hex(out['--result-sha']) && hex(out['--acceptance-sha']), 'expected 64-digit SHA256')
  return out
}
function within(p, root) { const rel=path.relative(root,p); assert(rel && !rel.startsWith('..') && !path.isAbsolute(rel), `outside ${root}: ${p}`) }
function pinArtifact(result,p) {
  const record=result.artifacts[p]
  assert(record && hex(record.sha256) && Number.isSafeInteger(record.bytes), `missing artifact pin ${p}`)
  const bytes=read(p)
  assert.equal(bytes.length,record.bytes,`artifact bytes ${p}`)
  assert.equal(sha(bytes),record.sha256,`artifact SHA ${p}`)
  return bytes
}
function validate(input) {
  assert.equal(process.execPath,NODE,'run with formal Node 20 binary')
  assert.equal(process.version,'v20.20.2')
  checkHash(`${PKG}/MANIFEST.json`,EXPECT.packageManifest)
  checkHash(`${PKG}/arm/SOURCE-PINS.json`,EXPECT.sourcePins)
  const pkg=JSON.parse(read(`${PKG}/MANIFEST.json`))
  const source=JSON.parse(read(`${PKG}/arm/SOURCE-PINS.json`))
  assert.equal(Object.keys(source).length,197)
  assert.equal(pkg.sourcePinsSha256,EXPECT.sourcePins)
  for (const [rel,digest] of Object.entries(source)) {
    assert(!rel.startsWith('/') && !rel.split('/').includes('..') && hex(digest))
    checkHash(`${PKG}/arm/tree/${rel}`,digest)
  }
  for (const [name,p] of Object.entries(IMPLEMENTATIONS)) checkHash(p,EXPECT[name])
  const resultPath=path.resolve(input['--result'])
  within(resultPath,RUNS)
  assert.equal(path.basename(resultPath),'RESULT.json')
  checkHash(resultPath,input['--result-sha'])
  const runDir=path.dirname(resultPath)
  assert.equal(path.basename(runDir),'ABC-clean-p13a-r1')
  const acceptancePath=path.resolve(input['--acceptance'])
  within(acceptancePath,ROOT)
  checkHash(acceptancePath,input['--acceptance-sha'])
  const acceptance=JSON.parse(read(acceptancePath))
  assert.equal(acceptance.decision,'ACCEPT')
  assert.equal(acceptance.resultSha256,input['--result-sha'])
  const result=JSON.parse(read(resultPath))
  assert.equal(result.mode,'clean'); assert.equal(result.arm,'ABC'); assert.equal(result.seed,'p13a-core-causal-01')
  assert.equal(result.actualChildExit,0); assert.equal(result.recorderChildExit,0); assert.equal(result.timedOut,false)
  assert.equal(result.allGuardsExact,true); assert.equal(result.livePostflightExact,true)
  assert.deepEqual(result.reportingErrors,[])
  assert.equal(result.processGroup.cleanupVerified,true)
  assert.equal(result.processGroup.noSurvivors,true)
  assert.equal(result.processGroup.leaderReaped,true)
  assert.equal(result.pins.sourcePinsSha256,EXPECT.sourcePins)
  assert.equal(result.pins.runnerManifestSha256,EXPECT.packageManifest)
  const capture=result.captureStatus
  assert.equal(capture.usable,true); assert.equal(capture.present,true)
  assert.equal(capture.week,416); assert.equal(capture.seed,result.seed)
  assert.equal(capture.sourcePinsSha256,EXPECT.sourcePins)
  assert(hex(capture.sha256) && capture.bytes>0 && capture.bytes<=64*1024*1024)
  assert.equal(acceptance.stateSha256,capture.sha256)
  const statePath=`${runDir}/state.v8`,dataPath=`${runDir}/data.json`
  const stateBytes=pinArtifact(result,statePath)
  assert.equal(stateBytes.length,capture.bytes); assert.equal(sha(stateBytes),capture.sha256)
  const dataBytes=pinArtifact(result,dataPath)
  const data=JSON.parse(dataBytes)
  assert.equal(data.completed,true); assert.equal(data.sourcePostflight,true)
  assert.equal(data.arm,'ABC'); assert.equal(data.mode,'clean'); assert.equal(data.seed,result.seed)
  assert.equal(data.horizon,416); assert.equal(data.weekly.length,416)
  assert(hex(data.finalStateDigest))
  const state=v8.deserialize(stateBytes)
  const ts=require(`${PKG}/arm/tree/node_modules/typescript`)
  function load(name) {
    const source=read(IMPLEMENTATIONS[name]).toString('utf8')
    const js=ts.transpileModule(`${source}\nexports.snap=snap`,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText
    const context={exports:{},assert,Buffer,Map,Set,Date,Object,ArrayBuffer,JSON,String,Number}
    vm.runInNewContext(js,context)
    return context.exports.snap
  }
  const funcs=Object.fromEntries(Object.keys(IMPLEMENTATIONS).map(name=>[name,load(name)]))
  const frozen=funcs.frozen(state)
  assert.equal(sha(frozen),data.finalStateDigest,'frozen tagged digest differs from formal data.json')
  for (const [name,fn] of Object.entries(funcs)) assert.equal(fn(state),frozen,`${name} differs from frozen bytes`)
  return {state,funcs,identity:{resultSha256:input['--result-sha'],acceptanceSha256:input['--acceptance-sha'],stateSha256:capture.sha256,dataSha256:sha(dataBytes),sourcePinsSha256:EXPECT.sourcePins,frozenDigest:data.finalStateDigest,stateBytes:stateBytes.length}}
}
const median=a=>{const b=[...a].sort((x,y)=>x-y);return (b[3]+b[4])/2}
const p90=a=>{const b=[...a].sort((x,y)=>x-y);return b[Math.ceil(.9*b.length)-1]}
function measure(state,funcs) {
  const names=['frozen','r2','batched'], rounds=8
  const series=Object.fromEntries(names.map(n=>[n,[]]))
  const heapDeltas=Object.fromEntries(names.map(n=>[n,[]]))
    for(let i=0;i<3;i++) for(const n of names) funcs[n](state)
    for(let round=0;round<rounds;round++) {
      const order=round%2===0 ? names : [...names].reverse()
      for(const n of order) {
        const before=process.memoryUsage().heapUsed
        const start=process.hrtime.bigint()
        funcs[n](state)
        const ms=Number(process.hrtime.bigint()-start)/1e6
        const after=process.memoryUsage().heapUsed
        series[n].push(ms); heapDeltas[n].push(after-before)
      }
    }
  return {rounds,order:'alternating frozen/r2/batched and reverse',timing:Object.fromEntries(names.map(n=>[n,{ms:series[n],medianMs:median(series[n]),p90Ms:p90(series[n])}])),heapDeltaBytes:heapDeltas,gcEvents:'not measured: synchronous timing loop cannot reliably deliver PerformanceObserver GC callbacks without altering the rounds',warning:'Heap deltas are diagnostic only, not allocation accounting. Timings are isolated serializer calls on one captured clean state, not route acceptance.'}
}
function main() {
  const input=args(process.argv.slice(2))
  if(input===null){console.log('Usage: node benchmark.cjs --result PATH --result-sha SHA256 --acceptance PATH --acceptance-sha SHA256 --output NEW.json');return}
  const output=path.resolve(input['--output'])
  within(output,ROOT)
  assert(!fs.existsSync(output),'output must be new')
  const {state,funcs,identity}=validate(input)
  const report={status:'diagnostic only',node:process.version,v8:process.versions.v8,identity,measurement:measure(state,funcs)}
  fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'})
  console.log(JSON.stringify({output,sha256:fileSha(output),medians:Object.fromEntries(Object.entries(report.measurement.timing).map(([k,v])=>[k,v.medianMs]))}))
}
main()
