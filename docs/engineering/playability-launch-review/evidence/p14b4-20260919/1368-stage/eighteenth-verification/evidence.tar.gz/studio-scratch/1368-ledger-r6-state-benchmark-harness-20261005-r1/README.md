# R6 captured-state serializer benchmark harness r1

Prepared only; **not run against a fixture**. The R6 clean `state.v8` sidecar is not admitted merely because it exists. Do not invoke this harness until R6 types and clean have formally closed, the fixture's independent review has accepted its exact RESULT and sidecar, and an acceptance JSON has been written under scratch with this schema:

```json
{"decision":"ACCEPT","resultSha256":"<64 lowercase hex>","stateSha256":"<64 lowercase hex>"}
```

The reviewer must supply the file path and its full SHA256 separately; a benchmark operator must not create their own acceptance file. This is a diagnostic authorization gate, not a cryptographic signature. The operator supplies the accepted RESULT and acceptance hashes explicitly:

```sh
/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node benchmark.cjs \
  --result /Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r6-capture-r1/ABC-clean-p13a-r1/RESULT.json \
  --result-sha '<accepted full SHA256>' \
  --acceptance '/Users/zacheryspector/studio-scratch/<independent-review>/BENCHMARK-ACCEPTANCE.json' \
  --acceptance-sha '<accepted full SHA256>' \
  --output '/Users/zacheryspector/studio-scratch/<new-diagnostic-dir>/RESULT.json'
```

Before deserializing or timing, the harness checks the exact R6 package manifest and source-pin hashes; rehashes all 197 regular source files; rehashes the frozen, r2, and batched code files; checks RESULT SHA, mode/arm/seed/exit/timeout/guards/postflight/cleanup, its package/source pins, captureStatus, and RESULT artifact hashes/lengths for both `state.v8` and `data.json`. It verifies accepted fixture and acceptance SHA agreement, requires completed 416-week data, then runs frozen rawSnap on the deserialized state and requires its SHA256 to equal `data.json.finalStateDigest`. Every candidate must produce byte-identical tagged output before a timer starts.

It then warms each function and runs eight single-call rounds, alternating frozen/r2/batched and reverse order. It reports all raw times, median, nearest-rank p90, and heap-used deltas. Heap deltas are not allocation measurements; synchronous GC callbacks are intentionally not reported. Output is an exclusive scratch JSON file. This measures a captured **clean week-416 state only**; it cannot establish observed-mode completion, runtime bounds or route acceptance. The r2 and batched implementations already failed preliminary performance controls, and this harness does not promote them.

Local preparation checks: Node 20 `--check` and `--help` passed. No fixture input or benchmark result was produced in this preparation step. No heavy lane or tracked file was touched.
