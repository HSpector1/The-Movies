from pathlib import Path
from hashlib import sha256
import ast, json, difflib
S=Path('/Users/zacheryspector/studio-scratch')
R5=S/'1368-ledger-r5-profile-proposal-20261005-r1'
P=S/'1368-ledger-r7-exploratory-proposal-20261005-r1'
def digest(path): return sha256(path.read_bytes()).hexdigest()
probe='tests/1368-ledger-attribution.test.ts'
a=(R5/'arm/tree'/probe).read_text();b=(P/'arm/tree'/probe).read_text()
assert a.count('}, 300_000)')==1 and b==a.replace('}, 300_000)','}, 600_000)')
assert (P/'kit/files'/probe).read_text()==b
s=json.loads((P/'arm/SOURCE-PINS.json').read_text());s5=json.loads((R5/'arm/SOURCE-PINS.json').read_text())
assert len(s)==len(s5)==197 and {k for k in s if s[k]!=s5[k]}=={probe}
assert s[probe]==digest(P/'arm/tree'/probe)
assert sum(k.startswith('src/') for k in s)==188
for k in s:
 assert digest(P/'arm/tree'/k)==s[k]
 if k!=probe: assert s[k]==s5[k]
kit=json.loads((P/'kit/MANIFEST.json').read_text());k5=json.loads((R5/'kit/MANIFEST.json').read_text())
assert set(kit)==set(k5) and {k for k in kit if kit[k]!=k5[k]}=={'files/'+probe}
assert kit['files/'+probe]==s[probe]
for k,v in kit.items(): assert digest(P/'kit'/k)==v
assembly=json.loads((P/'arm/ASSEMBLY.json').read_text())
assert assembly['arm']=='ABC' and assembly['regularFiles']==197 and assembly['productionFiles']==188
assert assembly['status'].startswith('EXPLORATORY_NOT_ACCEPTANCE')
assert assembly['sourcePinsSha256']==digest(P/'arm/SOURCE-PINS.json')
assert assembly['kitManifestSha256']==digest(P/'kit/MANIFEST.json')
assert set(assembly['files'])==set(s)
for k,v in assembly['files'].items(): assert v['sha256']==s[k] and v['bytes']==(P/'arm/tree'/k).stat().st_size
assert assembly['originalPins']==json.loads((P/'kit/SOURCE-PINS.json').read_text())['ABC']
runner=(P/'runner/run.py').read_text();ast.parse(runner)
assert runner.count('EXPLORATORY_NOT_ACCEPTANCE')>=5
assert 'proc.wait(timeout=630)' in runner and '}, 600_000)' in b
assert "b['outerCapSeconds'] == 630 and b['probeTestSeconds'] == 600 and b['horizon'] == 416" in runner
assert "R5_CLEAN_SHA = '64c942ae10bd4648ee2269a4453980fb0ea77f8e75e289d00874c15aae5225a6'" in runner
assert 'r7 clean data differs byte-for-byte from admitted r5 clean' in runner
assert 'prior_types(Path(a.types_receipt)' in runner and 'prior_clean(Path(a.clean_receipt)' in runner
assert b.count('admit(input,')==a.count('admit(input,')==1
assert b.count('admit(answer,')==a.count('admit(answer,')==1
for token in ['phaseRows.push(', 'industryRows.push(', 'weekly.push(', 'snap(args)', 'snap(input)', 'snap(answer)', 'sourcePostflight', '64 * 1024 * 1024']:
 assert b.count(token)==a.count(token),token
for target,rel in [('PROBE.diff','arm/tree/'+probe),('RUNNER.diff','runner/run.py')]:
 x=(R5/rel).read_text().splitlines(True);y=(P/rel).read_text().splitlines(True)
 expected=''.join(difflib.unified_diff(x,y,fromfile='r5/'+rel,tofile='r7/'+rel))
 assert (P/target).read_text()==expected
m=json.loads((P/'MANIFEST.json').read_text())
assert m['status']=='EXPLORATORY_NOT_ACCEPTANCE; scratch proposal; no heavy run'
assert m['baseR5ManifestSha256']==digest(R5/'MANIFEST.json')
assert m['runnerSha256']==digest(P/'runner/run.py')
assert m['sourcePinsSha256']==digest(P/'arm/SOURCE-PINS.json')
assert m['kitManifestSha256']==digest(P/'kit/MANIFEST.json')
assert m['assemblySha256']==digest(P/'arm/ASSEMBLY.json')
assert len(m['files'])==218
for k,row in m['files'].items():
 q=P/k;assert q.is_file() and not q.is_symlink() and row=={'sha256':digest(q),'bytes':q.stat().st_size},k
print(json.dumps({'status':'PASS','productionFiles':188,'regularFiles':197,'changedArmFiles':[probe],'manifestMembers':len(m['files']),'probeOnlyTimeoutChange':True,'classification':'EXPLORATORY_NOT_ACCEPTANCE'}))
