from pathlib import Path
import hashlib,json,re
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');P=S/'1368-ledger-r7-exploratory-proposal-20261005-r2';RUNS=S/'1368-ledger-recorded-runs-r7-exploratory-r2';OUT=RUNS/'ABC-clean-p13a-r1';E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';STEM='1368-ledger-r7-exploratory-r2-abc-clean-p13a-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest='855eae61224f7211999795437fd19c9ae32f6f797548161b6e64a3373c4f8bc6';runner='c99a2d7c6ec23c2548974378e94a8afdacd631855daf27382682ab75102ddb10'
assert sha(P/'MANIFEST.json')==manifest and sha(P/'runner/run.py')==runner
m=read(P/'MANIFEST.json');assert len(m['files'])==219 and m['status']=='EXPLORATORY_NOT_ACCEPTANCE; scratch proposal; no heavy run'
for name,row in m['files'].items():
 f=P/name;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
rp=OUT/'RESULT.json';r=read(rp);b=read(OUT/'binding.json')
assert (r['mode'],r['arm'],r['seed'],r['classification'])==('clean','ABC','p13a-core-causal-01','EXPLORATORY_NOT_ACCEPTANCE')
assert (b['mode'],b['arm'],b['seed'],b['classification'],b['horizon'])==('clean','ABC','p13a-core-causal-01','EXPLORATORY_NOT_ACCEPTANCE',416)
assert b['manifestPin']==manifest and b['selfRunnerSha256']==runner and b['outerCapSeconds']==630 and b['probeTestSeconds']==600
assert b['typesReceipt']==str(RUNS/'ABC-types-source-r1/RESULT.json') and b['typesReceiptSha256']==sha(RUNS/'ABC-types-source-r1/RESULT.json')=='8280f61a97fb0c01813790ce73167b4f7f12f84e86181a60c362c9bc896ea2fc'
assert b['cleanReceipt'] is None and b['profilePath']==str(OUT/'profile.jsonl') and r['pins']==b['pins']
assert r['pins']['runnerManifestSha256']==manifest and r['pins']['selfRunnerSha256']==runner and r['pins']['regularFiles']==197
assert r['pins']['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and r['pins']['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and r['pins']['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
assert r['actualChildExit']==r['recorderChildExit']==0 and not r['timedOut'] and r['allGuardsExact'] and r['livePostflightExact'] and r['reportingErrors']==[]
g=r['processGroup'];assert g['cleanupVerified'] and g['noSurvivors'] and g['leaderReaped'] and not g['errors']
assert len(r['artifacts'])==15
for name,row in r['artifacts'].items():
 f=Path(name);assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
pre=read(E/(STEM+'-preflight.json'));record=read(E/(STEM+'.json'));post=read(E/(STEM+'-postflight.json'))
head=r['pins']['publicationHead'];assert pre['head']==record['sourceSha']==record['sourceShaAtEnd']==post['head']==head
assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact'] and record['exitCode']==post['exitCode']==0
assert record['command']==[record['command'][0],str(P/'runner/run.py'),'--child',str(OUT),sha(OUT/'binding.json')]
assert read(OUT/'CHILD.json')['actualChildExit']==0
meta=(S/'heavy-queue/1368-ledger-r7-exploratory-r2-clean-p13a-r1.log.meta').read_text();assert re.search(r'end, exit 0;',meta)
data=OUT/'data.json';base=S/'1368-ledger-recorded-runs-r5-profile-r1/ABC-clean-p13a-r1/data.json';assert data.is_file() and sha(base)=='18f1a6b913061f92a43f0ab432fff159714afadc0e781b62cadf6e923d01c108' and data.read_bytes()==base.read_bytes()
d=read(data);assert d['completed'] and d['sourcePostflight'] and (d['arm'],d['mode'],d['seed'],d['horizon'])==('ABC','clean','p13a-core-causal-01',416)
assert len(d['weekly'])==416 and [x['week'] for x in d['weekly']]==list(range(1,417))
progress=[json.loads(line) for line in (OUT/'progress.jsonl').read_text().splitlines()];profile=[json.loads(line) for line in (OUT/'profile.jsonl').read_text().splitlines()];weeks=list(range(52,417,52))
assert [x['week'] for x in progress]==[x['week'] for x in profile]==weeks
assert r['profileStatus']=={'expected':True,'present':True,'sha256':sha(OUT/'profile.jsonl'),'rows':weeks,'parseError':None}
prev={n:(0,0,0) for n in ['snap','admit','owners','windowFacts','changedCases']}
for row in profile:
 assert set(row['functions'])==set(prev)
 for n,v in row['functions'].items():
  assert set(v)=={'calls','inclusiveNs','exclusiveNs'} and type(v['calls'])==int and all(isinstance(v[k],str) and v[k].isdigit() for k in ['inclusiveNs','exclusiveNs'])
  cur=(v['calls'],int(v['inclusiveNs']),int(v['exclusiveNs']));assert cur[1]>=cur[2]>=0 and all(a>=b for a,b in zip(cur,prev[n]));prev[n]=cur
assert {n:profile[-1]['functions'][n]['calls'] for n in ['admit','owners','windowFacts','changedCases']}=={'admit':417,'owners':416,'windowFacts':0,'changedCases':416}
v=read(OUT/'vitest.json');assert v['numTotalTests']==v['numPassedTests']==1 and v['numFailedTests']==0
report={'decision':'ACCEPT','classification':'EXPLORATORY_NOT_ACCEPTANCE','cleanResultSha256':sha(rp),'typesResultSha256':sha(RUNS/'ABC-types-source-r1/RESULT.json'),'manifestSha256':manifest,'runnerSha256':runner,'packageMembersVerified':219,'artifactsVerified':15,'formalRecordSha256':sha(E/(STEM+'.json')),'formalPostflightSha256':sha(E/(STEM+'-postflight.json')),'actualChildExit':0,'recorderChildExit':0,'timedOut':False,'cleanupVerified':True,'dataSha256':sha(data),'r5DataByteExact':True,'weeks':416,'progressRows':8,'profileRows':8,'vitestPass':1,'observedGate':'ACCEPT only for separately labeled 600/630 exploratory route, subject to fresh launch guards and exact same-r7 types+clean receipt pins; never original bounded-route acceptance'}
out=Path(__file__).with_name('RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
