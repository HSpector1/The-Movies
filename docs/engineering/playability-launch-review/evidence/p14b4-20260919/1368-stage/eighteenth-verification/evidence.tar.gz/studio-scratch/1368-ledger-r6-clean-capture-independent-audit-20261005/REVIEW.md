# Independent R6 clean capture audit

Decision: **ACCEPT a usable clean p13a week-416 fixture** for the separately reviewed diagnostic benchmark. This accepts the captured state and exact clean-output identity, not observed-mode representativeness, an optimization, or gameplay acceptance.

The R6 clean RESULT hashes to `314c3e6423c5cb23757f78a8d440aa16245aff4ef72a548f28ea28eb1451a210`. It binds the frozen 216-member package manifest, runner, ABC source/seed and fresh R6 types RESULT. I rehashed all 216 package members and all 16 RESULT artifacts. Actual child, recorder and lane wrapper exited 0 without timeout; formal record SHA `1aacbdb678acf86452c97b1ff2f24a4840b435f82925ec9d7a300f3c6bada69d` and postflight SHA `308ccace1cd65f311cd03e01fa5fd8f529ad8661a50f3ef95ec77ef115ee890f` agree on fixed source and exact guards. Process-group cleanup is verified with no survivors.

`data.json` has all 416 ordered weekly rows, eight progress/profile marks and one Vitest PASS. Its bytes are identical to accepted R5 ABC clean p13a (`18f1a6b913061f92a43f0ab432fff159714afadc0e781b62cadf6e923d01c108`). The new `state.v8` is an exclusive 1,327,449-byte sidecar with SHA `7f335a5c2547715976057200cbcb6ef7f9c1b0d6176eaa356e5c7b13d6788edb`; `captureStatus` binds it to seed `p13a-core-causal-01`, week 416 and the R6 source pin, and marks it usable. An independent Node 20.20.2 deserialization and faithful `rawSnap` replay yielded the exact final-state digest `55724315fab31bc3615aa1edb647cf4a03e310a151af1f58fee97952c47d9bb8` and week 416. The source probe had separately required raw tagged-snapshot equality before writing the sidecar.

`ACCEPTANCE.json` is the minimal machine-readable gate for the benchmark harness, with the exact RESULT and state hashes. It applies only to this clean final state. The R5 observed run stopped at week 260; no measured equivalence to an observed-mode state is inferred.

`verify.py` and `replay.cjs` are the independent read-only verifiers; `RECEIPT.json` preserves the detailed result. This audit launched no heavy task and edited no tracked or frozen file.
