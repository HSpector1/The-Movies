const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const v8 = require('node:v8')
const ts = require('/Users/zacheryspector/The-Movies-headless-program/node_modules/typescript')
const p = __dirname + '/arm/tree/tests/1368-ledger-attribution.test.ts'
const source = fs.readFileSync(p, 'utf8')
const fragment = source.slice(source.indexOf('function rawSnap('), source.indexOf('\nfunction snap('))
const js = ts.transpileModule(fragment, { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText
const context = vm.createContext({ assert, Buffer, Map, Set, Date, ArrayBuffer, Uint8Array, Object, JSON })
vm.runInContext(js + '\nthis.rawSnap = rawSnap', context)
const snap = context.rawSnap
const good = { a: new Map([['x', new Set([1, 2])]]), b: new Date('2020-01-01T00:00:00.000Z'), c: new Uint8Array([1, 2]), d: [undefined, -0, 3n] }
assert.equal(snap(v8.deserialize(v8.serialize(good))), snap(good))
const bad = Object.create(null); bad.x = 1
assert.notEqual(snap(v8.deserialize(v8.serialize(bad))), snap(bad))
console.log(JSON.stringify({ commonRoundTrip: 'PASS', nullPrototypeMismatch: 'DETECTED', node: process.version }))
