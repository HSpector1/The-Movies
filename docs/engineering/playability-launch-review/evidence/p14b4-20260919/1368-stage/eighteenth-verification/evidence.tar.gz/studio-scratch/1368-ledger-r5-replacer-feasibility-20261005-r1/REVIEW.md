# Native JSON.stringify replacer feasibility

Decision: reject direct native replacer as a byte-exact rawSnap replacement. Node v20.20.2 command: `/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node counterexample.cjs`. Output is in `OUTPUT.txt`.

With property `b` inserted before `a`, `b`'s getter changes `a` from 1 to 2. Frozen rawSnap sorts keys first and reads `a=1`; native JSON.stringify reads `b` first and later reads `a=2`. Native JSON.stringify also calls an object's `toJSON` before its replacer, making the original object unavailable to the replacer. A Map becomes `{}` natively, while frozen rawSnap spreads entries before recursive visits. A wrapper or prewalk that fixes these differences must perform the original full visit/tagging logic itself; the final native stringify would be the existing second phase. No new implementation or heavy route is justified by a direct replacer.
