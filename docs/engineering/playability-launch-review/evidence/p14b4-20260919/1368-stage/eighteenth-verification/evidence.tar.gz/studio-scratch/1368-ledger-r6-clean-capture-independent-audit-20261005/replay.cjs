const assert = require('node:assert/strict')
const fs = require('node:fs')
const v8 = require('node:v8')
const crypto = require('node:crypto')
const path = process.argv[2]
const expected = process.argv[3]
assert.ok(path && expected)
function rawSnap(value) {
  const ancestors = new Set()
  const visit = (v) => {
    if (v === null) return ['null']
    if (v === undefined) return ['undefined']
    if (typeof v === 'number') return ['number', Object.is(v, -0) ? '-0' : String(v)]
    if (typeof v === 'string' || typeof v === 'boolean' || typeof v === 'bigint') return [typeof v, String(v)]
    assert.equal(typeof v, 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) return ['Map', [...v].map(([k, x]) => [visit(k), visit(x)])]
      if (v instanceof Set) return ['Set', [...v].map(visit)]
      if (v instanceof Date) return ['Date', v.toISOString()]
      if (ArrayBuffer.isView(v)) return [v.constructor.name, Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64')]
      if (v instanceof ArrayBuffer) return ['ArrayBuffer', Buffer.from(v).toString('base64')]
      if (Array.isArray(v)) return ['Array', Array.from({length: v.length}, (_, i) => i in v ? visit(v[i]) : ['hole'])]
      const proto = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      return [proto === null ? 'null-object' : 'object', Object.keys(v).sort().map(k => [k, visit(v[k])])]
    } finally { ancestors.delete(v) }
  }
  return JSON.stringify(visit(value))
}
const state = v8.deserialize(fs.readFileSync(path))
const snapshot = rawSnap(state)
const digest = crypto.createHash('sha256').update(snapshot).digest('hex')
assert.equal(digest, expected)
console.log(JSON.stringify({digest, week: state.market.tick, saveVersion: state.saveVersion, snapshotBytes: Buffer.byteLength(snapshot)}))
