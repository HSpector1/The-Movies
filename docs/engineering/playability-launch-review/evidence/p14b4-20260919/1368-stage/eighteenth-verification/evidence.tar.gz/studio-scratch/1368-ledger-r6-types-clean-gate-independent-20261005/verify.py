from pathlib import Path
import hashlib,json,re
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');P=S/'1368-ledger-r6-state-capture-proposal-20261005-r1';RUN=S/'1368-ledger-recorded-runs-r6-capture-r1/ABC-types-source-r1';E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';STEM='1368-ledger-r6-capture-r1-abc-types-source-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest='3671e0b599c59def8a1e326750edd458689f31dd6bdefbbd067f176717cc4622';runner='ca496e9d52c33318cb79a2a873b304d684fd05adbc781620245f7cea788769a5'
assert sha(P/'MANIFEST.json')==manifest and sha(P/'runner/run.py')==runner
m=read(P/'MANIFEST.json');assert len(m['files'])==216
for name,row in m['files'].items():
 f=P/name;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
assert m['runnerSha256']==runner and m['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and m['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and m['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
rp=RUN/'RESULT.json';assert sha(rp)=='765b0b8ef28573e367cce57d703891e1916eab82206a7ad4d908f26f7be4ba62'
r=read(rp);b=read(RUN/'binding.json')
assert (r['mode'],r['arm'],r['seed'])==('types','ABC',None)
assert r['actualChildExit']==r['recorderChildExit']==0 and not r['timedOut'] and r['allGuardsExact'] and r['livePostflightExact'] and r['reportingErrors']==[]
g=r['processGroup'];assert g['cleanupVerified'] and g['noSurvivors'] and g['leaderReaped'] and not g['errors']
assert r['command']==b['command'] and b['mode']=='types' and b['arm']=='ABC' and b['seed'] is None
assert b['manifestPin']==manifest and b['selfRunnerSha256']==runner and b['outerCapSeconds']==330 and b['probeTestSeconds']==300 and b['horizon']==416
assert b['profilePath'] is None and b['capturePath'] is None and r['pins']==b['pins']
assert r['pins']['runnerManifestSha256']==manifest and r['pins']['selfRunnerSha256']==runner
assert r['pins']['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and r['pins']['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and r['pins']['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
assert r['pins']['regularFiles']==197 and r['pins']['arm']=='ABC'
assert r['profileStatus']=={'expected':False,'present':False,'sha256':None,'rows':None,'parseError':None}
assert r['captureStatus']['expected'] is False and r['captureStatus']['present'] is False and r['captureStatus']['usable'] is False and r['captureStatus']['sha256'] is None
assert len(r['artifacts'])==11
for name,row in r['artifacts'].items():
 f=Path(name);assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
pre=read(E/(STEM+'-preflight.json'));record=read(E/(STEM+'.json'));post=read(E/(STEM+'-postflight.json'))
head=r['pins']['publicationHead'];assert pre['head']==record['sourceSha']==record['sourceShaAtEnd']==post['head']==head
assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact'] and record['exitCode']==post['exitCode']==0
assert record['command']==[record['command'][0],str(P/'runner/run.py'),'--child',str(RUN),sha(RUN/'binding.json')]
assert read(RUN/'CHILD.json')['actualChildExit']==0
meta=(S/'heavy-queue/1368-ledger-r6-capture-types-r1.log.meta').read_text();assert re.search(r'end, exit 0;',meta)
report={'decision':'ACCEPT','typesResultSha256':sha(rp),'packageManifestSha256':manifest,'runnerSha256':runner,'packageMembersVerified':216,'artifactsVerified':11,'formalRecordSha256':sha(E/(STEM+'.json')),'formalPostflightSha256':sha(E/(STEM+'-postflight.json')),'actualChildExit':0,'recorderChildExit':0,'timedOut':False,'allGuardsExact':True,'cleanupVerified':True,'profileAndCaptureAbsentAsExpected':True,'cleanCaptureGate':'ACCEPT subject to fresh HEAD/remote/lane/disk/power guards and exact types receipt binding'}
out=Path(__file__).with_name('RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
