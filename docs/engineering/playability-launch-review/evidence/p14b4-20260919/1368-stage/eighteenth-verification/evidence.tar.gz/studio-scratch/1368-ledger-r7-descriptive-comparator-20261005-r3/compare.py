from __future__ import annotations
import argparse, hashlib, json, os, re, stat
from pathlib import Path
S=Path('/Users/zacheryspector/studio-scratch')
R=Path('/Users/zacheryspector/The-Movies-headless-program')
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
P=S/'1368-ledger-r7-exploratory-proposal-20261005-r2'
RUNS=S/'1368-ledger-recorded-runs-r7-exploratory-r2'
OUT=S/'1368-ledger-r7-descriptive-comparator-20261005-r3'
MANIFEST_SHA='855eae61224f7211999795437fd19c9ae32f6f797548161b6e64a3373c4f8bc6'
RUNNER_SHA='c99a2d7c6ec23c2548974378e94a8afdacd631855daf27382682ab75102ddb10'
SOURCE_SHA='89048717737f6a792324f00418f416d5890a94adb131547c3dfcc9fc0ab3cc67'
CLASS='EXPLORATORY_NOT_ACCEPTANCE'
SEED='p13a-core-causal-01'
LEAVES={'types':'ABC-types-source-r1','clean':'ABC-clean-p13a-r1','observed':'ABC-observed-p13a-r1'}
CONTEXT={
 'r5Clean':(S/'1368-ledger-recorded-runs-r5-profile-r1/ABC-clean-p13a-r1/RESULT.json','ABC','clean'),
 'r4C0':(S/'1368-ledger-recorded-runs-r4-lowspace-r2/C0-clean-p13a-baseline-r1/RESULT.json','C0','clean'),
}
EXPECTED_FIELDS={'completed','arm','mode','seed','horizon','sourcePins','originalPins','weekly','phaseRows','industryRows','actualPins','pinComparisons','rows','finalStateDigest','finalMarket','finalEmployment','finalIndustryReceipts','finalRetirements','sourcePostflight'}
SHARED_FIELDS=EXPECTED_FIELDS-{'mode','phaseRows','industryRows'}

def sha(data: bytes)->str:return hashlib.sha256(data).hexdigest()
def digest(path:Path)->str:return sha(path.read_bytes())
def hex64(value):return isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value) is not None
def regular(path:Path):
    assert path.is_absolute() and path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode),path
    assert path.resolve()==path,path
    return path
def pinned(path:Path, expected:str):
    assert hex64(expected);regular(path);assert digest(path)==expected,path
    return path
def artifact(result:dict,path:Path,read_data:bool=False):
    pin=result['artifacts'].get(str(path));assert isinstance(pin,dict) and hex64(pin.get('sha256')) and isinstance(pin.get('bytes'),int),path
    regular(path)
    if not read_data: return pin
    data=path.read_bytes();assert len(data)==pin['bytes'] and sha(data)==pin['sha256'],path
    return data

def receipt(mode:str,expected_sha:str):
    path=RUNS/LEAVES[mode]/'RESULT.json';pinned(path,expected_sha)
    row=json.loads(path.read_text());assert row['classification']==CLASS and row['mode']==mode and row['arm']=='ABC'
    assert row['seed']==(None if mode=='types' else SEED)
    assert row['actualChildExit']==row['recorderChildExit']==0 and row['timedOut'] is False,mode
    assert row['allGuardsExact'] is True and row['livePostflightExact'] is True and row['reportingErrors']==[],mode
    group=row['processGroup'];assert group['cleanupVerified'] and group['noSurvivors'] and group['leaderReaped'],mode
    pins=row['pins'];assert pins['runnerManifestSha256']==MANIFEST_SHA and pins['selfRunnerSha256']==RUNNER_SHA and pins['sourcePinsSha256']==SOURCE_SHA and pins['regularFiles']==197,mode
    binding_path=path.parent/'binding.json';artifact(row,binding_path,True)
    binding=json.loads(binding_path.read_text())
    assert binding['classification']==CLASS and binding['mode']==mode and binding['arm']=='ABC' and binding['seed']==row['seed']
    assert binding['horizon']==416 and binding['probeTestSeconds']==600 and binding['outerCapSeconds']==630
    assert binding['manifestPin']==MANIFEST_SHA and binding['selfRunnerSha256']==RUNNER_SHA and binding['pins']==pins
    assert row['command']==binding['command'] and binding['publicationHead']==pins['publicationHead']
    if mode=='types': assert binding['typesReceipt'] is None and binding['cleanReceipt'] is None
    for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json']:
        formal=E/('1368-ledger-r7-exploratory-r2-abc-'+('types-source' if mode=='types' else mode+'-p13a')+'-r1'+suffix)
        artifact(row,formal,True)
    formal_base=E/('1368-ledger-r7-exploratory-r2-abc-'+('types-source' if mode=='types' else mode+'-p13a')+'-r1')
    post=json.loads(Path(str(formal_base)+'-postflight.json').read_text())
    formal_record=json.loads(Path(str(formal_base)+'.json').read_text())
    assert post['fixedSource'] and post['allGuardsExact'] and formal_record['fixedSource']
    assert post['exitCode']==formal_record['exitCode']==0 and post['head']==pins['publicationHead']
    assert formal_record['sourceSha']==formal_record['sourceShaAtEnd']==post['head']
    # Rehash every non-data artifact now; keep data unopened until all R7 receipts, bindings and independent audit pass.
    for artifact_name in row['artifacts']:
        q=Path(artifact_name)
        if q.name=='data.json' and q.parent==path.parent: continue
        artifact(row,q,True)
    if mode!='types': artifact(row,path.parent/'data.json',False)
    return path,row,binding

def short(value):
    encoded=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str)
    return {'bytes':len(encoded.encode()),'sha256':sha(encoded.encode()),'preview':encoded[:180]}
def first_diff(a,b,path='$'):
    if type(a)!=type(b): return {'path':path,'left':short(a),'right':short(b)}
    if isinstance(a,dict):
        for key in sorted(set(a)|set(b)):
            q=path+'.'+key
            if key not in a or key not in b:return {'path':q,'left':short(a.get(key,'<missing>')),'right':short(b.get(key,'<missing>'))}
            found=first_diff(a[key],b[key],q)
            if found:return found
        return None
    if isinstance(a,list):
        for i in range(min(len(a),len(b))):
            found=first_diff(a[i],b[i],f'{path}[{i}]')
            if found:return found
        if len(a)!=len(b):return {'path':path+'.length','left':short(len(a)),'right':short(len(b))}
        return None
    if a!=b:return {'path':path,'left':short(a),'right':short(b)}
    return None

def diagnostic_rows(rows):
    weeks=[x.get('week') for x in rows if isinstance(x,dict)]
    return {'count':len(rows),'firstWeek':weeks[0] if weeks else None,'lastWeek':weeks[-1] if weeks else None,'digest':sha(json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode())}

def context(name:str,expected_sha:str):
    path,arm,mode=CONTEXT[name];pinned(path,expected_sha);row=json.loads(path.read_text())
    assert row['mode']==mode and row['arm']==arm and row['seed']==SEED
    assert row['actualChildExit']==row['recorderChildExit']==0 and row['timedOut'] is False and row['allGuardsExact'] and row['livePostflightExact']
    group=row['processGroup'];assert group['cleanupVerified'] and group['noSurvivors'] and group['leaderReaped']
    raw=artifact(row,path.parent/'data.json',True);data=json.loads(raw)
    assert data['completed'] and data['sourcePostflight'] and data['horizon']==416 and len(data['weekly'])==416
    return {'resultSha256':expected_sha,'dataSha256':sha(raw),'arm':arm,'mode':mode,'actualPins':data['actualPins'],'rowCount':len(data['rows']),'finalStateDigest':data['finalStateDigest']}

def main():
    ap=argparse.ArgumentParser(description='Descriptive only; requires independent complete R7 observed audit')
    for name in ('types','clean','observed'):ap.add_argument('--'+name+'-result-sha',required=True)
    ap.add_argument('--observed-audit',required=True);ap.add_argument('--observed-audit-sha',required=True)
    ap.add_argument('--r5-clean-result-sha');ap.add_argument('--r4-c0-result-sha')
    ap.add_argument('--output',required=True)
    args=ap.parse_args()
    for name in ('types','clean','observed'):
        assert hex64(getattr(args,name+'_result_sha'))
    assert hex64(args.observed_audit_sha)
    output=Path(args.output);assert output.is_absolute() and output.is_relative_to(S) and not output.exists()
    # Package and source identity precede any data read.
    pinned(P/'MANIFEST.json',MANIFEST_SHA);pinned(P/'runner/run.py',RUNNER_SHA);pinned(P/'arm/SOURCE-PINS.json',SOURCE_SHA)
    package=json.loads((P/'MANIFEST.json').read_text())
    assert package['status'].startswith(CLASS) and package['runnerSha256']==RUNNER_SHA and package['sourcePinsSha256']==SOURCE_SHA
    assert len(package['files'])==219
    for rel,pin in package['files'].items():
        q=regular(P/rel);assert q.stat().st_size==pin['bytes'] and digest(q)==pin['sha256'],q
    source=json.loads((P/'arm/SOURCE-PINS.json').read_text());assert len(source)==197
    for rel,expected in source.items():
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts and hex64(expected)
        pinned(P/'arm/tree'/rel,expected)
    items={name:receipt(name,getattr(args,name+'_result_sha')) for name in ('types','clean','observed')}
    types_path,types_result,_=items['types'];clean_path,clean_result,clean_binding=items['clean'];observed_path,observed_result,observed_binding=items['observed']
    assert clean_binding['typesReceipt']==str(types_path) and clean_binding['typesReceiptSha256']==args.types_result_sha
    assert observed_binding['typesReceipt']==str(types_path) and observed_binding['typesReceiptSha256']==args.types_result_sha
    assert observed_binding['cleanReceipt']==str(clean_path) and observed_binding['cleanReceiptSha256']==args.clean_result_sha
    for key in ('sourcePinsSha256','assemblySha256','kitManifestSha256','inputPinsSha256','runnerManifestSha256','selfRunnerSha256','entrypoints','regularFiles'):
        assert types_result['pins'][key]==clean_result['pins'][key]==observed_result['pins'][key],key
    audit_path=Path(args.observed_audit);assert audit_path.is_absolute() and audit_path.is_relative_to(S)
    audit_dir=audit_path.parent
    assert audit_dir.parent==S and audit_dir.name.startswith('1368-ledger-r7-') and 'independent' in audit_dir.name
    pinned(audit_path,args.observed_audit_sha)
    audit=json.loads(audit_path.read_text())
    assert audit['decision']=='ACCEPT' and audit['resultSha256']==args.observed_result_sha
    assert audit.get('classification')==CLASS and audit.get('complete') is True
    for label,suffix in [('review','.md'),('receipt','.json')]:
        q=Path(audit[label+'Path']);assert q.parent==audit_dir and q.name.endswith(suffix)
        pinned(q,audit[label+'Sha256'])
    review=Path(audit['reviewPath']).read_text()
    assert args.observed_result_sha in review and 'EXPLORATORY_NOT_ACCEPTANCE' in review
    # Only now open R7 data artifacts.
    data={}
    for name in ('clean','observed'):
        path,row,_=items[name]
        raw=artifact(row,path.parent/'data.json',True);obj=json.loads(raw)
        assert set(obj)==EXPECTED_FIELDS and obj['completed'] is True and obj['sourcePostflight'] is True
        assert obj['arm']=='ABC' and obj['mode']==name and obj['seed']==SEED and obj['horizon']==416
        assert len(obj['weekly'])==416 and [x['week'] for x in obj['weekly']]==list(range(1,417))
        assert len(obj['rows'])==obj['actualPins']['rows']
        data[name]=(obj,sha(raw))
    clean,clean_sha=data['clean'];observed,observed_sha=data['observed']
    assert clean['sourcePins']==observed['sourcePins'] and clean['originalPins']==observed['originalPins']
    comparisons={}
    for field in sorted(SHARED_FIELDS):
        found=first_diff(clean[field],observed[field],'$.'+field)
        comparisons[field]={'equal':found is None,'firstDifference':found}
    weekly_diff=comparisons['weekly']['firstDifference']
    first_week=None
    if weekly_diff:
        match=re.search(r'\$\.weekly\[(\d+)\]',weekly_diff['path'])
        if match:first_week=int(match.group(1))+1
    optional={}
    if args.r5_clean_result_sha:optional['r5Clean']=context('r5Clean',args.r5_clean_result_sha)
    if args.r4_c0_result_sha:optional['r4C0']=context('r4C0',args.r4_c0_result_sha)
    report={'classification':'DESCRIPTIVE_ONLY_NOT_ACCEPTANCE','r7Classification':CLASS,
        'inputs':{'typesResultSha256':args.types_result_sha,'cleanResultSha256':args.clean_result_sha,'observedResultSha256':args.observed_result_sha,'observedAuditSha256':args.observed_audit_sha,'cleanDataSha256':clean_sha,'observedDataSha256':observed_sha},
        'sharedFieldComparisons':comparisons,'firstDifferingWeeklyWeek':first_week,
        'equalSharedFields':[key for key,v in comparisons.items() if v['equal']],
        'differingSharedFields':[key for key,v in comparisons.items() if not v['equal']],
        'observedOnlyDiagnostics':{'phaseRows':diagnostic_rows(observed['phaseRows']),'industryRows':diagnostic_rows(observed['industryRows'])},
        'cleanModeDiagnostics':{'phaseRows':diagnostic_rows(clean['phaseRows']),'industryRows':diagnostic_rows(clean['industryRows'])},
        'optionalContext':optional,'interpretation':'Field differences are descriptive under separately extended 600/630 diagnostic bounds; no causal, unchanged-comparator, gameplay or original-route acceptance claim.'}
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps({'output':str(output),'sha256':digest(output),'firstDifferingWeeklyWeek':first_week,'differingSharedFields':report['differingSharedFields']}))
if __name__=='__main__':main()
