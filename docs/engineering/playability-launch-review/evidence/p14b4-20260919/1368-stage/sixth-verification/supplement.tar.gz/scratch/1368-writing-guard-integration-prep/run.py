from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time
r=Path('/Users/zacheryspector/The-Movies-headless-program');s=Path('/Users/zacheryspector/studio-scratch');p=s/'1368-save46-swept-proposal-r4';t=p/'tree';e=r/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';node=Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin');prep=s/'1368-writing-guard-integration-prep'
sha=lambda b:hashlib.sha256(b).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['types','backward','p15','current','helper-consumers','ui','writing']);parser.add_argument('--head',required=True);parser.add_argument('--run-id',required=True);parser.add_argument('--child');a=parser.parse_args()
import re
assert re.fullmatch(r'[0-9a-f]{40}',a.head);assert re.fullmatch(r'[a-z0-9][a-z0-9-]{0,39}',a.run_id)
base=a.head;stem='1368-swept-r4-'+a.mode+'-'+a.run_id;out=prep/('run-'+a.mode+'-'+a.run_id)
KIT_PINS={'SELECTIONS.json': 'dd39479ff422a8e63bbaf2c1516689218e6960ea6d99e9fba13962ef3dd2430c', 'tsconfig.producers.json': '24eaf19d3c7decbac18b573f8e627305a2e9001aeadf55ad26c40a3b2622a0ea', 'FIXTURE-PINS.json': '618cdf309eeff5c17dac32d18a4a278363da59fd10d4e800b18aacdc1e8c44a9'}
selections=json.loads((prep/'SELECTIONS.json').read_text())['selections']
assert sha((p/'SOURCE-PINS.json').read_bytes())=='ca96ecb42e78ddf4442e17804bd15a80d70e5808a5e78ed42f43b4f06a0320d2'
assert sha((p/'ASSEMBLY.json').read_bytes())=='604e0a722f5248ef7003ba5dc9216462564d6dad29ba86519612198fb53b94f5'

source=json.loads((p/'SOURCE-PINS.json').read_text());extra=json.loads((prep/'FIXTURE-PINS.json').read_text())
env=dict(os.environ,PATH=str(node)+':'+str(r/'.venv/bin')+':'+os.environ['PATH'],GIT_OPTIONAL_LOCKS='0',P1368_ACCEPTED45_ROOT=str(r/'tests/fixtures/p14/genuine-v45-recovery-witnesses-1368'),P1368_ACCEPTED45_MANIFEST_SHA256='11ad61be481a8bec170f40425cfcfe7fcb24596418d30b6c8bf27895e93c3ba5',P1368_ACCEPTED26_ROOT=str(r/'tests/fixtures/p13b/genuine-v26-period52-1368'),P1368_ACCEPTED26_MANIFEST_SHA256='8e40e51bb360ba6ff6c0d641a03e90aa8ed6f73f8c0b232a9a4b5861af358db4',RIVAL_WRITING_CAPTURE_DIR=str(r/'tests/fixtures/p14/genuine-v46-rival-writing-pre414-1368'),RIVAL_WRITING_MANIFEST_SHA256='d097bbf131c1dc495b881d73e96994953b2f6a0ef50f88bd3b043f263024f205')
def verify():
 for name,expected in KIT_PINS.items():assert sha((prep/name).read_bytes())==expected,'kit drift '+name
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,env=env,text=True).strip()==base
 for n,h in source.items():assert sha((t/n).read_bytes())==h,'candidate drift '+n
 for n,h in extra.items():assert sha((r/n).read_bytes())==h,'fixture drift '+n
 assert subprocess.check_output(['node','--version'],env=env,text=True).strip()=='v20.20.2'
 # Reject new source files in the frozen snapshot; normal runtime caches/output stay outside this source scope.
 unknown=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','src','tests','bridge','ui','generated','scripts'],cwd=t,env=env,text=True).splitlines()
 assert not unknown,unknown
 actual=[]
 for directory,dirs,files in os.walk(t,followlinks=False):
  current=Path(directory)
  dirs[:]=[n for n in dirs if not (current/n).is_symlink() and not (current==t and n in ['.git','dist','.tmp'])]
  for n in files:
   file=current/n
   if not file.is_symlink():actual.append(file.relative_to(t).as_posix())
 assert sorted(actual)==sorted(source),'exact consumed regular-file inventory changed'
 scratchHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,env=env)
 scratchStage=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=t,env=env)
 scratchIndex=(t/'.git/index').read_bytes()
 return {'scratchHead':scratchHead.decode().strip(),'scratchIndexSha256':sha(scratchIndex),'scratchStageSha256':sha(scratchStage),'regularInventorySha256':sha(json.dumps(sorted(actual)).encode()),'sourcePinsSha256':sha((p/'SOURCE-PINS.json').read_bytes()),'assemblySha256':sha((p/'ASSEMBLY.json').read_bytes()),'runnerSha256':sha(Path(__file__).read_bytes()),'selectionSha256':sha((prep/'SELECTIONS.json').read_bytes()),'producerConfigSha256':sha((prep/'tsconfig.producers.json').read_bytes()),'fixturePinsSha256':sha((prep/'FIXTURE-PINS.json').read_bytes()),'nodeSha256':sha((node/'node').read_bytes()),'vitestEntrySha256':sha((t/'node_modules/vitest/vitest.mjs').read_bytes()),'tscEntrySha256':sha((t/'node_modules/typescript/bin/tsc').read_bytes())}
def exclusive(path):
 assert not os.path.lexists(path),str(path)
 assert not any(x.is_symlink() for x in [path,*path.parents]),str(path)
if a.child:
 binding=out/'binding.json';assert sha(binding.read_bytes())==a.child;bound=json.loads(binding.read_text());assert verify()==bound['pins']
 commands=[]
 if a.mode=='types':
  for name,args in [('root',['node','node_modules/typescript/bin/tsc','--noEmit']),('ui',['node','node_modules/typescript/bin/tsc','-p','ui/tsconfig.json','--noEmit']),('bridge',['node','node_modules/typescript/bin/tsc','-p','tsconfig.bridge.json']),('contract',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract.ts','--check']),('contract-fixtures',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract-fixtures.ts','--check'])]:commands.append((name,args))
  commands.append(('producers',['node','node_modules/typescript/bin/tsc','--noEmit','-p',str(prep/'tsconfig.producers.json')]))
 else:
  args=['node','node_modules/vitest/vitest.mjs','run']
  args+=['--project','ui' if a.mode=='ui' else 'core']
  assert selections[a.mode];args+=selections[a.mode]
  args+=['--reporter=verbose','--reporter=json','--outputFile.json='+str(out/'vitest.json')];commands=[(a.mode,args)]
 results=[]
 for name,cmd in commands:
  start=time.monotonic()
  with (out/(name+'.txt')).open('x') as f:c=subprocess.run(cmd,cwd=t,env=env,stdout=f,stderr=subprocess.STDOUT)
  row={'name':name,'command':cmd,'actualChildExit':c.returncode,'seconds':time.monotonic()-start,'rawSha256':sha((out/(name+'.txt')).read_bytes())};results.append(row);print(json.dumps(row),flush=True)
 assert verify()==bound['pins'];assert sha(binding.read_bytes())==a.child
 result={'mode':a.mode,'baseHead':base,'sourceFiles':len(source),'allGuardsExact':True,'bindingSha256':a.child,'results':results}
 if (out/'vitest.json').exists():
  result['vitestJsonSha256']=sha((out/'vitest.json').read_bytes())
  data=json.loads((out/'vitest.json').read_text())
  actual=sorted(str(Path(row['name']).relative_to(t)) for row in data['testResults'])
  result['actualSelectedFiles']=actual;result['exactFileSelection']=actual==sorted(selections[a.mode])
  assert result['exactFileSelection'],actual
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');sys.exit(0 if all(x['actualChildExit']==0 for x in results) else 1)
exclusive(out);out.mkdir();pins=verify();assert shutil.disk_usage(r).free>=5*1024**3
for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json']:exclusive(e/(stem+suffix))
(out/'binding.json').write_text(json.dumps({'baseHead':base,'pins':pins,'sourceFiles':len(source),'fixturePins':extra,'selectedFiles':selections.get(a.mode,[]),'scope':'approved swept originals plus writing guard regression tests; not broad acceptance','environment':{k:v for k,v in env.items() if k.startswith('P1368_') or k.startswith('RIVAL_WRITING_') or k=='PATH'}},indent=2)+'\n')
with (out/'power.txt').open('x') as f:subprocess.run(['pmset','-g','batt'],stdout=f,check=True)
subprocess.Popen(['caffeinate','-is','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
guard=[sys.executable,str(e/'run-bounded-source-guards.py')];subprocess.run([*guard,'pre',stem,'0'],cwd=r,env=env,check=True)
try:recordExit=subprocess.run(['node',str(e/'run-bounded-source-c2.mjs'),stem,sys.executable,str(Path(__file__).resolve()),a.mode,'--head',base,'--run-id',a.run_id,'--child',sha((out/'binding.json').read_bytes())],cwd=r,env=env).returncode
finally:postExit=subprocess.run([*guard,'post',stem],cwd=r,env=env).returncode
assert recordExit==postExit==0
record=json.loads((e/(stem+'.json')).read_text());post=json.loads((e/(stem+'-postflight.json')).read_text());assert record['fixedSource'] and post['allGuardsExact'] and record['exitCode']==post['exitCode'];assert verify()==pins
print(json.dumps({'mode':a.mode,'actualChildExit':record['exitCode'],'fixedSource':True,'postflight':True}));sys.exit(record['exitCode'] if isinstance(record['exitCode'],int) and record['exitCode']>=0 else 1)
