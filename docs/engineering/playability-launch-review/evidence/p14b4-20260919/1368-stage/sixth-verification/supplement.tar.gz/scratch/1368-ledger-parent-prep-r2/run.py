"""Recorded strict types or exact two-arm ledger diagnostic modes; no assembly or policy changes."""
import argparse, hashlib, importlib.util, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
R = Path('/Users/zacheryspector/The-Movies-headless-program')
S = Path('/Users/zacheryspector/studio-scratch')
P = S / '1368-ledger-parent-prep-r2'
ARMS = S / '1368-ledger-arms-02'
KIT = P / 'kit'
RUNS = S / '1368-ledger-recorded-runs-r2'
E = R / 'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
NODE = Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
LEGACY = S / '1368-recovery-legacy-prep/run-recovery.py'
BRANCH = 'refs/heads/wip/headless-program-20260916-ts'
SCOPE = ['src', 'bridge', 'tests', 'ui', 'generated', 'scripts', 'package.json', 'package-lock.json', 'vitest.config.ts', 'vitest.workspace.ts', 'tsconfig.json', 'tsconfig.bridge.json', 'tsconfig.src.json', ':(exclude)tests/fixtures', ':(exclude)ui/e2e', ':(exclude)ui/public']
FIXED = {
    Path('/Users/zacheryspector/studio-scratch/1368-rival-writing-guard-prep/MANIFEST.json'): '727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-01/ASSEMBLY.json'): '05cba942c8cb0d2ce8837f5b5020f7714b73a8a0db0ff8f4f72b7fc19381e1bd',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-02/ASSEMBLY.json'): '98005b47507551d2f9c0c261d74128e76fe3e6898dfa7ab0535f132c6c52d474',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-02/C0/ASSEMBLY.json'): '4268653cc50a024e179fb02195db4b3a9af5c8df4f6878766bfb84073f2bfc3f',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-02/C0/SOURCE-PINS.json'): 'c0b04263da3a67cc788b38184900633d05216961ab3c8a4ac54417232e1b9102',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-02/ABC/ASSEMBLY.json'): '7d835a634c203bc95ab710e1841bb025f75a7b19afbf7bd143e4bc4d24f4425e',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-02/ABC/SOURCE-PINS.json'): '1e121e86b91534f1f73df074fc11292cc70bd2a7cadb4f30843901f26278cdcc',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r2/kit/MANIFEST.json'): '6f9a6625ad20d60fc40fb12bb0062e6fd12e1df07676234b93be91fb7293ec65',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r2/kit/SOURCE-PINS.json'): 'a2ba20f3ac5009f11c938ec55b7cb21371f1f8d3b74b7febe0f344e95f93a61a',
    Path('/Users/zacheryspector/studio-scratch/1368-recovery-legacy-prep/run-recovery.py'): '7568362dbfdc07cf63d768dda14edd4e754f89b3aeae14ebf0ef335d8832be02',
    Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919/run-bounded-source-guards.py'): '1a1e144c25dd36320c64237d5b58f19d848eb85171fa777e5772c2c3fff1a20e',
    Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919/run-bounded-source-c2.mjs'): 'ae167b103ddaa714268cd63e163daa4966b0c3b8f07bfa3e9bd8f0c7d07751a2',
}
SEEDS = {"p13a-core-causal-01": "p13a", "p13-public-commercial-adoption": "adoption"}


def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def safe(path):
    assert path.is_absolute() and str(path) == os.path.abspath(path)
    for part in [path, *path.parents]: assert not part.is_symlink(), str(part)
def exclusive(path):
    safe(path); assert not os.path.lexists(path), 'existing output: ' + str(path)
def write(path, obj):
    with path.open('x') as f: json.dump(obj, f, indent=2); f.write('\n')
def environment():
    return dict(os.environ, PATH=str(NODE.parent) + ':' + str(R / '.venv/bin') + ':' + os.environ.get('PATH', ''), GIT_OPTIONAL_LOCKS='0')
def git(*args): return subprocess.check_output(['git', *args], cwd=R, env=environment())
def verify(head, manifest_pin, arm):
    assert arm in ["C0", "ABC"]
    ARM = ARMS / arm; T = ARM / "tree"
    assert re.fullmatch('[0-9a-f]{40}', head)
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert git('symbolic-ref', 'HEAD').decode().strip() == BRANCH
    assert git('diff', '--name-only', 'HEAD', '--', *SCOPE) == b'', 'dirty live source'
    assert git('ls-files', '--others', '--exclude-standard', '--', *SCOPE) == b'', 'untracked live source'
    assert re.fullmatch('[0-9a-f]{64}', manifest_pin)
    safe(P / 'MANIFEST.json'); assert sha(P / 'MANIFEST.json') == manifest_pin
    for name, row in json.loads((P / 'MANIFEST.json').read_text())['files'].items():
        path = P / name; safe(path); assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
    for path, pin in FIXED.items(): safe(path); assert sha(path) == pin, str(path)
    source = json.loads((ARM / 'SOURCE-PINS.json').read_text()); assert len(source) == 197
    kit = json.loads((KIT / 'MANIFEST.json').read_text())
    for name, row in kit.items():
        path = KIT / name; safe(path); assert sha(path) == row
    kit_names = ['tests/1368-ledger-attribution.test.ts', 'tests/1368-ledger-original.ts', 'tsconfig.1368-ledger.json', 'vitest.1368-ledger.config.ts', 'vitest.1368-ledger.workspace.ts']
    assert sorted(n.removeprefix('files/') for n in kit if n.startswith('files/')) == sorted(kit_names)
    for name in kit_names: assert source[name] == kit['files/' + name]
    inputs = json.loads((KIT / 'SOURCE-PINS.json').read_text())[arm]
    assert len(inputs) == 189
    for name, pin in inputs.items(): assert source[name] == pin
    assembly = json.loads((ARM / 'ASSEMBLY.json').read_text())
    assert assembly['arm'] == arm and assembly['productionFiles'] == 188 and assembly['regularFiles'] == 197
    assert set(assembly['files']) == set(source)
    assert assembly['originalPins'] == inputs
    assert assembly['sourcePinsSha256'] == sha(ARM / 'SOURCE-PINS.json')
    assert assembly['kitManifestSha256'] == sha(KIT / 'MANIFEST.json')
    for name, row in assembly['files'].items(): assert source[name] == row['sha256'] and (T / name).stat().st_size == row['bytes']
    actual = []
    safe(T)
    for folder, dirs, files in os.walk(T, followlinks=False):
        root = Path(folder)
        if root == T:
            assert 'node_modules' in dirs; dirs.remove('node_modules')
        for name in dirs: safe(root / name)
        for name in files:
            path = root / name; safe(path); assert path.is_file() and path.stat().st_nlink == 1
            rel = path.relative_to(T).as_posix(); assert rel in source and sha(path) == source[rel], rel
            actual.append(rel)
    assert sorted(actual) == sorted(source)
    assert (T / 'node_modules').is_symlink() and (T / 'node_modules').resolve() == (R / 'node_modules').resolve()
    assert subprocess.check_output([str(NODE), '--version'], text=True).strip() == 'v20.20.2'
    entries = [NODE, T / 'node_modules/typescript/bin/tsc', T / 'node_modules/vitest/vitest.mjs']
    index = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    return {'arm': arm, 'publicationHead': head, 'publicationIndexSha256': sha(index), 'publicationStageSha256': digest(git('ls-files', '--stage', '-z')),
            'boundedDiffSha256': digest(git('diff', 'HEAD', '--', *SCOPE)), 'sourcePinsSha256': sha(ARM / 'SOURCE-PINS.json'),
            'assemblySha256': sha(ARM / 'ASSEMBLY.json'), 'kitManifestSha256': sha(KIT / 'MANIFEST.json'),
            'inputPinsSha256': sha(KIT / 'SOURCE-PINS.json'), 'runnerManifestSha256': manifest_pin,
            'entrypoints': {str(path): sha(path) for path in entries}, 'regularFiles': 197}
def command_for(mode, out):
    if mode == 'types': return [str(NODE), 'node_modules/typescript/bin/tsc', '--noEmit', '-p', 'tsconfig.1368-ledger.json']
    assert mode in ['clean', 'observed']
    return [str(NODE), 'node_modules/vitest/vitest.mjs', 'run', '--workspace', 'vitest.1368-ledger.workspace.ts', '--config', 'vitest.1368-ledger.config.ts', '--maxWorkers', '1', '--minWorkers', '1', '--no-file-parallelism', '--reporter=verbose', '--reporter=json', '--outputFile.json=' + str(out / 'vitest.json')]

def prior_types(path, pin, current):
    safe(path); assert sha(path) == pin
    receipt = json.loads(path.read_text())
    assert receipt['command'] == command_for('types', path.parent)
    assert receipt['mode'] == 'types' and receipt['allGuardsExact'] and receipt['actualChildExit'] == 0 and receipt['recorderChildExit'] == 0 and not receipt['timedOut']
    assert receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped']
    # Documentation publication may advance between modes; consumed source and kit must not.
    for name in ['arm', 'sourcePinsSha256', 'assemblySha256', 'kitManifestSha256', 'inputPinsSha256', 'runnerManifestSha256', 'entrypoints', 'regularFiles']:
        assert receipt['pins'][name] == current[name], 'types source differs: ' + name
    for name, row in receipt['artifacts'].items():
        f = Path(name); safe(f); assert sha(f) == row['sha256'] and f.stat().st_size == row['bytes']
def child(out, binding_pin):
    safe(out / 'binding.json'); assert sha(out / 'binding.json') == binding_pin
    b = json.loads((out / 'binding.json').read_text())
    assert b['arm'] in ['C0', 'ABC']; T = ARMS / b['arm'] / 'tree'
    assert b['mode'] in ['types', 'clean', 'observed']
    assert b['mode'] != 'observed' or b['arm'] == 'ABC'
    assert b['seed'] is None if b['mode'] == 'types' else b['seed'] in SEEDS
    assert b['outerCapSeconds'] == 330 and b['probeTestSeconds'] == 300 and b['horizon'] == 416
    assert b['command'] == command_for(b['mode'], out)
    assert verify(b['publicationHead'], b['manifestPin'], b['arm']) == b['pins']
    if b['mode'] in ['clean', 'observed']: prior_types(Path(b['typesReceipt']), b['typesReceiptSha256'], b['pins'])
    # Import only after verifying the reviewed helper's exact SHA; __main__ is not run.
    spec = importlib.util.spec_from_file_location('reviewed_cleanup', LEGACY); helper = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode; sys.dont_write_bytecode = True
    try: spec.loader.exec_module(helper)
    finally: sys.dont_write_bytecode = old
    env = environment(); env.update(LEDGER_ARM=b['arm'], LEDGER_MODE=b['mode'], LEDGER_SEED=b['seed'] or '', LEDGER_OUTPUT=str(out / 'data.json'))
    start = time.monotonic(); timed_out = False
    with (out / 'stdout.txt').open('x') as stdout, (out / 'stderr.txt').open('x') as stderr:
        proc = subprocess.Popen(b['command'], cwd=T, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try: proc.wait(timeout=330)
        except subprocess.TimeoutExpired: timed_out = True
        finally: code, group = helper.cleanup_owned_group(proc)
    exact = verify(b['publicationHead'], b['manifestPin'], b['arm']) == b['pins'] and sha(out / 'binding.json') == binding_pin
    write(out / 'CHILD.json', {'actualChildExit': code, 'timedOut': timed_out, 'processGroup': group, 'elapsedSeconds': time.monotonic() - start, 'allGuardsExact': exact, 'command': b['command']})
    assert exact
    if timed_out: return 124
    if not group['noSurvivors'] or not group['leaderReaped']: return 1
    return code if code is not None and code >= 0 else 1

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=['types', 'clean', 'observed']); ap.add_argument('--arm', required=True, choices=['C0', 'ABC']); ap.add_argument('--seed', choices=list(SEEDS)); ap.add_argument('--head', required=True)
    ap.add_argument('--manifest-sha256', required=True); ap.add_argument('--leaf', required=True)
    ap.add_argument('--types-receipt'); ap.add_argument('--types-receipt-sha256'); a = ap.parse_args()
    assert Path(__file__).resolve() == P / 'run.py'
    assert re.fullmatch('[a-z0-9-]+', a.leaf)
    assert a.mode != 'observed' or a.arm == 'ABC'
    assert a.seed is None if a.mode == 'types' else a.seed in SEEDS
    tag = a.arm + '-' + a.mode + '-' + (SEEDS[a.seed] if a.seed else 'source') + '-' + a.leaf
    out = RUNS / tag; exclusive(out)
    pins = verify(a.head, a.manifest_sha256, a.arm)
    assert git('ls-remote', '--exit-code', 'origin', BRANCH).decode().split() == [a.head, BRANCH]
    if a.mode in ['clean', 'observed']:
        assert a.types_receipt and a.types_receipt_sha256
        prior_types(Path(a.types_receipt), a.types_receipt_sha256, pins)
    else: assert not a.types_receipt and not a.types_receipt_sha256
    assert shutil.disk_usage(R).free >= 5 * 1024**3
    stem = '1368-ledger-r2-' + tag.lower()
    for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']: exclusive(E / (stem + suffix))
    safe(RUNS); RUNS.mkdir(exist_ok=True); out.mkdir()
    command = command_for(a.mode, out)
    binding = {'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'horizon': 416, 'publicationHead': a.head, 'sourceStatus': 'C0 is historical 2eaa697e; ABC is the reviewed Save46 candidate plus only the approved prospective-writing guard. Publication HEAD is coordinator provenance only', 'pins': pins, 'manifestPin': a.manifest_sha256, 'command': command, 'typesReceipt': a.types_receipt, 'typesReceiptSha256': a.types_receipt_sha256, 'outerCapSeconds': 330, 'probeTestSeconds': 300}
    write(out / 'binding.json', binding)
    with (out / 'power.txt').open('x') as f: subprocess.run(['pmset', '-g', 'batt'], stdout=f, check=True)
    subprocess.Popen(['caffeinate', '-is', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    guard = [sys.executable, str(E / 'run-bounded-source-guards.py')]
    subprocess.run([*guard, 'pre', stem, '0'], cwd=R, env=environment(), check=True)
    try:
        recorder = subprocess.run([str(NODE), str(E / 'run-bounded-source-c2.mjs'), stem, sys.executable, str(P / 'run.py'), '--child', str(out), sha(out / 'binding.json')], cwd=R, env=environment()).returncode
    finally: post_code = subprocess.run([*guard, 'post', stem], cwd=R, env=environment()).returncode
    record = json.loads((E / (stem + '.json')).read_text()); post = json.loads((E / (stem + '-postflight.json')).read_text())
    assert recorder == post_code == 0
    assert record['command'] == [sys.executable, str(P / 'run.py'), '--child', str(out), sha(out / 'binding.json')]
    assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
    assert record['sourceSha'] == record['sourceShaAtEnd'] == post['head'] == a.head
    assert record['exitCode'] == post['exitCode']
    assert verify(a.head, a.manifest_sha256, a.arm) == pins
    child_result = json.loads((out / 'CHILD.json').read_text()); assert child_result['allGuardsExact']
    assert child_result['command'] == command
    code = child_result['actualChildExit']; group = child_result['processGroup']
    expected_exit = 124 if child_result['timedOut'] else (1 if not group['noSurvivors'] or not group['leaderReaped'] else (code if isinstance(code, int) and code >= 0 else 1))
    assert record['exitCode'] == post['exitCode'] == expected_exit, 'Node/cleanup/recorder exit mismatch'
    if a.mode != 'types' and expected_exit == 0:
        data = json.loads((out / 'data.json').read_text())
        assert data['completed'] is True and data['sourcePostflight'] is True
        assert (data['arm'], data['mode'], data['seed'], data['horizon']) == (a.arm, a.mode, a.seed, 416)
        assert data['sourcePins'] == json.loads((KIT / 'SOURCE-PINS.json').read_text())[a.arm]
        report = json.loads((out / 'vitest.json').read_text())
        assert report['numTotalTests'] == report['numPassedTests'] == 1 and report['numFailedTests'] == 0
    paths = [f for f in out.rglob('*') if f.is_file()]
    for f in paths: safe(f)
    paths += [E / (stem + suffix) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']]
    artifacts = {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in sorted(paths)}
    write(out / 'RESULT.json', {**child_result, 'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'pins': pins, 'recorderChildExit': record['exitCode'], 'allGuardsExact': True, 'artifacts': artifacts, 'interpretation': 'Actual Node exit retained separately from recorder/wrapper status; diagnostic completion is not gameplay acceptance.'})
    print(json.dumps({'receipt': str(out / 'RESULT.json'), 'receiptSha256': sha(out / 'RESULT.json'), 'actualChildExit': child_result['actualChildExit'], 'timedOut': child_result['timedOut']}))
    return record['exitCode'] if isinstance(record['exitCode'], int) and record['exitCode'] >= 0 else 1
if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '--child': sys.exit(child(Path(sys.argv[2]), sys.argv[3]))
    sys.exit(main())
