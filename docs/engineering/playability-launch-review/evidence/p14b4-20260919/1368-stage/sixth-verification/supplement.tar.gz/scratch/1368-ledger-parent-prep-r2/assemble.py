"""Exclusive APFS clones of the admitted ledger arms, with one approved ABC source amendment."""
import argparse, hashlib, json, os, shutil, subprocess
from pathlib import Path
S = Path('/Users/zacheryspector/studio-scratch')
R = Path('/Users/zacheryspector/The-Movies-headless-program')
P = S / '1368-ledger-parent-prep-r2'
A = S / '1368-ledger-arms-02'
B = S / '1368-ledger-arms-01'
G = S / '1368-rival-writing-guard-prep'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def safe(path):
    assert path.is_absolute() and str(path) == os.path.abspath(path)
    for part in [path, *path.parents]: assert not part.is_symlink(), str(part)
a = argparse.ArgumentParser(); a.add_argument('--manifest-sha256', required=True); args = a.parse_args()
safe(P / 'MANIFEST.json'); assert sha(P / 'MANIFEST.json') == args.manifest_sha256
for name, row in json.loads((P / 'MANIFEST.json').read_text())['files'].items():
    path = P / name; safe(path); assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
assert sha(B / 'ASSEMBLY.json') == '05cba942c8cb0d2ce8837f5b5020f7714b73a8a0db0ff8f4f72b7fc19381e1bd'
assert sha(G / 'MANIFEST.json') == '727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca'
proof = json.loads((P / 'SOURCE-DIFFERENCE-PROOF.json').read_text())
origins = json.loads((P / 'ORIGINS.json').read_text())
for arm in ['C0', 'ABC']:
    assert sha(B / arm / 'SOURCE-PINS.json') == proof[arm]['oldSourcePinsSha256']
    old = json.loads((B / arm / 'SOURCE-PINS.json').read_text())
    now = json.loads((P / 'templates' / f'{arm}-SOURCE-PINS.json').read_text())
    assert len(now) == len(old) == 197 and set(now) == set(old)
    assert len([n for n in now if n.startswith('src/')]) == 188
    delta = {n: {'before': old[n], 'after': now[n]} for n in now if n.startswith('src/') and old[n] != now[n]}
    assert delta == proof[arm]['productionChanges']
    for name, pin in now.items():
        path = Path(origins[arm][name]); safe(path); assert path.is_file() and sha(path) == pin
safe(A); assert not os.path.lexists(A); A.mkdir()
for arm in ['C0', 'ABC']:
    root = A / arm; tree = root / 'tree'; tree.mkdir(parents=True)
    expected = json.loads((P / 'templates' / f'{arm}-SOURCE-PINS.json').read_text())
    for name, pin in expected.items():
        source = Path(origins[arm][name]); dest = tree / name; dest.parent.mkdir(parents=True, exist_ok=True)
        assert not os.path.lexists(dest)
        subprocess.run(['/bin/cp', '-c', '-p', str(source), str(dest)], check=True)
        assert sha(dest) == pin and dest.stat().st_nlink == 1 and dest.stat().st_ino != source.stat().st_ino
    (tree / 'node_modules').symlink_to(R / 'node_modules', target_is_directory=True)
    for name in ['ASSEMBLY.json', 'SOURCE-PINS.json']:
        shutil.copy2(P / 'templates' / f'{arm}-{name}', root / name)
shutil.copy2(P / 'templates/ASSEMBLY.json', A / 'ASSEMBLY.json')
for arm in ['C0', 'ABC']:
    for name, pin in json.loads((A / arm / 'SOURCE-PINS.json').read_text()).items():
        assert sha(Path(origins[arm][name])) == pin
print(json.dumps({'assemblySha256': sha(A / 'ASSEMBLY.json'), 'filesPerArm': 197, 'runtimeExecuted': False}))
