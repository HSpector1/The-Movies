# Ledger guarded-source r2 rebind

PROCEED to parent-owned exclusive assembly and matching arm types, then the separately selected existing six bounded diagnostic runs after idle/disk prerequisites. This is preparation approval only.

Manifest6f1ab6dd2fa81678157c342f795872bcef83ad2e126ada1859ecede2344af752; runner34d60bcdf297c6435906a341801328d4c312f6dbc81b45d2645db387a1d72fbd. All package entries and394 named origins rehash exactly. Both197-file inventories retain188 production files. C0 production is unchanged; ABC changes only reviewed hollywoodTick to c540c6830537aaaca6cb448993e4c9648f7141bcf498ca92e239b9ebd1cee5b8. Guard manifest727183f5 is bound. Probe whole-file equality holds after replacing only the corresponding source-hash literal; comparator is byte-identical.

Exclusive arms02 uses mandatory APFS copies, exact hashes, distinct inodes, explicit dependency links and source-origin postflight. Old arms and outputs remain preserved. Runner changes are paths/source-and-kit pins/fresh stem and truthful source label only. Dynamic published HEAD plus remote equality, same-source types, both original seeds/416 ticks, C0 clean/ABC clean/ABC observed,300/330 caps and recorder/owned-cleanup guards remain unchanged.

Original oracle, ledger in-loop assertions, tagged parity and diagnostic-only final count/digest treatment remain intact. Comparator still requires independent parent recorder admission; it does not replace exact receipt review. C0 versus current remains a combined source comparison, not isolated attribution of every ledger difference to the writing guard. No new behavioral pin, count law or causal acceptance follows before measurement.

Static reads/hash comparisons/Python AST only; no assembly, compiler, simulation, fixture read or live/index mutation.
