"""APFS-clone exact r3 files, apply only the reviewed writing guard and landing tests; retain r3 intact."""
import argparse,hashlib,json,os,stat,subprocess
from pathlib import Path
S=Path('/Users/zacheryspector/studio-scratch');P=S/'1368-writing-guard-integration-prep';B=S/'1368-save46-swept-proposal-r3';D=S/'1368-save46-swept-proposal-r4';G=S/'1368-rival-writing-guard-prep';L=S/'1368-rival-writing-landing-tests-prep'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(p):
 assert p.is_absolute() and str(p)==os.path.abspath(p)
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def inventory(tree,pins,links):
 safe(tree);actual=[];found={}
 for folder,dirs,files in os.walk(tree,followlinks=False):
  root=Path(folder)
  for n in list(dirs):
   p=root/n;rel=p.relative_to(tree).as_posix()
   if p.is_symlink():found[rel]=os.readlink(p);dirs.remove(n)
   elif root==tree and n in ['.git','dist','.tmp']:dirs.remove(n)
   else:safe(p)
  for n in files:
   p=root/n;rel=p.relative_to(tree).as_posix()
   if p.is_symlink():found[rel]=os.readlink(p);continue
   safe(p);assert stat.S_ISREG(p.stat().st_mode);assert rel in pins and sha(p)==pins[rel],rel;actual.append(rel)
 assert sorted(actual)==sorted(pins) and found==links
 return {n:{'bytes':(tree/n).stat().st_size,'mode':stat.S_IMODE((tree/n).stat().st_mode)} for n in pins}
a=argparse.ArgumentParser();a.add_argument('--manifest-sha256',required=True);args=a.parse_args()
safe(P/'MANIFEST.json');assert sha(P/'MANIFEST.json')==args.manifest_sha256
for n,row in json.loads((P/'MANIFEST.json').read_text())['files'].items():safe(P/n);assert sha(P/n)==row['sha256'] and (P/n).stat().st_size==row['bytes']
for name,row in json.loads((P/'PREIMAGES.json').read_text()).items():p=Path(name);safe(p);assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
assert sha(G/'MANIFEST.json')=='727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca'
assert sha(L/'MANIFEST.json')=='e886c1d8a68f139ecb3fbc635f17f4a890587d7137be29f8868025dca9a0c1c9'
for package in [G,L]:
 for n,row in json.loads((package/'MANIFEST.json').read_text())['files'].items():safe(package/n);assert sha(package/n)==row['sha256'] and (package/n).stat().st_size==row['bytes']
original=json.loads((B/'SOURCE-PINS.json').read_text());assembly=json.loads((B/'ASSEMBLY.json').read_text());links=assembly['dependencyLinks'];expected=json.loads((P/'EXPECTED-SOURCE-PINS.json').read_text());target=json.loads((P/'EXPECTED-ASSEMBLY.json').read_text())
assert len(original)==1622 and len(expected)==1625
assert target['previousSourcePinsSha256']==sha(B/'SOURCE-PINS.json') and target['previousAssemblySha256']==sha(B/'ASSEMBLY.json') and target['sourcePinsSha256']==sha(P/'EXPECTED-SOURCE-PINS.json') and target['dependencyLinks']==links
metadata=inventory(B/'tree',original,links)
safe(D);assert not os.path.lexists(D);D.mkdir();tree=D/'tree';tree.mkdir()
for n in sorted(original):
 source=B/'tree'/n;dest=tree/n;dest.parent.mkdir(parents=True,exist_ok=True);assert not os.path.lexists(dest)
 # -c is required APFS copy-on-write cloning; no large byte-copy fallback.
 subprocess.run(['/bin/cp','-c','-p',str(source),str(dest)],check=True)
 assert sha(dest)==original[n] and dest.stat().st_size==metadata[n]['bytes'] and stat.S_IMODE(dest.stat().st_mode)==metadata[n]['mode']
 assert (source.stat().st_dev,source.stat().st_ino)!=(dest.stat().st_dev,dest.stat().st_ino),'must clone, never hardlink source'
for n,text in links.items():
 dest=tree/n;safe(dest.parent);dest.parent.mkdir(parents=True,exist_ok=True);assert not os.path.lexists(dest);dest.symlink_to(text)
assert not os.path.lexists(tree/'.git')
env={k:v for k,v in os.environ.items() if k not in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR']};env['GIT_OPTIONAL_LOCKS']='0'
patches=[(G/'production.patch','guardPatchSha256'),(L/'landing-tests.patch','landingPatchSha256')]
for patch,key in patches:
 assert sha(patch)==target[key]
 subprocess.run(['/usr/bin/git','-C',str(tree),'apply','--check',str(patch)],env=env,check=True)
 subprocess.run(['/usr/bin/git','-C',str(tree),'apply',str(patch)],env=env,check=True)
assert not os.path.lexists(tree/'.git')
inventory(tree,expected,links);assert inventory(B/'tree',original,links)==metadata
changed=[n for n,h in original.items() if expected[n]!=h]
assert changed==['src/core/hollywoodTick.ts'] and sum(n.startswith('src/') for n in original)==188
assert expected[changed[0]]=='c540c6830537aaaca6cb448993e4c9648f7141bcf498ca92e239b9ebd1cee5b8'
assert set(expected)-set(original)==set(target['newTestFiles']) and len(target['newTestFiles'])==3
assert 'tests/1368-rival-writing-capture.test.ts' not in expected
for source,name in [(P/'EXPECTED-SOURCE-PINS.json','SOURCE-PINS.json'),(P/'EXPECTED-ASSEMBLY.json','ASSEMBLY.json')]:
 with (D/name).open('xb') as f:f.write(source.read_bytes())
write(D/'PROVENANCE.json',{'integrationManifestSha256':args.manifest_sha256,'assemblyScriptSha256':sha(Path(__file__)),'patches':{str(patch):sha(patch) for patch,key in patches},'sourcePinsSha256':sha(D/'SOURCE-PINS.json'),'assemblySha256':sha(D/'ASSEMBLY.json'),'regularFiles':len(expected),'method':'APFS cp -c -p per exact regular input; git apply without index; exact symlink text recreation','originalPostflightExact':True,'changedProductionFiles':changed,'other187ProductionFilesUnchanged':True,'allOtherR3FilesUnchanged':True,'captureProducerIncluded':False,'gitInitialized':False,'runtimeExecuted':False,'dependencyLinks':links,'newRoot':str(tree)})
print(json.dumps({'sourcePinsSha256':sha(D/'SOURCE-PINS.json'),'assemblySha256':sha(D/'ASSEMBLY.json'),'provenanceSha256':sha(D/'PROVENANCE.json'),'regularFiles':1625}))
