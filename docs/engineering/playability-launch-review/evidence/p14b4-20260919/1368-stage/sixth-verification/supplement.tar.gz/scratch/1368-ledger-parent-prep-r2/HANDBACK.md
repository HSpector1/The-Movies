# Ledger current-source rebind, revision 2

Prepared only; no assembly, compiler, game runtime, fixture read, Git/index change or live source edit was performed. Original packages and arms remain unchanged. This revision is the parent-authorized rebind of the already independently reviewed ledger diagnostic. It does not change its two seeds, 416-week horizon, natural actions, observed phases, original assertions, protected behavioral pins, classification/oracle or tagged state parity.

## Exact amendment

C0 retains all 188 original accepted Save45 production files from `2eaa697effc38538c37da28b486786ce267a2284`, source tree `88d0197645b3a5bd69d73ebff0c5c1c9ff0aa837`. ABC retains the 188 reviewed Save46 files except `src/core/hollywoodTick.ts`, now exactly the approved prospective-writing guard file `c540c6830537aaaca6cb448993e4c9648f7141bcf498ca92e239b9ebd1cee5b8`. Guard package `S/1368-rival-writing-guard-prep/MANIFEST.json` is pinned at `727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca`; its exact patch is copied for review.

`SOURCE-DIFFERENCE-PROOF.json` records zero C0 production changes and exactly that one ABC change. The shared diagnostic source changes only the ABC `hollywoodTick.ts` source SHA literal, so each arm also receives the revised source guard. `PROBE-SOURCE-REBIND.diff` shows this single-line replacement. The extracted original oracle, classifier, all original behavioral pins, comparator and configs are byte-identical to the accepted first kit. `RUNNER-R1-TO-R2.diff` contains the complete runner delta: new paths/pins/receipt stem and an accurate source-status label; the lifecycle, argv, modes and guards are retained.

The original kit at `S/1368-ledger-attribution-prep` remains manifest `5c39b5b9621dd24b3b1115ac8beb2309d710da6ea1028909cc15c4b4e644dd34`; original runner and `S/1368-ledger-arms-01` are preserved. Existing static reviews remain `S/1368-independent-review/LEDGER-DIAGNOSTIC-STATIC.md` and the original parent-runner review. The new revision still requires independent static review before use.

## Small exclusive assembly

`assemble.py` copies only the exactly named 197 regular files per arm into new `S/1368-ledger-arms-02/{C0,ABC}/tree`: 188 production files, the original ledger reference test, package/lock/root type configuration and five diagnostic/helper/config files. Source origins, hashes and expected per-arm/top assembly records are fully pinned in this package. It uses independent APFS clones, never hardlinks, and creates only the established repository node_modules symlink. Logical source size is roughly 11 MB total; no physical clone-saving claim is made. No fixture tree, archive, dependency copy, Git initialization or runtime execution is part of assembly.

The runner consumes the new package's `kit` subdirectory and the expected new assembly identities. It hashes every regular source file and repeats the full inventory at postflight. The actual full publication HEAD must be supplied with `--head`; current branch/remote must equal it. No stale HEAD is compiled into this revision. C0 historical generating source and ABC unlanded guarded candidate remain distinct from coordinator HEAD. Documentation publication can advance before an invocation or between modes; exact consumed source and types bindings cannot change.

Unchanged protections include 5 GiB free disk, Node 20.20.2 and actual entrypoint hashes, power receipt/caffeinate, existing five-file recorder/manual guards, live raw index/stage/bounded source diff, exclusive output paths, exact single-test worker/config flags, 300-second leaf and 330-second outer cap, and reviewed owned-process-group cleanup. Actual child exit/timeout/group status must agree with recorder/postflight, and wrapper success alone is never proof. Each run requires that source arm's own successful type receipt; an old arm or pre-guard type pass cannot authorize the revised source.

## Parent sequence

Expand `S` to `/Users/zacheryspector/studio-scratch` in these examples and replace descriptive tokens with actual values. Use the sole heavy lane and inspect each completed receipt before continuing. There is no loop or automatic retry in the wrapper.

```
python3 S/1368-ledger-parent-prep-r2/assemble.py --manifest-sha256 R2_MANIFEST_SHA
python3 S/1368-ledger-parent-prep-r2/run.py types --arm C0 --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 R2_MANIFEST_SHA --leaf r1
python3 S/1368-ledger-parent-prep-r2/run.py types --arm ABC --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 R2_MANIFEST_SHA --leaf r1
```

Then run exactly these six original modes. Each uses the matching arm's actual type receipt and SHA; both seed strings are fixed in the runner:

| Seed | Arm | Mode |
| --- | --- | --- |
| p13a-core-causal-01 | C0 | clean |
| p13a-core-causal-01 | ABC | clean |
| p13a-core-causal-01 | ABC | observed |
| p13-public-commercial-adoption | C0 | clean |
| p13-public-commercial-adoption | ABC | clean |
| p13-public-commercial-adoption | ABC | observed |

```
python3 S/1368-ledger-parent-prep-r2/run.py clean --arm C0 --seed p13a-core-causal-01 --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 R2_MANIFEST_SHA --leaf r1 --types-receipt ABSOLUTE_C0_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
```

Use the corresponding mode/arm/seed and ABC type receipt for the other rows. Outputs are exclusive under `S/1368-ledger-recorded-runs-r2/<ARM>-<mode>-<seed-label-or-source>-<leaf>/`. Five formal evidence stems are lowercased `1368-ledger-r2-...`. The exact compiled source hashes and original 416-week probe identity are recorded before and after each process.

Only after parent admission of each complete actual child-0 triple, all recorder/source guards and every artifact hash, run the unchanged comparator once per seed:

```
python3 S/1368-ledger-parent-prep-r2/kit/compare.py --baseline ABSOLUTE_C0_CLEAN_DATA_JSON --clean ABSOLUTE_ABC_CLEAN_DATA_JSON --observed ABSOLUTE_ABC_OBSERVED_DATA_JSON --out ABSOLUTE_NEW_COMPARISON_JSON
```

The unchanged comparator takes data paths, not recorder receipts; parent receipt/artifact admission is an explicit prerequisite, as in the original reviewed package. It requires complete routes, clean/observed tagged state parity and lossless row occurrence accounting. It reports changed actual pins against the unchanged historical pins; it never grants re-pin authority. Its original C0-versus-ABC explanatory label predates this rebind: this comparison now also includes the named prospective-writing guard, alongside A/F6/B/C. No difference may be attributed to one of those policies just from timing or aggregate cardinality. Missing receipts, source drift, any incomplete route, mismatch, failure or timeout remains unaccepted.

Only byte/hash checks and static Python AST parsing were performed here. Old baseline failure facts and all unresolved causal limitations are retained. No new seeds, fallback route, horizon extension, production rule, expectation change or test replacement is authorized by this package.
