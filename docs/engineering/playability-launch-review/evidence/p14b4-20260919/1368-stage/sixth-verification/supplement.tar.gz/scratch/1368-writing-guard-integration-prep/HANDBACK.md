# R4 writing correction integration and focused runner

Prepared only. No assembly, Git initialization/index mutation, fixture adoption, compiler, generator, test or other heavy process was run. Live publication and r3 remain untouched. Parent owns adoption/assembly outside recorded activity and all later runs.

## Exact bounded candidate

Start from `S/1368-save46-swept-proposal-r3` SOURCE-PINS `ee24fe3f3600565c180e70a2e6072a33d65a94f650c67731fb806c4a30eae8d2`, ASSEMBLY `406e34a2d01e79d2d48dd61984b881a1962627c24279bce1fa9728dbcc3e5a19`. The new exclusive destination is `S/1368-save46-swept-proposal-r4/tree`.

Apply only these two separately reviewed patches, in order:

1. Parent writing guard `1368-rival-writing-guard-prep/production.patch` SHA `2a4ea2dc9b0fd87c211c9cf600d9691081f158fa45982ce42dcada4b703de058`, manifest `727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca`.
2. Landing-only three-file test patch `1368-rival-writing-landing-tests-prep/landing-tests.patch` SHA `c4dbd3fd059624b20a046a0b65a2a5f2e281c22ad5ab20a1db1d707fd46cf4e3`, manifest `e886c1d8a68f139ecb3fbc635f17f4a890587d7137be29f8868025dca9a0c1c9`.

The resulting1,625-file map changes exactly one existing r3 path: `src/core/hollywoodTick.ts` becomes `c540c6830537aaaca6cb448993e4c9648f7141bcf498ca92e239b9ebd1cee5b8`. All187 other production files and every other existing r3 file retain their exact hashes. Added files are the two original writing test files and their reviewed portable helper. No capture-producer test or evidence configs enter ordinary tests. Expected source `ca96ecb42e78ddf4442e17804bd15a80d70e5808a5e78ed42f43b4f06a0320d2`; expected assembly `604e0a722f5248ef7003ba5dc9216462564d6dad29ba86519612198fb53b94f5`.

The assembler reuses the accepted r3 integration pattern, with ASSEMBLER-DELTA.diff. It verifies all named original regular files and exact dependency link text without traversing targets, requires APFS independent-inode `cp -c -p` clones, preserves modes/bytes/hashes, recreates links identically and applies the two pinned patches without index use or Git initialization. It verifies the exact final inventory and rechecks r3 afterward. A failed clone/apply leaves a new incomplete output and never falls back to physical duplication or deletion. `.git`, `dist` and `.tmp` runtime directories are not copied. No original snapshot is overwritten.

## Fixture and test selection

Parent must first adopt the exact accepted two-file capture into the real repository directory `R/tests/fixtures/p14/genuine-v46-rival-writing-pre414-1368` at a safe checkpoint. This package copies no fixture bytes and does not dereference the existing p14 fixture link during assembly. FIXTURE-PINS preserves all25 prior entries and adds only:

- MANIFEST.json: `d097bbf131c1dc495b881d73e96994953b2f6a0ef50f88bd3b043f263024f205`.
- pre414.save46.json.gz: `501e9023c873548bd19e5df24851ef916cf5ac192db17f5ce6b281e307db4c67`,225,221 bytes as accepted.

The runner supplies both `RIVAL_WRITING_CAPTURE_DIR` pointing to that real repository directory and `RIVAL_WRITING_MANIFEST_SHA256` with the literal accepted manifest. Those values are retained in the recorded binding environment. The helper's ordinary-path check rejects symlink ancestry. No missing-fixture fallback, regeneration, format conversion or substitute witness exists. Original producer and invalid416 endpoint remain evidence-only.

SELECTION-DELTA.json records the precise scope: backward16, P154, helper-consumers37 and UI7 selections are byte-identical; current grows from102 to104 files by appending the two original writing files. New optional `writing` mode contains exactly those two files/four original leaves under the same core project/configuration. No other mode changes membership or selection order. Existing import-edge metadata is retained with only the new files' literal relative-import edges appended; it does not claim all consumers of a source correction form a new campaign.

## Runner and parent commands

RUNNER-REBIND.diff shows only r4/prep/output paths, exact source/assembly/config/selection/fixture pins, the paired capture environment, and bounded writing mode. Producer tsconfig changes only its absolute r3 paths to r4. Existing test configurations, individual deadlines, workers and selection mechanism remain. The existing synchronous focused-runner lifecycle and its previously documented cleanup limitation remain; this rebind does not introduce or claim an external330-second owned-group runner. Actual selected-file equality, child exit, fixed source/index/manual guards,5GiB floor, power/caffeinate and formal pre/post recorder checks are preserved. No broad or all-run mode is added.

After this independent review and when the parent permits assembly:

```
python3 S/1368-writing-guard-integration-prep/assemble.py --manifest-sha256 PACKAGE_PIN
```

Parent then independently initializes the exact scratch Git snapshot outside recorded runs, as the unchanged focused runner requires. Neither assembler nor this preparation does so. Use actual published coordinator HEAD, never an anticipated SHA:

```
python3 S/1368-writing-guard-integration-prep/run.py types --head ACTUAL_PUBLISHED_HEAD --run-id r1
python3 S/1368-writing-guard-integration-prep/run.py writing --head ACTUAL_PUBLISHED_HEAD --run-id r1
```

Other unchanged modes remain backward, p15, current, helper-consumers and ui; parent chooses their reviewed order after actual results. S is `/Users/zacheryspector/studio-scratch`; R is `/Users/zacheryspector/The-Movies-headless-program`. Future result paths are this new prep's `run-MODE-ID`; formal stems start `1368-swept-r4-`. No command runs automatically.

Focused guard GREEN and public boundaries are independently accepted in RIVAL-WRITING-GREEN-MEASURED.md; the exact landing helper has separate static approval. This integration still needs measured r4 types, four writing leaves and required existing-work/retirement and affected-file checks. It does not substitute for source-bound diagnostic repeat, fallout accounting, eventual landing/broad gates or1363V source rebinding. No protected repin, market/trust rule change or checkpoint closure is implied.
