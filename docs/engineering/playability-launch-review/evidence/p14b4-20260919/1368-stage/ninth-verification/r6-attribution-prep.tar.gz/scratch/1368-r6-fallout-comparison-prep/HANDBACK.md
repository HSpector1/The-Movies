# R6 selected attribution adapter

Prepared only, ready for independent static review. No attribution output, compiler, test, simulation, candidate assembly or live/index mutation was performed. The adapter cannot accept preparation metadata as a run receipt. Disk-blocked future runs remain unexecuted.

This is a narrow rebind of `1368-r5-fallout-comparison-prep-r3`, preserving its copied `reviewed_v2.py`, `legacy_raw_parser.py`, `PARSER-ORIGIN.json` and `sys.dont_write_bytecode = True` exactly. `r5-to-r6.diff` shows the complete executable delta: R6 preparation/tree paths, formal record stem, binding filename, and one additional `backward-residual` mode. No parser, normalization, attribution or failure-category logic changes.

## Fixed R6 basis

- Integration kit: `fd4251831e6e8241a3bafe913cc04039a629107b192ab70522845fcebb62bf31`.
- Actual scratch HEAD: `a59301c631531d9189aef5ee1827d6886db78f45`; tree: `80919a922661f9202bc64ad43ef93da3f8472b7c`.
- Source inventory: `2d92af276435275d7ec45554e188962780f0e08467a17dbe42d7ced5f6c85f64`, exactly 1,626 regular files.
- Assembly: `b3dcf41960c58528339415fa822cc3e8555738225275ae5f9ff107b68e28b508`.
- Runner: `4302b3103e06539fcdcf0a86a9eb9ce44fefdbebdceddc3295691ff5d5440c9c`.
- Selections: `14b9f1f49a1fd65242fbe00235a588ee1e15865761e30c518a754732523fafc2`.

`R6-BINDING.json` binds the actual scratch index and stage hashes from read-only inspection, complete regular inventory, source/assembly/runner/selection/producer-config/fixture pins and expected tool identities. The tool expectations are retained from the accepted R5 binding; they are expectations which the future R6 types and run receipts must match, not a claim that R6 has run. The reviewed R6 integration and approved R5 adapter review are exact inputs.

`92c3466a8a878b6a8e0aad7b5c95748477750aa3` is preparation provenance only. As in the prior adapter, `--head` remains dynamic. Fresh types, selected run and formal pre/post/record HEAD fields must all equal that supplied publication. A later documentation publication therefore needs no semantic relaxation or changed source binding.

## Selection and evidence law

All eight existing runner selection values remain identical. The seven attribution modes previously exposed (`backward`, `p15`, `current`, `helper-consumers`, `ui`, `release`, `trust`) remain exposed. The added mode selects these four entire original files, without title filters:

- `tests/p14c3-cohort-transition.test.ts`
- `tests/p14c3-dual-extensions.test.ts`
- `tests/p14p3-directing-promises.test.ts`
- `tests/p14p4p5-opportunities.test.ts`

The existing runner's `writing` selection remains pinned and unchanged; it was not an exposed mode in the prior attribution adapter and is not newly added here.

Admission still requires completed exact formal record, preflight, postflight, raw and patch hashes; actual recorded child command; the exact selected Vitest argv/results/output paths; source/scratch-index/stage/HEAD and every fixed runner/config/fixture binding; fresh successful six-command types and its exact prerequisite artifact map; report timestamps; complete selected file identity; raw/JSON assertion and suite multiplicity reconciliation. Failed runs remain attributable as failed evidence; parser completion is not test success. There is no acceptance before those receipts exist.

Original M3 and unswept 1368-E baseline bytes remain pinned unchanged. All original assertion objects, statuses, full failure-message arrays, raw primary messages, per-file/occurrence identities, suite errors and duplicate handling remain. Outside-selection failures stay NOT_SELECTED. GONE requires per-occurrence review and is not automatic repair. Existing release/trust title relationships remain separate metadata and never rewrite raw keys or claim same-route equivalence. No failure is recategorized by this rebind.

## Parent use after static approval and completed R6 runs

Invoke only after the chosen R6 selected run and its matching six-command types run have completed formal postflight, for example:

`python3 -B /Users/zacheryspector/studio-scratch/1368-r6-fallout-comparison-prep/attribute_r6.py backward-residual --run-id r1 --types-run-id r1 --head <actual shared publication HEAD> --package-sha <reviewed manifest SHA-256> --output /Users/zacheryspector/studio-scratch/1368-r6-attribution-backward-residual-r1`

The output must be new and external to repository, arm, runner and adapter directories. This command is documentation, not an autorun. Independently inspect the emitted issues, statuses, comparisons and residuals before drawing any conclusion. Overlapping selected modes must not be added as unique coverage. No broad gate, ledger repin, gameplay repair or landing approval follows from attribution success.
