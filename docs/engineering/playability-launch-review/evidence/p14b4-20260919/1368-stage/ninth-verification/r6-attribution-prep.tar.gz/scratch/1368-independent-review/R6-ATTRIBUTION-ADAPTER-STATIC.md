# R6 attribution adapter static review

PROCEED for future completed R6 reports only. Manifest `713acfbe028d198944f36c5d55df94d236115caff5c989530efe01d5bfbb7cbf`; adapter `84cebdd4837e6fd9a0fa2d7f8fe938f5626e6dbb06caa745c9e5ce505b45be48`. All package hashes independently verified.

The actual source delta from the approved R5 adapter consists only of R6 preparation/arm/stem/binding names, the descriptive label and backward-residual mode. Both parser modules and PARSER-ORIGIN are byte-identical; no-bytecode loading remains. The seven prior exposed modes stay intact; writing is not newly exposed. The added mode uses the reviewed four entire modified files through the pinned selection map.

The binding matches the actual R6 source/assembly descriptors and reviewed runner, with 1,626 files and recorded scratch HEAD a59301c631531d9189aef5ee1827d6886db78f45. Dynamic --head remains mandatory: completed types and selected run bindings, formal start/end source identity and pre/post HEAD must all equal it. The preparation publication HEAD is metadata, not a substitute for those checks. Old R5 receipts cannot satisfy R6 source/runner binding.

Raw identities, multiplicity, complete assertions/messages, suite errors, projected selected baselines, NOT_SELECTED rows and separate title mappings retain the approved law. No GONE is automatically a pass, overlapping modes are not unique coverage, and parser success does not mean test success. No completed R6 result is claimed or processed here. Future use requires closed exact receipts; changing source or tool identities requires another explicit rebind. Disk and all runtime prerequisites remain unchanged. No attribution execution, game runtime, fixture payload read or live/index mutation performed.
