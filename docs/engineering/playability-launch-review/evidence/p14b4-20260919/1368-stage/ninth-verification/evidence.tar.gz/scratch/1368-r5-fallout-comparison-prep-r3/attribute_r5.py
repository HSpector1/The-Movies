#!/usr/bin/env python3
"""Read completed selected r5 evidence; never execute the game or alter identities."""
import argparse, hashlib, json, os, re, sys
from pathlib import Path
from collections import Counter
HERE=Path(__file__).resolve().parent
R=Path('/Users/zacheryspector/The-Movies-headless-program'); S=Path('/Users/zacheryspector/studio-scratch')
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
PREP=S/'1368-r5-integration-prep'; ARM=S/'1368-save46-swept-proposal-r5'; TREE=ARM/'tree'
MODES=['backward','p15','current','helper-consumers','ui','release','trust']
ARTIFACTS={}
def readbytes(p):
 p=Path(p); assert p.is_file() and not p.is_symlink(),p
 b=p.read_bytes(); h=hashlib.sha256(b).hexdigest()
 if str(p) in ARTIFACTS: assert ARTIFACTS[str(p)]=={'sha256':h,'bytes':len(b)},p
 ARTIFACTS[str(p)]={'sha256':h,'bytes':len(b)};return b
def digest(p): return hashlib.sha256(readbytes(p)).hexdigest()
def read(p): return json.loads(readbytes(p))
def text(p): return readbytes(p).decode()
def formal(mode,run_id,head,binding_hash,types_id=None):
 stem='1368-swept-r5-'+mode+'-'+run_id
 paths={k:E/(stem+s) for k,s in {'record':'.json','pre':'-preflight.json','post':'-postflight.json','raw':'.txt','patch':'.patch'}.items()}
 # Require closed outer record before reading raw or external report.
 rec=read(paths['record']);post=read(paths['post']);pre=read(paths['pre'])
 assert rec.get('end') and rec['fixedSource'] is True and rec['signal'] is None and rec['error'] is None
 assert rec['sourceSha']==rec['sourceShaAtEnd']==pre['head']==post['head']==head
 assert post['fixedSource'] is True and post['allGuardsExact'] is True and post['exitCode']==rec['exitCode']
 for k in ['guardScope','head','sourcePaths','sourceFiles','sourceInventory','manual','index','stageEntries']:assert pre[k]==post[k],k
 for k in ['record','raw','patch']:assert post[k]['sha256']==digest(paths[k]) and post[k]['bytes']==paths[k].stat().st_size,k
 expected=[FIXED['pythonExecutable'],str(PREP/'run.py'),mode,'--head',head,'--run-id',run_id,'--child',binding_hash]
 if types_id is not None:expected+=['--types-run-id',types_id]
 assert rec['command']==expected
 return rec,paths

def completed(mode,run_id,head,types_id=None):
 root=PREP/('run-'+mode+'-'+run_id);binding=root/'binding.json'
 # Formal completion is checked first; hash binding is needed for its command check.
 bh=digest(binding);rec,formal_paths=formal(mode,run_id,head,bh,types_id)
 bound=read(binding);result=read(root/'RESULT.json')
 assert bound['baseHead']==result['baseHead']==head
 assert bound['pins']==FIXED['pins'] and bound['sourceFiles']==result['sourceFiles']==FIXED['sourceFiles']
 assert bound['fixturePins']==read(PREP/'FIXTURE-PINS.json')
 assert bound['selectedFiles']==([] if mode=='types' else SELECTIONS[mode])
 assert result['mode']==mode and result['bindingSha256']==bh and result['allGuardsExact'] is True
 printed=[]
 for line in text(formal_paths['raw']).splitlines():
  try:v=json.loads(line)
  except json.JSONDecodeError:continue
  if isinstance(v,dict) and 'name' in v and 'actualChildExit' in v:printed.append(v)
 assert printed==result['results']
 if mode=='types':
  expected=[('root',['node','node_modules/typescript/bin/tsc','--noEmit']),('ui',['node','node_modules/typescript/bin/tsc','-p','ui/tsconfig.json','--noEmit']),('bridge',['node','node_modules/typescript/bin/tsc','-p','tsconfig.bridge.json']),('contract',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract.ts','--check']),('contract-fixtures',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract-fixtures.ts','--check']),('producers',['node','node_modules/typescript/bin/tsc','--noEmit','-p',str(PREP/'tsconfig.producers.json')])]
  assert bound['typesPrerequisite'] is None
 else:
  expected=[(mode,['node','node_modules/vitest/vitest.mjs','run','--project','ui' if mode=='ui' else 'core',*SELECTIONS[mode],'--reporter=verbose','--reporter=json','--outputFile.json='+str(root/'vitest.json')])]
 assert [(x['name'],x['command']) for x in printed]==expected
 for row in printed:assert digest(root/(row['name']+'.txt'))==row['rawSha256']
 assert rec['exitCode']==(0 if all(x['actualChildExit']==0 for x in printed) else 1)
 if mode=='types':assert rec['exitCode']==0 and all(x['actualChildExit']==0 for x in printed)
 return root,rec,bound,result,formal_paths

def failmap(rows,prefix):
 assert len(rows)==len({r['identity'] for r in rows}),'ambiguous duplicate failure identity; no collapse authorized'
 return {r['identity']:V.normalize(r['primary'] or '',str(prefix)) for r in rows}
def selected_raw(row,selected):
 # Preserve original parser strings. The parser's literal suite file suffix is
 # matched to the exact selected path; no identity or grammar is rewritten.
 return any(row['file']==f or (row['suite'] and row['file']==f+' [ '+f+' ]') for f in selected)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=MODES);ap.add_argument('--run-id',required=True);ap.add_argument('--types-run-id',required=True);ap.add_argument('--head',required=True);ap.add_argument('--package-sha',required=True);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args()
 assert re.fullmatch('[0-9a-f]{40}',a.head)
 for v in [a.run_id,a.types_run_id]:assert re.fullmatch('[a-z0-9][a-z0-9-]{0,39}',v)
 out=a.output;assert out.is_absolute() and not os.path.lexists(out)
 assert all(not p.is_symlink() for p in out.parents)
 for forbidden in [R,ARM,PREP,HERE]:assert out!=forbidden and forbidden not in out.parents
 assert digest(HERE/'MANIFEST.json')==a.package_sha
 for n,pin in read(HERE/'MANIFEST.json')['files'].items():assert digest(HERE/n)==pin['sha256'] and (HERE/n).stat().st_size==pin['bytes']
 # The full reviewed module and parser are copied exactly and loaded only after pin verification.
 global V,FIXED,SELECTIONS
 sys.dont_write_bytecode = True
 import reviewed_v2 as V
 FIXED=read(HERE/'R5-BINDING.json')
 for p,pin in read(HERE/'INPUT-PINS.json').items():assert digest(p)==pin['sha256'] and Path(p).stat().st_size==pin['bytes']
 source=read(ARM/'SOURCE-PINS.json');assert len(source)==FIXED['sourceFiles']
 assert V.sha(json.dumps(sorted(source)).encode())==FIXED['pins']['regularInventorySha256']
 for k,p in [('sourcePinsSha256',ARM/'SOURCE-PINS.json'),('assemblySha256',ARM/'ASSEMBLY.json'),('runnerSha256',PREP/'run.py'),('selectionSha256',PREP/'SELECTIONS.json'),('producerConfigSha256',PREP/'tsconfig.producers.json'),('fixturePinsSha256',PREP/'FIXTURE-PINS.json')]:assert digest(p)==FIXED['pins'][k]
 SELECTIONS=read(PREP/'SELECTIONS.json')['selections'];selected=SELECTIONS[a.mode]
 tr,trec,tbound,tresult,tformal=completed('types',a.types_run_id,a.head)
 root,rec,bound,result,formal_paths=completed(a.mode,a.run_id,a.head,a.types_run_id)
 typepaths=[tr/'binding.json',tr/'RESULT.json',*[tr/(r['name']+'.txt') for r in tresult['results']],*tformal.values()]
 expected_types={str(p):digest(p) for p in typepaths};assert bound['typesPrerequisite']==expected_types
 reportpath=root/'vitest.json';assert digest(reportpath)==result['vitestJsonSha256'];report=read(reportpath)
 assert result['exactFileSelection'] is True and result['actualSelectedFiles']==sorted(selected)
 start,end=V.stamp(rec['start']),V.stamp(rec['end']);assert start<=report['startTime']<=end
 for f in report['testResults']:assert report['startTime']<=f['startTime']<=f['endTime']<=end
 rows,files,suite_errors=V.json_rows(report,str(TREE));assert sorted(files)==sorted(selected)
 issues=[];statuses=Counter(r['status'] for r in rows);failed=[r for r in rows if r['status']=='failed']
 if len(rows)!=report['numTotalTests']:issues.append('report total differs from all assertion occurrences')
 for key,ss in [('numPassedTests',['passed']),('numFailedTests',['failed']),('numPendingTests',['pending','skipped']),('numTodoTests',['todo'])]:
  if report[key]!=sum(statuses[s] for s in ss):issues.append(key+' does not reconcile')
 if rec['exitCode']==0 and (failed or any(f['status']=='failed' for f in report['testResults'])):issues.append('zero child contradicts failed JSON')
 if rec['exitCode']!=0 and not failed:issues.append('nonzero child without failed assertions: inspect suite/runtime failures')
 raw=text(root/(a.mode+'.txt'));products={'case-rows.json':rows,'suite-errors.json':suite_errors,'raw-failure-blocks.json':V.raw_detail(raw)}
 products['unhandled-markers.json']=re.findall(r'(?:Unhandled Errors|Uncaught Exception|Unhandled Rejection)[^\n]*',raw)
 if products['unhandled-markers.json']:issues.append('unhandled raw error markers')
 duplicates={}
 for row in rows:
  if row['displayMultiplicity']>1:duplicates.setdefault(row['identity'],[]).append(row)
 products['duplicate-display-titles.json']=duplicates
 project='ui' if a.mode=='ui' else 'core'; oldroot=S/('1368-fallout-attribution-ui-r1' if project=='ui' else '1368-fallout-attribution-core-r2')
 baseline1361=read(E/('1361-stage/land/attr-ui-live/ui-failures.json' if project=='ui' else '1361-stage/land/attr-core-live/core-failures.json'))['rows']
 baseline1368=read(oldroot/'raw-failure-rows.json');old_cases=read(oldroot/'case-rows.json')
 products['unswept-selected-case-rows.json']=[r for r in old_cases if r['file'] in selected]
 products['unswept-selected-suite-errors.json']=[r for r in read(oldroot/'inventory.json')['suiteErrors'] if r['file'] in selected]
 try:
  _,_,rawrows=V.raw_parse(str(root/(a.mode+'.txt')));products['raw-failure-rows.json']=rawrows
  assert all(selected_raw(r,selected) for r in rawrows),'raw failure belongs to unknown/unselected file'
  rc=Counter(r['identity'] for r in rawrows if not r['suite']);jc=Counter(r['identity'] for r in failed)
  products['raw-json-identity-difference.json']={'rawOnly':dict(rc-jc),'jsonOnly':dict(jc-rc),'rawCaseOccurrences':sum(rc.values()),'jsonCaseOccurrences':sum(jc.values()),'rawSuiteOccurrences':sum(r['suite'] for r in rawrows)}
  if rc!=jc:issues.append('raw/JSON failed occurrence multiplicity mismatch')
  assert len(failed)==len({r['identity'] for r in failed}),'duplicate JSON failure identity needs explicit match'
  after=failmap(rawrows,TREE)
  for label,baseline,prefix in [('1361M3',baseline1361,R),('unswept1368E',baseline1368,S/'1368-save46-fallout-r1/tree')]:
   within=[r for r in baseline if selected_raw(r,selected)];outside=[r for r in baseline if not selected_raw(r,selected)]
   comparison=V.compare(failmap(within,prefix),after)
   comparison.update({'scope':'failure identities within selected files only; GONE is not automatic repair','selectedFiles':selected,'notSelected':outside,'rawBaselineSelected':within})
   gone=[]
   for identity in comparison['gone']:
    matches=[r for r in rows if r['identity']==identity]
    gone.append({'identity':identity,'currentOccurrences':matches,'disposition':'EXECUTED_PASS' if len(matches)==1 and matches[0]['status']=='passed' else 'MASKED_OR_ABSENT_OR_AMBIGUOUS_REQUIRES_REVIEW'})
   comparison['goneDispositions']=gone;products['comparison-vs'+label+'.json']=comparison
 except Exception as exc:
  issues.append('INCOMPLETE_FAILURE_COMPARISON: '+repr(exc))
  products['comparison-error.json']={'error':repr(exc),'baseline1361Rows':baseline1361,'baseline1368Rows':baseline1368}
 # Complete failure-message arrays and all statuses remain in case rows; no title rewrites.
 products['declared-title-relationships.json']=[read(S/n/'TITLE-MAPPING.json') for n in ['1368-rival-release-title-mapping','1368-trust-import-title-mapping']]
 summary={'status':'ATTRIBUTION_ONLY','mode':a.mode,'head':a.head,'sourcePinsSha256':FIXED['pins']['sourcePinsSha256'],'actualChildExit':result['results'][0]['actualChildExit'],'recorderChildExit':rec['exitCode'],'selectedFiles':selected,'fileCount':len(files),'caseCount':len(rows),'statuses':dict(statuses),'suiteErrorCount':len(suite_errors),'issues':issues,'completeIdentityAttribution':not issues,'limits':'No global GONE, no combined unique coverage, no mapped-title identity rewrite, no acceptance from parser success; absent baseline failure is not automatic repair. Full before/after messages remain separate from raw-primary equality.','artifacts':ARTIFACTS}
 for p,pin in list(ARTIFACTS.items()):assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==pin['sha256'] and Path(p).stat().st_size==pin['bytes']
 out.mkdir(parents=True)
 for name,value in {**products,'SUMMARY.json':summary}.items():
  with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 m={f.name:{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(out.iterdir())}
 with (out/'MANIFEST.json').open('x') as f:json.dump(m,f,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in summary.items() if k!='artifacts'},indent=2))
if __name__=='__main__':main()
