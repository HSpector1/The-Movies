#!/usr/bin/env python3
"""Preserve cold evidence logically while reducing physical allocation. No deletion."""
import argparse,hashlib,json,os,re,stat,subprocess,time,uuid
from pathlib import Path
R=Path('/Users/zacheryspector/The-Movies-headless-program')
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
S=Path('/Users/zacheryspector/studio-scratch')
OUT=S/'1368-closed-eighth-compression-prep/results'
WHITELIST_PATH=Path(__file__).resolve().parent/'WHITELIST.json'
WHITELIST_SHA256='aa3096943813bcec7b44f5d98b601f968afe619be0f4ec4654631fc183a73178'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def regular(p):
 assert p.is_absolute()
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1,str(p)
 return s
def attrs(p):
 names=subprocess.check_output(['/usr/bin/xattr',str(p)],text=True).splitlines()
 assert all(re.fullmatch(r'[A-Za-z0-9_.:-]+',k) for k in names),'unexpected xattr name'
 return {k:hashlib.sha256(bytes.fromhex(subprocess.check_output(['/usr/bin/xattr','-px',k,str(p)],text=True))).hexdigest() for k in names if k!='com.apple.decmpfs'}
def meta(p):
 s=regular(p)
 return dict(size=s.st_size,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,mtimeNs=s.st_mtime_ns,flags=s.st_flags,
  attrs=attrs(p),
  acl=subprocess.check_output(['/bin/ls','-lde',str(p)],text=True).splitlines()[1:])
# Exact cold/completed whitelist only: never discover new inputs during apply.
def whitelist():
 regular(WHITELIST_PATH)
 assert sha(WHITELIST_PATH)==WHITELIST_SHA256
 paths=json.loads(WHITELIST_PATH.read_text())
 assert isinstance(paths,list) and len(paths)==3 and paths==sorted(set(paths))
 return tuple(Path(p) for p in paths)
WHITELIST=whitelist()
def eligible(p):
 return p in WHITELIST
def unused(p):
 result=subprocess.run(["/usr/sbin/lsof","-t",str(p)],capture_output=True,text=True)
 assert result.returncode==1 and not result.stdout and not result.stderr,"active file user or uncertain lsof result: "+str(p)
def output_path(value):
 p=Path(value)
 assert p.is_absolute() and p.parent==OUT and OUT.is_dir()
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
 assert p.parent.resolve()==OUT and not os.path.lexists(p)
 return p
SCOPE=['src','bridge','tests','ui','generated','scripts','package.json','package-lock.json','vitest.config.ts','vitest.workspace.ts','tsconfig.json','tsconfig.bridge.json','tsconfig.src.json',':(exclude)tests/fixtures',':(exclude)ui/e2e',':(exclude)ui/public']
def syncdir(p):
 fd=os.open(p,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def frozen_git():
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 def call(*v):return subprocess.check_output(['git','-C',str(R),*v],env=env)
 index=Path(call('rev-parse','--path-format=absolute','--git-path','index').decode().strip())
 return {'head':hashlib.sha256(call('rev-parse','HEAD')).hexdigest(),'stage':hashlib.sha256(call('ls-files','--stage','-z')).hexdigest(),'boundedDiff':hashlib.sha256(call('diff','--no-ext-diff','HEAD','--',*SCOPE)).hexdigest(),'indexSha256':sha(index)}
def no_run():
 lines=subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines()
 bad=[x for x in lines if any(v in x for v in ('run-bounded-source-c2.mjs','node (vitest','run-bounded-source-guards.py','npm install','npm update','npm uninstall'))]
 assert not bad,'active recorded/heavy process: '+repr(bad)
def emit(f,obj):
 f.write(json.dumps(obj,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['plan','apply']);ap.add_argument('--manifest',required=True);ap.add_argument('--manifest-sha');ap.add_argument('--journal');a=ap.parse_args()
manifest=Path(a.manifest)
# Parent separately establishes that the recorded lane and all writers are idle.
# no_run() is an additional refusal check, not proof of exclusive ownership.
if a.mode=='plan':
 manifest=output_path(a.manifest);no_run();rows=[]
 for p in WHITELIST:
  unused(p);s=regular(p)
  assert s.st_size>=8192 and s.st_flags==0,str(p)
  rows.append(dict(path=str(p),sha256=sha(p),metadata=meta(p),inode=s.st_ino,allocated=s.st_blocks*512))
 rows.sort(key=lambda x:x['allocated'],reverse=True)
 value=dict(scope='exact three completed eighth-archive text evidence files; logical bytes, paths and named metadata preserved; inode/ctime/compression flags change',scriptSha256=sha(Path(__file__)),dittoSha256=sha(Path('/usr/bin/ditto')),whitelistSha256=WHITELIST_SHA256,git=frozen_git(),rows=rows)
 with manifest.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 syncdir(OUT)
 print(json.dumps({'manifestSha256':sha(manifest),'files':len(rows),'allocated':sum(x['allocated'] for x in rows)}))
else:
 assert a.manifest_sha and sha(manifest)==a.manifest_sha and a.journal
 assert manifest.parent==OUT and manifest.resolve()==manifest
 regular(manifest);journal_path=output_path(a.journal)
 v=json.loads(manifest.read_text());no_run();assert frozen_git()==v['git']
 assert v['whitelistSha256']==WHITELIST_SHA256
 assert v['scriptSha256']==sha(Path(__file__)) and v['dittoSha256']==sha(Path('/usr/bin/ditto'))
 assert sorted(row['path'] for row in v['rows'])==sorted(str(p) for p in WHITELIST)
 env={k:x for k,x in os.environ.items() if k!='DITTONORSRC'}
 with journal_path.open('x') as journal:
  emit(journal,dict(status='BEGIN',manifestSha256=a.manifest_sha,scriptSha256=v['scriptSha256'],whitelistSha256=WHITELIST_SHA256));syncdir(OUT)
  for row in v['rows']:
   # Leave a small reserve above the governed 5 GiB next-run floor.
   if os.statvfs(R).f_bavail*os.statvfs(R).f_frsize >= int(5.25*1024**3):break
   no_run();p=Path(row['path']);assert eligible(p);unused(p)
   before=regular(p);assert before.st_ino==row['inode'] and meta(p)==row['metadata'] and sha(p)==row['sha256']
   tmp=p.with_name(p.name+'.1368-compress-'+uuid.uuid4().hex);assert not os.path.lexists(tmp)
   command=['/usr/bin/ditto','--hfsCompression','--rsrc','--extattr','--acl',str(p),str(tmp)]
   emit(journal,dict(status='COMPRESS_INTENT',path=str(p),temporary=str(tmp),command=command))
   subprocess.run(command,env=env,check=True)
   assert sha(tmp)==row['sha256']
   os.utime(tmp,ns=(before.st_atime_ns,before.st_mtime_ns))
   tm=meta(tmp);expected={**row['metadata'],'flags':row['metadata']['flags']|32}
   assert tm==expected,(str(p),tm,expected)
   after=regular(tmp)
   if after.st_blocks*512>=row['allocated']:
    # Only the new owned redundant temporary file may be removed.
    tmp.unlink();emit(journal,dict(path=str(p),status='SKIP_NO_SAVINGS'));continue
   with tmp.open('rb') as f:os.fsync(f.fileno())
   assert regular(p).st_ino==row['inode'] and meta(p)==row['metadata'] and sha(p)==row['sha256']
   emit(journal,dict(path=str(p),temporary=str(tmp),status='VERIFIED_BEFORE_REPLACE',sha256=row['sha256'],beforeAllocated=row['allocated'],afterAllocated=after.st_blocks*512,metadata=tm))
   unused(p);os.replace(tmp,p)
   fd=os.open(p.parent,os.O_RDONLY)
   try:os.fsync(fd)
   finally:os.close(fd)
   assert sha(p)==row['sha256'] and meta(p)==expected
   emit(journal,dict(path=str(p),status='PRESERVED_COMPRESSED',inode=regular(p).st_ino,freeBytes=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize))
  assert frozen_git()==v['git']
  free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
  emit(journal,dict(status='COMPLETE',git=v['git'],freeBytes=free,minimum5GiBMet=free>=5*1024**3,target5_25GiBMet=free>=int(5.25*1024**3)))
