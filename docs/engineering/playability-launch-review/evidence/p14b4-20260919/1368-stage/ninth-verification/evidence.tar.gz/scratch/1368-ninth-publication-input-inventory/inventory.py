from pathlib import Path
import json,hashlib,os
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';O=S/'1368-ninth-publication-input-inventory'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selected={};pins={};prior={};priorbytes={};archives=[];runs=[];notes=[]
def add(p,category,pin=None):
 p=Path(p);assert p.is_file() and not any(x.is_symlink() for x in [p,*p.parents]),str(p)
 assert p.is_relative_to(S) or p.is_relative_to(E)
 selected[str(p)]=category
 if pin:
  assert str(p) not in pins or pins[str(p)]==pin
  pins[str(p)]=pin

def package(name):
 root=S/name;m=root/'MANIFEST.json';data=json.loads(m.read_text());add(m,'fixed-package-manifest')
 files=data.get('files',data)
 for name,row in files.items():
  if isinstance(row,dict) and 'sha256' in row:
   file=root/name;add(file,'fixed-package',row['sha256']);assert file.stat().st_size==row.get('bytes',row.get('size',file.stat().st_size))

def flat(root,category):
 for f in Path(root).iterdir():
  assert f.is_file() and not f.is_symlink(),str(f)
  add(f,category)

def formal(stem):
 for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json']:add(E/(stem+suffix),'formal-record')
 record=json.loads((E/(stem+'.json')).read_text());post=json.loads((E/(stem+'-postflight.json')).read_text())
 assert record['fixedSource'] is True and post['allGuardsExact'] is True and record['exitCode']==post['exitCode']
 return record,post

for rel,archive_name in [('fifth-verification/MANIFEST.json','evidence.tar.gz'),('sixth-verification/MANIFEST.json','evidence.tar.gz'),('sixth-verification/SUPPLEMENT-MANIFEST.json','supplement.tar.gz'),('seventh-verification/MANIFEST.json','evidence.tar.gz'),('eighth-verification/MANIFEST.json','evidence.tar.gz'),('eighth-verification/R5-PREPARATION-MANIFEST.json','r5-preparation.tar.gz')]:
 p=E/'1368-stage'/rel;data=json.loads(p.read_text());archive=p.parent/archive_name
 archives.append({'manifest':str(p),'manifestSha256':sha(p),'archive':str(archive),'archiveSha256':data['archive_sha256'],'archiveBytes':data['archive_bytes'],'archiveHashSource':'accepted published manifest; no compressed archive read or extraction'})
 for row in data['files']:
  ref={'priorArchive':str(archive),'priorArchiveSha256':data['archive_sha256'],'priorArchiveMember':row['path']}
  prior[(row.get('original'),row['sha256'])]=ref;priorbytes[(row['sha256'],row.get('size',row.get('bytes')))]=ref

# Published preparation is rechecked but deduplicated against explicit eighth members.
for name in ['1368-r5-integration-prep','1368-r5-fallout-comparison-prep-r2','1368-r5-fallout-comparison-prep-r3','1368-r5-attribution-release-r1','1368-r5-attribution-trust-r1','1368-r5-attribution-backward-r1','1368-r5-backward-residual-diagnosis','1368-r5-backward-residual-patch-prep','1368-r5-backward-residual-patch-prep-r2','1368-ledger-r3-observed-diagnosis','1368-ledger-parent-prep-r4','1368-closed-eighth-compression-prep']:package(name)
# Actual r5 descriptors only: no tree, .git, bundle or dependency scan.
for name in ['root-commit.raw','ASSEMBLY.json','PROVENANCE.json','SOURCE-PINS.json','GIT-SNAPSHOT.json']:add(S/'1368-save46-swept-proposal-r5'/name,'actual-r5-descriptor')
prep=S/'1368-r5-integration-prep'
for mode in ['types','release','trust','backward']:
 root=prep/('run-'+mode+'-r1');flat(root,'closed-r5-run')
 for suffix in ['.lane.log','.lane.log.meta']:add(prep/(mode+'-r1'+suffix),'completed-lane')
 result=json.loads((root/'RESULT.json').read_text());assert result['allGuardsExact'] is True
 for row in result['results']:add(root/(row['name']+'.txt'),'closed-r5-run',row['rawSha256'])
 if 'vitestJsonSha256' in result:add(root/'vitest.json','closed-r5-run',result['vitestJsonSha256'])
 add(root/'binding.json','closed-r5-run',result['bindingSha256'])
 record,post=formal('1368-swept-r5-'+mode+'-r1')
 runs.append({'root':str(root),'resultSha256':sha(root/'RESULT.json'),'mode':mode,'actualCommandExits':[x['actualChildExit'] for x in result['results']],'recorderChildExit':record['exitCode'],'allGuardsExact':True,'scope':'completed exact selection; failure remains failure'})
# Completed parent-only arm04 assembly metadata; no new type/runtime claim.
for relative in ['ASSEMBLY.json','C0/ASSEMBLY.json','C0/SOURCE-PINS.json','ABC/ASSEMBLY.json','ABC/SOURCE-PINS.json']:
 add(S/'1368-ledger-arms-04'/relative,'actual-ledger-r4-arm-descriptor')
add(S/'1368-ledger-r4-assembly-parent-receipt.json','parent-assembly-receipt')
assert sha(S/'1368-ledger-arms-04/ASSEMBLY.json')=='8d027bf8e9cd6aa5e874b6f053e14b5b17be3701c6f4966b3b42610cf7fd6b38'
# Newly completed standalone mocked safety prerequisite; no simulator or real signals.
safety=S/'1368-ledger-r4-cleanup-safety-r1';flat(safety,'closed-mocked-cleanup-safety')
sr=json.loads((safety/'RESULT.json').read_text());assert sr['tests']==7 and sr['actualChildExit']==sr['recorderExit']==sr['postflightExit']==0 and sr['allGuardsExact']
for suffix,pin in sr['formal'].items():add(E/('1368-ledger-r4-cleanup-safety-r1'+suffix),'formal-record',pin)
formal('1368-ledger-r4-cleanup-safety-r1')
runs.append({'root':str(safety),'resultSha256':sha(safety/'RESULT.json'),'tests':7,'actualChildExit':0,'recorderExit':0,'postflightExit':0,'allGuardsExact':True,'scope':'Mocked cleanup safety only; no game, child launch or real signals'})
# A floor refusal happened before binding/formal preflight/child launch; directory is empty.
p15=prep/'run-p15-r1';assert p15.is_dir() and not p15.is_symlink() and list(p15.iterdir())==[]
for suffix in ['.lane.log','.lane.log.meta']:add(prep/('p15-r1'+suffix),'preflight-refusal')
formal_p15={suffix:(E/('1368-swept-r5-p15-r1'+suffix)).exists() for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json']};assert not any(formal_p15.values())
notes.append({'root':str(p15),'status':'EMPTY_DIRECTORY_AFTER_DISK_FLOOR_REFUSAL','entryCount':0,'formalArtifactsPresent':formal_p15,'source':str(prep/'p15-r1.lane.log'),'meaning':'Not launched; no P15 result or acceptance. Empty directory represented as metadata, not an invented artifact.'})
# Accepted selected attribution products also bind their original completed input receipts.
for name in ['1368-r5-attribution-release-r1','1368-r5-attribution-trust-r1','1368-r5-attribution-backward-r1']:
 data=json.loads((S/name/'SUMMARY.json').read_text());assert not data['issues'] and data['completeIdentityAttribution'] is True
 for path,row in data['artifacts'].items():
  # Only named artifact hashes in the fixed report; no recursive baseline or fixture scan.
  assert '/tests/fixtures/' not in path
  add(path,'attribution-bound-input',row['sha256']);assert Path(path).stat().st_size==row.get('bytes',row.get('size',Path(path).stat().st_size))
# Newly completed ledger ABC runs; existing C0 results are already in eighth.
ledger=S/'1368-ledger-recorded-runs-r3';lp=S/'1368-ledger-parent-prep-r3'
for name,lane in [('ABC-types-source-r1','types-abc-r1'),('ABC-clean-p13a-r1','clean-abc-p13a-r1')]:
 root=ledger/name;flat(root,'closed-ledger-run');result=json.loads((root/'RESULT.json').read_text());assert result['allGuardsExact']
 for path,row in result['artifacts'].items():add(path,'formal-record' if str(path).startswith(str(E)) else 'closed-ledger-run',row['sha256'])
 for suffix in ['.lane.log','.lane.log.meta']:add(lp/(lane+suffix),'completed-lane')
 runs.append({'root':str(root),'resultSha256':sha(root/'RESULT.json'),'actualChildExit':result['actualChildExit'],'recorderChildExit':result['recorderChildExit'],'timedOut':result['timedOut'],'allGuardsExact':result['allGuardsExact']})
root=ledger/'ABC-observed-p13a-r1';flat(root,'closed-incomplete-ledger-attempt')
for name in ['CHILD.json','RESULT.json','data.json','vitest.json']:assert not (root/name).exists()
for suffix in ['.lane.log','.lane.log.meta']:add(lp/('observed-abc-p13a-r1'+suffix),'completed-failure-lane')
record,post=formal('1368-ledger-r3-abc-observed-p13a-r1')
runs.append({'root':str(root),'status':'CLOSED_INCOMPLETE_ATTEMPT','recorderChildExit':record['exitCode'],'actualNodeExit':None,'timedOut':None,'cleanupNoSurvivors':None,'allLiveGuardsExact':True,'missing':['CHILD.json','RESULT.json','data.json','vitest.json'],'meaning':'EPERM escaped cleanup reporting; no fabricated Node status or timeout.'})
flat(S/'1368-ledger-r3-observed-failure-audit','closed-process-audit')
flat(S/'1368-disk-preflight-refusal','disk-preflight-refusal-audit')
flat(S/'1368-closed-eighth-compression-prep/results','completed-compression-transaction')
final=json.loads((S/'1368-closed-eighth-compression-prep/results/apply-r1.jsonl').read_text().splitlines()[-1]);assert final['status']=='COMPLETE'
notes.append({'root':str(S/'1368-closed-eighth-compression-prep/results'),'status':'COMPLETE','measuredFreeBytesAtCompletion':final['freeBytes'],'minimum5GiBMetAtCompletion':final['minimum5GiBMet'],'target5_25GiBMetAtCompletion':final['target5_25GiBMet'],'meaning':'Historical completion measurement only; not current free-space clearance or Owner 1.5 GiB request completion.'})
for name in ['R5-INTEGRATION-STATIC.md','R5-TYPES-MEASURED.md','R5-ORIGINAL-RELEASE-MEASURED.md','R5-TRUST-WHOLE-FILE-MEASURED.md','R5-ATTRIBUTION-ADAPTER-STATIC.md','R5-RELEASE-TRUST-ATTRIBUTION-MEASURED.md','R5-BACKWARD16-MEASURED.md','LEDGER-R3-ABC-P13A-CLEAN-MEASURED.md','LEDGER-R3-OBSERVED-INCOMPLETE.md','LEDGER-R4-STATIC.md','LEDGER-R4-CLEANUP-SAFETY-MEASURED.md','R5-BACKWARD-RESIDUAL-R2-STATIC.md','CLOSED-EIGHTH-COMPRESSION-STATIC.md','CLOSED-EIGHTH-COMPRESSION-PLAN.md','CLOSED-EIGHTH-COMPRESSION-MEASURED.md']:add(S/'1368-independent-review'/name,'independent-review')
new=[];refs=[]
for path,category in sorted(selected.items()):
 p=Path(path);before=p.stat();data=p.read_bytes();h=hashlib.sha256(data).hexdigest();after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
 if path in pins:assert h==pins[path],('pin mismatch',path)
 member=('scratch/'+p.relative_to(S).as_posix()) if p.is_relative_to(S) else ('evidence/'+p.relative_to(E).as_posix())
 row={'original':path,'path':member,'size':len(data),'sha256':h,'category':category};ref=prior.get((path,h)) or priorbytes.get((h,len(data)))
 if ref:row.update(ref);row['referenceKind']='same-original-and-bytes' if (path,h) in prior else 'same-bytes-at-explicit-other-member';refs.append(row)
 else:new.append(row)
for row in new+refs:
 p=Path(row['original']);assert p.stat().st_size==row['size'] and sha(p)==row['sha256'],('changed during inventory',str(p))
assert list(p15.iterdir())==[]
result={'status':'INPUT_INVENTORY_ONLY_NOT_AN_ARCHIVE','sincePublishedHead':'ee7f700ff5b088a508c4a790a65378e36f131fa8','newFiles':new,'priorReferences':refs,'priorArchives':archives,'closedRuns':runs,'notes':notes,'issues':[],
'excluded':['No candidate full source tree, .git directory, dependency tree, binary, bundle or duplicate archive payload','No old fixture payload reads or private-save/unrelated scratch traversal','R6 integration preparation remains mutable and is excluded; parent must preserve a separate supplement after exact freeze/review','Ledger r4 parent assembly included as five descriptors; no fresh r4 types/simulation or later outputs included','No P15 simulation launched by floor-refused attempt; no result invented','No clearance of present disk floor or completion of Owner requested 1.5 GiB space recovery'],
'addendumBoundary':{'mutablePackage':'R6 integration preparation; parent to name exact frozen package in later supplement','action':'Do not mutate this fixed inventory. Independently pin a separate addendum after parent confirms package freeze and review; any later ledger r4 types/run is likewise separate.'},
'counts':{'newFiles':len(new),'newLogicalBytes':sum(x['size'] for x in new),'priorReferences':len(refs),'referencedLogicalBytes':sum(x['size'] for x in refs),'closedRunEntries':len(runs)}}
(O/'INPUTS.json').write_text(json.dumps(result,indent=2)+'\n');print(result['counts']);print('INPUTS',sha(O/'INPUTS.json'))
