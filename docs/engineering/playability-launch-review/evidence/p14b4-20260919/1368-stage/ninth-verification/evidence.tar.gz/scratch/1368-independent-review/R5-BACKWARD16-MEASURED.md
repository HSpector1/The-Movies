# R5 backward 16 measured review and first boundaries

Accept the recorded evidence; the selected scope remains RED: 285 cases, 278 passed, 7 failed, no skips/TODO or setup/suite errors. RESULT `08da21551ecf69c9cd87a118a1eca87cc3e8ff76981c7f3096b3db4b544cc2a6` records actual child 1; formal recorder/postflight also report 1 with exact guards. Independently verified the attribution output manifest and every recorded input artifact hash/size. Parser issues are empty, not evidence that tests passed.

Against selected 1361-M3 failures: 2 SAME, 5 NEW, no CHANGED/GONE. Against selected unswept 1368-E: 2 SAME, 5 CHANGED, no NEW, 152 GONE raw failure identities. GONE is not a global repair claim: per-occurrence dispositions and renamed/setup-masked distinctions remain mandatory. Backward16 is this core file selection, not the separate d16 gate.

| Failure | Current first boundary | Required handling |
| --- | --- | --- |
| J7, cohort-transition:287 | `migrateToV45: cannot downgrade or discard recovery authority: costCutting.since, facilityDemolitionRefund, facilityDisposed` | Real nonempty Save46 authority refuses at the public 46-to-45 edge, before the older ranking guard. Preserve that ownership and disclose masked lower guards. |
| X5 Director and X5 Writer, dual-extensions:178 | `migrateToV45: cannot downgrade or discard recovery authority: costCutting.since` | Same public boundary, with the exact observed narrower authority set. Neither lower Power Ranking refusal is reached. |
| D14, directing-promises:451 | Full migrated-state equality differs | Independently parsed both complete raw JSON operands: only four `{version:1,since:null}` costCutting additions and four zero facilityDemolitionRefund movements differ. An expected-only exact empty-recovery initializer is supported; keep the entire comparison. |
| Q04, opportunities:399 | Full migrated-state equality differs | Independently confirmed the same eight additive empty-recovery paths, with no other state difference. Preserve genuine historical admission and the complete expected-state comparison. |
| D07 and D18, directing-promises:1017 | Fixed rival does not win the later focus case as required by the fixture premise | Exact identity/primary SAME in both accepted baselines. Downstream promise/staffing assertions are not reached; no repair or waiver follows. |

The current save source admits V46 before examining nonempty recovery authority and strips only genuinely empty recovery when allowed. Do not cast, manually strip, relabel or bypass a real refusal to reach a historical reader. Any proposed first-message change must retain exact case-specific observed ownership and explicitly state which older guarantees remain covered by their own-era controls. D14/Q04 failed at the first capture/first equality; later captures and downstream converter assertions still require measurement after a reviewed correction. This review does not authorize a string-only repin or an automatic extension of the eight-path result to unexecuted variants.

No source edits, fixture payload reads, runtime or expectation changes were performed. Broad acceptance, landing and unresolved baseline behavior remain open.
