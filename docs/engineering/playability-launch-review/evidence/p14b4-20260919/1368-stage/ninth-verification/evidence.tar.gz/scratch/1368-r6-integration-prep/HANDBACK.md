# R6 preparation: four reviewed backward residual files

Preparation only. This package creates no candidate and executes no types, tests, Node, Git initialization or runtime. It preserves R5 and all prior evidence. The separately reviewed correction is `1368-r5-backward-residual-patch-prep-r2`, manifest de463ccd2ba578736d601b0895ca51930a724ad85153c702c9cba561590ce6a9, patch 7b55bd7f8755b89aa7b328c3b4f864a418188c4123d3b69c7a508e7cd5ab0871. Static review: R5-BACKWARD-RESIDUAL-R2-STATIC.md, SHA 859d4fae4d912e8e062b75554d0f94e5becbfd40621f0298d9421aeec752f89e.

Expected source remains 1,626 regular files, including 188 unchanged production files. Exactly four existing tests differ: cohort-transition, dual-extensions, directing-promises and opportunities. No new/removed file, fixture, dependency link or production change occurs. SOURCE-DIFFERENCE-PROOF.json records every changed preimage/postimage; EXPECTED-SOURCE-PINS.json binds the complete result. The base is the recorded R5 root 73d3d44d640dc885f5855f726a9edc9516eb9704, tree 8860f82ac679c7dd1df52b25bd181fc2df66d508. These are scratch identities, not a claim of source landing.

assemble.py reuses the reviewed R5 APFS clone procedure: verify package and exact source/patch preimages, verify base root/tree/inventory/symlink text, require an exclusive new target, clone each exact regular file with cp -c -p and no fallback/hardlinks, recreate original symlink texts, apply only the pinned reviewed patch without an index, verify the full target and unchanged base, then write source/assembly/provenance metadata. It neither follows/copies bulky fixture/dependency trees nor initializes Git. Target is exclusively `S/1368-save46-swept-proposal-r6`. Parent must separately initialize and record the isolated scratch root before the existing runner's Git guards can pass. No live Git history changes are authorized by assembly.

run.py preserves R5's lifecycle, actual-publication-HEAD binding, source/index/fixture/manual guards, Node20 entrypoint hashes, six-command same-source fresh types prerequisite, original worker/config/leaf deadlines, 5 GiB free-space floor and five formal recorder files. It adds no new timeout or watchdog semantics. Type producer config changes only its absolute target prefix to R6. All 29 fixture pins and their environment values remain byte-identical. Old R5 type receipts cannot satisfy the new-source prerequisite.

All existing whole-file mode selections are unchanged: backward16, P15four, current104, helper-consumers37, UI7, writing2, release1 and trust1. The only added mode, `backward-residual`, runs all four modified files, without a title filter. This exposes the complete downstream D14/Q04 assertions and retains unchanged D07/D18 baseline failures for attribution rather than excluding them. SELECTION-DELTA.json proves the original lists are identical; mode counts are file counts, and overlaps are not unique coverage. No expectation beyond the independently reviewed patch is changed.

Parent sequence after this package's independent review and the normal disk/lane gate:

```sh
python3 /Users/zacheryspector/studio-scratch/1368-r6-integration-prep/assemble.py --manifest-sha256 REVIEWED_PACKAGE_MANIFEST_SHA
# Parent records the new isolated scratch Git root; the assembler intentionally does not.
python3 /Users/zacheryspector/studio-scratch/1368-r6-integration-prep/run.py types --head ACTUAL_PUBLISHED_HEAD --run-id r1
python3 /Users/zacheryspector/studio-scratch/1368-r6-integration-prep/run.py backward-residual --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-run-id r1
```

Only after admitting those results should parent choose the remaining existing groups. External outputs are exclusive `S/1368-r6-integration-prep/run-MODE-ID`; formal stems are `1368-swept-r6-MODE-ID`. Commands do not run automatically, and preparation supplies no permission to ignore the current disk gate.

ASSEMBLER-DELTA.diff and RUNNER-REBIND.diff are the complete changes from reviewed R5 utilities. PREIMAGES.json pins their sources, all four input tests, base metadata and the adopted patch. INTEGRATION.patch is a byte-identical convenience copy; assembly applies the independently pinned author package. Static Python AST checks passed. No result, GREEN, broad verification, promotion or closure is claimed. The existing attribution adapter remains R5-bound and must not be relabeled as R6 without its own explicit binding revision.
