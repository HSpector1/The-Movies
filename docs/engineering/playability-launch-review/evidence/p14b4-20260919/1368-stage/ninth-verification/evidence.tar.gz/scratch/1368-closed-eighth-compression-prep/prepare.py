from pathlib import Path
import ast,hashlib,json,tarfile,subprocess,stat,difflib
S=Path('/Users/zacheryspector/studio-scratch');O=S/'1368-closed-eighth-compression-prep';E=Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919/1368-stage/eighth-verification'); prior=S/'1368-cold-dependency-compression-next-prep/compress.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
names=['1368-writing-guarded-split-recorded-runs/probe-core-no-laboratory-r1/data/core-no-laboratory.jsonl','1368-writing-guarded-split-recorded-runs/probe-bridge-laboratory-r1/data/bridge-laboratory.jsonl','1368-ledger-recorded-runs-r3/C0-clean-p13a-r1/data.json']
manifest=E/'MANIFEST.json';j=json.loads(manifest.read_text());archive=E/'evidence.tar.gz';assert sha(archive.read_bytes())==j['archive_sha256']; selected=[]; processes=[]
with tarfile.open(archive,'r:gz') as tf:
 for name in sorted(names):
  p=S/name; r=next(r for r in j['files'] if r['original']==str(p));member=tf.getmember(r['path']);assert member.isfile() and member.size==r['size']; archived=tf.extractfile(member).read();current=p.read_bytes();assert archived==current and sha(current)==r['sha256']
  for q in [p,*p.parents]:assert not q.is_symlink(),q
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_flags==0
  ls=subprocess.run(['/usr/sbin/lsof','-t',str(p)],capture_output=True,text=True);assert ls.returncode==1 and not ls.stdout and not ls.stderr,(p,ls)
  attrs=subprocess.check_output(['/usr/bin/xattr',str(p)],text=True).splitlines()
  attrs={k:sha(bytes.fromhex(subprocess.check_output(['/usr/bin/xattr','-px',k,str(p)],text=True))) for k in attrs}
  acl=subprocess.check_output(['/bin/ls','-lde',str(p)],text=True).splitlines()[1:]
  selected.append({**r,'archive':str(archive),'archiveSha256':j['archive_sha256'],'archiveMemberByteEquality':True,'inode':s.st_ino,'allocated':s.st_blocks*512,'metadata':{'size':s.st_size,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtimeNs':s.st_mtime_ns,'flags':s.st_flags,'nlink':s.st_nlink,'attrs':attrs,'acl':acl}})
  processes.append({'path':str(p),'argv':['/usr/sbin/lsof','-t',str(p)],'exitCode':ls.returncode,'stdout':ls.stdout,'stderr':ls.stderr})
wl=O/'WHITELIST.json';wl.write_text(json.dumps(sorted(str(S/n) for n in names),indent=2)+'\n'); wh=sha(wl.read_bytes());old=prior.read_text();new=old.replace("OUT=S/'1368-cold-dependency-compression-next-prep/results'","OUT=S/'1368-closed-eighth-compression-prep/results'").replace("WHITELIST_SHA256='1b5dee177d889e81468865bcc20c5f3fecad9f5201974dc48b61c6cf9b4afcae'",f"WHITELIST_SHA256='{wh}'").replace('len(paths)==160','len(paths)==3').replace('exact 150 inactive project dependency text files and 10 completed evidence traces','exact three completed eighth-archive text evidence files')
ast.parse(new);(O/'compress.py').write_text(new);(O/'compress.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(prior),tofile=str(O/'compress.py'))))
proof={'status':'READ_ONLY_PREFLIGHT_NOT_TRANSACTION_PLAN','archiveManifest':str(manifest),'archiveManifestSha256':sha(manifest.read_bytes()),'archive':str(archive),'archiveSha256':j['archive_sha256'],'archiveBytes':archive.stat().st_size,'sourceCompressor':str(prior),'sourceCompressorSha256':sha(prior.read_bytes()),'rows':selected,'lsof':processes,'logicalBytes':sum(r['size'] for r in selected),'allocatedBytes':sum(r['allocated'] for r in selected),'actualCompressionSavings':'Unmeasured; positive savings required per file by unchanged transaction.'}
(O/'PREFLIGHT.json').write_text(json.dumps(proof,indent=2)+'\n');print('logical',proof['logicalBytes'],'allocated',proof['allocatedBytes'],'whitelist',wh)
