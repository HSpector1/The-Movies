from pathlib import Path
import json,hashlib,difflib,ast
S=Path('/Users/zacheryspector/studio-scratch');P=S/'1368-r6-integration-prep';OLD=S/'1368-r5-integration-prep';B=S/'1368-save46-swept-proposal-r5';G=S/'1368-r5-backward-residual-patch-prep-r2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
source=json.loads((B/'SOURCE-PINS.json').read_text());expected=dict(source);rows=json.loads((G/'FILE-INVENTORY.json').read_text())
for r in rows:
 assert source[r['file']]==r['beforeSha256'] and sha(B/'tree'/r['file'])==r['beforeSha256'] and sha(G/'candidate'/r['file'])==r['afterSha256']
 expected[r['file']]=r['afterSha256']
assert len(expected)==1626 and sum(n.startswith('src/') for n in expected)==188
changed=sorted(n for n in source if source[n]!=expected[n]);assert changed==sorted(r['file'] for r in rows)
dump('EXPECTED-SOURCE-PINS.json',expected)
baseassembly=json.loads((B/'ASSEMBLY.json').read_text());git=json.loads((B/'GIT-SNAPSHOT.json').read_text())
dump('EXPECTED-ASSEMBLY.json',{'status':'PROPOSED_R6_NOT_ASSEMBLED_OR_EXECUTED','revision':6,'previousRoot':str(B),'previousHead':git['head'],'previousTree':git['tree'],'previousSourcePinsSha256':sha(B/'SOURCE-PINS.json'),'previousAssemblySha256':sha(B/'ASSEMBLY.json'),'sourcePinsSha256':sha(P/'EXPECTED-SOURCE-PINS.json'),'regularFiles':1626,'dependencyLinks':baseassembly['dependencyLinks'],'productionFiles':188,'changedProductionFiles':[],'changedTestFiles':changed,'newTestFiles':[],'backwardManifestSha256':sha(G/'MANIFEST.json'),'backwardPatchSha256':sha(G/'backward-residuals.patch'),'captureProducerIncluded':False})
selections=json.loads((OLD/'SELECTIONS.json').read_text());selections['selections']['backward-residual']=changed;selections['scope']+='; R6 adds only backward-residual: four modified whole files, no title filters';dump('SELECTIONS.json',selections)
for n in ['FIXTURE-PINS.json']:(P/n).write_bytes((OLD/n).read_bytes())
(P/'tsconfig.producers.json').write_text((OLD/'tsconfig.producers.json').read_text().replace('1368-save46-swept-proposal-r5','1368-save46-swept-proposal-r6'))
(P/'INTEGRATION.patch').write_bytes((G/'backward-residuals.patch').read_bytes())
a=(OLD/'assemble.py').read_text();b=a
b=b.replace('APFS-clone exact r4 files, apply only approved release/trust tests; retain r4 and every production file intact.','APFS-clone exact r5 files, apply only approved backward residual tests; retain r5 and every production file intact.')
line=next(x for x in b.splitlines() if x.startswith("S=Path("));b=b.replace(line,"S=Path('/Users/zacheryspector/studio-scratch');P=S/'1368-r6-integration-prep';B=S/'1368-save46-swept-proposal-r5';D=S/'1368-save46-swept-proposal-r6';G=S/'1368-r5-backward-residual-patch-prep-r2'")
start=b.index("assert sha(G/'MANIFEST.json')");end=b.index('original=json.loads',start)
b=b[:start]+f"assert sha(G/'MANIFEST.json')=='{sha(G/'MANIFEST.json')}'\nfor n,row in json.loads((G/'MANIFEST.json').read_text())['files'].items():safe(G/n);assert sha(G/n)==row['sha256'] and (G/n).stat().st_size==row['bytes']\n"+b[end:]
b=b.replace('len(original)==1625','len(original)==1626').replace("patches=[(G/'original-leaf.patch','releasePatchSha256'),(L/'trust-import-wiring.patch','trustPatchSha256')]","patches=[(G/'backward-residuals.patch','backwardPatchSha256')]")
b=b.replace('len(changed)==2','len(changed)==4').replace("len(target['newTestFiles'])==1","len(target['newTestFiles'])==0").replace("'other1623R4FilesUnchanged':True","'other1622R5FilesUnchanged':True")
(P/'assemble.py').write_text(b);(P/'ASSEMBLER-DELTA.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='r5/assemble.py',tofile='r6/assemble.py')))
a=(OLD/'run.py').read_text();b=a.replace('1368-r5-integration-prep','1368-r6-integration-prep').replace('1368-save46-swept-proposal-r5','1368-save46-swept-proposal-r6').replace('1368-swept-r5-','1368-swept-r6-')
b=b.replace("'release','trust']","'release','trust','backward-residual']")
for n in ['SELECTIONS.json','FIXTURE-PINS.json','tsconfig.producers.json']:
 b=b.replace(sha(OLD/n),sha(P/n))
b=b.replace(sha(B/'SOURCE-PINS.json'),sha(P/'EXPECTED-SOURCE-PINS.json')).replace(sha(B/'ASSEMBLY.json'),sha(P/'EXPECTED-ASSEMBLY.json'))
b=b.replace('approved swept originals plus release/trust input corrections; all production unchanged from r4; not broad acceptance','approved R6 backward residual corrections with all original whole-file selections; all production unchanged from r5; not broad acceptance')
(P/'run.py').write_text(b);(P/'RUNNER-REBIND.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='r5/run.py',tofile='r6/run.py')))
paths=[B/n for n in ['SOURCE-PINS.json','ASSEMBLY.json','GIT-SNAPSHOT.json']]+[OLD/n for n in ['MANIFEST.json','assemble.py','run.py','SELECTIONS.json','FIXTURE-PINS.json','tsconfig.producers.json']]+[G/'MANIFEST.json',G/'backward-residuals.patch']+[B/'tree'/r['file'] for r in rows]
dump('PREIMAGES.json',{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths})
dump('SOURCE-DIFFERENCE-PROOF.json',{'baseSourcePinsSha256':sha(B/'SOURCE-PINS.json'),'expectedSourcePinsSha256':sha(P/'EXPECTED-SOURCE-PINS.json'),'regularFilesBefore':len(source),'regularFilesAfter':len(expected),'productionFiles':188,'changedProductionFiles':[],'changedFiles':rows,'newFiles':[],'removedFiles':[],'unchangedFiles':len(source)-len(rows),'method':'Expected full map derived from exact r5 map and four independently reviewed patch postimages; actual assembly still required.'})
dump('SELECTION-DELTA.json',{'originalSelectionSha256':sha(OLD/'SELECTIONS.json'),'allOriginalSelectionsByteValueIdentical':all(selections['selections'][k]==v for k,v in json.loads((OLD/'SELECTIONS.json').read_text())['selections'].items()),'onlyAddedMode':'backward-residual','files':changed,'titleFilters':False,'budgets':'Existing Vitest/leaf deadlines unchanged; identical original R5 runner lifecycle and floor.'})
for p in [P/'assemble.py',P/'run.py']:ast.parse(p.read_text())
print('expected-source',sha(P/'EXPECTED-SOURCE-PINS.json'));print('expected-assembly',sha(P/'EXPECTED-ASSEMBLY.json'))
