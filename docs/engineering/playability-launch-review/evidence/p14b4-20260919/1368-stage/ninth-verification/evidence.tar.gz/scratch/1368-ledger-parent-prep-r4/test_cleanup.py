"""Standalone mocked syscall checks; never launches or signals a real process."""
import errno
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('ledger_cleanup', Path(__file__).with_name('cleanup.py'))
cleanup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cleanup)


class CleanupTests(unittest.TestCase):
    def proc(self, code=0):
        proc = Mock(pid=24680)
        proc.poll.return_value = code
        return proc

    def receipt(self, proc):
        rows = []
        code = cleanup.finish_child(proc, False, 0, ['fixed-test-command'], lambda: True, rows.append)
        self.assertEqual(len(rows), 1)
        return code, rows[0]

    @patch.object(cleanup.os, 'getpgrp', return_value=13579)
    @patch.object(cleanup.os, 'killpg', side_effect=PermissionError(errno.EPERM, 'denied'))
    def test_eperm_probe_is_unknown_and_nonzero(self, killpg, _):
        code, row = self.receipt(self.proc())
        self.assertEqual(code, 1)
        self.assertEqual(row['processGroup']['statusAfterCleanup'], 'UNKNOWN')
        self.assertFalse(row['processGroup']['noSurvivors'])
        self.assertEqual(row['processGroup']['signalAttempts'], [])
        self.assertEqual(row['processGroup']['errors'][0]['errno'], errno.EPERM)
        killpg.assert_called_once_with(24680, 0)

    @patch.object(cleanup.os, 'getpgrp', return_value=13579)
    @patch.object(cleanup.os, 'killpg', side_effect=[None, None, PermissionError(errno.EPERM, 'grace probe denied')])
    def test_term_then_eperm_stops_before_kill(self, killpg, _):
        code, row = self.receipt(self.proc(-15))
        self.assertEqual(code, 1)
        self.assertEqual(row['actualChildExit'], -15)
        self.assertEqual(row['processGroup']['signals'], ['TERM'])
        self.assertFalse(row['processGroup']['noSurvivors'])
        self.assertEqual([call.args[1] for call in killpg.call_args_list], [0, cleanup.signal.SIGTERM, 0])

    @patch.object(cleanup.os, 'getpgrp', return_value=13579)
    @patch.object(cleanup.os, 'killpg', side_effect=[None, PermissionError(errno.EPERM, 'TERM denied')])
    def test_signal_error_is_recorded(self, killpg, _):
        code, row = self.receipt(self.proc())
        self.assertEqual(code, 1)
        self.assertEqual(row['processGroup']['errors'][0]['operation'], 'TERM')
        self.assertEqual(row['processGroup']['signals'], [])
        self.assertEqual(row['processGroup']['signalAttempts'], ['TERM'])
        self.assertEqual(killpg.call_count, 2)

    @patch.object(cleanup.time, 'monotonic', side_effect=[0, 6, 7])
    @patch.object(cleanup.os, 'getpgrp', return_value=13579)
    @patch.object(cleanup.os, 'killpg', side_effect=[None, None, PermissionError(errno.EPERM, 'KILL denied')])
    def test_kill_error_is_recorded_after_bounded_grace(self, killpg, _, clock):
        code, row = self.receipt(self.proc(0))
        self.assertEqual(code, 1)
        self.assertEqual(row['processGroup']['errors'][0]['operation'], 'KILL')
        self.assertEqual(row['processGroup']['signals'], ['TERM'])
        self.assertEqual(row['processGroup']['signalAttempts'], ['TERM', 'KILL'])
        self.assertFalse(row['processGroup']['noSurvivors'])
        self.assertEqual(killpg.call_count, 3)

    @patch.object(cleanup.os, 'getpgrp', return_value=13579)
    @patch.object(cleanup.os, 'killpg', side_effect=ProcessLookupError(errno.ESRCH, 'absent'))
    def test_known_absent_and_reaped_preserves_success(self, killpg, _):
        code, row = self.receipt(self.proc(0))
        self.assertEqual(code, 0)
        self.assertTrue(row['processGroup']['noSurvivors'])
        self.assertTrue(row['processGroup']['leaderReaped'])
        self.assertTrue(row['processGroup']['cleanupVerified'])
        self.assertTrue(all(call.args[1] == 0 for call in killpg.call_args_list))

    @patch.object(cleanup, 'cleanup_owned_group', side_effect=RuntimeError('failed before helper return'))
    def test_helper_exception_still_writes_incomplete_receipt(self, _):
        code, row = self.receipt(self.proc(None))
        self.assertEqual(code, 1)
        self.assertIsNone(row['actualChildExit'])
        self.assertFalse(row['processGroup']['noSurvivors'])
        self.assertFalse(row['processGroup']['leaderReaped'])
        self.assertEqual(row['reportingErrors'][0]['operation'], 'cleanup')
        self.assertTrue(row['allGuardsExact'])

    @patch.object(cleanup, 'cleanup_owned_group', side_effect=RuntimeError('cleanup failure'))
    def test_guard_failure_not_hidden_and_timeout_flag_retained(self, _):
        rows = []
        def check():
            raise RuntimeError('source guard failure')
        code = cleanup.finish_child(self.proc(None), True, 0, ['fixed-test-command'], check, rows.append)
        self.assertEqual(code, 124)
        self.assertTrue(rows[0]['timedOut'])
        self.assertIsNone(rows[0]['actualChildExit'])
        self.assertFalse(rows[0]['allGuardsExact'])
        self.assertEqual([e['operation'] for e in rows[0]['reportingErrors']], ['cleanup', 'source-check'])

if __name__ == '__main__':
    unittest.main()
