from pathlib import Path
import hashlib, json, tarfile

S = Path('/Users/zacheryspector/studio-scratch')
R = Path('/Users/zacheryspector/The-Movies-headless-program')
E = R / 'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
I = S / '1368-ninth-publication-input-inventory/INPUTS.json'
O = E / '1368-stage/ninth-verification'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(I) == '48c3f12e52c1a6c27a66d455c2604f38481b96587176906dbe5d00c6cf04eee5'
x = json.loads(I.read_text())
assert not x['issues']
files = x['newFiles'].copy()
refs = x['priorReferences']
known = {r['original'] for r in files + refs}
prep = S / '1368-r6-integration-prep'
assert sha(prep / 'MANIFEST.json') == 'fd4251831e6e8241a3bafe913cc04039a629107b192ab70522845fcebb62bf31'
for name, row in json.loads((prep / 'MANIFEST.json').read_text())['files'].items():
    p = prep / name
    assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes']
extra = [p for p in prep.rglob('*') if p.is_file()]
extra += list((S / '1368-ninth-publication-input-inventory').glob('*'))
extra += [S / '1368-independent-review' / n for n in ['R6-INTEGRATION-STATIC.md', '1368-I-NARRATIVE-PREVIEW.md']]
extra += [S / '1368-disk-preflight-refusal/OWNER-RECHECK-01.json', Path(__file__)]
extra += [S / '1368-save46-swept-proposal-r6' / n for n in ['SOURCE-PINS.json', 'ASSEMBLY.json', 'PROVENANCE.json', 'GIT-SNAPSHOT.json', 'root-commit.raw']]
for p in sorted(set(extra)):
    assert p.is_file() and not any(q.is_symlink() for q in [p, *p.parents])
    if str(p) in known:
        continue
    files.append({'path': 'scratch/' + p.relative_to(S).as_posix(), 'original': str(p), 'size': p.stat().st_size, 'sha256': sha(p), 'category': 'closed-parent-supplement'})
    known.add(str(p))
assert len({r['path'] for r in files}) == len(files)
for row in files + refs:
    p = Path(row['original'])
    assert p.is_file() and not any(q.is_symlink() for q in [p, *p.parents])
    assert p.stat().st_size == row['size'] and sha(p) == row['sha256'], str(p)
for a in x['priorArchives']:
    archive = Path(a['archive'])
    assert sha(archive) == a['archiveSha256']
    assert sha(Path(a['manifest'])) == a['manifestSha256']
    with tarfile.open(archive, 'r:gz') as tar:
        for row in refs:
            if row['priorArchive'] != str(archive):
                continue
            member = tar.getmember(row['priorArchiveMember'])
            assert member.isfile() and member.size == row['size']
            assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == row['sha256']
assert not O.exists()
O.mkdir(parents=True)
archive = O / 'evidence.tar.gz'
files.sort(key=lambda r: r['path'])
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for row in files:
        tar.add(row['original'], arcname=row['path'], recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert [m.name for m in members] == [r['path'] for r in files]
    for member, row in zip(members, files):
        assert member.isfile() and member.size == row['size']
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == row['sha256']
for row in files + refs:
    assert sha(Path(row['original'])) == row['sha256']
result = {'status': 'ARCHIVE_VERIFIED', 'sincePublishedHead': x['sincePublishedHead'], 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size, 'file_count': len(files), 'logical_bytes': sum(r['size'] for r in files), 'files': files, 'priorReferences': refs, 'priorArchives': x['priorArchives'], 'closedRuns': x['closedRuns'], 'inventoryExclusionsAtOriginalCutoff': x['excluded'], 'inputInventorySha256': sha(I), 'supplement': 'Later frozen and independently reviewed R6 integration kit plus exact assembled descriptors/root commit, review, inventory package, builder and Owner disk recheck. R6 types and simulation remain unrun.', 'scope': 'Integrated partial fallout, ledger incomplete attempt and cleanup safety; recovery in progress, no main promotion. Source snapshots are reconstructible from preserved prior bytes and exact reviewed deltas.'}
(O / 'MANIFEST.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['status', 'archive_sha256', 'archive_bytes', 'file_count', 'logical_bytes']}))
print('priorReferences', len(refs))
