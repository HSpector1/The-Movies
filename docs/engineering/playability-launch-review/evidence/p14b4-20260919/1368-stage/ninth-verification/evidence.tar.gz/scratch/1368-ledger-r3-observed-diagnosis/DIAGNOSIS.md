# Ledger r3 observed failure: bounded diagnosis

The observed p13a run is incomplete and unaccepted. A cleanup-reporting defect is proved; the cause of the long route duration is not. No patch, retry, process signal, compiler, game run or live edit was performed for this diagnosis. Exact inputs are pinned in `INPUT-PINS.json`; compact measured facts are in `OBSERVED-FACTS.json`.

## What the completed artifacts establish

The formal record at `E/1368-ledger-r3-abc-observed-p13a-r1.json` spans 331.522 seconds and reports the Python child exit as 1. Its source is fixed and the completed postflight reports every live guard exact at `ee7f700ff5b088a508c4a790a65378e36f131fa8`. This is not a recorded Node exit. The output directory contains binding, power, an 81-byte Vitest startup stdout and empty stderr. `CHILD.json`, `RESULT.json`, `data.json` and `vitest.json` are absent. No completed week, ledger row count, phase parity or Node exit can be recovered from those artifacts.

The traceback proves this path:

1. `1368-ledger-parent-prep-r3/run.py:133` calls `helper.cleanup_owned_group(proc)` in `finally` after the bounded wait.
2. `1368-recovery-legacy-prep/run-recovery.py:204` is inside the TERM grace polling loop, after the helper found the launched group present and attempted TERM. The available artifact does not persist whether that TERM syscall succeeded or raced with process disappearance.
3. `owned_group_exists` at lines 180–186 catches only `ProcessLookupError`. Its `os.killpg(pgid, 0)` raises `PermissionError: [Errno 1] Operation not permitted`; the exception escapes.
4. Child-side source revalidation and `CHILD.json` writing at runner lines 134–135 are bypassed. The outer formal recorder and live postflight complete. The parent-side wrapper then raises `FileNotFoundError` at line 179 while reading the missing child receipt.

`timedOut` was only an in-memory local. A wait reaching its 330-second limit is consistent with the duration and path, but this run did not persist that flag. Record it as unknown, not `true`, and do not invent exit −15, 124, successful KILL, a reaped leader or a no-survivors certificate. The parent's later full process census reported no Vitest, Python probe or heavy process; that is a later observation supplied by the parent, not a substitute for the missing cleanup receipt. Its underlying ps artifact was not supplied here. Unknown processes were not touched.

For context only, the completed r3 clean receipts report C0 p13a at 255.293 seconds and ABC p13a at 258.580 seconds, both child 0, no timeout and exact guards. Those receipts do not prove why the observed run lasted longer, nor that a small optimization will fit the existing limits.

## Smallest cleanup and reporting correction to prepare next

Prepare a new local cleanup revision and ledger-runner rebind; do not modify the shared fixed `1368-recovery-legacy-prep/run-recovery.py`, any earlier runner, or the failed output.

- Replace boolean-only group inspection with an explicit result: `absent` only after `ProcessLookupError`, `present` after a successful zero signal, and `inaccessible` with operation/errno/PGID details after `PermissionError`. Never interpret EPERM as absence. Other syscall errors must also be retained and fail closed.
- Retain the owned launched process group and existing bounded TERM/grace/KILL discipline. A permission or ownership-uncertain result cannot authorize signaling an unrelated or newly discovered process. On such a result, stop escalation for that unresolved group, poll/reap the known child where possible, and return a cleanup failure with `noSurvivors: false` and an explicit uncertainty/error field. Do not use broad process-name matches or the parent's unrelated census as a signaling target. If later bounded inspection independently proves absence, report that later fact separately; retain the earlier cleanup error and fail the run rather than hiding it.
- Catch/report errors from TERM, KILL, group inspection and leader reaping. Preserve the actual `proc.poll()` result when available; `null` remains a valid unknown. No unbounded `wait()` may be introduced.
- Retain the wait outcome before cleanup. Use an outer `finally` which attempts source/binding verification and writes a structured child failure receipt even when cleanup fails. Each guard failure is distinct from cleanup failure; `allGuardsExact` can only reflect checks actually completed. Keep stdout/stderr hashes and actual command. The run remains nonzero for timeout or any unverified cleanup/child outcome.
- The outer wrapper must persist a structured failure receipt if `CHILD.json` is absent or malformed, retaining the completed formal record/postflight and artifact pins, rather than replacing the primary failure with an unqualified missing-file traceback. Missing child information stays null; it must never yield acceptance. Preserve the original five recorder artifacts.

These are reporting/cleanup repairs, not evidence that the failed run was a timeout or that a retry is now authorized. Narrow mocked syscall-path tests, if parent authorizes implementation, should cover present→TERM→EPERM, direct EPERM, ESRCH, TERM/KILL permission failures and a normally exited leader with surviving descendants. They must never send real signals in the tests.

## Static observer cost: proved operations versus inferred performance

The exact probe is `1368-ledger-parent-prep-r3/kit/files/tests/1368-ledger-attribution.test.ts`.

- Lines 467–473 and 526–544 already implement the reviewed 417-boundary admission scheme: genesis once, then each of 416 outputs once, with a fresh pre-tick tagged equality check and post-tick input neutrality. Do not remove or weaken these checks.
- Lines 492–504 serialize the full industry argument tuple before and after its real call, plus its returned partial result. Lines 508–519 serialize the market input before `windowFacts`, again to prove that observation neutral, again after the real market call, and serialize the returned state. If all 416 calls complete, that is 2,496 extra full-state/argument traversals plus 416 partial industry-result traversals. The tagged serializer recursively constructs tagged values, sorts object keys and JSON-serializes the result (lines 17–41). The entire argument tuple includes the optional Map when present, so its exact serialization cannot be replaced by ordinary JSON.
- `changedCases` at lines 447–451 searches the entire old case array for each new case, then serializes both records even when they are the same retained object. The market and weekly observers both call it. Industry and weekly employment diffs likewise serialize retained identical row references independently at lines 502 and 541. These are demonstrable repeated operations; no per-operation timing was measured.
- `windowFacts`, owner/account snapshots, proposals and cumulative take/greenlight copies also add work. Their output is causal evidence. The pre-market `windowFacts` neutrality assertion is purposeful, not an expendable duplicate. Source `tick.ts:938` supplies an industry state assembled after prior phase work; `tick.ts:1181–1182` runs lifecycle settlement and ranking/archive work around/after market. Neither observer's input/output can be assumed identical to the public tick boundary for digest reuse.

The smallest defensible observation optimization is local to record diffs:

1. Preserve the existing full argument/input neutrality assertions at exactly their current positions. Only afterward, when comparing an old/new record pair, skip the two `snap` calls if the references are identical. Comparing the same retained record with itself cannot report a difference; changed references still undergo the exact tagged comparison and copied before/after output. Apply this consistently to `changedCases` and the two employment-diff sites. Do not cache mutable-state hashes or infer whole-state equality from a reference.
2. In `changedCases`, build a local old-case index once per call, retaining the *first* old case for each exact existing `caseKey`, then iterate new cases in their original order. This is equivalent to the original `.find` even if duplicate keys exist; it does not rely on a new uniqueness assumption. Preserve the same `copy` and result order.

Those changes retain the output schema, every history assertion, real call count and order, full phase snapshots, 417 whole admissions, original classifier, exact two seeds, 416 ticks, 300-second leaf and 330-second outer bound. They do not change ordinary route actions or source pins. They avoid identifiable redundant row work without dropping causal evidence. Their benefit is unmeasured and may be insufficient; do not promise completion or add a blind retry. A streaming replacement of the full tagged serializer, phase reordering, discarded snapshots, resumed partial runs and extended deadlines are outside this smallest recommendation.

After a separately reviewed implementation and parent-selected bounded verification, the existing clean/observed comparator must still establish equality of every weekly row, full tagged state/RNG digest, accounting/history output and final state. Existing clean runs cannot certify a newly altered probe automatically; any reuse requires an explicit exact-output/unchanged-law review. Current ledger cardinality expectations remain untouched. There is no acceptance of either seed's final attribution in this diagnosis.
