# Four-file backward residual correction

Prepared only against the exact immutable r5 preimages in FILE-INVENTORY.json. Parent approved the bounded diagnosis at `1368-r5-backward-residual-diagnosis`, manifest dc8a0b166526c7637c2db79d9a9fbbd6fbea0e0151395f8c4215493005aa3d92. No production, live/r5, fixture, helper, index, assembly or runtime change was made. No test/typecheck executed.

`backward-residuals.patch` affects only:

- `tests/p14c3-cohort-transition.test.ts`, J7: retain the original real downward chain, require all three recorded recovery authorities, assert its exact anchored first refusal, compare the complete envelope to its original snapshot, and re-admit current46 with another neutrality check.
- `tests/p14c3-dual-extensions.test.ts`, shared X5 for actor→director and actor→writer: explicitly admit the current envelope before refusal; require nonnull cutting, all historical refunds zero and no disposal receipt; require the exact since-only refusal, unchanged complete input and strict46 read afterward. The existing accepted(loaded) assertion stays.
- `tests/p14p3-directing-promises.test.ts`, D14: wrap the entire existing independently authored expected-state expression in the existing expected-only withEmptyRecovery helper; explicitly admit migrated46. All genuine old inputs, legacy initializers, full equality and real reverse chains remain.
- `tests/p14p4p5-opportunities.test.ts`, Q04: the same expected-only wrapper around its full existing expected expression. Existing strict46 admission, firstTakeSubjects proof, old-input neutrality and reverse chain remain untouched.

No describe/it title changed, including the two parameterized X5 cases. TITLE-IDENTITIES.json records that no identity mapping is required. D07/D18 are unchanged. Routes, seeds, target weeks, timeouts, caches, fixture pins and every unrelated assertion remain unchanged.

The measured raw J7 message contains since/refund/disposal; both X5 messages contain since only. These current histories cannot lawfully project to45, so the older rank guard is explicitly masked. Comments name the separately retained rank-root-downgrade-recorded-quarter-refuses and rank-root-downgrade-frozen-builders-refuse controls in p15a2-power-ranking-archive.test.ts. No optional genuine45 fixture or control is added before those controls' outcome establishes a need. The correction does not claim the masked older guards executed in J7/X5.

For D14/Q04, the completed displayed operands differ only by four null cutting and four zero historical refund additions apiece; the diagnostic evidence retains exact string hashes and equality of all other text. The expected helper is unchanged and rejects preexisting recovery keys; it never supplies production input. Later loop entries/assertions are still newly unmasked obligations until original-leaf execution. No actual history is stripped, no authority cast is added and no mismatch is hidden by a new digest, tolerance or expected broken output.

Independent static review precedes parent composition, appropriate types and the original affected leaves on the final integrated source. A source-only patch is not GREEN or broad closure. The unchanged expected-helper source is pinned in REFERENCES.json to make its review dependency explicit.
