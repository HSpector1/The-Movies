# R5 selected-report attribution adapter

Prepared, not executed. This new package leaves the original note, reviewed v2 tool, original baseline reports, r5 tree and integration runner untouched. No game/runtime/typecheck, report processing, growing output read, source/index edit or fixture payload access occurred. Python AST checks only verify syntax. Independent static review is required before use.

The adapter binds exactly the current r5 source/assembly/runner/config/selection/fixture maps and the scratch HEAD/index/stage plus Node/Vitest/TypeScript entrypoint identities previously recorded by the completed release run. R5-BINDING.json documents that origin; the coordinator publication HEAD remains an explicit argument and must match the selected run and its required types run. Future source or runner changes require a separate reviewed rebind, not edited pins in this package.

reviewed_v2.py is a byte-for-byte copy of the reviewed multiplicity-preserving attribute.py. legacy_raw_parser.py and PARSER-ORIGIN.json are also copied byte-for-byte. The adapter imports them only after manifest verification and reuses json_rows, raw_detail, normalize, compare and raw_parse without changing their code or grammar. Every originalAssertion, file/assertion ordinal, display multiplicity, suite message and raw shared frame remains available. All baseline paths are literal hash/size bindings in INPUT-PINS.json.

The added code owns only r5 receipt admission, pinned file selection, baseline projection and result disposition. It requires closed formal record and postflight, equal pre/post source/index/manual guards, exact record/raw/patch hashes, exact child command and printed-result identity, actual child versus recorder consistency, and report timing/selection/count reconciliation. It independently admits the same-source six-command types prerequisite and compares its full declared hash map. It does not reread source-tree or fixture payloads: the pinned inventory and recorded pre/post verification provide that evidence. No change to the runtime runner is proposed.

Modes are backward, p15, current, helper-consumers, ui, release and trust. The first four plus release/trust compare against core; ui compares against UI. Each produces two raw-primary failure comparisons: accepted 1361-M3 and unswept 1368-E. Only exact selected files enter each comparison; all other baseline failures are explicitly NOT_SELECTED. Backward16 is a core file selection, not d16. The original baseline count is never imposed on new results.

Raw NEW/GONE/CHANGED/SAME identities are preserved. GONE has an additional actual-current-occurrence disposition; only one exact original identity actually passing gets EXECUTED_PASS, and this still is not a broad product-repair claim. Missing, renamed, skipped, todo, duplicate or setup-masked identities require review. Complete failure-message arrays remain in the current and selected unswept case rows, independently of primary equality. Raw suite and case occurrences are counted separately. Duplicate failure titles refuse matching rather than collapse, while all rows are retained. Existing title mappings are emitted as a separate declared-relationship artifact, never applied to raw keys or rows. Trust's imported replacement does not imply the original genesis premise passed.

Each invocation is independent. Overlapping modes must not be summed into unique coverage; compare their per-report locators only within each report. Parser completion and completeIdentityAttribution do not mean tests passed. Inspect SUMMARY issues, suite errors, skipped/todo states and actual child status. Ambiguous raw matching emits incomplete comparison evidence and does not guess identities.

After independent review and only after the requested report is completed, invoke:

```sh
python3 /Users/zacheryspector/studio-scratch/1368-r5-fallout-comparison-prep-r3/attribute_r5.py MODE --run-id r1 --types-run-id ACTUAL_TYPES_RUN_ID --head ACTUAL_RECORDED_PUBLICATION_HEAD --package-sha REVIEWED_MANIFEST_SHA --output /Users/zacheryspector/studio-scratch/1368-r5-attribution-MODE-r1
```

Replace MODE with one supported literal mode. Output must be new and exclusive, outside live, r5 source, runner and adapter directories; dangling symlinks refuse. Completed release/trust are eligible first examples, but were not processed during preparation. All read artifacts are rehashed before exclusive output creation. Output includes its own exact file manifest, full inventories/messages, raw comparisons, declared title relationships and input provenance. This is selected evidence attribution only, not 1363-V, a broad gate, landing authority or checkpoint closure.

Revision 3 changes only import-time bytecode suppression: sys.dont_write_bytecode is true before either copied module is imported, so attribution cannot create __pycache__ inside the fixed package. Revision 2 remains unchanged. The diff records the full code delta; no report was executed.
