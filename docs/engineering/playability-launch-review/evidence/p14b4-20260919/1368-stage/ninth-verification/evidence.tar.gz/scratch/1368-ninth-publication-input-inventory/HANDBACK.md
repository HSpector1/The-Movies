# Ninth publication input inventory

Frozen input inventory only, since published `ee7f700ff5b088a508c4a790a65378e36f131fa8`. No archive, live repository write, Git mutation, source assembly, compiler or game execution was performed. `INPUTS.json` supplies 209 new files (23,880,639 logical bytes) and 86 exact prior references (15,178,445 logical bytes). Every selected file was byte-hashed, checked against any declaring manifest/receipt pin, and rehashed for stability. Issues are empty.

Prior references name exact archive/member/hash combinations from accepted fifth, sixth, seventh and eighth manifests, including the eighth R5 preparation supplement. Compressed archives were not reread or extracted. Their archive hashes are taken from their accepted manifests, not newly verified here. The parent archive builder must apply its usual archive/member verification before publication. No full source tree, dependency tree, Git directory or duplicate binary/archive payload is included.

Included scope:

- Actual R5 assembly/source/provenance descriptors, root commit bytes and Git snapshot; four closed types/release/trust/backward runs, lane logs and five formal artifacts per run; the already published R5 kit as exact prior member references where bytes match.
- The P15 disk-floor refusal log and lane metadata. Its output directory was verified empty, with all five formal run artifacts absent. `INPUTS.json` records that fact; there is no invented P15 result or simulated execution.
- Frozen attribution adapters r2/r3, all three selected attribution products and their exact named inputs/reviews. Old baseline bytes are referenced to prior archives rather than recopied. Raw identities, failures, masks and title relationships remain intact.
- Newly closed ledger r3 ABC types and clean results; incomplete observed output, complete formal guards, later process audit and source diagnosis. Its recorder child exit is 1; missing Node exit, timeout flag and cleanup result remain unknown.
- Frozen ledger r4 kit/static review, five actual arm04 assembly descriptors and the parent assembly receipt. Seven mocked cleanup safety tests completed successfully with exact formal guards and independent measured review. No fresh r4 types or simulator run occurred; r3 C0 results remain historical evidence rather than tests of arm04.
- The completed eighth lossless compression transaction and all three reviews, plus the disk-refusal audit. Cache clearing remains a failed partial attempt with no material reclaim; approximately 62 MiB of root-owned cache remained. Neither the historical compression success nor this inventory clears the current heavy-job floor or completes the Owner's requested 1.5 GiB recovery.
- The separately frozen backward diagnosis, original residual patch and corrected r2 package. R2 manifest is `de463ccd2ba578736d601b0895ca51930a724ad85153c702c9cba561590ce6a9`; its static review is preserved. This is preparation preservation, not application or runtime acceptance.

The eight closed-run entries include failures and the mocked safety prerequisite. Types passed six commands; release retained 5 passes/2 skips; trust retained 10 passes/1 failure/2 TODO; backward retained 278 passes/7 failures. These are selected, overlapping scopes, not unique broad coverage or global resolution counts. All statuses and residuals remain governed by their exact receipts and reviews.

R6 integration preparation remains mutable and is excluded in full. Any later frozen R6 package, ledger r4 types/run or additional completion evidence belongs in a separately pinned supplement. Do not edit this inventory to absorb later work. The parent may build the ninth archive after reviewing these fixed inputs; no compressed-size or storage-savings claim is made here.
