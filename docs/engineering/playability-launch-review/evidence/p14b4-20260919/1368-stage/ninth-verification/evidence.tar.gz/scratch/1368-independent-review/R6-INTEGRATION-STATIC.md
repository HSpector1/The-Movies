# R6 integration static review

PROCEED with isolated assembly and fresh R6 verification when lane/storage prerequisites permit. Manifest `fd4251831e6e8241a3bafe913cc04039a629107b192ab70522845fcebb62bf31`; assembler `98e8e0e0de7abcc397785297ec700ecb7b306cc7e7d4609289a081655f01e78b`; runner `4302b3103e06539fcdcf0a86a9eb9ce44fefdbebdceddc3295691ff5d5440c9c`. All package hashes independently verified.

Expected source `2d92af276435275d7ec45554e188962780f0e08467a17dbe42d7ced5f6c85f64` and assembly `b3dcf41960c58528339415fa822cc3e8555738225275ae5f9ff107b68e28b508` retain exactly 1,626 regular files. The map comparison changes only the four approved backward-residual test files; all 188 production files and other 1,622 files remain identical. Fixture pins are byte-identical to R5. The assembler verifies the exact R5 predecessor, applies only the approved r2 patch into a new exclusive clone, preserves dependency links and validates both inventories. No automatic Git initialization or runtime is introduced.

All original selections remain identical. The new backward-residual mode selects the four entire modified files without leaf filters, so D07/D18 and later masked assertions remain present. Fresh exact R6 six-command types are required; prior R5 receipts cannot satisfy the new source/runner binding. Recorder, HEAD/index, fixture guards, disk floor and inherited synchronous lifecycle/deadlines are unchanged; no new outer watchdog is claimed.

This is preparation approval, not runtime acceptance. Separate ranking controls and all newly reachable later assertions remain required; no preemptive guard repin, broad acceptance, landing or checkpoint conclusion follows. No assembly, compiler, game runtime, fixture payload read or live mutation was performed.
