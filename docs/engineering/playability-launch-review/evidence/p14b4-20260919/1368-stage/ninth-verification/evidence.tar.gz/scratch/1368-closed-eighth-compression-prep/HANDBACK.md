# Three completed archived evidence files: bounded compression preparation

Prepared only. The explicit whitelist contains exactly the two completed guarded-writing trace files and the completed ledger r3 C0-clean data.json named by the parent. No other file is eligible. All three byte streams were compared directly with their exact eighth-archive members, including sizes and SHA-256; the compressed archive itself matches its accepted manifest hash. Their completed receipts report actual child/recorder 0, no timeout and exact guards, and bind those same data hashes. See PREFLIGHT.json.

Read-only metadata inspection found regular files, single links, flags zero and no symlink ancestry. Mode, owner/group, mtime, ACL and xattr hashes are recorded. Exact per-file lsof checks returned 1 with empty stdout/stderr. This is an instantaneous observation, not a lock: parent must ensure all consumers/writers and the recorded lane are idle before planning or application. The transaction repeats lsof before staging and immediately before replacement.

The three files occupy 43,819,008 physical bytes (41.79 MiB), with 43,815,039 logical bytes. This is the maximum reclaimable allocation, not measured savings. The repeated JSON traces are plausible compression candidates, but actual savings cannot be asserted before staging; the unchanged utility accepts each replacement only when allocation decreases. This narrow whitelist cannot promise a 5.25 GiB margin. No broader fallback is included.

compress.py is the reviewed cold-dependency-next compressor with only four substitutions: exclusive output directory, exact whitelist hash, count 3 and scope label. compress.diff shows the complete delta. Staging, byte/metadata verification, ditto arguments/binary hash, raw index and bounded Git guards, no-active-run check, lsof gates, fsync/journal handling, atomic replacement and 5.25 GiB stop target are unchanged. The 5 GiB heavy-lane floor is unchanged and must be checked from the actual completed result. Inode, ctime, allocation and compressed flag intentionally change; logical evidence, names and recorded metadata remain identical. The utility may remove only its own newly created redundant no-savings temporary; it never removes an original evidence file or an existing temporary.

PREFLIGHT.json is not an executable transaction plan: it does not substitute for the fresh Git/index/inode/metadata/ditto capture performed by plan mode. No compressor mode was run, no compression or archive was created, and no Git/source mutation occurred. Only byte/hash reads, metadata/ACL/xattr reads, exact lsof checks and static Python AST parsing were performed.

After independent static review, the parent creates the new results directory, generates a fresh plan while the lane is idle, reviews its exact hash, then separately authorizes application:

```sh
mkdir /Users/zacheryspector/studio-scratch/1368-closed-eighth-compression-prep/results
/usr/bin/python3 /Users/zacheryspector/studio-scratch/1368-closed-eighth-compression-prep/compress.py plan --manifest /Users/zacheryspector/studio-scratch/1368-closed-eighth-compression-prep/results/plan-r1.json
/usr/bin/python3 /Users/zacheryspector/studio-scratch/1368-closed-eighth-compression-prep/compress.py apply --manifest /Users/zacheryspector/studio-scratch/1368-closed-eighth-compression-prep/results/plan-r1.json --manifest-sha ACTUAL_REVIEWED_PLAN_SHA --journal /Users/zacheryspector/studio-scratch/1368-closed-eighth-compression-prep/results/apply-r1.jsonl
```

No command executes automatically. Preserve any refused attempt and owned staging under the existing transaction procedure. This preparation gives no authority to alter raw state, delete evidence, expand the whitelist or touch active binaries.
