from pathlib import Path
import ast,hashlib,json,shutil,difflib
S=Path('/Users/zacheryspector/studio-scratch');P=S/'1368-ledger-parent-prep-r4';O=S/'1368-ledger-parent-prep-r3';A=S/'1368-ledger-arms-04';B=S/'1368-ledger-arms-03'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(v if isinstance(v,str) else json.dumps(v,indent=2)+'\n')
def diff(a,b,old,new):return ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=old,tofile=new))
for source in (O/'kit').rglob('*'):
 if source.is_file():
  dest=P/'kit'/source.relative_to(O/'kit');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
probe='files/tests/1368-ledger-attribution.test.ts';old=(O/'kit'/probe).read_text();v=old
v=v.replace('import { lstatSync, readFileSync, realpathSync, writeFileSync }', 'import { appendFileSync, lstatSync, readFileSync, realpathSync, writeFileSync }')
needle="""  return after.talentMarket.cases.filter(k => {
    const old = before.talentMarket.cases.find(x => caseKey(x) === caseKey(k))
    return old === undefined || snap(old) !== snap(k)
  }).map(copy)"""
replacement="""  const firstByKey = new Map<string, GameState['talentMarket']['cases'][number]>()
  for (const old of before.talentMarket.cases) if (!firstByKey.has(caseKey(old))) firstByKey.set(caseKey(old), old)
  return after.talentMarket.cases.filter(k => {
    const old = firstByKey.get(caseKey(k))
    return old === undefined || (old !== k && snap(old) !== snap(k))
  }).map(copy)"""
assert v.count(needle)==1;v=v.replace(needle,replacement)
needle='old.employment[ordinal] === undefined || snap(e) !== snap(old.employment[ordinal])'
assert v.count(needle)==2;v=v.replace(needle,'old.employment[ordinal] === undefined || (e !== old.employment[ordinal] && snap(e) !== snap(old.employment[ordinal]))')
needle="  const output = process.env.LEDGER_OUTPUT; assert.ok(output); exclusive(output)"
v=v.replace(needle,needle+"\n  const progress = process.env.LEDGER_PROGRESS; assert.ok(progress); exclusive(progress)\n  writeFileSync(progress, '', { flag: 'wx' })\n  const diagnosticStarted = process.hrtime.bigint()\n  let progressRows = 0")
needle='      admittedBoundary = nextAdmission\n      return answer'
v=v.replace(needle,"""      admittedBoundary = nextAdmission
      if (answer.market.tick % 52 === 0) {
        assert.ok(++progressRows <= 8)
        appendFileSync(progress, JSON.stringify({ week: answer.market.tick,
          elapsedSeconds: Number(process.hrtime.bigint() - diagnosticStarted) / 1e9 }) + '\\n')
      }
      return answer""")
write(P/'kit'/probe,v);write(P/'PROBE-R3-TO-R4.diff',diff(old,v,'r3/'+probe,'r4/'+probe))
km=json.loads((O/'kit/MANIFEST.json').read_text());km[probe]=sha(P/'kit'/probe);write(P/'kit/MANIFEST.json',km)
origins={};proof={};combined={}
for arm in ['C0','ABC']:
 previous=json.loads((B/arm/'SOURCE-PINS.json').read_text());now=dict(previous);now['tests/1368-ledger-attribution.test.ts']=sha(P/'kit'/probe)
 write(P/'templates'/f'{arm}-SOURCE-PINS.json',now)
 origins[arm]={n:str(P/'kit/files'/n if n=='tests/1368-ledger-attribution.test.ts' else B/arm/'tree'/n) for n in now}
 asm=json.loads((B/arm/'ASSEMBLY.json').read_text());asm['sourceOrigin']=str(B/arm/'tree');asm['sourcePinsSha256']=sha(P/'templates'/f'{arm}-SOURCE-PINS.json');asm['kitManifestSha256']=sha(P/'kit/MANIFEST.json');asm['priorAssemblySha256']=sha(B/arm/'ASSEMBLY.json')
 for n,row in asm['files'].items():
  row['origin']=origins[arm][n];row['sha256']=now[n]
  if n=='tests/1368-ledger-attribution.test.ts':row['bytes']=(P/'kit'/probe).stat().st_size
 write(P/'templates'/f'{arm}-ASSEMBLY.json',asm)
 combined[arm]={'sourcePinsSha256':sha(P/'templates'/f'{arm}-SOURCE-PINS.json'),'assemblySha256':sha(P/'templates'/f'{arm}-ASSEMBLY.json'),'files':197,'logicalBytes':sum(x['bytes'] for x in asm['files'].values())}
 proof[arm]={'oldSourcePinsSha256':sha(B/arm/'SOURCE-PINS.json'),'productionFileCount':188,'productionChanges':{},'onlyFileChange':{'tests/1368-ledger-attribution.test.ts':{'before':previous['tests/1368-ledger-attribution.test.ts'],'after':now['tests/1368-ledger-attribution.test.ts']}},'unchangedOriginalOracleSha256':now['tests/1368-ledger-original.ts']}
 assert [n for n in now if now[n]!=previous[n]]==['tests/1368-ledger-attribution.test.ts']
write(P/'templates/ASSEMBLY.json',combined);write(P/'ORIGINS.json',origins);write(P/'SOURCE-DIFFERENCE-PROOF.json',proof)
a=(O/'assemble.py').read_text().replace('with one diagnostic-only duplicate-admission correction.','with only equivalent record-diff work and bounded progress observation.')
a=a.replace("P = S / '1368-ledger-parent-prep-r3'","P = S / '1368-ledger-parent-prep-r4'").replace("A = S / '1368-ledger-arms-03'","A = S / '1368-ledger-arms-04'").replace("B = S / '1368-ledger-arms-02'","B = S / '1368-ledger-arms-03'")
a=a.replace('98005b47507551d2f9c0c261d74128e76fe3e6898dfa7ab0535f132c6c52d474',sha(B/'ASSEMBLY.json'))
write(P/'assemble.py',a);write(P/'assemble.py.diff',diff((O/'assemble.py').read_text(),a,'r3/assemble.py','r4/assemble.py'))
r=(O/'run.py').read_text().replace('1368-ledger-parent-prep-r3','1368-ledger-parent-prep-r4').replace('1368-ledger-arms-03','1368-ledger-arms-04').replace('1368-ledger-recorded-runs-r3','1368-ledger-recorded-runs-r4').replace("stem = '1368-ledger-r3-'","stem = '1368-ledger-r4-'")
r=r.replace("LEGACY = S / '1368-recovery-legacy-prep/run-recovery.py'","CLEANUP = P / 'cleanup.py'")
# Preserve old legacy helper pin as historical dependency; import only the new local helper.
r=r.replace("spec_from_file_location('reviewed_cleanup', LEGACY)","spec_from_file_location('reviewed_cleanup', CLEANUP)")
for arm in ['C0','ABC']:
 for name in ['ASSEMBLY.json','SOURCE-PINS.json']:r=r.replace(sha(B/arm/name),sha(P/'templates'/f'{arm}-{name}'))
r=r.replace(sha(B/'ASSEMBLY.json'),sha(P/'templates/ASSEMBLY.json')).replace(sha(O/'kit/MANIFEST.json'),sha(P/'kit/MANIFEST.json'))
# Local helper is checked by the package manifest; preserve explicit pin too.
r=r.replace('FIXED = {','FIXED = {\n    P / \'cleanup.py\': '+repr(sha(P/'cleanup.py'))+',')
r=r.replace("receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped']", "receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped'] and receipt['processGroup']['cleanupVerified'] and not receipt['reportingErrors']")
# Small fresh clean prerequisite only for observed; commands and artifacts retain original verification law.
pos=r.index('def child(out, binding_pin):')
r=r[:pos]+'''def prior_clean(path, pin, current, seed):
    safe(path); assert sha(path) == pin
    receipt = json.loads(path.read_text())
    assert receipt['mode'] == 'clean' and receipt['arm'] == 'ABC' and receipt['seed'] == seed
    assert receipt['command'] == command_for('clean', path.parent)
    assert receipt['allGuardsExact'] and receipt['actualChildExit'] == receipt['recorderChildExit'] == 0 and not receipt['timedOut']
    assert receipt['processGroup']['cleanupVerified'] and receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped'] and not receipt['reportingErrors']
    for name in ['arm', 'sourcePinsSha256', 'assemblySha256', 'kitManifestSha256', 'inputPinsSha256', 'runnerManifestSha256', 'entrypoints', 'regularFiles']:
        assert receipt['pins'][name] == current[name], 'clean source differs: ' + name
    for name, row in receipt['artifacts'].items():
        f = Path(name); safe(f); assert sha(f) == row['sha256'] and f.stat().st_size == row['bytes']
    data = json.loads((path.parent / 'data.json').read_text())
    assert data['completed'] is True and data['sourcePostflight'] is True and data['mode'] == 'clean' and data['arm'] == 'ABC' and data['seed'] == seed and data['horizon'] == 416
    assert len(data['weekly']) == 416 and [x['week'] for x in data['weekly']] == list(range(1, 417))

'''+r[pos:]
r=r.replace("    # Import only after verifying", "    if b['mode'] == 'observed': prior_clean(Path(b['cleanReceipt']), b['cleanReceiptSha256'], b['pins'], b['seed'])\n    # Import only after verifying")
r=r.replace("LEDGER_OUTPUT=str(out / 'data.json'))", "LEDGER_OUTPUT=str(out / 'data.json'), LEDGER_PROGRESS=str(out / 'progress.jsonl'))")
start=r.index('    start = time.monotonic(); timed_out = False\n',r.index('def child('));end=r.index('\ndef main():',start)
r=r[:start]+'''    start = time.monotonic(); timed_out = False; wait_error = None
    with (out / 'stdout.txt').open('x') as stdout, (out / 'stderr.txt').open('x') as stderr:
        proc = subprocess.Popen(b['command'], cwd=T, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            # Persist launch identity before the bounded wait, independently of final reporting.
            write(out / 'LAUNCH.json', {'nodePid': proc.pid, 'ownedProcessGroup': proc.pid,
                'startNewSession': True, 'monotonicStarted': start, 'command': b['command'], 'bindingSha256': binding_pin})
            try: proc.wait(timeout=330)
            except subprocess.TimeoutExpired: timed_out = True
        except Exception as error:
            wait_error = error
        finally:
            def check_source():
                return verify(b['publicationHead'], b['manifestPin'], b['arm']) == b['pins'] and sha(out / 'binding.json') == binding_pin
            def write_receipt(row):
                row.update(stdoutSha256=sha(out / 'stdout.txt'), stderrSha256=sha(out / 'stderr.txt'))
                write(out / 'CHILD.json', row)
            exit_code = helper.finish_child(proc, timed_out, start, b['command'], check_source, write_receipt, wait_error)
    return exit_code
'''+r[end:]
r=r.replace("ap.add_argument('--types-receipt'); ap.add_argument('--types-receipt-sha256');", "ap.add_argument('--types-receipt'); ap.add_argument('--types-receipt-sha256'); ap.add_argument('--clean-receipt'); ap.add_argument('--clean-receipt-sha256');")
r=r.replace("    assert shutil.disk_usage(R).free >= 5 * 1024**3", "    if a.mode == 'observed':\n        assert a.clean_receipt and a.clean_receipt_sha256\n        prior_clean(Path(a.clean_receipt), a.clean_receipt_sha256, pins, a.seed)\n    else: assert not a.clean_receipt and not a.clean_receipt_sha256\n    assert shutil.disk_usage(R).free >= 5 * 1024**3")
r=r.replace("'typesReceiptSha256': a.types_receipt_sha256, 'outerCapSeconds'", "'typesReceiptSha256': a.types_receipt_sha256, 'cleanReceipt': a.clean_receipt, 'cleanReceiptSha256': a.clean_receipt_sha256, 'outerCapSeconds'")
start=r.index("    child_result = json.loads((out / 'CHILD.json').read_text()); assert child_result['allGuardsExact']")
end=r.index("    if a.mode != 'types' and expected_exit == 0:",start)
r=r[:start]+'''    # Reporting failure is evidence, never an invented Node exit or successful cleanup.
    try:
        child_result = json.loads((out / 'CHILD.json').read_text())
        assert isinstance(child_result, dict) and child_result['command'] == command
        assert isinstance(child_result['processGroup'], dict) and isinstance(child_result['reportingErrors'], list)
        assert isinstance(child_result['timedOut'], bool) and isinstance(child_result['allGuardsExact'], bool)
        assert child_result['actualChildExit'] is None or type(child_result['actualChildExit']) is int
        group = child_result['processGroup']
        assert all(type(group[key]) is bool for key in ['cleanupVerified', 'noSurvivors', 'leaderReaped'])
        code = child_result['actualChildExit']
        failed_reporting = bool(child_result['reportingErrors']) or not child_result['allGuardsExact']
        expected_exit = 124 if child_result['timedOut'] else (1 if failed_reporting or not group['cleanupVerified'] or not group['noSurvivors'] or not group['leaderReaped'] else (code if isinstance(code, int) and code >= 0 else 1))
        assert record['exitCode'] == post['exitCode'] == expected_exit, 'Node/cleanup/recorder exit mismatch'
    except Exception as error:
        paths = [f for f in out.iterdir() if f.is_file()] + [E / (stem + suffix) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']]
        for f in paths: safe(f)
        write(out / 'WRAPPER-FAILURE.json', {'status': 'INCOMPLETE_CHILD_REPORT', 'actualChildExit': None,
            'timedOut': None, 'noSurvivors': None, 'recorderChildExit': record['exitCode'],
            'livePostflightExact': True, 'command': command, 'errorType': type(error).__name__, 'error': str(error),
            'artifacts': {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in paths}})
        return 1
'''+r[end:]
# Do not overwrite a child-side false guard fact with outer live postflight truth.
r=r.replace("'recorderChildExit': record['exitCode'], 'allGuardsExact': True, 'artifacts'", "'recorderChildExit': record['exitCode'], 'allGuardsExact': child_result['allGuardsExact'], 'livePostflightExact': True, 'artifacts'")
r=r.replace("        assert report['numTotalTests'] == report['numPassedTests'] == 1 and report['numFailedTests'] == 0", "        assert report['numTotalTests'] == report['numPassedTests'] == 1 and report['numFailedTests'] == 0\n        progress = [json.loads(line) for line in (out / 'progress.jsonl').read_text().splitlines()]\n        assert [row['week'] for row in progress] == list(range(52, 417, 52))\n        assert all(set(row) == {'week', 'elapsedSeconds'} and isinstance(row['elapsedSeconds'], (int, float)) and 0 <= row['elapsedSeconds'] < float('inf') for row in progress)\n        assert all(left['elapsedSeconds'] <= right['elapsedSeconds'] for left, right in zip(progress, progress[1:]))")
write(P/'run.py',r);write(P/'run.py.diff',diff((O/'run.py').read_text(),r,'r3/run.py','r4/run.py'))
for name in ['run.py','assemble.py','cleanup.py','test_cleanup.py']:ast.parse((P/name).read_text())
paths=[O/'MANIFEST.json',O/'run.py',O/'assemble.py',O/'kit/MANIFEST.json',O/'kit'/probe,B/'ASSEMBLY.json',S/'1368-ledger-r3-observed-diagnosis/MANIFEST.json',S/'1368-ledger-r3-observed-diagnosis/DIAGNOSIS.md',S/'1368-recovery-legacy-prep/run-recovery.py']
write(P/'PREIMAGES.json',{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths})
print(json.dumps({'probe':sha(P/'kit'/probe),'kit':sha(P/'kit/MANIFEST.json'),'cleanup':sha(P/'cleanup.py'),'runner':sha(P/'run.py'),'assembly':sha(P/'templates/ASSEMBLY.json')}))
