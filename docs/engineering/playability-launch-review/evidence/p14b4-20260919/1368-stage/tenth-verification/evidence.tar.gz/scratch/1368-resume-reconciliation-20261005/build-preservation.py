from pathlib import Path
import hashlib,json,tarfile
r=Path('/Users/zacheryspector/The-Movies-headless-program')
s=Path('/Users/zacheryspector/studio-scratch')
e=r/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
out=e/'1368-stage/tenth-verification'
assert not out.exists()
files={}
for rel in ['1368-r6-integration-prep/run-types-r1','1368-r6-integration-prep/run-backward-residual-r1','1368-r6-attribution-backward-residual-r1','1368-resume-reconciliation-20261005']:
 for p in sorted((s/rel).rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():files['scratch/'+p.relative_to(s).as_posix()]=p
for rel in ['1368-independent-review/R6-BACKWARD-RESIDUAL-MEASURED.md',*[f'heavy-queue/1368-r6-{mode}-r1-resume.log'+suffix for mode in ['types','backward-residual','p15'] for suffix in ['', '.meta']]]:
 p=s/rel;assert p.is_file() and not p.is_symlink(),p;files['scratch/'+rel]=p
for mode in ['types','backward-residual']:
 for suffix in ['.json','.txt','.patch','-preflight.json','-postflight.json']:
  p=e/('1368-swept-r6-'+mode+'-r1'+suffix);assert p.is_file() and not p.is_symlink();files['repo/'+p.relative_to(r).as_posix()]=p
members={name:{'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for name,p in sorted(files.items())}
out.mkdir(parents=True)
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert sorted(tf.getnames())==sorted(members)
 for name,row in members.items():
  b=tf.extractfile(name).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
  assert Path(row['source']).read_bytes()==b
manifest={'scope':'Completed exact R6 types/residual results, selected attribution, independent review, pre-recording P15 refusal and live-repository reconciliation. No candidate source or assertion changes.','coordinatorHead':'d82f451e14d31de44c92472bb38130a4b9b04419','archive':{'path':str(archive.relative_to(r)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size},'memberCount':len(members),'logicalBytes':sum(v['bytes'] for v in members.values()),'members':members,'emptyDirectoriesPreservedAtOrigin':[str(s/'1368-r6-integration-prep/run-p15-r1')],'priorSourceAndKits':'Already published in eighth/ninth archives and attribution supplement at d82f451e; not copied or regenerated. Original scratch retained.'}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'},indent=2))
print('MANIFEST sha256',hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest())
