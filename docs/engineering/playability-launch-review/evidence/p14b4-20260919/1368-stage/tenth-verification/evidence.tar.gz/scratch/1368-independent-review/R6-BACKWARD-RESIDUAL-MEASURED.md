# R6 backward-residual measured review

Disposition: ACCEPT the fresh R6 types prerequisite and completed bounded backward-residual evidence, including the five corrected leaf results and exact failure attribution. This is 49 PASS / 2 FAIL, not an all-green selection, broad acceptance, landing approval, recovery closure or promotion.

Read-only independent review on 2026-10-05. Read HANDOFF, 1368-I, the R6 integration and attribution static reviews, reviewed source patch/runner, completed bindings/results/raw output/Vitest, all ten formal records and fixed comparison inputs. No tests, Node, game runtime, fixture decompression, live source/index/HANDOFF mutation or nested delegation was performed. Only this new review file was written.

## Source and formal identity

Both closed runs bind coordinator `d82f451e14d31de44c92472bb38130a4b9b04419`, frozen scratch HEAD `a59301c631531d9189aef5ee1827d6886db78f45`, tree `80919a922661f9202bc64ad43ef93da3f8472b7c`. Independently hashed all 1,626 consumed regular source files, checked the exact inventory, scratch HEAD/tree/index/stage hashes, both reviewed package manifests and their members, attribution output manifest and every artifact pinned by its summary. All matched. R5/R6 descriptor comparison changes exactly the four selected tests; all 188 production files and 1,622 other files remain identical.

Both bindings have identical source/tool/fixture pins. The residual prerequisite names the exact fresh types binding, result, six raw command outputs and five formal records, all hash-verified. Four typechecks (root/UI/Bridge/producers) and both generators exited 0. Types RESULT is `ddff16e75c29364016f787985fbac5f581bd25affdb7a95fbda89238e12f5414`.

For each run, formal start/end source identity, pre/post HEAD and preflight remote equal the coordinator SHA. Pre/post source inventory, index, staged entries, manual inputs and scope are identical. Both patches are empty, both untracked-source lists empty, formal signal/error null, Node v20.20.2, power receipts AC. Formal postflight hashes match the actual record/raw/patch bytes. Types actual child/recorder/postflight exit codes are 0; residual actual child/recorder/postflight exit codes are 1, with completed exact guards. The residual ran 351.368469 seconds according to its child receipt. No wrapper exit is substituted for these results.

## Results and attribution

The four complete modified files were selected without a leaf filter. Direct reconciliation of every original Vitest assertion with case rows confirms 51 unique identities, 49 passed, two failed, zero pending/TODO. Raw text ends normally with 3 passed files / 1 failed file and 49 passed / 2 failed tests. Vitest's aggregate nested suite counters are not standalone suite errors. All four file messages are empty; suite-error and unhandled-marker reports are empty, and independent raw-text inspection found no unhandled/uncaught/worker error or failed-suite section.

J7, actor-to-director X5, actor-to-writer X5, D14 and Q04 each passed as a complete leaf. Pinned source inspection confirms their original trailing assertions remain in the executed bodies. Thus the previously masked D14/Q04 loops and later assertions completed; no new expectation repin was needed. J7/X5 prove the exact current recovery-authority refusal and input neutrality, not a later ranking boundary.

D07 and D18 remain failed at the fixed-rival winner premise. Independently matched each raw identity and exact primary message to both original baseline partitions: two SAME, zero NEW, zero CHANGED against accepted M3 and unswept 1368-E. SAME concerns the approved raw-primary rule; it does not assert byte-identical complete stacks or waive the failures. Both full current failure messages remain retained. Baseline selected/unselected partitions match original pinned inputs exactly (M3: 2 selected / 131 outside; unswept: 34 selected / 893 outside).

All 32 unswept GONE identities were checked individually against their actual original Vitest assertions: each has one exact matching current occurrence, status passed and no failure messages. Every `EXECUTED_PASS` disposition is justified. None relies on an absent or renamed leaf. No global GONE claim or combined unique coverage follows.

## Remaining limits and publication consistency

Separate week-13 ranking controls remain unexecuted and required. The preserved R6 P15 r1 log shows the existing 5 GiB disk assertion refused before binding/formal recording/tests; its output directory is empty. This is not a P15 runtime failure or pass, and the refusal ID must not be reused. Current/helper/UI, ledger clean/observed, landing, broad gates and final recovery-source measurements remain outside this result.

The pinned draft 1368-J's measured-results, attribution and claim limits agree with this review. Its repository-reconciliation and disk-byte observations are parent-owned observations, not independently remeasured here. A later editorial change requires identifying the inspected draft pin; it must not change measured source/results or imply broader acceptance.

## Exact artifact pins

Paths use S=`/Users/zacheryspector/studio-scratch` and E=`docs/engineering/playability-launch-review/evidence/p14b4-20260919` in the live repository. The attribution MANIFEST transitively pins all 13 output files; SUMMARY pins the original inputs and raw/formal receipts. All were independently verified.

| Artifact | SHA-256 |
| --- | --- |
| `S/1368-r6-integration-prep/MANIFEST.json` | `fd4251831e6e8241a3bafe913cc04039a629107b192ab70522845fcebb62bf31` |
| `S/1368-r6-fallout-comparison-prep/MANIFEST.json` | `713acfbe028d198944f36c5d55df94d236115caff5c989530efe01d5bfbb7cbf` |
| `S/1368-save46-swept-proposal-r6/SOURCE-PINS.json` | `2d92af276435275d7ec45554e188962780f0e08467a17dbe42d7ced5f6c85f64` |
| `S/1368-save46-swept-proposal-r6/ASSEMBLY.json` | `b3dcf41960c58528339415fa822cc3e8555738225275ae5f9ff107b68e28b508` |
| `S/1368-save46-swept-proposal-r6/GIT-SNAPSHOT.json` | `5f56fdcfebf45ef39e439995561783e70fe7a36ffc2a4b93a81c36e94b88dc6d` |
| `S/1368-r6-integration-prep/run-types-r1/binding.json` | `2ea8397df170b7a3ff7ea56aa70e11993f36e02826fc37d14e2fe26e198c39c2` |
| `S/1368-r6-integration-prep/run-types-r1/RESULT.json` | `ddff16e75c29364016f787985fbac5f581bd25affdb7a95fbda89238e12f5414` |
| `S/1368-r6-integration-prep/run-backward-residual-r1/binding.json` | `98c83949cf18332a214ed49fdc690f8c2ad22b591005e763ab7e67bd044ba83b` |
| `S/1368-r6-integration-prep/run-backward-residual-r1/RESULT.json` | `ffd8e636c754736d9164cefd3c6ad41b8bcfbe4474d53595e130572d657f714f` |
| `S/1368-r6-integration-prep/run-backward-residual-r1/backward-residual.txt` | `c659c7676856e652a97b7fbc1b1ad5bec69f2eb825f1b6135c6776de761fcc97` |
| `S/1368-r6-integration-prep/run-backward-residual-r1/vitest.json` | `162a8147d7361577c801c29543e9ba60f4edfd70d6a67f83ea698ebaba3c3d48` |
| `S/1368-r6-attribution-backward-residual-r1/MANIFEST.json` | `c756f76c0ea326c537f75880d181135e2646b6aaf871303cbc8ccb3ba6340cda` |
| `S/1368-r6-attribution-backward-residual-r1/SUMMARY.json` | `ec33faa767b406f3daa7ba36a501ff5e67eb7a874eeb7db13618c8c3abf01545` |
| `S/1368-r6-attribution-backward-residual-r1/comparison-vs1361M3.json` | `0629113f31d26de6cf7f81a293fc3a71f181ff9502a61b22be62f91cbd159867` |
| `S/1368-r6-attribution-backward-residual-r1/comparison-vsunswept1368E.json` | `27b6556e950c2f0214fe8fe97f0f3073179d78ffb4297384284e8ebb43a60a92` |
| `S/heavy-queue/1368-r6-p15-r1-resume.log` | `2f58edbeead9b31efdd9860d469160d449a13c761121176cd47ac169e60e07f6` |
| `E/1368-J-r6-resumed-verification.md` | `00d711dec2828c693f6c019434e240404dfea4ecc2ce3187dff4bd01c2e8b71a` |
| `E/1368-swept-r6-types-r1.json` | `3c3fee0f2d49d38f780da2ecad44379e3ccd357863d4aecdde01ed30245aa6d5` |
| `E/1368-swept-r6-types-r1.patch` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `E/1368-swept-r6-types-r1.txt` | `a4f53236f85adf7f12a9e3d976061ed4688d4dcd2bf0c9d3f818c2b62aab2e28` |
| `E/1368-swept-r6-types-r1-preflight.json` | `eff391f16d8c5e2af1c5bc12e601c617198ebe4e16a0a78a1519df56cd40fb4c` |
| `E/1368-swept-r6-types-r1-postflight.json` | `ab0ba3a4029b5ed6196cde2d1ddbacf3bb6c286257d11e04d4f1b3f8011fb1b3` |
| `E/1368-swept-r6-backward-residual-r1.json` | `08c99212d87f130c9c6145a6232c745b7d12cf5f186d9023d6c8e7c92d52e2b4` |
| `E/1368-swept-r6-backward-residual-r1.patch` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `E/1368-swept-r6-backward-residual-r1.txt` | `9bc02fb0f4169d1777e005d5f775f70fad7a98cbff6c32faf02df80574a28838` |
| `E/1368-swept-r6-backward-residual-r1-preflight.json` | `57a519da173410e1da036dcb3071ec4cfe9f295e2832af6ee0cf6554cada6395` |
| `E/1368-swept-r6-backward-residual-r1-postflight.json` | `906b616c2a88ba39c3a77fdfd7c1ec45ccd1a8af2b004dc7946c4d6175f4e29b` |
