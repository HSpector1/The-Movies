# r5 lookup proposal r2 — bounded static re-review

**ACCEPT the corrected lookup patch as a bounded static design for further isolated verification.** This is not approval to assemble or launch an r5 route. The r1 type blocker is corrected: the per-call contract map now stores a mutable array of case elements, while the source `cases` array remains readonly. The README now correctly says 197 regular files, including 188 production files.

The r2 patch applies cleanly to the pinned frozen r4 attribution probe and changes only `owners` and `windowFacts`. The retained 200 synthetic old/new function fixtures pass. The map and set preserve original case/ordinal order and multiplicity on admitted plain states; each business gets a fresh ordinal array, and each emitted case still passes through `copy`. `renewalWindowOpen`, first-match `retirementRecordFor`, row traversal and output fields remain. Full tagged state traversals, public admissions, neutrality assertions, seed/guard pins and 300/330-second caps are untouched by this patch.

Before any assembly, typecheck the entire proposed file in a disposable copy and compare outputs on admissible completed clean states. The synthetic fixtures use mocked helper behavior and are not a complete equivalence proof. No timing improvement, observed completion, comparator admission or protected pin correction is claimed. The separate proposed profiling package must be reviewed on its own merits.

`R2-RECEIPT.json` records exact reviewed hashes. No live or frozen files were edited.
