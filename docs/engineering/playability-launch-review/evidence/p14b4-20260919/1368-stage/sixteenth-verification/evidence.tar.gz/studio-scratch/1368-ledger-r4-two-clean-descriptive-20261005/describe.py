from pathlib import Path
from collections import defaultdict
import datetime,hashlib,json
S=Path('/Users/zacheryspector/studio-scratch');B=S/'1368-ledger-recorded-runs-r4-lowspace-r2';O=S/'1368-ledger-r4-two-clean-descriptive-20261005';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();digest=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
c0p=B/'C0-clean-p13a-baseline-r1/data.json';abcp=B/'ABC-clean-p13a-r1/data.json';c0=json.loads(c0p.read_text());abc=json.loads(abcp.read_text())
for d,arm in [(c0,'C0'),(abc,'ABC')]:
 assert d['completed'] is True and d['sourcePostflight'] is True and (d['arm'],d['mode'],d['seed'],d['horizon'])==(arm,'clean','p13a-core-causal-01',416)
 assert len(d['weekly'])==416 and [w['week'] for w in d['weekly']]==list(range(1,417))
 assert d['actualPins']['rows']==len(d['rows'])==sum(d['actualPins'][n] for n in ['settled','declined','expired'])
 assert d['phaseRows']==d['industryRows']==[]
assert c0['originalPins']==abc['originalPins'] and c0['sourcePins']!=abc['sourcePins']
assert sha(B/'C0-clean-p13a-baseline-r1/RESULT.json')=='cfdf38f6462e01937ca11217eb1bd0c6f09c7461097583661e79a34eb3531dc6'
assert sha(B/'ABC-clean-p13a-r1/RESULT.json')=='95631b3a7aa3b743e5edaf5c60772826a06783a5ab74ef355efb8c42c0b6b8b5'
assert not (B/'ABC-observed-p13a-r1/data.json').exists()
fields=['changedEmployment','changedCases','newMarketReceipts','newIndustryReceipts','firstTakes','rng']
first={}
for x,y in zip(c0['weekly'],abc['weekly']):
 for key in fields:
  if key not in first and x[key]!=y[key]:first[key]={'week':x['week'],'baseline':x[key],'current':y[key],'baselineSha256':digest(x[key]),'currentSha256':digest(y[key])}

def bucket(rows):
 out=defaultdict(list)
 for ordinal,row in enumerate(rows):out[(row['week'],row['talentId'],row['subjectStudioId'])].append({'sourceOrdinal':ordinal,'row':row})
 return out
old,new=bucket(c0['rows']),bucket(abc['rows']);paired=[];missing=[];added=[]
for key in sorted(set(old)|set(new)):
 left,right=old[key],new[key];n=min(len(left),len(right))
 for j in range(n):paired.append({'key':list(key),'occurrence':j+1,'baseline':left[j],'current':right[j],'rowEqual':left[j]['row']==right[j]['row']})
 for j,row in enumerate(left[n:],start=n+1):missing.append({'key':list(key),'occurrence':j,**row})
 for j,row in enumerate(right[n:],start=n+1):added.append({'key':list(key),'occurrence':j,**row})
assert len(c0['rows'])==len(paired)+len(missing) and len(abc['rows'])==len(paired)+len(added)
assert len(abc['rows'])-len(c0['rows'])==len(added)-len(missing)
summary={'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'TWO_ADMITTED_CLEAN_RUNS_ONLY_DESCRIPTIVE_NOT_THREE_INPUT_COMPARATOR','inputHashes':{'c0DataSha256':sha(c0p),'abcDataSha256':sha(abcp),'c0ResultSha256':sha(B/'C0-clean-p13a-baseline-r1/RESULT.json'),'abcResultSha256':sha(B/'ABC-clean-p13a-r1/RESULT.json')},'seed':'p13a-core-causal-01','horizon':416,'originalPinsEqual':True,'sourcePinsEqual':False,'counts':{'c0Rows':len(c0['rows']),'abcRows':len(abc['rows']),'paired':len(paired),'pairedIdentical':sum(x['rowEqual'] for x in paired),'pairedChanged':sum(not x['rowEqual'] for x in paired),'missing':len(missing),'added':len(added)},'firstOrdinaryDifferences':first,'missing':missing,'added':added,'paired':paired,'limits':['No ABC observed completion/data exists, so unchanged comparator and clean/observed parity are blocked.','C0 versus ABC combines A/F6/B/C source differences; temporal/key association is not a causal label.','Protected baseline digest disagreements remain; no expectation repin.']}
(O/'DIFFERENCES.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
receipt={'timeUTC':summary['timeUTC'],'status':summary['scope'],'inputHashes':summary['inputHashes'],'differenceSha256':sha(O/'DIFFERENCES.json'),'counts':summary['counts'],'firstOrdinaryWeeks':{k:v['week'] for k,v in first.items()},'missingIdentities':[{'key':x['key'],'occurrence':x['occurrence'],'sourceOrdinal':x['sourceOrdinal'],'eventId':x['row']['eventId'],'kind':x['row']['kind']} for x in missing],'addedIdentities':[{'key':x['key'],'occurrence':x['occurrence'],'sourceOrdinal':x['sourceOrdinal'],'eventId':x['row']['eventId'],'kind':x['row']['kind']} for x in added],'issues':[]}
(O/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'counts':summary['counts'],'firstOrdinaryWeeks':receipt['firstOrdinaryWeeks'],'missingIdentities':receipt['missingIdentities'],'addedIdentities':receipt['addedIdentities']},indent=2))
