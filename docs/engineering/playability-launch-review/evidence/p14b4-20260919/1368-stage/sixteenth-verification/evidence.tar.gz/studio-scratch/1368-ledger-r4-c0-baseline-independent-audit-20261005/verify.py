from pathlib import Path
import datetime,hashlib,json,math,subprocess
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';P=S/'1368-ledger-parent-prep-r4';ARM=S/'1368-ledger-arms-04/C0';RUN=S/'1368-ledger-lowspace-runner-proposal-r2';BASE=S/'1368-ledger-recorded-runs-r4-lowspace-r2';OUT=S/'1368-ledger-r4-c0-baseline-independent-audit-20261005'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head='4556debe1dc2e77688ded0229b9ab0f2c25d47bb'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert subprocess.check_output(['git','ls-remote','https://github.com/HSpector1/The-Movies.git','refs/heads/wip/headless-program-20260916-ts'],cwd=R,text=True).split()[0]==head
pins={'r4ManifestSha256':'3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f','kitManifestSha256':'01cea5e3beffcb65032dbd45bbb8c56a44016c913bff27c0f756e58d04353a53','assemblySha256':'7134409ad5d09a9d2dbb16080165b1161cc351c0042fc893d5d78874e13ed303','sourcePinsSha256':'00d4b886c0acbeb64ebc413348427723c7b5dcf0fbbce845fceb4a149d4d3a7f','runnerManifestSha256':'c22813f8145742b0a8a418d663447e7ed80f1963b419a9ef7bcb823a339dd414','runnerSha256':'7eb654ebd6b45ab297262b38315414643a1ac26d08b3a03c7b78dcd875aa6f4d'}
assert sha(P/'MANIFEST.json')==pins['r4ManifestSha256'];assert sha(P/'kit/MANIFEST.json')==pins['kitManifestSha256'];assert sha(ARM/'ASSEMBLY.json')==pins['assemblySha256'];assert sha(ARM/'SOURCE-PINS.json')==pins['sourcePinsSha256'];assert sha(RUN/'MANIFEST.json')==pins['runnerManifestSha256'];assert sha(RUN/'run.py')==pins['runnerSha256']
for root,manifest in [(P,json.loads((P/'MANIFEST.json').read_text())['files']),(RUN,json.loads((RUN/'MANIFEST.json').read_text())['files'])]:
 for n,row in manifest.items():assert sha(root/n)==row['sha256'] and (root/n).stat().st_size==row['bytes'],n
for n,digest in json.loads((P/'kit/MANIFEST.json').read_text()).items():assert sha(P/'kit'/n)==digest,n
source=json.loads((ARM/'SOURCE-PINS.json').read_text());assert len(source)==197
for n,digest in source.items():assert sha(ARM/'tree'/n)==digest,n
kit_source=json.loads((P/'kit/SOURCE-PINS.json').read_text())['C0'];assert len(kit_source)==189
for n,digest in kit_source.items():assert source[n]==digest,n
report={'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'ACCEPT_FRESH_C0_BASELINE_COMPARATOR_BLOCKED_BY_INCOMPLETE_OBSERVED','publicationHead':head,'pins':pins,'sourceFilesRehashed':len(source),'types':{},'clean':{},'issues':[],'limits':['C0 is historical production; its four protected digest comparisons remain false.','The unchanged comparator cannot run: ABC observed timed out and has no data.json or vitest.json.']}
results={}
for mode,leaf,stem,log in [('types','C0-types-source-baseline-r1','1368-ledger-r4-lowspace-r2-c0-types-source-baseline-r1','1368-ledger-r4-lowspace-r2-c0-types-source-baseline-r1'),('clean','C0-clean-p13a-baseline-r1','1368-ledger-r4-lowspace-r2-c0-clean-p13a-baseline-r1','1368-ledger-r4-lowspace-r2-c0-clean-p13a-baseline-r1')]:
 o=BASE/leaf;rp=o/'RESULT.json';res=json.loads(rp.read_text());binding=json.loads((o/'binding.json').read_text());child=json.loads((o/'CHILD.json').read_text());formal=json.loads((E/(stem+'.json')).read_text());post=json.loads((E/(stem+'-postflight.json')).read_text());launch=json.loads((o/'LAUNCH.json').read_text())
 assert 'end, exit 0;' in (S/'heavy-queue'/(log+'.log.meta')).read_text()
 assert binding['mode']==mode and binding['arm']=='C0' and binding['publicationHead']==head and binding['manifestPin']==pins['r4ManifestSha256'] and binding['selfRunnerSha256']==pins['runnerSha256']
 assert binding['pins']==res['pins'] and binding['pins']['sourcePinsSha256']==pins['sourcePinsSha256'] and binding['pins']['assemblySha256']==pins['assemblySha256'] and binding['pins']['kitManifestSha256']==pins['kitManifestSha256'] and binding['pins']['selfRunnerSha256']==pins['runnerSha256'] and binding['pins']['regularFiles']==197
 assert res['mode']==mode and res['arm']=='C0' and res['actualChildExit']==res['recorderChildExit']==0 and not res['timedOut'] and res['allGuardsExact'] and res['livePostflightExact'] and res['reportingErrors']==[]
 assert child['actualChildExit']==0 and not child['timedOut'] and child['allGuardsExact'] and child['reportingErrors']==[]
 assert res['processGroup']==child['processGroup'] and all(res['processGroup'][k] for k in ['cleanupVerified','noSurvivors','leaderReaped']) and res['processGroup']['errors']==[]
 assert formal['fixedSource'] and formal['exitCode']==0 and formal['sourceSha']==formal['sourceShaAtEnd']==head
 assert post['fixedSource'] and post['allGuardsExact'] and post['exitCode']==0 and post['head']==head
 assert formal['command']==[str(Path('/usr/local/opt/python@3.14/bin/python3.14')),str(RUN/'run.py'),'--child',str(o),sha(o/'binding.json')] or formal['command'][-4:]==[str(RUN/'run.py'),'--child',str(o),sha(o/'binding.json')]
 assert launch['bindingSha256']==sha(o/'binding.json') and launch['command']==binding['command'] and launch['ownedProcessGroup']==launch['nodePid']==res['processGroup']['ownedProcessGroup']
 assert res['stdoutSha256']==sha(o/'stdout.txt') and res['stderrSha256']==sha(o/'stderr.txt')
 for path,row in res['artifacts'].items():
  p=Path(path);assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],path
 assert len(res['artifacts'])==(11 if mode=='types' else 14)
 results[mode]={'resultSha256':sha(rp),'formalRecordSha256':sha(E/(stem+'.json')),'postflightSha256':sha(E/(stem+'-postflight.json')),'actualChildExit':0,'recorderChildExit':0,'cleanupVerified':True,'artifactHashesVerified':len(res['artifacts']),'elapsedSeconds':res['elapsedSeconds']}
 if mode=='types':
  assert binding['seed'] is None and binding['typesReceipt'] is None
  assert binding['command'][-3:]==['--noEmit','-p','tsconfig.1368-ledger.json']
 else:
  assert binding['seed']==res['seed']=='p13a-core-causal-01'
  assert binding['typesReceipt']==str(BASE/'C0-types-source-baseline-r1/RESULT.json') and binding['typesReceiptSha256']==results['types']['resultSha256']
  for k in ['arm','sourcePinsSha256','assemblySha256','kitManifestSha256','inputPinsSha256','runnerManifestSha256','selfRunnerSha256','entrypoints','regularFiles']:assert binding['pins'][k]==json.loads((BASE/'C0-types-source-baseline-r1/RESULT.json').read_text())['pins'][k]
  data=json.loads((o/'data.json').read_text());v=json.loads((o/'vitest.json').read_text());progress=[json.loads(line) for line in (o/'progress.jsonl').read_text().splitlines()]
  assert data['completed'] and data['sourcePostflight'] and (data['mode'],data['arm'],data['seed'],data['horizon'])==('clean','C0','p13a-core-causal-01',416)
  assert data['sourcePins']==kit_source and len(data['weekly'])==416 and [x['week'] for x in data['weekly']]==list(range(1,417))
  assert all(data['weekly'][i+1]['inputDigest']==data['weekly'][i]['digest'] for i in range(415)) and data['finalStateDigest']==data['weekly'][-1]['digest']
  assert len(data['phaseRows'])==len(data['industryRows'])==0
  assert [x['week'] for x in progress]==list(range(52,417,52)) and all(set(x)=={'week','elapsedSeconds'} and math.isfinite(x['elapsedSeconds']) and x['elapsedSeconds']>=0 for x in progress) and all(a['elapsedSeconds']<=b['elapsedSeconds'] for a,b in zip(progress,progress[1:]))
  assert v['numTotalTests']==v['numPassedTests']==1 and v['numFailedTests']==0 and v['testResults'][0]['assertionResults'][0]['status']=='passed'
  results[mode].update(dataSha256=sha(o/'data.json'),progressWeeks=[x['week'] for x in progress],progressLastSeconds=progress[-1]['elapsedSeconds'],rows=len(data['rows']),actualPins=data['actualPins'],pinComparisons=data['pinComparisons'],oneTestPassed=True)
report['types']=results['types'];report['clean']=results['clean']
abc=json.loads((BASE/'ABC-clean-p13a-r1/data.json').read_text());c0=json.loads((BASE/'C0-clean-p13a-baseline-r1/data.json').read_text());old=json.loads((S/'1368-ledger-recorded-runs-r3/C0-clean-p13a-r1/data.json').read_text())
assert c0['seed']==abc['seed']=='p13a-core-causal-01' and c0['horizon']==abc['horizon']==416 and c0['originalPins']==abc['originalPins']
assert c0['sourcePins']!=abc['sourcePins']
prior_equal={n:c0[n]==old[n] for n in ['sourcePins','originalPins','actualPins','pinComparisons','weekly','rows','finalStateDigest','finalMarket','finalEmployment','finalIndustryReceipts','finalRetirements']}
assert all(prior_equal.values())
assert sha(P/'kit/compare.py')==json.loads((P/'kit/MANIFEST.json').read_text())['compare.py']
assert not (BASE/'ABC-observed-p13a-r1/data.json').exists()
report['comparatorInputs']={'c0CleanDataSha256':sha(BASE/'C0-clean-p13a-baseline-r1/data.json'),'abcCleanDataSha256':sha(BASE/'ABC-clean-p13a-r1/data.json'),'abcObservedDataExists':False,'seed':'p13a-core-causal-01','horizon':416,'originalPinsEqual':True,'c0AndAbcSourcePinsDiffer':True,'unchangedComparatorSha256':sha(P/'kit/compare.py'),'oldR3C0SelectedFieldsEqual':prior_equal,'admission':'BLOCKED_ABSENT_ABC_OBSERVED_DATA'}
(OUT/'RECEIPT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'decision':report['decision'],'types':results['types'],'clean':{k:v for k,v in results['clean'].items() if k not in ['actualPins','pinComparisons']}},indent=2))
