from pathlib import Path
import datetime,hashlib,json,subprocess
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';B=S/'1368-ledger-recorded-runs-r4-lowspace-r2';O=B/'ABC-observed-p13a-r1';OUT=S/'1368-ledger-r4-observed-timeout-review-20261005';stem='1368-ledger-r4-lowspace-r2-abc-observed-p13a-r1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
res=json.loads((O/'RESULT.json').read_text());child=json.loads((O/'CHILD.json').read_text());binding=json.loads((O/'binding.json').read_text());record=json.loads((E/(stem+'.json')).read_text());post=json.loads((E/(stem+'-postflight.json')).read_text());launch=json.loads((O/'LAUNCH.json').read_text());progress=[json.loads(x) for x in (O/'progress.jsonl').read_text().splitlines()]
assert 'end, exit 124;' in (S/'heavy-queue/1368-ledger-r4-lowspace-r2-observed-p13a-r1.log.meta').read_text()
assert (binding['mode'],binding['arm'],binding['seed'],binding['horizon'])==('observed','ABC','p13a-core-causal-01',416)
assert binding['typesReceipt']==str(B/'ABC-types-source-r1/RESULT.json') and binding['typesReceiptSha256']==sha(B/'ABC-types-source-r1/RESULT.json')
assert binding['cleanReceipt']==str(B/'ABC-clean-p13a-r1/RESULT.json') and binding['cleanReceiptSha256']==sha(B/'ABC-clean-p13a-r1/RESULT.json')
assert binding['pins']==res['pins'] and binding['pins']['sourcePinsSha256']==sha(S/'1368-ledger-arms-04/ABC/SOURCE-PINS.json') and binding['pins']['selfRunnerSha256']==sha(S/'1368-ledger-lowspace-runner-proposal-r2/run.py')
assert res['mode']=='observed' and res['arm']=='ABC' and res['seed']=='p13a-core-causal-01' and res['timedOut'] is True and res['actualChildExit']==-15 and res['recorderChildExit']==124 and res['allGuardsExact'] and res['livePostflightExact'] and res['reportingErrors']==[]
assert child['timedOut'] is True and child['actualChildExit']==-15 and child['allGuardsExact'] and child['reportingErrors']==[] and child['processGroup']==res['processGroup']
p=res['processGroup'];assert p['statusBeforeCleanup']=='PRESENT' and p['statusAfterCleanup']=='ABSENT' and p['signals']==['TERM'] and p['errors']==[] and p['cleanupVerified'] and p['noSurvivors'] and p['leaderReaped']
assert record['fixedSource'] and record['exitCode']==124 and record['sourceSha']==record['sourceShaAtEnd']==binding['publicationHead']
assert post['fixedSource'] and post['allGuardsExact'] and post['exitCode']==124 and post['head']==binding['publicationHead']
assert launch['command']==binding['command'] and launch['bindingSha256']==sha(O/'binding.json') and launch['nodePid']==launch['ownedProcessGroup']==p['ownedProcessGroup']
assert res['stdoutSha256']==sha(O/'stdout.txt') and res['stderrSha256']==sha(O/'stderr.txt')
assert len(res['artifacts'])==12
for path,row in res['artifacts'].items():f=Path(path);assert sha(f)==row['sha256'] and f.stat().st_size==row['bytes']
assert not (O/'data.json').exists() and not (O/'vitest.json').exists()
assert [x['week'] for x in progress]==[52,104,156,208] and all(a['elapsedSeconds']<b['elapsedSeconds'] for a,b in zip(progress,progress[1:]))
assert res['elapsedSeconds']>=330
report={'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'INCOMPLETE_HONEST_TIMEOUT_NO_COMPARATOR_ADMISSION','resultSha256':sha(O/'RESULT.json'),'childSha256':sha(O/'CHILD.json'),'formalRecordSha256':sha(E/(stem+'.json')),'formalPostflightSha256':sha(E/(stem+'-postflight.json')),'bindingSha256':sha(O/'binding.json'),'typesReceiptSha256':binding['typesReceiptSha256'],'cleanReceiptSha256':binding['cleanReceiptSha256'],'head':binding['publicationHead'],'sourcePinsSha256':binding['pins']['sourcePinsSha256'],'runnerSha256':binding['pins']['selfRunnerSha256'],'timedOut':True,'actualChildExit':-15,'recorderChildExit':124,'elapsedSeconds':res['elapsedSeconds'],'progress':progress,'artifactHashesVerified':len(res['artifacts']),'noSurvivors':True,'cleanupVerified':True,'dataJsonExists':False,'vitestJsonExists':False,'issues':[]}
(OUT/'RECEIPT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['progress','issues']},indent=2))
