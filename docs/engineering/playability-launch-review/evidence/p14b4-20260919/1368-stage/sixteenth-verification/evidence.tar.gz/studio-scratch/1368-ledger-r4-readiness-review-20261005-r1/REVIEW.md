# Ledger r4 gate readiness: static review, 2026-10-05

Scope: read-only verification of the frozen r4 kit, both assembled arms, live publication identity, disk gate, and next command order. No ledger types or simulation was launched. The concurrent formal R8 current run and its artifacts were untouched.

## Verified identities

- Live branch `wip/headless-program-20260916-ts`, HEAD and explicit remote `af16f53feb1edcb51d7e9dff109d43c7be2ec804`. The r4 runner's `verify` function passed for C0 and ABC at this HEAD. Bounded live-source diff hash is the empty SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`; index SHA-256 `1c0725efe0a5b971d9f23f2e24e30e95d23e38357abacf59a3cf2338d9309fd4`, staged-list SHA-256 `bb17f6cf66669be728f8648fe9760e916f4153366e2e31730d4d68a7007b4700`. Recheck these at launch; HEAD publication may legitimately advance.
- r4 package manifest SHA-256 `3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f`; all 32 declared files match hash and size. This includes local repaired `cleanup.py` and exact `run.py`. Existing seven mocked safety tests have a recorded PASS, actual/recorder/postflight exits 0, and exact guards in `1368-ledger-r4-cleanup-safety-r1/RESULT.json`.
- Combined arm assembly SHA-256 `8d027bf8e9cd6aa5e874b6f053e14b5b17be3701c6f4966b3b42610cf7fd6b38`. C0 assembly/source pins `7134409ad5d09a9d2dbb16080165b1161cc351c0042fc893d5d78874e13ed303` / `00d4b886c0acbeb64ebc413348427723c7b5dcf0fbbce845fceb4a149d4d3a7f`; ABC `c37c8d1a1c58a6729cc75a6fb5f38fd1158f60c9cf17a54c7b290aeec1a9f259` / `43ee074d7833ddae4993794b9084d603bb7eebd2943de7b7949e31759b5de336`. Independently rehashed every 197 regular files in each arm: zero mismatches; each assembly records 188 production files. Runner verification also checked protected inputs, kit, dependency link, Node 20.20.2, entrypoints, and live index/source guards.
- `1368-ledger-recorded-runs-r4` does not yet exist, so all r4 result leaves remain exclusive and fresh. Historical r3 C0 clean has 40 matching rows/status/RNG but four protected digest differences; it is qualified historical evidence only. Historical r3 ABC clean passed, while r3 observed is incomplete after legacy cleanup EPERM. The r4 runner uses local fail-closed cleanup; no observed result can be inferred from r3.

## Current gate

At review, filesystem free bytes were `4,571,774,976`, below the unchanged r4 runner floor `5,368,709,120` by `796,934,144` bytes. The heavy lane was occupied by formal `1368-r8-current-r1` under HEAD `af16f53feb1edcb51d7e9dff109d43c7be2ec804` (lane PID 74598, runner 74848 at inspection). Disk capacity and lane occupancy are transient: remeasure immediately before any launch. Do not create an output leaf or invoke the runner while either condition fails. The runner checks disk before creating outputs, but lane discipline is an independent prerequisite. No source mismatch or narrow versioned fix is indicated by this static review.

The repository `HANDOFF.md` still says no heavy run is active and describes an older checkpoint; current process and Git observations supersede that stale status. This specialist review did not edit HANDOFF or formal R8 artifacts during the active run.

## Exact bounded next sequence

After R8 has fully ended and its postflight has been reconciled, confirm one heavy lane idle, AC/power and no competing writer, HEAD/remote equality, and at least 5 GiB free. Preserve the original r3 records and every failed receipt. Then run fresh r4 ABC types first:

```sh
python3 -B /Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/run.py types --arm ABC --head af16f53feb1edcb51d7e9dff109d43c7be2ec804 --manifest-sha256 3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f --leaf r1
```

Inspect `.../1368-ledger-recorded-runs-r4/ABC-types-source-r1/RESULT.json` for actual and recorder exit 0, exact guards and verified cleanup; record its actual SHA-256. If publication HEAD advances before launch, substitute the newly verified, explicitly remote-matched full HEAD in *each* command. Source and kit pins must remain identical. Then run clean p13a:

```sh
python3 -B /Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/run.py clean --arm ABC --seed p13a-core-causal-01 --head af16f53feb1edcb51d7e9dff109d43c7be2ec804 --manifest-sha256 3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f --leaf r1 --types-receipt /Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4/ABC-types-source-r1/RESULT.json --types-receipt-sha256 <actual accepted types RESULT.json SHA-256>
```

Only after clean has completed its 416 weeks, all original controls, recorder/source/cleanup guards, and independent receipt review, run observed on the same p13a seed:

```sh
python3 -B /Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/run.py observed --arm ABC --seed p13a-core-causal-01 --head af16f53feb1edcb51d7e9dff109d43c7be2ec804 --manifest-sha256 3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f --leaf r1 --types-receipt /Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4/ABC-types-source-r1/RESULT.json --types-receipt-sha256 <actual accepted types RESULT.json SHA-256> --clean-receipt /Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4/ABC-clean-p13a-r1/RESULT.json --clean-receipt-sha256 <actual accepted clean RESULT.json SHA-256>
```

The comparator requires an explicitly accepted C0 baseline, new ABC clean data, new ABC observed data, and a fresh exclusive output. An old C0 r3 data file may be used only with explicit qualification of its four protected digest differences; a fresh r4 C0 types/clean measurement is the stronger path if the parent requires same-runner baseline evidence. Comparator admission cannot be decided until observed has an actual complete RESULT. Do not repin protected digests, change 300/330-second limits, infer missing child fields from elapsed time, or run the adoption seed as an automatic follow-up.

Disposition: kit and arms are statically ready; execution is **not ready now** because the heavy lane is active and disk free is below the hard floor. Once those transient gates clear, the ABC types command above is the next executable step. No r4 code fix is needed on evidence inspected here.
