const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const ts = require('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/tree/node_modules/typescript')
const base = '/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/tree/tests/1368-ledger-attribution.test.ts'
const next = '/Users/zacheryspector/studio-scratch/1368-ledger-r5-observed-proposal-20261005-r1/PROPOSED-attribution.test.ts'
function funcs(path) {
  const source = fs.readFileSync(path, 'utf8')
  const owners = source.slice(source.indexOf('function owners(h: Hollywood) {'), source.indexOf('\nfunction caseKey('))
  const windowFacts = source.slice(source.indexOf('function windowFacts(state: GameState) {'), source.indexOf('\nfunction admit('))
  const js = ts.transpileModule(owners + '\n' + windowFacts + '\nexports.owners = owners; exports.windowFacts = windowFacts', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText
  const context = { exports: {}, Map, Set, copy: value => structuredClone(value),
    recovery: b => b.costCutting === undefined ? { present: false } : { present: true, ...structuredClone(b.costCutting) },
    renewalWindowOpen: (terms, week) => terms.openAt <= week && week <= terms.closeAt,
    retirementRecordFor: (state, personId) => { const role = state.talent.find(p => p.id === personId)?.role; return state.careerLifecycle.records.find(r => r.personId === personId && r.profession === role) } }
  vm.runInNewContext(js, context)
  return context.exports
}
const a = funcs(base), b = funcs(next)
let checked = 0
for (let n = 0; n < 200; n++) {
  const studios = ['A', 'B', 'A', 'C'].slice(0, n % 5)
  const employment = Array.from({ length: n % 37 }, (_, i) => ({ contractId: `c${i % 11}`, studioId: ['A', 'B', 'C'][i % 3], endedWeek: i % 4 ? null : 9, terms: { talentId: `t${i % 8}`, openAt: i % 3, closeAt: 20 } }))
  const activeEmploymentOrdinals = employment.map((_, i) => i).filter(i => i % 3 !== 0).reverse()
  const businesses = studios.map((studioId, i) => ({ studioId, costCutting: i % 2 ? { version: 1, since: null } : undefined, account: { cash: i, debt: 3 }, nextDecisionWeek: i, policy: { reserveWeeks: 7 }, productions: [{ id: `p${i}` }], runs: [{ productionId: `p${i}` }] }))
  const cases = Array.from({ length: n % 23 }, (_, i) => ({ contractId: `c${i % 11}`, variant: i % 2 ? 'retirementExtension' : 'expiry', outcome: null }))
  const state = { hollywood: { employment, activeEmploymentOrdinals, businesses }, market: { tick: 5 }, talentMarket: { cases }, talent: Array.from({ length: 8 }, (_, i) => ({ id: `t${i}`, role: i % 2 ? 'actor' : 'director' })), careerLifecycle: { records: Array.from({ length: 8 }, (_, i) => ({ personId: `t${i}`, profession: i % 2 ? 'actor' : 'director' })) } }
  assert.equal(JSON.stringify(b.owners(state.hollywood)), JSON.stringify(a.owners(state.hollywood)), `owners ${n}`)
  assert.equal(JSON.stringify(b.windowFacts(state)), JSON.stringify(a.windowFacts(state)), `windowFacts ${n}`)
  checked++
}
console.log(JSON.stringify({ staticFixtures: checked, bothFunctionsEqual: true }))
