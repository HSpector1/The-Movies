# Fresh r4 low-space C0 p13a baseline — prepared, not launched

Scope: one C0 `types` mode followed, only if admitted, by one C0 `clean` mode for `p13a-core-causal-01` using the reviewed r4 low-space r2 runner. This is scratch preparation only. Do not launch either mode until the coordinator explicitly releases this plan after the ABC observed mode and its formal postflight have closed, the heavy lane is idle, and the 21:05 CDT cutoff still permits a new heavy start. Stop at any failed gate. Do not run C0 observed, adoption, a retry, or a modified deadline.

## Why measure this baseline

The historical r3 C0 clean receipt is complete (actual/recorder exit 0, 416 weeks), but its source uses the r3 attribution probe and the earlier runner/cleanup. Its 40 rows and status/RNG comparisons match while four protected comparisons remain false: `settlement`, `receipts`, `employment`, and `takes`. Fresh r4 C0 uses the frozen original production arm with the same r4 probe, low-space r2 runner, kit, recorder, cleanup, seed and horizon as the new ABC clean/observed route. That makes it a stronger technical comparator input. It does not turn C0 into the ABC source, erase those four differences, or prove their cause. The unchanged comparator reports C0→ABC differences combining A/F6/B/C; it must not attribute causality from temporal association.

Read-only preparation found C0 arm04 assembly SHA-256 `7134409ad5d09a9d2dbb16080165b1161cc351c0042fc893d5d78874e13ed303` and SOURCE-PINS SHA-256 `00d4b886c0acbeb64ebc413348427723c7b5dcf0fbbce845fceb4a149d4d3a7f`. All 197 regular files match exact names, hashes and assembly byte counts; 188 are production files, all have link count one, and the only symlink is `node_modules` to live dependencies. Compared with r3 C0, only `tests/1368-ledger-attribution.test.ts` changed. The kit manifest `01cea5e3beffcb65032dbd45bbb8c56a44016c913bff27c0f756e58d04353a53` has 12/12 pinned members; frozen parent manifest `3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f` has 32/32. The reviewed r2 runner is SHA-256 `7eb654ebd6b45ab297262b38315414643a1ac26d08b3a03c7b78dcd875aa6f4d`; proposal manifest `c22813f8145742b0a8a418d663447e7ed80f1963b419a9ef7bcb823a339dd414`. Its independent static ACCEPT receipt is `e06f949b8cdd0f82bbbf0a55b987b8af87e1e666f91a8d0c9b11564f03e1e3d9`. Rehash all of these before launch.

The accepted ABC clean p13a RESULT SHA-256 is `95631b3a7aa3b743e5edaf5c60772826a06783a5ab74ef355efb8c42c0b6b8b5`: actual/recorder 0, complete 416 weeks, one JSON test PASS, eight progress marks, exact source/postflight/cleanup and 14 artifacts. This is a measured ABC clean input, not an observed or C0 result. ABC observed must close independently before this C0 sequence is released.

## Gate before each launch

Confirm no active writer/recorded postflight, no `HEAVY-LANE-LOCK`, no Vitest/tsc runner survivors, AC power, free bytes at least 3 GiB, and time before 21:05 America/Chicago. Confirm tracked live files and bounded source are clean; formal outputs from other modes may be untracked. Rehash runner, proposal/frozen manifests, C0 assembly/source pins, kit and C0 197-file inventory. Confirm branch and full local HEAD equal the explicit origin branch, then use that freshly verified full SHA as `LEDGER_HEAD`:

```sh
LEDGER_HEAD="$(git rev-parse HEAD)"
LEDGER_REMOTE_HEAD="$(git ls-remote --exit-code origin refs/heads/wip/headless-program-20260916-ts | awk '{print $1}')"
test "$LEDGER_HEAD" = "$LEDGER_REMOTE_HEAD"
```

At preparation, HEAD/explicit origin was `4556debe1dc2e77688ded0229b9ab0f2c25d47bb`; a later documentation checkpoint may change it. The runner checks the live source, HEAD, index, stage and manual guard before, during and after each mode. Preserve all old leaves and partial receipts. The paths below were absent at preparation; recheck immediately before use.

## 1. C0 types

Leaf: `S/1368-ledger-recorded-runs-r4-lowspace-r2/C0-types-source-baseline-r1` (where `S=/Users/zacheryspector/studio-scratch`). Formal stem: `1368-ledger-r4-lowspace-r2-c0-types-source-baseline-r1` with five exclusive evidence paths. Unique log: `S/heavy-queue/1368-ledger-r4-lowspace-r2-c0-types-source-baseline-r1.log` and `.meta`.

```sh
bash /Users/zacheryspector/studio-scratch/heavy-queue/lane-run.sh 0 /Users/zacheryspector/studio-scratch/heavy-queue/1368-ledger-r4-lowspace-r2-c0-types-source-baseline-r1.log python3 -B /Users/zacheryspector/studio-scratch/1368-ledger-lowspace-runner-proposal-r2/run.py types --arm C0 --head "$LEDGER_HEAD" --manifest-sha256 3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f --self-runner-sha256 7eb654ebd6b45ab297262b38315414643a1ac26d08b3a03c7b78dcd875aa6f4d --leaf baseline-r1
```

Admit only after `.meta` end and exact formal pre/postflight: CHILD and RESULT exist, one TypeScript command with actual child exit 0, recorder exit 0, `timedOut=false`, empty `reportingErrors`, `allGuardsExact`/`livePostflightExact`, fixed source, matching HEAD/index/stage/manual inventories, process-group `cleanupVerified`, `noSurvivors`, `leaderReaped` all true, no surviving test process, and every RESULT artifact and formal file hash/size verified. Wrapper exit 0 alone is insufficient. Record the actual accepted RESULT SHA as `LEDGER_C0_TYPES_SHA`; do not substitute an ABC or r3 types receipt.

## 2. C0 clean p13a

Recheck all launch gates and rehash the exact C0 types RESULT immediately before consuming it. Leaf: `S/1368-ledger-recorded-runs-r4-lowspace-r2/C0-clean-p13a-baseline-r1`. Formal stem: `1368-ledger-r4-lowspace-r2-c0-clean-p13a-baseline-r1`. Unique log: `S/heavy-queue/1368-ledger-r4-lowspace-r2-c0-clean-p13a-baseline-r1.log` and `.meta`. Refresh `LEDGER_HEAD` from local/explicit origin again.

```sh
LEDGER_C0_TYPES_SHA="$(shasum -a 256 /Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4-lowspace-r2/C0-types-source-baseline-r1/RESULT.json | awk '{print $1}')"
bash /Users/zacheryspector/studio-scratch/heavy-queue/lane-run.sh 0 /Users/zacheryspector/studio-scratch/heavy-queue/1368-ledger-r4-lowspace-r2-c0-clean-p13a-baseline-r1.log python3 -B /Users/zacheryspector/studio-scratch/1368-ledger-lowspace-runner-proposal-r2/run.py clean --arm C0 --seed p13a-core-causal-01 --head "$LEDGER_HEAD" --manifest-sha256 3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f --self-runner-sha256 7eb654ebd6b45ab297262b38315414643a1ac26d08b3a03c7b78dcd875aa6f4d --leaf baseline-r1 --types-receipt /Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4-lowspace-r2/C0-types-source-baseline-r1/RESULT.json --types-receipt-sha256 "$LEDGER_C0_TYPES_SHA"
```

Apply the same CHILD/RESULT/recorder/postflight/source/index/manual/process/artifact admission. Additionally require `data.completed=true`, `sourcePostflight=true`, C0/clean/p13a/416 identity, exact C0 source pins, 416 contiguous weekly rows, JSON one PASS/zero FAIL, and progress weeks 52, 104, 156, 208, 260, 312, 364, 416 in order. Preserve the historical pin-comparison fields verbatim. A completed C0 run can be offered for a separate comparator review; it cannot repin the four false historical digest comparisons or certify ABC observed parity.

If any gate fails or the cutoff arrives before a new launch, stop and report the original evidence. Do not retry a used leaf, lower the 300/330-second limits, or infer child/cleanup fields from elapsed time.
