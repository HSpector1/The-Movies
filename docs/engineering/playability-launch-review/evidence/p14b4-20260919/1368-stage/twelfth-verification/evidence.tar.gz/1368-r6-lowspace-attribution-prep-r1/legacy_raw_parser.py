# Narrow extracted parser functions from the accepted 1321-I parser; no old baseline side effects.
import re, hashlib
FAIL_LINE_RE = re.compile('^ FAIL \\|(core|ui)\\|\\s+(.*)$', re.M)
FRAME_RE = re.compile('^ ❯ (.*)$', re.M)
TESTFILE_IN_FRAME_RE = re.compile('((?:tests|ui/src)/[^\\s():]+\\.test\\.tsx?):(\\d+):(\\d+)')

def load(path):
    raw = open(path, 'rb').read()
    return (raw, raw.decode('utf8', errors='replace'))

def split_block(block_text):
    """Return (list_of_header_strings, body_text_after_last_header)."""
    header_matches = list(FAIL_LINE_RE.finditer(block_text))
    assert header_matches, 'no FAIL header found in block: %r' % block_text[:200]
    headers = [hm.group(2).strip() for hm in header_matches]
    body_start = header_matches[-1].end()
    body = block_text[body_start:]
    return (headers, body)

def extract_primary_and_frame(body):
    frame_matches = list(FRAME_RE.finditer(body))
    if frame_matches:
        msg_text = body[:frame_matches[0].start()]
    else:
        msg_text = body
    first_line = None
    for line in msg_text.splitlines():
        line = line.strip()
        if line:
            first_line = line
            break
    test_frame = None
    for fm in frame_matches:
        line = fm.group(1)
        tm = TESTFILE_IN_FRAME_RE.search(line)
        if tm:
            test_frame = f'{tm.group(1)}:{tm.group(2)}:{tm.group(3)}'
            break
    is_timeout = bool(re.search('[Tt]est timed out in \\d+ms', msg_text))
    return (first_line, test_frame, is_timeout, msg_text.strip())

def identity_parts(header):
    parts = [p.strip() for p in header.split(' > ')]
    file = parts[0]
    leaf = parts[-1]
    describe = ' > '.join(parts[1:-1])
    return (file, describe, leaf)

def parse(path):
    raw, data = load(path)
    data = re.sub('\\x1b\\[[0-9;]*m', '', data)
    ms = re.search('⎯+ Failed Suites (\\d+) ⎯+', data)
    m = re.search('⎯+ Failed Tests (\\d+) ⎯+', data)
    suites = int(ms.group(1)) if ms else 0
    tests_failed = int(m.group(1)) if m else 0
    total = suites + tests_failed
    cases = []
    if total:
        first = ms if ms else m
        body_all = data[data.find(first.group(0)):]
        markers = list(re.finditer('\\n⎯+\\[(\\d+)/%d\\]⎯\\n' % total, body_all))
        cursor = body_all.find(' FAIL |')
        for mk in markers:
            block = body_all[cursor:mk.start() + 1]
            block = re.sub('⎯+ Failed Tests \\d+ ⎯+\\n', '', block)
            headers, body = split_block(block)
            primary, frame, timeout, _ = extract_primary_and_frame(body)
            for h in headers:
                f, d, leaf = identity_parts(h)
                cases.append({'file': f, 'describe': d, 'leaf': leaf, 'identity': h, 'primary': primary, 'frame': frame, 'timeout': timeout, 'shared_group_size': len(headers), 'marker_no': int(mk.group(1)), 'suite': h.endswith(']') and '[ ' in h})
            cursor = mk.end()
    total = len([c for c in cases if not c['suite']]) if total else 0
    assert total == tests_failed, (total, tests_failed)
    return (raw, data, cases)
