# R6 low-space attribution rebind

Only PREP location changes in the adapter. Parser, identities, baselines, source pins, selection, fixture, compiler and formal guard logic remain unchanged. The new runner differs from R6 only in output directory and launch free-space check, 5 to 3 GiB. This package binds the new runner SHA and both original and new kit manifests. It is for UI r2 with types r4 at published c3d55c84; completed helper evidence remains bound to the original runner and original attribution. Attribution completion is not test success.
