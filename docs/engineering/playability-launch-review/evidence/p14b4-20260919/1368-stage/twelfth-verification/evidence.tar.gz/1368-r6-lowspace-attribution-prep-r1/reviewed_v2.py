#!/usr/bin/env python3
"""Attribute completed, guarded Save46 fallout. No game execution or fixture reads."""
from pathlib import Path
from datetime import datetime
from collections import Counter
import argparse, hashlib, json, os, re
from legacy_raw_parser import parse as raw_parse
R=Path('/Users/zacheryspector/The-Movies-headless-program')
S=Path('/Users/zacheryspector/studio-scratch')
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
P=S/'1368-save46-fallout-r1'; T=P/'tree'
BASE='eb5fa9146fd934efc98ed8275c7aab4521b4228e'
FIXED={'sourcePinsSha256':'62721195669b82c4299ebcafc907004bbe32e848e370c02fa1a17255e6dee403','assemblySha256':'dcf9f266af1763fd34e8785ddbefb30dc3783f8bfd191a926af03ac5d1e88e06','runnerSha256':'4f2828410d387a221478f3da5a0bde1bf1e2ef996873daa742c8c250ae90b2a7','fixturePinsSha256':'172bf2381e5447bc42f7d4a4194d34f50c2b3233044e60bb4a8809e61bfb6ccc'}
BASELINES={'core':('1361-stage/land/attr-core-live/core-failures.json','4cf7485d2842a966325cf57c917d708691fbce9485b5161d7a10affa7de96c38'),'ui':('1361-stage/land/attr-ui-live/ui-failures.json','70c4cb059accf867e290f4ec0efedc60d0a1329a45d4d505736781375a880591'),'d16':('1361-stage/land/d16-vitest.json','eb0251e7de94cddc73546b6255d891e2260168d06fb95153794f7116798805b9')}
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):return sha(p.read_bytes())
def read(p):return json.loads(p.read_text())
def stamp(s):return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()*1000
def normalize(s,prefix):return re.sub(re.escape(prefix+'/')+r'(?!node_modules/)', '<tree>/', s)
def compare(before,after):
 common=before.keys() & after.keys()
 return {'beforeCount':len(before),'afterCount':len(after),'same':sorted(k for k in common if before[k]==after[k]),'new':sorted(after.keys()-before.keys()),'gone':sorted(before.keys()-after.keys()),'changed':[{'identity':k,'before':before[k],'after':after[k]} for k in sorted(common) if before[k]!=after[k]]}
def guards(mode):
 stem='1368-save46-fallout-'+mode+'-r1';out=P/mode
 # Read final record/postflight first; never attribute an incomplete capture.
 paths={k:E/(stem+v) for k,v in {'record':'.json','pre':'-preflight.json','post':'-postflight.json','raw':'.txt','patch':'.patch'}.items()}
 rec=read(paths['record']);assert rec.get('end') and rec.get('fixedSource') is True,'run unfinished/source not fixed'
 pre=read(paths['pre']);post=read(paths['post'])
 assert rec['signal'] is None and rec['error'] is None,'abnormal recorder termination'
 assert rec['sourceSha']==rec['sourceShaAtEnd']==pre['head']==post['head']==BASE
 assert post['fixedSource'] is True and post['allGuardsExact'] is True and post['exitCode']==rec['exitCode']
 for k in ['guardScope','head','sourcePaths','sourceFiles','sourceInventory','manual','index','stageEntries']:assert pre[k]==post[k],k
 for k in ['record','raw','patch']:assert post[k]['sha256']==digest(paths[k]) and post[k]['bytes']==paths[k].stat().st_size,k
 binding=out/'binding.json'; bound=read(binding);result_path=out/'RESULT.json';result=read(result_path)
 assert bound['baseHead']==result['baseHead']==BASE and result['allGuardsExact'] is True
 assert result['mode']==mode and result['bindingSha256']==digest(binding)
 assert rec['command'][-3:]==[mode,'--child',digest(binding)]
 assert Path(rec['command'][1])==S/'1368-fallout-parent-prep/run.py'
 assert bound['sourceFiles']==result['sourceFiles']==1620 and bound['coreFiles']==459
 for k,h in FIXED.items():assert bound['pins'][k]==h,(k,bound['pins'].get(k))
 for k,p in [('sourcePinsSha256',P/'SOURCE-PINS.json'),('assemblySha256',P/'ASSEMBLY.json'),('runnerSha256',S/'1368-fallout-parent-prep/run.py'),('fixturePinsSha256',S/'1368-fallout-parent-prep/FIXTURE-PINS.json')]:assert digest(p)==FIXED[k],k
 assert bound['pins']['coreListSha256']==digest(P/'core-list.txt')
 fixture_map=read(S/'1368-fallout-parent-prep/FIXTURE-PINS.json');assert bound['fixturePins']==fixture_map
 # The recorded child prints each exact result row. Bind the external child logs to it.
 printed=[]
 for line in paths['raw'].read_text().splitlines():
  try:v=json.loads(line)
  except json.JSONDecodeError:continue
  if isinstance(v,dict) and 'name' in v and 'actualChildExit' in v:printed.append(v)
 assert printed==result['results'],'external RESULT differs from recorder rows'
 expected_names=['root','ui','bridge','contract','contract-fixtures'] if mode=='types' else [mode]
 assert [v['name'] for v in printed]==expected_names
 child_files={}
 for v in printed:
  path=out/(v['name']+'.txt');assert digest(path)==v['rawSha256'];child_files[v['name']]=path
 assert rec['exitCode']==(0 if all(v['actualChildExit']==0 for v in printed) else 1)
 artifacts={str(p):{'sha256':digest(p),'bytes':p.stat().st_size} for p in [*paths.values(),binding,result_path,*child_files.values()]}
 if mode!='types':
  report_path=out/'vitest.json';assert digest(report_path)==result['vitestJsonSha256'];report=read(report_path)
  start,end=stamp(rec['start']),stamp(rec['end']);assert start<=report['startTime']<=end
  for f in report['testResults']:assert report['startTime']<=f['startTime']<=f['endTime']<=end
  cmd=printed[0]['command'];assert cmd[:3]==['node','node_modules/vitest/vitest.mjs','run']
  assert '--reporter=verbose' in cmd and '--reporter=json' in cmd and '--outputFile.json='+str(report_path) in cmd
  if mode=='d16':assert cmd[3:5]==['--config','src/harness/d16/vitest.d16.config.ts']
  else:assert cmd[3:5]==['--project',mode]
  if mode=='core':assert cmd[5:-3]==(P/'core-list.txt').read_text().splitlines()
  artifacts[str(report_path)]={'sha256':digest(report_path),'bytes':report_path.stat().st_size}
 else:report=None
 return rec,result,child_files,report,artifacts

def json_rows(report,prefix):
 rows=[];files=[];suite_errors=[]
 for file_index,f in enumerate(report['testResults']):
  assert f['name'].startswith(prefix+'/'),f['name'];file=f['name'][len(prefix)+1:];files.append(file)
  if f.get('message'):suite_errors.append({'file':file,'status':f['status'],'message':f['message']})
  for assertion_index,a in enumerate(f['assertionResults']):
   identity=file+' > '+' > '.join([*a['ancestorTitles'],a['title']])
   # Display names need not be unique: Vitest truncates interpolated parameters.
   # This locator identifies one assertion in this exact pinned report, not across runs.
   rows.append({'file':file,'identity':identity,'caseLocator':{'file':file,'assertionIndex':assertion_index},
    'reportLocation':{'fileIndex':file_index,'assertionIndex':assertion_index},
    'status':a['status'],'fullName':a['fullName'],'failureMessages':a.get('failureMessages',[]),'duration':a.get('duration'),
    'sourceLocation':a.get('location'),'originalAssertion':a})
 assert len(files)==len(set(files)),'duplicate test files'
 assert len(rows)==len({(r['file'],r['caseLocator']['assertionIndex']) for r in rows}),'duplicate assertion locator'
 multiplicities=Counter(r['identity'] for r in rows);seen=Counter()
 for row in rows:
  seen[row['identity']]+=1
  row['displayOccurrence']=seen[row['identity']]
  row['displayMultiplicity']=multiplicities[row['identity']]
 return rows,files,suite_errors

def raw_detail(raw):
 text=re.sub(r'\x1b\[[0-9;]*m','',raw)
 # Group shared FAIL headers before the same marker so every identity retains the actual helper frames.
 first=re.search(r'^ FAIL \|(?:core|ui|d16)\|',text,re.M)
 if not first:return []
 body=text[first.start():];blocks=re.split(r'\n⎯+\[\d+/\d+\]⎯[^\n]*\n',body);groups=[]
 for block in blocks:
  headers=list(re.finditer(r'^ FAIL \|(?:core|ui|d16)\|\s+(.*)$',block,re.M))
  if not headers:continue
  message=block[headers[-1].end():]
  groups.append({'headers':[h.group(1).strip() for h in headers],'rawBody':message,'frames':re.findall(r'^\s*❯ (.*)$',message,re.M)})
 return groups

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['types','core','ui','d16']);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args()
 out=a.output;assert out.is_absolute() and not os.path.lexists(out)
 assert all(not p.is_symlink() for p in out.parents)
 for forbidden in [R,P,Path(__file__).parent]:assert out!=forbidden and forbidden not in out.parents
 rec,result,child_files,report,artifacts=guards(a.mode)
 for tool in [Path(__file__),Path(__file__).with_name('legacy_raw_parser.py'),Path(__file__).with_name('PARSER-ORIGIN.json')]:artifacts[str(tool)]={'sha256':digest(tool),'bytes':tool.stat().st_size}
 products={};summary={'mode':a.mode,'status':'ATTRIBUTION_ONLY','actualChildExit':rec['exitCode'],'sourceGuardsExact':True,'start':rec['start'],'end':rec['end'],'causes':'Unassigned; parent review required','artifacts':artifacts}
 if a.mode=='types':
  rows=[]
  for name,path in child_files.items():
   txt=path.read_text();rows.append({'name':name,'actualChildExit':next(x['actualChildExit'] for x in result['results'] if x['name']==name),'diagnostics':re.findall(r'^.*error TS\d+:.*$',txt,re.M),'fullText':txt})
  products['types-and-generators.json']=rows
  summary['limits']='No historical type-diagnostic equivalence assumed; full outputs retained. No baseline cause is assigned.'
 else:
  rows,files,suite_errors=json_rows(report,str(T));census=S/'1368-save46-fallout-prep/census-6c60'
  expected=(P/'core-list.txt').read_text().splitlines() if a.mode=='core' else (census/('ui-204.txt' if a.mode=='ui' else 'd16-10.txt')).read_text().splitlines()
  inventory={'expectedFiles':len(expected),'actualFiles':len(files),'missingFiles':sorted(set(expected)-set(files)),'extraFiles':sorted(set(files)-set(expected)),'statuses':dict(Counter(v['status'] for v in rows)),'caseCount':len(rows),'reportCounts':{k:report.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','numRuntimeErrorTestSuites']},'suiteErrors':suite_errors}
  products['inventory.json']=inventory;products['case-rows.json']=rows
  duplicate_titles={}
  for row in rows:
   if row['displayMultiplicity']>1:duplicate_titles.setdefault(row['identity'],[]).append(row)
  products['duplicate-display-titles.json']=duplicate_titles
  inventory['duplicateDisplayGroups']=len(duplicate_titles)
  inventory['assertionsInDuplicateDisplayGroups']=sum(len(v) for v in duplicate_titles.values())
  inventory['assertionLocatorMeaning']='Zero-based position within the exact pinned JSON report; no source line or cross-run parameter identity inferred.'
  issues=[]
  if inventory['missingFiles'] or inventory['extraFiles']:issues.append('actual test file selection differs from exact inventory')
  if report['numTotalTests']!=len(rows):issues.append('reported test total differs from assertion inventory')
  failed=[r for r in rows if r['status']=='failed']
  if rec['exitCode']==0 and (failed or any(f['status']=='failed' for f in report['testResults'])):issues.append('zero child exit conflicts with failed JSON cases/files')
  if rec['exitCode']!=0 and not failed:issues.append('nonzero child exit without failed assertion cases; inspect suite/runtime errors')
  if report['numFailedTests']!=len(failed):issues.append('reported failed total differs from assertion inventory')
  for key,statuses in [('numPassedTests',('passed',)),('numPendingTests',('pending','skipped')),('numTodoTests',('todo',))]:
   if report[key]!=sum(r['status'] in statuses for r in rows):issues.append(key+' differs from assertion status inventory')
  basepath=E/BASELINES[a.mode][0];assert digest(basepath)==BASELINES[a.mode][1];baseline=read(basepath)
  artifacts[str(basepath)]={'sha256':digest(basepath),'bytes':basepath.stat().st_size}
  if a.mode=='d16':
   old,oldfiles,old_suite_errors=json_rows(baseline,str(R))
   assert len([r for r in old if r['status']=='failed'])==len({r['identity'] for r in old if r['status']=='failed'}),'duplicate baseline failure title; explicit matching required'
   assert len(failed)==len({r['identity'] for r in failed}),'duplicate current failure title; explicit matching required'
   before={r['identity']:[normalize(m,str(R)) for m in r['failureMessages']] for r in old if r['status']=='failed'}
   after={r['identity']:[normalize(m,str(T)) for m in r['failureMessages']] for r in failed}
   comparison=compare(before,after);comparison['baselineCaseCount']=len(old);comparison['newCaseIdentities']=sorted({r['identity'] for r in rows}-{r['identity'] for r in old});comparison['goneCaseIdentities']=sorted({r['identity'] for r in old}-{r['identity'] for r in rows});comparison['evidence']='Full failureMessages arrays; only exact checkout prefixes normalized; node_modules preserved.'
   if len(old)!=176 or len(before)!=12:raise AssertionError('accepted d16 baseline identity changed')
  else:
   try:
    _,raw_text,rawrows=raw_parse(str(child_files[a.mode]));products['raw-failure-rows.json']=rawrows
    assert len(baseline['rows'])==len({r['identity'] for r in baseline['rows']}),'duplicate baseline failure title; explicit matching required'
    assert len(rawrows)==len({r['identity'] for r in rawrows}),'duplicate raw failure title; explicit matching required'
    assert len(failed)==len({r['identity'] for r in failed}),'duplicate JSON failure title; explicit matching required'
    before={r['identity']:normalize(r['primary'] or '',str(R)) for r in baseline['rows']};after={r['identity']:normalize(r['primary'] or '',str(T)) for r in rawrows}
    assert len(before)==(133 if a.mode=='core' else 0),'accepted baseline changed'
    comparison=compare(before,after)
    raw_cases=Counter(r['identity'] for r in rawrows if not r['suite']);json_cases=Counter(r['identity'] for r in failed)
    if raw_cases!=json_cases:issues.append('raw and JSON failed-case identity multiplicities differ; inspect suite/name parsing before acceptance')
    products['raw-json-identity-difference.json']={'rawOnly':dict(sorted((raw_cases-json_cases).items())),'jsonOnly':dict(sorted((json_cases-raw_cases).items())),
     'rawCaseOccurrences':sum(raw_cases.values()),'jsonCaseOccurrences':sum(json_cases.values()),'rawSuiteOccurrences':sum(r['suite'] for r in rawrows)}
    comparison['evidence']='Accepted raw primary parser reused; full JSON failureMessages and raw frames preserved separately.'
   except Exception as exc:
    issues.append('raw parser requires explicit adaptation: '+repr(exc));comparison={'status':'INCOMPLETE_RAW_PARSE','error':repr(exc)}
  products['comparison-vs1361M3.json']=comparison
  raw=child_files[a.mode].read_text();products['raw-failure-blocks.json']=raw_detail(raw)
  unhandled=re.findall(r'(?:Unhandled Errors|Uncaught Exception|Unhandled Rejection)[^\n]*',raw);products['unhandled-markers.json']=unhandled
  if unhandled:issues.append('raw contains unhandled-error markers; disposition required')
  summary.update({'issues':issues,'completeIdentityAttribution':not issues,'observedFileCount':len(files),'observedCaseCount':len(rows),'observedFailedCases':len(failed),'newCount':len(comparison.get('new',[])),'goneCount':len(comparison.get('gone',[])),'changedCount':len(comparison.get('changed',[])),'sameCount':len(comparison.get('same',[]))})
 # Rehash completed inputs before emitting; no result depends on growing artifacts.
 for name,entry in artifacts.items():assert digest(Path(name))==entry['sha256'],name
 out.mkdir(parents=True)
 for name,value in {**products,'SUMMARY.json':summary}.items():
  with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 manifest={p.name:{'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
 with (out/'MANIFEST.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in summary.items() if k!='artifacts'},indent=2))
if __name__=='__main__':main()
