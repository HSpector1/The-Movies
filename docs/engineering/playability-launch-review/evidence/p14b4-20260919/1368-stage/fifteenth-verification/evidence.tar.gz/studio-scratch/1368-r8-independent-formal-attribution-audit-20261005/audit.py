from pathlib import Path
import collections, datetime, hashlib, json, subprocess
R=Path('/Users/zacheryspector/The-Movies-headless-program')
S=Path('/Users/zacheryspector/studio-scratch')
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
P=S/'1368-r8-integration-prep-r1'
O=S/'1368-r8-independent-formal-attribution-audit-20261005'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head='af16f53feb1edcb51d7e9dff109d43c7be2ec804'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert subprocess.check_output(['git','ls-remote','https://github.com/HSpector1/The-Movies.git','refs/heads/wip/headless-program-20260916-ts'],cwd=R,text=True).split()[0]==head
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R)
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R)
assert sha(S/'1368-save46-swept-proposal-r8/SOURCE-PINS.json')=='0c89540f6bb05e7a49c53100f9f4e0b203d4bc500439938b4f8334b8c0147edc'
assert sha(P/'MANIFEST.json')=='0b37a671ed357d7faf4cb0a89e2b7995c574c6a2f12ccad7aa1b67cfad0ad163'
source=json.loads((S/'1368-save46-swept-proposal-r8/SOURCE-PINS.json').read_text())
for path,digest in source.items():assert sha(S/'1368-save46-swept-proposal-r8/tree'/path)==digest,path
receipt={'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'sourceFiles':len(source),'sourcePinsSha256':sha(S/'1368-save46-swept-proposal-r8/SOURCE-PINS.json'),'kitManifestSha256':sha(P/'MANIFEST.json'),'modes':{},'issues':[]}
for mode,expected_files in [('current',104),('helper-consumers',37),('p15',4)]:
 stem=f'1368-swept-r8-{mode}-r1'; out=P/f'run-{mode}-r1'; attr=S/f'1368-r8-attribution-{mode}-r1'
 result=json.loads((out/'RESULT.json').read_text());binding=json.loads((out/'binding.json').read_text());v=json.loads((out/'vitest.json').read_text());record=json.loads((E/(stem+'.json')).read_text());post=json.loads((E/(stem+'-postflight.json')).read_text());summary=json.loads((attr/'SUMMARY.json').read_text())
 assert 'end, exit 1;' in (S/f'heavy-queue/1368-r8-{mode if mode != "p15" else "p15-formal"}-r1.log.meta').read_text() if mode!='current' else 'end, exit 1;' in (S/'heavy-queue/1368-r8-current-r1.log.meta').read_text()
 assert result['mode']==mode and result['baseHead']==head and result['sourceFiles']==len(source) and result['allGuardsExact'] and result['exactFileSelection']
 assert len(result['actualSelectedFiles'])==expected_files==len(v['testResults'])
 assert sorted(result['actualSelectedFiles'])==sorted(binding['selectedFiles'])
 assert result['bindingSha256']==sha(out/'binding.json') and result['vitestJsonSha256']==sha(out/'vitest.json')
 assert binding['baseHead']==head and binding['pins']['sourcePinsSha256']==receipt['sourcePinsSha256'] and binding['pins']['runnerSha256']==sha(P/'run.py')
 assert len(result['results'])==1 and result['results'][0]['actualChildExit']==record['exitCode']==post['exitCode']==1
 assert result['results'][0]['rawSha256']==sha(out/f'{mode}.txt')
 assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact'] and post['head']==head
 assert record['sourceSha']==record['sourceShaAtEnd'] and record['testedDiffSha256']==record['testedDiffSha256AtEnd']
 assert summary['head']==head and summary['mode']==mode and summary['files']==expected_files and sorted(summary['selectedFiles'])==sorted(result['actualSelectedFiles']) and summary['issues']==[] and summary['rawJsonFailedIdentityEqual']
 assert summary['resultSha256']==sha(out/'RESULT.json') and summary['formalRecordSha256']==sha(E/(stem+'.json')) and summary['formalPostflightSha256']==sha(E/(stem+'-postflight.json')) and summary['sourcePinsSha256']==receipt['sourcePinsSha256']
 status=collections.Counter(a['status'] for f in v['testResults'] for a in f['assertionResults'])
 for key,code in [('passed','passed'),('failed','failed'),('skipped','skipped'),('todo','todo')]:assert summary['counts'].get(key,0)==status[code],(mode,key)
 assert v['numTotalTests']==sum(status.values()) and v['numPassedTests']==status['passed'] and v['numFailedTests']==status['failed'] and v['numTodoTests']==status['todo'] and v['numPendingTests']==status['skipped']
 rows=json.loads((attr/'case-rows.json').read_text());raw=json.loads((attr/'raw-occurrences.json').read_text());assert len(rows)==v['numTotalTests'] and len(raw)==status['failed']
 assert collections.Counter(x['status'] for x in rows)==status
 assert collections.Counter((x['file'],x['fullName'],x['status']) for x in rows)==collections.Counter((str(Path(f['name']).relative_to(S/'1368-save46-swept-proposal-r8/tree')),a['fullName'],a['status']) for f in v['testResults'] for a in f['assertionResults'])
 manifest=json.loads((attr/'MANIFEST.json').read_text())['files']
 assert set(manifest)==set(x.name for x in attr.iterdir() if x.is_file() and x.name!='MANIFEST.json')
 for name,metadata in manifest.items():assert (attr/name).stat().st_size==metadata['bytes'] and sha(attr/name)==metadata['sha256'],(mode,name)
 comps={}
 for baseline,filename in [('1361M3','comparison-vs1361M3.json'),('r6','comparison-vsr6.json'),('unswept1368E','comparison-vsunswept1368E.json')]:
  d=json.loads((attr/filename).read_text());counts={k:len(d[k]) for k in ['same','new','changed','gone']};assert counts==summary['comparisons'][baseline]
  assert d['afterCount']==len(raw)==len(d['after']) and d['beforeCount']==len(d['beforeSelected'])
  key=lambda x:(x['identity'],x['occurrence'],x['primaryNormalized'])
  assert collections.Counter(map(key,d['after']))==collections.Counter(map(key,raw))
  assert collections.Counter(map(key,d['after']))==collections.Counter(map(key,[x['after'] for group in ['same','changed'] for x in d[group]]+d['new']))
  assert collections.Counter(map(key,d['beforeSelected']))==collections.Counter(map(key,[x['before'] for group in ['same','changed'] for x in d[group]]+d['gone']))
  for x in d['same']:assert key(x['before'])==key(x['after'])
  for x in d['changed']:assert x['before']['identity']==x['after']['identity'] and x['before']['primaryNormalized']!=x['after']['primaryNormalized']
  assert len(d['goneDispositions'])==len(d['gone'])
  for x in d['goneDispositions']:
   if x['disposition']=='EXECUTED_PASS':assert any(row['identity']==x['before']['identity'] and row['status']=='passed' for row in rows)
  comps[baseline]=counts
 receipt['modes'][mode]={'resultSha256':sha(out/'RESULT.json'),'formalRecordSha256':sha(E/(stem+'.json')),'formalPostflightSha256':sha(E/(stem+'-postflight.json')),'attributionManifestSha256':sha(attr/'MANIFEST.json'),'files':expected_files,'counts':dict(status),'comparisons':comps,'manifestMembersVerified':len(manifest),'fixedSource':True,'allGuardsExact':True,'exactFileSelection':True}
(O/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,indent=2))
