# Ledger r4 low-space runner r2 — static review

This is a scratch-only, versioned runner proposal. Frozen r4 prep, kit, C0/ABC arms, live source, Git index, and formal R8 run were not edited. No r2 types or simulation was launched.

The full `RUNNER-DELTA.diff` from frozen r4 `run.py` changes only:

- Output namespace to `1368-ledger-recorded-runs-r4-lowspace-r2` and formal stem `1368-ledger-r4-lowspace-r2-*`, preserving exclusive output checks.
- Operational launch floor from 5 GiB to 3 GiB. **3 GiB is a chosen operational threshold, not a measured safe minimum.** No actual low-space run exists yet.
- The three required runner-path bindings: parent self-path assertion, recorder `--child` executable path, and expected recorder command. All now point at this versioned `run.py`. The child also verifies its own resolved path.
- A required `--self-runner-sha256` pin. Preflight, child, and cleanup source checks hash this exact file; the pin enters the immutable binding and result `pins`. A clean or observed run must consume an accepted types or clean receipt carrying the same runner pin. The original r4 package manifest and all kit/arm pins remain mandatory.

Python AST parsing passed for frozen and proposed runner. The diff was reviewed: fixed source scope, 188/197-file inventory, original manifest, protected helper and entrypoint hashes, remote/HEAD/index/source checks, seed and 416-week route, 300-second leaf and 330-second outer cap, Node/recorder/cleanup behavior, progress/launch receipts, result admission, and comparator are unchanged. The original `compare.py` is still the comparator. Read-only `verify(head, originalManifest, arm, selfRunnerPin)` passed for both arms at local/remote HEAD `af16f53feb1edcb51d7e9dff109d43c7be2ec804`; no other runner or kit path change was found in that check. This is static launchability, not a completed run.

The formal R8 current run was still active when reviewed, so **do not launch r2 now**. After its recorded child and postflight end, the heavy lane is idle, no writer is active, AC/power are checked, current HEAD equals explicit remote, sources and arms still match, and measured free space is at least 3 GiB, the first bounded command is:

```sh
python3 -B /Users/zacheryspector/studio-scratch/1368-ledger-lowspace-runner-proposal-r2/run.py types --arm ABC --head af16f53feb1edcb51d7e9dff109d43c7be2ec804 --manifest-sha256 3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f --self-runner-sha256 7eb654ebd6b45ab297262b38315414643a1ac26d08b3a03c7b78dcd875aa6f4d --leaf r1
```

The exclusive output is `/Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4-lowspace-r2/ABC-types-source-r1/RESULT.json`; formal stem is `1368-ledger-r4-lowspace-r2-abc-types-source-r1`. If HEAD advances before the launch, substitute the newly verified full local/remote-matched HEAD. Do not reuse a partially created leaf. Inspect actual child/recorder exit, source/postflight and process-group cleanup guards, all artifact hashes and exact self-runner pin. Only an accepted types receipt/hash allows clean p13a; only an accepted clean p13a receipt/hash allows observed p13a. Do not use historical r3 types/clean receipts as r2 prerequisites, infer a result for the incomplete r3 observed attempt, or repin the four C0 protected digest differences.

Remaining limits: the floor reduction is unmeasured operational discretion; the active heavy lane still blocks execution. This review asserts static binding and guard continuity only. No additional runner/kit path changes were required by the static checks.
