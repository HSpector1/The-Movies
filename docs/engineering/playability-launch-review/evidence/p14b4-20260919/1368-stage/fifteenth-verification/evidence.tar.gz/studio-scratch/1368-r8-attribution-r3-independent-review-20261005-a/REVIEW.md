# Independent static re-review: R8 attribution r3

**Disposition: ACCEPT for bounded attribution after formal postflight completes.** Reviewed `/Users/zacheryspector/studio-scratch/1368-r8-attribution-prep-r3/attribute_r8.py` SHA-256 `e68eb63b9032ee14167dd421fe7a1d236851b99d5cb2d472249cb0e5dd31ea5d`. It is byte identical to the prior scratch-only refinement and Python AST parsing succeeds. I did not execute the adapter against the active R8 current run or start a test. At review, current `run-current-r1/RESULT.json` was absent; the prepared binding exists with head `af16f53feb1edcb51d7e9dff109d43c7be2ec804`, and completed `run-types-r2` uses the same head.

The three prior REFINE findings are closed:

1. **Package/source pins.** Lines 17-23 verify the literal package manifest hash and every member's regular-file status, SHA-256 and byte length before selections are read. I independently rehashed all seven package members: zero mismatches. Lines 78-85 require both run/type binding source counts and fixture maps to match, bind current/type pins to each other, and bind source, assembly, runner, selection, producer configuration, fixture, symlink inventory, untracked inventory and scratch diff pins to their actual frozen bytes. This prevents a changed `run.py` or selection member being silently repinned as an attribution input.
2. **Recorder/result relationship.** Lines 53-63 retain exact completed formal record/postflight hashes and source/index guards. Lines 94-102 now extract the child-result JSON rows printed in the formal raw records and require exact equality to both external RESULT arrays. The child raw file/report hashes and exact command remain checked at lines 73-93.
3. **Duplicate occurrences.** Lines 165-181 retain exact display identity and normalized-primary occurrence matching. Line 168 adds an issue for any duplicate display group, so `completeIdentityAttribution` cannot be true without parameter-level review. Lines 184-188 permit `EXECUTED_PASS` for a gone occurrence only with one baseline occurrence, one current JSON assertion, unique current display title and passed status. Ambiguous cases remain explicit in output.

Selected-file baseline scope at lines 159-162 and 183 remains bounded and preserves out-of-selection rows. Accepted M3, unswept and R6 hashes remain fixed at lines 141-156. Outputs retain full case/raw occurrences, suite/unhandled evidence, comparison classifications, artifact rehash and output manifest at lines 157-196. No identity rewrite, deadline increase, source edit or broad recovery claim was introduced.

**Exact current command, only after `run-current-r1/RESULT.json` and the matching formal current postflight are complete:**

```bash
/usr/local/opt/python@3.14/bin/python3.14 /Users/zacheryspector/studio-scratch/1368-r8-attribution-prep-r3/attribute_r8.py current --run-id r1 --types-run-id r2 --head af16f53feb1edcb51d7e9dff109d43c7be2ec804
```

The command writes a new `/Users/zacheryspector/studio-scratch/1368-r8-attribution-current-r1` directory; r3 refuses if it already exists. It will reject incomplete or mismatched records. An `ACCEPT` here approves the adapter's static checks, not any as-yet-unmeasured current fallout result.
