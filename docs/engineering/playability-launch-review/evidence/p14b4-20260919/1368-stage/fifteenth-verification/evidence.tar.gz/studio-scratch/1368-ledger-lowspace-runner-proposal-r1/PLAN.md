# Ledger r4 low-space runner proposal r1 — static, unlaunchable

This scratch copy is a three-line proposal against the frozen `/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/run.py` (SHA-256 `80e156a5aa24c8f901eee765b4a31d54e94160ed4567736c3adfb1accad390c8`). `RUNNER-DELTA.diff` is complete. Both files parse as Python AST; exactly lines 9, 186 and 187 differ. The changed output namespaces are `1368-ledger-recorded-runs-r4-lowspace-r1` and formal stem `1368-ledger-r4-lowspace-r1-*`, preserving exclusive output rules and the original records. The operational free-space assertion changes from 5 GiB to 3 GiB. This does **not** establish 3 GiB as a measured minimum or alter source, horizon, 300/330-second limits, cleanup, process handling, comparator, or kit bytes.

**No launch command is safe for this r1 proposal.** The original runner has three strict self-path bindings beyond the requested output namespace and disk check:

1. `main()` asserts `Path(__file__).resolve() == P / 'run.py'`, where `P` is the frozen prep directory. The scratch copy fails before any output or test launch.
2. The formal recorder invokes `P / 'run.py'` for `--child`. If only the assertion were changed, the recorder would still execute the original 5 GiB runner rather than this proposal.
3. The postflight command assertion expects the same original `P / 'run.py'`; it must follow any changed child command exactly.

The original package manifest pins the original runner, so a runnable replacement also needs a **new versioned runner provenance pin**. Keeping the original kit manifest and arm pins is desirable; those paths do not need to change. The three path bindings and runner provenance require explicit narrow review before making an executable r2. This r1 intentionally leaves them unchanged under the instruction to stop rather than broaden scope silently.

After a separately reviewed runnable r2 exists, its first possible command must wait for the active formal R8 run and postflight to finish, an idle heavy lane, AC/power, actual published HEAD and remote match, unchanged source/index/arms, and at least 3 GiB measured free space. Run fresh ABC types before clean p13a; require the exact accepted types receipt/hash, then accepted clean receipt/hash before observed p13a. No r3 receipt can satisfy same-runner source binding, and the r3 observed attempt remains incomplete after EPERM. The r4 cleanup fix is present in the frozen prep package, but this static proposal performs no cleanup or simulator measurement.

To review the narrow runnable extension, compare the copy to the original and require only the three path bindings above and explicit self-runner pinning in addition to the three already proposed lines. Preserve formal recorder source/HEAD/index checks, child and recorder actual exit distinctions, exact cleanup/postflight guards, and exclusive output paths. Do not launch this r1 or invoke `--help` as a substitute for its failed preflight.
