import argparse, hashlib, importlib.util, json, os, re, sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

S=Path('/Users/zacheryspector/studio-scratch')
R=Path('/Users/zacheryspector/The-Movies-headless-program')
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
P=S/'1368-r8-integration-prep-r1'
C=S/'1368-save46-swept-proposal-r8'
VPATH=S/'1368-r6-fallout-comparison-prep/reviewed_v2.py'
RAWPATH=VPATH.with_name('legacy_raw_parser.py')
sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
read=lambda path: json.loads(Path(path).read_text())
assert sha(C/'SOURCE-PINS.json')=='0c89540f6bb05e7a49c53100f9f4e0b203d4bc500439938b4f8334b8c0147edc'
assert sha(C/'ASSEMBLY.json')=='878f5615318d0d1fc1f76c07b1bd507cb9f820a59a18efe58587ae035c7d39ad'
assert sha(P/'MANIFEST.json')=='0b37a671ed357d7faf4cb0a89e2b7995c574c6a2f12ccad7aa1b67cfad0ad163'
package=read(P/'MANIFEST.json')
assert package['sourcePinsSha256']=='0c89540f6bb05e7a49c53100f9f4e0b203d4bc500439938b4f8334b8c0147edc'
assert package['assemblySha256']=='878f5615318d0d1fc1f76c07b1bd507cb9f820a59a18efe58587ae035c7d39ad'
for name,value in package['files'].items():
 path=P/name
 assert path.is_file() and not path.is_symlink() and sha(path)==value['sha256'] and path.stat().st_size==value['bytes'],name
assert sha(VPATH)=='f9d449ec18327cecc58e0d3ce4ee4ba205adc5156ed4cb0a87916d6f115a878b'
assert sha(RAWPATH)=='13bf103a99be3b066818052fce511ffacdde481991b280e2463b189534bbdf6c'
# The reviewed module imports its original raw parser by module name.
sys.dont_write_bytecode=True
sys.path.insert(0,str(VPATH.parent))
spec=importlib.util.spec_from_file_location('reviewed_v2',VPATH);V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
selections=read(P/'SELECTIONS.json')['selections']
parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=['current','helper-consumers','p15','modified10'])
parser.add_argument('--run-id',required=True)
parser.add_argument('--types-run-id',required=True)
parser.add_argument('--head',required=True)
a=parser.parse_args()
assert re.fullmatch('[a-z0-9][a-z0-9-]{0,39}',a.run_id)
assert re.fullmatch('[a-z0-9][a-z0-9-]{0,39}',a.types_run_id)
assert re.fullmatch('[0-9a-f]{40}',a.head)
selected=selections[a.mode]
out=S/f'1368-r8-attribution-{a.mode}-{a.run_id}'
assert not os.path.lexists(out)
assert out.is_absolute() and not any(p.is_symlink() for p in out.parents)

artifacts={}
def pin(path):
 path=Path(path)
 assert path.is_file() and not path.is_symlink(),path
 value={'sha256':sha(path),'bytes':path.stat().st_size}
 artifacts[str(path)]=value
 return value

def formal(mode,runid):
 stem=f'1368-swept-r8-{mode}-{runid}'
 paths={k:E/(stem+s) for k,s in {'record':'.json','pre':'-preflight.json','post':'-postflight.json','raw':'.txt','patch':'.patch'}.items()}
 rec=read(paths['record']);pre=read(paths['pre']);post=read(paths['post'])
 assert rec['sourceSha']==rec['sourceShaAtEnd']==pre['head']==post['head']==a.head
 assert rec['fixedSource'] and post['fixedSource'] and post['allGuardsExact'] and rec['exitCode']==post['exitCode']
 assert rec['end'] and rec['signal'] is None and rec['error'] is None
 for k in ['guardScope','head','sourcePaths','sourceFiles','sourceInventory','manual','index','stageEntries']:assert pre[k]==post[k],k
 for k in ['record','raw','patch']:assert post[k]['sha256']==sha(paths[k]) and post[k]['bytes']==paths[k].stat().st_size,k
 for path in paths.values():pin(path)
 return rec,paths

trec,tp=formal('types',a.types_run_id)
assert trec['exitCode']==0
tr=P/f'run-types-{a.types_run_id}'
types=read(tr/'RESULT.json');tb=read(tr/'binding.json')
assert types['mode']=='types' and types['sourceFiles']==tb['sourceFiles']==1630
assert types['baseHead']==a.head and types['allGuardsExact'] and all(x['actualChildExit']==0 for x in types['results'])
assert trec['exitCode']==(0 if all(x['actualChildExit']==0 for x in types['results']) else 1)
assert tb['baseHead']==a.head and tb['selectedFiles']==[] and types['bindingSha256']==sha(tr/'binding.json')
assert trec['command']==[sys.executable,str((P/'run.py').resolve()),'types','--head',a.head,'--run-id',a.types_run_id,'--child',sha(tr/'binding.json')]
for row in types['results']:assert row['rawSha256']==sha(tr/(row['name']+'.txt'))
root=P/f'run-{a.mode}-{a.run_id}'
result=read(root/'RESULT.json');bound=read(root/'binding.json')
rec,fp=formal(a.mode,a.run_id)
assert result['baseHead']==bound['baseHead']==a.head and result['mode']==a.mode and result['sourceFiles']==bound['sourceFiles']==1630
assert result['allGuardsExact'] and result['bindingSha256']==sha(root/'binding.json')
assert result['exactFileSelection'] and result['actualSelectedFiles']==sorted(selected)
assert bound['pins']==tb['pins'] and bound['selectedFiles']==selected
assert bound['fixturePins']==tb['fixturePins']==read(P/'FIXTURE-PINS.json')
for key,path in [('sourcePinsSha256',C/'SOURCE-PINS.json'),('assemblySha256',C/'ASSEMBLY.json'),('runnerSha256',P/'run.py'),('selectionSha256',P/'SELECTIONS.json'),('producerConfigSha256',P/'tsconfig.producers.json'),('fixturePinsSha256',P/'FIXTURE-PINS.json'),('sourceLinksSha256',P/'SOURCE-LINKS.json'),('untrackedSha256',P/'UNTRACKED.json')]:
 assert bound['pins'][key]==sha(path),key
assert bound['pins']['scratchDiffSha256']==(P/'DIFF.sha256').read_text().strip()
expected=[tr/'binding.json',tr/'RESULT.json',*[tr/(x['name']+'.txt') for x in types['results']],*tp.values()]
assert bound['typesPrerequisite']=={str(x):sha(x) for x in expected}
assert rec['command']==[sys.executable,str((P/'run.py').resolve()),a.mode,'--head',a.head,'--run-id',a.run_id,'--child',sha(root/'binding.json'),'--types-run-id',a.types_run_id]
assert result['results'][0]['actualChildExit']==rec['exitCode']
assert result['results'][0]['command']==['node','node_modules/vitest/vitest.mjs','run','--project','core',*selected,'--reporter=verbose','--reporter=json','--outputFile.json='+str(root/'vitest.json')]
assert result['results'][0]['rawSha256']==sha(root/(a.mode+'.txt'))
assert result['vitestJsonSha256']==sha(root/'vitest.json')
assert rec['exitCode']==(0 if all(x['actualChildExit']==0 for x in result['results']) else 1)
def printed_results(path):
 found=[]
 for line in path.read_text().splitlines():
  try:value=json.loads(line)
  except json.JSONDecodeError:continue
  if isinstance(value,dict) and 'name' in value and 'actualChildExit' in value:found.append(value)
 return found
assert printed_results(tp['raw'])==types['results']
assert printed_results(fp['raw'])==result['results']
for path in [tr/'RESULT.json',tr/'binding.json',root/'RESULT.json',root/'binding.json',root/'vitest.json',root/(a.mode+'.txt'),VPATH,RAWPATH,C/'SOURCE-PINS.json',C/'ASSEMBLY.json',P/'MANIFEST.json',P/'SELECTIONS.json',P/'run.py'] :pin(path)
for name in package['files']:pin(P/name)
pin(Path(__file__))
for row in types['results']:pin(tr/(row['name']+'.txt'))
source=read(C/'SOURCE-PINS.json')
assert len(source)==1630 and all(sha(C/'tree'/name)==h for name,h in source.items())
report=read(root/'vitest.json')
start,end=V.stamp(rec['start']),V.stamp(rec['end'])
assert start<=report['startTime']<=end
assert all(report['startTime']<=f['startTime']<=f['endTime']<=end for f in report['testResults'])
rows,files,suite=V.json_rows(report,str(C/'tree'))
assert sorted(files)==sorted(selected) and len(rows)==report['numTotalTests']
counts=Counter(x['status'] for x in rows)
assert counts['passed']==report['numPassedTests'] and counts['failed']==report['numFailedTests']
assert counts['pending']+counts['skipped']==report['numPendingTests'] and counts['todo']==report['numTodoTests']
_,_,rawrows=V.raw_parse(str(root/(a.mode+'.txt')))
rc=Counter(x['identity'] for x in rawrows if not x['suite'])
jc=Counter(x['identity'] for x in rows if x['status']=='failed')
issues=[]
if rc!=jc:issues.append('raw/JSON failed occurrence multiplicity mismatch')
if suite:issues.append('JSON suite errors require separate disposition')
if report.get('numRuntimeErrorTestSuites',0):issues.append('runtime suite errors require separate disposition')
raw_text=(root/(a.mode+'.txt')).read_text()
unhandled=re.findall(r'(?:Unhandled Errors|Uncaught Exception|Unhandled Rejection)[^\n]*',raw_text)
if unhandled:issues.append('raw unhandled-error markers require disposition')
if rec['exitCode']==0 and (jc or suite):issues.append('zero child exit contradicts failed assertions or suite errors')
if rec['exitCode']!=0 and not jc and not suite:issues.append('nonzero child without failed assertions or suite errors')
if Counter(row['identity'] for row in rows if row['status']=='failed')!=rc:issues.append('case occurrence reconciliation failed')

def selected_raw(row):return row['file'] in selected or (row.get('suite') and row['file'] in [x+' [ '+x+' ]' for x in selected])
assert all(selected_raw(x) for x in rawrows)
def occurrence_rows(records,prefix):
 seen=Counter();result=[]
 for row in records:
  seen[row['identity']]+=1
  result.append({'identity':row['identity'],'occurrence':seen[row['identity']],'primaryNormalized':V.normalize(row['primary'] or '',str(prefix)),'raw':row})
 return result
after=occurrence_rows(rawrows,C/'tree')
m3=read(E/'1361-stage/land/attr-core-live/core-failures.json')['rows']
unswept=read(S/'1368-fallout-attribution-core-r2/raw-failure-rows.json')
assert sha(E/'1361-stage/land/attr-core-live/core-failures.json')=='4cf7485d2842a966325cf57c917d708691fbce9485b5161d7a10affa7de96c38'
assert sha(S/'1368-fallout-attribution-core-r2/raw-failure-rows.json')=='fbcfd908b23c7f0e65c0ffd2fb878879a97dbf0a5b026b5092560ccce36692bb'
prior=[]
prior_dir=None
if a.mode in ['current','helper-consumers','p15']:
 prior_dir=S/f"1368-r6-attribution-{a.mode}-{'r2' if a.mode=='p15' else 'r1'}"
 expected_manifest={'current':'148aca0c8f5e49644ce9522a15f6f052f1732017e1b4a5731ffd92df0592e217','helper-consumers':'d3842fe6cb977e8919720e9785ff99b31e59eee100a684686c8b5ddea4d29685','p15':'1d317e72e1a2180d88adb15e46350d4a4bd1d86947b770fd6aac3deda8f9b9cb'}[a.mode]
 assert sha(prior_dir/'MANIFEST.json')==expected_manifest
 manifest=read(prior_dir/'MANIFEST.json')
 assert sha(prior_dir/'raw-failure-rows.json')==manifest['raw-failure-rows.json']['sha256']
 pin(prior_dir/'MANIFEST.json')
 prior=read(prior_dir/'raw-failure-rows.json')
for path in [E/'1361-stage/land/attr-core-live/core-failures.json',S/'1368-fallout-attribution-core-r2/raw-failure-rows.json'] :pin(path)
if prior_dir:pin(prior_dir/'raw-failure-rows.json')
outputs={'case-rows.json':rows,'raw-failure-rows.json':rawrows,'raw-occurrences.json':after,'raw-json-identity-difference.json':{'rawOnly':dict(rc-jc),'jsonOnly':dict(jc-rc),'rawCaseOccurrences':sum(rc.values()),'jsonCaseOccurrences':sum(jc.values()),'rawSuiteOccurrences':sum(x['suite'] for x in rawrows)},'suite-errors.json':suite,'raw-failure-blocks.json':V.raw_detail(raw_text),'unhandled-markers.json':unhandled}
comparisons={}
for label,baseline,prefix in [('1361M3',m3,R),('unswept1368E',unswept,S/'1368-save46-fallout-r1/tree'),('r6',prior,S/'1368-save46-swept-proposal-r6/tree')]:
 if label=='r6' and not prior:continue
 within=[x for x in baseline if selected_raw(x)]
 before=occurrence_rows(within,prefix)
 # Compare raw occurrences by exact display identity and normalized primary.
 # Equal multisets are stable even when Vitest prints duplicate titles in a new order.
 bg=defaultdict(list);ag=defaultdict(list)
 for x in before:bg[x['identity']].append(x)
 for x in after:ag[x['identity']].append(x)
 if any(len(group)>1 for group in [*bg.values(),*ag.values()]):
  issues.append(label+' duplicate display identities need parameter-level review')
 same=[];new=[];changed=[];gone=[]
 for identity in sorted(bg.keys()|ag.keys()):
  bs=bg[identity];aa=ag[identity]
  bymsg=defaultdict(list);aymsg=defaultdict(list)
  for x in bs:bymsg[x['primaryNormalized']].append(x)
  for x in aa:aymsg[x['primaryNormalized']].append(x)
  for message in sorted(bymsg.keys() & aymsg.keys()):
   n=min(len(bymsg[message]),len(aymsg[message]));same.extend({'before':b,'after':c} for b,c in zip(bymsg[message][:n],aymsg[message][:n]));del bymsg[message][:n];del aymsg[message][:n]
  bleft=[x for v in bymsg.values() for x in v];aleft=[x for v in aymsg.values() for x in v]
  bleft.sort(key=lambda x:(x['primaryNormalized'],x['occurrence']));aleft.sort(key=lambda x:(x['primaryNormalized'],x['occurrence']))
  n=min(len(bleft),len(aleft))
  changed.extend({'before':b,'after':c,'pairing':'same display identity; message-sorted occurrence pairing, not a parameter identity claim'} for b,c in zip(bleft[:n],aleft[:n]))
  gone.extend(bleft[n:]);new.extend(aleft[n:])
 comparison={'scope':'selected whole-file raw occurrence identities; absent failure is not automatic repair','selectedFiles':selected,'beforeCount':len(before),'afterCount':len(after),'beforeSelected':before,'beforeNotSelected':[x for x in baseline if not selected_raw(x)],'after':after,'same':same,'new':new,'changed':changed,'gone':gone}
 comparison['goneDispositions']=[]
 for item in gone:
  matches=[x for x in rows if x['identity']==item['identity']]
  disposition='EXECUTED_PASS' if len(bg[item['identity']])==1 and len(matches)==1 and matches[0]['displayMultiplicity']==1 and matches[0]['status']=='passed' else 'MASKED_OR_ABSENT_OR_AMBIGUOUS_REQUIRES_REVIEW'
  comparison['goneDispositions'].append({'before':item,'currentOccurrences':matches,'disposition':disposition})
 comparisons[label]={k:len(comparison[k]) for k in ['same','new','changed','gone']}
 outputs[f'comparison-vs{label}.json']=comparison
summary={'status':'PARENT_ATTRIBUTION_ONLY_NOT_SEPARATE_REVIEWER','mode':a.mode,'head':a.head,'sourcePinsSha256':sha(C/'SOURCE-PINS.json'),'resultSha256':sha(root/'RESULT.json'),'typesResultSha256':sha(tr/'RESULT.json'),'formalRecordSha256':sha(fp['record']),'formalPostflightSha256':sha(fp['post']),'selectedFiles':selected,'files':len(files),'counts':dict(counts),'rawJsonFailedIdentityEqual':rc==jc,'suiteErrors':len(suite),'issues':issues,'completeIdentityAttribution':not issues,'comparisons':comparisons,'artifacts':artifacts,'limits':'Selected whole-file raw occurrence identities only; duplicate display titles preserve each occurrence but do not establish cross-run parameter identity. No automatic repair from absent baseline failures, no independent review or overall acceptance.'}
outputs['SUMMARY.json']=summary
for path,value in artifacts.items():assert sha(path)==value['sha256'] and Path(path).stat().st_size==value['bytes'],path
out.mkdir()
for name,data in outputs.items():(out/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
manifest={name:{'sha256':sha(out/name),'bytes':(out/name).stat().st_size} for name in outputs}
(out/'MANIFEST.json').write_text(json.dumps({'files':manifest},indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2))
