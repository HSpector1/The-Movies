# Explicit-file R8 landing kit (unapplied)

Prepared 2026-10-05 from frozen R8 `1368-save46-swept-proposal-r8/tree` for the live repo `/Users/zacheryspector/The-Movies-headless-program`. This kit contains precisely ten changed tests and four new historical fixture files under `payload/`. The source assembly and source-pin SHA-256s are recorded in `MANIFEST.json`; every payload is pinned to its source pin. The ten live file preimage hashes and four expected absences are recorded there too.

`python3 landing.py` performs read-only preflight and prints the ten unified text diffs plus four fixture add summaries. The captured output is `PREVIEW.diff`. Preflight refuses any changed live preimage, missing or changed source pin, missing payload, symlink payload, symlink destination ancestor, or destination collision. It does not run tests or inspect closure gates.

After the separate current/helper/P15 fallout and ledger gates close, a coordinator may run `python3 landing.py --apply --after-gates`. That future command installs only the fourteen allowlisted files and checks postimage hashes. It never invokes Git, edits `HANDOFF.md`, or copies the scratch `tests/fixtures/p14` or `p15` directory representation. The two fixture subdirectories are created as ordinary directories in the live repo. The coordinator must check that no recorded run/postflight is active before application, then perform the normal source-qualified tests, review and history-preserving commit workflow separately.

The future apply mode checks all preimages before writing, but filesystem replacement across fourteen separate files is not a single transaction. If an unexpected write error occurs, stop and inspect the live tree. The pinned live preimages make this kit intentionally stale if another authorized source edit lands first; in that case regenerate and review a new kit instead of overriding it.

Scratch R8 has local `tests/fixtures/p14` and `p15` directories with absolute symlinks for existing fixture children. Those symlinks are assembly plumbing and are excluded from this kit. Never recursively copy or stage those scratch directories.
