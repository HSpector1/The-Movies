#!/usr/bin/env python3
"""Verify and optionally install exactly the R8 landing-kit files.

Default mode is read-only. Application requires both --apply and --after-gates.
The caller, not this script, decides whether fallout/ledger/run gates are closed.
"""

import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import tempfile

KIT = Path(__file__).resolve().parent
MANIFEST = json.loads((KIT / "MANIFEST.json").read_text())
REPO = Path(MANIFEST["liveRepo"])


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_path(root: Path, relative: str) -> Path:
    part = Path(relative)
    if part.is_absolute() or ".." in part.parts or not part.parts or part.parts[0] != "tests":
        raise RuntimeError(f"unsafe path: {relative}")
    path = root / part
    cursor = root
    for segment in part.parts[:-1]:
        cursor = cursor / segment
        if cursor.is_symlink():
            raise RuntimeError(f"symlink ancestor: {cursor}")
    return path


def verify():
    if not (REPO / ".git").exists():
        raise RuntimeError("live repo identity missing")
    source_root = Path(MANIFEST["sourceTree"]).parent
    source_pins_bytes = (source_root / "SOURCE-PINS.json").read_bytes()
    assembly_bytes = (source_root / "ASSEMBLY.json").read_bytes()
    if sha(source_pins_bytes) != MANIFEST["sourcePinsSha256"]:
        raise RuntimeError("frozen R8 SOURCE-PINS.json changed")
    if sha(assembly_bytes) != MANIFEST["assemblySha256"]:
        raise RuntimeError("frozen R8 ASSEMBLY.json changed")
    source_pins = json.loads(source_pins_bytes)
    assembly = json.loads(assembly_bytes)
    entries = MANIFEST["entries"]
    if len(entries) != 14 or len({row["path"] for row in entries}) != 14:
        raise RuntimeError("expected exactly fourteen distinct paths")
    if sum(row["action"] == "replace" for row in entries) != 10:
        raise RuntimeError("expected ten replacements")
    if sum(row["action"] == "add" for row in entries) != 4:
        raise RuntimeError("expected four additions")
    if [row["path"] for row in entries if row["action"] == "replace"] != assembly["changed"]:
        raise RuntimeError("replacement allowlist differs from frozen assembly")
    if [row["path"] for row in entries if row["action"] == "add"] != assembly["added"]:
        raise RuntimeError("addition allowlist differs from frozen assembly")
    checked = []
    for row in entries:
        relative = row["path"]
        source = safe_path(KIT / "payload", relative)
        target = safe_path(REPO, relative)
        if not source.is_file() or source.is_symlink():
            raise RuntimeError(f"missing or linked payload: {relative}")
        payload = source.read_bytes()
        if row["postimage"]["sha256"] != source_pins[relative]:
            raise RuntimeError(f"postimage differs from frozen R8 pin: {relative}")
        if sha(payload) != row["postimage"]["sha256"] or len(payload) != row["postimage"]["bytes"]:
            raise RuntimeError(f"postimage hash/length mismatch: {relative}")
        if row["action"] == "replace":
            if not target.is_file() or target.is_symlink():
                raise RuntimeError(f"preimage is not a regular file: {relative}")
            original = target.read_bytes()
            if sha(original) != row["preimage"]["sha256"] or len(original) != row["preimage"]["bytes"]:
                raise RuntimeError(f"live preimage changed: {relative}")
        else:
            if target.exists() or target.is_symlink():
                raise RuntimeError(f"addition already exists: {relative}")
            original = None
        checked.append((row, target, original, payload))
    return checked


def preview(checked):
    for row, _, original, payload in checked:
        name = row["path"]
        if name.endswith(".ts"):
            old = original.decode("utf-8").splitlines(keepends=True)
            new = payload.decode("utf-8").splitlines(keepends=True)
            print("".join(difflib.unified_diff(old, new, fromfile=f"live/{name}", tofile=f"r8/{name}")), end="")
        else:
            print(f"ADD {name}: {len(payload)} bytes sha256={sha(payload)}")


def apply(checked):
    # All preimages and payloads have passed before the first write. The parent
    # directories of the two additions are new; existing directories remain.
    for _, target, _, payload in checked:
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".r8-landing-", dir=target.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(temporary, 0o644)
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
    for row, target, _, _ in checked:
        if sha(target.read_bytes()) != row["postimage"]["sha256"]:
            raise RuntimeError(f"postflight mismatch: {row['path']}")
    print("Installed fourteen explicit files; Git index, HEAD, HANDOFF untouched.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--after-gates", action="store_true")
    args = parser.parse_args()
    if args.after_gates and not args.apply:
        parser.error("--after-gates is only meaningful with --apply")
    if args.apply and not args.after_gates:
        parser.error("--apply requires --after-gates")
    checked = verify()
    if args.apply:
        apply(checked)
    else:
        preview(checked)


if __name__ == "__main__":
    main()
