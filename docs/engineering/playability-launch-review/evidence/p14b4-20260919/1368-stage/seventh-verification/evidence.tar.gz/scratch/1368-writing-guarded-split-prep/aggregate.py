"""Accept both completed exact route observations, never a partial timeout trace."""
import argparse,hashlib,json,os,re
from pathlib import Path
P=Path('/Users/zacheryspector/studio-scratch/1368-writing-guarded-split-prep')
ROUTES=['core-no-laboratory','bridge-laboratory']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(p):
 assert p.is_absolute()
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
def read(p,pin):safe(p);assert sha(p)==pin;return json.loads(p.read_text())
a=argparse.ArgumentParser();a.add_argument('--manifest-sha256',required=True);a.add_argument('--core-receipt',required=True);a.add_argument('--core-sha256',required=True);a.add_argument('--bridge-receipt',required=True);a.add_argument('--bridge-sha256',required=True);a.add_argument('--output',required=True);args=a.parse_args()
manifest=read(P/'MANIFEST.json',args.manifest_sha256)
for n,row in manifest['files'].items():assert sha(P/n)==row['sha256'] and (P/n).stat().st_size==row['bytes']
accepted=[];common=None
for route,path,pin in [(ROUTES[0],args.core_receipt,args.core_sha256),(ROUTES[1],args.bridge_receipt,args.bridge_sha256)]:
 p=Path(path);v=read(p,pin)
 assert v['mode']=='probe' and v['route']==route and v['actualChildExit']==v['recorderChildExit']==0 and not v['timedOut'] and v['allGuardsExact']
 assert v['processGroup']['noSurvivors'] and v['processGroup']['leaderReaped']
 pins=v['pins'];assert re.fullmatch('[0-9a-f]{40}', pins['publicationHead']) and pins['runnerManifestSha256']==pins['kitManifestSha256']==args.manifest_sha256
 assert pins['sourcePinsSha256']==sha(P/'SOURCE-PINS.json') and pins['inputPinsSha256']==sha(P/'INPUT-PINS.json') and pins['assemblySha256']==sha(P/'ASSEMBLY-TEMPLATE.json') and pins['regularFiles']==198
 if common is None:common=pins
 else:assert common==pins,'different consumed source/environment across routes'
 for name,row in v['artifacts'].items():
  f=Path(name);safe(f);assert sha(f)==row['sha256'] and f.stat().st_size==row['bytes']
 def artifact(name):
  q=p.parent/name;row=v['artifacts'][str(q)];return read(q,row['sha256'])
 binding=artifact('binding.json');assert binding['route']==route and binding['mode']=='probe' and binding['pins']==pins and binding['outerCapSeconds']==330 and binding['probeTestSeconds']==300
 report=artifact('vitest.json');assert len(report['testResults'])==1
 suite=report['testResults'][0];assert Path(suite['name']).name=='1368-writing-admission.probe.ts';assert len(suite['assertionResults'])==1 and suite['assertionResults'][0]['status']=='passed'
 data=p.parent/'data';m=artifact('data/MANIFEST.json');assert m['success'] and m['selectedRoute']==route and m['inputPinsSha256']==pins['inputPinsSha256']
 assert set(m['files'])=={route+'.jsonl',route+'-boundary416.jsonl','RESULT.jsonl'}
 for n,row in m['files'].items():
  q=data/n;safe(q);assert sha(q)==row['sha256'] and q.stat().st_size==row['bytes'] and v['artifacts'][str(q)]==row
 rows=[]
 with (data/(route+'.jsonl')).open() as f:
  for week,line in enumerate(f):
   row=json.loads(line);assert row['week']==week and re.fullmatch('[0-9a-f]{64}',row['stateSha256']);assert row['admission']['ok'] is True, f'{route}: rejected weekly admission {week}';rows.append(week)
 assert rows==list(range(417))
 results=[json.loads(x) for x in (data/'RESULT.jsonl').read_text().splitlines()];assert len(results)==1
 result=results[0];assert result['status']=='OBSERVED_ONE_ROUTE' and result['selectedRoute']==route and len(result['routes'])==1
 observed=result['routes'][0];assert observed['route']==route and observed['seed']=='p13b-s7-independence-01' and observed['end']==416 and observed['fullBoundaryReplayParity'] and observed['observerCalls']=={'advances':416,'finishes':416}
 assert observed['firstFailure'] is None, 'route reports a failed weekly admission'
 assert set(observed['endpointAdmissions'])=={'base','purchase','leadingZeroPeriod'}
 assert all(x['ok'] is True for x in observed['endpointAdmissions'].values()), 'rejected endpoint admission'
 boundary=[json.loads(x) for x in (data/(route+'-boundary416.jsonl')).read_text().splitlines()];assert len(boundary)==1
 assert set(boundary[0])=={'base','purchase','leadingZeroPeriod'}
 for name in ['base','purchase','leadingZeroPeriod']:
  assert boundary[0][name]['admission']==observed['endpointAdmissions'][name] and boundary[0][name]['admission']['ok'] is True
 accepted.append({'route':route,'receipt':str(p),'receiptSha256':pin,'dataManifestSha256':sha(data/'MANIFEST.json'),'observation':observed})
out=Path(args.output);safe(out);assert out.parent==P.parent/'1368-writing-guarded-split-recorded-runs' and not os.path.lexists(out)
with out.open('x') as f:json.dump({'status':'BOTH_GUARDED_ROUTES_ADMITTED','pins':common,'routes':accepted,'interpretation':'Both exact guarded routes completed with full tagged replay, all 417 weekly admissions valid and all three endpoints valid per route. This bounded writing correction result does not establish the separate original behavior leaves or broad recovery closure.'},f,indent=2);f.write('\n')
print(json.dumps({'aggregateSha256':sha(out),'path':str(out)}))
