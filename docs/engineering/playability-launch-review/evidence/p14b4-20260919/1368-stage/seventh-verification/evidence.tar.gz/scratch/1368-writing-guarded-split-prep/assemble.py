"""Assemble one exact 198-file guarded split-route arm; applies only the independently approved production guard."""
import argparse,hashlib,json,os,shutil
from pathlib import Path
S=Path('/Users/zacheryspector/studio-scratch');P=S/'1368-writing-guarded-split-prep';OLD=S/'1368-writing-split-arm-01';ARM=S/'1368-writing-guarded-split-arm-01';R=Path('/Users/zacheryspector/The-Movies-headless-program')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(p):
 assert p.is_absolute()
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
a=argparse.ArgumentParser();a.add_argument('--manifest-sha256',required=True);args=a.parse_args()
safe(P/'MANIFEST.json');assert sha(P/'MANIFEST.json')==args.manifest_sha256
for n,row in json.loads((P/'MANIFEST.json').read_text())['files'].items():safe(P/n);assert sha(P/n)==row['sha256'] and (P/n).stat().st_size==row['bytes']
pre=json.loads((P/'PREIMAGES.json').read_text());assert sha(OLD/'ASSEMBLY.json')==pre['oldAssembly'] and sha(OLD/'SOURCE-PINS.json')==pre['oldSourcePins']
original=json.loads((OLD/'SOURCE-PINS.json').read_text());source=json.loads((P/'SOURCE-PINS.json').read_text());assert len(source)==len(original)==198
for n,h in original.items():safe(OLD/'tree'/n);assert sha(OLD/'tree'/n)==h
safe(ARM);assert not os.path.lexists(ARM);ARM.mkdir();tree=ARM/'tree';tree.mkdir()
for n,h in source.items():
 src=P/'files'/n if (P/'files'/n).is_file() else OLD/'tree'/n
 safe(src);dest=tree/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);assert sha(dest)==h
assert (OLD/'tree/node_modules').is_symlink() and (OLD/'tree/node_modules').resolve() == (R/'node_modules').resolve()
(tree/'node_modules').symlink_to(os.readlink(OLD/'tree/node_modules'),target_is_directory=True)
for n,h in original.items():safe(OLD/'tree'/n);assert sha(OLD/'tree'/n)==h
assert sha(OLD/'ASSEMBLY.json')==pre['oldAssembly'] and sha(OLD/'SOURCE-PINS.json')==pre['oldSourcePins']
for src,name in [(P/'SOURCE-PINS.json','SOURCE-PINS.json'),(P/'ASSEMBLY-TEMPLATE.json','ASSEMBLY.json')]:shutil.copy2(src,ARM/name)
print(json.dumps({'assemblySha256':sha(ARM/'ASSEMBLY.json'),'sourcePinsSha256':sha(ARM/'SOURCE-PINS.json'),'files':198}))
