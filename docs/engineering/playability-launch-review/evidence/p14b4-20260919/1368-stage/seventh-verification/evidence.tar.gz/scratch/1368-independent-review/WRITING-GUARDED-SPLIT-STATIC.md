# Guarded original split-route rebind

PROCEED to parent-owned assembly, fresh exact-source types and the two separately selected original routes under their unchanged bounds. No runtime result is approved here.

Manifest ae30e5ae9dd8294806aa8d558f29ba258b2f856b28036817448ce6ccc70b9592; runner93c5b10627e4397359e2b05f46437d023155f8e2092c373aa559472ebed51ca7; aggregate238dbd5d2dbd04c620efad960befa63aadcf3bf34dc15966877c921c69e80a09. Rehashed all package entries and all198 original-arm files. Complete expected-map delta is exactly approved hollywoodTick c540c683 plus the probe's source-input hash literal. All187 other production files, original routes/actions, tagged replay, observers and configurations remain unchanged. Whole-probe equality after replacing the one pin confirms no concealed route/observer change.

The new exclusive arm preserves the original tree and dependency link text, copying exact pinned regular files and rechecking the original inventory after assembly. The runner uses a fresh output/stem, actual published HEAD with explicit remote equality, matching types and existing source/index/manual/entrypoint guards. The original300-second leaf and330-second outer process-group watchdog remain. No combined run, wider horizon, extra seed or partial-route substitution is added.

Reviewed aggregate delta strengthens acceptance: both complete route receipts must share exact source/environment and pass original replay/call-count/data-hash guards; all417 ordered weekly admission records must be true, firstFailure null, and base/purchase/leadingZeroPeriod endpoints must all be true and equal their separate boundary416 records. Original diagnostic child0 alone is insufficient. A rejected endpoint or incomplete/timeout route cannot be called GREEN. Original full tagged clean replay remains mandatory for each route.

This bounded route acceptance will remain distinct from the three original behavior leaves, retained retirement checks and broad recovery closure. No production source, live index, tests or runtime were changed/executed in review. Only static reads, hashes and Python AST parsing.
