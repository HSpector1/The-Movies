# R4 recovery selector — independent static review

Disposition: PROCEED with the six fixed modes, after the mandatory matching successful R4 types/generators receipt and ordinary recorded-run prerequisites. No execution acceptance is implied.

Manifest: `3d41ada02f4098a8609dd301780a71e6e7adc00434def719e4d10f0d815bed3a`.
Runner: `b82606867e253555d3667065c659baa2bb5458cf89e971988313b3d489d9ca21`.
All package hashes, six named historical receipt/source-map hashes, eleven current test-file hashes, and the unchanged bounded helper identity were independently verified.

The modes preserve the original whole-file Part A six-file 46-case scope, B 52, adapter 2, C 24, migration 111 and period 2. There is no title filter. Current test bytes match the named accepted predecessor test bytes. Historical success remains distinct from results on the guarded R4 implementation.

The runner retains the previously reviewed exact R4 inventory/assembly, types prerequisite, fixture bindings, published coordinator HEAD/remote equality, source/index checks and formal pre/postflight. It adds the original one-worker/no-file-parallelism flags and exact existing 330-second helper, without changing leaf budgets. The actual Node exit, helper exit and timeout are separately parsed and reconciled; timeout maps to 124 and cannot become a passing scope. Missing or duplicate helper receipts fail. The helper only bounds its owned child group on timeout and does not certify a separate final survivor inventory.

Whole-file JSON rows are preserved without identity collapse. Exact selected files, exact case count, every case passed, and actual helper success are all required. Missing JSON, additional cases, pending or skipped cases cannot pass. Recorder/postflight exit mapping and artifact hashes remain required after the child. No substantive defect found in this bounded delta.

This closes no new measured gate and does not waive broad fallout or campaign/promotion obligations. The separate twelve retirement/protected leaves and writing regressions remain separate selections. No runtime, tests, compiler, fixture payload reads, source/index edits or Git operations were performed.
