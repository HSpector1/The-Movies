# Next bounded lossless compression proposal

Prepared only. No compression, transaction planning/application, package installation, runtime, source/index edit or evidence deletion was performed. The parent owns exact-plan generation, independent inspection and application with all consumers idle. The prior 77-file package and every prior journal remain unchanged.

The exact whitelist has 160 paths: eight completed G2 digest traces, two completed protected-digest outputs and 150 previously unlisted project dependency JavaScript/maps of at least 64 KiB. They occupy 107,241,472 bytes physically (106,898,968 logical): 70,426,624 evidence bytes plus 36,814,848 dependency bytes. Actual savings are unmeasured. This allocation is not a promise of 100 MB saved. The earlier metadata census found only 59,695,104 eligible allocated bytes across all remaining project text files of at least 8 KiB; the 1,023 smaller entries are not selected. Parent then explicitly authorized these ten completed evidence paths. No further storage search is proposed.

All selected entries were checked as regular, single-link, flags zero, canonical paths with no symlink ancestry. They are disjoint from the accepted prior dependency whitelist. Read-only lsof batches found no users for the selected dependency files or ten trace files; their exact output is retained. This instantaneous observation is not an exclusive lock. Parent must keep Node/compiler/package writers and evidence consumers idle; the unchanged transaction repeats fail-closed per-file lsof checks during plan, before staging and immediately before replacement. Active binaries, Node22 headers and stopped temporaries, Owner files, fixture payloads and package versions are excluded.

## Completion evidence

COMPLETION-EVIDENCE.json pins the four exact `S/1361-g2/run/out/{control,candidate-1,candidate-2,k4}/g2-run.json` manifests. Each reports `complete: true`, 6,240 weeks, Node v20.20.2 and the exact two digest filenames for p13a-core-causal-01 and seed-b. The completed `g2-all.log`, its metadata and runs.meta independently record all four exits zero and report completion on October 2. Only their eight named digest files are selected; no save payload is read or selected.

The protected-digest clean-r1 and observed-r1 RESULT receipts both record actual child zero, recorder zero, exact guards and no timeout. Their named data.json files match the receipt artifact hashes and lengths. Completion verification establishes that these are closed artifacts; it does not revise any experiment's interpretation. All ten current logical hashes are retained in SELECTION.json and will be independently captured again in the parent plan.

## Same guarded transaction

compress.diff changes only the accepted compressor's output directory, whitelist hash, count and scope label. All byte/hash, size/mode/owner/group/mtime/ACL/xattr, path/single-link, old-inode, ditto-binary, raw Git/index/source and no-active-run guards remain. The exact generated plan records metadata before any change. Compression stages a new exclusive file beside the original, verifies logical equality and named metadata, requires smaller allocation and the compressed flag, fsyncs, rechecks the old file, then atomically replaces and verifies again. Any refusal halts while retaining original evidence and relevant staging/journal. Only a newly owned redundant no-savings temporary may be removed. Inode, ctime, physical allocation and compression flag intentionally change; no logical source or evidence change is allowed.

Application retains the previous 5.25 GiB early-stop target and reports the actual 5 GiB floor independently. Thus it can stop before consuming the whole whitelist. Parent must inspect the completed journal and actual free space before any next heavy lane. This package does not guarantee a margin or authorize a wider fallback.

After static review, parent generates a fresh plan at the then-current published HEAD and inspects/reviews its exact hash before apply:

```sh
/usr/bin/python3 /Users/zacheryspector/studio-scratch/1368-cold-dependency-compression-next-prep/compress.py plan --manifest /Users/zacheryspector/studio-scratch/1368-cold-dependency-compression-next-prep/results/plan-r1.json
/usr/bin/python3 /Users/zacheryspector/studio-scratch/1368-cold-dependency-compression-next-prep/compress.py apply --manifest /Users/zacheryspector/studio-scratch/1368-cold-dependency-compression-next-prep/results/plan-r1.json --manifest-sha ACTUAL_REVIEWED_PLAN_SHA --journal /Users/zacheryspector/studio-scratch/1368-cold-dependency-compression-next-prep/results/apply-r1.jsonl
```

No command runs automatically. Python AST parsing, bounded metadata/hash reads, completion-receipt checks and read-only lsof census are the only verification performed here.
