# R4 original recovery focused recheck

Prepared only. This is the separate parent-authorized coherent recheck of the original 1368-D focused recovery scopes on the guarded r4 source. It does not modify tests, source, fixtures, assertions, original behavioral pins or deadlines. No runtime, compiler, fixture payload read, assembly, live file or Git/index mutation occurred in preparation.

The exact r4 source inventory is `ca96ecb42e78ddf4442e17804bd15a80d70e5808a5e78ed42f43b4f06a0320d2`; assembly is `604e0a722f5248ef7003ba5dc9216462564d6dad29ba86519612198fb53b94f5`. The candidate is `S/1368-save46-swept-proposal-r4/tree`, 1,625 regular consumed files, including the approved prospective-writing guard. Actual publication HEAD is supplied dynamically and checked against the remote branch; it describes coordinator provenance, not published Save46 gameplay.

## Six exact original scopes

There is no test-name filter in any mode. All leaves in every listed file run under the unchanged core project, one worker and no file parallelism, as in the accepted original scope commands.

| Mode | Whole files under tests/ | Historical accepted cases |
| --- | --- | ---: |
| part-a | p14d1-rival-shelving.test.ts; p14d2-binding-cash.test.ts; p14d2-a8-binding-cash.test.ts; p15c2-legacy-lens-shape.test.ts; save-masked-downgrade-own-era.test.ts; save-v36-extension-own-era.test.ts | 46 |
| b | p14d2-rival-cost-cutting.test.ts | 52 |
| adapter | p14d2-rival-cost-cutting-adapter.test.ts | 2 |
| c | p14d2-rival-facility-disposal.test.ts | 24 |
| migration | p14d2-save46-migration.test.ts | 111 |
| period | p13b-s8-old-era-period.test.ts | 2 |

`HISTORICAL-SELECTION-PROVENANCE.json` binds the actual prior successful receipt, exact command and source inventory for each scope. All eleven selected r4 test files are byte-identical to the corresponding accepted historical test bytes. The prior receipts' generating source is distinct from r4. Their prior passes are justification for the preserved selections, not new r4 results. `EVIDENCE-PINS.json` binds those records and governing 1368-A/B/C/D facts. The old current-genesis failed probes, alternative inputs, predecessor RED qualifications and original 312-period failed affordability remain preserved.

Each current report must name exactly its original file set, retain the complete assertion rows without collapsing titles, contain exactly the original case count and pass all those cases before this scope is accepted. Missing, skipped, pending, failed or extra cases cannot produce a successful wrapper result. File hashes are fixed, so an equal count is not used to permit different test bodies. Complete JSON and raw failures remain available even when the case-count or completion gate fails.

## Budgets and cleanup

No `--testTimeout` or source timeout changes are introduced. `DEADLINE-SITES.json` records the original explicit timeout sites; all other leaves retain the 5,000 ms core default. Existing larger budgets include Part A shelving's 15/20/30-second leaves, binding/A8's 30-second leaves, F6 lens's 120-second leaf, B/adapter's explicit 120-second routes, C's 120-second cases and 300-second natural-520 leaf, and migration's explicit 120-second route. The original period and own-era reader tests keep their default deadlines.

The parent explicitly required retaining the original 1368-D 330-second outer cap. The runner invokes the exact existing `S/1361-capture-runner/bounded-child.py`, SHA `717d02e676d08600ffd4c5b54cb9cb5b94d3d4ddb73555ad70981e8bae406b9c`. It starts an owned child session; on timeout it sends group TERM, polls through the existing five-second grace independently of leader exit, then KILLs the remaining group and waits for the leader. No helper change or new cleanup framework is included. Its existing receipt does not independently certify a no-survivor inventory; this package makes no stronger claim.

The Node command retains `--maxWorkers=1 --minWorkers=1 --no-file-parallelism`. Raw output must contain exactly one actual bounded-child receipt. The runner preserves its actual Node `childExit`, timeout flag and helper exit separately, verifies their mapping, and reconciles the final recorder/postflight exit. A timeout remains 124, not a missing-witness finding or ordinary test success. A missing helper receipt is an execution failure. The helper's exact bytes are checked before and after.

## Reused source/type/recording gates

The lifecycle and five formal recorder/manual guard outputs derive from the existing r4 integration runner and the separate original-leaf selector preparation. Complete diffs are included against both. No source copy or candidate mutation is needed.

The runner requires the exact r4 integration package's completed `run-types-<id>/RESULT.json` and actual SHA. All six original root/UI/Bridge/generator/generator-fixture/producer commands must have actual exit 0. It checks their binding/raw hashes, exact r4 source/assembly/scratch HEAD/index/stage/entrypoint identity and the actual completed formal type recorder/postflight. Earlier r3 or pre-guard types do not qualify. Documentation publication can advance between admitted types and a run while consumed candidate source stays exact.

The unchanged 5 GiB floor, Node 20.20.2, power receipt/caffeinate, full regular source inventory, scratch HEAD/index/stage, fixture pin map, exact recorder command, dynamic published HEAD/remote equality and exclusive output paths remain. `FIXTURE-PINS.json` is the exact integration map, not a new payload census. Existing accepted45/26 environment pins point to the named published copies. Test loaders retain their literal gzip/raw/manifest checks and genuine historical admission before current use. No private Owner input or unrelated fixture tree is read by this preparation.

## Parent invocation

After independent review, r4 assembly and successful r4 integration types, execute the six modes separately in the sole heavy lane. Expand `S` to `/Users/zacheryspector/studio-scratch`; replace descriptive tokens with actual values:

```
python3 S/1368-r4-recovery-selector-prep/run.py part-a --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
python3 S/1368-r4-recovery-selector-prep/run.py b --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
python3 S/1368-r4-recovery-selector-prep/run.py adapter --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
python3 S/1368-r4-recovery-selector-prep/run.py c --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
python3 S/1368-r4-recovery-selector-prep/run.py migration --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
python3 S/1368-r4-recovery-selector-prep/run.py period --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
```

Outputs are exclusive `S/1368-r4-recovery-selector-prep/run-<mode>-<id>/`. Formal five-file evidence stems are `1368-r4-recovery-<mode>-<id>`. `RESULT.json` preserves actual child facts and all selected assertion objects; `POSTFLIGHT-RECEIPT.json` binds completed outputs and formal artifacts. Parent binds the reviewed package/runner hash at launch. There is no automatic retry, fallback input or horizon extension.

The retirement/protected twelve-leaf package remains separate and unchanged at `S/1368-r4-original-selector-prep`. These six original recovery scopes complement it and the r4 writing guard regressions. They are focused verification only: current source behavior, broad fallout, full campaign measurements, promotion gates and original unmet hypotheses are not waived by this preparation or by historical 1368-D passes.
