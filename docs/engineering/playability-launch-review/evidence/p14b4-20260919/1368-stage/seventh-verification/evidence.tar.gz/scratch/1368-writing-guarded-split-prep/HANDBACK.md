# Guarded split writing diagnostic

Prepared for independent static review and parent-controlled assembly, fresh types and two separate route runs. No assembly, compiler, game runtime, fixture access, Git mutation or live/frozen source edit was performed. All prior invalid-route, timeout and accepted diagnostic results remain unchanged.

## Exact source and route delta

The predecessor is `S/1368-writing-split-arm-01`, with source inventory `dd34eaf0908abf5854588b24cef680de5e3c58d271682ae78eb74fcbff952806` and assembly `2fa3f5b1491be353d0605cf17fcaeb7c571803bd0a3f6a7e6dbe99fa3e3a70ee`. New exclusive destination: `S/1368-writing-guarded-split-arm-01/tree`.

The 198-file candidate changes exactly two predecessor files. Of 188 production files, only `src/core/hollywoodTick.ts` changes, to the already approved guard SHA `c540c6830537aaaca6cb448993e4c9648f7141bcf498ca92e239b9ebd1cee5b8`. The original split probe changes only its literal input-pin SHA. All other 196 arm files, including the three configs, original test reference and exact `_contractFixtures.ts` dependency, retain their bytes. ORIGINAL-PRODUCTION-PINS.json, CURRENT-PRODUCTION-PINS.json and SOURCE-DIFFERENCE.json give the complete comparison; production.diff is the exact approved patch. Preimages preserve the prior package and guard identities.

New SOURCE-PINS: `bc0afb6504dc7eae6c6810fe52ced0554229c3d0080acc9d932086c10d812c56`.
New ASSEMBLY-TEMPLATE: `8407a4c8a974945e0305b8f01a38cb9a95a1f08379c9f5dfa72df67575d6ccef`.
New INPUT-PINS: `97ee1e66b0d9db7b6ae0ffab0730cdb91d51f6eb0bd17d35ef93674d83c72f0b`.

The two original routes remain `core-no-laboratory` and `bridge-laboratory`, both seed `p13b-s7-independence-01`, exactly 416 default ticks and 417 boundaries. The Bridge route's original laboratory placement, actual observers, renewal quote observation, full tagged-state uninstrumented replay, rival purchase and leading-zero-period endpoint operations are unchanged. The observer still records any failed admission instead of prematurely discarding the route. The leaf remains 300 seconds; each child retains the original 330-second outer cap and reviewed owned-group cleanup. No timeout or horizon increase, capture reuse, route substitution, state repair or extra operation exists.

## Rebinding and acceptance

The assembler verifies the predecessor's entire inventory before copying, overlays only the two changed files (the three config overlays are byte-identical), preserves the existing dependency link text, and verifies the old inventory again afterward. It never overwrites an arm or initializes Git. Parent controls execution and disk admission.

The runner uses an explicitly supplied actual published 40-character coordinator HEAD, requiring local HEAD, fixed branch and remote equality before and after execution. This publication is recorder provenance; the guarded candidate source is independently pinned. A fresh successful types receipt must match this package, source, assembly, input pins and entrypoints before either route launches. No original unguarded types receipt can satisfy it. The existing source/index/entrypoint guards, five formal recorder artifacts, process-group cleanup, actual child/recorder exits, 5 GiB free-space floor, power logging and caffeinate remain. Each route has an exclusive output and formal stem; all old outputs remain intact.

A zero diagnostic exit is insufficient. The aggregate requires two complete, guarded, successful receipts with identical source/environment pins and no timeout or surviving process. It checks both data manifests and every artifact hash; exactly 417 ordered weekly rows; all weekly `admission.ok` values strictly true; exactly 416 advance and finish observations; full replay parity; null first failure; and all three endpoint admissions strictly true in both the result summary and the boundary file. Only then does it write `BOTH_GUARDED_ROUTES_ADMITTED`. A rejected week or endpoint refuses aggregation without changing the completed diagnostic evidence. This bounded result does not establish the separately requested three original behavior leaves, retirement regressions, broad gates or recovery closure.

`assemble.py.diff`, `run.py.diff`, `aggregate.py.diff` and `probe-pin.diff` expose the full changes to the original split kit. Only Python AST parsing and static byte/hash comparisons were performed here. No runtime outcome is claimed.

## Parent commands after review

Use the reviewed literal package hash and actual published HEAD. S expands to `/Users/zacheryspector/studio-scratch`; no command runs automatically.

```sh
/usr/bin/python3 S/1368-writing-guarded-split-prep/assemble.py --manifest-sha256 REVIEWED_PACKAGE_SHA
/usr/bin/python3 S/1368-writing-guarded-split-prep/run.py types --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 REVIEWED_PACKAGE_SHA --leaf r1
/usr/bin/python3 S/1368-writing-guarded-split-prep/run.py probe --route core-no-laboratory --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 REVIEWED_PACKAGE_SHA --leaf r1 --types-receipt S/1368-writing-guarded-split-recorded-runs/types-r1/RESULT.json --types-receipt-sha256 ACTUAL_TYPES_SHA
/usr/bin/python3 S/1368-writing-guarded-split-prep/run.py probe --route bridge-laboratory --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 REVIEWED_PACKAGE_SHA --leaf r1 --types-receipt S/1368-writing-guarded-split-recorded-runs/types-r1/RESULT.json --types-receipt-sha256 ACTUAL_TYPES_SHA
/usr/bin/python3 S/1368-writing-guarded-split-prep/aggregate.py --manifest-sha256 REVIEWED_PACKAGE_SHA --core-receipt S/1368-writing-guarded-split-recorded-runs/probe-core-no-laboratory-r1/RESULT.json --core-sha256 ACTUAL_CORE_RECEIPT_SHA --bridge-receipt S/1368-writing-guarded-split-recorded-runs/probe-bridge-laboratory-r1/RESULT.json --bridge-sha256 ACTUAL_BRIDGE_RECEIPT_SHA --output S/1368-writing-guarded-split-recorded-runs/AGGREGATE-r1.json
```
