from pathlib import Path
import hashlib,json,tarfile,os,subprocess
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program');E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';P=S/'1368-seventh-publication-prep';I=S/'1368-seventh-publication-input-inventory/INPUTS.json';O=E/'1368-stage/seventh-verification'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(I)=='784493282b0a42f2394827a8c30cc5d082a4a94ae9ccf75e89b117ee6f088612'
x=json.loads(I.read_text());assert x['allNamedRunsClosed'];files=x['newFiles'].copy();refs=x['priorReferences']
for p in [I,P/'r4-commit.raw',Path(__file__)]:files.append({'path':'scratch/'+p.relative_to(S).as_posix(),'original':str(p),'size':p.stat().st_size,'sha256':sha(p)})
assert len({r['path'] for r in files})==len(files)
for r in files+refs:
 p=Path(r['original']);assert p.is_file() and not any(q.is_symlink() for q in [p,*p.parents]);assert p.stat().st_size==r['size'] and sha(p)==r['sha256'],str(p)
for a in x['archives']:
 archive=E/a['archive'];assert sha(archive)==a['archiveSha256'];selected=[r for r in refs if r['priorArchive']==a['archive']]
 with tarfile.open(archive,'r:gz') as tar:
  for r in selected:
   m=tar.getmember(r['priorArchiveMember']);assert m.isfile() and m.size==r['size'];assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==r['sha256']
raw=(P/'r4-commit.raw').read_bytes();assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==x['r4Reconstruction']['rootCommit'];assert raw.startswith(('tree '+x['r4Reconstruction']['tree']+'\n').encode());assert b'\nparent ' not in raw
assert not O.exists();O.mkdir(parents=True);archive=O/'evidence.tar.gz';files.sort(key=lambda r:r['path'])
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for r in files:tar.add(r['original'],arcname=r['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files);assert [m.name for m in members]==[r['path'] for r in files]
 for m,r in zip(members,files):assert m.isfile() and m.size==r['size'] and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==r['sha256']
for r in files+refs:assert sha(Path(r['original']))==r['sha256']
result={'status':'ARCHIVE_VERIFIED','source_head':'f5cba8b7ea41a1b3ec87cff43c1bcb1a7b7b0f9a','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'file_count':len(files),'logical_bytes':sum(r['size'] for r in files),'files':files,'priorReferences':refs,'priorArchives':x['archives'],'inputInventorySha256':sha(I),'r4Reconstruction':x['r4Reconstruction'],'r3BundleReference':x['r3BundleReference'],'scope':'Guarded r4 focused verification and recovery history preserved; no full checkpoint closure or main promotion.'}
(O/'MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','archive_sha256','archive_bytes','file_count','logical_bytes']}));print('priorReferences',len(refs))
