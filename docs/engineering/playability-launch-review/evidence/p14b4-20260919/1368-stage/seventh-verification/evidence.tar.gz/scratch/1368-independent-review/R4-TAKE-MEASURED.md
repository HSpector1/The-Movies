# R4 protected take — independent measured review

Accepted for the one exact original protected take leaf. RESULT SHA-256 `a6bc28513f363d01147694f0e60a5e4797dff7705c0db7fed5bfa173d0aadf8d`; POSTFLIGHT-RECEIPT `f1436809296361f986b4ea2f718f5fe298259a8339046465b06518a883c9c82a`.

Every receipt artifact was independently rehashed. Complete JSON contains one passed selected leaf and 52 skipped/unselected leaves; those 52 are not measured passes. Exact file and full-title selection, actual Node/recorder exits 0, and completed exact source/index guards agree. Recorded command duration is 5.936664 seconds. The original RNG and protected comparison assertions were reached; this run uses the reviewed real public guarded Save46-to-45 comparison projection and retains the original digest.

This accepts neither the whole relationships file nor the two market protected leaves, recovery suites or broad checkpoint. Active market output was not read. No runtime, fixture payload read, source/index mutation or Git operation occurred in this review.
