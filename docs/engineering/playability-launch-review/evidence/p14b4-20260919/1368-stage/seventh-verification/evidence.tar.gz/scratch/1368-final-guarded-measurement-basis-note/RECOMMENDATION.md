# Final guarded source: current measurement basis decision

Technical recommendation only; parent approval remains deferred until step 9 focused/landing outcomes. No matrix, source adaptation, observer, comparator or runner has been authored or executed. This is an engineering comparison-basis decision, not an Owner product questionnaire or an acceptance claim.

Recommend one explicitly amended, matched current matrix, `C0+G / A+G / AB+G / ABC+G`, plus one original `C0` guard-effect comparison per existing seed. Preserve the original eight source copies and eight successful type receipts unchanged. Do not call a derived control historical C0 or describe A+G as Part A alone. This smallest recommended arrangement requires a reviewed parent amendment that explicitly replaces the current experiment's source roles; the original wording is not already satisfied by the derived controls.

## Binding requirements

- 1363-A §6.1, lines 487–496: control is landed Save45, A is Part A alone, AB is the landed recovery source; pressure and no-loan/shadow-loan distinctions are retained. The adopted kit already identifies A's actual F6 validation difference rather than falsely claiming original C0 source equality.
- 1363-A §6.3, lines 521–535: changed-label and first-entry identity prefixes, player identity, ledger, repeat determinism, false-positive scrutiny, Part A/Part B attribution and no-hastening comparisons remain required. An unexplained guard-induced prefix difference cannot be normalized away.
- 1363-A2 §7, lines 117–122: preserve the Save45 baseline/captures; measure one final integrated ABC with control/A/AB attribution arms; G-P/G-L consume that exact candidate. Pressure-off retains control and final candidate only.
- 1363-F ruling 9, lines 57–62, and 1363-A2 line 122: H1=`469a9547` versus H0=`ff803032`, and H1+Part A versus H0, preserve the historical equal-basis 154 attribution. Candidate versus H0 remains confounded totals. No writing guard goes into those three historical arms.
- 1368-D, “Exact source and results” and “Next gate and preservation”: all eight original matrix typechecks passed, with no simulation claimed. That evidence cannot validate newly guarded source or observer bytes. The fixed receipt is `5d578116b1fe53ae4d5556ea069d1a0c55d1236e4eedfc5fad82102a98402f46`; all eight raw hashes were checked for this note.

## What changes and what stays historical

G is only the independently reviewed prospective rival-writing guard, patch `2a4ea2dc9b0fd87c211c9cf600d9691081f158fa45982ce42dcada4b703de058`. It prevents a newly selected commission when `week + draftWeeks > endWeekExclusive`. Equality remains permitted. No writer reselection, forced renewal, commissionStop change, retirement exception, money adjustment or schema change is introduced.

Final ABC+G must bind the actual final landed 188-file source, not an anticipated HEAD or merely this draft's hash. Derived C0+G and A+G retain their original 187 other production files, original Save45 writer and all existing F6 distinctions. AB+G retains the already reviewed natural-only C-disabled seam and complete Save46 representation; it must keep zero actual refund/disposal authority throughout its route. ABC+G versus AB+G then isolates automatic C, A+G versus C0+G isolates Part A on the corrected commission law, and AB+G versus A+G isolates Part B while retaining disclosed Save46 representation overhead.

Changing ABC alone would confound C with G. Changing AB and ABC alone would confound B with G. The matched matrix fixes those comparisons without rewriting the historical inputs. It does not show what original A or AB did under the old commission law.

Keep untouched: the original eight matrix copies/type receipts; original Save45 source and accepted G-L/post-2040 release evidence; existing historical154 H0/H1/H1+A package; original failed and successful writing diagnostics/captures. These remain evidence, not new simulation claims. Final G-P/G-L/K3 and the separately governed player52, Row6 and promise148 routes still require exact final-source binding and their existing controls. This note does not count or discharge those separate obligations, later enabled pressure, or real P15B loan integration. Shadow loans remain shadow only.

## Smallest contract-complete current route count

The accepted natural kit has five fixed seeds, exactly 520 default ticks, and three independent processes per arm/seed: clean, observed, observed repeat. Its eight source variants are four arms times clean/observed; repeat reuses the observed variant. Nothing below adds a seed, horizon, retry, threshold or policy operation.

| Scope | Source/seed routes | Simulation processes |
|---|---:|---:|
| Matched C0+G/A+G/AB+G/ABC+G | 4 × 5 = 20 | 60 |
| Original C0 guard-effect control | 1 × 5 = 5 additional | 15 additional |
| Recommended amended current experiment | 25 | 75 total |

Reuse the already-required C0+G outputs for the guard-effect pairs; do not run those five routes again. Preserve the original kit's three-process parity/repeat contract for the added C0 rows. Five clean-only original C0 runs would reduce the total to 65, but would drop that contract and are not this recommendation. The 75-process design is smaller than duplicating both complete 60-process campaigns. It needs ten source variants for execution (five clean/observed pairs), while all old copies remain preserved.

One original-C0 versus C0+G pair per seed is sufficient for **baseline guard effects only**, and for the proposed amended current experiment when combined with the matched recovery matrix. It is not sufficient to establish original A versus C0, original AB versus A, guard effects conditional on A or B, or a claim that G never interacts with recovery. No algebra or unchanged baseline route may substitute for those absent measurements.

Therefore the amendment must say explicitly: current A/B/C causal claims are on shared corrected commission law; original-C0 to final-ABC+G totals combine guard and recovery and are labelled accordingly; original A/AB simulations under old G-free law are superseded for this current experiment, not falsely marked completed. If the parent instead retains the literal original A/C0 and original AB/A simulation obligations, the minimal complete addition is original C0, A and AB at 15 processes each, for 105 total alongside the matched 60. Original obsolete ABC need not be rerun merely to double the campaign. The separate historical154 obligations remain unchanged under either choice.

## Exact implementation seams for later preparation

Current clean hollywoodTick sources: C0 `d5963544…` at lines 57/321; A `21b00c62…` at 57/323; AB `8808d5dd…` at 58/350; original ABC `6da40c08…` at 58/350. Each has one `currentEmployees` helper and one existing draftWeeks boundary. Full hashes and named source identities are in SOURCE-PINS.json. The approved guarded tick `c540c683…` places the check at lines 351–354, before weekly cost/package selection. ABC's inner runDecision returns into the existing end-of-decision evaluation at 371–377; the observer must not change that control flow.

The current observer generator, prepare-observer.py lines 41–49, records existing commission returns and commissionStop. Because the approved new return deliberately leaves commissionStop unchanged, a later rebind must add a transparent observation inside the actual executed coverage guard, recording paid writer/start/end, input week and due week. No inferred refusal, changed condition, extra chooser call or changed commissionStop is permitted. Retain all existing full-state/RNG/Map-aware neutrality and repeat comparisons. Every changed source/observer pair needs fresh strict types and its own clean/observed parity; the eight old type passes remain historical only.

Any later implementation must carry explicit G-derived arm identities and the amendment pin through bind-arm.py, run-one.py, source manifests and compare.py. A separate original-C0 bridge comparison must consume its exact three completed receipts and the existing C0+G results; it must not relabel the original four-arm 60-row comparator as having accepted a new 75-row matrix. Parent review of that bounded delta precedes execution. Approval is deferred; this note creates no executable campaign.
