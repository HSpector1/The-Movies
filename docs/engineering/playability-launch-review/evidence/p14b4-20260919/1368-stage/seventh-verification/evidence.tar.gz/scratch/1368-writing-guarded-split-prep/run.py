"""Recorded strict types or exact 416-week writing diagnostic; no assembly or policy changes."""
import argparse, hashlib, importlib.util, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
R = Path('/Users/zacheryspector/The-Movies-headless-program')
S = Path('/Users/zacheryspector/studio-scratch')
P = S / '1368-writing-guarded-split-prep'
ARM = S / '1368-writing-guarded-split-arm-01'
T = ARM / 'tree'
KIT = P
RUNS = S / '1368-writing-guarded-split-recorded-runs'
E = R / 'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
NODE = Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
LEGACY = S / '1368-recovery-legacy-prep/run-recovery.py'
BRANCH = 'refs/heads/wip/headless-program-20260916-ts'
SCOPE = ['src', 'bridge', 'tests', 'ui', 'generated', 'scripts', 'package.json', 'package-lock.json', 'vitest.config.ts', 'vitest.workspace.ts', 'tsconfig.json', 'tsconfig.bridge.json', 'tsconfig.src.json', ':(exclude)tests/fixtures', ':(exclude)ui/e2e', ':(exclude)ui/public']
FIXED = {
    ARM / 'ASSEMBLY.json': '8407a4c8a974945e0305b8f01a38cb9a95a1f08379c9f5dfa72df67575d6ccef',
    ARM / 'SOURCE-PINS.json': 'bc0afb6504dc7eae6c6810fe52ced0554229c3d0080acc9d932086c10d812c56',
    KIT / 'INPUT-PINS.json': '97ee1e66b0d9db7b6ae0ffab0730cdb91d51f6eb0bd17d35ef93674d83c72f0b',
    LEGACY: '7568362dbfdc07cf63d768dda14edd4e754f89b3aeae14ebf0ef335d8832be02',
    E / 'run-bounded-source-guards.py': '1a1e144c25dd36320c64237d5b58f19d848eb85171fa777e5772c2c3fff1a20e',
    E / 'run-bounded-source-c2.mjs': 'ae167b103ddaa714268cd63e163daa4966b0c3b8f07bfa3e9bd8f0c7d07751a2',
}
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def safe(path):
    assert path.is_absolute() and str(path) == os.path.abspath(path)
    for part in [path, *path.parents]: assert not part.is_symlink(), str(part)
def exclusive(path):
    safe(path); assert not os.path.lexists(path), 'existing output: ' + str(path)
def write(path, obj):
    with path.open('x') as f: json.dump(obj, f, indent=2); f.write('\n')
def environment():
    return dict(os.environ, PATH=str(NODE.parent) + ':' + str(R / '.venv/bin') + ':' + os.environ.get('PATH', ''), GIT_OPTIONAL_LOCKS='0')
def git(*args): return subprocess.check_output(['git', *args], cwd=R, env=environment())
def verify(head, manifest_pin):
    assert re.fullmatch('[0-9a-f]{40}', head), 'actual published coordinator HEAD required'
    assert git('ls-remote', '--exit-code', 'origin', BRANCH).decode().split() == [head, BRANCH], 'published remote differs'
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert git('symbolic-ref', 'HEAD').decode().strip() == BRANCH
    assert git('diff', '--name-only', 'HEAD', '--', *SCOPE) == b'', 'dirty live source'
    assert git('ls-files', '--others', '--exclude-standard', '--', *SCOPE) == b'', 'untracked live source'
    assert re.fullmatch('[0-9a-f]{64}', manifest_pin)
    safe(P / 'MANIFEST.json'); assert sha(P / 'MANIFEST.json') == manifest_pin
    for name, row in json.loads((P / 'MANIFEST.json').read_text())['files'].items():
        path = P / name; safe(path); assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
    for path, pin in FIXED.items(): safe(path); assert sha(path) == pin, str(path)
    source = json.loads((ARM / 'SOURCE-PINS.json').read_text()); assert len(source) == 198
    kit = json.loads((KIT / 'MANIFEST.json').read_text())
    for name, row in kit['files'].items():
        path = KIT / name; safe(path); assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
        if name.startswith('files/'): assert source[name[6:]] == row['sha256']
    inputs = json.loads((KIT / 'INPUT-PINS.json').read_text())['files']; assert len(inputs) == 194
    for name, row in inputs.items(): assert source[name] == row['sha256'] and (T / name).stat().st_size == row['bytes']
    assert source['tests/contracts/_contractFixtures.ts'] == '7554a6b11f0756c7cd286a7732ab888757a129fe0d9f10657c93c4d214f10de2'
    actual = []
    safe(T)
    for folder, dirs, files in os.walk(T, followlinks=False):
        root = Path(folder)
        if root == T:
            assert 'node_modules' in dirs; dirs.remove('node_modules')
        for name in dirs: safe(root / name)
        for name in files:
            path = root / name; safe(path); assert path.is_file()
            rel = path.relative_to(T).as_posix(); assert rel in source and sha(path) == source[rel], rel
            actual.append(rel)
    assert sorted(actual) == sorted(source)
    assert (T / 'node_modules').is_symlink() and (T / 'node_modules').resolve() == (R / 'node_modules').resolve()
    assert subprocess.check_output([str(NODE), '--version'], text=True).strip() == 'v20.20.2'
    entries = [NODE, T / 'node_modules/typescript/bin/tsc', T / 'node_modules/vitest/vitest.mjs']
    index = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    return {'publicationHead': head, 'publicationIndexSha256': sha(index), 'publicationStageSha256': digest(git('ls-files', '--stage', '-z')),
            'boundedDiffSha256': digest(git('diff', 'HEAD', '--', *SCOPE)), 'sourcePinsSha256': sha(ARM / 'SOURCE-PINS.json'),
            'assemblySha256': sha(ARM / 'ASSEMBLY.json'), 'kitManifestSha256': sha(KIT / 'MANIFEST.json'),
            'inputPinsSha256': sha(KIT / 'INPUT-PINS.json'), 'runnerManifestSha256': manifest_pin,
            'entrypoints': {str(path): sha(path) for path in entries}, 'regularFiles': 198}
def prior_types(path, pin, current):
    safe(path); assert sha(path) == pin
    receipt = json.loads(path.read_text())
    assert receipt['mode'] == 'types' and receipt['allGuardsExact'] and receipt['actualChildExit'] == 0 and receipt['recorderChildExit'] == 0 and not receipt['timedOut']
    assert receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped']
    # Documentation publication may advance between modes; consumed source and kit must not.
    for name in ['sourcePinsSha256', 'assemblySha256', 'kitManifestSha256', 'inputPinsSha256', 'runnerManifestSha256', 'entrypoints', 'regularFiles']:
        assert receipt['pins'][name] == current[name], 'types source differs: ' + name
    for name, row in receipt['artifacts'].items():
        f = Path(name); safe(f); assert sha(f) == row['sha256'] and f.stat().st_size == row['bytes']
def child(out, binding_pin):
    safe(out / 'binding.json'); assert sha(out / 'binding.json') == binding_pin
    b = json.loads((out / 'binding.json').read_text()); assert verify(b['publicationHead'], b['manifestPin']) == b['pins']
    if b['mode'] == 'probe': prior_types(Path(b['typesReceipt']), b['typesReceiptSha256'], b['pins'])
    # Import only after verifying the reviewed helper's exact SHA; __main__ is not run.
    spec = importlib.util.spec_from_file_location('reviewed_cleanup', LEGACY); helper = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode; sys.dont_write_bytecode = True
    try: spec.loader.exec_module(helper)
    finally: sys.dont_write_bytecode = old
    env = environment(); env.update(DIAG_INPUT_PINS=str(KIT / 'INPUT-PINS.json'), DIAG_OUTPUT=str(out / 'data'))
    if b['mode'] == 'probe':
        assert b['route'] in ['core-no-laboratory', 'bridge-laboratory']; env['DIAG_ROUTE'] = b['route']
    start = time.monotonic(); timed_out = False
    with (out / 'stdout.txt').open('x') as stdout, (out / 'stderr.txt').open('x') as stderr:
        proc = subprocess.Popen(b['command'], cwd=T, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try: proc.wait(timeout=330)
        except subprocess.TimeoutExpired: timed_out = True
        finally: code, group = helper.cleanup_owned_group(proc)
    exact = verify(b['publicationHead'], b['manifestPin']) == b['pins'] and sha(out / 'binding.json') == binding_pin
    write(out / 'CHILD.json', {'actualChildExit': code, 'timedOut': timed_out, 'processGroup': group, 'elapsedSeconds': time.monotonic() - start, 'allGuardsExact': exact, 'command': b['command'], 'route': b['route']})
    assert exact
    if timed_out: return 124
    if not group['noSurvivors'] or not group['leaderReaped']: return 1
    return code if code is not None and code >= 0 else 1

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=['types', 'probe']); ap.add_argument('--head', required=True)
    ap.add_argument('--manifest-sha256', required=True); ap.add_argument('--leaf', required=True)
    ap.add_argument('--route', choices=['core-no-laboratory', 'bridge-laboratory']); ap.add_argument('--types-receipt'); ap.add_argument('--types-receipt-sha256'); a = ap.parse_args()
    assert Path(__file__).resolve() == P / 'run.py'
    assert re.fullmatch('[a-zA-Z0-9_-]+', a.leaf)
    assert (a.mode == 'probe' and a.route is not None) or (a.mode == 'types' and a.route is None)
    out = RUNS / (a.mode + ('-' + a.route if a.route else '') + '-' + a.leaf); exclusive(out)
    pins = verify(a.head, a.manifest_sha256)
    assert git('ls-remote', '--exit-code', 'origin', BRANCH).decode().split() == [a.head, BRANCH]
    if a.mode == 'probe':
        assert a.types_receipt and a.types_receipt_sha256
        prior_types(Path(a.types_receipt), a.types_receipt_sha256, pins)
    else: assert not a.types_receipt and not a.types_receipt_sha256
    assert shutil.disk_usage(R).free >= 5 * 1024**3
    stem = '1368-writing-guarded-split-' + a.mode + ('-' + a.route if a.route else '') + '-' + a.leaf
    for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']: exclusive(E / (stem + suffix))
    safe(RUNS); RUNS.mkdir(exist_ok=True); out.mkdir()
    command = [str(NODE), 'node_modules/typescript/bin/tsc', '--noEmit', '-p', 'tsconfig.1368-writing-admission.json'] if a.mode == 'types' else [str(NODE), 'node_modules/vitest/vitest.mjs', 'run', '--config', 'vitest.1368-writing-admission.config.ts', '--workspace', 'vitest.1368-writing-admission.workspace.ts', '--project', 'core', '--maxWorkers', '1', '--minWorkers', '1', '--no-file-parallelism', '--reporter=verbose', '--reporter=json', '--outputFile.json=' + str(out / 'vitest.json')]
    binding = {'mode': a.mode, 'route': a.route, 'publicationHead': a.head, 'sourceStatus': 'ABC plus approved writing guard; publication HEAD is recorder provenance, not candidate product identity', 'pins': pins, 'manifestPin': a.manifest_sha256, 'command': command, 'typesReceipt': a.types_receipt, 'typesReceiptSha256': a.types_receipt_sha256, 'outerCapSeconds': 330, 'probeTestSeconds': 300}
    write(out / 'binding.json', binding)
    with (out / 'power.txt').open('x') as f: subprocess.run(['pmset', '-g', 'batt'], stdout=f, check=True)
    subprocess.Popen(['caffeinate', '-is', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    guard = [sys.executable, str(E / 'run-bounded-source-guards.py')]
    subprocess.run([*guard, 'pre', stem, '0'], cwd=R, env=environment(), check=True)
    try:
        recorder = subprocess.run([str(NODE), str(E / 'run-bounded-source-c2.mjs'), stem, sys.executable, str(P / 'run.py'), '--child', str(out), sha(out / 'binding.json')], cwd=R, env=environment()).returncode
    finally: post_code = subprocess.run([*guard, 'post', stem], cwd=R, env=environment()).returncode
    record = json.loads((E / (stem + '.json')).read_text()); post = json.loads((E / (stem + '-postflight.json')).read_text())
    assert recorder == post_code == 0
    assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
    assert record['sourceSha'] == record['sourceShaAtEnd'] == post['head'] == a.head
    assert record['exitCode'] == post['exitCode']
    assert verify(a.head, a.manifest_sha256) == pins
    child_result = json.loads((out / 'CHILD.json').read_text()); assert child_result['allGuardsExact']
    code = child_result['actualChildExit']; group = child_result['processGroup']
    expected_exit = 124 if child_result['timedOut'] else (1 if not group['noSurvivors'] or not group['leaderReaped'] else (code if isinstance(code, int) and code >= 0 else 1))
    assert record['exitCode'] == post['exitCode'] == expected_exit, 'Node/cleanup/recorder exit mismatch'
    paths = [f for f in out.rglob('*') if f.is_file()]
    for f in paths: safe(f)
    paths += [E / (stem + suffix) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']]
    artifacts = {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in sorted(paths)}
    write(out / 'RESULT.json', {**child_result, 'mode': a.mode, 'pins': pins, 'recorderChildExit': record['exitCode'], 'allGuardsExact': True, 'artifacts': artifacts, 'interpretation': 'One exact guarded route only. Zero diagnostic exit alone is not GREEN; final aggregate requires both complete routes, zero failed weekly admissions and three valid endpoints each.'})
    print(json.dumps({'receipt': str(out / 'RESULT.json'), 'receiptSha256': sha(out / 'RESULT.json'), 'actualChildExit': child_result['actualChildExit'], 'timedOut': child_result['timedOut']}))
    return record['exitCode'] if isinstance(record['exitCode'], int) and record['exitCode'] >= 0 else 1
if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '--child': sys.exit(child(Path(sys.argv[2]), sys.argv[3]))
    sys.exit(main())
