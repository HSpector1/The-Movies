# Integrated R4 writing — independent measured review

Accepted for this four-leaf focused scope. RESULT SHA-256 `8029a91c8ba20e992807981b1c6961ad8cda584fffd142b7653584263d77fb07`; binding `5cf2c7ca20e9a066a850b544d091dfcfc37b089fbe0290227c0744ba6ae59fd3`; Vitest JSON `43dabb0352c01593bae0ea4388e728f1c95945a50b64fa3e3d8416138a5b9c60`.

Independently verified result/binding/raw/JSON hashes and all four full assertion rows: both prospective rival term regressions and both public paid completion-boundary controls passed, with no skipped or failed leaves. Exact two-file selection, actual Node exit 0, 14.644750 seconds, formal recorder exit 0 and completed fixed-source/all-guards-exact postflight are recorded. Binding pins equal the accepted R4 types binding exactly.

The integrated portable loader therefore exercised the accepted genuine pre414 capture on R4, preserving the selected term end416 and public admission after refusal of the due417 draft. The public controls retain real paid completion before expiry; they do not prove a naturally reached rival equality case. No new witness, hash repin, deadline change or bypass was introduced by this run.

This accepts the integrated writing scope only. Retirement, protected comparisons, original recovery scopes, guarded full replay and broad/promotion gates require their own receipts. Active retirement outputs were not read. No runtime, compiler, fixture payload access or source/index/Git mutation was performed in this review.
