# R4 types and generators — independent measured review

Accepted for the exact guarded R4 candidate only. RESULT SHA-256: `ea2dc1bf0e744bd53cf8eba3e303bcd39b01f88f0480b1d1aeb643ab4e594947`; binding: `b717179fdb044c5aa1211cc5087a403d8a45148647fbdfa2589f95a8ee55e857`.

All six actual child exits are 0: root, UI, Bridge and producer typechecks, plus both contract generator checks. Independently rehashed all six raw outputs and the result/binding, inspected the commands, and verified the formal recorder command, child exit 0, completed postflight exit 0, fixed source and exact guard declarations. Four type outputs are empty; generator outputs retain their own hashes.

The binding identifies 1,625 consumed files, source map `ca96ecb42e78ddf4442e17804bd15a80d70e5808a5e78ed42f43b4f06a0320d2`, assembly `604e0a722f5248ef7003ba5dc9216462564d6dad29ba86519612198fb53b94f5`, scratch HEAD `956fc30e340a13461b701e70aa3d3aa34397b653`, and reviewed runner `26ac8dfd421c777b0c38f9b046711a78afb796d421e2c84a959064caa16fae3c`. Coordinator publication HEAD is `f5cba8b7ea41a1b3ec87cff43c1bcb1a7b7b0f9a`; it is not a claim that R4 gameplay is published.

This admits the matching types prerequisite for the reviewed focused runners. It proves neither behavioral tests nor broad acceptance, campaign measurements, source landing or checkpoint completion. Receipt review only: no compiler/runtime, fixture payload access, source/index edits or Git operation; active writing outputs were not read.
