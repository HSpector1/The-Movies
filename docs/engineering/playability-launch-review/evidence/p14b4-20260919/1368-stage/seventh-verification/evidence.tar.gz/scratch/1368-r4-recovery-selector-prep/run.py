from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time
r=Path('/Users/zacheryspector/The-Movies-headless-program');s=Path('/Users/zacheryspector/studio-scratch');p=s/'1368-save46-swept-proposal-r4';t=p/'tree';e=r/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';node=Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin');prep=s/'1368-r4-recovery-selector-prep';typesPrep=s/'1368-writing-guard-integration-prep'
sha=lambda b:hashlib.sha256(b).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['part-a','b','adapter','c','migration','period']);parser.add_argument('--head',required=True);parser.add_argument('--run-id',required=True);parser.add_argument('--child');parser.add_argument('--types-receipt',required=True);parser.add_argument('--types-receipt-sha256',required=True);a=parser.parse_args()
import re
assert re.fullmatch(r'[0-9a-f]{40}',a.head);assert re.fullmatch(r'[a-z0-9][a-z0-9-]{0,39}',a.run_id)
base=a.head;stem='1368-r4-recovery-'+a.mode+'-'+a.run_id;out=prep/('run-'+a.mode+'-'+a.run_id)
KIT_PINS={'SELECTIONS.json': '220d461705378a34a25324ef90bf751e709547ee9fc7069a009d87a468728dba', 'FIXTURE-PINS.json': '618cdf309eeff5c17dac32d18a4a278363da59fd10d4e800b18aacdc1e8c44a9'}
selections=json.loads((prep/'SELECTIONS.json').read_text())
assert sha((p/'SOURCE-PINS.json').read_bytes())=='ca96ecb42e78ddf4442e17804bd15a80d70e5808a5e78ed42f43b4f06a0320d2'
assert sha((p/'ASSEMBLY.json').read_bytes())=='604e0a722f5248ef7003ba5dc9216462564d6dad29ba86519612198fb53b94f5'

source=json.loads((p/'SOURCE-PINS.json').read_text());extra=json.loads((prep/'FIXTURE-PINS.json').read_text())
env=dict(os.environ,PATH=str(node)+':'+str(r/'.venv/bin')+':'+os.environ['PATH'],GIT_OPTIONAL_LOCKS='0',P1368_ACCEPTED45_ROOT=str(r/'tests/fixtures/p14/genuine-v45-recovery-witnesses-1368'),P1368_ACCEPTED45_MANIFEST_SHA256='11ad61be481a8bec170f40425cfcfe7fcb24596418d30b6c8bf27895e93c3ba5',P1368_ACCEPTED26_ROOT=str(r/'tests/fixtures/p13b/genuine-v26-period52-1368'),P1368_ACCEPTED26_MANIFEST_SHA256='8e40e51bb360ba6ff6c0d641a03e90aa8ed6f73f8c0b232a9a4b5861af358db4',RIVAL_WRITING_CAPTURE_DIR=str(r/'tests/fixtures/p14/genuine-v46-rival-writing-pre414-1368'),RIVAL_WRITING_MANIFEST_SHA256='d097bbf131c1dc495b881d73e96994953b2f6a0ef50f88bd3b043f263024f205')
bounded=s/'1361-capture-runner/bounded-child.py'
def verify():
 assert sha(bounded.read_bytes())=='717d02e676d08600ffd4c5b54cb9cb5b94d3d4ddb73555ad70981e8bae406b9c'
 assert sha((typesPrep/'run.py').read_bytes())=='26ac8dfd421c777b0c38f9b046711a78afb796d421e2c84a959064caa16fae3c'
 assert sha((typesPrep/'tsconfig.producers.json').read_bytes())=='24eaf19d3c7decbac18b573f8e627305a2e9001aeadf55ad26c40a3b2622a0ea'
 for name,expected in KIT_PINS.items():assert sha((prep/name).read_bytes())==expected,'kit drift '+name
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,env=env,text=True).strip()==base
 for n,h in source.items():assert sha((t/n).read_bytes())==h,'candidate drift '+n
 for n,h in extra.items():assert sha((r/n).read_bytes())==h,'fixture drift '+n
 assert subprocess.check_output(['node','--version'],env=env,text=True).strip()=='v20.20.2'
 # Reject new source files in the frozen snapshot; normal runtime caches/output stay outside this source scope.
 unknown=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','src','tests','bridge','ui','generated','scripts'],cwd=t,env=env,text=True).splitlines()
 assert not unknown,unknown
 actual=[]
 for directory,dirs,files in os.walk(t,followlinks=False):
  current=Path(directory)
  dirs[:]=[n for n in dirs if not (current/n).is_symlink() and not (current==t and n in ['.git','dist','.tmp'])]
  for n in files:
   file=current/n
   if not file.is_symlink():actual.append(file.relative_to(t).as_posix())
 assert sorted(actual)==sorted(source),'exact consumed regular-file inventory changed'
 scratchHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,env=env)
 scratchStage=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=t,env=env)
 scratchIndex=(t/'.git/index').read_bytes()
 return {'scratchHead':scratchHead.decode().strip(),'scratchIndexSha256':sha(scratchIndex),'scratchStageSha256':sha(scratchStage),'regularInventorySha256':sha(json.dumps(sorted(actual)).encode()),'sourcePinsSha256':sha((p/'SOURCE-PINS.json').read_bytes()),'assemblySha256':sha((p/'ASSEMBLY.json').read_bytes()),'boundedHelperSha256':sha(bounded.read_bytes()),'runnerSha256':sha(Path(__file__).read_bytes()),'selectionSha256':sha((prep/'SELECTIONS.json').read_bytes()),'producerConfigSha256':sha((typesPrep/'tsconfig.producers.json').read_bytes()),'fixturePinsSha256':sha((prep/'FIXTURE-PINS.json').read_bytes()),'nodeSha256':sha((node/'node').read_bytes()),'vitestEntrySha256':sha((t/'node_modules/vitest/vitest.mjs').read_bytes()),'tscEntrySha256':sha((t/'node_modules/typescript/bin/tsc').read_bytes())}
def exclusive(path):
 assert not os.path.lexists(path),str(path)
 assert not any(x.is_symlink() for x in [path,*path.parents]),str(path)
def prior_types(current):
 path=Path(a.types_receipt);assert path.is_absolute() and not any(x.is_symlink() for x in [path,*path.parents]);assert sha(path.read_bytes())==a.types_receipt_sha256
 assert path.name=='RESULT.json' and path.parent.parent==typesPrep and path.parent.name.startswith('run-types-')
 runid=path.parent.name.removeprefix('run-types-');assert re.fullmatch(r'[a-z0-9][a-z0-9-]{0,39}',runid)
 data=json.loads(path.read_text());binding=path.parent/'binding.json';bound=json.loads(binding.read_text())
 assert data['mode']=='types' and data['allGuardsExact'] and data['sourceFiles']==len(source) and sha(binding.read_bytes())==data['bindingSha256']
 assert data['baseHead']==bound['baseHead']
 for key in ['scratchHead','scratchIndexSha256','scratchStageSha256','regularInventorySha256','sourcePinsSha256','assemblySha256','fixturePinsSha256','nodeSha256','vitestEntrySha256','tscEntrySha256']:
  assert bound['pins'][key]==current[key],'types source mismatch '+key
 expected=[('root',['node','node_modules/typescript/bin/tsc','--noEmit']),('ui',['node','node_modules/typescript/bin/tsc','-p','ui/tsconfig.json','--noEmit']),('bridge',['node','node_modules/typescript/bin/tsc','-p','tsconfig.bridge.json']),('contract',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract.ts','--check']),('contract-fixtures',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract-fixtures.ts','--check']),('producers',['node','node_modules/typescript/bin/tsc','--noEmit','-p',str(typesPrep/'tsconfig.producers.json')])]
 assert [(row['name'],row['command']) for row in data['results']]==expected
 pins={str(path):sha(path.read_bytes()),str(binding):sha(binding.read_bytes())}
 for row in data['results']:
  assert row['actualChildExit']==0
  raw=path.parent/(row['name']+'.txt');assert sha(raw.read_bytes())==row['rawSha256'];pins[str(raw)]=sha(raw.read_bytes())
 stem='1368-swept-r4-types-'+runid
 for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json']:
  f=e/(stem+suffix);assert not f.is_symlink();pins[str(f)]=sha(f.read_bytes())
 record=json.loads((e/(stem+'.json')).read_text());post=json.loads((e/(stem+'-postflight.json')).read_text())
 assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact'] and record['exitCode']==post['exitCode']==0
 assert record['sourceSha']==record['sourceShaAtEnd']==post['head']==data['baseHead']
 assert record['command'][1:]==[str(typesPrep/'run.py'),'types','--head',data['baseHead'],'--run-id',runid,'--child',data['bindingSha256']]
 assert bound['pins']['runnerSha256']==sha((typesPrep/'run.py').read_bytes())
 return pins
def selected_exit(rows,result):
 for row in rows:
  if row['boundedHelperExit']!=0:return row['boundedHelperExit']
 return 0 if result['exactFileSelection'] and result['exactLeafSelection'] and result['allSelectedPassed'] else 1
if a.child:
 binding=out/'binding.json';assert sha(binding.read_bytes())==a.child;bound=json.loads(binding.read_text());assert verify()==bound['pins'];assert prior_types(bound['pins'])==bound['typesPins']
 selection=selections[a.mode]
 args=['node','node_modules/vitest/vitest.mjs','run','--project','core',*selection['files'],'--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=verbose','--reporter=json','--outputFile.json='+str(out/'vitest.json')]
 commands=[(a.mode,[sys.executable,str(bounded),'330',*args])]
 results=[]
 for name,cmd in commands:
  start=time.monotonic()
  with (out/(name+'.txt')).open('x') as f:c=subprocess.run(cmd,cwd=t,env=env,stdout=f,stderr=subprocess.STDOUT)
  raw=(out/(name+'.txt')).read_text();boundedRows=[]
  for line in raw.splitlines():
   if line.startswith('{\"boundedCaptureChild\": true,'):
    boundedRows.append(json.loads(line))
  assert len(boundedRows)==1,'missing/duplicate actual bounded-child receipt'
  receipt=boundedRows[0];assert receipt['boundedCaptureChild'] is True and receipt['timeoutSeconds']==330 and isinstance(receipt['childExit'],int) and isinstance(receipt['timedOut'],bool)
  helperExit=124 if receipt['timedOut'] else (receipt['childExit'] if receipt['childExit']>=0 else 1);assert c.returncode==helperExit
  row={'name':name,'command':cmd,'nodeCommand':args,'actualChildExit':receipt['childExit'],'boundedHelperExit':c.returncode,'boundedChild':receipt,'seconds':time.monotonic()-start,'rawSha256':sha((out/(name+'.txt')).read_bytes())};results.append(row);print(json.dumps(row),flush=True)
 assert verify()==bound['pins'];assert prior_types(bound['pins'])==bound['typesPins'];assert sha(binding.read_bytes())==a.child
 result={'mode':a.mode,'baseHead':base,'sourceFiles':len(source),'allGuardsExact':True,'bindingSha256':a.child,'results':results}
 if (out/'vitest.json').exists():
  result['vitestJsonSha256']=sha((out/'vitest.json').read_bytes())
  data=json.loads((out/'vitest.json').read_text())
  actual=sorted(str(Path(row['name']).relative_to(t)) for row in data['testResults'])
  result['actualSelectedFiles']=actual;result['exactFileSelection']=actual==sorted(selections[a.mode]['files'])
  allrows=[row for file in data['testResults'] for row in file['assertionResults']]
  result['expectedCaseCount']=selections[a.mode]['expectedCases'];result['actualCaseCount']=len(allrows)
  result['caseResults']=allrows;result['caseCounts']={status:sum(row['status']==status for row in allrows) for status in sorted({row['status'] for row in allrows})}
  result['exactLeafSelection']=len(allrows)==selections[a.mode]['expectedCases']
  result['allSelectedPassed']=result['exactLeafSelection'] and all(row['status']=='passed' for row in allrows)
 else:
  result['exactFileSelection']=False;result['exactLeafSelection']=False;result['allSelectedPassed']=False
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');sys.exit(selected_exit(results,result))
exclusive(out);pins=verify();typePins=prior_types(pins);assert subprocess.check_output(['git','ls-remote','--exit-code','origin','refs/heads/wip/headless-program-20260916-ts'],cwd=r,env=env,text=True).split()==[base,'refs/heads/wip/headless-program-20260916-ts'];out.mkdir();assert shutil.disk_usage(r).free>=5*1024**3
for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json']:exclusive(e/(stem+suffix))
(out/'binding.json').write_text(json.dumps({'baseHead':base,'pins':pins,'sourceFiles':len(source),'fixturePins':extra,'selectedFiles':selections[a.mode]['files'],'expectedCaseCount':selections[a.mode]['expectedCases'],'typesPins':typePins,'scope':'1368D six original full-file recovery scopes on guarded r4; historical passes are not current acceptance','environment':{k:v for k,v in env.items() if k.startswith('P1368_') or k.startswith('RIVAL_WRITING_') or k=='PATH'}},indent=2)+'\n')
with (out/'power.txt').open('x') as f:subprocess.run(['pmset','-g','batt'],stdout=f,check=True)
subprocess.Popen(['caffeinate','-is','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
guard=[sys.executable,str(e/'run-bounded-source-guards.py')];subprocess.run([*guard,'pre',stem,'0'],cwd=r,env=env,check=True)
try:recordExit=subprocess.run(['node',str(e/'run-bounded-source-c2.mjs'),stem,sys.executable,str(Path(__file__).resolve()),a.mode,'--head',base,'--run-id',a.run_id,'--types-receipt',a.types_receipt,'--types-receipt-sha256',a.types_receipt_sha256,'--child',sha((out/'binding.json').read_bytes())],cwd=r,env=env).returncode
finally:postExit=subprocess.run([*guard,'post',stem],cwd=r,env=env).returncode
assert recordExit==postExit==0
record=json.loads((e/(stem+'.json')).read_text());post=json.loads((e/(stem+'-postflight.json')).read_text());assert record['fixedSource'] and post['allGuardsExact'] and record['exitCode']==post['exitCode'];assert verify()==pins;assert prior_types(pins)==typePins
assert record['sourceSha']==record['sourceShaAtEnd']==post['head']==base
assert record['command']==[sys.executable,str(Path(__file__).resolve()),a.mode,'--head',base,'--run-id',a.run_id,'--types-receipt',a.types_receipt,'--types-receipt-sha256',a.types_receipt_sha256,'--child',sha((out/'binding.json').read_bytes())]
childResult=json.loads((out/'RESULT.json').read_text());expectedExit=selected_exit(childResult['results'],childResult)
assert record['exitCode']==expectedExit
paths=[f for f in out.iterdir() if f.is_file()]+[e/(stem+suffix) for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json']]
(out/'POSTFLIGHT-RECEIPT.json').write_text(json.dumps({'mode':a.mode,'actualNodeExits':[row['actualChildExit'] for row in childResult['results']],'recorderChildExit':record['exitCode'],'allGuardsExact':True,'pins':pins,'typesPins':typePins,'artifacts':{str(f):{'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size} for f in paths}},indent=2)+'\n')
print(json.dumps({'mode':a.mode,'actualChildExit':record['exitCode'],'fixedSource':True,'postflight':True}));sys.exit(record['exitCode'] if isinstance(record['exitCode'],int) and record['exitCode']>=0 else 1)
