# R4 original retirement and protected-comparison selectors

Prepared only. This package adds no tests, source edits, fixtures, configs, timeout overrides, worker overrides or gameplay routes. It selects exactly twelve existing leaves from the current r3 test bodies, executing against the parent's assembled guarded r4 candidate. No Node, compiler, Vitest, game runtime, assembly or Git mutation was run during preparation.

The r4 source inventory must be `ca96ecb42e78ddf4442e17804bd15a80d70e5808a5e78ed42f43b4f06a0320d2`; assembly must be `604e0a722f5248ef7003ba5dc9216462564d6dad29ba86519612198fb53b94f5`. Actual root is `S/1368-save46-swept-proposal-r4/tree`, with 1,625 regular consumed files. The actual published live HEAD is a required dynamic argument and must match the remote branch; it is coordinator provenance, not a claim that the unlanded r4 gameplay is published.

## Three bounded selections

`SELECTIONS.json` contains the exact full Vitest titles and anchored escaped regexes. Each mode runs only its named file under the unchanged `core` project/configs:

| Mode | File | Original selected leaves | Original per-leaf deadline |
| --- | --- | ---: | ---: |
| retirement | tests/p14c2rm-writer-continuation.test.ts | 9 | Core default 5,000 ms |
| take | tests/p14b5-relationships.test.ts | 1 | Core default 5,000 ms |
| market | tests/p15a1-market-integration.test.ts | 2 | Explicit MEDIUM = 300,000 ms |

Retirement selects the entire original `880-B natural retired-writer continuation` describe: active-contract control, E-boundary save/load, due completion, uninterrupted/resumed parity, D<E announced continuation, Calendar/construction, unrelated lawful commission, pooled writer and the existing no-new-work/release-refusal companion. The latter is a negative companion, not counted as a ninth positive.

Take selects the original `no RNG reaches the seam: ... everything but the root is byte-identical to the frozen post-tick state` leaf. Market selects only the K1 `one pressured tick differs ... only inside the pressured chain` and K2 `the post-tick state minus the new roots ... RED-commit pin` leaves. The neighboring market behavior-only leaves are not accidentally selected. Original deadlines and all assertions remain untouched.

The completed report must contain the exact file and every exact selected title once; unexpected active titles, a missing title or skipped selected leaf prevents success. Unselected original leaves may be reported skipped by Vitest and remain visible in the complete report. Actual failed selected leaves are preserved, not collapsed into wrapper status. Actual Node exit, title/file checks and recorder child/postflight exit are reconciled; final `POSTFLIGHT-RECEIPT.json` binds all output and five formal evidence files.

## Prerequisite types and recorded lifecycle

The existing r4 integration runner must first complete all six original types/check commands successfully: root, UI, Bridge, contract generator check, contract-fixture generator check and producer types. This selector runner accepts only that package's completed `run-types-<id>/RESULT.json`, supplied with its actual SHA. It verifies the matching exact source/assembly/index/entrypoint pins, all six command identities and child exits, binding/raw hashes, and the completed five-file formal type recorder/postflight. An old-r3 type pass, an incomplete run or a generator-only pass does not qualify. Documentation HEAD may advance between the admitted type run and selection; consumed candidate identity cannot.

`RUNNER-DELTA.diff` is the complete change from `S/1368-writing-guard-integration-prep/run.py` (26ac8dfd421c777b0c38f9b046711a78afb796d421e2c84a959064caa16fae3c). It reuses that exact synchronous child lifecycle, ordinary existing Vitest configuration, 5 GiB floor, Node 20.20.2, power/caffeinate receipt, full regular inventory and scratch HEAD/index/stage checks, fixture pin map and existing five-output source recorder/manual guards. It adds the bounded selected-title accounting and completed-type prerequisite above.

This inherited synchronous runner has no separate process-group watchdog or no-survivor proof. The unchanged Vitest per-leaf deadlines apply; do not claim an external cleanup guarantee or introduce a deadline increase from this package. Parent retains the sole heavy lane and existing operational supervision.

## Invocation

After independent static approval, completed r4 assembly and admitted r4 types, run the three modes separately. Expand `S` to `/Users/zacheryspector/studio-scratch`; replace descriptive values with the actual current published full HEAD and completed type receipt/hash:

```
python3 S/1368-r4-original-selector-prep/run.py retirement --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
python3 S/1368-r4-original-selector-prep/run.py take --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
python3 S/1368-r4-original-selector-prep/run.py market --head ACTUAL_PUBLISHED_HEAD --run-id r1 --types-receipt ABSOLUTE_R4_TYPES_RESULT --types-receipt-sha256 ACTUAL_TYPES_SHA
```

External outputs are exclusive `S/1368-r4-original-selector-prep/run-<mode>-<id>/`; formal evidence stems are `1368-r4-original-<mode>-<id>`. Existing or dangling output paths refuse. Parent must bind the exact reviewed runner/package hash at launch, as with its source integration runner. There is no automatic rerun or alternate selection.

## What a result proves

880-B preserves already-lawful recorded retirement obligations. These nine original controls use the existing disclosed $30m fixture bootstrap, followed by actual player creation, employment, renewal, commission and clock transitions. They are funded player retirement regressions, not an unfunded natural rival prospective-admission witness. Their current `admitted` helper must genuinely admit V46 after the approved reader sweep. The separate genuine-V37 historical pair and strict old-reader tests are outside this selection; no bypass of them is implied.

The take control retains its genuine V30 public-reader-first fixture admission and current migration. K1/K2 retain their original pinned historical preimage/manifest. All three comparison operands must first admit the full current state and successfully use the real guarded V46-to-V45 conversion. A cutting/refund/disposal authority refusal is an unmet control, not permission to strip fields or repin. K1's measured thirteen raw outside paths were eight recovery fields plus five Object.is-zero differences; the original allowed-path list stays unchanged.

Authority and measured scope remain `880-B-retirement-writer-validation-contract.md`, adopted `1363-N-save46-recovery-fallout-sweep.md`, and `S/1368-independent-review/PROTECTED-DIGEST-MEASURED.md` / `PROTECTED-COMPARISON-PATCH-STATIC.md`. The previous diagnostic evidence does not substitute for these original leaves on r4. Any setup failure, historical admission failure, timeout, guard failure, missing title or failed original assertion remains a failure. No broad checkpoint closure is claimed by these selections.
