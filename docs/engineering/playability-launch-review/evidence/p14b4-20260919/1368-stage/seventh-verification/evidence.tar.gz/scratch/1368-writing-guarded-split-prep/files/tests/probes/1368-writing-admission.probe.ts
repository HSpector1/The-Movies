// Diagnostic only: exact original S7 routes, no gameplay repair or policy intervention.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { appendFileSync, lstatSync, mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs'
import { dirname, isAbsolute, relative, resolve, sep } from 'node:path'
import { it, vi } from 'vitest'
import { p13aGeneratedStudio } from '../../src/harness/p13a/fixtures.js'
import { tick } from '../../src/core/tick.js'
import { makeSave, stableStringify } from '../../src/core/save.js'
import { commitPlacement } from '../../src/core/placement.js'
import { considerRivalSoundPurchase } from '../../src/core/technologyRival.js'
import { newFinancePeriod, rivalWeeklyOperatingCost } from '../../src/core/hollywood.js'
import { renewalWindowOpen } from '../../src/core/employment.js'
import * as phases from '../../src/core/hollywoodTick.js'
import * as market from '../../src/core/talentMarket.js'
import type { GameState } from '../../src/core/types.js'

const SEED = 'p13b-s7-independence-01'
const END = 416
const PIN_SHA = '97ee1e66b0d9db7b6ae0ffab0730cdb91d51f6eb0bd17d35ef93674d83c72f0b'
const sha = (v: string | Uint8Array) => createHash('sha256').update(v).digest('hex')
// Full-state parity is distinct from the public JSON save codec. Keep collection
// iteration order, undefined-valued properties, array holes and special numbers.
function bytes(value: unknown): string {
  const ancestors = new Set<object>()
  const visit = (v: unknown): unknown => {
    if (v === null) return ['null']
    if (v === undefined) return ['undefined']
    if (typeof v === 'number') return ['number', Object.is(v, -0) ? '-0' : String(v)]
    if (typeof v === 'string' || typeof v === 'boolean' || typeof v === 'bigint') return [typeof v, String(v)]
    assert(typeof v === 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) return ['Map', [...v].map(([k, x]) => [visit(k), visit(x)])]
      if (v instanceof Set) return ['Set', [...v].map(visit)]
      if (v instanceof Date) return ['Date', v.toISOString()]
      if (ArrayBuffer.isView(v)) return [v.constructor.name, Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64')]
      if (v instanceof ArrayBuffer) return ['ArrayBuffer', Buffer.from(v).toString('base64')]
      if (Array.isArray(v)) return ['Array', Array.from({ length: v.length }, (_, i) => i in v ? visit(v[i]) : ['hole'])]
      const proto: unknown = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      const record = v as Record<string, unknown>
      return [proto === null ? 'null-object' : 'object', Object.keys(record).sort().map(k => [k, visit(record[k])])]
    } finally { ancestors.delete(v) }
  }
  return JSON.stringify(visit(value))
}
const copy = <T,>(v: T): T => structuredClone(v)
function exists(path: string): boolean { try { lstatSync(path); return true } catch (e) { if ((e as NodeJS.ErrnoException).code === 'ENOENT') return false; throw e } }
function ordinary(path: string): void {
  for (let p = path; ; p = dirname(p)) { assert(!lstatSync(p).isSymbolicLink(), `symlink ${p}`); if (p === dirname(p)) break }
}
function facts(s: GameState) {
  const h = s.hollywood
  const owners = [{ studioId: h?.playerStudioId ?? 'player', projects: s.scriptDevelopment.projects },
    ...(h?.businesses.map(b => ({ studioId: b.studioId, projects: b.development.projects })) ?? [])]
  const work = owners.flatMap(o => o.projects.filter(p => p.status === 'drafting' || p.status === 'rewriting' || p.id === 'script-0034')
    .map(p => {
      const writerIds = p.writerIds ?? [p.writerId]
      return { studioId: o.studioId, project: copy(p), writers: writerIds.map(id => ({ id,
        person: copy(s.talent.find(t => t.id === id)),
        playerContracts: copy(s.contracts.filter(c => c.talentId === id)),
        employment: copy(h?.employment.filter(e => e.studioId === o.studioId && e.terms.talentId === id) ?? []),
        marketCases: copy(s.talentMarket.cases.filter(c => c.talentId === id)),
        retirementRecords: copy(s.careerLifecycle.records.filter(r => r.personId === id)),
        // Raw coverage only. Retirement-writing exceptions remain the real validator's law.
        activeContractNow: o.studioId === h?.playerStudioId
          ? s.contracts.some(c => c.talentId === id && c.startWeek <= s.market.tick && s.market.tick < c.endWeekExclusive)
          : (h?.employment.some(e => e.studioId === o.studioId && e.terms.talentId === id && e.endedWeek === null
            && e.terms.startWeek <= s.market.tick && s.market.tick < e.terms.endWeekExclusive) ?? false),
      })) }
    }))
  return { week: s.market.tick, playerDevelopmentMode: s.scriptDevelopment.mode, work,
    owners: h?.businesses.map(b => ({ studioId: b.studioId, cash: b.account.cash, cutting: copy(b.costCutting),
      nextDecisionWeek: b.nextDecisionWeek, lastPeriod: copy(b.account.periods.at(-1)) })) ?? [] }
}
function admission(s: GameState) {
  const before = bytes(s)
  try {
    const saved = makeSave(s)
    assert.equal(saved.saveVersion, 46)
    return { ok: true as const, saveSha256: sha(stableStringify(saved)), saveBytes: Buffer.byteLength(stableStringify(saved)) }
  } catch (e) { return { ok: false as const, error: e instanceof Error ? e.message : String(e) } }
  finally { assert.equal(bytes(s), before, 'writer admission mutated state') }
}
function purchase(s: GameState): GameState {
  const hollywood = copy(s.hollywood)!
  let result = s.technology
  for (const b of hollywood.businesses) { result = considerRivalSoundPurchase(s, hollywood, b); if (result !== s.technology) break }
  assert.notEqual(result, s.technology, 'UNMET original purchase premise; no seed, cash or horizon fallback')
  return { ...s, hollywood, technology: result }
}
function periodVariant(s: GameState): GameState {
  const target = s.hollywood!.businesses[0]!
  return { ...s, hollywood: { ...s.hollywood!, businesses: s.hollywood!.businesses.map(b => b.studioId !== target.studioId ? b :
    { ...b, account: { ...b.account, periods: [newFinancePeriod(b.account.periods[0]!.fromWeek, b.account.openingBalance), ...b.account.periods] } }) } }
}
function start(laboratory: boolean): GameState {
  const state = p13aGeneratedStudio(SEED)
  return laboratory ? commitPlacement(state, { blueprintId: 'research-laboratory', origin: { gx: 0, gy: 9 } }) : state
}

it('diagnoses exact S7 admission boundaries without changing source or route', () => {
  const selectedRoute = process.env.DIAG_ROUTE
  assert(selectedRoute === 'core-no-laboratory' || selectedRoute === 'bridge-laboratory', 'explicit DIAG_ROUTE enum required')
  const root = realpathSync(process.cwd())
  const output = process.env.DIAG_OUTPUT
  const pinPath = process.env.DIAG_INPUT_PINS
  assert(output && pinPath && isAbsolute(output) && isAbsolute(pinPath))
  assert(!exists(output), 'output already exists, including dangling symlink')
  ordinary(dirname(output)); ordinary(pinPath)
  const relativeOutput = relative(root, output)
  assert((relativeOutput === '..' || relativeOutput.startsWith('..' + sep)) && !isAbsolute(relativeOutput), 'output must be outside source tree')
  for (const forbidden of ['/Users/zacheryspector/The-Movies-headless-program', '/Users/zacheryspector/studio-scratch/1368-writing-admission-diagnostic-prep', '/Users/zacheryspector/studio-scratch/1368-writing-split-prep']) {
    const rel = relative(forbidden, output); assert(rel === '..' || rel.startsWith('..' + sep), 'output inside publication source or immutable preparation')
  }
  const pinBytes = readFileSync(pinPath); assert.equal(sha(pinBytes), PIN_SHA)
  const pins = JSON.parse(pinBytes.toString()) as { files: Record<string, { sha256: string; bytes: number }> }
  const check = () => { for (const [rel, pin] of Object.entries(pins.files)) {
    const path = resolve(root, rel); ordinary(path); const data = readFileSync(path)
    assert.equal(data.byteLength, pin.bytes, rel); assert.equal(sha(data), pin.sha256, rel)
  } }
  check(); mkdirSync(output) // exclusive; parent recorder separately binds publication/index/whole kit.
  const produced: string[] = []
  const emit = (name: string, value: unknown) => {
    const path = resolve(output, name)
    if (!produced.includes(name)) { assert(!exists(path)); writeFileSync(path, '', { flag: 'wx' }); produced.push(name) }
    appendFileSync(path, JSON.stringify(value) + '\n')
  }
  const started = performance.now()
  let success = false
  try {
    const routes: unknown[] = []
    for (const laboratory of [selectedRoute === 'bridge-laboratory']) {
      const route = laboratory ? 'bridge-laboratory' : 'core-no-laboratory'
      let state = start(laboratory)
      const hashes = [sha(bytes(state))]
      const firstAdmission = admission(state); assert(firstAdmission.ok, 'UNMET generated starting admission')
      const advanceReal = phases.advanceHollywoodWeek, finishReal = phases.finishHollywoodWeek, floorReal = market.floorOffer
      let inAdvance = false, advances = 0, finishes = 0
      const pending: unknown[] = []
      const advanceSpy = vi.spyOn(phases, 'advanceHollywoodWeek').mockImplementation((...args) => {
        advances++; inAdvance = true
        const before = facts(args[0]), oldReceipts = args[0].hollywood?.receipts.length ?? 0
        try {
          const result = advanceReal(...args)
          const view = { ...args[0], hollywood: result.hollywood, talent: result.talent, technology: result.technology, physicalPlans: result.physicalPlans }
          pending.push({ phase: 'advanceHollywoodWeek', before, after: facts(view), newReceipts: copy(result.hollywood?.receipts.slice(oldReceipts) ?? []) })
          return result
        } finally { inAdvance = false }
      })
      const finishSpy = vi.spyOn(phases, 'finishHollywoodWeek').mockImplementation((...args) => {
        finishes++; const before = facts(args[0]), length = args[0].hollywood?.receipts.length ?? 0
        const result = finishReal(...args)
        pending.push({ phase: 'finishHollywoodWeek', before, after: facts(result), newReceipts: copy(result.hollywood?.receipts.slice(length) ?? []) })
        return result
      })
      const floorSpy = vi.spyOn(market, 'floorOffer').mockImplementation((...args) => {
        const result = floorReal(...args)
        if (inAdvance) {
          const [s, studioId] = args, week = args[3] ?? s.market.tick, h = s.hollywood!
          const b = h.businesses.find(b => b.studioId === studioId)
          const ordinal = h.activeEmploymentOrdinals.find(i => { const e = h.employment[i]!; return e.studioId === studioId && e.terms.talentId === result.talentId })
          if (b && ordinal !== undefined && renewalWindowOpen(h.employment[ordinal]!.terms, week)) {
            // Independent evaluation of the exact staff reserveAfterOffer expression; not a producer input.
            const prospective = { ...h, employment: [...h.employment, { contractId: 'diagnostic-only', studioId, terms: result, endedWeek: null, reason: 'replacement' as const }],
              activeEmploymentOrdinals: [...h.activeEmploymentOrdinals.filter(i => i !== ordinal), h.employment.length] }
            const reserveAfter = rivalWeeklyOperatingCost(b, prospective, week) * b.policy.reserveWeeks
            pending.push({ phase: 'actual-staff-renewal-quote', studioId, week, oldEmployment: copy(h.employment[ordinal]), quote: copy(result),
              cash: b.account.cash, reserveAfter, cashRefusalArithmetic: b.account.cash - result.signingBonus < reserveAfter,
              disclaimer: 'Quote was really called within advanceHollywoodWeek; predicate arithmetic is copied observation, not persisted or a standalone refusal receipt.' })
          }
        }
        return result
      })
      let firstFailure: { inputWeek: number; outputWeek: number; error: string } | null = null
      try {
        emit(route + '.jsonl', { week: 0, admission: firstAdmission, facts: facts(state), stateSha256: hashes[0] })
        for (let week = 0; week < END; week++) {
          const before = bytes(state), oldCount = state.hollywood!.receipts.length
          const next = tick(state) // exact original default path; never develop:true
          assert.equal(bytes(state), before, 'tick mutated its input')
          assert.equal(next.market.tick, week + 1)
          const checked = admission(next)
          if (!checked.ok && firstFailure === null) firstFailure = { inputWeek: week, outputWeek: week + 1, error: checked.error }
          hashes.push(sha(bytes(next)))
          emit(route + '.jsonl', { week: week + 1, stateSha256: hashes.at(-1), admission: checked, facts: facts(next),
            newReceipts: copy(next.hollywood!.receipts.slice(oldCount)), actualPhases: pending.splice(0) })
          state = next
        }
      } finally { floorSpy.mockRestore(); finishSpy.mockRestore(); advanceSpy.mockRestore() }
      assert.equal(advances, END, 'advance observer binding failed'); assert.equal(finishes, END, 'finish observer binding failed')
      // Uninstrumented exact-route replay verifies every whole-state boundary, not only the endpoint.
      let replay = start(laboratory); assert.equal(sha(bytes(replay)), hashes[0])
      for (let week = 0; week < END; week++) { replay = tick(replay); assert.equal(sha(bytes(replay)), hashes[week + 1], `observer parity ${route} week${week + 1}`) }
      // Original labWorld advances to12, then advanceTo continues to416; there is no intervening action.
      const baseBytes = bytes(state), bought = purchase(state), boughtBytes = bytes(bought)
      assert.equal(bytes(state), baseBytes, 'purchase mutated base')
      assert.equal(bytes(bought.scriptDevelopment), bytes(state.scriptDevelopment), 'rival variant changed player scripts')
      assert.equal(bytes(bought.contracts), bytes(state.contracts), 'rival variant changed player contracts')
      const layered = periodVariant(bought)
      assert.equal(bytes(bought), boughtBytes, 'period variant mutated purchase input')
      const comparisons = { base: { admission: admission(state), facts: facts(state), stateSha256: sha(baseBytes) },
        purchase: { admission: admission(bought), facts: facts(bought), stateSha256: sha(boughtBytes) },
        leadingZeroPeriod: { admission: admission(layered), facts: facts(layered), stateSha256: sha(bytes(layered)) } }
      emit(route + '-boundary416.jsonl', comparisons)
      routes.push({ route, seed: SEED, end: END, firstFailure, observerCalls: { advances, finishes }, fullBoundaryReplayParity: true,
        endpointAdmissions: { base: comparisons.base.admission, purchase: comparisons.purchase.admission, leadingZeroPeriod: comparisons.leadingZeroPeriod.admission } })
    }
    assert.equal(routes.length, 1)
    emit('RESULT.jsonl', { status: 'OBSERVED_ONE_ROUTE', selectedRoute, routes, elapsedMs: performance.now() - started,
      note: 'OBSERVED means diagnostic completed, not game acceptance or a proven correction. Null firstFailure means no failure on this exact route.' })
    success = true
  } catch (e) {
    emit('ERROR.jsonl', { status: 'EXECUTION_OR_PREMISE_FAILURE', error: e instanceof Error ? e.stack : String(e), elapsedMs: performance.now() - started })
    throw e
  } finally {
    check()
    const files = Object.fromEntries(produced.map(name => { const data = readFileSync(resolve(output, name)); return [name, { bytes: data.length, sha256: sha(data) }] }))
    writeFileSync(resolve(output, 'MANIFEST.json'), JSON.stringify({ inputPinsSha256: PIN_SHA, selectedRoute, success, files }, null, 2) + '\n', { flag: 'wx' })
  }
}, 300_000)
