# R4 original protected comparisons — measured acceptance

Accepted for all three exact selected original leaves: protected take, K1 confinement and K2 identity. No original digest or allowed-path expectation changed.

Take RESULT `a6bc28513f363d01147694f0e60a5e4797dff7705c0db7fed5bfa173d0aadf8d`, POST `f1436809296361f986b4ea2f718f5fe298259a8339046465b06518a883c9c82a`: one PASS, 52 unselected skips. Its separate measured review is R4-TAKE-MEASURED.md.

Market RESULT `96925be2e29f7c8ebfa950c55cbb644d695bdd341346b019635fc571203fd409`, POST `75c4b40fd83d18e47dbac7478096c709f1fb34903ee34cf93271ef45d08b3fbc`: two PASS, 52 unselected skips. All final receipt artifacts were independently rehashed; exact selected file/title multiplicities, all selected passed, actual Node/recorder 0 and exact source/index guards agree.

The reviewed real public guarded 46-to-45 projection supplies only protected historical comparison operands. Original current behavior assertions, protected digests and K1 permitted paths remain. These results accept the three selected controls on guarded R4; they do not accept either entire file, silently count unselected leaves, or close recovery/broad/promotion obligations. Active Part A output was not read. No runtime, fixture payload access or source/index/Git mutation occurred in this review.
