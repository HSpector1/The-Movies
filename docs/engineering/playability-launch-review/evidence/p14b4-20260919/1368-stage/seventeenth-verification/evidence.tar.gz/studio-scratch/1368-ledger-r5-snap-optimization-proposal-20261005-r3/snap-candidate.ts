function snap(value: unknown): string {
  const ancestors = new Set<object>()
  const completed = new WeakMap<object, unknown>()
  const remember = <T>(node: object, tagged: T): T => { completed.set(node, tagged); return tagged }
  const visit = (v: unknown): unknown => {
    if (v === null) return ['null']
    if (v === undefined) return ['undefined']
    if (typeof v === 'number') return ['number', Object.is(v, -0) ? '-0' : String(v)]
    if (typeof v === 'string' || typeof v === 'boolean' || typeof v === 'bigint') return [typeof v, String(v)]
    assert(typeof v === 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    const cached = completed.get(v)
    if (cached !== undefined) return cached
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) return remember(v, ['Map', [...v].map(([k, x]) => [visit(k), visit(x)])])
      if (v instanceof Set) return remember(v, ['Set', [...v].map(visit)])
      if (v instanceof Date) return remember(v, ['Date', v.toISOString()])
      if (ArrayBuffer.isView(v)) return remember(v, [v.constructor.name, Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64')])
      if (v instanceof ArrayBuffer) return remember(v, ['ArrayBuffer', Buffer.from(v).toString('base64')])
      if (Array.isArray(v)) return remember(v, ['Array', Array.from({ length: v.length }, (_, i) => i in v ? visit(v[i]) : ['hole'])])
      const proto: unknown = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      const record = v as Record<string, unknown>
      return remember(v, [proto === null ? 'null-object' : 'object', Object.keys(record).sort().map(k => [k, visit(record[k])])])
    } finally { ancestors.delete(v) }
  }
  return JSON.stringify(visit(value))
}
