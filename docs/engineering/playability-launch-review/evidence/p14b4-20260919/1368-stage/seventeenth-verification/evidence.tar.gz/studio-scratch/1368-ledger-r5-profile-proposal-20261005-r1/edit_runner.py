from pathlib import Path
p=Path('/Users/zacheryspector/studio-scratch/1368-ledger-r5-profile-proposal-20261005-r1/runner/run.py')
s=p.read_text()
def repl(a,b):
 global s
 assert a in s,a
 s=s.replace(a,b)
repl("P = S / '1368-ledger-parent-prep-r4'\nARMS = S / '1368-ledger-arms-04'\nKIT = P / 'kit'\nRUNS = S / '1368-ledger-recorded-runs-r4-lowspace-r2'\nSELF = S / '1368-ledger-lowspace-runner-proposal-r2' / 'run.py'", "P = S / '1368-ledger-r5-profile-proposal-20261005-r1'\nARMS = P / 'arm'\nKIT = P / 'kit'\nRUNS = S / '1368-ledger-recorded-runs-r5-profile-r1'\nSELF = P / 'runner' / 'run.py'")
repl("CLEANUP = P / 'cleanup.py'", "CLEANUP = S / '1368-ledger-parent-prep-r4' / 'cleanup.py'")
repl("P / 'cleanup.py':", "S / '1368-ledger-parent-prep-r4' / 'cleanup.py':")
repl("    assert arm in [\"C0\", \"ABC\"]\n    ARM = ARMS / arm; T = ARM / \"tree\"", "    assert arm == 'ABC'\n    ARM = ARMS; T = ARM / 'tree'")
repl("    assert b['arm'] in ['C0', 'ABC']; T = ARMS / b['arm'] / 'tree'", "    assert b['arm'] == 'ABC'; T = ARMS / 'tree'")
repl("    assert b['command'] == command_for(b['mode'], out)\n", "    assert b['command'] == command_for(b['mode'], out)\n    assert b['profilePath'] == (str(out / 'profile.jsonl') if b['mode'] != 'types' else None)\n    if b['profilePath'] is not None: exclusive(Path(b['profilePath']))\n")
repl("LEDGER_OUTPUT=str(out / 'data.json'), LEDGER_PROGRESS=str(out / 'progress.jsonl'))", "LEDGER_OUTPUT=str(out / 'data.json'), LEDGER_PROGRESS=str(out / 'progress.jsonl'), LEDGER_PROFILE=b['profilePath'] or '')")
repl("    assert a.mode != 'observed' or a.arm == 'ABC'", "    assert a.arm == 'ABC'")
repl("    stem = '1368-ledger-r4-lowspace-r2-' + tag.lower()", "    stem = '1368-ledger-r5-profile-r1-' + tag.lower()")
repl("    binding = {'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'horizon': 416,", "    binding = {'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'horizon': 416, 'profilePath': str(out / 'profile.jsonl') if a.mode != 'types' else None,")
repl("'sourceStatus': 'C0 is historical 2eaa697e; ABC is the reviewed Save46 candidate plus only the approved prospective-writing guard. Publication HEAD is coordinator provenance only'", "'sourceStatus': 'ABC is the frozen r4 candidate production source with a separate profiling-only probe. Publication HEAD is coordinator provenance only; profiling is diagnostic, not gameplay acceptance'")
needle="        assert all(left['elapsedSeconds'] <= right['elapsedSeconds'] for left, right in zip(progress, progress[1:]))"
addition="""
        profile = [json.loads(line) for line in (out / 'profile.jsonl').read_text().splitlines()]
        assert [row['week'] for row in profile] == list(range(52, 417, 52))
        assert all(set(row) == {'week', 'elapsedSeconds', 'functions'} and set(row['functions']) == {'snap', 'admit', 'owners', 'windowFacts', 'changedCases'} for row in profile)
        assert all(set(stats) == {'calls', 'inclusiveNs', 'exclusiveNs'} and type(stats['calls']) is int and stats['calls'] >= 0 and
                   all(isinstance(stats[key], str) and stats[key].isdigit() for key in ['inclusiveNs', 'exclusiveNs']) and
                   int(stats['inclusiveNs']) >= int(stats['exclusiveNs']) for row in profile for stats in row['functions'].values())
        assert all(left['week'] == right['week'] and left['elapsedSeconds'] <= right['elapsedSeconds'] for left, right in zip(progress, profile))
        if a.mode == 'observed':
            assert profile[-1]['functions']['admit']['calls'] == 417
            assert profile[-1]['functions']['owners']['calls'] == 1664
            assert profile[-1]['functions']['windowFacts']['calls'] == 416
            assert profile[-1]['functions']['changedCases']['calls'] == 832
        else:
            assert profile[-1]['functions']['admit']['calls'] == 417
            assert profile[-1]['functions']['owners']['calls'] == 416
            assert profile[-1]['functions']['windowFacts']['calls'] == 0
            assert profile[-1]['functions']['changedCases']['calls'] == 416
"""
repl(needle,needle+addition)
needle="    paths = [f for f in out.rglob('*') if f.is_file()]"
addition="""    profile_path = out / 'profile.jsonl'
    profile_status = {'expected': a.mode != 'types', 'present': profile_path.is_file(), 'sha256': sha(profile_path) if profile_path.is_file() else None, 'rows': None, 'parseError': None}
    if profile_path.is_file():
        try:
            profile_rows = [json.loads(line) for line in profile_path.read_text().splitlines()]
            profile_status['rows'] = [row['week'] for row in profile_rows]
        except Exception as error:
            profile_status['parseError'] = type(error).__name__ + ': ' + str(error)
"""
repl(needle,addition+needle)
repl("'livePostflightExact': True, 'artifacts': artifacts, 'interpretation':", "'livePostflightExact': True, 'profileStatus': profile_status, 'artifacts': artifacts, 'interpretation':")
p.write_text(s)
