import assert from 'node:assert/strict'
function snap(value: unknown): string {
  const ancestors = new Set<object>()
  const visit = (v: unknown): unknown => {
    if (v === null) return ['null']
    if (v === undefined) return ['undefined']
    if (typeof v === 'number') return ['number', Object.is(v, -0) ? '-0' : String(v)]
    if (typeof v === 'string' || typeof v === 'boolean' || typeof v === 'bigint') return [typeof v, String(v)]
    assert(typeof v === 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) return ['Map', [...v].map(([k, x]) => [visit(k), visit(x)])]
      if (v instanceof Set) return ['Set', [...v].map(visit)]
      if (v instanceof Date) return ['Date', v.toISOString()]
      if (ArrayBuffer.isView(v)) return [v.constructor.name, Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64')]
      if (v instanceof ArrayBuffer) return ['ArrayBuffer', Buffer.from(v).toString('base64')]
      if (Array.isArray(v)) {
        const length = v.length
        const values: unknown[] = new Array(length)
        for (let i = 0; i < length; i++) values[i] = i in v ? visit(v[i]) : ['hole']
        return ['Array', values]
      }
      const proto: unknown = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      const record = v as Record<string, unknown>
      const keys = Object.keys(record).sort()
      const values: unknown[] = new Array(keys.length)
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i]!
        values[i] = [key, visit(record[key])]
      }
      return [proto === null ? 'null-object' : 'object', values]
    } finally { ancestors.delete(v) }
  }
  return JSON.stringify(visit(value))
}

export { snap }
