function snap(value: unknown): string {
  // Emit tagged JSON in the original depth-first order without a second walk of a tagged tree.
  const parts: string[] = []
  const ancestors = new Set<object>()
  const tag = (kind: string, payload?: string) => {
    parts.push('[', JSON.stringify(kind))
    if (payload !== undefined) parts.push(',', JSON.stringify(payload))
    parts.push(']')
  }
  const visit = (v: unknown): void => {
    if (v === null) { tag('null'); return }
    if (v === undefined) { tag('undefined'); return }
    if (typeof v === 'number') { tag('number', Object.is(v, -0) ? '-0' : String(v)); return }
    if (typeof v === 'string' || typeof v === 'boolean' || typeof v === 'bigint') { tag(typeof v, String(v)); return }
    assert(typeof v === 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) {
        parts.push('["Map",[')
        let first = true
        for (const [k, x] of v) { if (!first) parts.push(','); first = false; parts.push('['); visit(k); parts.push(','); visit(x); parts.push(']') }
        parts.push(']]'); return
      }
      if (v instanceof Set) {
        parts.push('["Set",[')
        let first = true
        for (const x of v) { if (!first) parts.push(','); first = false; visit(x) }
        parts.push(']]'); return
      }
      if (v instanceof Date) { tag('Date', v.toISOString()); return }
      if (ArrayBuffer.isView(v)) { tag(v.constructor.name, Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64')); return }
      if (v instanceof ArrayBuffer) { tag('ArrayBuffer', Buffer.from(v).toString('base64')); return }
      if (Array.isArray(v)) {
        const length = v.length
        parts.push('["Array",[')
        for (let i = 0; i < length; i++) { if (i) parts.push(','); if (i in v) visit(v[i]); else tag('hole') }
        parts.push(']]'); return
      }
      const proto: unknown = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      const record = v as Record<string, unknown>
      parts.push(proto === null ? '["null-object",[' : '["object",[')
      let first = true
      for (const key of Object.keys(record).sort()) { if (!first) parts.push(','); first = false; parts.push('[', JSON.stringify(key), ','); visit(record[key]); parts.push(']') }
      parts.push(']]')
    } finally { ancestors.delete(v) }
  }
  visit(value)
  return parts.join('')
}
