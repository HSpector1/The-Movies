from pathlib import Path
import hashlib,json,os,re
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program')
P=S/'1368-ledger-r5-profile-proposal-20261005-r1';RUNS=S/'1368-ledger-recorded-runs-r5-profile-r1';OUT=RUNS/'ABC-observed-p13a-r1';E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919';STEM='1368-ledger-r5-profile-r1-abc-observed-p13a-r1'
MT='55c993b5f350e5133603aa13c224fa2c62d2304924ade0d075f62cb0c2a4260a';SELF='74ae1b3a965bd1b6034f055d714b066faf8868535d65187638d98ddeb1d5ad47'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
assert sha(P/'MANIFEST.json')==MT and sha(P/'runner/run.py')==SELF
m=read(P/'MANIFEST.json');assert len(m['files'])==218
for name,row in m['files'].items():
 f=P/name;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
b=read(OUT/'binding.json');r=read(OUT/'RESULT.json')
assert (b['arm'],b['mode'],b['seed'],b['horizon'])==('ABC','observed','p13a-core-causal-01',416)
assert b['manifestPin']==MT and b['selfRunnerSha256']==SELF and b['outerCapSeconds']==330 and b['probeTestSeconds']==300
assert b['profilePath']==str(OUT/'profile.jsonl') and b['typesReceipt']==str(RUNS/'ABC-types-source-r1/RESULT.json') and b['cleanReceipt']==str(RUNS/'ABC-clean-p13a-r1/RESULT.json')
assert b['typesReceiptSha256']==sha(RUNS/'ABC-types-source-r1/RESULT.json')=='fa9724bf0742ce21b284ed479ef3816a267f098d2881a29407c9f1228c5ff1f2'
assert b['cleanReceiptSha256']==sha(RUNS/'ABC-clean-p13a-r1/RESULT.json')=='64c942ae10bd4648ee2269a4453980fb0ea77f8e75e289d00874c15aae5225a6'
assert r['pins']==b['pins'] and r['pins']['runnerManifestSha256']==MT and r['pins']['selfRunnerSha256']==SELF
assert r['pins']['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and r['pins']['assemblySha256']==sha(P/'arm/ASSEMBLY.json')
assert (r['arm'],r['mode'],r['seed'])==('ABC','observed','p13a-core-causal-01')
assert r['allGuardsExact'] and r['livePostflightExact'] and r['reportingErrors']==[]
g=r['processGroup'];assert all(g[k] for k in ['cleanupVerified','noSurvivors','leaderReaped']) and not g['errors']
for name,row in r['artifacts'].items():
 f=Path(name);assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],name
pre=read(E/(STEM+'-preflight.json'));record=read(E/(STEM+'.json'));post=read(E/(STEM+'-postflight.json'))
head=r['pins']['publicationHead'];assert pre['head']==record['sourceSha']==record['sourceShaAtEnd']==post['head']==head
assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
assert record['command']==[record['command'][0],str(P/'runner/run.py'),'--child',str(OUT),sha(OUT/'binding.json')]
assert record['exitCode']==post['exitCode']==r['recorderChildExit']
assert read(OUT/'CHILD.json')['actualChildExit']==r['actualChildExit']
meta=(S/'heavy-queue/1368-ledger-r5-profile-observed-p13a-r1.log.meta').read_text()
assert re.search(r'end, exit \d+;',meta),meta
wrapper_exit=int(re.search(r'end, exit (\d+);',meta).group(1));assert wrapper_exit==r['recorderChildExit']
status=r['profileStatus'];f=OUT/'profile.jsonl';assert status['expected'] and status['present']==f.is_file() and status['sha256']==sha(f) and status['parseError'] is None
profile=[json.loads(line) for line in f.read_text().splitlines()]
assert status['rows']==[row['week'] for row in profile]
progress=[json.loads(line) for line in (OUT/'progress.jsonl').read_text().splitlines()]
assert [row['week'] for row in profile]==[row['week'] for row in progress]==list(range(52,52*len(profile)+1,52))
names=['snap','admit','owners','windowFacts','changedCases'];prev={n:(0,0,0) for n in names};windows=[];last_elapsed=0
for row,prog in zip(profile,progress):
 week=row['week'];assert set(row)=={'week','elapsedSeconds','functions'} and set(row['functions'])==set(names)
 assert row['elapsedSeconds']>=prog['elapsedSeconds']>=last_elapsed
 elapsed_delta=row['elapsedSeconds']-last_elapsed;last_elapsed=row['elapsedSeconds'];deltas={}
 for n in names:
  v=row['functions'][n];assert set(v)=={'calls','inclusiveNs','exclusiveNs'} and type(v['calls'])==int
  assert isinstance(v['inclusiveNs'],str) and v['inclusiveNs'].isdigit() and isinstance(v['exclusiveNs'],str) and v['exclusiveNs'].isdigit()
  cur=(v['calls'],int(v['inclusiveNs']),int(v['exclusiveNs']));assert cur[1]>=cur[2]>=0 and all(a>=b for a,b in zip(cur,prev[n]))
  deltas[n]={'calls':cur[0]-prev[n][0],'inclusiveSeconds':(cur[1]-prev[n][1])/1e9,'exclusiveSeconds':(cur[2]-prev[n][2])/1e9};prev[n]=cur
 assert {n:row['functions'][n]['calls'] for n in ['admit','owners','windowFacts','changedCases']}=={'admit':week+1,'owners':4*week,'windowFacts':week,'changedCases':2*week}
 windows.append({'throughWeek':week,'elapsedSeconds':row['elapsedSeconds'],'intervalWallSeconds':elapsed_delta,'functions':deltas,'measuredExclusiveSeconds':sum(x['exclusiveSeconds'] for x in deltas.values())})
if r['timedOut']:
 assert r['recorderChildExit']==wrapper_exit==124 and r['actualChildExit'] is not None and r['actualChildExit']!=0
 assert not (OUT/'data.json').exists(), 'completed data unexpectedly exists on timeout'
else:
 assert r['actualChildExit']==r['recorderChildExit']==wrapper_exit==0
 assert len(profile)==8 and (OUT/'data.json').is_file()
report={'decision':'ACCEPT' if r['timedOut'] or r['actualChildExit']==0 else 'REFINE','resultSha256':sha(OUT/'RESULT.json'),'formalRecordSha256':sha(E/(STEM+'.json')),'formalPostflightSha256':sha(E/(STEM+'-postflight.json')),'wrapperExit':wrapper_exit,'actualChildExit':r['actualChildExit'],'recorderChildExit':r['recorderChildExit'],'timedOut':r['timedOut'],'formalAndCleanupExact':True,'artifactsVerified':len(r['artifacts']),'profileSha256':sha(f),'profileRows':[x['week'] for x in profile],'progressRows':[x['week'] for x in progress],'windows':windows,'dataPresent':(OUT/'data.json').exists(),'vitestPresent':(OUT/'vitest.json').exists(),'completionClaim':bool(not r['timedOut'] and r['actualChildExit']==0 and (OUT/'data.json').exists())}
out=Path(__file__).with_name('RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='windows'},indent=2))
