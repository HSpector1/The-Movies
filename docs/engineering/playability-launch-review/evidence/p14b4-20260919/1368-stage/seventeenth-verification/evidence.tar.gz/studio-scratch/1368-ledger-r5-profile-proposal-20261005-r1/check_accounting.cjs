const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const ts = require('/Users/zacheryspector/studio-scratch/1368-ledger-r5-profile-proposal-20261005-r1/arm/tree/node_modules/typescript')
const path = '/Users/zacheryspector/studio-scratch/1368-ledger-r5-profile-proposal-20261005-r1/arm/tree/tests/1368-ledger-attribution.test.ts'
const source = fs.readFileSync(path, 'utf8')
const block = source.slice(source.indexOf('type ProfileName ='), source.indexOf('function rawSnap('))
const js = ts.transpileModule(block + '\nexports.measured = measured; exports.profileRow = profileRow; exports.profileTotals = profileTotals; exports.profileStack = profileStack', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText
let clock = 0n
const context = { exports: {}, assert, Object, String, process: { hrtime: { bigint: () => ++clock } } }
vm.runInNewContext(js, context)
const { measured, profileRow, profileTotals, profileStack } = context.exports
assert.equal(measured('owners', () => measured('snap', () => 7)), 7)
assert.equal(profileTotals.owners.calls, 1)
assert.equal(profileTotals.snap.calls, 1)
assert.equal(profileTotals.owners.inclusiveNs, 3n)
assert.equal(profileTotals.snap.inclusiveNs, 1n)
assert.equal(profileTotals.owners.exclusiveNs, 2n)
assert.equal(profileTotals.snap.exclusiveNs, 1n)
assert.throws(() => measured('admit', () => { throw new Error('sentinel') }), /sentinel/)
assert.equal(profileTotals.admit.calls, 1)
assert.equal(profileStack.length, 0)
const row = profileRow(52, 0n)
assert.equal(row.week, 52)
assert.equal(row.functions.owners.calls, 1)
assert.equal(row.functions.owners.inclusiveNs, '3')
assert.equal(row.functions.owners.exclusiveNs, '2')
console.log(JSON.stringify({ nestedInclusiveExclusiveExact: true, exceptionRethrown: true, stackEmpty: true, checkpointShapeExact: true }))
