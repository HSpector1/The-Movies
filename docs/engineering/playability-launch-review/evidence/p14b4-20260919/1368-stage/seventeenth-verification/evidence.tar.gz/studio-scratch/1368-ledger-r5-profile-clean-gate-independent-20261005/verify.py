from pathlib import Path
import hashlib,json,os
S=Path('/Users/zacheryspector/studio-scratch');R=Path('/Users/zacheryspector/The-Movies-headless-program')
P=S/'1368-ledger-r5-profile-proposal-20261005-r1';B=S/'1368-ledger-arms-04/ABC';RUNS=S/'1368-ledger-recorded-runs-r5-profile-r1';E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest_pin='55c993b5f350e5133603aa13c224fa2c62d2304924ade0d075f62cb0c2a4260a';runner_pin='74ae1b3a965bd1b6034f055d714b066faf8868535d65187638d98ddeb1d5ad47'
assert sha(P/'MANIFEST.json')==manifest_pin and sha(P/'runner/run.py')==runner_pin
manifest=read(P/'MANIFEST.json');assert len(manifest['files'])==218
for n,row in manifest['files'].items():
 f=P/n;assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],n
source=read(P/'arm/SOURCE-PINS.json');base=read(B/'SOURCE-PINS.json')
assert len(source)==len(base)==197
assert {n for n in source if source[n]!=base[n]}=={'tests/1368-ledger-attribution.test.ts'}
assert all(source[n]==base[n] for n in source if n.startswith('src/'))
assert all(sha(P/'arm/tree'/n)==source[n] for n in source)
assert manifest['runnerSha256']==runner_pin and manifest['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and manifest['assemblySha256']==sha(P/'arm/ASSEMBLY.json')
results={};bindings={};profiles={};datas={}
for mode,leaf in [('types','ABC-types-source-r1'),('clean','ABC-clean-p13a-r1')]:
 out=RUNS/leaf; rp=out/'RESULT.json';result=read(rp);binding=read(out/'binding.json');results[mode]=result;bindings[mode]=binding
 assert result['mode']==mode and result['arm']=='ABC' and result['seed']==(None if mode=='types' else 'p13a-core-causal-01')
 assert result['actualChildExit']==result['recorderChildExit']==0 and result['timedOut'] is False and result['allGuardsExact'] and result['livePostflightExact'] and result['reportingErrors']==[]
 group=result['processGroup'];assert group['cleanupVerified'] and group['noSurvivors'] and group['leaderReaped'] and not group['errors']
 assert result['pins']['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and result['pins']['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and result['pins']['runnerManifestSha256']==manifest_pin and result['pins']['selfRunnerSha256']==runner_pin
 assert result['pins']==binding['pins'] and binding['manifestPin']==manifest_pin and binding['selfRunnerSha256']==runner_pin and binding['mode']==mode and binding['arm']=='ABC'
 assert binding['outerCapSeconds']==330 and binding['probeTestSeconds']==300 and binding['horizon']==416
 assert len(result['artifacts'])==(11 if mode=='types' else 15)
 for n,row in result['artifacts'].items():
  f=Path(n);assert f.is_file() and not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],n
 stem='1368-ledger-r5-profile-r1-abc-'+('types-source' if mode=='types' else 'clean-p13a')+'-r1'
 pre=read(E/(stem+'-preflight.json'));record=read(E/(stem+'.json'));post=read(E/(stem+'-postflight.json'))
 head=result['pins']['publicationHead']
 assert pre['head']==record['sourceSha']==record['sourceShaAtEnd']==post['head']==head and record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
 assert record['exitCode']==post['exitCode']==0 and record['command']==[record['command'][0],str(P/'runner/run.py'),'--child',str(out),sha(out/'binding.json')]
 assert (out/'CHILD.json').is_file() and read(out/'CHILD.json')['actualChildExit']==0
 if mode=='types':
  assert result['profileStatus']=={'expected':False,'present':False,'sha256':None,'rows':None,'parseError':None}
  assert binding['profilePath'] is None and not (out/'profile.jsonl').exists()
 else:
  assert binding['profilePath']==str(out/'profile.jsonl')
  data=read(out/'data.json');datas[mode]=data
  assert data['completed'] and data['sourcePostflight'] and (data['arm'],data['mode'],data['seed'],data['horizon'])==('ABC','clean','p13a-core-causal-01',416)
  assert len(data['weekly'])==416 and [r['week'] for r in data['weekly']]==list(range(1,417))
  progress=[json.loads(line) for line in (out/'progress.jsonl').read_text().splitlines()]
  profile=[json.loads(line) for line in (out/'profile.jsonl').read_text().splitlines()];profiles[mode]=profile
  checkpoints=list(range(52,417,52));assert [r['week'] for r in progress]==[r['week'] for r in profile]==checkpoints
  assert result['profileStatus']=={'expected':True,'present':True,'sha256':sha(out/'profile.jsonl'),'rows':checkpoints,'parseError':None}
  names={'snap','admit','owners','windowFacts','changedCases'}
  previous={n:(-1,-1,-1) for n in names}
  for pr,pf in zip(progress,profile):
   assert set(pf)=={'week','elapsedSeconds','functions'} and pf['elapsedSeconds']>=pr['elapsedSeconds']>=0 and set(pf['functions'])==names
   for n,v in pf['functions'].items():
    assert set(v)=={'calls','inclusiveNs','exclusiveNs'} and type(v['calls'])==int and v['calls']>=0
    assert all(isinstance(v[k],str) and v[k].isdigit() for k in ['inclusiveNs','exclusiveNs'])
    curr=(v['calls'],int(v['inclusiveNs']),int(v['exclusiveNs']))
    assert curr[1]>=curr[2]>=0 and all(a>=b for a,b in zip(curr,previous[n]));previous[n]=curr
  final=profile[-1]['functions'];assert {n:final[n]['calls'] for n in ['admit','owners','windowFacts','changedCases']}=={'admit':417,'owners':416,'windowFacts':0,'changedCases':416}
  vitest=read(out/'vitest.json');assert vitest['numTotalTests']==vitest['numPassedTests']==1 and vitest['numFailedTests']==0
assert bindings['clean']['typesReceipt']==str(RUNS/'ABC-types-source-r1/RESULT.json') and bindings['clean']['typesReceiptSha256']==sha(RUNS/'ABC-types-source-r1/RESULT.json')
for key in ['arm','sourcePinsSha256','assemblySha256','kitManifestSha256','inputPinsSha256','runnerManifestSha256','selfRunnerSha256','entrypoints','regularFiles']:
 assert results['types']['pins'][key]==results['clean']['pins'][key],key
old=read(S/'1368-ledger-recorded-runs-r4-lowspace-r2/ABC-clean-p13a-r1/data.json');new=datas['clean']
assert set(old)==set(new)
diff=[k for k in old if old[k]!=new[k]]
assert diff==[],diff
assert sha(S/'1368-ledger-recorded-runs-r4-lowspace-r2/ABC-clean-p13a-r1/data.json')==sha(RUNS/'ABC-clean-p13a-r1/data.json')
report={'decision':'ACCEPT','packageManifestSha256':manifest_pin,'packageMembersVerified':218,'typesResultSha256':sha(RUNS/'ABC-types-source-r1/RESULT.json'),'cleanResultSha256':sha(RUNS/'ABC-clean-p13a-r1/RESULT.json'),'formalExact':True,'artifactsVerified':{m:len(results[m]['artifacts']) for m in results},'typesCleanPinsLinked':True,'r4CleanAllOutputFieldsEqual':sorted(old),'dataJsonByteExactSha256':sha(RUNS/'ABC-clean-p13a-r1/data.json'),'probeSourceHashDifference':'tests/1368-ledger-attribution.test.ts only, outside data.json; data.sourcePins retains original 189 frozen input pins','weeks':416,'progressRows':8,'profileRows':8,'observedDiagnosticGate':'ACCEPT subject to fresh live/remote/lane/disk guards; no run authorized by this receipt'}
out=Path(__file__).with_name('RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
