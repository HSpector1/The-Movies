// ── P14B.1 — The First Kept Promise Core ─────────────────────────────────────
//
// A PURE module (like talentMarket/employment): no React/DOM/async/IO, no time,
// no unseeded entropy, NO RNG AT ALL. Every function here is a deterministic,
// replayable read or write over committed state, so `state.rngState` is
// untouched by every promise path (companion §4.3: "deterministic, consumes no
// RNG, reads only committed state").
//
// Authority: docs/engineering/playability-launch-review/plans/P14-HEADLESS-PLAN.md
// ("P14B.1 — First Kept Promise Core — task expansion"), and by reference
// docs/engineering/p14-preparation-8ef5246a/P14-PREPARATION-COMPANION.md §4.1
// (what a promise is), §4.2 (the five families and the qualifying event), §4.3
// (the feasibility service), §4.4 (outcomes) and §4.5 (trust).
//
// WHAT THIS MODULE DOES NOT OWN (never duplicated here): P10 the person, the
// contract and its price; P12 studio identity and the employer intervals; P14A
// the case, the proposal, reservation, ranking and settlement (`talentMarket.ts`
// calls in); the production lifecycle (`operations.ts` raises the first take,
// this module only records and reads it).
//
// WHERE THE TWO NEW ROOTS LIVE. `state.firstTakes` and `state.promises` are
// GAME-STATE roots, beside `talentMarket`, not inside it: the first take is a
// production-lifecycle fact that the market merely reads, and a promise outlives
// the case it was attached to (it is carried by the contract, evaluated for
// years, and read by trust long after the proposal is gone). The plan's phrase
// "the root's new firstTakes" is read as the SAVE root; the V29 save step lifts
// both, and `migrateToV28` refuses to discard either.

import { fnv1a64 } from './math.js'
import { assignmentRefusal, retirementRecordFor } from './careerLifecycle.js'
import { occupiedResourceSlots } from './occupancy.js'
import { productionCompanyTalentIds } from './productionPeople.js'
import { openMarketCaseFor } from './talentMarket.js'
import { TUNING } from './tuning.js'
import { shelvedScriptIds } from './hollywoodTypes.js'
import { subjectForNewTake, takeSubjectOwner, validateFirstTakeSubjects } from './firstTakeSubjects.js'
import { isOpportunityPredicate, opportunitySlots, opportunityPredicateRefusal, opportunitySubjectMatches,
  opportunityProductionMatches, opportunityReservations, opportunityFeasibilityInputs, opportunityAssessment,
  opportunityPhysicalImpossibility, OPPORTUNITY_PROMISE_RULES_VERSION } from './opportunityPromises.js'
import type {
  CastRoleCountPredicate, DirectorCountPredicate, OpportunityPredicate, Genre, CastSlot, FirstTakeReceipt, GameState, GameStateV30, GameStateV40, ProfessionalPromise, ProfessionalPromiseV30, Production,
  PromiseClassification, PromiseFamily, PromiseFeasibilityReceipt, TalentMarketStateV36,
} from './types.js'

const CAST_SLOTS: readonly CastSlot[] = ['lead', 'antagonist', 'support'] as const

/** The evaluator revision stamped on newly evaluated receipts and newly minted
 * roots. 4 = P14B.4 (record 600, D1 (a)): class-restricted fixed-seat paths for
 * tagged P2 plus shared residual capacity (`reserved + X` against the spare-event
 * buffer) on the count-family scalar, applied to fresh P1 and tagged P2 alike.
 * The bounded joint certificate and UNCERTIFIED -> FRAGILE are a later evaluator
 * revision (5). Stored root versions and old receipts are never rewritten. */
export const PROMISE_RULES_VERSION = 4
/** Explicit Director scope; the separate joint-certificate revision5 stays reserved. */
export const DIRECTING_PROMISE_RULES_VERSION = 6

type ReadablePromise = ProfessionalPromiseV30 | ProfessionalPromise
const isDirectorPredicate = (predicate: PromisePredicate): predicate is DirectorCountPredicate =>
  'kind' in predicate && predicate.kind === 'directorCount'
const isDirectorPromise = (promise: Pick<ReadablePromise, 'family' | 'predicate'>): boolean =>
  promise.family === 'DIRECTING_COUNT' && isDirectorPredicate(promise.predicate)

// ── the named HYPOTHESES (plan's OPEN section; none of these is settled law) ──

/** On schedule the first take completes in the FIFTH week after greenlight
 * (companion §4.3.1: the fixed eight-week countdown; verified against
 * `advanceManagedProductions`, whose first advance is skipped for a production
 * greenlit this week and whose 5 → 4 branch is therefore the fifth week). */
export const WEEKS_TO_FIRST_TAKE = 5

/** HYPOTHESIS: a person holds exactly ONE seat per production and is reserved
 * from greenlight through release (companion §4.3.1), so their qualifying events
 * are counted SEQUENTIALLY, one per production cycle. */
const SEAT_CYCLE_WEEKS = TUNING.PRODUCTION_TICKS

/** HYPOTHESIS (companion §4.3.2): the X-th event's expected first-take week must
 * leave at least this many weeks before the due week. */
export const PROMISE_SLACK_WEEKS = 8

/** HYPOTHESIS (companion §4.3.2): the count-family spare-event buffer — one
 * event, or 25% of `N_max` rounded up, whichever is larger. */
export function promiseBuffer(nMax: number): number {
  return Math.max(1, Math.ceil(0.25 * nMax))
}

/** HYPOTHESIS (companion §4.5): drivers older than this leave the current tier
 * but stay in history. */
export const TRUST_HORIZON_WEEKS = 260

/** HYPOTHESIS (companion §4.5): the two descriptor edges. `Reliable` needs a real
 * positive driver and NO negative one; `Distrusted` needs at least two negative
 * drivers that also outweigh the positives, so one firing inside a long, honoured
 * relationship is a Mixed record rather than a ruined one. */
const TRUST_DISTRUST_MIN_NEGATIVES = 2

// ── the two roots ────────────────────────────────────────────────────────────

/**
 * LOUD, never silent: a live state MUST carry the V29 roots. Treating a missing
 * root as "no promises" would let a state one save version behind run live verbs
 * and quietly record nothing — exactly the fault `advanceTalentMarketWeek` refuses
 * for the V28 market root, refused here the same way.
 */
function requirePromiseRoots(state: GameState): void {
  if (state.promises === undefined || state.firstTakes === undefined) {
    throw new Error('promises: the Save V29 roots are missing — migrate this state to V29 before acting on it')
  }
}

/** Every first take this world has recorded, in append order. */
export function firstTakeReceipts(state: Pick<GameState, 'firstTakes'>): readonly FirstTakeReceipt[] {
  return state.firstTakes
}

/** Every promise this world holds, open or terminal. */
export function allPromises(state: Pick<GameState, 'promises'>): readonly ProfessionalPromise[] {
  return state.promises
}

/** §4.4: the promises that have reached a TERMINAL outcome. */
export function promiseOutcomes(state: Pick<GameState, 'promises'>): readonly ProfessionalPromise[] {
  return state.promises.filter((p) => p.outcome !== null)
}

/**
 * The qualifying-event receipt, appended at the 5 → 4 advance for BOTH
 * `advanceManagedProductions` callers. IDEMPOTENT BY productionId: a production
 * records exactly one first take for its life, so re-entering the branch (or
 * replaying a tick) can never double-count a promise.
 *
 * ENGAGEMENT, exactly the market's own rule: no industry root means no studio
 * identity a receipt could name and no case, proposal or promise this world could
 * ever hold, so the headless M0A corpus and the roster-wall observatory stay
 * byte-identical apart from the empty V29 root itself.
 */
export function appendFirstTakes(
  state: GameState,
  entries: readonly { studioId: string; production: Production }[],
  week: number,
): GameState {
  if (entries.length === 0) return state
  requirePromiseRoots(state)
  if (state.hollywood === null) return state
  const takes = [...state.firstTakes]
  if (state.firstTakeSubjects === undefined) throw new Error('promises: migrate to Save40 before recording a first take')
  const subjects = [...state.firstTakeSubjects.facts]
  const seen = new Set(takes.map((t) => t.productionId))
  for (const { studioId, production } of entries) {
    if (seen.has(production.id)) continue
    seen.add(production.id)
    subjects.push(subjectForNewTake(state, studioId, production, `first-take-event-${String(takes.length)}`))
    takes.push({
      eventId: `first-take-event-${String(takes.length)}`,
      week,
      productionId: production.id,
      studioId,
      directorId: production.directorId,
      cast: { lead: production.cast.lead, antagonist: production.cast.antagonist, support: production.cast.support },
    })
  }
  return takes.length === state.firstTakes.length ? state : {
    ...state, firstTakes: takes, firstTakeSubjects: { ...state.firstTakeSubjects, facts: subjects },
  }
}

// ── the proposal digest (P14B.1 (3): the promise is a MATERIAL term) ─────────

/** One promise's own material definition, digested. A drifted predicate, window
 * or family mints a different value, which is what makes a drifted promise drop
 * `materialTermsChanged` at freeze. */
export function promiseDigest(promise: ReadablePromise): string {
  const material: readonly unknown[] = [promise.family, promise.predicate.count, promise.windowStartWeek, promise.dueWeekExclusive]
  // Preserve the exact historical tuple for every count-only family. The tag
  // and selected class are additional material, never inferred from a version.
  if (isDirectorPredicate(promise.predicate)) return fnv1a64(JSON.stringify([...material, promise.predicate.kind]))
  if (isOpportunityPredicate(promise.predicate)) return fnv1a64(JSON.stringify([...material, promise.predicate.kind,
    promise.predicate.seatClass, promise.predicate.kind === 'genreOpportunity' ? promise.predicate.genre : promise.predicate.scriptProjectId]))
  return fnv1a64(JSON.stringify('kind' in promise.predicate
    ? [...material, promise.predicate.kind, promise.predicate.seatClass]
    : material))
}

/** The digest of whatever promises a proposal currently carries, resolved LIVE
 * against the promise root. `''` — the empty string — is the no-promise value and
 * is BYTE-PRESERVING: a proposal with no promise digests exactly as it did under
 * V28, so every migrated proposal re-derives its stored digest unchanged. */
export function attachedPromiseDigest(
  state: { promises: readonly ReadablePromise[] },
  promiseIds: readonly string[],
): string {
  if (promiseIds.length === 0) return ''
  return fnv1a64(JSON.stringify(promiseIds.map((id) => {
    const promise = state.promises.find((p) => p.promiseId === id)
    return promise === undefined ? `missing:${id}` : promiseDigest(promise)
  })))
}

/** The ONE proposal-digest formula (companion §2.1.4, widened by P14B.1 (3)).
 * Material terms only; price is derived and never material. */
export function proposalDigest(
  talentId: string,
  issuerStudioId: string,
  termWeeks: number,
  startWeek: number,
  premiumTier: number,
  promisePart: string,
): string {
  const material: readonly unknown[] = promisePart === ''
    ? [talentId, issuerStudioId, termWeeks, startWeek, premiumTier]
    : [talentId, issuerStudioId, termWeeks, startWeek, premiumTier, promisePart]
  return fnv1a64(JSON.stringify(material))
}

// ── §4.3 the feasibility service ─────────────────────────────────────────────

/** The material predicate: count-only for every family, or the explicitly
 * selected P2 seat class. The class is never inferred from a version. */
export type PromisePredicate = { count: number } | CastRoleCountPredicate | DirectorCountPredicate | OpportunityPredicate

export type PromiseDraft = {
  family: PromiseFamily
  issuerStudioId: string
  beneficiaryPersonId: string
  predicate: PromisePredicate
  windowStartWeek: number
  dueWeekExclusive: number
  /** The PROPOSED CONTRACT interval the window must lie inside. */
  startWeek: number
  termWeeks: number
  /** Set when an ALREADY-MINTED promise is re-classified, so the service does not
   * count the promise against itself as an active seat reservation. */
  promiseId?: string
}

// P14B.4 (record 600): the P2 line left this map; a seat-class promise is offered
// exactly when its class is explicitly selected (see `promiseFeasibility`).
const NOT_OFFERED_IN_B1: Partial<Record<PromiseFamily, string>> = {
  PREFERRED_GENRE_OPPORTUNITY: 'a genre promise is not offered in this slice',
  SPECIFIC_PROJECT: 'a named-project promise is not offered in this slice',
}

/** Input identity follows saved values, not object insertion order. Casts,
 * workflows and reservations can arrive directly from play or from the sorted
 * save format (952/957). Keep array order and native JSON scalar/omission rules;
 * only newly evaluated receipts use this, never stored historical receipts. */
function serializeFeasibilityInputs(inputs: readonly unknown[]): string {
  return JSON.stringify(inputs, (_key, value: unknown) => {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) return value
    const fields = value as Record<string, unknown>
    return Object.fromEntries(Object.keys(fields).sort().map(key => [key, fields[key]]))
  })
}

function receipt(
  classification: PromiseClassification,
  bottleneck: string | null,
  inputs: readonly unknown[],
  week: number,
  rulesVersion = PROMISE_RULES_VERSION,
): PromiseFeasibilityReceipt {
  return { classification, bottleneck, inputsDigest: fnv1a64(serializeFeasibilityInputs(inputs)), rulesVersion, week }
}

/** The studio's live pictures, whichever owner holds them. */
function studioProductions(state: GameState, studioId: string): readonly Production[] {
  if (state.hollywood !== null && studioId !== state.hollywood.playerStudioId) {
    return state.hollywood.businesses.find((b) => b.studioId === studioId)?.productions ?? []
  }
  return state.studio.activeProductions
}

/** The studio's committed, not-yet-produced screenplays — each one a picture that
 * ALREADY EXISTS and needs no new commission (companion §4.3.2's existing-path
 * test; Example A's "one script ready … one script drafting"). */
function unproducedScripts(state: GameState, studioId: string, directingScope = false): number {
  const development = state.hollywood !== null && studioId !== state.hollywood.playerStudioId
    ? state.hollywood.businesses.find((b) => b.studioId === studioId)?.development
    : state.scriptDevelopment
  if (development === undefined || development.mode !== 'managed') return 0
  // P14D.1: a shelved rival screenplay is not a picture the studio is making.
  const shelved = shelvedScriptIds(state.hollywood, studioId)
  // A linked script is the running picture, not another future picture. Its
  // actual qualifying seat is counted separately until that picture's take.
  return development.projects.filter((p) => p.status !== 'produced' && !shelved.has(p.id)
    && (!directingScope || p.productionId === null)).length
}

/**
 * Can this studio start ONE more picture right now out of stock, with no
 * commission at all? In the accepted runtime the plain `greenlight` door takes an
 * UNUSED CONCEPT plus contracted people directly, so a concept the studio already
 * holds IS an existing-pipeline path — bounded at one because the beneficiary can
 * occupy only one seat at a time, so a second stock picture would be a future
 * commitment the studio has not made (that is exactly "a picture not yet
 * commissioned"). Rivals commission before they greenlight and hold no such stock
 * door, so this term is the player's alone.
 */
function stockGreenlightAvailable(state: GameState, studioId: string, directingScope = false): boolean {
  if (directingScope && state.scriptDevelopment.mode === 'managed') return false
  if (state.hollywood !== null && studioId !== state.hollywood.playerStudioId) return false
  const used = new Set<string>()
  for (const p of state.studio.activeProductions) used.add(p.conceptId)
  for (const f of state.studio.releasedFilms) used.add(f.conceptId)
  if (state.scriptDevelopment.mode === 'managed') for (const p of state.scriptDevelopment.projects) used.add(p.conceptId)
  if (!state.concepts.some((c) => !used.has(c.id))) return false
  const stages = state.operations.facilities.filter((f) => f.capability === 'soundstage').length
  return state.studio.activeProductions.length < stages
}

/** This person's seat on an ALREADY-STARTED picture of this studio whose first
 * take is still ahead — the one path that needs no greenlight either. Only a seat
 * inside the promise's class mask counts (record 600): a fixed seat outside the
 * mask is not an event. A recorded first take means no NEW event from that picture. */
function seatedPreFirstTake(
  state: GameState,
  studioId: string,
  personId: string,
  slots: readonly CastSlot[],
  director = false,
): readonly Production[] {
  const recorded = new Set(state.firstTakes.map((t) => t.productionId))
  return studioProductions(state, studioId).filter(
    (p) => !recorded.has(p.id) && (director
      ? p.remainingTicks >= 5 && p.directorId === personId
      : slots.some((slot) => p.cast[slot] === personId)),
  )
}

type PromiseProductionOccupancy = { studioId: string; production: Production }

/** Revision6 cannot start fresh work while this person holds another production
 * seat. An actual qualifying seat keeps its own first-take clock; a credited
 * writer alone holds no seat. Read every owner so changing issuer cannot make
 * an existing assignment disappear. These are earliest release bounds, not a
 * certificate that resource holds will clear. */
function promiseProductionOccupancy(state: GameState, draft: PromiseDraft): readonly PromiseProductionOccupancy[] {
  const qualifying = new Set(committedPromiseSeats(state, draft))
  const playerStudioId = state.hollywood?.playerStudioId ?? draft.issuerStudioId
  const owners = [{ studioId: playerStudioId, productions: state.studio.activeProductions },
    ...(state.hollywood?.businesses.filter(business => business.studioId !== playerStudioId)
      .map(business => ({ studioId: business.studioId, productions: business.productions })) ?? [])]
  return owners.flatMap(owner => owner.productions
    .filter(production => !qualifying.has(production)
      && productionCompanyTalentIds([production]).has(draft.beneficiaryPersonId))
    .map(production => ({ studioId: owner.studioId, production })))
}

/** Companion §4.3.1's "already-active promises … seats those promises reserve
 * inside the same window". Bound commitments and CURRENT attached drafts reserve;
 * abandoned unbound roots remain history without claiming a future seat. Both the
 * arithmetic and its receipt digest consume this ONE membership rule. Competing
 * current issuers still count under the existing policy; none is optimized away. */
function activePromiseReservations(state: GameState, draft: PromiseDraft, from: number): readonly ProfessionalPromise[] {
  const attached = new Set(state.talentMarket.proposals.flatMap((proposal) => proposal.promises))
  return state.promises.filter((promise) =>
    promise.outcome === null
    && (promise.contractId !== null || attached.has(promise.promiseId))
    && promise.promiseId !== draft.promiseId
    && promise.beneficiaryPersonId === draft.beneficiaryPersonId
    && promise.dueWeekExclusive > from
    && promise.windowStartWeek < draft.dueWeekExclusive)
}

/** Membership is determined before the person/issuer union. Retained abandoned
 * and terminal rows are history, and an own-ID reclassification reserves no self. */
function directingScopeReservations(state: GameState, draft: PromiseDraft, from: number): readonly ProfessionalPromise[] | undefined {
  const attached = new Set(state.talentMarket.proposals.flatMap(proposal => proposal.promises))
  const selected = new Map<string, ProfessionalPromise>()
  for (const promise of state.promises) {
    if (promise.outcome !== null || (promise.contractId === null && !attached.has(promise.promiseId))
      || promise.promiseId === draft.promiseId || promise.dueWeekExclusive <= from
      || promise.windowStartWeek >= draft.dueWeekExclusive
      || (promise.beneficiaryPersonId !== draft.beneficiaryPersonId && promise.issuerStudioId !== draft.issuerStudioId)) continue
    if (!selected.has(promise.promiseId)) selected.set(promise.promiseId, promise)
  }
  const rows = [...selected.values()]
  return isDirectorPredicate(draft.predicate) || rows.some(isDirectorPromise) ? rows : undefined
}

function reservedByActivePromises(state: GameState, draft: PromiseDraft, from: number): number {
  return activePromiseReservations(state, draft, from)
    .reduce((reserved, promise) => reserved + Math.max(0, promise.predicate.count - promise.progress), 0)
}

/** The receipt identifies the committed inputs, not just the requested terms.
 * Keep this bounded to current pipeline/availability facts from their owners:
 * no account balances, RNG, outcome history or whole-campaign serialization. */
function feasibilityInputs(state: GameState, draft: PromiseDraft, week: number,
  directingReservations?: readonly ProfessionalPromise[],
  productionOccupancy: readonly PromiseProductionOccupancy[] = []): readonly unknown[] {
  const directingScope = directingReservations !== undefined
  const requestedRole = isDirectorPredicate(draft.predicate) ? 'director' : 'actor'
  const rival = state.hollywood !== null && draft.issuerStudioId !== state.hollywood.playerStudioId
  const business = rival ? state.hollywood?.businesses.find((b) => b.studioId === draft.issuerStudioId) : undefined
  const productions = studioProductions(state, draft.issuerStudioId)
  const productionIds = new Set(productions.map((p) => p.id))
  const operations = rival ? business?.operations : state.operations
  const development = rival ? business?.development : state.scriptDevelopment
  const occupancy = occupiedResourceSlots(rival
    ? business === undefined ? {} : { operations: business.operations, scriptDevelopment: business.development }
    : state)
  const from = Math.max(draft.windowStartWeek, week)
  const person = state.talent.find((t) => t.id === draft.beneficiaryPersonId)
  const retirement = retirementRecordFor(state, draft.beneficiaryPersonId)
  const shelved = shelvedScriptIds(state.hollywood, draft.issuerStudioId)
  const actingRetirement = retirementRecordFor(state, draft.beneficiaryPersonId, requestedRole)
  return [
    draft.family, draft.issuerStudioId, draft.beneficiaryPersonId, draft.predicate.count,
    draft.windowStartWeek, draft.dueWeekExclusive, draft.startWeek, draft.termWeeks, week,
    person === undefined ? null : person.skills[requestedRole === 'director' ? 'directing' : 'acting'] !== undefined,
    productions.map((p) => [p.id, p.conceptId, p.startTick, p.remainingTicks, p.directorId, p.cast]),
    operations?.facilities.map((f) => [f.id, f.capability, f.capacity]) ?? [],
    operations?.workflows ?? [],
    development?.projects.filter((p) => p.status !== 'produced' && !shelved.has(p.id) && (!directingScope || p.productionId === null))
      .map((p) => [p.id, p.conceptId, p.status, p.writerIds, p.dueWeek, p.reservation, p.productionId]) ?? [],
    [...occupancy].map(([key, claims]) => [key, claims.map((c) => [c.owner, c.ownerId, c.capability, c.slot])]),
    rival ? [] : state.productionQueue,
    rival ? [] : state.placement.facilities.filter((f) => f.status !== 'cancelled')
      .map((f) => [f.facilityId, f.blueprintId, f.status, f.completesWeek]),
    rival ? false : stockGreenlightAvailable(state, draft.issuerStudioId, directingScope),
    state.firstTakes.filter((t) => productionIds.has(t.productionId)).map((t) => [t.eventId, t.productionId, t.week]),
    state.hollywood?.employment.filter((e) => e.terms.talentId === draft.beneficiaryPersonId
      && e.terms.startWeek < draft.dueWeekExclusive && (e.endedWeek ?? e.terms.endWeekExclusive) > from)
      .map((e) => [e.contractId, e.studioId, e.terms.startWeek, e.terms.endWeekExclusive, e.endedWeek]) ?? [],
    (directingReservations ?? activePromiseReservations(state, draft, from))
      .map((p) => directingScope
        ? [p.promiseId, p.family, p.issuerStudioId, p.beneficiaryPersonId, p.predicate, p.windowStartWeek, p.dueWeekExclusive, p.progress]
        : [p.promiseId, p.family, p.issuerStudioId, p.windowStartWeek, p.dueWeekExclusive, p.predicate.count, p.progress]),
    // Appended only for a tagged draft so every count-only tuple stays byte-identical.
    ...('kind' in draft.predicate ? [isDirectorPredicate(draft.predicate)
      ? [draft.predicate.kind] : [draft.predicate.kind, draft.predicate.seatClass]] : []),
    // C.2c: append only an actual boundary. An unannounced person's historical
    // input tuple remains byte-identical; an accepted extension changes this fact.
    ...(retirement === undefined ? [] : [['retirement', retirement.status, retirement.effectiveWeek]]),
    // C.3 acting promises see the requested episode as well as today's global
    // boundary. Keep the existing tuple unchanged when both refer to one row.
    ...(actingRetirement === undefined || actingRetirement === retirement ? []
      : [['requestedRetirement', requestedRole, actingRetirement.status, actingRetirement.effectiveWeek]]),
    ...(directingScope ? [['directingScope', requestedRole, draft.issuerStudioId,
      person === undefined ? null : person.skills.directing !== undefined]] : []),
    ...(directingScope && productionOccupancy.length > 0 ? [['occupiedProductionSeats',
      productionOccupancy.map(({ studioId, production }) =>
        [studioId, production.id, production.startTick, production.remainingTicks])]] : []),
    // P14D.1: appended only when the issuer has shelved screenplays, so every other tuple stays byte-identical.
    ...(shelved.size === 0 ? [] : [['shelvedScripts', [...shelved]]]),
  ]
}

/**
 * The expected first-take week of this person's k-th sequential qualifying event
 * (0-based), counting only paths the studio controls. Event 0 may already be
 * running: a picture the person is seated on advances on its own clock
 * (`remainingTicks` counts down to the 5 → 4 take), and nothing needs to be
 * greenlit for it at all.
 */
function expectedFirstTakeWeek(
  state: GameState,
  draft: Pick<PromiseDraft, 'issuerStudioId' | 'beneficiaryPersonId' | 'predicate'>,
  from: number,
  k: number,
  freshFrom = from,
  committedSeatsOnly = false,
): number {
  if (k === 0) {
    const running = committedSeatsOnly ? committedPromiseSeats(state, draft)
      : seatedPreFirstTake(state, draft.issuerStudioId, draft.beneficiaryPersonId, promiseCastSlots(draft), isDirectorPredicate(draft.predicate))
    let earliest: number | null = null
    for (const production of running) {
      // `remainingTicks` 5 is the week BEFORE the take; the first advance is
      // skipped for a picture greenlit this very week.
      const weeks = Math.max(1, production.remainingTicks - 4) + (production.startTick >= from ? 1 : 0)
      if (earliest === null || from + weeks < earliest) earliest = from + weeks
    }
    if (earliest !== null) return earliest
  }
  return freshFrom + k * SEAT_CYCLE_WEEKS + WEEKS_TO_FIRST_TAKE
}

/** Earliest owner-clock boundaries, ignoring resource holds. A fresh picture
 * skips its greenlight week's advance. A take can be held until the promise
 * window opens; that also postpones its earliest release by the four remaining
 * advances. These are timing bounds, never a funded production certificate. */
function earliestTakeWeek(production: Production, week: number): number {
  return week + Math.max(1, production.remainingTicks - 4) + (production.startTick >= week ? 1 : 0)
}

function earliestReleaseWeek(production: Production, week: number): number {
  return week + Math.max(1, production.remainingTicks) + (production.startTick >= week ? 1 : 0)
}

function committedPromiseSeats(
  state: GameState,
  promise: Pick<PromiseDraft, 'issuerStudioId' | 'beneficiaryPersonId' | 'predicate'>,
): readonly Production[] {
  // A grandfathered picture already past 5 cannot mint another first take just
  // because no historical receipt was backfilled for it.
  return seatedPreFirstTake(state, promise.issuerStudioId, promise.beneficiaryPersonId, promiseCastSlots(promise), isDirectorPredicate(promise.predicate))
    .filter((production) => production.remainingTicks >= 5 && (!isOpportunityPredicate(promise.predicate)
      || opportunityProductionMatches(state, promise.issuerStudioId, promise.predicate, production)))
}

/** C.2c quote estimate for a person with a retirement record. The existing
 * eight-week fresh-picture hypothesis stays a QUOTE input. Bound GREENLIGHTS,
 * never first takes: a committed seat may film during finishing_commitments.
 * A fresh path and each already-held qualifying path are alternatives; choose
 * the earliest k-th event without inventing an extra simultaneous seat. */
function retirementQuoteTakeWeek(state: GameState, draft: PromiseDraft, week: number, k: number,
  capped = true, freshNotBefore = week): number {
  const admitted = (greenlightWeek: number): boolean => !capped
    || assignmentRefusal(state, draft.beneficiaryPersonId, greenlightWeek, isDirectorPredicate(draft.predicate) ? 'director' : 'actor') === null
  const freshTake = Math.max(draft.windowStartWeek, freshNotBefore + WEEKS_TO_FIRST_TAKE)
  const freshGreenlight = k === 0 ? freshNotBefore : freshTake + k * SEAT_CYCLE_WEEKS - WEEKS_TO_FIRST_TAKE
  let earliest = admitted(freshGreenlight) ? freshTake + k * SEAT_CYCLE_WEEKS : Infinity
  for (const production of committedPromiseSeats(state, draft)) {
    const take = Math.max(draft.windowStartWeek, earliestTakeWeek(production, week))
    if (k === 0) {
      earliest = Math.min(earliest, take)
      continue
    }
    const greenlight = Math.max(earliestReleaseWeek(production, week), take + 4, freshNotBefore)
      + (k - 1) * SEAT_CYCLE_WEEKS
    if (admitted(greenlight)) earliest = Math.min(earliest, greenlight + WEEKS_TO_FIRST_TAKE)
  }
  return earliest
}

/**
 * §4.3: does this studio's own authoritative schedule show a reasonable path to
 * satisfy this promise? Pure, no RNG, committed state by reference.
 *
 * The COUNT-FAMILY rule of §4.3.2, with all three conditions:
 *   1. `X ≤ N_max − buffer`                       (spare events)
 *   2. the X earliest events lie on EXISTING-pipeline paths
 *   3. the X-th event's expected first take leaves `slack` weeks before the due week
 * REASONABLY ACHIEVABLE iff all three hold; FRAGILE iff `X ≤ N_max` but one
 * fails; IMPOSSIBLE iff `X > N_max`, the window lies outside the contract, or
 * active promises already exhaust the seats.
 *
 * C.2c reads the actual retirement admission boundary when one exists. It
 * restricts future greenlights, while already-committed qualifying seats keep
 * their own clock. The quote is not the permanent retirement-outcome predicate.
 */
export function promiseFeasibility(state: GameState, draft: PromiseDraft, week: number): PromiseFeasibilityReceipt {
  const X = draft.predicate.count
  const from = Math.max(draft.windowStartWeek, week)
  const opportunityScope = opportunityReservations(state, draft, from)
  const reservations = opportunityScope ?? directingScopeReservations(state, draft, from)
  const directingScope = reservations !== undefined
  const director = isDirectorPredicate(draft.predicate)
  const requestedRole = director ? 'director' : 'actor'
  const productionOccupancy = directingScope ? promiseProductionOccupancy(state, draft) : []
  const inputs = [...feasibilityInputs(state, draft, week, reservations, productionOccupancy),
    ...(opportunityScope === undefined ? [] : [opportunityFeasibilityInputs(state, draft)])]
  const answer = (classification: PromiseClassification, bottleneck: string | null): PromiseFeasibilityReceipt =>
    receipt(classification, bottleneck, inputs, week, opportunityScope !== undefined ? OPPORTUNITY_PROMISE_RULES_VERSION
      : directingScope ? DIRECTING_PROMISE_RULES_VERSION : PROMISE_RULES_VERSION)
  const refuse = (bottleneck: string): PromiseFeasibilityReceipt => answer('IMPOSSIBLE', bottleneck)

  const notOffered = NOT_OFFERED_IN_B1[draft.family]
  const opportunity = isOpportunityPredicate(draft.predicate)
  if (notOffered !== undefined && !opportunity) return refuse(notOffered)
  const opportunityRefusal = opportunityPredicateRefusal(draft.family, draft.predicate)
  if (opportunityRefusal !== null) return refuse(opportunityRefusal)
  if (draft.family === 'DIRECTING_COUNT' && !director) return refuse('a directing promise needs its explicit directorCount predicate selected')
  if (director && (draft.family !== 'DIRECTING_COUNT'
    || Object.keys(draft.predicate).some(key => key !== 'kind' && key !== 'count'))) {
    return refuse('the directorCount predicate applies only to DIRECTING_COUNT and contains only kind and count')
  }
  // Record 600: a seat-class promise is offered only with its class selected; a
  // legacy count-only P2 stays nonofferable at a new quote/freeze with the missing
  // fact named. A class on any other family is a shape refusal, not a search miss.
  if (draft.family === 'LEAD_OR_SIGNIFICANT_ROLE_COUNT' && !('kind' in draft.predicate)) {
    return refuse('a seat-class promise needs its seat class selected (lead, or lead-or-antagonist); without one it is not offered')
  }
  if ('kind' in draft.predicate && !director && !opportunity && draft.family !== 'LEAD_OR_SIGNIFICANT_ROLE_COUNT') {
    return refuse('a selected seat class applies only to a seat-class promise')
  }
  if (!Number.isInteger(X) || X < 1) return refuse('the promised count must be a whole picture')
  if (draft.dueWeekExclusive <= draft.windowStartWeek) return refuse('the window closes before it opens')
  if (draft.windowStartWeek < draft.startWeek) return refuse('the window starts before the proposed contract')
  if (draft.dueWeekExclusive > draft.startWeek + draft.termWeeks) {
    return refuse('the due week falls outside the proposed contract')
  }
  // Match greenlight's has-discipline law (actions.ts `requireRole`): an acting
  // skill profile permits a cast assignment regardless of primary profession.
  const person = state.talent.find((t) => t.id === draft.beneficiaryPersonId)
  if (person === undefined) return refuse('this person is not in the world')
  if (director ? person.skills.directing === undefined : person.skills.acting === undefined) {
    return refuse(director ? 'this person lacks a directing skill profile' : 'this person lacks an acting skill profile')
  }
  if (isOpportunityPredicate(draft.predicate)) {
    const result = opportunityAssessment(state, { ...draft, predicate: draft.predicate }, week, opportunityScope ?? [])
    return answer(result.classification, result.bottleneck)
  }

  const reserved = reservations === undefined ? reservedByActivePromises(state, draft, from)
    : reservations.reduce((sum, promise) => sum + Math.max(0, promise.predicate.count - promise.progress), 0)
  const hasRetirement = retirementRecordFor(state, draft.beneficiaryPersonId) !== undefined
    || retirementRecordFor(state, draft.beneficiaryPersonId, requestedRole) !== undefined
  const freshNotBefore = productionOccupancy.reduce((earliest, { production }) =>
    Math.max(earliest, earliestReleaseWeek(production, week)), week)
  const expectedTake = (k: number): number => !hasRetirement
    ? expectedFirstTakeWeek(state, draft, from, k, Math.max(from, freshNotBefore), directingScope)
    : retirementQuoteTakeWeek(state, draft, week, k, true, freshNotBefore)

  // N_max: the events this person can reach inside the window, counted
  // sequentially (one seat at a time), each on the minimum lawful pipeline.
  let nMax = 0
  while (expectedTake(nMax) < draft.dueWeekExclusive) {
    nMax += 1
    if (nMax > 1000) break // bounded: a window can never buy more than this
  }
  if (X > nMax) {
    if (hasRetirement && retirementQuoteTakeWeek(state, draft, week, X - 1, false, freshNotBefore) < draft.dueWeekExclusive) {
      return refuse('retirement leaves too few qualifying production seats inside the window')
    }
    return refuse('no filming week inside the window can reach that many pictures')
  }
  if (reserved + X > nMax) return refuse('promises already made to this person exhaust the window')

  const existingPath = (directingScope ? committedPromiseSeats(state, draft)
    : seatedPreFirstTake(state, draft.issuerStudioId, draft.beneficiaryPersonId, promiseCastSlots(draft), director)).length
    + unproducedScripts(state, draft.issuerStudioId, directingScope)
    + (stockGreenlightAvailable(state, draft.issuerStudioId, directingScope) ? 1 : 0)
  const lastEventWeek = expectedTake(reserved + X - 1)

  // Evaluator 4 (record 600): active reservations are subtracted before the
  // spare-event buffer is tested — shared residual capacity, for fresh P1 and
  // tagged P2 alike.
  if (reserved + X > nMax - promiseBuffer(nMax)) {
    return answer('FRAGILE', 'the schedule leaves no spare picture inside the window')
  }
  if (reserved + X > existingPath) {
    return answer('FRAGILE', 'needs a picture not yet commissioned')
  }
  if (draft.dueWeekExclusive - lastEventWeek < PROMISE_SLACK_WEEKS) {
    return answer('FRAGILE', 'the due week leaves too little room before filming would start')
  }
  return answer('REASONABLY_ACHIEVABLE', null)
}

/** Re-classification of an ALREADY-MINTED promise against committed state
 * through `promiseFeasibility`. The window itself is the interval: a live
 * promise no longer asks whether it fits inside a contract it already rode in
 * on. History: p14b1's §4.4 studio-caused-event step (`breakPromisesOnCancel`)
 * broke a promise on this read's IMPOSSIBLE; since record 630 that seam judges
 * by `targetSpecificImpossibility` instead. The §2.1.8 freeze step never used
 * it: talentMarket's own `attachedFeasibility` reads `promiseFeasibility` over
 * the PROPOSAL's interval. No production caller remains (grep src/ bridge/ ui/);
 * the export stays for index.ts and the RED's premises
 * (tests/p14b4-cancel-causal-proof.test.ts). */
export function reclassifyPromise(state: GameState, promise: ProfessionalPromise, week: number): PromiseFeasibilityReceipt {
  return promiseFeasibility(state, {
    family: promise.family,
    issuerStudioId: promise.issuerStudioId,
    beneficiaryPersonId: promise.beneficiaryPersonId,
    predicate: promise.predicate,
    windowStartWeek: promise.windowStartWeek,
    dueWeekExclusive: promise.dueWeekExclusive,
    startWeek: promise.windowStartWeek,
    termWeeks: promise.dueWeekExclusive - promise.windowStartWeek,
    promiseId: promise.promiseId,
  }, week)
}

// ── §4.1 attachment: the promise rides on a CURRENT proposal ────────────────

export type PromiseAttachment = {
  family: PromiseFamily
  predicate: PromisePredicate
  windowStartWeek: number
  dueWeekExclusive: number
}

function appendMarketReceipt(
  market: TalentMarketStateV36,
  draft: { kind: 'promiseOutcome'; week: number; talentId: string; studioId: string | null; reasons: readonly string[] },
): TalentMarketStateV36 {
  return {
    ...market,
    receipts: [...market.receipts, { ...draft, dropped: [], eventId: `talent-market-event-${String(market.receipts.length)}` }],
  }
}

/**
 * Attach ONE promise to the studio's current proposal for this person. The
 * contract interval and the parties are read off the target proposal (companion
 * §4.1: a promise "is attached to a proposal"); only the promise's own fields are
 * drafted here.
 *
 * AT MOST ONE PROMISE PER PROPOSAL (plan item 3, bounded hypothesis) is ENFORCED
 * BY REFUSAL, not by silent replacement: a revision re-submits the proposal —
 * this codebase's own "revised in place" convention, which restores the material
 * terms and clears the promise — and then attaches a new draft.
 */
export function attachPromise(
  state: GameState,
  talentId: string,
  issuerStudioId: string,
  draft: PromiseAttachment,
): GameState {
  const week = state.market.tick
  // P14C.2b (806 §7.1 / §8.4): no promise rides a retirement extension.
  // C.2c disposes existing obligations without changing that attachment rule.
  if (openMarketCaseFor(state, talentId)?.variant === 'retirementExtension') {
    throw new Error(`promises: "${talentId}"'s open case is a retirementExtension — no promise rides the one final extension (P14C.2b)`)
  }
  const proposal = state.talentMarket.proposals.find((p) => p.talentId === talentId && p.issuerStudioId === issuerStudioId)
  if (proposal === undefined) {
    throw new Error(`promises: studio "${issuerStudioId}" has no current proposal for "${talentId}" to attach a promise to`)
  }
  if (proposal.promises.length > 0) {
    throw new Error(
      `promises: studio "${issuerStudioId}"'s proposal for "${talentId}" already carries a promise — P14B.1 attaches at most one; re-submit the proposal to revise it`,
    )
  }
  const director = isDirectorPredicate(draft.predicate)
  const opportunityRefusal = opportunityPredicateRefusal(draft.family, draft.predicate)
  if (opportunityRefusal !== null) throw new Error(`promises: ${opportunityRefusal}`)
  if (isOpportunityPredicate(draft.predicate) && draft.predicate.kind === 'projectOpportunity') {
    const projectId = draft.predicate.scriptProjectId
    if (!takeSubjectOwner(state, issuerStudioId)?.development.projects.some(row => row.id === projectId)) {
      throw new Error('promises: a named opportunity requires an existing script project of the issuing studio')
    }
  }
  if (draft.family === 'DIRECTING_COUNT' && !director) {
    throw new Error('promises: a fresh directing promise requires the explicit directorCount predicate')
  }
  if (director && (draft.family !== 'DIRECTING_COUNT'
    || Object.keys(draft.predicate).some(key => key !== 'kind' && key !== 'count'))) {
    throw new Error('promises: directorCount is an exact kind/count predicate for DIRECTING_COUNT only')
  }
  if ('kind' in draft.predicate && !director && !isOpportunityPredicate(draft.predicate) && draft.family !== 'LEAD_OR_SIGNIFICANT_ROLE_COUNT') {
    throw new Error(
      `promises: a selected seat class is legal only on a LEAD_OR_SIGNIFICANT_ROLE_COUNT promise, not "${draft.family}"`,
    )
  }
  const feasibilityReceipt = promiseFeasibility(state, {
    family: draft.family,
    issuerStudioId,
    beneficiaryPersonId: talentId,
    predicate: draft.predicate,
    windowStartWeek: draft.windowStartWeek,
    dueWeekExclusive: draft.dueWeekExclusive,
    startWeek: proposal.startWeek,
    termWeeks: proposal.termWeeks,
  }, week)
  const base = {
    promiseId: `promise-${String(state.promises.length)}`,
    version: feasibilityReceipt.rulesVersion,
    issuerStudioId,
    beneficiaryPersonId: talentId,
    windowStartWeek: draft.windowStartWeek,
    dueWeekExclusive: draft.dueWeekExclusive,
    feasibilityReceipt,
    progress: 0,
    evidenceRefs: [],
    outcome: null,
    outcomeWeek: null,
    outcomeCause: null,
    outcomeEventId: null,
    contractId: null,
    // Save V32: a freshly attached promise supersedes nothing. Only `waivePromise`
    // ever writes a non-null link, and only onto the promise it waives.
    supersededByPromiseId: null,
  }
  // The COMPLETE predicate is copied as a detached object, minted in two typed
  // branches against the correlated V30 members (the tagged branch is P2 by the
  // guard above).
  const promise: ProfessionalPromise = isDirectorPredicate(draft.predicate)
    ? { ...base, family: 'DIRECTING_COUNT', predicate: { kind: 'directorCount', count: draft.predicate.count } }
    : isOpportunityPredicate(draft.predicate)
    ? draft.predicate.kind === 'genreOpportunity'
      ? { ...base, family: 'PREFERRED_GENRE_OPPORTUNITY', predicate: { ...draft.predicate } }
      : { ...base, family: 'SPECIFIC_PROJECT', predicate: { ...draft.predicate } }
    : 'kind' in draft.predicate
    ? {
        ...base,
        family: 'LEAD_OR_SIGNIFICANT_ROLE_COUNT',
        predicate: { kind: 'castRoleCount', count: draft.predicate.count, seatClass: draft.predicate.seatClass },
      }
    : { ...base, family: draft.family, predicate: { count: draft.predicate.count } }
  const promises = [...state.promises, promise]
  const promised = { ...proposal, promises: [promise.promiseId] }
  const redigested = {
    ...promised,
    digest: proposalDigest(
      promised.talentId, promised.issuerStudioId, promised.termWeeks, promised.startWeek, promised.premiumTier,
      attachedPromiseDigest({ promises }, promised.promises),
    ),
  }
  return {
    ...state,
    promises,
    talentMarket: {
      ...state.talentMarket,
      proposals: state.talentMarket.proposals.map((p) => (p === proposal ? redigested : p)),
    },
  }
}

// ── §4.4 outcomes ────────────────────────────────────────────────────────────

/** The qualifying first takes for one promise: this studio's own, inside the
 * window, with this person in a cast seat. Ordered as they were recorded. */
/**
 * RULING (i) (plan, P14B.1 T2): a promise BINDS only when the proposal that
 * carried it is COMMITTED at settlement — `commitWinningPromise` setting the
 * `contractId` it rode in on (companion §4.1). A promise whose proposal LOST,
 * was dropped at freeze, or was withdrawn is UNBOUND and is NEVER evaluated: no
 * due-week BROKEN, no SATISFIED, no termination or cancellation BROKEN, no
 * `promiseOutcome` receipt and therefore no trust driver — its record keeps
 * `outcome: null` and `contractId: null` for good. B.1 mints no outcome for an
 * offer nobody took.
 *
 * DELIBERATELY NOT GATED: the feasibility quote (`reservedByActivePromises`) and
 * the freeze re-classification act on ATTACHED, not-yet-bound promises by
 * design — quoting a promise before anyone has accepted it is what they are for.
 */
function evaluable(promise: Pick<ProfessionalPromiseV30, 'outcome' | 'contractId'>): boolean {
  // The two fields it actually reads, so a FROZEN V30 row (`promisedCastMasks`)
  // answers the same question as a live V32 one. Both are identical on both V30
  // union members and unchanged by the V32 field.
  return promise.outcome === null && promise.contractId !== null
}

export function promiseCastSlots(promise: { predicate: PromisePredicate }): readonly CastSlot[] {
  // Legacy count-only records of every family retain generic-cast semantics.
  // Only the explicit predicate shape selects a restricted seat class.
  if (!('kind' in promise.predicate)) return CAST_SLOTS
  if (isDirectorPredicate(promise.predicate)) return []
  if (isOpportunityPredicate(promise.predicate)) return opportunitySlots(promise.predicate)
  return promise.predicate.seatClass === 'lead' ? ['lead'] : ['lead', 'antagonist']
}

/** P14B.4 final seating preference (plan :215-236): the people a package decided
 * this week should seat, each with the INTERSECTION of the masks of every promise
 * a take in `takeWeek` could serve — bound OPEN, unmet, this issuer, take inside
 * the half-open window. CURRENT unaccepted offers never count: they reserve quote
 * capacity (`activePromiseReservations`) and bind nobody. Reads `state.promises`
 * only; no receipts, no RNG. */
export function promisedCastMasks(
  state: { promises: readonly ReadablePromise[] }, issuerStudioId: string, takeWeek: number,
  subject?: { genre: Genre; scriptProjectId: string | null },
): ReadonlyMap<string, readonly CastSlot[]> {
  const masks = new Map<string, readonly CastSlot[]>()
  for (const promise of state.promises) {
    if (isDirectorPromise(promise)) continue
    if (isOpportunityPredicate(promise.predicate) && (subject === undefined
      || (promise.predicate.kind === 'genreOpportunity' ? promise.predicate.genre !== subject.genre
        : promise.predicate.scriptProjectId !== subject.scriptProjectId))) continue
    if (!evaluable(promise) || promise.issuerStudioId !== issuerStudioId
      || promise.progress >= promise.predicate.count
      || takeWeek < promise.windowStartWeek || takeWeek >= promise.dueWeekExclusive) continue
    const slots = promiseCastSlots(promise)
    masks.set(promise.beneficiaryPersonId,
      (masks.get(promise.beneficiaryPersonId) ?? CAST_SLOTS).filter((slot) => slots.includes(slot)))
  }
  return masks
}

export function qualifyingTakes(
  state: Pick<GameStateV30, 'firstTakes'> & Partial<Pick<GameState, 'firstTakeSubjects'>>,
  promise: ReadablePromise,
): readonly FirstTakeReceipt[] {
  const slots = promiseCastSlots(promise)
  const director = isDirectorPromise(promise)
  const productions = new Set<string>()
  return state.firstTakes.filter((take) => {
    if (productions.has(take.productionId)
      || take.studioId !== promise.issuerStudioId
      || take.week < promise.windowStartWeek || take.week >= promise.dueWeekExclusive
      || !(director ? take.directorId === promise.beneficiaryPersonId
        : slots.some((slot) => take.cast[slot] === promise.beneficiaryPersonId))) return false
    if (isOpportunityPredicate(promise.predicate) && !opportunitySubjectMatches(promise.predicate,
      state.firstTakeSubjects?.facts.find(subject => subject.eventId === take.eventId))) return false
    productions.add(take.productionId)
    return true
  })
}

/**
 * Plan :331-336 / :348-355: the SEPARATE target-specific physical proof for a
 * BOUND promise after a studio action (the cancel seam), never the offer
 * classification. `remaining` is the count minus the ACTUAL class-qualified
 * distinct first takes (`qualifyingTakes`), never the stored `progress`
 * counter; zero remaining is a met predicate the weekly owner settles, not a
 * failed probe. The bound presumes M16 one-seat exclusivity
 * (`assertGreenlightStaffingIdle`: a person on a running picture cannot be
 * greenlit again) and fixed cast (no recast verb), so each later take needs a
 * greenlight at least WEEKS_TO_FIRST_TAKE after the previous take week:
 * t0 + 5k is a floor on the k-th remaining take week and ceil((due - t0) / 5)
 * a ceiling on the count reachable before `dueWeekExclusive` — a hard upper
 * bound (plan :348-349), deliberately looser than the quote's SEAT_CYCLE_WEEKS
 * hypothesis, which may not write a permanent BROKEN. The physical clock runs
 * from `week` (a picture greenlit now first-takes at week + 5); the window
 * start is only a floor on t0 because a picture can be held at ticks 5 until
 * the window opens. No reservation subtraction, no family or class refusal, no
 * FRAGILE term, no receipt (record 26 §2): a joint conflict, an unsupported
 * family and a FRAGILE remainder are all `null` here. Pure, no RNG.
 */
export function targetSpecificImpossibility(state: GameState, promise: ProfessionalPromise, week: number): string | null {
  const remaining = Math.max(0, promise.predicate.count - qualifyingTakes(state, promise).length)
  if (remaining === 0) return null
  if (isOpportunityPredicate(promise.predicate)) return opportunityPhysicalImpossibility(state, { ...promise, predicate: promise.predicate }, week)
  const t0 = Math.max(promise.windowStartWeek, expectedFirstTakeWeek(state, promise, week, 0))
  const nMax = t0 < promise.dueWeekExclusive ? Math.ceil((promise.dueWeekExclusive - t0) / WEEKS_TO_FIRST_TAKE) : 0
  return remaining > nMax ? 'no filming week inside the window can reach that many pictures' : null
}

/** A rival cannot use the player's cancel-after-first-take shortcut. Its next
 * seat waits for the actual owner's earliest release; every further fresh
 * picture needs PRODUCTION_TICKS + 1 weeks including its skipped first advance.
 * As in the existing physical check this ignores resource contention and rival
 * decision cadence, so it can rule timing out, never certify a complete plan. */
function rivalUncappedPromiseCapacity(state: GameState, promise: ProfessionalPromise, week: number): number {
  const personId = promise.beneficiaryPersonId
  const productions = [...state.studio.activeProductions,
    ...(state.hollywood?.businesses.flatMap((business) => business.productions) ?? [])]
  let released = week
  for (const production of productions) {
    if (production.directorId === personId || production.craftIds.includes(personId)
      || CAST_SLOTS.some((slot) => production.cast[slot] === personId)) {
      released = Math.max(released, earliestReleaseWeek(production, week))
    }
  }
  const freshCapacity = (greenlight: number): number => {
    const take = Math.max(promise.windowStartWeek, greenlight + WEEKS_TO_FIRST_TAKE)
    return take < promise.dueWeekExclusive
      ? Math.ceil((promise.dueWeekExclusive - take) / (TUNING.PRODUCTION_TICKS + 1)) : 0
  }
  // It may release a held picture whose take cannot count, then start another.
  let capacity = freshCapacity(released)
  for (const production of committedPromiseSeats(state, promise)) {
    const take = Math.max(promise.windowStartWeek, earliestTakeWeek(production, week))
    if (take >= promise.dueWeekExclusive) continue
    // Alternatively hold this qualifying take to the window, which also delays
    // release. One-seat exclusivity makes these alternatives, not extra seats.
    capacity = Math.max(capacity, 1 + freshCapacity(Math.max(released, take + 4)))
  }
  return capacity
}

/** Record 823's delegated C.2c disposition: wait until retirement ACTUALLY
 * closes new admission, protect committed qualifying work, and retain ordinary
 * law when physical timing independently rules out the unmet target. This is
 * not the quote classification or an executable counterfactual certificate.
 * Future extensions do not postpone the check: they decide at the carrying
 * contract's expiry, at or after this promise's unchanged exclusive deadline. */
function retirementVoidsPromise(state: GameState, promise: ProfessionalPromise, week: number, remaining: number): boolean {
  // Admission reads the current profession and the work this promise requests.
  // A completed Actor episode does not close an otherwise lawful Director seat.
  const requestedRole = isDirectorPromise(promise) ? 'director' : 'actor'
  if (remaining === 0 || assignmentRefusal(state, promise.beneficiaryPersonId, week, requestedRole) === null) return false
  if (isOpportunityPredicate(promise.predicate)) {
    const target = { ...promise, predicate: promise.predicate }
    return opportunityPhysicalImpossibility(state, target, week, true) !== null
      && opportunityPhysicalImpossibility(state, target, week, false) === null
  }
  const committed = committedPromiseSeats(state, promise).filter((production) =>
    Math.max(promise.windowStartWeek, earliestTakeWeek(production, week)) < promise.dueWeekExclusive)
  if (committed.length >= remaining) return false
  if (state.hollywood !== null && promise.issuerStudioId !== state.hollywood.playerStudioId) {
    return rivalUncappedPromiseCapacity(state, promise, week) >= remaining
  }
  // C.2c uses the SAME filtered future seats on both sides of its cutoff check.
  // The older cancellation evaluator's unrecorded-picture read can include a
  // grandfathered countdown already below 5; that is not another future take.
  // Preserve its separate law, while bounding this player's remaining takes
  // by a real fresh start or one of these still-ahead qualifying seats.
  let first = Math.max(promise.windowStartWeek, week + WEEKS_TO_FIRST_TAKE)
  for (const production of committed) {
    first = Math.min(first, Math.max(promise.windowStartWeek, earliestTakeWeek(production, week)))
  }
  // The player's existing cancel-after-take route permits a fresh greenlight
  // at that take, unlike the rival release-only route above.
  const capacity = first < promise.dueWeekExclusive
    ? Math.ceil((promise.dueWeekExclusive - first) / WEEKS_TO_FIRST_TAKE) : 0
  return capacity >= remaining
}

/** The outcome fields a settlement may write; identical on both V30 members.
 * `supersededByPromiseId` (Save V32) joins them because the WAIVED branch is the
 * only settlement that names a successor, and it must be written in the SAME
 * `settle()` call that freezes the outcome. */
type PromiseSettlement = Partial<Pick<ProfessionalPromise,
  'progress' | 'evidenceRefs' | 'outcome' | 'outcomeCause' | 'outcomeEventId' | 'supersededByPromiseId'>>

function settle(
  state: GameState,
  promise: ProfessionalPromise,
  next: PromiseSettlement,
  week: number,
  reason: string,
): GameState {
  const market = appendMarketReceipt(state.talentMarket, {
    kind: 'promiseOutcome',
    week,
    talentId: promise.beneficiaryPersonId,
    studioId: promise.issuerStudioId,
    reasons: [reason],
  })
  const eventId = market.receipts[market.receipts.length - 1]!.eventId
  return {
    ...state,
    promises: state.promises.map((p) => (p.promiseId === promise.promiseId
      ? { ...p, ...next, outcomeWeek: week, outcomeEventId: next.outcomeEventId ?? eventId }
      : p)),
    talentMarket: market,
  }
}

/**
 * The weekly promise pass: SATISFIED at the X-th qualifying first take inside the
 * window, BROKEN at `dueWeekExclusive` when the window passes unsatisfied.
 * Outcomes are TERMINAL and emitted ONCE — a promise that already carries one is
 * never re-evaluated, so a replayed or repeated tick cannot duplicate it.
 *
 * C.2c: after satisfied work is counted, retirement may VOID the unmet
 * remainder under its admission-cutoff rule. The existing waiver command
 * remains a separate owner; neither path adds a negative trust driver.
 */
export function advancePromisesWeek(state: GameState): GameState {
  requirePromiseRoots(state)
  const week = state.market.tick
  let next = state
  for (const promise of state.promises) {
    if (!evaluable(promise)) continue
    const takes = qualifyingTakes(next, promise)
    const progress = Math.min(promise.predicate.count, takes.length)
    if (takes.length >= promise.predicate.count) {
      const evidenceRefs = takes.slice(0, promise.predicate.count).map((t) => t.eventId)
      next = settle(next, promise, {
        progress,
        evidenceRefs,
        outcome: 'SATISFIED',
        outcomeCause: 'the promised pictures began filming inside the window',
        // `outcomeEventId` names this promise's OWN outcome event — the
        // `promiseOutcome` receipt `settle` appends — in every branch, never the
        // causing first take, which `evidenceRefs` already names. ONE take seats
        // up to three promised people (measured: r01's `first-take-event-76`
        // satisfies three of its own promises at week 216), so pointing the field
        // at the take made several promises name one event and the V29 root
        // validator refused the save: "records a second outcome".
        outcomeEventId: null,
      }, week, 'a promise to this person was kept')
      continue
    }
    if (retirementVoidsPromise(next, promise, week, promise.predicate.count - progress)) {
      next = settle(next, promise, {
        progress,
        evidenceRefs: takes.map((take) => take.eventId),
        outcome: 'VOIDED',
        outcomeCause: 'retirement closed new production assignments before the remaining promised pictures could begin filming',
        outcomeEventId: null,
      }, week, 'a promise to this person was voided by retirement')
      continue
    }
    if (week >= promise.dueWeekExclusive) {
      next = settle(next, promise, {
        progress,
        outcome: 'BROKEN',
        outcomeCause: 'the window closed before the promised pictures began filming',
        outcomeEventId: null,
      }, week, 'a promise to this person went unmet to its due week')
      continue
    }
    if (progress !== promise.progress) {
      next = { ...next, promises: next.promises.map((p) => (p.promiseId === promise.promiseId
        ? { ...p, progress, ...(isDirectorPromise(promise) ? { evidenceRefs: takes.map(take => take.eventId) } : {}) }
        : p)) }
    }
  }
  return next
}

/**
 * §4.4, recorded IMMEDIATELY at the causing action: the issuing studio terminated
 * the beneficiary early, so every open promise it made them is BROKEN at the
 * termination, not at the next weekly pass.
 */
export function breakPromisesOnTermination(state: GameState, issuerStudioId: string, personId: string): GameState {
  requirePromiseRoots(state)
  const week = state.market.tick
  let next = state
  for (const promise of state.promises) {
    if (!evaluable(promise)) continue
    if (promise.issuerStudioId !== issuerStudioId || promise.beneficiaryPersonId !== personId) continue
    next = settle(next, promise, {
      outcome: 'BROKEN',
      outcomeCause: 'the studio terminated this contract early, ending the window',
      outcomeEventId: null,
    }, week, 'a promise to this person was broken by an early termination')
  }
  return next
}

/**
 * §4.4's "any studio-caused event that makes the predicate unsatisfiable": the
 * studio cancelled a picture the beneficiary held a qualifying seat on BEFORE its
 * first take. BROKEN iff the separate target-specific proof finds no physical
 * path for the REMAINING count on the post-cancel state (plan :243-252, :331-336;
 * record 26 §2). A cancellation the schedule can still absorb costs the studio
 * nothing here (it is priced by trust, §4.5); a joint reservation conflict, an
 * unsupported family or a FRAGILE remainder never breaks; a first take already
 * taken is never un-taken (companion §4.2: "first take, then cancellation").
 */
export function breakPromisesOnCancel(state: GameState, issuerStudioId: string, cancelled: Production): GameState {
  requirePromiseRoots(state)
  const week = state.market.tick
  if (state.firstTakes.some((t) => t.productionId === cancelled.id)) return state
  let next = state
  for (const promise of state.promises) {
    if (!evaluable(promise)) continue
    if (promise.issuerStudioId !== issuerStudioId) continue
    // The post-cancel owner has cleared its production link; the concept still
    // identifies the exact retained screenplay that cancellation returned to Ready.
    if (isOpportunityPredicate(promise.predicate)) {
      const owner = state.hollywood?.playerStudioId === issuerStudioId ? state.scriptDevelopment
        : state.hollywood?.businesses.find(row => row.studioId === issuerStudioId)?.development
      const project = owner?.projects.find(row => row.id === ('scriptProjectId' in promise.predicate ? promise.predicate.scriptProjectId : ''))
      if (promise.predicate.kind === 'projectOpportunity' && project?.conceptId !== cancelled.conceptId) continue
      if (promise.predicate.kind === 'genreOpportunity' && !opportunityProductionMatches(state, issuerStudioId, promise.predicate, cancelled)) continue
    }
    const directing = isDirectorPromise(promise)
    if (!(directing ? cancelled.directorId === promise.beneficiaryPersonId
      : promiseCastSlots(promise).some((slot) => cancelled.cast[slot] === promise.beneficiaryPersonId))) continue
    if (targetSpecificImpossibility(state, promise, week) === null) continue
    next = settle(next, promise, {
      outcome: 'BROKEN',
      outcomeCause: directing
        ? 'the studio cancelled the picture this person was directing, and no path was left'
        : 'the studio cancelled the picture this person was cast in, and no path was left',
      outcomeEventId: null,
    }, week, 'a promise to this person was broken by a cancelled picture')
  }
  return next
}

/** Only the successful assignment owner calls this, after the screenplay link
 * is committed. A queued or refused request never creates a terminal outcome. */
export function breakPromisesOnGreenlight(state: GameState, issuerStudioId: string, production: Production,
  week = state.market.tick): GameState {
  let next = state
  for (const promise of state.promises) {
    if (!evaluable(promise) || promise.issuerStudioId !== issuerStudioId
      || !isOpportunityPredicate(promise.predicate) || promise.predicate.kind !== 'projectOpportunity'
      || promise.progress >= promise.predicate.count || qualifyingTakes(state, promise).length >= promise.predicate.count
      || !opportunityProductionMatches(state, issuerStudioId, promise.predicate, production)
      || promiseCastSlots(promise).some(slot => production.cast[slot] === promise.beneficiaryPersonId)) continue
    next = settle(next, promise, { outcome: 'BROKEN', outcomeEventId: null,
      outcomeCause: 'the studio fixed the named project cast without this person in the promised seat' },
    week, 'a promise to this person was broken by the named project casting')
  }
  return next
}

// ── §4.4 the waiver: the second road out of an open promise (P14B.7) ────────

/**
 * The REAL employment interval the original rode in on, read from the contract
 * `promise.contractId` names. `null` when no such contract is on the record —
 * reported, never defaulted.
 */
function contractInterval(state: GameState, promise: ProfessionalPromise): { startWeek: number; termWeeks: number } | null {
  const contract = state.hollywood?.employment.find((e) => e.contractId === promise.contractId)
  if (contract === undefined) return null
  return { startWeek: contract.terms.startWeek, termWeeks: contract.terms.endWeekExclusive - contract.terms.startWeek }
}

/**
 * The substitute's feasibility draft. TWO details differ from every neighbouring
 * caller and nothing in the type enforces either, so both are stated here.
 *
 * `startWeek`/`termWeeks` are the CONTRACT interval (`:203`), and they alone arm
 * the two refusals at `:406-409`. `reclassifyPromise` passes the PROMISE's own
 * window there, which makes both refusals tautological (`w < w`, `d > d`). That
 * is correct for a live promise, which already rode in on a contract, and wrong
 * here: the substitute is a brand-new promise whose window has never been checked
 * against anything. Copying that shape would accept a substitute overrunning the
 * real contract and hand the player an opaque save-validator crash instead of a
 * published refusal.
 *
 * `promiseId` names the ORIGINAL, not the substitute. `activePromiseReservations`
 * (`:289-297`) excludes exactly that id and `reservedByActivePromises` sums
 * `count - progress` — precisely the remaining obligation this substitute must
 * cover. Unexcluded, the promise being waived books the capacity its own
 * replacement needs. It is lawful to exclude it because it settles WAIVED in this
 * same step, so the reservation being subtracted is one already being released.
 */
function substituteDraft(
  promise: ProfessionalPromise,
  substitute: PromiseAttachment,
  interval: { startWeek: number; termWeeks: number },
): PromiseDraft {
  return {
    family: substitute.family,
    issuerStudioId: promise.issuerStudioId,
    beneficiaryPersonId: promise.beneficiaryPersonId,
    predicate: substitute.predicate,
    windowStartWeek: substitute.windowStartWeek,
    dueWeekExclusive: substitute.dueWeekExclusive,
    startWeek: interval.startWeek,
    termWeeks: interval.termWeeks,
    promiseId: promise.promiseId,
  }
}

/** The selected P2 seat class, or `null` for every count-only record. */
function seatClassOf(predicate: PromisePredicate): string | null {
  return 'kind' in predicate && predicate.kind === 'castRoleCount' ? predicate.seatClass : null
}

/** Same family, class, count AND window: a substitute that changes nothing the
 * studio owes. It passes strength at equality and the count rule at equality, so
 * only this test can refuse it. */
function identicalSubstitute(promise: ProfessionalPromise, substitute: PromiseAttachment): boolean {
  if (isOpportunityPredicate(promise.predicate) || isOpportunityPredicate(substitute.predicate)) {
    return promiseDigest(promise) === promiseDigest({ ...promise, ...substitute } as ProfessionalPromise)
  }
  return substitute.family === promise.family
    && seatClassOf(substitute.predicate) === seatClassOf(promise.predicate)
    && substitute.predicate.count === promise.predicate.count
    && substitute.windowStartWeek === promise.windowStartWeek
    && substitute.dueWeekExclusive === promise.dueWeekExclusive
}

/** Restriction inclusion is independent of class inclusion and remaining count. It reads only the
 * Save40 era's state, so the frozen V40/V41 proof can ask it as well as the live writer. */
function opportunitySubstitutionRefusal(state: GameStateV40, promise: ProfessionalPromise, substitute: PromiseAttachment): string | null {
  if (!isOpportunityPredicate(promise.predicate)) return null
  if (!isOpportunityPredicate(substitute.predicate)) return 'a substitute cannot erase the promised genre or project restriction'
  if (promise.predicate.kind === 'projectOpportunity') {
    return substitute.predicate.kind === 'projectOpportunity' && substitute.predicate.scriptProjectId === promise.predicate.scriptProjectId
      ? null : 'a substitute must retain the same named script project'
  }
  if (substitute.predicate.kind === 'genreOpportunity') return substitute.predicate.genre === promise.predicate.genre
    ? null : 'a substitute must retain the same promised genre'
  const owner = takeSubjectOwner(state, promise.issuerStudioId)
  const id = substitute.predicate.scriptProjectId
  const project = owner?.development.projects.find(row => row.id === id)
  return owner?.concepts.find(row => row.id === project?.conceptId)?.genre === promise.predicate.genre
    ? null : 'the substitute project must belong to the original promised genre'
}

/**
 * §1's three acceptance conditions plus the shape rules, as a SEPARATE pure
 * predicate: the REASON a person refuses this substitute, or `null` when they
 * accept it. A reason rather than a boolean, so `waivePromise` publishes the
 * refusal it actually made instead of re-deriving one.
 *
 * STRENGTH IS A SUBSET TEST, `substituteMask ⊆ originalMask`, over the module's
 * one seat-mask authority (`promiseCastSlots`). Strength runs OPPOSITE to mask
 * size — P1 `['lead','antagonist','support']` is the WEAKEST promise and P2-lead
 * `['lead']` the strongest — so a superset test would silently accept every
 * downgrade and refuse every upgrade.
 *
 * COUNT (Owner, 2026-09-23): the substitute covers at least the unfulfilled
 * obligation, `count - progress`. Completed work is neither erased nor recounted.
 *
 * TRUST is a LABEL test, never a driver count: `label()` reads
 * `negative >= 2 && negative > positives`, so a genuinely Distrusted record can
 * still carry a positive driver.
 *
 * THE WINDOW OPENS AFTER THE WEEK IT IS AGREED, `windowStartWeek > week`. A
 * substitute is a FORWARD obligation, and `qualifyingTakes` (`:637-641`) excludes
 * only `take.week < windowStartWeek`, so a window opening ON the waiver week
 * inherits every take that already served the ORIGINAL: promise two, deliver one,
 * waive for a one-picture substitute opening on the delivered take's own week, owe
 * nothing further and collect a SATISFIED for free. Measured live on
 * `genuine-v31-part-served-p1`, not reasoned. The comparison rather than a scan
 * over `firstTakes` is deliberate: a take scheduled to land LATER in the same week
 * would still be credited to a window opening at `week`, so a scan closes the
 * instance and this closes the class.
 *
 * EVERY BRANCH RETURNS ITS OWN SENTENCE, distinguished within its first six
 * characters. The refusals overlap by design — an identical substitute carries the
 * original's window, which has usually already opened, so both that rule and the
 * window rule fire on it — and a caller that publishes or asserts WHICH refusal it
 * got must not have two of them collapse under truncation.
 */
export function waiverAccepted(
  state: GameState,
  promise: ProfessionalPromise,
  substitute: PromiseAttachment,
  week: number,
): string | null {
  const shapeRefusal = opportunityPredicateRefusal(substitute.family, substitute.predicate)
  if (shapeRefusal !== null) return shapeRefusal
  // Predicate shape selects the work domain; historical count-only P3 remains
  // cast work. Neither domain has a defined exchange rate for the other.
  const directing = isDirectorPredicate(promise.predicate)
  if (directing !== isDirectorPredicate(substitute.predicate)) {
    return 'directing and cast work cannot substitute for one another'
  }
  // `evaluable()`, both halves, for their two separate reasons. A terminal
  // promise must not be waived because `settle()` would overwrite an outcome the
  // "TERMINAL and emitted ONCE" law froze; an UNBOUND one because B.1 mints no
  // outcome for an offer nobody took.
  if (promise.outcome !== null) {
    return `this promise already settled ${promise.outcome}, and a terminal outcome is never rewritten`
  }
  if (promise.contractId === null) {
    return 'nobody took up this promise, so there is no commitment to waive'
  }
  const interval = contractInterval(state, promise)
  if (interval === null) {
    return 'the employment contract this promise rode in on is no longer on the record'
  }
  if (identicalSubstitute(promise, substitute)) {
    return 'an identical substitute changes nothing this studio owes'
  }
  if (substitute.windowStartWeek <= week) {
    return 'a substitute is a forward obligation, and this window opens no later than the week of the waiver'
  }
  const promised = promiseCastSlots(promise)
  if (!directing && !promiseCastSlots({ predicate: substitute.predicate }).every((slot) => promised.includes(slot))) {
    return 'the part offered is weaker than the part promised'
  }
  const restrictionRefusal = opportunitySubstitutionRefusal(state, promise, substitute)
  if (restrictionRefusal !== null) return restrictionRefusal
  const remaining = promise.predicate.count - promise.progress
  if (substitute.predicate.count < remaining) {
    return `only ${String(substitute.predicate.count)} of the ${String(remaining)} pictures still owed would be covered`
  }
  if (trustDescriptor(state, promise.beneficiaryPersonId, promise.issuerStudioId, week).label === 'Distrusted') {
    return 'this person no longer trusts this studio enough to accept a substitute for what was promised'
  }
  const feasibility = promiseFeasibility(state, substituteDraft(promise, substitute, interval), week)
  if (feasibility.classification !== 'REASONABLY_ACHIEVABLE') {
    return `what remains of the contract cannot reasonably carry the substitute — ${feasibility.bottleneck ?? feasibility.classification}`
  }
  return null
}

/**
 * §1's second road: the player WAIVES an open promise by offering a substitute
 * the person accepts in its place. The original settles WAIVED through the
 * existing `settle()` — one `promiseOutcome` receipt, no second kind invented —
 * keeping its `progress` and `evidenceRefs`, and the substitute binds to the SAME
 * contract in the same step.
 *
 * REFUSAL IS CLEAN AND LOUD: the reason is thrown before any successor is built,
 * so the original promise and the whole game state are untouched. Nothing is
 * staged for a later save to reject.
 *
 * The substitute is minted BOUND (`contractId` from the original, `outcome: null`,
 * so `evaluable()` admits it on the next weekly pass) and never travels through
 * `attachPromise`: no proposal is created and no market case is opened. It starts
 * at `progress: 0` with `evidenceRefs: []` — the original's delivered takes are
 * not swept in (Owner: "without erasing completed work or counting it again").
 *
 * Pure and RNG-free like every other verb in this module.
 */
export function waivePromise(
  state: GameState,
  draft: { promiseId: string; substitute: PromiseAttachment },
): GameState {
  requirePromiseRoots(state)
  const week = state.market.tick
  const promise = state.promises.find((p) => p.promiseId === draft.promiseId)
  if (promise === undefined) {
    throw new Error(`promises: no promise "${draft.promiseId}" to waive`)
  }
  const refusal = waiverAccepted(state, promise, draft.substitute, week)
  if (refusal !== null) {
    throw new Error(`promises: this person did not accept the substitute — ${refusal}`)
  }
  const interval = contractInterval(state, promise)
  if (interval === null) {
    throw new Error(`promises: contract "${String(promise.contractId)}" is no longer on the record`)
  }
  const feasibilityReceipt = promiseFeasibility(state, substituteDraft(promise, draft.substitute, interval), week)
  const substituteId = `promise-${String(state.promises.length)}`
  // `progress` and `evidenceRefs` are ABSENT from the settlement, so the waived
  // original keeps both (`settle`'s `next` is Partial; the BROKEN branch
  // recomputes progress, this one deliberately does not).
  const settled = settle(state, promise, {
    outcome: 'WAIVED',
    outcomeCause: `this person accepted the substitute promise "${substituteId}" in place of it`,
    outcomeEventId: null,
    // Save V32's typed link, on the WAIVED original and nowhere else. The prose
    // above stays because every terminal branch states a cause; it is not what
    // a reader resolves the successor by.
    supersededByPromiseId: substituteId,
  }, week, 'a promise to this person was waived for a substitute the person accepted')
  const base = {
    promiseId: substituteId,
    version: feasibilityReceipt.rulesVersion,
    issuerStudioId: promise.issuerStudioId,
    beneficiaryPersonId: promise.beneficiaryPersonId,
    windowStartWeek: draft.substitute.windowStartWeek,
    dueWeekExclusive: draft.substitute.dueWeekExclusive,
    feasibilityReceipt,
    progress: 0,
    evidenceRefs: [],
    outcome: null,
    outcomeWeek: null,
    outcomeCause: null,
    outcomeEventId: null,
    contractId: promise.contractId,
    // The link points backwards only: the substitute supersedes nothing.
    supersededByPromiseId: null,
  }
  const substitute: ProfessionalPromise = isDirectorPredicate(draft.substitute.predicate)
    ? { ...base, family: 'DIRECTING_COUNT', predicate: { kind: 'directorCount', count: draft.substitute.predicate.count } }
    : isOpportunityPredicate(draft.substitute.predicate)
    ? draft.substitute.predicate.kind === 'genreOpportunity'
      ? { ...base, family: 'PREFERRED_GENRE_OPPORTUNITY', predicate: { ...draft.substitute.predicate } }
      : { ...base, family: 'SPECIFIC_PROJECT', predicate: { ...draft.substitute.predicate } }
    : 'kind' in draft.substitute.predicate && draft.substitute.predicate.kind === 'castRoleCount'
    ? {
        ...base,
        family: 'LEAD_OR_SIGNIFICANT_ROLE_COUNT',
        predicate: {
          kind: 'castRoleCount',
          count: draft.substitute.predicate.count,
          seatClass: draft.substitute.predicate.seatClass,
        },
      }
    : { ...base, family: draft.substitute.family, predicate: { count: draft.substitute.predicate.count } }
  return { ...settled, promises: [...settled.promises, substitute] }
}

// ── §4.5 trust: professional memory, DERIVED ON READ ────────────────────────

export type TrustLabel = 'Reliable' | 'Mixed record' | 'Distrusted'
export type TrustDriverKind = 'promiseKept' | 'promiseBroken' | 'terminatedEarly' | 'ranToEnd' | 'cancelledAfterFirstTake'
export type TrustDriver = { kind: TrustDriverKind; week: number; positive: boolean; reason: string }
export type TrustDescriptor = { label: TrustLabel; drivers: readonly TrustDriver[]; scope: 'person' | 'studio' }

/**
 * The FOUR driver kinds of §4.5 (the fourth splits into the two cancellation
 * cases the accepted records can witness), for one (person, studio) pair. Nothing
 * is persisted: every driver is read from a fact some other owner already holds —
 * this module's own promise outcomes, P12's termination receipts and employment
 * intervals, and the first-take root joined against what became of the picture.
 *
 * THE RECORDING BOUNDARY (Q3, no behavioral backfill): drivers dated before the
 * campaign's own recording boundary are not read at all, so a migrated save never
 * acquires a professional history it never recorded.
 */
export function trustDrivers(
  state: GameState,
  personId: string | null,
  studioId: string,
  week: number,
): readonly TrustDriver[] {
  const boundary = state.studioHistory.recordingStartedWeek
  const horizon = week - TRUST_HORIZON_WEEKS
  const drivers: TrustDriver[] = []
  // Inside the recency horizon and at or after the campaign's own recording
  // boundary. Nothing is filtered by "not in the future": a driver's week comes
  // from the record that produced it, and second-guessing that here would hide a
  // real clock fault instead of reporting it.
  const keep = (at: number): boolean => at >= boundary && at > horizon

  for (const promise of state.promises) {
    if (promise.issuerStudioId !== studioId) continue
    if (personId !== null && promise.beneficiaryPersonId !== personId) continue
    if (promise.outcome === null || promise.outcomeWeek === null || !keep(promise.outcomeWeek)) continue
    if (promise.outcome === 'SATISFIED') {
      drivers.push({ kind: 'promiseKept', week: promise.outcomeWeek, positive: true, reason: 'kept a promise' })
    } else if (promise.outcome === 'BROKEN') {
      drivers.push({ kind: 'promiseBroken', week: promise.outcomeWeek, positive: false, reason: 'broke a promise' })
    }
  }

  const hollywood = state.hollywood
  if (hollywood !== null) {
    for (const row of hollywood.employment) {
      if (row.studioId !== studioId) continue
      if (personId !== null && row.terms.talentId !== personId) continue
      if (row.endedWeek === null || !keep(row.endedWeek)) continue
      const terminated = hollywood.receipts.some((r) => r.kind === 'employment' && r.contractId === row.contractId
        && r.toStudioId === null && r.reason === 'termination')
      if (terminated) drivers.push({ kind: 'terminatedEarly', week: row.endedWeek, positive: false, reason: 'ended a contract early' })
      else if (row.endedWeek >= row.terms.endWeekExclusive) {
        drivers.push({ kind: 'ranToEnd', week: row.endedWeek, positive: true, reason: 'ran a contract to its end' })
      }
    }
  }

  // A picture that filmed and then vanished without a release was cancelled after
  // its first take — derived from the two records that already exist (the first
  // take, and what became of the picture), never a new one.
  const live = new Set<string>()
  for (const p of state.studio.activeProductions) live.add(p.id)
  for (const f of state.studio.releasedFilms) live.add(f.productionId)
  for (const business of hollywood?.businesses ?? []) for (const p of business.productions) live.add(p.id)
  for (const f of hollywood?.films ?? []) live.add(f.filmId)
  for (const take of state.firstTakes) {
    if (take.studioId !== studioId || live.has(take.productionId) || !keep(take.week)) continue
    // The recorded Director and cast seats are both professional conduct.
    if (personId !== null && take.directorId !== personId
      && !CAST_SLOTS.some((slot) => take.cast[slot] === personId)) continue
    drivers.push({ kind: 'cancelledAfterFirstTake', week: take.week, positive: false, reason: 'cancelled a picture after filming began' })
  }
  return drivers.sort((a, b) => (a.week === b.week ? a.kind.localeCompare(b.kind) : b.week - a.week))
}

function label(drivers: readonly TrustDriver[]): TrustLabel {
  const positive = drivers.filter((d) => d.positive).length
  const negative = drivers.length - positive
  if (negative === 0) return positive > 0 ? 'Reliable' : 'Mixed record'
  return negative >= TRUST_DISTRUST_MIN_NEGATIVES && negative > positive ? 'Distrusted' : 'Mixed record'
}

/**
 * §4.5's public descriptor: per (person, studio), with the STUDIO-LEVEL aggregate
 * as the fallback when this pair has no shared history at all. Never a hidden
 * multiplier and never a persisted meter — two reads of the same state give the
 * same label, and no tick writes one.
 */
export function trustDescriptor(state: GameState, personId: string, studioId: string, week: number): TrustDescriptor {
  const own = trustDrivers(state, personId, studioId, week)
  if (own.length > 0) return { label: label(own), drivers: own.slice(0, 3), scope: 'person' }
  return studioTrustDescriptor(state, studioId, week)
}

/** The public studio aggregate, labelled from ALL drivers before the display cap. */
export function studioTrustDescriptor(state: GameState, studioId: string, week: number): TrustDescriptor {
  const aggregate = trustDrivers(state, null, studioId, week)
  return { label: label(aggregate), drivers: aggregate.slice(0, 3), scope: 'studio' }
}

// ── the V29 save-root validator (R22: no authority without its backing fact) ──

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/**
 * The two V29 roots, validated where the save boundary can name the real fault:
 * every first take is dated inside the campaign, once per production, with an
 * in-state ordinal id. Proposals, contracts, outcomes and qualifying evidence
 * resolve to their actual records, including the parties those records name.
 * A first take may serve several beneficiaries; each outcome has its own receipt.
 */
export function validatePromiseRoots(state: unknown): void {
  validatePromiseRootsForVersion(state, 29)
}

/** V30 validates selected P2 seats without reinterpreting legacy count-only
 * records. V29 still invokes the exact count-only policy and error prefix. */
export function validatePromiseRootsV30(state: unknown): void {
  validatePromiseRootsForVersion(state, 30)
}

/** Current-only promise policy. Historical public readers never pass39. The
 * caller separately validates the V32 link before projecting its shared rows. */
export function validatePromiseRootsV39(state: unknown): void {
  validatePromiseRootsForVersion(state, 39)
}

export function validatePromiseRootsV40(state: unknown): void {
  validatePromiseRootsForVersion(state, 40)
}

function validatePromiseRootsForVersion(state: unknown, saveVersion: 29 | 30 | 39 | 40): void {
  const fail = (message: string): never => {
    throw new Error(`validateSaveV${String(saveVersion)}: ${message}`)
  }
  if (!isRecord(state)) return fail('state is not a plain object')
  const takes = state.firstTakes
  const promises = state.promises
  if (!Array.isArray(takes)) return fail('state.firstTakes is not an array')
  if (!Array.isArray(promises)) return fail('state.promises is not an array')

  const record = (value: unknown, at: string): Record<string, unknown> => {
    if (!isRecord(value)) return fail(`${at} is not a plain object`)
    return value
  }
  const exact = (row: Record<string, unknown>, keys: readonly string[], at: string): void => {
    for (const key of keys) if (!Object.hasOwn(row, key)) fail(`${at}.${key} is missing`)
    for (const key of Object.keys(row)) if (!keys.includes(key)) fail(`${at}.${key} is not a field of this record`)
  }
  const text = (value: unknown, at: string): string => {
    if (typeof value !== 'string' || value.trim() === '') return fail(`${at} must be a non-empty string`)
    return value
  }
  const nonnegative = (value: unknown, at: string): number => {
    if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) return fail(`${at} must be a non-negative integer`)
    return value
  }
  const currentWeek = nonnegative(record(state.market, 'state.market').tick, 'state.market.tick')
  const boundary = nonnegative(record(state.studioHistory, 'state.studioHistory').recordingStartedWeek,
    'state.studioHistory.recordingStartedWeek')
  const recordedWeek = (value: unknown, at: string): number => {
    const week = nonnegative(value, at)
    if (week < boundary || week > currentWeek) return fail(`${at} is outside this campaign's recording interval`)
    return week
  }

  const hollywood = isRecord(state.hollywood) ? state.hollywood : null
  const identities = hollywood !== null && Array.isArray(hollywood.identities) ? hollywood.identities : []
  const entered = new Set(identities
    .filter((s): s is Record<string, unknown> => isRecord(s) && s.enteredWeek !== null)
    .map((s) => String(s.studioId)))
  const people = new Set((Array.isArray(state.talent) ? state.talent : [])
    .filter(isRecord).map((person) => person.id))
  const personId = (value: unknown, at: string): string => {
    const id = text(value, at)
    if (!people.has(id)) return fail(`${at} does not name a person of this world`)
    return id
  }
  const studioId = (value: unknown, at: string): string => {
    const id = text(value, at)
    if (!entered.has(id)) return fail(`${at} is not an entered studio of this world`)
    return id
  }
  const employment = hollywood !== null && Array.isArray(hollywood.employment)
    ? hollywood.employment.filter(isRecord) : []
  const market = record(state.talentMarket, 'state.talentMarket')
  if (!Array.isArray(market.proposals)) return fail('state.talentMarket.proposals is not an array')
  if (!Array.isArray(market.receipts)) return fail('state.talentMarket.receipts is not an array')
  const receiptsById = new Map(market.receipts.filter(isRecord).map((r) => [r.eventId, r]))

  const seenProduction = new Set<string>()
  const takesById = new Map<string, FirstTakeReceipt>()
  for (let i = 0; i < takes.length; i++) {
    const at = `state.firstTakes[${String(i)}]`
    const row = record(takes[i], at)
    exact(row, ['eventId', 'week', 'productionId', 'studioId', 'directorId', 'cast'], at)
    if (row.eventId !== `first-take-event-${String(i)}`) return fail(`${at}.eventId is not this root's ordinal id`)
    recordedWeek(row.week, `${at}.week`)
    const productionId = text(row.productionId, `${at}.productionId`)
    if (seenProduction.has(productionId)) return fail(`${at} records a second first take for production "${productionId}"`)
    seenProduction.add(productionId)
    studioId(row.studioId, `${at}.studioId`)
    personId(row.directorId, `${at}.directorId`)
    const cast = record(row.cast, `${at}.cast`)
    exact(cast, CAST_SLOTS, `${at}.cast`)
    for (const slot of CAST_SLOTS) personId(cast[slot], `${at}.cast.${slot}`)
    // A cancellation can remove the production. Its durable take remains valid
    // without reconstructing a production that no longer exists.
    takesById.set(row.eventId as string, row as unknown as FirstTakeReceipt)
  }

  if (saveVersion === 40) validateFirstTakeSubjects(state)
  const subjects = saveVersion === 40 ? (state as unknown as GameState).firstTakeSubjects.facts : []
  const promisesById = new Map<string, ReadablePromise>()
  const outcomeEvents = new Set<string>()
  for (let i = 0; i < promises.length; i++) {
    const at = `state.promises[${String(i)}]`
    const row = record(promises[i], at)
    exact(row, ['promiseId', 'family', 'version', 'issuerStudioId', 'beneficiaryPersonId', 'predicate',
      'windowStartWeek', 'dueWeekExclusive', 'feasibilityReceipt', 'progress', 'evidenceRefs',
      'outcome', 'outcomeWeek', 'outcomeCause', 'outcomeEventId', 'contractId'], at)
    const promiseId = text(row.promiseId, `${at}.promiseId`)
    if (promisesById.has(promiseId)) return fail(`${at}.promiseId "${promiseId}" is recorded twice`)
    if (!['APPEARANCE_COUNT', 'LEAD_OR_SIGNIFICANT_ROLE_COUNT', 'DIRECTING_COUNT', 'PREFERRED_GENRE_OPPORTUNITY', 'SPECIFIC_PROJECT']
      .includes(String(row.family))) return fail(`${at}.family is not in the promise catalogue`)
    if (nonnegative(row.version, `${at}.version`) < 1) return fail(`${at}.version must be positive`)
    studioId(row.issuerStudioId, `${at}.issuerStudioId`)
    personId(row.beneficiaryPersonId, `${at}.beneficiaryPersonId`)
    const predicate = record(row.predicate, `${at}.predicate`)
    let qualifyingSlots: readonly CastSlot[] = CAST_SLOTS
    const director = saveVersion >= 39 && predicate.kind === 'directorCount'
    const opportunity = saveVersion === 40 && (predicate.kind === 'genreOpportunity' || predicate.kind === 'projectOpportunity')
    if (saveVersion >= 39 && Object.hasOwn(predicate, 'kind')
      && !opportunity && predicate.kind !== 'directorCount' && predicate.kind !== 'castRoleCount') {
      return fail(`${at}.predicate.kind is not a supported promise predicate`)
    }
    if (opportunity) {
      const refusal = opportunityPredicateRefusal(String(row.family), predicate as unknown as PromisePredicate)
      if (refusal !== null) return fail(`${at}.predicate ${refusal}`)
      if (row.version !== OPPORTUNITY_PROMISE_RULES_VERSION) return fail(`${at}.version must be opportunity revision7`)
      qualifyingSlots = opportunitySlots(predicate as unknown as OpportunityPredicate)
      if (predicate.kind === 'projectOpportunity' && !takeSubjectOwner(state as unknown as GameState, String(row.issuerStudioId))
        ?.development.projects.some(project => project.id === predicate.scriptProjectId)) {
        return fail(`${at}.predicate.scriptProjectId does not name a retained project of its issuing studio`)
      }
    } else if (director) {
      exact(predicate, ['kind', 'count'], `${at}.predicate`)
      if (row.family !== 'DIRECTING_COUNT') return fail(`${at}.predicate.directorCount is only valid for DIRECTING_COUNT`)
      if (row.version !== DIRECTING_PROMISE_RULES_VERSION && !(saveVersion === 40 && row.version === OPPORTUNITY_PROMISE_RULES_VERSION)) return fail(`${at}.version must be a supported Director revision`)
      qualifyingSlots = []
    } else if (saveVersion !== 29 && Object.hasOwn(predicate, 'kind')) {
      exact(predicate, ['kind', 'count', 'seatClass'], `${at}.predicate`)
      if (predicate.kind !== 'castRoleCount') return fail(`${at}.predicate.kind is not a supported promise predicate`)
      if (row.family !== 'LEAD_OR_SIGNIFICANT_ROLE_COUNT') {
        return fail(`${at}.predicate.castRoleCount is only valid for LEAD_OR_SIGNIFICANT_ROLE_COUNT`)
      }
      if (predicate.seatClass !== 'lead' && predicate.seatClass !== 'leadOrAntagonist') {
        return fail(`${at}.predicate.seatClass is not a selected P2 seat class`)
      }
      qualifyingSlots = predicate.seatClass === 'lead' ? ['lead'] : ['lead', 'antagonist']
    } else {
      // All legacy catalogue families retain generic-cast evidence. Neither
      // root.version nor receipt.rulesVersion selects a new predicate shape.
      exact(predicate, ['count'], `${at}.predicate`)
    }
    const count = nonnegative(predicate.count, `${at}.predicate.count`)
    if (count < 1) return fail(`${at}.predicate.count must be a whole picture`)
    const progress = nonnegative(row.progress, `${at}.progress`)
    if (progress > count) return fail(`${at}.progress is outside its own predicate`)
    const start = nonnegative(row.windowStartWeek, `${at}.windowStartWeek`)
    const due = nonnegative(row.dueWeekExclusive, `${at}.dueWeekExclusive`)
    if (due <= start) return fail(`${at} closes before it opens`)

    const feasibility = record(row.feasibilityReceipt, `${at}.feasibilityReceipt`)
    exact(feasibility, ['classification', 'bottleneck', 'inputsDigest', 'rulesVersion', 'week'], `${at}.feasibilityReceipt`)
    if (!['REASONABLY_ACHIEVABLE', 'FRAGILE', 'IMPOSSIBLE'].includes(String(feasibility.classification))) {
      return fail(`${at}.feasibilityReceipt.classification is not in the catalogue`)
    }
    if (feasibility.classification === 'REASONABLY_ACHIEVABLE') {
      if (feasibility.bottleneck !== null) return fail(`${at}.feasibilityReceipt names a bottleneck for an achievable promise`)
    } else text(feasibility.bottleneck, `${at}.feasibilityReceipt.bottleneck`)
    if (!/^[0-9a-f]{16}$/.test(text(feasibility.inputsDigest, `${at}.feasibilityReceipt.inputsDigest`))) {
      return fail(`${at}.feasibilityReceipt.inputsDigest is not a feasibility digest`)
    }
    if (nonnegative(feasibility.rulesVersion, `${at}.feasibilityReceipt.rulesVersion`) < 1) {
      return fail(`${at}.feasibilityReceipt.rulesVersion must be positive`)
    }
    if (opportunity && feasibility.rulesVersion !== OPPORTUNITY_PROMISE_RULES_VERSION) {
      return fail(`${at}.feasibilityReceipt.rulesVersion must be opportunity revision7`)
    }
    if (director && feasibility.rulesVersion !== DIRECTING_PROMISE_RULES_VERSION
      && !(saveVersion === 40 && feasibility.rulesVersion === OPPORTUNITY_PROMISE_RULES_VERSION)) {
      return fail(`${at}.feasibilityReceipt.rulesVersion must be a supported Director revision`)
    }
    recordedWeek(feasibility.week, `${at}.feasibilityReceipt.week`)

    if (row.contractId !== null) {
      const contractId = text(row.contractId, `${at}.contractId`)
      const contract = employment.find((e) => e.contractId === contractId)
      if (contract === undefined || !isRecord(contract.terms)
        || contract.studioId !== row.issuerStudioId || contract.terms.talentId !== row.beneficiaryPersonId) {
        return fail(`${at}.contractId does not name this person's employment at the issuing studio`)
      }
      if (due > Number(contract.terms.endWeekExclusive)) return fail(`${at}.contractId ends before the promised window`)
      const contractStart = nonnegative(contract.terms.startWeek, `${at}.contractId start week`)
      if ((director || opportunity) && start < contractStart) return fail(`${at}.windowStartWeek precedes its contractId`)
      if (contractStart > currentWeek) return fail(`${at}.contractId has not started in this campaign`)
      if (row.outcome !== null && Number(row.outcomeWeek) < contractStart) {
        return fail(`${at}.outcomeWeek precedes the contract that carried this promise`)
      }
      // Earlier V29 writers retained the submission receipt and admitted a lower
      // window edge before the contract. Read those facts without inventing a
      // historical freeze. New quote/freeze paths enforce both interval edges.
    }

    if (!Array.isArray(row.evidenceRefs)) return fail(`${at}.evidenceRefs is not an array`)
    const evidence = new Set<string>()
    for (const ref of row.evidenceRefs) {
      const id = text(ref, `${at}.evidenceRefs`)
      if (evidence.has(id)) return fail(`${at}.evidenceRefs repeats a first take`)
      evidence.add(id)
      const take = takesById.get(id)
      if (take === undefined || take.studioId !== row.issuerStudioId
        || !(director ? take.directorId === row.beneficiaryPersonId
          : qualifyingSlots.some((slot) => take.cast[slot] === row.beneficiaryPersonId))
        || take.week < start || take.week >= due
        || (row.outcomeWeek !== null && take.week > Number(row.outcomeWeek))) {
        return fail(`${at}.evidenceRefs does not name a qualifying first take inside this promise's window`)
      }
      if (opportunity && !opportunitySubjectMatches(predicate as unknown as OpportunityPredicate,
        subjects.find(subject => subject.eventId === id))) return fail(`${at}.evidenceRefs does not match its recorded take subject`)
    }
    if (evidence.size > progress) return fail(`${at}.evidenceRefs exceeds its recorded progress`)
    if ((director || opportunity) && evidence.size !== progress) return fail(`${at}.evidenceRefs does not match its recorded progress`)
    promisesById.set(promiseId, row as unknown as ReadablePromise)
    if (row.outcome === null) {
      if (row.outcomeWeek !== null) return fail(`${at} has no outcome but names an outcome week`)
      if (row.outcomeCause !== null || row.outcomeEventId !== null) return fail(`${at} has outcome evidence but no outcome`)
      continue
    }
    if (!['SATISFIED', 'BROKEN', 'WAIVED', 'VOIDED'].includes(String(row.outcome))) {
      return fail(`${at}.outcome "${String(row.outcome)}" is not an outcome of this catalogue`)
    }
    if (row.contractId === null) return fail(`${at} is terminal without a committed contract`)
    const outcomeWeek = recordedWeek(row.outcomeWeek, `${at}.outcomeWeek`)
    text(row.outcomeCause, `${at}.outcomeCause`)
    const eventId = text(row.outcomeEventId, `${at}.outcomeEventId`)
    if (outcomeEvents.has(eventId)) return fail(`${at}.outcomeEventId "${eventId}" records a second outcome`)
    outcomeEvents.add(eventId)
    const outcomeReceipt = receiptsById.get(eventId)
    if (outcomeReceipt === undefined || outcomeReceipt.kind !== 'promiseOutcome'
      || outcomeReceipt.talentId !== row.beneficiaryPersonId || outcomeReceipt.studioId !== row.issuerStudioId
      || outcomeReceipt.week !== outcomeWeek) return fail(`${at}.outcomeEventId does not name this promise's own outcome receipt`)
    if (row.outcome === 'SATISFIED' && (progress !== count || evidence.size !== count)) {
      return fail(`${at} is satisfied without the promised number of qualifying first takes`)
    }
    if (row.outcome === 'BROKEN' && progress >= count) return fail(`${at} is broken despite a satisfied predicate`)
  }

  for (let i = 0; i < market.proposals.length; i++) {
    const at = `state.talentMarket.proposals[${String(i)}]`
    const row = record(market.proposals[i], at)
    if (!Array.isArray(row.promises) || row.promises.length > 1) return fail(`${at}.promises must be an array of at most one promise ID`)
    for (const ref of row.promises) {
      const promise = promisesById.get(text(ref, `${at}.promises`))
      if (promise === undefined || promise.issuerStudioId !== row.issuerStudioId
        || promise.beneficiaryPersonId !== row.talentId) return fail(`${at}.promises does not name this proposal's own promise`)
      if (promise.contractId !== null || promise.outcome !== null) return fail(`${at}.promises names an already committed promise`)
    }
  }
}

/**
 * The POSITIVE projection to every version before V29. A world that actually
 * carries a first take or a promise is REFUSED rather than flattened, exactly as
 * `projectTalentMarketPreV28` refuses a case: an envelope that quietly dropped a
 * kept promise would misreport a campaign that honoured one as a campaign that
 * never made it. Lossless exactly when both roots are empty and no proposal
 * carries a promise.
 */
export function projectPromisesPreV29(state: unknown): void {
  if (!isRecord(state)) return
  for (const key of ['firstTakes', 'promises'] as const) {
    const rows = state[key]
    if (Array.isArray(rows) && rows.length > 0) {
      throw new Error(`frozen save projection cannot discard authoritative V29 ${key} (${String(rows.length)} held)`)
    }
  }
  const market = state.talentMarket
  const proposals = isRecord(market) && Array.isArray(market.proposals) ? market.proposals : []
  for (const row of proposals) {
    if (isRecord(row) && Array.isArray(row.promises) && row.promises.length > 0) {
      throw new Error('frozen save projection cannot discard an authoritative V29 promise attached to a proposal')
    }
  }
}

/**
 * The V32 field, validated where the save boundary can name the real fault (R22:
 * no authority without its backing fact). `validateSaveV32` asks this and then
 * hands the frozen V31 chain the row shape V31 knows — an older validator is
 * never taught a newer field and never silently tolerates one.
 *
 * A link is present on every row, is `string | null`, and when it is set it names
 * a DIFFERENT promise of this same campaign, on a row that really settled WAIVED.
 * A non-null link on a live or differently-settled promise would claim a
 * renegotiation that never happened.
 */
export function validateWaivedPromiseLinks(state: unknown): void {
  const fail = (message: string): never => {
    throw new Error(`validateSaveV32: ${message}`)
  }
  if (!isRecord(state)) return fail('state is not a plain object')
  const rows = state.promises
  if (!Array.isArray(rows)) return fail('state.promises is not an array')
  const ids = new Set(rows.filter(isRecord).map((row) => row.promiseId))
  for (let i = 0; i < rows.length; i++) {
    const at = `state.promises[${String(i)}]`
    const row = rows[i]
    if (!isRecord(row)) return fail(`${at} is not a plain object`)
    if (!Object.hasOwn(row, 'supersededByPromiseId')) return fail(`${at}.supersededByPromiseId is missing`)
    const superseded = row.supersededByPromiseId
    if (superseded === null) continue
    if (typeof superseded !== 'string' || superseded.trim() === '') {
      return fail(`${at}.supersededByPromiseId must be a promise id or null`)
    }
    if (superseded === row.promiseId) return fail(`${at}.supersededByPromiseId names itself`)
    if (!ids.has(superseded)) return fail(`${at}.supersededByPromiseId does not name a promise of this world`)
    if (row.outcome !== 'WAIVED') {
      return fail(`${at}.supersededByPromiseId names a substitute for a promise that was not waived`)
    }
  }
}

/** Current39-only relations, after complete row/contract/evidence admission.
 * The frozen V32 reader still admits its historical links, including WAIVED
 * rows lifted with no successor. Explicit Director work can only be exchanged
 * for a new forward obligation in that same domain and employment contract. */
export function validateDirectorWaiverLinks(promises: readonly ProfessionalPromise[]): void {
  if (!promises.some(isDirectorPromise)) return
  const indices = new Map(promises.map((row, index) => [row.promiseId, index] as const))
  const incoming = new Set<string>()
  const fail = (index: number, reason: string): never => {
    throw new Error(`validateSaveV39: state.promises[${String(index)}].supersededByPromiseId ${reason}`)
  }
  for (let i = 0; i < promises.length; i++) {
    const original = promises[i]!
    const id = original.supersededByPromiseId
    if (id === null) {
      if (isDirectorPromise(original) && original.outcome === 'WAIVED') {
        fail(i, 'must name the successor of a waived Director promise')
      }
      continue
    }
    const successorIndex = indices.get(id) ?? -1
    const successor = promises[successorIndex]
    // The complete frozen link proof already requires an existing target.
    if (successor === undefined) return fail(i, 'does not name an existing successor')
    if (!isDirectorPromise(original) && !isDirectorPromise(successor)) continue
    if (!isDirectorPromise(original) || !isDirectorPromise(successor)) {
      fail(i, 'cannot exchange Director and cast predicate domains')
    }
    if (successorIndex <= i || incoming.has(id)) {
      fail(i, 'must name a later successor belonging to exactly one waiver')
    }
    incoming.add(id)
    if (successor.contractId !== original.contractId
      || successor.beneficiaryPersonId !== original.beneficiaryPersonId
      || successor.issuerStudioId !== original.issuerStudioId) {
      fail(i, 'successor must preserve the same contract, beneficiary and issuer')
    }
    if (original.outcomeWeek === null || successor.feasibilityReceipt.week !== original.outcomeWeek
      || successor.windowStartWeek <= original.outcomeWeek) {
      fail(i, 'successor must be agreed at the waiver and carry a forward window')
    }
    if (successor.feasibilityReceipt.classification !== 'REASONABLY_ACHIEVABLE') {
      fail(i, 'successor must carry an accepted reasonably achievable receipt')
    }
    if (successor.predicate.count < original.predicate.count - original.progress) {
      fail(i, 'successor does not cover the remaining pictures owed')
    }
  }
}

/** Called only after complete40 admission, with full material and employment authority. Typed by
 * the era it proves: save.ts hands it the V40/V41 state, which carries no later root. */
export function validateOpportunityWaiverLinks(state: GameStateV40): void {
  const indices = new Map(state.promises.map((row, i) => [row.promiseId, i] as const))
  const incoming = new Set<string>()
  const fail = (id: string, reason: string): never => { throw new Error(`validateSaveV40: opportunity waiver ${id} ${reason}`) }
  for (let i = 0; i < state.promises.length; i++) {
    const original = state.promises[i]!, id = original.supersededByPromiseId
    if (id === null) {
      if (isOpportunityPredicate(original.predicate) && original.outcome === 'WAIVED') fail(original.promiseId, 'must name its successor')
      continue
    }
    const successorIndex = indices.get(id) ?? -1, successor = state.promises[successorIndex]
    if (successor === undefined) return fail(original.promiseId, 'has no successor')
    if (!isOpportunityPredicate(original.predicate) && !isOpportunityPredicate(successor.predicate)) continue
    if (successorIndex <= i || incoming.has(id)) fail(original.promiseId, 'must have one later successor')
    incoming.add(id)
    if (successor.contractId !== original.contractId || successor.issuerStudioId !== original.issuerStudioId
      || successor.beneficiaryPersonId !== original.beneficiaryPersonId) fail(original.promiseId, 'must preserve contract, issuer and beneficiary')
    if (original.outcomeWeek === null || successor.feasibilityReceipt.week !== original.outcomeWeek
      || successor.windowStartWeek <= original.outcomeWeek) fail(original.promiseId, 'must carry a forward obligation agreed at the waiver')
    if (successor.feasibilityReceipt.classification !== 'REASONABLY_ACHIEVABLE') fail(original.promiseId, 'must have an accepted achievable receipt')
    if (isDirectorPredicate(original.predicate) !== isDirectorPredicate(successor.predicate)
      || !promiseCastSlots(successor).every(slot => promiseCastSlots(original).includes(slot))) fail(original.promiseId, 'cannot weaken the work domain or cast class')
    const restriction = opportunitySubstitutionRefusal(state, original, successor)
    if (restriction !== null) fail(original.promiseId, restriction)
    if (successor.predicate.count < original.predicate.count - original.progress) fail(original.promiseId, 'does not cover the remaining work')
  }
}

/**
 * The POSITIVE projection to every version before V32, the device
 * `projectPromisesPreV29` and `projectRelationshipsPreV31` both use: a waiver
 * link is REFUSED rather than dropped, and the question is asked BEFORE the
 * envelope is validated, so a world that really waived a promise is refused as a
 * DOWNGRADE and not as a shape complaint about a field V31 has no schema for.
 * Lossless exactly when no promise names a substitute.
 */
export function projectPromisesPreV32(state: unknown): void {
  if (!isRecord(state)) return
  const rows = state.promises
  if (!Array.isArray(rows)) return
  for (const row of rows) {
    if (!isRecord(row)) continue
    const superseded = row.supersededByPromiseId
    if (superseded !== undefined && superseded !== null) {
      throw new Error(
        `frozen save projection cannot discard the substitute "${String(superseded)}" a waived promise was superseded by`,
      )
    }
  }
}
