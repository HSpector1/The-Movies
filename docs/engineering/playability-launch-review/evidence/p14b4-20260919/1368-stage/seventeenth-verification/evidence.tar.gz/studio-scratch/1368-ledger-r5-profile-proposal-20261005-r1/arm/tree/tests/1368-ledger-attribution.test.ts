// Separate 416-week observation. Original ledger tests and protected pins are unchanged.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { appendFileSync, lstatSync, readFileSync, realpathSync, writeFileSync } from 'node:fs'
import { dirname, isAbsolute, resolve } from 'node:path'
import { it, expect, vi } from 'vitest'
import * as industry from '../src/core/hollywoodTick.js'
import * as market from '../src/core/talentMarket.js'
import { retirementRecordFor } from '../src/core/careerLifecycle.js'
import { renewalWindowOpen } from '../src/core/employment.js'
import { makeSave, migrateToLive, stableStringify } from '../src/core/save.js'
import { tick } from '../src/core/tick.js'
import type { GameState } from '../src/core/types.js'
import { LEDGER_END_WEEK, LEDGER_SEEDS, relationships, runLedger, settlementDigest } from './1368-ledger-original.js'
const sha = (value: string | Uint8Array) => createHash('sha256').update(value).digest('hex')
const copy = <T>(value: T): T => structuredClone(value)
type ProfileName = 'snap' | 'admit' | 'owners' | 'windowFacts' | 'changedCases'
const profileNames: ProfileName[] = ['snap', 'admit', 'owners', 'windowFacts', 'changedCases']
const profileTotals = Object.fromEntries(profileNames.map(name => [name, { calls: 0, inclusiveNs: 0n, exclusiveNs: 0n }])) as Record<ProfileName, { calls: number; inclusiveNs: bigint; exclusiveNs: bigint }>
const profileStack: { started: bigint; childNs: bigint }[] = []
function measured<T>(name: ProfileName, operation: () => T): T {
  const parent = profileStack.at(-1)
  const frame = { started: process.hrtime.bigint(), childNs: 0n }
  profileStack.push(frame)
  try { return operation() }
  finally {
    const elapsed = process.hrtime.bigint() - frame.started
    assert.equal(profileStack.pop(), frame)
    const total = profileTotals[name]
    total.calls++
    total.inclusiveNs += elapsed
    total.exclusiveNs += elapsed - frame.childNs
    if (parent !== undefined) parent.childNs += elapsed
  }
}
function profileRow(week: number, started: bigint) {
  assert.equal(profileStack.length, 0)
  return { week, elapsedSeconds: Number(process.hrtime.bigint() - started) / 1e9,
    functions: Object.fromEntries(profileNames.map(name => {
      const total = profileTotals[name]
      assert.ok(total.inclusiveNs >= total.exclusiveNs && total.exclusiveNs >= 0n)
      return [name, { calls: total.calls, inclusiveNs: String(total.inclusiveNs), exclusiveNs: String(total.exclusiveNs) }]
    })) }
}
function rawSnap(value: unknown): string {
  const ancestors = new Set<object>()
  const visit = (v: unknown): unknown => {
    if (v === null) return ['null']
    if (v === undefined) return ['undefined']
    if (typeof v === 'number') return ['number', Object.is(v, -0) ? '-0' : String(v)]
    if (typeof v === 'string' || typeof v === 'boolean' || typeof v === 'bigint') return [typeof v, String(v)]
    assert(typeof v === 'object', 'unsupported full-state value')
    assert(!ancestors.has(v), 'cyclic full-state value')
    ancestors.add(v)
    try {
      assert.equal(Object.getOwnPropertySymbols(v).length, 0, 'unsupported symbol state keys')
      if (v instanceof Map) return ['Map', [...v].map(([k, x]) => [visit(k), visit(x)])]
      if (v instanceof Set) return ['Set', [...v].map(visit)]
      if (v instanceof Date) return ['Date', v.toISOString()]
      if (ArrayBuffer.isView(v)) return [v.constructor.name, Buffer.from(v.buffer, v.byteOffset, v.byteLength).toString('base64')]
      if (v instanceof ArrayBuffer) return ['ArrayBuffer', Buffer.from(v).toString('base64')]
      if (Array.isArray(v)) return ['Array', Array.from({ length: v.length }, (_, i) => i in v ? visit(v[i]) : ['hole'])]
      const proto: unknown = Object.getPrototypeOf(v)
      assert(proto === Object.prototype || proto === null, 'unsupported full-state object prototype')
      const record = v as Record<string, unknown>
      return [proto === null ? 'null-object' : 'object', Object.keys(record).sort().map(k => [k, visit(record[k])])]
    } finally { ancestors.delete(v) }
  }
  return JSON.stringify(visit(value))
}
function snap(value: unknown): string { return measured('snap', () => rawSnap(value)) }

const SOURCE_PINS = {
  "C0": {
    "src/core/actions.ts": "88acf224e5bf9dbe7234eb6933d0f7e02bea55fc1ac68b65711f4b7d54e1898f",
    "src/core/agents.ts": "ee68473f551a90541d5cb8d64ce39499649c4848034d2f7403ca44e048234a73",
    "src/core/aging.ts": "f0fa2af61d7b8cfaff9923be46c07c21134f899ec2321dccc618a1160aa75c34",
    "src/core/blueprintRequirements.ts": "abf32723f6530c8d2fda94067d6b793daab33154e636e2e906587211f4d456e0",
    "src/core/boundedStableSort.ts": "87861f3ceefe2b2a9163a34bd9762a991d5c8a7f1640b84fbe6d1133f33ff964",
    "src/core/broadcast.ts": "81809e230570dd795bef921716a2c300dd062298878705e5d5b6c4582c667e85",
    "src/core/calendar.ts": "c54fe83ab161d4c80727c3ece021e6340eda3a7ff0bf134f5288d76de8f811ef",
    "src/core/campaignLegacy.ts": "b958691c971e36be17a53726224c21bcfc2081d6119880c07519f88c6f71331f",
    "src/core/candidates.ts": "85a6d18e32cfca3e554977825ea06f10d2928eca68331a1b7b801ee320fe4104",
    "src/core/careerLifecycle.ts": "338510e570d2ace8bdeaa24b989fe7783c2d4e4250e1929eb56fc8f149c5d1f6",
    "src/core/castingPackageReadModel.ts": "0a6615639ce224665f059790d39f33d95270398fbd1158d310647a7aaf0f94c6",
    "src/core/castingReadModel.ts": "56e0021c14337f333863be25ade1450ec59503b94e3ccb257ff31ceed5deb1c8",
    "src/core/castingSessions.ts": "497a8a32152e556378db96d8363be6de9a0719f2eed1fbec4a4fcfe222cf3a3b",
    "src/core/construction.ts": "24cad343abe3122e919e4dae57b85bdac24418a360723a3055b76ae82fefdf36",
    "src/core/corporateCondition.ts": "428f2e59c141ad765b0a04cb032de7801a0006cfe3ddd5953ef429a835fadf44",
    "src/core/data/screenplay.ts": "176f5fd2c0f01d2af16ce0c6a3e77344bd6030a9b3660232f17a14e4baae15ad",
    "src/core/data/wordlists.ts": "6642296c7a0a4d385c6eb00e7b9ff4eb3213f72a6799b197549cba23718ebfac",
    "src/core/development.ts": "ce37f726f18270f6d9d0aa6444ed23104cf963418365f00192a13f5fc55153fc",
    "src/core/economy.ts": "caa6f20444be1544d64e2226f8eb89823c8d787c1460473169e0954ef15d0e10",
    "src/core/economyView.ts": "64c51d1e58ff994dea3250db3a8b11a0d146ae58cd50799c4a06747646e28a9a",
    "src/core/employment.ts": "6c3fec2129c0a461ec0de8e3e20f4bb47e4150bb9f0c39fd7201fae6a3951ce0",
    "src/core/facilityEffects.ts": "2250d163627b28ad70603e422294a90372521c24111b5eb29303b4070e8c4814",
    "src/core/filmPackage.ts": "f0dce46007d5f3b778f62f237c58e049c14a84764ae2545bd52258cfb2b4bd3b",
    "src/core/filmParticipants.ts": "e26410299b9a7a0527cf6413b53a482f6280a137f3b32871ba729516ba4cf849",
    "src/core/financeReport.ts": "53667586cbeb4456a2b2f150b11bb1233c41ee7e9e36dcbe0952522eb3fc18ea",
    "src/core/firstFilmJourney.ts": "3c4bbde1ad298fc40103558cd1dc5dc73849ba73d4eba2e8a675b193295d0412",
    "src/core/firstTakeSubjects.ts": "2525b7e04a2449fbb91f8fb73765448eacf791f1854f5c054c093641f388993a",
    "src/core/fixedCostAllocation.ts": "72252b6e87557f9ed94eb922fd41a855a92c6540d2328efd168a26c22db9440e",
    "src/core/forecast.ts": "13add49ffbcf0811b56de03c3978e0122c0f901226b405a76359b8b8fda6ae04",
    "src/core/grid.ts": "67fe3355621e630de8c69e520348600bdb57445122daee791fcbbe59f803ce89",
    "src/core/hollywood.ts": "c9281b85fab7fe6ce72568f318a545fce01343da86c8fd9c7db8ee5e3bd17f1f",
    "src/core/hollywoodPolicy.ts": "843131da845b609ad133259ee82035bc129aad4b75394b757d5ac66341efd234",
    "src/core/hollywoodStartingData.ts": "0ac26f1a958327c694369a8583e8439cd80dfd5cc3c7c1882b7d9d2cea2af976",
    "src/core/hollywoodTick.ts": "d5963544fd591ee5abbb3584e3f0337db0210bfeaac05b69195a3c339452ac17",
    "src/core/hollywoodTypes.ts": "09606801a73c8c675737f972dae5b78ef41deef375aad0c9732286d13a08b68a",
    "src/core/hollywoodValidation.ts": "b58d085621ff41e8fe6e3e8d7ebe0d2b60e4925f6faaa0e8ddc3aea622eb6aff",
    "src/core/index.ts": "132372f417563651c7a31eec1629027b6eaef873746c5436d5b1d544d6237bea",
    "src/core/industryCareer.ts": "088a95368557cd893a4c93d90b403a9c3debf95710fcc4d055c01726e81e2d7e",
    "src/core/industryEmployment.ts": "51a4128847d310a735ae72ad9fa1ef3fc5fa698db2a6c195879abdcc0b6e0c39",
    "src/core/installationCancellation.ts": "eabfe77872df9e6b4d388b888152a20b1c46d8442dc1c96538e1bac9d2d728e0",
    "src/core/liveRetirementWriting.ts": "eb8736770ae2d96ad90069d981327acbebb661852101143ca53afa8d1553530b",
    "src/core/lot.ts": "b4366332889e113736ab788eee74f55fd3e5b89af2984a56436a355924b4cdf5",
    "src/core/marketIntegration.ts": "99219178fe1c906d36c25c410a03e1b3bac8d9287536c7a026eb3e19b73570f5",
    "src/core/marketingMenu.ts": "61d6e1efef70b880b8e2c1d3d8573d6acbb7d78b6bd781663c9af4e07e5c4e7d",
    "src/core/math.ts": "ac048a1ca635eefdafb154f54934d1cecd6ac922212b765dd283960e20a68670",
    "src/core/newspaper.ts": "a29d5922dcf613bd9794f204d11ed3991543099c9b058c5e894fa67f68f7b1a4",
    "src/core/occupancy.ts": "e9f66c3d225d8fe9f47d52ce18fc1ca00c587d24ec84f4dc70e9b0ab29a85122",
    "src/core/officeConversion.ts": "bf9d928f8bbdc46e01488dae84266f686be6f1cc1bafd9c11febb090a30971f8",
    "src/core/operations.ts": "9935b09495df1d11f39bf3b1a37b244c3d7bf7d0994cd4c8ce286571b3be3411",
    "src/core/opportunityPromises.ts": "a4acd02eb0151af8c873f939a546bdc26265ca0c680c3c004def056e124a4461",
    "src/core/p15Phases.ts": "a29f102947567e283eee93763c1d603bad7e5c2a53efae703cf2ef414fe5cfc8",
    "src/core/physicalPlans.ts": "52e5901b41d97fa384888b88671ae97723a33a6c695898f22f7dd8adaafd67de",
    "src/core/placement.ts": "28c2f23521d752ecdccf260c25b0ee06a7b8fd0a01a29b39060796d05e4086ed",
    "src/core/powerRanking.ts": "95b094724fbaee2689edfd577b542e7e9ce99a8d5ca9bf160250d1f658290c8b",
    "src/core/powerRankingArchive.ts": "f8b768d0bf628c836471f62721c776fa8a43a0669eddb124620554801cc13a6e",
    "src/core/presence.ts": "fe1eb5cc044e5193a68a848e025f3acf1714775a53d479286033de87bee2c6f9",
    "src/core/productionAdmission.ts": "fba9441b361920491e430ca87306912e7e54b40ee9bb0ce25a05c3da3d9ecd6e",
    "src/core/productionIdentity.ts": "9e283644085782bbb951c266685040bfe648ef68bd3cf504db56a90de2d97fb6",
    "src/core/productionPeople.ts": "2c6ea9affd6811d25cd36d85808d9470441f579153a7f0a2fb5b6a2c8a118d58",
    "src/core/productionPhases.ts": "f043868f28db91c518fbf821fdd952cde4da6509662a468131599cf48aafaf40",
    "src/core/productionQueue.ts": "38672a2d2c0d7c5a4b7434545d9b4ebb7400865349a3ec5568fb31ddae4c6c92",
    "src/core/productionSetup.ts": "778a40bb189b53501e5d796d3db8c12d46eaf0eeababbc0d463a45882b549935",
    "src/core/professionHistory.ts": "aa28b6283f9738726bc649d840e5a25e744671d614a04a804534992c6204fccf",
    "src/core/professionTransitions.ts": "945a911700f8ce8ea493f1ff080d906132b80ab9cf4d6c790a336bed1a95439d",
    "src/core/promiseCapacityEnumerator.ts": "c0be83a91cf15e5bbf779e9336a697bd19c0b65d95f660866ad85d5c80c697d6",
    "src/core/promiseCapacityKernel.ts": "1faa6fcac443dac046bd97fa3e27c61bada80c7297f8e69ea4ebcff76d899332",
    "src/core/promiseCapacityOwnerReplay.ts": "9e97ffed9911af55a1a5ff5e819cf53c17dfc3214bc729cc995ae72cb956ebd5",
    "src/core/promiseCapacityOwners.ts": "d6b6f8887d321aa2c52e8f555c40803d14381a8118c4fc84e1c9aaf037016734",
    "src/core/promises.ts": "580ddb7d1e8c5a198f18beb5843d1cecf77680b8b735e1f2603e2c86099e950d",
    "src/core/publicity.ts": "01f6b900730273f02f66e3148efe1904499e81f6d78f1f61c03e586fea1da3e5",
    "src/core/queueAdmission.ts": "ad74544f539f1d383839cbbe8b19d6324b5c5fffd3e7249ae6a2cc1b330b1047",
    "src/core/reception.ts": "ca27b0c299c463e8356615c013a4fa7acd7a7bb65c67b132480ec53c878c4095",
    "src/core/receptionVerdict.ts": "825e474ccce57e8de4a0d3aeb1d7ad5071b8d46121f95b7544946243af03e3d7",
    "src/core/relationshipLabels.ts": "e1d5d635b9e61867ba27bc0291315ac8fb63e8c57de5343876a2fb6fa85ec956",
    "src/core/relationships.ts": "27026dd3020190762aa6a95da5ce3012f79face854045b06cf968d5d9b129265",
    "src/core/releaseAuthority.ts": "9ab259623d3b5f5f75f1d750168e68ccb5c14d27d96f06f4656985db8064b218",
    "src/core/releaseCareers.ts": "b8050c8a70b165e42ed2841bbcfd99eb27ff5986529aa94dc511e5bd196ee965",
    "src/core/researchPeople.ts": "5202ec8a75b396a25418183c765cb8a1f10cb4b26e6e2f74bf83eee2c818e7fa",
    "src/core/retirementWriting.ts": "73590d43ce9e374fdfa784b24e6e11a5751a91f1cecf581f128be6483ecf4f0d",
    "src/core/rivalResearch.ts": "eb7753e88b31e980f504f28421346447eb6ece2308e42d1032fb7e9cc6e38d74",
    "src/core/rng.ts": "2f21996018c6f5399e1a68a1bf765e505db4d17360a939aa00cae0740cc6c57a",
    "src/core/save.ts": "3f852f997feaa77effd581858f56bf59a9cfa87069afec6e0a895cc653dced72",
    "src/core/sceneryLoadIn.ts": "f9240de85704a29aa1040694a53f2d0f7761856b579fb0dc93abf89fb8176766",
    "src/core/screenplay.ts": "1cb32a9ccd23dd7dc51d11cf080370feeb985de66fd36d4670c936ca6d1f929f",
    "src/core/scriptDevelopment.ts": "88ab848828a7eadad1a818a61d37cf0ab7d962ef06858c58d923ab50a56181b0",
    "src/core/scriptReadModel.ts": "c0ee15d37264b8329de70cb37e525a4644518497527763eccdf00fc5cac73616",
    "src/core/sets.ts": "7f18032b877f1215e7d8a6f8906509887bb0de4f899c66ba9d12c6cc66c98ab5",
    "src/core/shape.ts": "30f1530ac6f3d144818747aa0e5bdae846e1f5c4963c8eb447eb722efc4d92a2",
    "src/core/sharedMarket.ts": "eaf076da2b2a398d2ffb6153393e17051b4fe46a8f774b675eb21057ca2bd0c2",
    "src/core/standing.ts": "5e1ec7279553014099077a8e5cbe02c1b78454256bf3f400634accc2209c6893",
    "src/core/starPower.ts": "007c98dcaf612f87f7197bd14ddeb89df7a2cb0ae6542027f33d398976ccb881",
    "src/core/studioCalendar.ts": "67ebbbe36e8c136bb7806543b9bba39b37681bafb8e51d927c35f293eb0042c2",
    "src/core/studioEvents.ts": "570521afd32d96490092236d0041b358bd4b72abce08a79d929736a57ffbdc31",
    "src/core/studioHistory.ts": "6c363326c75aa1359b55ead36577beab0250bd8e35d2603ee09c1eb262f02697",
    "src/core/studioLoan.ts": "def5bd5b03e45b307615e33935ac6064e01e239735ee4128f61eae8a5b6f57b2",
    "src/core/studioQueueView.ts": "fc3f5136d402414d1603557f2b10e661f41655d488be77959bd64d8ec7b5e7e2",
    "src/core/studioRunRecap.ts": "1d61386ded5144e1663e72831c072d932b7c8d61bec4746885c195509f586962",
    "src/core/studioWeekTheater.ts": "b7d3be0569fc2cd4e4394403f9b4f5e4a5c5b335b9c5b57955e7edbf43175c87",
    "src/core/talentMarket.ts": "010ed07634a5991674dc867f61b3b78ab022c91699366d29fea26a4d5585c087",
    "src/core/talentSummary.ts": "ef4ff968b8348bab6b31fdc9f1fed0d5293c1da13dd9c0a755da64beafd1cce1",
    "src/core/technology.ts": "2842cb82fe703921d03bf73463dc5ae0a6724057bbb24588d299e32ce23d6fda",
    "src/core/technologyAdoption.ts": "ccd6ce36f219e271a93374dd42e7b9c9c7b8cb99f9c0e513a841e441e7eb8027",
    "src/core/technologyCatalogue.ts": "c9117fcff0944ffa9a518190f642fd46acddfe65d9f67f5df559558b3b941428",
    "src/core/technologyDisclosure.ts": "cff15e66dbe6e71a3a04dffdf9c7171b864113d305bfe4b2fa753f8a87b0c290",
    "src/core/technologyMilestones.ts": "8d8f7df921950fd9845c79e892da1da6177599a6c2514f5dc0fb5dc1cd556832",
    "src/core/technologyProduction.ts": "aa77c468b2b59742fcf5fea9d24229ab0e0f01d656b25a18af59ce987fa3f176",
    "src/core/technologyRival.ts": "69c8fa5ab2446b0cb3c74678538bd4b308917e0c8021e71355e5c54d07803520",
    "src/core/technologyTypes.ts": "158776e65d9a0411c5857f79515a7e2ddc16d0a8482d4437ee55c89c8a3e3bae",
    "src/core/tick.ts": "f923eb1694a030b3212e4f6f9881e83fd027f5ce5882a148623f58eca9cb0224",
    "src/core/tuning.ts": "dbc81b7b2c1e3b160266a792c2485506db906858dcc6a34bcc7a62e9a2072125",
    "src/core/types.ts": "d0d5c51ea08c8bec71d78f32b653f835d1d32c73c3f7d0d46aa3f9c541fa0dc2",
    "src/core/vector.ts": "b692a62a7167be503a45bf752eedc04fc62e861fbaa67d0398584ca0af01898b",
    "src/core/worldgen.ts": "7c38162376e5a5d69fd5f7ee56c4c76c2958dbde6a9940b097ccb257f5755f58",
    "src/harness/aggregate.ts": "9562e875073428832db05438d3bd46ba5cf14d361bf38cb81ac11f1b7b73720c",
    "src/harness/d16/compare-d17b-production.ts": "60f9fd2c2750eae3cff511ed67b63d1021c3b5f85e67de3d8212b4405e24bcb5",
    "src/harness/d16/counterflow.test.ts": "cb46fef7d5ee5bd67c1968c3bad735151c1fad353d6d012ed9c30bb84bd7a6f1",
    "src/harness/d16/counterflow.ts": "c17648540b48a80d53bdb002ee46aeb468bb3bc498292d714422db64c77b4f97",
    "src/harness/d16/driver.test.ts": "b0c5e127d215ab1ec674de33f918d9c8bf1b541d699a459913bdf0665fdab66d",
    "src/harness/d16/driver.ts": "47cd9431caa79c9a4c17f9a771f32996fa9e9ffd179f9d56fbeee2f584d52301",
    "src/harness/d16/experiment.test.ts": "ccaef3262ba6f4c5205cf16831e0693a2958148f880d86f675849fc59378274f",
    "src/harness/d16/experiment.ts": "3c08c67fe4076e3fc317d6f1adc126aa95053afdf36daf243e7742ec0eeaa530",
    "src/harness/d16/isolation.test.ts": "59dfb64a3e17108d65d5b64114b63bee8e8ea262833ea34a24ac56cea29d8abe",
    "src/harness/d16/luck.test.ts": "230358d9f8ce418f17e368387faa12bf508947b990348d8ccc8d79151912a16b",
    "src/harness/d16/luck.ts": "cad58de739921d7c09e9a7ecca48c56fd53e28c319737956059f62cff083ced1",
    "src/harness/d16/packages.test.ts": "dc855509e2185ff10a1d08d5188f4a5f5b797acb392963b0656044dd7be20625",
    "src/harness/d16/packages.ts": "dabd00dc7cfa87ffe99c0cb9a1aabc5c574d1720f350a08a006c423181e7650b",
    "src/harness/d16/policies.ts": "56c9e358ea307309327c1abfdfc8fcbea76ec5b73b7dfeccd15577d44768ddbb",
    "src/harness/d16/production-agreement.test.ts": "15983af90316fd0c387e7077b2f143104ac4f942f38771fdf2a1a3debc5400f0",
    "src/harness/d16/productionIdentity.ts": "0e472c916ad5aac3a181d367b155fe599fa15511b99e3815007766246ac8a1d0",
    "src/harness/d16/publicity.test.ts": "35cb17c4ff59e83854258b920a071399f40ae81ffb9deaa69b9463e36dc30483",
    "src/harness/d16/publicity.ts": "77f7fd9481e94dca9e91c79d9ac5428a2f40afd3e61392cb4fbbe19f7e2ad5b2",
    "src/harness/d16/run-d16-corpus.ts": "91130cba5f1d78e1c0520010196892ef03392b730cc91e02d803598d1b9d3a3a",
    "src/harness/d16/run-d17b-continuation.ts": "8fabf8806167281db95a99b769094d98f45262e6f30cb0a53f8dadceff070c04",
    "src/harness/d16/run-d17b-week86.ts": "b172a567a98a4d16ce8d5d0ba3d9bcfd3e806f04de4dcb55ea6bfc2cad503701",
    "src/harness/d16/sourceProvenance.ts": "b071c131add5c96e351afacbdad6a27fd6e359ae1a4330c9e0c2dbb8b85bc8c8",
    "src/harness/d16/states.test.ts": "d867f547a3a698501688d66054d7157a238111e45fc65fa2950b28b052d8ed23",
    "src/harness/d16/states.ts": "dd12173c5784d336b40b580d9ed87bd727bd895b1284de3bf70f775cba50ca23",
    "src/harness/d16/stats.test.ts": "d3b09d7689fc7db92d955bc6aa9ba75934ecef63e05c5bd80a6338b1c3eab8b3",
    "src/harness/d16/stats.ts": "2d779d930ba6661d9d05ba0a47fe1a46ef1e66482dbfc9f8bcded15bc44c1225",
    "src/harness/d16/view.ts": "f32ea92a667d3dcc78d93fd12978f6a1c4112918de566ea8bf6b6b4c887a2bb2",
    "src/harness/d16/vitest.d16.config.ts": "c28600c717ab3a318a1b7b6879d099aead67dc946355c877a58d75ad398b4cb2",
    "src/harness/facilities/index.ts": "2dacfaaaeef073c472b94180fede2f58b96e49393a8b1108e9a4988e22a89953",
    "src/harness/measure.ts": "ffd2acb87e1b1cc7104c9bbb77060339c333699d7be3342e1f5a35558b2b8185",
    "src/harness/p13a/fixtures.ts": "f9d07ff10728ef42aa4973e97880e2300b9f29c32db3cc3b4bd6e4cdbd01f6d5",
    "src/harness/p13b/fixtures.ts": "6f2d51bb6cf6d77847c1e86340f6c3dba3f026c115c92773c534f3d8f3d31770",
    "src/harness/p13b/legacy-v20-fixtures.ts": "f777d57ca4cc9b00667433ed8817095a7ad9c0ef3e6068df9132fb4564a96a02",
    "src/harness/p13b/legacy-v21-fixtures.ts": "d1740e4a0f9983154cf5948548a9b1ad685ebdafa2681d5130b44e2438cd78f8",
    "src/harness/p13b/legacy-v22-fixtures.ts": "0704482264a60848cd63915c93b941910650a048f5c7d1e34aa1282e1ad85e02",
    "src/harness/p13b/legacy-v23-fixtures.ts": "9d27aa0e64c11fc752f3fa503565969e034dc89c934a898bb15a8331df192c6a",
    "src/harness/p13b/legacy-v24-fixtures.ts": "9bcabdcf0e6e8560bfe79249d92f1232e06e9ad6f0e2123567270a518f8154ad",
    "src/harness/p13b/legacy-v25-fixtures.ts": "bda365faa71820f8294e9e85114c21f112cdadb878f47a54fbd4a5e385494799",
    "src/harness/p13b/legacy-v26-fixtures.ts": "9486527b6d6c324d90d0e62c8a47ce1172cdd3ea638c5212d5b7dcd286a1daed",
    "src/harness/p13b/legacy-v27-fixtures.ts": "c834ebecacf04338897493b6eec7e9844e0e1024d084c359af919bb7e7fcb40f",
    "src/harness/p13b/s3-fixtures.ts": "790d542939ec2ef08d7bc932fbb6335e73cdaf36faf7d8bc868b2bbd924cd0ca",
    "src/harness/p13b/s4-fixtures.ts": "b9ff6f2c42c3c8ba54c2d3b28ba808e182a8f365059693e58dbf1ffcfa2fc2f7",
    "src/harness/p13b/s6-fixtures.ts": "4ccc74fc7be78d954f5e44d746a5fbf55b7f5228c18ce3c17df24c3b90398169",
    "src/harness/p14/legacy-v28-fixtures.ts": "b4bfd704545be85ef81aa7cdb18f5390809983c5357a714182084a60aa5f38bc",
    "src/harness/roster-wall/artifacts.ts": "a797f939d1ccefce7ea40b8535ad1af57191b0789401050d3b2abae97d101b11",
    "src/harness/roster-wall/campaign.ts": "24ff204180c3e8adf21e978ea76669536259574eaa69d2d2b531e42065736b1e",
    "src/harness/roster-wall/continuation.ts": "db487c2cdd70e412fbc819819e8b52df979817d84a246b08f4570d42f8530389",
    "src/harness/roster-wall/corpus.ts": "80b4a344469540741fcc1281bfe24b02e40e90d1fef457fc2ee24c78d61f7fdf",
    "src/harness/roster-wall/fixtures.ts": "2f25a9ae771a9052a20a15ee075062e47922a6eb8ecc220521011069ca6d2b7f",
    "src/harness/roster-wall/historical-control.ts": "2b7b69a5fed68faa618735d1f0d26473d451bd7fbaecc2678fb1b7c002bd08c7",
    "src/harness/roster-wall/player-policy.ts": "e20381593a39929ea7cbdcb106903cc69138b694dfad13835898f6c0df6445fd",
    "src/harness/roster-wall/provenance.ts": "f4782ee266c3e933f61003b2a56e10aa03c66f324b5c85a875f8998a02b27b21",
    "src/harness/roster-wall/records.ts": "0c14448a22a36553b82beb19f65790dfce13374003dc216a336c93ce529ba7a0",
    "src/harness/roster-wall/renewal.ts": "f699af2b240476c470d7f4a167523f087702662f0a229235ca1fd0d1a7fce1c3",
    "src/harness/roster-wall/schema.ts": "f7c5f93de1ebba0b8285c1f3c0905efbe1025fde6efb592dfe84dfeb5874e2aa",
    "src/harness/roster-wall/summary.ts": "df380b54886409874bb1301456ce3827777dfa557f412679d4eaab05192f6ec9",
    "src/harness/run-capital-risk-reward-audit.ts": "5cb07b311353b886612989c0c8869f082bad79c1b174cc14c016340bbc9c2105",
    "src/harness/run-corpus.ts": "0c334b66db9c340342e8b74195ea932cefe2838a6d0c6cb00a8069c396bce735",
    "src/harness/run-creator-baseline-study.ts": "c8abae6627f8f644fcaa3b03ec7f7539a134643e499c873d90f36fe4154ee3d4",
    "src/harness/run-creator-development-study.ts": "a75b122490ea161968babbcc0f268bfc5e5ef2ae6fefd471a68ef54786a5c70b",
    "src/harness/run-dev-study.ts": "7eb8da0d7b9125b19c92460544834d3e4993462c65cf93fc6664c0573b939a55",
    "src/harness/run-driver.ts": "55e2cf7a6bf3a0da57d2ceeb6718ffabd136dbff91b14adc79a784b0b453d85f",
    "src/harness/run-economy-balance-study.ts": "0c4344c4753bccab61ec92958900e122ad758b36568bb1d31c2caa4231ac25ec",
    "src/harness/run-facilities-observatory.ts": "ce6fd8ca62d8581ba06f8ad86cb943fa199cc8fcb8b82f263966446109a97efe",
    "src/harness/run-final-balance.ts": "0c6b7901cb177a73a15176d630c3f19b9cbf888c2164c1f6b72c1181dc78c767",
    "src/harness/run-integrated-balance.ts": "92c29027fcc8617219ef71ae62f1b1b3472b3cae4920d604256f26a33dd8526b",
    "src/harness/run-microbudget-dominance-audit.ts": "2d300f4e02d6be28dd0d8240b37d4fbde702d0499be729722cc3deb60cbdf67b",
    "src/harness/run-multihyphenate-stats.ts": "ec00a0722c2152555265dee1eb27d33da284f2ead4ce98eeb6f23fabc04abb2c",
    "src/harness/run-owner-calibration-study.ts": "95e2ba022fc77fbdfc069ed4d334a27bc25e586ca5a6224150a776ea2d14266f",
    "src/harness/run-roster-balance-study.ts": "789d25830d974e70a529f70ba6b5154394d752dc5ee9aacf2603ac7030758577",
    "src/harness/run-roster-wall-observatory.ts": "9f2c167c614bdd246aebec25f07024a63f2660b860ecdb60ceb70cfa3b06db11",
    "src/harness/run-selection-stats.ts": "5eecfa59c1624650c5665e80de8c7cbc01b7e94720b84acecd5248b0d8aee113",
    "src/harness/run-shape-sensitivity.ts": "09b289bfcde6f0d0fa6a05e2a33dedbff233e0638b0a9e4c5d9f8f206f9bfde5",
    "src/harness/run-star-power-calibration.ts": "ea04887ca850a6ad340b09dbc17ed25d37e71e89a3e67c04db2ec85635022ce7",
    "src/harness/run-writer-bottleneck-study.ts": "2eb0d26a12d447e055060237811e7c7d179a8b1ec1e25030fcc37e3ab4cf5b7f",
    "tests/bridge-p14b5-relationships.test.ts": "7477288c2430681c2c5dd0ee959fd46d2d7d9cdb40e9bf1edf8249eac76da4b7"
  },
  "ABC": {
    "src/core/technologyMilestones.ts": "8d8f7df921950fd9845c79e892da1da6177599a6c2514f5dc0fb5dc1cd556832",
    "src/core/standing.ts": "5e1ec7279553014099077a8e5cbe02c1b78454256bf3f400634accc2209c6893",
    "src/core/promiseCapacityEnumerator.ts": "c0be83a91cf15e5bbf779e9336a697bd19c0b65d95f660866ad85d5c80c697d6",
    "src/core/technology.ts": "2842cb82fe703921d03bf73463dc5ae0a6724057bbb24588d299e32ce23d6fda",
    "src/core/installationCancellation.ts": "eabfe77872df9e6b4d388b888152a20b1c46d8442dc1c96538e1bac9d2d728e0",
    "src/core/relationships.ts": "27026dd3020190762aa6a95da5ce3012f79face854045b06cf968d5d9b129265",
    "src/core/hollywood.ts": "7e9e26ac92689a2db5ad9e239c90b6203b4f1084b1aca8f68064c9908569a441",
    "src/core/powerRanking.ts": "95b094724fbaee2689edfd577b542e7e9ce99a8d5ca9bf160250d1f658290c8b",
    "src/core/firstTakeSubjects.ts": "2525b7e04a2449fbb91f8fb73765448eacf791f1854f5c054c093641f388993a",
    "src/core/relationshipLabels.ts": "e1d5d635b9e61867ba27bc0291315ac8fb63e8c57de5343876a2fb6fa85ec956",
    "src/core/studioCalendar.ts": "67ebbbe36e8c136bb7806543b9bba39b37681bafb8e51d927c35f293eb0042c2",
    "src/core/technologyDisclosure.ts": "cff15e66dbe6e71a3a04dffdf9c7171b864113d305bfe4b2fa753f8a87b0c290",
    "src/core/researchPeople.ts": "5202ec8a75b396a25418183c765cb8a1f10cb4b26e6e2f74bf83eee2c818e7fa",
    "src/core/castingPackageReadModel.ts": "0a6615639ce224665f059790d39f33d95270398fbd1158d310647a7aaf0f94c6",
    "src/core/physicalPlans.ts": "52e5901b41d97fa384888b88671ae97723a33a6c695898f22f7dd8adaafd67de",
    "src/core/sets.ts": "7f18032b877f1215e7d8a6f8906509887bb0de4f899c66ba9d12c6cc66c98ab5",
    "src/core/broadcast.ts": "81809e230570dd795bef921716a2c300dd062298878705e5d5b6c4582c667e85",
    "src/core/candidates.ts": "85a6d18e32cfca3e554977825ea06f10d2928eca68331a1b7b801ee320fe4104",
    "src/core/talentSummary.ts": "ef4ff968b8348bab6b31fdc9f1fed0d5293c1da13dd9c0a755da64beafd1cce1",
    "src/core/productionQueue.ts": "38672a2d2c0d7c5a4b7434545d9b4ebb7400865349a3ec5568fb31ddae4c6c92",
    "src/core/scriptReadModel.ts": "c0ee15d37264b8329de70cb37e525a4644518497527763eccdf00fc5cac73616",
    "src/core/professionHistory.ts": "aa28b6283f9738726bc649d840e5a25e744671d614a04a804534992c6204fccf",
    "src/core/filmPackage.ts": "f0dce46007d5f3b778f62f237c58e049c14a84764ae2545bd52258cfb2b4bd3b",
    "src/core/promiseCapacityOwnerReplay.ts": "9e97ffed9911af55a1a5ff5e819cf53c17dfc3214bc729cc995ae72cb956ebd5",
    "src/core/releaseAuthority.ts": "9ab259623d3b5f5f75f1d750168e68ccb5c14d27d96f06f4656985db8064b218",
    "src/core/industryCareer.ts": "088a95368557cd893a4c93d90b403a9c3debf95710fcc4d055c01726e81e2d7e",
    "src/core/productionAdmission.ts": "fba9441b361920491e430ca87306912e7e54b40ee9bb0ce25a05c3da3d9ecd6e",
    "src/core/aging.ts": "f0fa2af61d7b8cfaff9923be46c07c21134f899ec2321dccc618a1160aa75c34",
    "src/core/placement.ts": "28c2f23521d752ecdccf260c25b0ee06a7b8fd0a01a29b39060796d05e4086ed",
    "src/core/math.ts": "ac048a1ca635eefdafb154f54934d1cecd6ac922212b765dd283960e20a68670",
    "src/core/boundedStableSort.ts": "87861f3ceefe2b2a9163a34bd9762a991d5c8a7f1640b84fbe6d1133f33ff964",
    "src/core/shape.ts": "30f1530ac6f3d144818747aa0e5bdae846e1f5c4963c8eb447eb722efc4d92a2",
    "src/core/productionIdentity.ts": "2093668d7b1fb878d45a19923a6d3196fbf50a91c1ce5cc38e80598c27741d84",
    "src/core/tuning.ts": "dbc81b7b2c1e3b160266a792c2485506db906858dcc6a34bcc7a62e9a2072125",
    "src/core/liveRetirementWriting.ts": "eb8736770ae2d96ad90069d981327acbebb661852101143ca53afa8d1553530b",
    "src/core/facilityEffects.ts": "2250d163627b28ad70603e422294a90372521c24111b5eb29303b4070e8c4814",
    "src/core/queueAdmission.ts": "ad74544f539f1d383839cbbe8b19d6324b5c5fffd3e7249ae6a2cc1b330b1047",
    "src/core/tick.ts": "f923eb1694a030b3212e4f6f9881e83fd027f5ce5882a148623f58eca9cb0224",
    "src/core/employment.ts": "ad7f32db9f5a5ed6b5d11a26a25604ab71df07daba0e273214336e92d8c0f1bf",
    "src/core/marketingMenu.ts": "61d6e1efef70b880b8e2c1d3d8573d6acbb7d78b6bd781663c9af4e07e5c4e7d",
    "src/core/retirementWriting.ts": "73590d43ce9e374fdfa784b24e6e11a5751a91f1cecf581f128be6483ecf4f0d",
    "src/core/studioHistory.ts": "6c363326c75aa1359b55ead36577beab0250bd8e35d2603ee09c1eb262f02697",
    "src/core/p15Phases.ts": "a29f102947567e283eee93763c1d603bad7e5c2a53efae703cf2ef414fe5cfc8",
    "src/core/professionTransitions.ts": "945a911700f8ce8ea493f1ff080d906132b80ab9cf4d6c790a336bed1a95439d",
    "src/core/sceneryLoadIn.ts": "f9240de85704a29aa1040694a53f2d0f7761856b579fb0dc93abf89fb8176766",
    "src/core/studioRunRecap.ts": "1d61386ded5144e1663e72831c072d932b7c8d61bec4746885c195509f586962",
    "src/core/operations.ts": "9935b09495df1d11f39bf3b1a37b244c3d7bf7d0994cd4c8ce286571b3be3411",
    "src/core/worldgen.ts": "7c38162376e5a5d69fd5f7ee56c4c76c2958dbde6a9940b097ccb257f5755f58",
    "src/core/fixedCostAllocation.ts": "72252b6e87557f9ed94eb922fd41a855a92c6540d2328efd168a26c22db9440e",
    "src/core/calendar.ts": "c54fe83ab161d4c80727c3ece021e6340eda3a7ff0bf134f5288d76de8f811ef",
    "src/core/studioWeekTheater.ts": "b7d3be0569fc2cd4e4394403f9b4f5e4a5c5b335b9c5b57955e7edbf43175c87",
    "src/core/officeConversion.ts": "bf9d928f8bbdc46e01488dae84266f686be6f1cc1bafd9c11febb090a30971f8",
    "src/core/filmParticipants.ts": "e26410299b9a7a0527cf6413b53a482f6280a137f3b32871ba729516ba4cf849",
    "src/core/campaignLegacy.ts": "48e1d086deaaf82a82d05f0a8065bca9b7a7ea35bc68051ea06c33ceb3a0e8de",
    "src/core/technologyAdoption.ts": "ccd6ce36f219e271a93374dd42e7b9c9c7b8cb99f9c0e513a841e441e7eb8027",
    "src/core/agents.ts": "ee68473f551a90541d5cb8d64ce39499649c4848034d2f7403ca44e048234a73",
    "src/core/technologyTypes.ts": "158776e65d9a0411c5857f79515a7e2ddc16d0a8482d4437ee55c89c8a3e3bae",
    "src/core/sharedMarket.ts": "eaf076da2b2a398d2ffb6153393e17051b4fe46a8f774b675eb21057ca2bd0c2",
    "src/core/types.ts": "114efba3aece83977c63fc8c5f5f77e9ce966807fcaed9b89625e608d715f9ee",
    "src/core/presence.ts": "fe1eb5cc044e5193a68a848e025f3acf1714775a53d479286033de87bee2c6f9",
    "src/core/development.ts": "ce37f726f18270f6d9d0aa6444ed23104cf963418365f00192a13f5fc55153fc",
    "src/core/reception.ts": "ca27b0c299c463e8356615c013a4fa7acd7a7bb65c67b132480ec53c878c4095",
    "src/core/powerRankingArchive.ts": "f8b768d0bf628c836471f62721c776fa8a43a0669eddb124620554801cc13a6e",
    "src/core/promises.ts": "580ddb7d1e8c5a198f18beb5843d1cecf77680b8b735e1f2603e2c86099e950d",
    "src/core/opportunityPromises.ts": "a4acd02eb0151af8c873f939a546bdc26265ca0c680c3c004def056e124a4461",
    "src/core/newspaper.ts": "a29d5922dcf613bd9794f204d11ed3991543099c9b058c5e894fa67f68f7b1a4",
    "src/core/actions.ts": "88acf224e5bf9dbe7234eb6933d0f7e02bea55fc1ac68b65711f4b7d54e1898f",
    "src/core/financeReport.ts": "53667586cbeb4456a2b2f150b11bb1233c41ee7e9e36dcbe0952522eb3fc18ea",
    "src/core/hollywoodTypes.ts": "65a54dc851cd1f61f8b97674ed825b343a8ec94ab7b8328ad113f12343a41a84",
    "src/core/productionPhases.ts": "f043868f28db91c518fbf821fdd952cde4da6509662a468131599cf48aafaf40",
    "src/core/technologyProduction.ts": "aa77c468b2b59742fcf5fea9d24229ab0e0f01d656b25a18af59ce987fa3f176",
    "src/core/productionSetup.ts": "778a40bb189b53501e5d796d3db8c12d46eaf0eeababbc0d463a45882b549935",
    "src/core/economyView.ts": "64c51d1e58ff994dea3250db3a8b11a0d146ae58cd50799c4a06747646e28a9a",
    "src/core/promiseCapacityKernel.ts": "1faa6fcac443dac046bd97fa3e27c61bada80c7297f8e69ea4ebcff76d899332",
    "src/core/receptionVerdict.ts": "825e474ccce57e8de4a0d3aeb1d7ad5071b8d46121f95b7544946243af03e3d7",
    "src/core/technologyCatalogue.ts": "c9117fcff0944ffa9a518190f642fd46acddfe65d9f67f5df559558b3b941428",
    "src/core/studioQueueView.ts": "fc3f5136d402414d1603557f2b10e661f41655d488be77959bd64d8ec7b5e7e2",
    "src/core/occupancy.ts": "e9f66c3d225d8fe9f47d52ce18fc1ca00c587d24ec84f4dc70e9b0ab29a85122",
    "src/core/productionPeople.ts": "2c6ea9affd6811d25cd36d85808d9470441f579153a7f0a2fb5b6a2c8a118d58",
    "src/core/hollywoodStartingData.ts": "0ac26f1a958327c694369a8583e8439cd80dfd5cc3c7c1882b7d9d2cea2af976",
    "src/core/screenplay.ts": "1cb32a9ccd23dd7dc51d11cf080370feeb985de66fd36d4670c936ca6d1f929f",
    "src/core/rng.ts": "2f21996018c6f5399e1a68a1bf765e505db4d17360a939aa00cae0740cc6c57a",
    "src/core/construction.ts": "24cad343abe3122e919e4dae57b85bdac24418a360723a3055b76ae82fefdf36",
    "src/core/hollywoodValidation.ts": "ec8cf7290a63389087750967fcbe456159eaf2840770341ce3c9cf7d9f75c214",
    "src/core/hollywoodPolicy.ts": "ea2994dbb980aa60ce70d1e53ecc6c2a0acf1365145f0e6aad148e5cd0a9bce1",
    "src/core/lot.ts": "b4366332889e113736ab788eee74f55fd3e5b89af2984a56436a355924b4cdf5",
    "src/core/blueprintRequirements.ts": "abf32723f6530c8d2fda94067d6b793daab33154e636e2e906587211f4d456e0",
    "src/core/technologyRival.ts": "fd9764c20f5a649be3b51e23533cd4208fd59c049b1b2a166d89a9bbb35c0336",
    "src/core/studioLoan.ts": "def5bd5b03e45b307615e33935ac6064e01e239735ee4128f61eae8a5b6f57b2",
    "src/core/releaseCareers.ts": "b8050c8a70b165e42ed2841bbcfd99eb27ff5986529aa94dc511e5bd196ee965",
    "src/core/industryEmployment.ts": "51a4128847d310a735ae72ad9fa1ef3fc5fa698db2a6c195879abdcc0b6e0c39",
    "src/core/index.ts": "25b07f15ee0fe71484faab449b5c50aa407832cae1b4f4196b70c4944244de4b",
    "src/core/hollywoodTick.ts": "c540c6830537aaaca6cb448993e4c9648f7141bcf498ca92e239b9ebd1cee5b8",
    "src/core/economy.ts": "caa6f20444be1544d64e2226f8eb89823c8d787c1460473169e0954ef15d0e10",
    "src/core/rivalResearch.ts": "e24566c984414a66fbfb896481dbc6d8f742bf7fa36702aec0a211b15d513d18",
    "src/core/firstFilmJourney.ts": "3c4bbde1ad298fc40103558cd1dc5dc73849ba73d4eba2e8a675b193295d0412",
    "src/core/careerLifecycle.ts": "338510e570d2ace8bdeaa24b989fe7783c2d4e4250e1929eb56fc8f149c5d1f6",
    "src/core/publicity.ts": "01f6b900730273f02f66e3148efe1904499e81f6d78f1f61c03e586fea1da3e5",
    "src/core/vector.ts": "b692a62a7167be503a45bf752eedc04fc62e861fbaa67d0398584ca0af01898b",
    "src/core/forecast.ts": "13add49ffbcf0811b56de03c3978e0122c0f901226b405a76359b8b8fda6ae04",
    "src/core/promiseCapacityOwners.ts": "d6b6f8887d321aa2c52e8f555c40803d14381a8118c4fc84e1c9aaf037016734",
    "src/core/talentMarket.ts": "feaf3ef75051583820addb8b3b00065925464e5a2ca265c3d328102c22aa5957",
    "src/core/castingSessions.ts": "497a8a32152e556378db96d8363be6de9a0719f2eed1fbec4a4fcfe222cf3a3b",
    "src/core/scriptDevelopment.ts": "88ab848828a7eadad1a818a61d37cf0ab7d962ef06858c58d923ab50a56181b0",
    "src/core/studioEvents.ts": "570521afd32d96490092236d0041b358bd4b72abce08a79d929736a57ffbdc31",
    "src/core/corporateCondition.ts": "428f2e59c141ad765b0a04cb032de7801a0006cfe3ddd5953ef429a835fadf44",
    "src/core/grid.ts": "67fe3355621e630de8c69e520348600bdb57445122daee791fcbbe59f803ce89",
    "src/core/marketIntegration.ts": "99219178fe1c906d36c25c410a03e1b3bac8d9287536c7a026eb3e19b73570f5",
    "src/core/starPower.ts": "007c98dcaf612f87f7197bd14ddeb89df7a2cb0ae6542027f33d398976ccb881",
    "src/core/save.ts": "cd4a1d42d02fee6280e2a658ba304448c0ab93c0e57fd8866ef5a65e0072c035",
    "src/core/castingReadModel.ts": "56e0021c14337f333863be25ade1450ec59503b94e3ccb257ff31ceed5deb1c8",
    "src/harness/run-dev-study.ts": "7eb8da0d7b9125b19c92460544834d3e4993462c65cf93fc6664c0573b939a55",
    "src/harness/run-integrated-balance.ts": "92c29027fcc8617219ef71ae62f1b1b3472b3cae4920d604256f26a33dd8526b",
    "src/harness/run-roster-balance-study.ts": "789d25830d974e70a529f70ba6b5154394d752dc5ee9aacf2603ac7030758577",
    "src/harness/run-shape-sensitivity.ts": "09b289bfcde6f0d0fa6a05e2a33dedbff233e0638b0a9e4c5d9f8f206f9bfde5",
    "src/harness/run-creator-development-study.ts": "a75b122490ea161968babbcc0f268bfc5e5ef2ae6fefd471a68ef54786a5c70b",
    "src/harness/run-owner-calibration-study.ts": "95e2ba022fc77fbdfc069ed4d334a27bc25e586ca5a6224150a776ea2d14266f",
    "src/harness/run-multihyphenate-stats.ts": "ec00a0722c2152555265dee1eb27d33da284f2ead4ce98eeb6f23fabc04abb2c",
    "src/harness/run-final-balance.ts": "0c6b7901cb177a73a15176d630c3f19b9cbf888c2164c1f6b72c1181dc78c767",
    "src/harness/run-writer-bottleneck-study.ts": "2eb0d26a12d447e055060237811e7c7d179a8b1ec1e25030fcc37e3ab4cf5b7f",
    "src/harness/run-facilities-observatory.ts": "ce6fd8ca62d8581ba06f8ad86cb943fa199cc8fcb8b82f263966446109a97efe",
    "src/harness/run-capital-risk-reward-audit.ts": "5cb07b311353b886612989c0c8869f082bad79c1b174cc14c016340bbc9c2105",
    "src/harness/run-roster-wall-observatory.ts": "9f2c167c614bdd246aebec25f07024a63f2660b860ecdb60ceb70cfa3b06db11",
    "src/harness/run-star-power-calibration.ts": "ea04887ca850a6ad340b09dbc17ed25d37e71e89a3e67c04db2ec85635022ce7",
    "src/harness/run-corpus.ts": "0c334b66db9c340342e8b74195ea932cefe2838a6d0c6cb00a8069c396bce735",
    "src/harness/run-economy-balance-study.ts": "0c4344c4753bccab61ec92958900e122ad758b36568bb1d31c2caa4231ac25ec",
    "src/harness/run-creator-baseline-study.ts": "c8abae6627f8f644fcaa3b03ec7f7539a134643e499c873d90f36fe4154ee3d4",
    "src/harness/aggregate.ts": "9562e875073428832db05438d3bd46ba5cf14d361bf38cb81ac11f1b7b73720c",
    "src/harness/run-selection-stats.ts": "5eecfa59c1624650c5665e80de8c7cbc01b7e94720b84acecd5248b0d8aee113",
    "src/harness/measure.ts": "ffd2acb87e1b1cc7104c9bbb77060339c333699d7be3342e1f5a35558b2b8185",
    "src/harness/run-microbudget-dominance-audit.ts": "2d300f4e02d6be28dd0d8240b37d4fbde702d0499be729722cc3deb60cbdf67b",
    "src/harness/run-driver.ts": "55e2cf7a6bf3a0da57d2ceeb6718ffabd136dbff91b14adc79a784b0b453d85f",
    "src/harness/p13a/fixtures.ts": "f9d07ff10728ef42aa4973e97880e2300b9f29c32db3cc3b4bd6e4cdbd01f6d5",
    "src/harness/p13b/fixtures.ts": "6f2d51bb6cf6d77847c1e86340f6c3dba3f026c115c92773c534f3d8f3d31770",
    "src/harness/p13b/legacy-v20-fixtures.ts": "f777d57ca4cc9b00667433ed8817095a7ad9c0ef3e6068df9132fb4564a96a02",
    "src/harness/p13b/legacy-v25-fixtures.ts": "bda365faa71820f8294e9e85114c21f112cdadb878f47a54fbd4a5e385494799",
    "src/harness/p13b/legacy-v26-fixtures.ts": "9486527b6d6c324d90d0e62c8a47ce1172cdd3ea638c5212d5b7dcd286a1daed",
    "src/harness/p13b/s6-fixtures.ts": "4ccc74fc7be78d954f5e44d746a5fbf55b7f5228c18ce3c17df24c3b90398169",
    "src/harness/p13b/legacy-v23-fixtures.ts": "9d27aa0e64c11fc752f3fa503565969e034dc89c934a898bb15a8331df192c6a",
    "src/harness/p13b/s3-fixtures.ts": "790d542939ec2ef08d7bc932fbb6335e73cdaf36faf7d8bc868b2bbd924cd0ca",
    "src/harness/p13b/legacy-v24-fixtures.ts": "9bcabdcf0e6e8560bfe79249d92f1232e06e9ad6f0e2123567270a518f8154ad",
    "src/harness/p13b/s4-fixtures.ts": "b9ff6f2c42c3c8ba54c2d3b28ba808e182a8f365059693e58dbf1ffcfa2fc2f7",
    "src/harness/p13b/legacy-v21-fixtures.ts": "d1740e4a0f9983154cf5948548a9b1ad685ebdafa2681d5130b44e2438cd78f8",
    "src/harness/p13b/legacy-v22-fixtures.ts": "0704482264a60848cd63915c93b941910650a048f5c7d1e34aa1282e1ad85e02",
    "src/harness/p13b/legacy-v27-fixtures.ts": "c834ebecacf04338897493b6eec7e9844e0e1024d084c359af919bb7e7fcb40f",
    "src/harness/d16/policies.ts": "56c9e358ea307309327c1abfdfc8fcbea76ec5b73b7dfeccd15577d44768ddbb",
    "src/harness/d16/states.ts": "dd12173c5784d336b40b580d9ed87bd727bd895b1284de3bf70f775cba50ca23",
    "src/harness/d16/driver.ts": "47cd9431caa79c9a4c17f9a771f32996fa9e9ffd179f9d56fbeee2f584d52301",
    "src/harness/d16/publicity.test.ts": "35cb17c4ff59e83854258b920a071399f40ae81ffb9deaa69b9463e36dc30483",
    "src/harness/d16/productionIdentity.ts": "0e472c916ad5aac3a181d367b155fe599fa15511b99e3815007766246ac8a1d0",
    "src/harness/d16/stats.ts": "2d779d930ba6661d9d05ba0a47fe1a46ef1e66482dbfc9f8bcded15bc44c1225",
    "src/harness/d16/compare-d17b-production.ts": "60f9fd2c2750eae3cff511ed67b63d1021c3b5f85e67de3d8212b4405e24bcb5",
    "src/harness/d16/isolation.test.ts": "59dfb64a3e17108d65d5b64114b63bee8e8ea262833ea34a24ac56cea29d8abe",
    "src/harness/d16/production-agreement.test.ts": "15983af90316fd0c387e7077b2f143104ac4f942f38771fdf2a1a3debc5400f0",
    "src/harness/d16/experiment.test.ts": "ccaef3262ba6f4c5205cf16831e0693a2958148f880d86f675849fc59378274f",
    "src/harness/d16/view.ts": "f32ea92a667d3dcc78d93fd12978f6a1c4112918de566ea8bf6b6b4c887a2bb2",
    "src/harness/d16/experiment.ts": "3c08c67fe4076e3fc317d6f1adc126aa95053afdf36daf243e7742ec0eeaa530",
    "src/harness/d16/run-d17b-week86.ts": "b172a567a98a4d16ce8d5d0ba3d9bcfd3e806f04de4dcb55ea6bfc2cad503701",
    "src/harness/d16/run-d17b-continuation.ts": "8fabf8806167281db95a99b769094d98f45262e6f30cb0a53f8dadceff070c04",
    "src/harness/d16/packages.ts": "dabd00dc7cfa87ffe99c0cb9a1aabc5c574d1720f350a08a006c423181e7650b",
    "src/harness/d16/sourceProvenance.ts": "b071c131add5c96e351afacbdad6a27fd6e359ae1a4330c9e0c2dbb8b85bc8c8",
    "src/harness/d16/run-d16-corpus.ts": "91130cba5f1d78e1c0520010196892ef03392b730cc91e02d803598d1b9d3a3a",
    "src/harness/d16/packages.test.ts": "dc855509e2185ff10a1d08d5188f4a5f5b797acb392963b0656044dd7be20625",
    "src/harness/d16/states.test.ts": "d867f547a3a698501688d66054d7157a238111e45fc65fa2950b28b052d8ed23",
    "src/harness/d16/luck.ts": "cad58de739921d7c09e9a7ecca48c56fd53e28c319737956059f62cff083ced1",
    "src/harness/d16/counterflow.ts": "c17648540b48a80d53bdb002ee46aeb468bb3bc498292d714422db64c77b4f97",
    "src/harness/d16/publicity.ts": "77f7fd9481e94dca9e91c79d9ac5428a2f40afd3e61392cb4fbbe19f7e2ad5b2",
    "src/harness/d16/vitest.d16.config.ts": "c28600c717ab3a318a1b7b6879d099aead67dc946355c877a58d75ad398b4cb2",
    "src/harness/d16/luck.test.ts": "230358d9f8ce418f17e368387faa12bf508947b990348d8ccc8d79151912a16b",
    "src/harness/d16/driver.test.ts": "b0c5e127d215ab1ec674de33f918d9c8bf1b541d699a459913bdf0665fdab66d",
    "src/harness/d16/counterflow.test.ts": "cb46fef7d5ee5bd67c1968c3bad735151c1fad353d6d012ed9c30bb84bd7a6f1",
    "src/harness/d16/stats.test.ts": "d3b09d7689fc7db92d955bc6aa9ba75934ecef63e05c5bd80a6338b1c3eab8b3",
    "src/harness/p14/legacy-v28-fixtures.ts": "b4bfd704545be85ef81aa7cdb18f5390809983c5357a714182084a60aa5f38bc",
    "src/harness/facilities/index.ts": "2dacfaaaeef073c472b94180fede2f58b96e49393a8b1108e9a4988e22a89953",
    "src/harness/roster-wall/schema.ts": "f7c5f93de1ebba0b8285c1f3c0905efbe1025fde6efb592dfe84dfeb5874e2aa",
    "src/harness/roster-wall/corpus.ts": "80b4a344469540741fcc1281bfe24b02e40e90d1fef457fc2ee24c78d61f7fdf",
    "src/harness/roster-wall/fixtures.ts": "2f25a9ae771a9052a20a15ee075062e47922a6eb8ecc220521011069ca6d2b7f",
    "src/harness/roster-wall/provenance.ts": "f4782ee266c3e933f61003b2a56e10aa03c66f324b5c85a875f8998a02b27b21",
    "src/harness/roster-wall/artifacts.ts": "a797f939d1ccefce7ea40b8535ad1af57191b0789401050d3b2abae97d101b11",
    "src/harness/roster-wall/summary.ts": "df380b54886409874bb1301456ce3827777dfa557f412679d4eaab05192f6ec9",
    "src/harness/roster-wall/campaign.ts": "24ff204180c3e8adf21e978ea76669536259574eaa69d2d2b531e42065736b1e",
    "src/harness/roster-wall/renewal.ts": "f699af2b240476c470d7f4a167523f087702662f0a229235ca1fd0d1a7fce1c3",
    "src/harness/roster-wall/continuation.ts": "db487c2cdd70e412fbc819819e8b52df979817d84a246b08f4570d42f8530389",
    "src/harness/roster-wall/records.ts": "0c14448a22a36553b82beb19f65790dfce13374003dc216a336c93ce529ba7a0",
    "src/harness/roster-wall/historical-control.ts": "2b7b69a5fed68faa618735d1f0d26473d451bd7fbaecc2678fb1b7c002bd08c7",
    "src/harness/roster-wall/player-policy.ts": "e20381593a39929ea7cbdcb106903cc69138b694dfad13835898f6c0df6445fd",
    "src/core/data/wordlists.ts": "6642296c7a0a4d385c6eb00e7b9ff4eb3213f72a6799b197549cba23718ebfac",
    "src/core/data/screenplay.ts": "176f5fd2c0f01d2af16ce0c6a3e77344bd6030a9b3660232f17a14e4baae15ad",
    "tests/bridge-p14b5-relationships.test.ts": "7477288c2430681c2c5dd0ee959fd46d2d7d9cdb40e9bf1edf8249eac76da4b7"
  }
}
function pathExists(path: string): boolean { try { lstatSync(path); return true } catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false; throw error } }
function exclusive(path: string) {
  assert.ok(isAbsolute(path) && !pathExists(path))
  for (let p = path; p !== dirname(p); p = dirname(p)) if (pathExists(p)) assert.ok(!lstatSync(p).isSymbolicLink(), p)
  assert.equal(realpathSync(dirname(path)), dirname(path))
}
type Hollywood = NonNullable<GameState['hollywood']>
type Business = Hollywood['businesses'][number]
function recovery(business: Business) {
  const field = (business as unknown as { costCutting?: { version: number; since: number | null } }).costCutting
  return field === undefined ? { present: false as const } : { present: true as const, ...copy(field) }
}
function rawOwners(h: Hollywood) {
  return h.businesses.map(b => ({ studioId: b.studioId, recovery: recovery(b), cash: b.account.cash,
    nextDecisionWeek: b.nextDecisionWeek, reserveWeeks: b.policy.reserveWeeks,
    productions: b.productions.map(p => p.id), runs: b.runs.map(r => r.productionId),
    activeEmployment: h.activeEmploymentOrdinals.filter(i => h.employment[i]!.studioId === b.studioId),
    account: copy(b.account) }))
}
function owners(h: Hollywood) { return measured('owners', () => rawOwners(h)) }

function caseKey(k: GameState['talentMarket']['cases'][number]) { return `${k.contractId}:${k.variant}` }
function rawChangedCases(before: GameState, after: GameState) {
  const firstByKey = new Map<string, GameState['talentMarket']['cases'][number]>()
  for (const old of before.talentMarket.cases) if (!firstByKey.has(caseKey(old))) firstByKey.set(caseKey(old), old)
  return after.talentMarket.cases.filter(k => {
    const old = firstByKey.get(caseKey(k))
    return old === undefined || (old !== k && snap(old) !== snap(k))
  }).map(copy)
}
function changedCases(before: GameState, after: GameState) { return measured('changedCases', () => rawChangedCases(before, after)) }

function rawWindowFacts(state: GameState) {
  const h = state.hollywood!, week = state.market.tick
  return h.employment.flatMap((row, ordinal) => {
    if (!renewalWindowOpen(row.terms, week)) return []
    const record = retirementRecordFor(state, row.terms.talentId)
    return [{ ordinal, row: copy(row), inActiveOrdinals: h.activeEmploymentOrdinals.includes(ordinal),
      retirement: record === undefined ? null : copy(record),
      existingCases: state.talentMarket.cases.filter(k => k.contractId === row.contractId).map(copy),
      sourceDiscoveryPremises: { activeOrdinal: h.activeEmploymentOrdinals.includes(ordinal),
        endedNull: row.endedWeek === null, renewalWindow: true,
        expiryCaseAbsent: !state.talentMarket.cases.some(k => k.contractId === row.contractId && k.variant !== 'retirementExtension'),
        retirementAbsent: record === undefined } }]
  })
}
function windowFacts(state: GameState) { return measured('windowFacts', () => rawWindowFacts(state)) }

function rawAdmit(state: GameState, expectedVersion: number) {
  const before = snap(state), saved = makeSave(state), readerInput = copy(saved), readerBefore = snap(readerInput)
  expect(saved.saveVersion).toBe(expectedVersion)
  const read = migrateToLive(readerInput)
  expect(stableStringify(read)).toBe(stableStringify(saved))
  expect(snap(readerInput)).toBe(readerBefore); expect(snap(state)).toBe(before)
  return { state, snapshot: before, digest: sha(before) }
}

function admit(state: GameState, expectedVersion: number) { return measured('admit', () => rawAdmit(state, expectedVersion)) }

it('1368 original 416-week natural ledger: bounded source attribution', async () => {
  const arm = process.env.LEDGER_ARM, mode = process.env.LEDGER_MODE, seed = process.env.LEDGER_SEED
  assert.ok(arm === 'C0' || arm === 'ABC')
  assert.ok(mode === 'clean' || (arm === 'ABC' && mode === 'observed'))
  assert.ok(seed === 'p13a-core-causal-01' || seed === 'p13-public-commercial-adoption')
  const output = process.env.LEDGER_OUTPUT; assert.ok(output); exclusive(output)
  const progress = process.env.LEDGER_PROGRESS; assert.ok(progress); exclusive(progress)
  writeFileSync(progress, '', { flag: 'wx' })
  const profile = process.env.LEDGER_PROFILE; assert.ok(profile); exclusive(profile)
  writeFileSync(profile, '', { flag: 'wx' })
  const diagnosticStarted = process.hrtime.bigint()
  let progressRows = 0
  const pins = SOURCE_PINS[arm]
  const guard = () => { for (const [path, hash] of Object.entries(pins)) expect(sha(readFileSync(resolve(path))), path).toBe(hash) }
  guard()
  const weekly: unknown[] = [], phaseRows: unknown[] = [], industryRows: unknown[] = []
  const result: Record<string, unknown> = { completed: false, arm, mode, seed, horizon: LEDGER_END_WEEK,
    sourcePins: pins, originalPins: LEDGER_SEEDS[seed], weekly, phaseRows, industryRows }
  let failed: unknown, phaseCalls = 0, industryCalls = 0
  const restores: (() => void)[] = []
  if (mode === 'observed') {
    const originalIndustry = industry.advanceHollywoodWeek
    const observer = vi.spyOn(industry, 'advanceHollywoodWeek').mockImplementation((...args: Parameters<typeof originalIndustry>) => {
      const before = snap(args), input = args[0], old = input.hollywood!
      const answer = originalIndustry(...args)
      expect(snap(args)).toBe(before); industryCalls++
      assert.ok(answer.hollywood)
      const h = answer.hollywood
      expect(h.receipts.slice(0, old.receipts.length)).toEqual(old.receipts)
      industryRows.push({ inputWeek: input.market.tick, inputDigest: sha(before), outputDigest: sha(snap(answer)),
        beforeOwners: owners(old), afterOwners: owners(h),
        newReceipts: copy(h.receipts.slice(old.receipts.length)),
        changedEmployment: h.employment.flatMap((e, ordinal) => old.employment[ordinal] === undefined || (e !== old.employment[ordinal] && snap(e) !== snap(old.employment[ordinal])) ? [{ ordinal, before: old.employment[ordinal] === undefined ? null : copy(old.employment[ordinal]), after: copy(e) }] : []),
        greenlights: copy(answer.greenlights), firstTakes: copy(answer.firstTakes) })
      return answer
    })
    restores.push(() => observer.mockRestore())
    const originalMarket = market.advanceTalentMarketWeek
    const observerMarket = vi.spyOn(market, 'advanceTalentMarketWeek').mockImplementation((input) => {
      const before = snap(input), inputWeek = input.market.tick, beforeWindows = windowFacts(input)
      expect(snap(input)).toBe(before)
      const answer = originalMarket(input)
      expect(snap(input)).toBe(before); phaseCalls++
      expect(answer.talentMarket.receipts.slice(0, input.talentMarket.receipts.length)).toEqual(input.talentMarket.receipts)
      phaseRows.push({ week: inputWeek, inputDigest: sha(before), outputDigest: sha(snap(answer)),
        inputRng: copy(input.rngState), outputRng: copy(answer.rngState), inputOwners: owners(input.hollywood!),
        windowFacts: beforeWindows, retirementRecords: copy(input.careerLifecycle.records),
        inputOpenCases: input.talentMarket.cases.filter(k => k.outcome === null).map(copy),
        changedCases: changedCases(input, answer), proposalsBefore: copy(input.talentMarket.proposals),
        proposalsAfter: copy(answer.talentMarket.proposals), newReceipts: copy(answer.talentMarket.receipts.slice(input.talentMarket.receipts.length)) })
      return answer
    })
    restores.push(() => observerMarket.mockRestore())
  }
  try {
    const rel = await relationships(); assert.ok(rel, 'the genuine relationship module must load')
    let admittedBoundary: ReturnType<typeof admit> | undefined
    const { state, rows } = runLedger(seed, rel, (input) => {
      const before = snap(input)
      if (admittedBoundary === undefined) admittedBoundary = admit(input, arm === 'C0' ? 45 : 46)
      // Only reuse a prior admission after proving this actual input is still that exact boundary.
      expect(input).toBe(admittedBoundary.state)
      expect(before).toBe(admittedBoundary.snapshot)
      const inputDigest = admittedBoundary.digest
      const old = input.hollywood!, answer = tick(input)
      expect(snap(input)).toBe(before); expect(answer.market.tick).toBe(input.market.tick + 1)
      const nextAdmission = admit(answer, arm === 'C0' ? 45 : 46)
      const digest = nextAdmission.digest, h = answer.hollywood!
      expect(answer.talentMarket.receipts.slice(0, input.talentMarket.receipts.length)).toEqual(input.talentMarket.receipts)
      expect(h.receipts.slice(0, old.receipts.length)).toEqual(old.receipts)
      weekly.push({ week: answer.market.tick, inputDigest, digest, rng: copy(answer.rngState), owners: owners(h),
        changedEmployment: h.employment.flatMap((e, ordinal) => old.employment[ordinal] === undefined || (e !== old.employment[ordinal] && snap(e) !== snap(old.employment[ordinal])) ? [{ ordinal, before: old.employment[ordinal] === undefined ? null : copy(old.employment[ordinal]), after: copy(e) }] : []),
        changedCases: changedCases(input, answer), newMarketReceipts: copy(answer.talentMarket.receipts.slice(input.talentMarket.receipts.length)),
        newIndustryReceipts: copy(h.receipts.slice(old.receipts.length)), firstTakes: copy(answer.firstTakes.slice(input.firstTakes.length)) })
      admittedBoundary = nextAdmission
      if (answer.market.tick % 52 === 0) {
        assert.ok(++progressRows <= 8)
        appendFileSync(progress, JSON.stringify({ week: answer.market.tick,
          elapsedSeconds: Number(process.hrtime.bigint() - diagnosticStarted) / 1e9 }) + '\n')
        appendFileSync(profile, JSON.stringify(profileRow(answer.market.tick, diagnosticStarted)) + '\n')
      }
      return answer
    })
    expect(state.market.tick).toBe(416); expect(weekly).toHaveLength(416)
    expect(phaseCalls).toBe(mode === 'observed' ? 416 : 0); expect(industryCalls).toBe(mode === 'observed' ? 416 : 0)
    const actualPins = { rows: rows.length, settled: rows.filter(r => r.kind === 'settled').length,
      declined: rows.filter(r => r.kind === 'declined').length, expired: rows.filter(r => r.kind === 'expired').length,
      settlement: settlementDigest(state), receipts: sha(JSON.stringify(state.talentMarket.receipts)),
      employment: sha(JSON.stringify(state.hollywood!.employment)), takes: sha(JSON.stringify(state.firstTakes)), rng: state.rngState }
    result.actualPins = actualPins
    result.pinComparisons = Object.fromEntries(Object.entries(actualPins).map(([key, value]) => [key, value === LEDGER_SEEDS[seed][key as keyof typeof actualPins]]))
    result.rows = copy(rows); result.finalStateDigest = sha(snap(state))
    result.finalMarket = copy(state.talentMarket); result.finalEmployment = copy(state.hollywood!.employment)
    result.finalIndustryReceipts = copy(state.hollywood!.receipts)
    result.finalRetirements = copy(state.careerLifecycle.records)
    result.completed = true
  } catch (error) { failed = error; result.failure = error instanceof Error ? error.stack : String(error) }
  finally {
    for (const restore of restores.reverse()) restore()
    try { guard(); result.sourcePostflight = true } catch (error) { result.sourcePostflight = false; result.completed = false; failed ??= error; result.guardFailure = String(error) }
    const bytes = JSON.stringify(result, null, 2) + '\n'
    assert.ok(Buffer.byteLength(bytes) <= 64 * 1024 * 1024, 'bounded diagnostic output exceeded 64 MiB')
    writeFileSync(output, bytes, { flag: 'wx' })
  }
  if (failed !== undefined) throw failed
}, 300_000)
