from pathlib import Path
import json, hashlib, ast
s=Path('/Users/zacheryspector/studio-scratch');p=s/'1368-ledger-r5-profile-proposal-20261005-r1'
old=(s/'1368-ledger-arms-04/ABC/tree/tests/1368-ledger-attribution.test.ts').read_text()
new=(p/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text()
def body(source, name):
 start=source.index('function '+name+'('); opening=source.index('{',start); depth=0
 for i in range(opening,len(source)):
  if source[i]=='{':depth+=1
  elif source[i]=='}':
   depth-=1
   if depth==0:return source[start:i+1]
 raise AssertionError(name)
for name in ['snap','owners','windowFacts','changedCases','admit']:
 a=body(old,name).replace('function '+name+'(','function raw'+name[0].upper()+name[1:]+'(',1)
 b=body(new,'raw'+name[0].upper()+name[1:])
 assert a==b,name
source=json.loads((p/'arm/SOURCE-PINS.json').read_text());frozen=json.loads((s/'1368-ledger-arms-04/ABC/SOURCE-PINS.json').read_text())
assert len(source)==len(frozen)==197
assert {k for k in source if source[k]!=frozen[k]}=={'tests/1368-ledger-attribution.test.ts'}
assert all(source[k]==frozen[k] for k in frozen if k.startswith('src/'))
assert old.count('admit(input,')==new.count('admit(input,')==1
assert old.count('admit(answer,')==new.count('admit(answer,')==1
assert old.count("}, 300_000)")==new.count("}, 300_000)")==1
assert old.count("phaseRows.push(")==new.count("phaseRows.push(")==1
assert old.count("industryRows.push(")==new.count("industryRows.push(")==1
assert old.count("weekly.push(")==new.count("weekly.push(")==1
ast.parse((p/'runner/run.py').read_text())
print(json.dumps({'rawFunctionBodiesExact':5,'regularFiles':197,'changedRelativePaths':['tests/1368-ledger-attribution.test.ts'],'productionSourceExact':True,'admissionAndOutputCallsitesExact':True,'runnerSyntax':True}))
