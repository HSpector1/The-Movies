"""Recorded strict types or exact two-arm ledger diagnostic modes; no assembly or policy changes."""
import argparse, hashlib, importlib.util, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
R = Path('/Users/zacheryspector/The-Movies-headless-program')
S = Path('/Users/zacheryspector/studio-scratch')
P = S / '1368-ledger-r5-profile-proposal-20261005-r1'
ARMS = P / 'arm'
KIT = P / 'kit'
RUNS = S / '1368-ledger-recorded-runs-r5-profile-r1'
SELF = P / 'runner' / 'run.py'
E = R / 'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
NODE = Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
CLEANUP = S / '1368-ledger-parent-prep-r4' / 'cleanup.py'
BRANCH = 'refs/heads/wip/headless-program-20260916-ts'
SCOPE = ['src', 'bridge', 'tests', 'ui', 'generated', 'scripts', 'package.json', 'package-lock.json', 'vitest.config.ts', 'vitest.workspace.ts', 'tsconfig.json', 'tsconfig.bridge.json', 'tsconfig.src.json', ':(exclude)tests/fixtures', ':(exclude)ui/e2e', ':(exclude)ui/public']
FIXED = {
    S / '1368-ledger-parent-prep-r4' / 'cleanup.py': '4698b610b50289fd289e3235c564c087774b443422ca7e0ac6635284babc49e4',
    Path('/Users/zacheryspector/studio-scratch/1368-rival-writing-guard-prep/MANIFEST.json'): '727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-01/ASSEMBLY.json'): '05cba942c8cb0d2ce8837f5b5020f7714b73a8a0db0ff8f4f72b7fc19381e1bd',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ASSEMBLY.json'): '8d027bf8e9cd6aa5e874b6f053e14b5b17be3701c6f4966b3b42610cf7fd6b38',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/C0/ASSEMBLY.json'): '7134409ad5d09a9d2dbb16080165b1161cc351c0042fc893d5d78874e13ed303',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/C0/SOURCE-PINS.json'): '00d4b886c0acbeb64ebc413348427723c7b5dcf0fbbce845fceb4a149d4d3a7f',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/ASSEMBLY.json'): 'c37c8d1a1c58a6729cc75a6fb5f38fd1158f60c9cf17a54c7b290aeec1a9f259',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/SOURCE-PINS.json'): '43ee074d7833ddae4993794b9084d603bb7eebd2943de7b7949e31759b5de336',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/kit/MANIFEST.json'): '01cea5e3beffcb65032dbd45bbb8c56a44016c913bff27c0f756e58d04353a53',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/kit/SOURCE-PINS.json'): 'a2ba20f3ac5009f11c938ec55b7cb21371f1f8d3b74b7febe0f344e95f93a61a',
    Path('/Users/zacheryspector/studio-scratch/1368-recovery-legacy-prep/run-recovery.py'): '7568362dbfdc07cf63d768dda14edd4e754f89b3aeae14ebf0ef335d8832be02',
    Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919/run-bounded-source-guards.py'): '1a1e144c25dd36320c64237d5b58f19d848eb85171fa777e5772c2c3fff1a20e',
    Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919/run-bounded-source-c2.mjs'): 'ae167b103ddaa714268cd63e163daa4966b0c3b8f07bfa3e9bd8f0c7d07751a2',
}
SEEDS = {"p13a-core-causal-01": "p13a", "p13-public-commercial-adoption": "adoption"}


def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def safe(path):
    assert path.is_absolute() and str(path) == os.path.abspath(path)
    for part in [path, *path.parents]: assert not part.is_symlink(), str(part)
def exclusive(path):
    safe(path); assert not os.path.lexists(path), 'existing output: ' + str(path)
def write(path, obj):
    with path.open('x') as f: json.dump(obj, f, indent=2); f.write('\n')
def environment():
    return dict(os.environ, PATH=str(NODE.parent) + ':' + str(R / '.venv/bin') + ':' + os.environ.get('PATH', ''), GIT_OPTIONAL_LOCKS='0')
def git(*args): return subprocess.check_output(['git', *args], cwd=R, env=environment())
def verify(head, manifest_pin, arm, runner_pin):
    assert arm == 'ABC'
    ARM = ARMS; T = ARM / 'tree'
    assert re.fullmatch('[0-9a-f]{40}', head)
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert git('symbolic-ref', 'HEAD').decode().strip() == BRANCH
    assert git('diff', '--name-only', 'HEAD', '--', *SCOPE) == b'', 'dirty live source'
    assert git('ls-files', '--others', '--exclude-standard', '--', *SCOPE) == b'', 'untracked live source'
    assert re.fullmatch('[0-9a-f]{64}', manifest_pin)
    safe(SELF); assert Path(__file__).resolve() == SELF
    assert re.fullmatch('[0-9a-f]{64}', runner_pin) and sha(SELF) == runner_pin
    safe(P / 'MANIFEST.json'); assert sha(P / 'MANIFEST.json') == manifest_pin
    package_manifest = json.loads((P / 'MANIFEST.json').read_text())
    assert package_manifest['runnerSha256'] == runner_pin
    assert package_manifest['sourcePinsSha256'] == sha(ARM / 'SOURCE-PINS.json')
    assert package_manifest['kitManifestSha256'] == sha(KIT / 'MANIFEST.json')
    assert package_manifest['assemblySha256'] == sha(ARM / 'ASSEMBLY.json')
    for name, row in package_manifest['files'].items():
        path = P / name; safe(path); assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
    for path, pin in FIXED.items(): safe(path); assert sha(path) == pin, str(path)
    source = json.loads((ARM / 'SOURCE-PINS.json').read_text()); assert len(source) == 197
    kit = json.loads((KIT / 'MANIFEST.json').read_text())
    for name, row in kit.items():
        path = KIT / name; safe(path); assert sha(path) == row
    kit_names = ['tests/1368-ledger-attribution.test.ts', 'tests/1368-ledger-original.ts', 'tsconfig.1368-ledger.json', 'vitest.1368-ledger.config.ts', 'vitest.1368-ledger.workspace.ts']
    assert sorted(n.removeprefix('files/') for n in kit if n.startswith('files/')) == sorted(kit_names)
    for name in kit_names: assert source[name] == kit['files/' + name]
    inputs = json.loads((KIT / 'SOURCE-PINS.json').read_text())[arm]
    assert len(inputs) == 189
    for name, pin in inputs.items(): assert source[name] == pin
    assembly = json.loads((ARM / 'ASSEMBLY.json').read_text())
    assert assembly['arm'] == arm and assembly['productionFiles'] == 188 and assembly['regularFiles'] == 197
    assert set(assembly['files']) == set(source)
    assert assembly['originalPins'] == inputs
    assert assembly['sourcePinsSha256'] == sha(ARM / 'SOURCE-PINS.json')
    assert assembly['kitManifestSha256'] == sha(KIT / 'MANIFEST.json')
    for name, row in assembly['files'].items(): assert source[name] == row['sha256'] and (T / name).stat().st_size == row['bytes']
    actual = []
    safe(T)
    for folder, dirs, files in os.walk(T, followlinks=False):
        root = Path(folder)
        if root == T:
            assert 'node_modules' in dirs; dirs.remove('node_modules')
        for name in dirs: safe(root / name)
        for name in files:
            path = root / name; safe(path); assert path.is_file() and path.stat().st_nlink == 1
            rel = path.relative_to(T).as_posix(); assert rel in source and sha(path) == source[rel], rel
            actual.append(rel)
    assert sorted(actual) == sorted(source)
    assert (T / 'node_modules').is_symlink() and (T / 'node_modules').resolve() == (R / 'node_modules').resolve()
    assert subprocess.check_output([str(NODE), '--version'], text=True).strip() == 'v20.20.2'
    entries = [NODE, T / 'node_modules/typescript/bin/tsc', T / 'node_modules/vitest/vitest.mjs']
    index = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    return {'arm': arm, 'publicationHead': head, 'publicationIndexSha256': sha(index), 'publicationStageSha256': digest(git('ls-files', '--stage', '-z')),
            'boundedDiffSha256': digest(git('diff', 'HEAD', '--', *SCOPE)), 'sourcePinsSha256': sha(ARM / 'SOURCE-PINS.json'),
            'assemblySha256': sha(ARM / 'ASSEMBLY.json'), 'kitManifestSha256': sha(KIT / 'MANIFEST.json'),
            'inputPinsSha256': sha(KIT / 'SOURCE-PINS.json'), 'runnerManifestSha256': manifest_pin, 'selfRunnerSha256': runner_pin,
            'entrypoints': {str(path): sha(path) for path in entries}, 'regularFiles': 197}
def command_for(mode, out):
    if mode == 'types': return [str(NODE), 'node_modules/typescript/bin/tsc', '--noEmit', '-p', 'tsconfig.1368-ledger.json']
    assert mode in ['clean', 'observed']
    return [str(NODE), 'node_modules/vitest/vitest.mjs', 'run', '--workspace', 'vitest.1368-ledger.workspace.ts', '--config', 'vitest.1368-ledger.config.ts', '--maxWorkers', '1', '--minWorkers', '1', '--no-file-parallelism', '--reporter=verbose', '--reporter=json', '--outputFile.json=' + str(out / 'vitest.json')]

def prior_types(path, pin, current):
    safe(path); assert sha(path) == pin
    receipt = json.loads(path.read_text())
    assert receipt['command'] == command_for('types', path.parent)
    assert receipt['mode'] == 'types' and receipt['allGuardsExact'] and receipt['actualChildExit'] == 0 and receipt['recorderChildExit'] == 0 and not receipt['timedOut']
    assert receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped'] and receipt['processGroup']['cleanupVerified'] and not receipt['reportingErrors']
    # Documentation publication may advance between modes; consumed source and kit must not.
    for name in ['arm', 'sourcePinsSha256', 'assemblySha256', 'kitManifestSha256', 'inputPinsSha256', 'runnerManifestSha256', 'selfRunnerSha256', 'entrypoints', 'regularFiles']:
        assert receipt['pins'][name] == current[name], 'types source differs: ' + name
    for name, row in receipt['artifacts'].items():
        f = Path(name); safe(f); assert sha(f) == row['sha256'] and f.stat().st_size == row['bytes']
def prior_clean(path, pin, current, seed):
    safe(path); assert sha(path) == pin
    receipt = json.loads(path.read_text())
    assert receipt['mode'] == 'clean' and receipt['arm'] == 'ABC' and receipt['seed'] == seed
    assert receipt['command'] == command_for('clean', path.parent)
    assert receipt['allGuardsExact'] and receipt['actualChildExit'] == receipt['recorderChildExit'] == 0 and not receipt['timedOut']
    assert receipt['processGroup']['cleanupVerified'] and receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped'] and not receipt['reportingErrors']
    for name in ['arm', 'sourcePinsSha256', 'assemblySha256', 'kitManifestSha256', 'inputPinsSha256', 'runnerManifestSha256', 'selfRunnerSha256', 'entrypoints', 'regularFiles']:
        assert receipt['pins'][name] == current[name], 'clean source differs: ' + name
    for name, row in receipt['artifacts'].items():
        f = Path(name); safe(f); assert sha(f) == row['sha256'] and f.stat().st_size == row['bytes']
    data = json.loads((path.parent / 'data.json').read_text())
    assert data['completed'] is True and data['sourcePostflight'] is True and data['mode'] == 'clean' and data['arm'] == 'ABC' and data['seed'] == seed and data['horizon'] == 416
    assert len(data['weekly']) == 416 and [x['week'] for x in data['weekly']] == list(range(1, 417))
    assert receipt['profileStatus'] == {'expected': True, 'present': True, 'sha256': sha(path.parent / 'profile.jsonl'), 'rows': list(range(52, 417, 52)), 'parseError': None}

def child(out, binding_pin):
    safe(out / 'binding.json'); assert sha(out / 'binding.json') == binding_pin
    b = json.loads((out / 'binding.json').read_text())
    assert b['arm'] == 'ABC'; T = ARMS / 'tree'
    assert b['mode'] in ['types', 'clean', 'observed']
    assert b['mode'] != 'observed' or b['arm'] == 'ABC'
    assert b['seed'] is None if b['mode'] == 'types' else b['seed'] in SEEDS
    assert b['outerCapSeconds'] == 330 and b['probeTestSeconds'] == 300 and b['horizon'] == 416
    assert b['command'] == command_for(b['mode'], out)
    assert b['profilePath'] == (str(out / 'profile.jsonl') if b['mode'] != 'types' else None)
    if b['profilePath'] is not None: exclusive(Path(b['profilePath']))
    assert verify(b['publicationHead'], b['manifestPin'], b['arm'], b['selfRunnerSha256']) == b['pins']
    if b['mode'] in ['clean', 'observed']: prior_types(Path(b['typesReceipt']), b['typesReceiptSha256'], b['pins'])
    if b['mode'] == 'observed': prior_clean(Path(b['cleanReceipt']), b['cleanReceiptSha256'], b['pins'], b['seed'])
    # Import only after verifying the reviewed helper's exact SHA; __main__ is not run.
    spec = importlib.util.spec_from_file_location('reviewed_cleanup', CLEANUP); helper = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode; sys.dont_write_bytecode = True
    try: spec.loader.exec_module(helper)
    finally: sys.dont_write_bytecode = old
    env = environment(); env.update(LEDGER_ARM=b['arm'], LEDGER_MODE=b['mode'], LEDGER_SEED=b['seed'] or '', LEDGER_OUTPUT=str(out / 'data.json'), LEDGER_PROGRESS=str(out / 'progress.jsonl'), LEDGER_PROFILE=b['profilePath'] or '')
    start = time.monotonic(); timed_out = False; wait_error = None
    with (out / 'stdout.txt').open('x') as stdout, (out / 'stderr.txt').open('x') as stderr:
        proc = subprocess.Popen(b['command'], cwd=T, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            # Persist launch identity before the bounded wait, independently of final reporting.
            write(out / 'LAUNCH.json', {'nodePid': proc.pid, 'ownedProcessGroup': proc.pid,
                'startNewSession': True, 'monotonicStarted': start, 'command': b['command'], 'bindingSha256': binding_pin})
            try: proc.wait(timeout=330)
            except subprocess.TimeoutExpired: timed_out = True
        except Exception as error:
            wait_error = error
        finally:
            def check_source():
                return verify(b['publicationHead'], b['manifestPin'], b['arm'], b['selfRunnerSha256']) == b['pins'] and sha(out / 'binding.json') == binding_pin
            def write_receipt(row):
                row.update(stdoutSha256=sha(out / 'stdout.txt'), stderrSha256=sha(out / 'stderr.txt'))
                write(out / 'CHILD.json', row)
            exit_code = helper.finish_child(proc, timed_out, start, b['command'], check_source, write_receipt, wait_error)
    return exit_code

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=['types', 'clean', 'observed']); ap.add_argument('--arm', required=True, choices=['C0', 'ABC']); ap.add_argument('--seed', choices=list(SEEDS)); ap.add_argument('--head', required=True)
    ap.add_argument('--manifest-sha256', required=True); ap.add_argument('--self-runner-sha256', required=True); ap.add_argument('--leaf', required=True)
    ap.add_argument('--types-receipt'); ap.add_argument('--types-receipt-sha256'); ap.add_argument('--clean-receipt'); ap.add_argument('--clean-receipt-sha256'); a = ap.parse_args()
    assert Path(__file__).resolve() == SELF
    assert re.fullmatch('[a-z0-9-]+', a.leaf)
    assert a.arm == 'ABC'
    assert a.seed is None if a.mode == 'types' else a.seed in SEEDS
    tag = a.arm + '-' + a.mode + '-' + (SEEDS[a.seed] if a.seed else 'source') + '-' + a.leaf
    out = RUNS / tag; exclusive(out)
    pins = verify(a.head, a.manifest_sha256, a.arm, a.self_runner_sha256)
    assert git('ls-remote', '--exit-code', 'origin', BRANCH).decode().split() == [a.head, BRANCH]
    if a.mode in ['clean', 'observed']:
        assert a.types_receipt and a.types_receipt_sha256
        prior_types(Path(a.types_receipt), a.types_receipt_sha256, pins)
    else: assert not a.types_receipt and not a.types_receipt_sha256
    if a.mode == 'observed':
        assert a.clean_receipt and a.clean_receipt_sha256
        prior_clean(Path(a.clean_receipt), a.clean_receipt_sha256, pins, a.seed)
    else: assert not a.clean_receipt and not a.clean_receipt_sha256
    assert shutil.disk_usage(R).free >= 3 * 1024**3
    stem = '1368-ledger-r5-profile-r1-' + tag.lower()
    for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']: exclusive(E / (stem + suffix))
    safe(RUNS); RUNS.mkdir(exist_ok=True); out.mkdir()
    command = command_for(a.mode, out)
    binding = {'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'horizon': 416, 'profilePath': str(out / 'profile.jsonl') if a.mode != 'types' else None, 'publicationHead': a.head, 'sourceStatus': 'ABC is the frozen r4 candidate production source with a separate profiling-only probe. Publication HEAD is coordinator provenance only; profiling is diagnostic, not gameplay acceptance', 'pins': pins, 'manifestPin': a.manifest_sha256, 'selfRunnerSha256': a.self_runner_sha256, 'command': command, 'typesReceipt': a.types_receipt, 'typesReceiptSha256': a.types_receipt_sha256, 'cleanReceipt': a.clean_receipt, 'cleanReceiptSha256': a.clean_receipt_sha256, 'outerCapSeconds': 330, 'probeTestSeconds': 300}
    write(out / 'binding.json', binding)
    with (out / 'power.txt').open('x') as f: subprocess.run(['pmset', '-g', 'batt'], stdout=f, check=True)
    subprocess.Popen(['caffeinate', '-is', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    guard = [sys.executable, str(E / 'run-bounded-source-guards.py')]
    subprocess.run([*guard, 'pre', stem, '0'], cwd=R, env=environment(), check=True)
    try:
        recorder = subprocess.run([str(NODE), str(E / 'run-bounded-source-c2.mjs'), stem, sys.executable, str(SELF), '--child', str(out), sha(out / 'binding.json')], cwd=R, env=environment()).returncode
    finally: post_code = subprocess.run([*guard, 'post', stem], cwd=R, env=environment()).returncode
    record = json.loads((E / (stem + '.json')).read_text()); post = json.loads((E / (stem + '-postflight.json')).read_text())
    assert recorder == post_code == 0
    assert record['command'] == [sys.executable, str(SELF), '--child', str(out), sha(out / 'binding.json')]
    assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
    assert record['sourceSha'] == record['sourceShaAtEnd'] == post['head'] == a.head
    assert record['exitCode'] == post['exitCode']
    assert verify(a.head, a.manifest_sha256, a.arm, a.self_runner_sha256) == pins
    # Reporting failure is evidence, never an invented Node exit or successful cleanup.
    try:
        child_result = json.loads((out / 'CHILD.json').read_text())
        assert isinstance(child_result, dict) and child_result['command'] == command
        assert isinstance(child_result['processGroup'], dict) and isinstance(child_result['reportingErrors'], list)
        assert isinstance(child_result['timedOut'], bool) and isinstance(child_result['allGuardsExact'], bool)
        assert child_result['actualChildExit'] is None or type(child_result['actualChildExit']) is int
        group = child_result['processGroup']
        assert all(type(group[key]) is bool for key in ['cleanupVerified', 'noSurvivors', 'leaderReaped'])
        code = child_result['actualChildExit']
        failed_reporting = bool(child_result['reportingErrors']) or not child_result['allGuardsExact']
        expected_exit = 124 if child_result['timedOut'] else (1 if failed_reporting or not group['cleanupVerified'] or not group['noSurvivors'] or not group['leaderReaped'] else (code if isinstance(code, int) and code >= 0 else 1))
        assert record['exitCode'] == post['exitCode'] == expected_exit, 'Node/cleanup/recorder exit mismatch'
    except Exception as error:
        paths = [f for f in out.iterdir() if f.is_file()] + [E / (stem + suffix) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']]
        for f in paths: safe(f)
        write(out / 'WRAPPER-FAILURE.json', {'status': 'INCOMPLETE_CHILD_REPORT', 'actualChildExit': None,
            'timedOut': None, 'noSurvivors': None, 'recorderChildExit': record['exitCode'],
            'livePostflightExact': True, 'command': command, 'errorType': type(error).__name__, 'error': str(error),
            'artifacts': {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in paths}})
        return 1
    if a.mode != 'types' and expected_exit == 0:
        data = json.loads((out / 'data.json').read_text())
        assert data['completed'] is True and data['sourcePostflight'] is True
        assert (data['arm'], data['mode'], data['seed'], data['horizon']) == (a.arm, a.mode, a.seed, 416)
        assert data['sourcePins'] == json.loads((KIT / 'SOURCE-PINS.json').read_text())[a.arm]
        report = json.loads((out / 'vitest.json').read_text())
        assert report['numTotalTests'] == report['numPassedTests'] == 1 and report['numFailedTests'] == 0
        progress = [json.loads(line) for line in (out / 'progress.jsonl').read_text().splitlines()]
        assert [row['week'] for row in progress] == list(range(52, 417, 52))
        assert all(set(row) == {'week', 'elapsedSeconds'} and isinstance(row['elapsedSeconds'], (int, float)) and 0 <= row['elapsedSeconds'] < float('inf') for row in progress)
        assert all(left['elapsedSeconds'] <= right['elapsedSeconds'] for left, right in zip(progress, progress[1:]))
        profile = [json.loads(line) for line in (out / 'profile.jsonl').read_text().splitlines()]
        assert [row['week'] for row in profile] == list(range(52, 417, 52))
        assert all(set(row) == {'week', 'elapsedSeconds', 'functions'} and set(row['functions']) == {'snap', 'admit', 'owners', 'windowFacts', 'changedCases'} for row in profile)
        assert all(set(stats) == {'calls', 'inclusiveNs', 'exclusiveNs'} and type(stats['calls']) is int and stats['calls'] >= 0 and
                   all(isinstance(stats[key], str) and stats[key].isdigit() for key in ['inclusiveNs', 'exclusiveNs']) and
                   int(stats['inclusiveNs']) >= int(stats['exclusiveNs']) for row in profile for stats in row['functions'].values())
        assert all(left['week'] == right['week'] and left['elapsedSeconds'] <= right['elapsedSeconds'] for left, right in zip(progress, profile))
        if a.mode == 'observed':
            assert profile[-1]['functions']['admit']['calls'] == 417
            assert profile[-1]['functions']['owners']['calls'] == 1664
            assert profile[-1]['functions']['windowFacts']['calls'] == 416
            assert profile[-1]['functions']['changedCases']['calls'] == 832
        else:
            assert profile[-1]['functions']['admit']['calls'] == 417
            assert profile[-1]['functions']['owners']['calls'] == 416
            assert profile[-1]['functions']['windowFacts']['calls'] == 0
            assert profile[-1]['functions']['changedCases']['calls'] == 416

    profile_path = out / 'profile.jsonl'
    profile_status = {'expected': a.mode != 'types', 'present': profile_path.is_file(), 'sha256': sha(profile_path) if profile_path.is_file() else None, 'rows': None, 'parseError': None}
    if profile_path.is_file():
        try:
            profile_rows = [json.loads(line) for line in profile_path.read_text().splitlines()]
            profile_status['rows'] = [row['week'] for row in profile_rows]
        except Exception as error:
            profile_status['parseError'] = type(error).__name__ + ': ' + str(error)
    paths = [f for f in out.rglob('*') if f.is_file()]
    for f in paths: safe(f)
    paths += [E / (stem + suffix) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']]
    artifacts = {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in sorted(paths)}
    write(out / 'RESULT.json', {**child_result, 'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'pins': pins, 'recorderChildExit': record['exitCode'], 'allGuardsExact': child_result['allGuardsExact'], 'livePostflightExact': True, 'profileStatus': profile_status, 'artifacts': artifacts, 'interpretation': 'Actual Node exit retained separately from recorder/wrapper status; diagnostic completion is not gameplay acceptance.'})
    print(json.dumps({'receipt': str(out / 'RESULT.json'), 'receiptSha256': sha(out / 'RESULT.json'), 'actualChildExit': child_result['actualChildExit'], 'timedOut': child_result['timedOut']}))
    return record['exitCode'] if isinstance(record['exitCode'], int) and record['exitCode'] >= 0 else 1
if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '--child': sys.exit(child(Path(sys.argv[2]), sys.argv[3]))
    sys.exit(main())
