const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const crypto = require('node:crypto')
const ts = require('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/tree/node_modules/typescript')
const root = '/Users/zacheryspector/studio-scratch/1368-ledger-r5-snap-optimization-proposal-20261005-r2'
function load(file) {
  const source = fs.readFileSync(`${root}/${file}`, 'utf8')
  const js = ts.transpileModule(source + '\nexports.snap = snap', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText
  const context = { exports: {}, assert, Buffer, Map, Set, Date, Object, ArrayBuffer, JSON, String, Number }
  vm.runInNewContext(js, context)
  return context.exports.snap
}
const frozen = load('snap-frozen.ts'), candidate = load('snap-candidate.ts')
const sha = value => crypto.createHash('sha256').update(value).digest('hex')
let fixtureCount = 0
function equal(value, label) {
  let a, b, ae, be
  try { a = frozen(value) } catch (error) { ae = `${error.name}:${error.message}` }
  try { b = candidate(value) } catch (error) { be = `${error.name}:${error.message}` }
  assert.equal(be, ae, `${label}: error`)
  assert.equal(b, a, `${label}: bytes`)
  fixtureCount++
  return a
}
const cases = [null, undefined, -0, 0, 1, -1, NaN, Infinity, -Infinity, 1n, true, false, '', 'a\n"b', [], [1, , 3], {z:1,a:{nested:[null,undefined,-0]}}, new Map([[{q:1},new Set([3,2])]]), new Date('2020-01-02T03:04:05.000Z'), new Uint8Array([0,255]), new ArrayBuffer(2), Object.assign(Object.create(null),{b:2,a:1})]
const cyclic = {}; cyclic.self = cyclic
cases.push(cyclic, Symbol('bad'), () => 1, Object.assign({}, {[Symbol('key')]: 1}), new (class Custom {constructor(){this.a=1}})())
for (let i=0;i<cases.length;i++) equal(cases[i],`edge-${i}`)
for (let i=0;i<400;i++) {
  const sample = {week:i, values:Array.from({length:i%25}, (_,j)=>({id:j, state:j%2?null:undefined, score:j/3, nested:[j,j*2]})), flags:new Set([i,i+1])}
  equal(sample,`generated-${i}`)
}
const data = JSON.parse(fs.readFileSync('/Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4-lowspace-r2/ABC-clean-p13a-r1/data.json','utf8'))
const samples = { weekly52: data.weekly[51], weekly208: data.weekly[207], finalMarket: data.finalMarket, finalEmployment: data.finalEmployment, recordedCleanData: data }
const output = { fixtureCount, recordedCleanDataIsFullGameState: false, samples: {} }
function timed(fn, value, reps) {
  let sum = 0n, digest
  for (let i=0;i<reps;i++) {
    const start = process.hrtime.bigint()
    const bytes = fn(value)
    sum += process.hrtime.bigint()-start
    digest = sha(bytes)
  }
  return { totalMs: Number(sum)/1e6, meanMs: Number(sum)/1e6/reps, digest }
}
for (const [name,value] of Object.entries(samples)) {
  const baseline = equal(value, name)
  const reps = name==='recordedCleanData' ? 3 : 30
  // Warm both implementations; alternate measurement order by sample.
  frozen(value); candidate(value)
  const first = name.length % 2 ? ['candidate','frozen'] : ['frozen','candidate']
  const results = {}
  for (const which of first) results[which] = timed(which==='frozen'?frozen:candidate,value,reps)
  output.samples[name] = { inputJsonBytes: Buffer.byteLength(JSON.stringify(value)), taggedBytes: Buffer.byteLength(baseline), taggedSha256: sha(baseline), reps, frozen:results.frozen, candidate:results.candidate, speedRatio: results.frozen.meanMs/results.candidate.meanMs }
}
fs.writeFileSync(`${root}/CHECK.json`,JSON.stringify(output,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({ fixtureCount: output.fixtureCount, samples:Object.fromEntries(Object.entries(output.samples).map(([k,v])=>[k,{reps:v.reps, frozenMs:v.frozen.meanMs, candidateMs:v.candidate.meanMs, speedRatio:v.speedRatio}])) }))
