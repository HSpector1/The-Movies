const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm')
const ts=require('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/tree/node_modules/typescript')
const root='/Users/zacheryspector/studio-scratch/1368-ledger-r5-snap-optimization-proposal-20261005-r3'
function load(name){const js=ts.transpileModule(fs.readFileSync(`${root}/${name}`,'utf8')+'\nexports.snap=snap',{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;const c={exports:{},assert,Buffer,Map,Set,Date,Object,ArrayBuffer,JSON,String,Number,WeakMap};vm.runInNewContext(js,c);return c.exports.snap}
const frozen=load('snap-frozen.ts'),candidate=load('snap-candidate.ts')
function makeAlias(){const shared={values:Array.from({length:100},(_,i)=>({i,text:`item-${i}`,score:i/3}))};return {rows:Array.from({length:80},()=>shared)}}
function duplicateCount(root){const seen=new WeakSet();let repeats=0,objects=0;function visit(v){if(v===null||typeof v!=='object')return;objects++;if(seen.has(v)){repeats++;return}seen.add(v);if(Array.isArray(v)){for(const x of v)visit(x)}else if(v instanceof Map){for(const [k,x] of v){visit(k);visit(x)}}else if(v instanceof Set){for(const x of v)visit(x)}else for(const x of Object.values(v))visit(x)}visit(root);return {objectsVisited:objects,repeatedIdentities:repeats}}
const aliased=makeAlias();assert.equal(frozen(aliased),candidate(aliased))
function timed(fn,v,reps){let start=process.hrtime.bigint();for(let i=0;i<reps;i++)fn(v);return Number(process.hrtime.bigint()-start)/1e6/reps}
const aliasBench={frozenMs:timed(frozen,aliased,10),candidateMs:timed(candidate,aliased,10),identity:duplicateCount(aliased)}
const data=JSON.parse(fs.readFileSync('/Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4-lowspace-r2/ABC-clean-p13a-r1/data.json','utf8'))
const recordedIdentity=duplicateCount(data)
function accessorFixture(){const shared={value:1};const b={};Object.defineProperty(b,'x',{enumerable:true,get(){shared.value=2;return shared}});return {a:shared,b}}
const oldBytes=frozen(accessorFixture()),newBytes=candidate(accessorFixture())
const result={aliasBench,recordedIdentity,accessorCounterexample:{equal:oldBytes===newBytes,frozen:oldBytes,candidate:newBytes}}
fs.writeFileSync(`${root}/ALIAS-CHECK.json`,JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({aliasBench,recordedIdentity,accessorEqual:oldBytes===newBytes}))
