#!/usr/bin/env python3
"""Exact data comparison after parent recorder admission; no automatic pin authorization."""
import argparse,hashlib,json,os
from collections import defaultdict
from pathlib import Path
p=argparse.ArgumentParser()
for name in ['baseline','clean','observed','out']:p.add_argument('--'+name,required=True)
a=p.parse_args();paths=[Path(getattr(a,k)) for k in ['baseline','clean','observed','out']]
for f in paths:
 assert f.is_absolute()
 for q in [f,*f.parents]:assert not q.is_symlink(),str(q)
assert not os.path.lexists(paths[3]) and paths[3].parent.resolve()==paths[3].parent
b,c,o=[json.loads(f.read_text()) for f in paths[:3]]
for x,arm,mode in [(b,'C0','clean'),(c,'ABC','clean'),(o,'ABC','observed')]:
 assert x['completed'] is True and x['sourcePostflight'] is True and x['arm']==arm and x['mode']==mode
 assert x['horizon']==416 and len(x['weekly'])==416 and [w['week'] for w in x['weekly']]==list(range(1,417))
 assert x['actualPins']['rows']==len(x['rows'])
 assert x['actualPins']['rows']==sum(x['actualPins'][k] for k in ['settled','declined','expired'])
assert b['seed']==c['seed']==o['seed'] and b['seed'] in ['p13a-core-causal-01','p13-public-commercial-adoption']
assert b['originalPins']==c['originalPins']==o['originalPins']
keys=['sourcePins','weekly','actualPins','pinComparisons','rows','finalStateDigest','finalMarket','finalEmployment','finalIndustryReceipts','finalRetirements']
parity={k:c[k]==o[k] for k in keys};assert all(parity.values()),parity
assert b['phaseRows']==b['industryRows']==c['phaseRows']==c['industryRows']==[]
assert [x['week'] for x in o['phaseRows']]==list(range(1,417))
assert [x['inputWeek'] for x in o['industryRows']]==list(range(416))
# The actual stable business key precedes the mutable event id. Preserve every
# occurrence and its source ordinal; no display-title or row collapse.
def buckets(rows):
 out=defaultdict(list)
 for ordinal,r in enumerate(rows):out[(r['week'],r['talentId'],r['subjectStudioId'])].append({'ordinal':ordinal,'row':r})
 return out
bs,cs=buckets(b['rows']),buckets(c['rows']);paired=[];missing=[];added=[]
for key in sorted(set(bs)|set(cs)):
 left,right=bs[key],cs[key];n=min(len(left),len(right))
 for i in range(n):paired.append({'key':key,'occurrence':i+1,'baseline':left[i],'current':right[i],'equal':left[i]['row']==right[i]['row']})
 missing.extend(left[n:]);added.extend(right[n:])
assert len(b['rows'])==len(paired)+len(missing)
assert len(c['rows'])==len(paired)+len(added)
assert len(c['rows'])-len(b['rows'])==len(added)-len(missing)

entry_transitions=[];cutting_terminations=[];withdrawals=[]
for phase in o['industryRows']:
 before={x['studioId']:x for x in phase['beforeOwners']}
 after={x['studioId']:x for x in phase['afterOwners']}
 for studio,row in after.items():
  old=before[studio]['recovery'];new=row['recovery']
  assert old['present'] and new['present']
  if old['since'] is None and new['since'] is not None:
   assert new['since']==phase['inputWeek'];entry_transitions.append({'week':phase['inputWeek'],'studioId':studio,'before':before[studio],'after':row})
 for receipt in phase['newReceipts']:
  if receipt['kind']!='employment' or receipt.get('reason')!='termination':continue
  studio=receipt['studioId'];owner=before[studio];since=owner['recovery']['since']
  changes=[e for e in phase['changedEmployment'] if e['after']['contractId']==receipt['contractId']]
  assert len(changes)==1
  if since is not None:
   entries=[e for e in entry_transitions if e['studioId']==studio and e['week']==since]
   assert len(entries)==1
   cutting_terminations.append({'receipt':receipt,'inputWeek':phase['inputWeek'],'entry':entries[0],'employment':changes[0],
    'ownerAtStaff':owner,'scope':'actual termination while cutting; full individual release legality belongs to its dedicated proof'})
for phase in o['phaseRows']:
 cutting={x['studioId']:x for x in phase['inputOwners'] if x['recovery']['present'] and x['recovery']['since'] is not None}
 for proposal in phase['proposalsBefore']:
  if proposal['issuerStudioId'] not in cutting:continue
  assert not any(q['talentId']==proposal['talentId'] and q['issuerStudioId']==proposal['issuerStudioId'] for q in phase['proposalsAfter'])
  withdrawals.append({'week':phase['week'],'proposal':proposal,'owner':cutting[proposal['issuerStudioId']],
   'scope':'actual market input is cutting; pinned source withdraws at entry before discovery/settlement and writes no withdrawal receipt'})

classified=[]
for item in missing:
 row=item['row'];cases=[k for k in b['finalMarket']['cases'] if k['talentId']==row['talentId'] and k['subjectStudioId']==row['subjectStudioId'] and k['closedWeek']==row['week'] and k['outcome']==row['kind']]
 assert len(cases)==1
 kase=cases[0];contracts=[e for e in b['finalEmployment'] if e['contractId']==kase['contractId']];assert len(contracts)==1
 old=contracts[0]
 same=[e for e in c['finalEmployment'] if e['contractId']==old['contractId'] and e['studioId']==old['studioId'] and e['terms']==old['terms']]
 finding={'baseline':item,'baselineCase':kase,'baselineContract':old,'currentSameContract':same,
  'classification':'unresolved historical/current route divergence; no causal label inferred from timing'}
 if len(same)==1 and same[0]['endedWeek'] is not None and same[0]['endedWeek']<same[0]['terms']['endWeekExclusive']:
  contract=same[0]
  release=[r for r in cutting_terminations if r['employment']['after']==contract]
  observations=[{'week':phase['week'],'fact':fact} for phase in o['phaseRows'] for fact in phase['windowFacts'] if fact['row']['contractId']==contract['contractId'] and fact['row']['terms']==contract['terms']]
  current_cases=[k for k in c['finalMarket']['cases'] if k['contractId']==contract['contractId']]
  if len(release)==1 and observations:
   finding.update({'classification':'same paid contract ended early while cutting; actual current discovery/invalidation evidence attached',
    'termination':release[0],'currentWindowObservations':observations,'currentCases':current_cases,
    'limit':'does not authorize a repin or infer later downstream missing contracts without an explicit lineage'})
 finding['personLineage']={
  'baselineEmployment':[e for e in b['finalEmployment'] if e['terms']['talentId']==row['talentId']],
  'currentEmployment':[e for e in c['finalEmployment'] if e['terms']['talentId']==row['talentId']],
  'baselineCases':[k for k in b['finalMarket']['cases'] if k['talentId']==row['talentId']],
  'currentCases':[k for k in c['finalMarket']['cases'] if k['talentId']==row['talentId']],
  'baselineReceipts':[r for r in b['finalMarket']['receipts'] if r['talentId']==row['talentId']],
  'currentReceipts':[r for r in c['finalMarket']['receipts'] if r['talentId']==row['talentId']],
  'cuttingTerminations':[r for r in cutting_terminations if r['employment']['after']['terms']['talentId']==row['talentId']],
  'currentOwnersDuringBaselineWindow':[{'week':p['week'],'owners':[{k:v for k,v in owner.items() if k!='account'} for owner in p['inputOwners']]} for p in o['phaseRows'] if kase['openedWeek']<=p['week']<=row['week']]
 }
 classified.append(finding)
# All changed ordinary fields are reported; C0 -> ABC includes A/F6/B/C, so a
# difference alone never selects one of those changes as its cause.
first_by_field={}
for bw,cw in zip(b['weekly'],c['weekly']):
 for key in ['changedEmployment','changedCases','newMarketReceipts','newIndustryReceipts','firstTakes','rng']:
  if key not in first_by_field and bw[key]!=cw[key]:first_by_field[key]={'week':bw['week'],'baseline':bw[key],'current':cw[key]}
result={'scope':'two original natural ledger routes, independently compared one seed at a time; diagnostic only',
 'seed':b['seed'],'horizon':416,'inputHashes':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in paths[:3]},
 'currentParity':parity,'originalPins':b['originalPins'],'baselineActualPins':b['actualPins'],'currentActualPins':c['actualPins'],
 'baselinePinComparisons':b['pinComparisons'],'currentPinComparisons':c['pinComparisons'],
 'counts':{'baseline':len(b['rows']),'current':len(c['rows']),'paired':len(paired),'missing':len(missing),'added':len(added)},
 'paired':paired,'missing':classified,'added':added,'actualEntryTransitions':entry_transitions,
 'actualCuttingTerminations':cutting_terminations,'sourceBoundWithdrawals':withdrawals,'firstOrdinaryDifferences':first_by_field,
 'limits':['Parent recorder/command/source/postflight admission remains mandatory.',
  'Old T2 cannot-move pins and preexisting baseline failures remain; no expectation changes.',
  'C0 versus ABC combines A, F6, B and C; unresolved rows remain unresolved rather than assigned by temporal association.',
  'This does not prove all release eligibility/accounting or replace the separate six-termination diagnostic.']}
with paths[3].open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'parity':True,'seed':b['seed'],'counts':result['counts']}))
