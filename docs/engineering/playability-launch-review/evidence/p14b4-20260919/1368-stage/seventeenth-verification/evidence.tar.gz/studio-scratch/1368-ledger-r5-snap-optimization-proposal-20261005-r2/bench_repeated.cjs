const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const ts = require('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/tree/node_modules/typescript')
const root = '/Users/zacheryspector/studio-scratch/1368-ledger-r5-snap-optimization-proposal-20261005-r2'
function load(file) {
 const js=ts.transpileModule(fs.readFileSync(`${root}/${file}`,'utf8')+'\nexports.snap=snap',{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText
 const c={exports:{},assert,Buffer,Map,Set,Date,Object,ArrayBuffer,JSON,String,Number};vm.runInNewContext(js,c);return c.exports.snap
}
const frozen=load('snap-frozen.ts'), candidate=load('snap-candidate.ts')
const data=JSON.parse(fs.readFileSync('/Users/zacheryspector/studio-scratch/1368-ledger-recorded-runs-r4-lowspace-r2/ABC-clean-p13a-r1/data.json','utf8'))
const samples={weekly208:data.weekly[207],finalMarket:data.finalMarket,finalEmployment:data.finalEmployment,recordedCleanData:data}
const report={}
function median(v){v=[...v].sort((a,b)=>a-b);return (v[Math.floor((v.length-1)/2)]+v[Math.floor(v.length/2)])/2}
function measure(fn,value,reps){let sum=0;for(let i=0;i<reps;i++){let start=process.hrtime.bigint();fn(value);sum+=Number(process.hrtime.bigint()-start)/1e6}return sum/reps}
for(const [name,value] of Object.entries(samples)){
 assert.equal(candidate(value),frozen(value))
 for(let i=0;i<3;i++){frozen(value);candidate(value)}
 const reps=name==='recordedCleanData'?1:20
 const f=[],c=[]
 for(let round=0;round<8;round++){
  if(global.gc)global.gc()
  if(round%2===0){f.push(measure(frozen,value,reps));c.push(measure(candidate,value,reps))}
  else{c.push(measure(candidate,value,reps));f.push(measure(frozen,value,reps))}
 }
 report[name]={repsPerRound:reps,rounds:8,frozenMs:f,candidateMs:c,medianFrozenMs:median(f),medianCandidateMs:median(c),ratio:median(f)/median(c)}
}
fs.writeFileSync(`${root}/REPEATED-BENCH.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(Object.fromEntries(Object.entries(report).map(([k,v])=>[k,{frozen:v.medianFrozenMs,candidate:v.medianCandidateMs,ratio:v.ratio}]))))
