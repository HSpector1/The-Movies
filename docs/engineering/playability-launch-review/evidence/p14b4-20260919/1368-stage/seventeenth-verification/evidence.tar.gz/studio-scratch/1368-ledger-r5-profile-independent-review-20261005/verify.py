from pathlib import Path
import hashlib,json,os,subprocess,tempfile
S=Path('/Users/zacheryspector/studio-scratch')
P=S/'1368-ledger-r5-profile-proposal-20261005-r1'
B=S/'1368-ledger-arms-04/ABC'
R=Path('/Users/zacheryspector/The-Movies-headless-program')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'README.md')=='7b961028a72fe06cda2bdf87e22a6539f94caaa00f3a3574e56137695104dff7'
assert sha(P/'MANIFEST.json')=='55c993b5f350e5133603aa13c224fa2c62d2304924ade0d075f62cb0c2a4260a'
assert sha(P/'runner/run.py')=='74ae1b3a965bd1b6034f055d714b066faf8868535d65187638d98ddeb1d5ad47'
assert sha(P/'PROBE.diff')=='3fdceb6473f586a1a59bfa647f354f2ace5d4b1d66b004cd97e12afe8422f698'
assert sha(P/'RUNNER.diff')=='9e73a5c74c2b9cb2f7def6aa7b10b996b187ffa04c9f1c277455f9d3d51e8265'
m=json.loads((P/'MANIFEST.json').read_text());assert len(m['files'])==218
for name,row in m['files'].items():
 path=P/name
 assert path.is_file() and not path.is_symlink() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],name
source=json.loads((P/'arm/SOURCE-PINS.json').read_text());base=json.loads((B/'SOURCE-PINS.json').read_text())
assert len(source)==len(base)==197
assert [n for n in source if source[n]!=base[n]]==['tests/1368-ledger-attribution.test.ts']
assert all(source[n]==base[n] for n in base if n.startswith('src/'))
assert all(sha(P/'arm/tree'/n)==source[n] for n in source)
assert set(n.removeprefix('arm/tree/') for n in m['files'] if n.startswith('arm/tree/'))==set(source)
assert (P/'arm/tree/node_modules').is_symlink() and (P/'arm/tree/node_modules').resolve()==(R/'node_modules').resolve()
old=(B/'tree/tests/1368-ledger-attribution.test.ts').read_text();new=(P/'arm/tree/tests/1368-ledger-attribution.test.ts').read_text()
# The diff files must reconstruct the copied source and runner exactly.
for oldfile,newfile,diff in [(B/'tree/tests/1368-ledger-attribution.test.ts',P/'arm/tree/tests/1368-ledger-attribution.test.ts',P/'PROBE.diff'),(S/'1368-ledger-lowspace-runner-proposal-r2/run.py',P/'runner/run.py',P/'RUNNER.diff')]:
 with tempfile.TemporaryDirectory() as td:
  target=Path(td)/'patched'
  res=subprocess.run(['patch','-s','-o',str(target),str(oldfile),str(diff)],capture_output=True)
  assert res.returncode==0 and target.read_bytes()==newfile.read_bytes(),(str(diff),res.stderr.decode())
# The original config retains the probe timeout and original output keys.
assert 'testTimeout: 300_000' in (P/'kit/files/vitest.1368-ledger.config.ts').read_text()
assert '}, 300_000)' in new
assert new.count('phaseRows.push(')==old.count('phaseRows.push(')==1
assert new.count('weekly.push(')==old.count('weekly.push(')==1
assert new.count('industryRows.push(')==old.count('industryRows.push(')==1
assert new.count('admit(input,')==old.count('admit(input,')==1
assert new.count('admit(answer,')==old.count('admit(answer,')==1
# Runner caps and complete/partial sidecar handling are independently inspected in REVIEW.
runner=(P/'runner/run.py').read_text()
for fragment in ["'outerCapSeconds': 330", "'probeTestSeconds': 300", "proc.wait(timeout=330)", "LEDGER_PROFILE=b['profilePath'] or ''", "profileStatus", "'artifacts': artifacts", "prior_types(Path(b['typesReceipt'])", "prior_clean(Path(b['cleanReceipt'])"]:assert fragment in runner,fragment
assert m['runnerSha256']==sha(P/'runner/run.py') and m['sourcePinsSha256']==sha(P/'arm/SOURCE-PINS.json') and m['assemblySha256']==sha(P/'arm/ASSEMBLY.json') and m['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
report={'decision':'ACCEPT','packageManifestSha256':sha(P/'MANIFEST.json'),'runnerSha256':sha(P/'runner/run.py'),'probeDiffSha256':sha(P/'PROBE.diff'),'runnerDiffSha256':sha(P/'RUNNER.diff'),'membersVerified':218,'regularArmFiles':197,'changedArmFiles':['tests/1368-ledger-attribution.test.ts'],'productionFilesByteExact':188,'patchReadbackExact':True,'originalCapsAndOutputCallsitesRetained':True,'heavyRunPerformed':False,'independentTypecheckExit':0,'isolatedAccountingExit':0,'isolatedStaticExit':0,'readOnlyRunnerVerifyExit':0,'partialProfileInterpretation':'artifact and parse status only until independent line/counter validation'}
out=Path(__file__).with_name('RECEIPT.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
