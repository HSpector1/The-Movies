# 1368 r5 observed cost attribution — scratch design, no run

This is a **separate diagnostic design**, not the r5 index optimization and not an assembled kit or runner. Do not edit or repin r4. Do not infer a gameplay result from the r4 observed timeout. The proposed `profile52-r1` command below is intentionally conditional on a future independently reviewed diagnostic kit, runner, source manifest, and fresh same-source types/clean receipts; it must not be invoked with current r4 pins.

## What to measure

Add a new, version-pinned *instrumented copy of the frozen r4 probe*, without applying the index proposal. Measure the original `snap`, `admit`, `owners`, `windowFacts`, and `changedCases` function bodies using `process.hrtime.bigint()` at function entry and exit in a `try/finally`. Keep the original function calls, body statements, values, errors, and order. Track a stack of measured frames to record both inclusive nanoseconds and exclusive nanoseconds (subtract time inside nested measured functions); report call counts and interval deltas. This matters because `admit` calls `snap`, and a sum of inclusive times would double count it. Record a separate unclassified wall-time residual rather than assigning Vitest, `tick`, cloning, assertions, industry/market work, GC, and profiler overhead to one of these functions. A small timing wrapper is itself overhead; the diagnostic does not prove a speedup.

Require a fresh absolute `LEDGER_PROFILE` path, reject symlink ancestors and existing leaf, and create it exclusively. At each *existing* `answer.market.tick % 52 === 0` branch, after the original progress append, synchronously append one JSON line to `profile.jsonl`: `week`, `elapsedSeconds`, and, for each of the five measured functions, cumulative/delta `calls`, `inclusiveNs`, and `exclusiveNs` as decimal strings. Capture counters after the week's original `weekly.push`/admission and before returning `answer`. The sidecar does not enter `GameState`, its RNG, `data.json`, or any existing output row. Counter access cannot branch game logic. At week 52, require 53 admission calls, 52 `windowFacts`, 52 industry and 52 market callbacks, 208 `owners` (industry before/after, market input, weekly), 104 `changedCases` (market and weekly), and at least 680 `snap` calls (212 in the 53 admissions plus 468 from two weekly and seven phase traversals; changed-row comparisons may add more). Assert monotone nonnegative counters and exactly the eight planned week labels if the full route completes. On timeout/failure, preserve whatever prefix exists, without treating absent later rows as success.

The new diagnostic runner must bind the profile path and its SHA into its own RESULT artifacts, verify the profile file at child/recorder postflight, retain strict source/index/HEAD guards and process-group cleanup, and leave the 300-second Vitest timeout and 330-second outer cap unchanged. The profiler's sidecar is additional evidence; all existing `data.json` fields and schema, original progress rows, formal raw/JSON/postflight paths, failure receipts and output guard behavior remain. No new producer may write to the frozen r4 leaf or formal namespace.

## Exact identity and equivalence gates

1. Rehash the frozen r4 ABC probe (`76fb3eddf1b6bab3e8723908d9d2840ef4df491f4f41a23f864c6ea45ddff755`) and r4 manifest (`3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f`). Diff the proposed diagnostic probe: only profiler scaffolding, five timing wrappers, exclusive sidecar creation, and one profile append at the existing 52-week branch may differ. Preserve the seven full tagged phase snapshot traversals, the 417 public save/migration admissions on completion, all argument/input/state/RNG neutrality assertions, original output fields, two seed definitions, 416 horizon, original production 188, 197 regular arm files, and protected failure receipts. Do not compose this diagnostic with the separate r5 index candidate; first measure the unchanged lookup implementations.
2. Unit-check stack accounting on static nested-function fixtures, including thrown functions; verify inclusive/exclusive deltas sum correctly and exceptions are rethrown. Run old/new probe functions on static admissible fixtures and compare return values, state and RNG bytes, exceptions, and existing serialized output fields exactly. Typecheck a disposable diagnostic arm and review all new source/kit/runner hashes independently before any heavy task.
3. Assemble an isolated diagnostic arm and runner with fresh source pins, self-runner SHA, manifest, output namespace, and strict same-source types/clean prerequisites. Before the observed diagnostic, require accepted types and clean RESULTs with actual child=recorder 0, exact formal pre/postflight, complete 416-week data and eight progress rows, artifact rehash, no survivors, and an exact clean-output comparison against the r4 ABC clean p13a record on shared fields (ignore timing sidecar; compare `data.json` byte-for-byte if JSON formatting and sourcePins permit, otherwise compare every common value with an explicit field diff). No source or deadline repin can be inferred from a wrapper exit alone.
4. For observed, check full local HEAD equals explicit remote HEAD, tracked tree clean, AC/free-space/lane gate, unused scratch/formal/log paths, all approved r5 diagnostic pins and accepted receipt SHAs. A first-52 profile line is diagnostic evidence only. For a complete route, require all 416 weeks, 417 admissions, seven phase traversals per week, eight profile rows, exact output/seed pins, actual child/recorder 0, no timeout and no survivors. If it times out, require honest child/recorder/cleanup/postflight receipts, rehash the partial profile, stop, and make no comparator or causal claim.

## One bounded first-52 diagnostic command for later review

This command deliberately starts the unchanged **416-week** observed route under its original 300/330-second bounds; “first-52” names the first profile checkpoint to inspect, **not** a shortened horizon or permission to terminate at week 52. It is a template until a diagnostic runner and fresh types/clean receipts have been independently accepted. The required `R5_*_APPROVED_SHA` values must come from that review, never be self-approved from the files being launched. No command in this document was executed.

```sh
set -euo pipefail
S=/Users/zacheryspector/studio-scratch
R=/Users/zacheryspector/The-Movies-headless-program
: "${R5_PROFILE_MANIFEST_APPROVED_SHA:?independent r5 diagnostic manifest pin required}"
: "${R5_PROFILE_RUNNER_APPROVED_SHA:?independent r5 diagnostic runner pin required}"
: "${R5_PROFILE_TYPES_APPROVED_SHA:?accepted same-source types RESULT SHA required}"
: "${R5_PROFILE_CLEAN_APPROVED_SHA:?accepted same-source clean RESULT SHA required}"
LEDGER_HEAD="$(git -C "$R" rev-parse HEAD)"
LEDGER_REMOTE_HEAD="$(git -C "$R" ls-remote --exit-code origin refs/heads/wip/headless-program-20260916-ts | awk '{print $1}')"
test "$LEDGER_HEAD" = "$LEDGER_REMOTE_HEAD"
test -z "$(git -C "$R" diff --name-only)"
test -z "$(git -C "$R" diff --cached --name-only)"
test ! -e "$S/heavy-queue/HEAVY-LANE-LOCK"
test ! -e "$S/1368-ledger-recorded-runs-r5-profile-r1/ABC-observed-p13a-profile52-r1"
test ! -e "$S/heavy-queue/1368-ledger-r5-profile52-r1.log"
test ! -e "$S/heavy-queue/1368-ledger-r5-profile52-r1.log.meta"
pmset -g batt | rg -q "Now drawing from 'AC Power'"
FORMAL="$R/docs/engineering/playability-launch-review/evidence/p14b4-20260919"
STEM=1368-ledger-r5-profile-r1-abc-observed-p13a-profile52-r1
for suffix in .json .txt .patch -preflight.json -postflight.json; do test ! -e "$FORMAL/$STEM$suffix"; done
test "$(shasum -a 256 "$S/1368-ledger-r5-profile-runner-r1/MANIFEST.json" | awk '{print $1}')" = "$R5_PROFILE_MANIFEST_APPROVED_SHA"
test "$(shasum -a 256 "$S/1368-ledger-r5-profile-runner-r1/run.py" | awk '{print $1}')" = "$R5_PROFILE_RUNNER_APPROVED_SHA"
test "$(shasum -a 256 "$S/1368-ledger-recorded-runs-r5-profile-r1/ABC-types-source-r1/RESULT.json" | awk '{print $1}')" = "$R5_PROFILE_TYPES_APPROVED_SHA"
test "$(shasum -a 256 "$S/1368-ledger-recorded-runs-r5-profile-r1/ABC-clean-p13a-r1/RESULT.json" | awk '{print $1}')" = "$R5_PROFILE_CLEAN_APPROVED_SHA"
python3 -c 'import shutil; assert shutil.disk_usage("/Users/zacheryspector/The-Movies-headless-program").free >= 3*1024**3'
bash "$S/heavy-queue/lane-run.sh" 0 "$S/heavy-queue/1368-ledger-r5-profile52-r1.log" python3 -B "$S/1368-ledger-r5-profile-runner-r1/run.py" observed --arm ABC --seed p13a-core-causal-01 --head "$LEDGER_HEAD" --manifest-sha256 "$R5_PROFILE_MANIFEST_APPROVED_SHA" --self-runner-sha256 "$R5_PROFILE_RUNNER_APPROVED_SHA" --leaf profile52-r1 --types-receipt "$S/1368-ledger-recorded-runs-r5-profile-r1/ABC-types-source-r1/RESULT.json" --types-receipt-sha256 "$R5_PROFILE_TYPES_APPROVED_SHA" --clean-receipt "$S/1368-ledger-recorded-runs-r5-profile-r1/ABC-clean-p13a-r1/RESULT.json" --clean-receipt-sha256 "$R5_PROFILE_CLEAN_APPROVED_SHA"
```

Before any launch, the reviewer must also check no surviving writer and the new runner's binding of `LEDGER_PROFILE` to `profile.jsonl`; absence of those gates stops the command. The run must be allowed to close under its original watchdog and formal postflight even after week 52. Read the sidecar only after checking its bound path and hash in the completed/timeout RESULT. Compare week-52 deltas to total elapsed and the unclassified residual; do not sum inclusive categories as if disjoint.
