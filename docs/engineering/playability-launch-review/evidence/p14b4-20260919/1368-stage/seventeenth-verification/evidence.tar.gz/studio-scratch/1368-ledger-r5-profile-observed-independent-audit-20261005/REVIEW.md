# Independent r5-profile observed outcome audit

Decision: **ACCEPT as an exact, incomplete timeout diagnostic**. The 416-week observed route did not complete, so this is not an unchanged-comparator input, gameplay acceptance, or a measured speedup for the separate r5 index proposal.

The observed RESULT hashes to `b97e94b3c15526d43bd2895946290909c5fb6335550154b170e973b9bd79d535`. It binds the frozen 218-member profile package manifest (`55c993b5f350e5133603aa13c224fa2c62d2304924ade0d075f62cb0c2a4260a`), runner self hash, ABC arm/seed, and the accepted fresh r5-profile types and clean RESULT hashes. I rehashed all 218 package files and all 13 RESULT artifacts. The formal record (`b94f30ccd88cbae41c38286f2c38ff8494147f19b20a37b521c4b1c8d2ceee1f`) and postflight (`7efd1046e708b90dae0fc925a85568617372b49e26def26d93b42af3569bb89a`) agree on HEAD, fixed source and exit 124. The lane wrapper also ended exit 124. The actual Node child was terminated by TERM (exit -15) after the original 330-second wait; the process group was reaped, cleanup verified, no survivors or reporting errors remained. `data.json` and `vitest.json` are absent, and the RESULT makes no completion claim.

The partial `profile.jsonl` SHA is `fb320e67aeac5ed255d2e8aa30278fdc61505364e720e28e938a978f4e4125c7`. It has five complete, parseable rows at weeks 52, 104, 156, 208 and 260, exactly paired with progress rows. Cumulative counters and decimal nanosecond fields are monotonic, nonnegative and satisfy exclusive ≤ inclusive. Observed checkpoint call counts equal the source route: `admit` is week+1, `owners` is 4×week, `windowFacts` is week and `changedCases` is 2×week. No row exists after week 260; the final 60.5 seconds before cleanup is unprofiled by checkpoint, and no week-312 state is inferred.

| Weeks | Wall interval (s) | `snap` exclusive (s) | `admit` exclusive (s) | Other measured exclusive (s) |
|---|---:|---:|---:|---:|
| 1–52 | 39.712 | 30.385 | 6.397 | 0.035 |
| 53–104 | 48.719 | 37.963 | 8.018 | 0.036 |
| 105–156 | 57.709 | 44.733 | 9.494 | 0.038 |
| 157–208 | 61.685 | 47.597 | 10.213 | 0.051 |
| 209–260 | 63.555 | 49.049 | 10.943 | 0.051 |

Across measured weeks 1–260, exclusive `snap` time is 209.726 seconds and exclusive `admit` time is 45.065 seconds, from 271.380 seconds wall. Their exclusive totals do not overlap; inclusive totals do overlap because `admit` and `changedCases` call `snap`. The five measured exclusive categories total 255.003 seconds, leaving 16.377 seconds of residual checkpoint wall time for unmeasured work and instrumentation overhead. `owners`/`windowFacts`/`changedCases` together account for only about 0.211 seconds exclusive through week 260. These are observations under the instrumented probe, not proof that removing any original assertion or traversal is safe; profiling may itself alter the timing.

`verify.py` independently validates package, formal, cleanup and artifact binding, checkpoint schema and exact counter deltas. `RECEIPT.json` holds the raw per-window values. No live or frozen source file was edited and no heavy task was launched by this audit.
