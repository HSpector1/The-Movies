from pathlib import Path
p=Path('/Users/zacheryspector/studio-scratch/1368-ledger-r5-profile-proposal-20261005-r1')
f=p/'arm/tree/tests/1368-ledger-attribution.test.ts'
s=f.read_text()
needle='const copy = <T>(value: T): T => structuredClone(value)\n'
scaffold='''type ProfileName = 'snap' | 'admit' | 'owners' | 'windowFacts' | 'changedCases'
const profileNames: ProfileName[] = ['snap', 'admit', 'owners', 'windowFacts', 'changedCases']
const profileTotals = Object.fromEntries(profileNames.map(name => [name, { calls: 0, inclusiveNs: 0n, exclusiveNs: 0n }])) as Record<ProfileName, { calls: number; inclusiveNs: bigint; exclusiveNs: bigint }>
const profileStack: { started: bigint; childNs: bigint }[] = []
function measured<T>(name: ProfileName, operation: () => T): T {
  const parent = profileStack.at(-1)
  const frame = { started: process.hrtime.bigint(), childNs: 0n }
  profileStack.push(frame)
  try { return operation() }
  finally {
    const elapsed = process.hrtime.bigint() - frame.started
    assert.equal(profileStack.pop(), frame)
    const total = profileTotals[name]
    total.calls++
    total.inclusiveNs += elapsed
    total.exclusiveNs += elapsed - frame.childNs
    if (parent !== undefined) parent.childNs += elapsed
  }
}
function profileRow(week: number, started: bigint) {
  assert.equal(profileStack.length, 0)
  return { week, elapsedSeconds: Number(process.hrtime.bigint() - started) / 1e9,
    functions: Object.fromEntries(profileNames.map(name => {
      const total = profileTotals[name]
      assert.ok(total.inclusiveNs >= total.exclusiveNs && total.exclusiveNs >= 0n)
      return [name, { calls: total.calls, inclusiveNs: String(total.inclusiveNs), exclusiveNs: String(total.exclusiveNs) }]
    })) }
}
'''
assert s.count(needle)==1;s=s.replace(needle,needle+scaffold)
changes=[
('function snap(value: unknown): string {','function rawSnap(value: unknown): string {','\nconst SOURCE_PINS =',"\nfunction snap(value: unknown): string { return measured('snap', () => rawSnap(value)) }\n"),
('function owners(h: Hollywood) {','function rawOwners(h: Hollywood) {','\nfunction caseKey(',"\nfunction owners(h: Hollywood) { return measured('owners', () => rawOwners(h)) }\n"),
('function changedCases(before: GameState, after: GameState) {','function rawChangedCases(before: GameState, after: GameState) {','\nfunction windowFacts(',"\nfunction changedCases(before: GameState, after: GameState) { return measured('changedCases', () => rawChangedCases(before, after)) }\n"),
('function windowFacts(state: GameState) {','function rawWindowFacts(state: GameState) {','\nfunction admit(',"\nfunction windowFacts(state: GameState) { return measured('windowFacts', () => rawWindowFacts(state)) }\n"),
('function admit(state: GameState, expectedVersion: number) {','function rawAdmit(state: GameState, expectedVersion: number) {',"\nit('1368 original", "\nfunction admit(state: GameState, expectedVersion: number) { return measured('admit', () => rawAdmit(state, expectedVersion)) }\n")]
for old,new,bound,wrapper in changes:
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
 assert s.count(bound)==1,(bound,s.count(bound));s=s.replace(bound,wrapper+bound)
needle='  const progress = process.env.LEDGER_PROGRESS; assert.ok(progress); exclusive(progress)\n  writeFileSync(progress, \'\', { flag: \'wx\' })'
replace=needle+"\n  const profile = process.env.LEDGER_PROFILE; assert.ok(profile); exclusive(profile)\n  writeFileSync(profile, '', { flag: 'wx' })"
assert s.count(needle)==1;s=s.replace(needle,replace)
needle="          elapsedSeconds: Number(process.hrtime.bigint() - diagnosticStarted) / 1e9 }) + '\\n')"
replace=needle+"\n        appendFileSync(profile, JSON.stringify(profileRow(answer.market.tick, diagnosticStarted)) + '\\n')"
assert s.count(needle)==1;s=s.replace(needle,replace)
f.write_text(s)
shutil=None
(p/'kit/files/tests/1368-ledger-attribution.test.ts').write_text(s)
