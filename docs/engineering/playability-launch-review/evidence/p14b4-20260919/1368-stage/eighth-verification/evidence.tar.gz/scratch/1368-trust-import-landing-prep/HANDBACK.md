# Original trust leaf: genuine imported-current input

Prepared only against the exact r4 test preimage. No runtime, typecheck, fixture installation, production edit or live/r4 mutation occurred. Parent adopts the two accepted fixture bytes at a safe publication, then integrates and measures this separately reviewed patch.

The patch changes one existing file, tests/p14b1-trust-chooser.test.ts, and adds tests/helpers/1368-trust-import.ts. Only the original three-witness leaf receives the imported input and a title naming that scope. Its complete callback body, three final witness assertions, first-writer-before-positive-actor requirement, all candidate/feasibility ordering, exact material/digest/root/receipt checks and negative zero-attachment oracle remain unchanged. ORACLE-PRESERVATION.json checks the callback byte-for-byte after removing only the new scanner input argument; assertOriginalAuthoring is byte-identical. No expectation, receipt count or trust classification is repinned.

The scanner gains an optional state argument and begins its existing loop at that state's real market tick, retaining absolute campaign week 220 as the upper boundary. The imported leaf starts at 195 and may perform only the ordinary ticks through 220, with its original early return when all witnesses are found. The other scanner caller still creates the original current genesis at week 0 and retains its full original 220-tick bound; no other test uses the imported fixture. The independently accepted diagnostic separately covered all 26 boundaries 195..220 with clean/observed full-state parity; this patch does not pretend the early-return original leaf itself performs that full diagnostic.

## Accepted provenance and portable loader

Independent TRUST-IMPORTED-CURRENT-WITNESSES-MEASURED.md is pinned at 63e22f36548e43b2ed57f9d8b7e29e1f1f1aeed8c9573a48a8bec44e57ac9bb5. The accepted original Save45 source is 2eaa697effc38538c37da28b486786ce267a2284, src88d0197645b3a5bd69d73ebff0c5c1c9ff0aa837; ordinary p13a-core-causal-01 genesis and 195 ticks. Parent-authorized fixture destination:

`tests/fixtures/p14/genuine-v45-trust-authoring-week195-1368/`

Copy only MANIFEST.json (0b98763001eb96949d8e312df5dfe600f1adf599f5466dd59eec214e1f229991, 41,502 bytes) and week195.save45.json.gz (f23c298aeea06724b983564f192cbcc0d100aa5f9e27744a82e1fac495d47899, 135,408 bytes) from the accepted capture directory named in FIXTURE-ADOPTION.json. No fixture payload was decoded, authored or copied during preparation; only the accepted compressed hash/length and manifest were read.

The helper defaults to that repository fixture directory. Isolated candidates may supply both TRUST_AUTHORING_CAPTURE_DIR and TRUST_AUTHORING_MANIFEST_SHA256; supplying only one refuses, and the pin must still equal the literal accepted manifest. Existing ordinaryPath rejects symlink ancestry/canonical-path mismatches for directory, manifest and gzip. The pinned manifest binds historical engine/source/seed/week and exact compressed/raw hashes and lengths. No alternate capture, dynamic discovery or generation fallback exists.

The loader first calls the genuine public validateSaveV45 reader on the parsed unknown input and checks canonical envelope equality and full tagged input neutrality. It requires the original week/seed and no prior rival submission history. Only then does real migrateToLive produce46; the loader checks migration input neutrality, actual version, public validateSaveV46, current writer/reader roundtrip, full envelope/state equality and neutrality of each actual reader input. The current state must still be week195 with no prior rival submissions. Its full-state serializer is copied exactly from the approved r4 writing helper (local name only); no JSON-only normalization is used for neutrality. It authors no fields, funds, cases, histories or commitments.

## Preservation and remaining gates

The original current-genesis220 missing-positive-actor result remains at S/1368-trust-witness-recorded-runs/probe-r1/RESULT.json, pin67450eaed8248d6a950667ee814bc9c192f57b8d863ce214477b6f452b56a94f, along with its unchanged original source/input and all-FRAGILE actor evidence. The entire r4 original test is preserved in preimages. The new named imported-current leaf qualifies that compatibility scenario only; it does not repair or relabel the old route, or close the documented unproven-person coverage gaps.

Parent next: independent static review; exact fixture adoption; patch composition against the pinned r4 preimage; fresh strict types and full affected-file execution with both override variables supplied when the scratch fixture link is not an ordinary path. Use the real repository fixture directory as the isolated override after adoption. The default path is for ordinary repository tests. Successful prior diagnostics establish this witness's provenance, not the runtime result of the new wiring. No broad, balance, promotion or checkpoint acceptance is claimed.
