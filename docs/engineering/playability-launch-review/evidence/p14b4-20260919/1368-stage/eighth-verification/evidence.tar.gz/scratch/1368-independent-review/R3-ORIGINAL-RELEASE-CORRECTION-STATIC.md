# Original R3 natural release leaf — independent static review

PROCEED with the exact test-only patch, then required types and original-file execution on the guarded candidate. Manifest `dada622ccd1e594b0997f6a88c2166a4670ed03b8b8b5ab0fa3c773ad3108230`; patch `30ef283b0a15217fa416e78582278be4d13ce5a451f9c17ac52b82ede2efb55d`; candidate test `8e584d2fefb3406e312e1295853153497839abb5cd73bb86ad9573dfd732941b`.

All package hashes verified. The original weekly role-count loop is byte-identical. The diff is confined to the final natural150 leaf/title/comments and necessary imports; prior siblings, generation seed, default ticks and deadlines are unchanged.

The obsolete zero-release inference is replaced with the accepted fixed-route six-row witness and substantive legality checks, not a universal six-count rule. Exact receipts, original contracts, order, ended rows, free agency and absence of unaccounted releases remain enforced. Entry91 and its real450,000 refund are distinguished from release92. Independent rounded salaries, capped charges, sequential cash/reserve/payback and complete release-week movement reconciliation match the accepted original-production observations. Zero unexpected terminations/debits is checked at every other owner/week. Original expected charge identities were checked against the independently accepted six-row attribution.

The test accurately claims returned-state proof; the accepted diagnostic separately establishes actual internal caller exclusions and per-call money bindings. The source before the boundary is not misrepresented as an independently observed internal staff state. It retains exact integer movement assertions and only bounded floating aggregate conservation tolerance.

No substantive defect found. The prospective writing guard may change this fixed natural route; final guarded execution remains mandatory and any mismatch must be attributed without blind repins. No broader balance, player byte identity, protected comparison, broad or promotion acceptance follows. No runtime/types, fixture payload access or source/index/Git mutation occurred in review.
