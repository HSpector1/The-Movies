# Trust imported-current original leaf wiring — independent static review

PROCEED with explicit fixture adoption and isolated composition, then required types and original-file final-source execution. Manifest `bddae3c5c8f6d149207c9d4fb9ce94bbd5494321bc75d54ebfbdb2a988e544ad`; patch `040c679fa562b6c8424614cebbbbe6588e8bc59320ed94c796a6eb95ed1c6bb4`; title mapping `ae47b921c2b13a812f52f5903ef0bfa5b3bc0516d0b7897425efaa95b7ab34b3`.

Package members verified; exact R4 preimage and candidate title identities match the mapping. Independently compared the entire three-witness callback and trailing assertions: byte-identical after removing only the added imported input argument. Shared original authoring checks and siblings remain unchanged. The other scanner caller retains current genesis; the imported scanner begins at195 and keeps the absolute220 bound, rather than adding220 more ticks.

The new helper binds the accepted immutable manifest, gzip/raw hashes and original45 provenance. Paired overrides cannot change the accepted manifest. Ordinary path checks precede reads; public45 admission precedes real migration/current46 admission. Actual passed reader objects and old/current state snapshots are checked for tagged neutrality, with a full current save/read roundtrip and original no-prior-rival-submissions checks before and after migration. No authority fields are stripped or forged.

The renamed title correctly identifies imported-current coverage. Mapping preserves the original failed raw identity/status/messages and raw NEW/GONE accounting; it links this exact pair as an input correction without claiming same-route equivalence or a new PASS before execution. The original current-genesis failure and open unproven branches stay explicit.

No substantive blocker found. Accepted diagnostic imported witnesses justify the new input, not silent replacement of current-genesis coverage or broad closure. Final integrated original-file measurement remains required. No runtime, fixture payload reading/copying, live source/index or Git mutation occurred in review.
