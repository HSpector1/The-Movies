# Six natural terminations — independent measured attribution

Accepted as an explanation of the original unswept ABC fallout, not guarded R4 behavior acceptance or authorization to replace an expectation with six.

Observed RESULT `c208acd1c24fde16b130b3bd58f6bf65efabddf3b1058fcb8fe7f204f0aa6440`; clean RESULT `fb748dc665d774961764873910301e0f5fbc1daa954d6aa340b1ab4f2324764e`; comparison `7ded8d6a89c6f0a85a8317931f0c6d0ca5a8927ed2addf905d7905e75e1375f9`. All observed receipt artifacts independently rehashed. Actual Node/recorder exits 0, no timeout, owned group absent/reaped and exact guards; observed duration 183.207603 seconds. Prior clean receipt was independently admitted.

Independently recomputed clean/observed equality for all comparator fields: source pins, seed, horizon, final digest, all 150 weekly whole-state/RNG records, 150 source-owned advance-return records and all six receipt bindings. Comparator input hashes match both completed data files. This is the fixed p13a-core-causal-01 default route through 150, with original production and only the reviewed diagnostic zero-delta oracle correction.

## Actual causal sequence

Rival studio-aca408ec-r04 enters cutting at input week91: actual decision ran, production/run counts zero, no greenlight/commission/active script work; commissionStop is unaffordablePackage. Actual entry predicate returns true while priorSince is null. Its real $450,000 laboratory refund occurs at week91; payroll $75,526, overhead $24,000 and facility opex $23,500 leave cash $5,208,796.95561068. This is earlier disposal income, not a fabricated week92 refund.

At input week92, since remains91. Employment ordinals18–23 terminate in ascending order, event IDs145–150, all six original terms ending208 (116 weeks remain). Each actual release predicate, one negative money call, ended employment row, receipt and outer free-agent membership joins by the same contract/person/studio/week. Actual production, writing, unreleased research and open-promise references are empty for every person. The ended rows retain their original entry reason; the employment end receipts correctly carry termination.

| Person suffix | Annual salary | Weekly salary | Actual charge | Cash after charge | Required reserve after |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0 | 734,049 | 14,116 | 367,016 | 4,841,780.955611 | 1,611,150 |
| 1 | 790,134 | 15,195 | 395,070 | 4,446,710.955611 | 1,360,725 |
| 2 | 379,009 | 7,289 | 189,514 | 4,257,196.955611 | 1,228,890 |
| 3 | 895,479 | 17,221 | 447,746 | 3,809,450.955611 | 948,075 |
| 4 | 395,223 | 7,600 | 197,600 | 3,611,850.955611 | 811,575 |
| 5 | 733,476 | 14,105 | 366,730 | 3,245,120.955611 | 577,500 |

Independently recomputed each charge as rounded annual/52 times min(116,26), saving as weekly salary plus1,500, reserve with the actual fresh operating cost and 15 reserve weeks, and payback inequality charge*operatingCost <= cash*saving. All six pass using sequentially reduced cash and active employment. Each period termination delta equals its exact debit; total termination is $1,963,676. Week92 payroll is zero after all six removals, overhead15,000 and facility opex23,500; closing cash $3,206,620.9556106804 and recorded conservation gap0. Week92 demolition refund is zero; the prior450,000 remains in its own week/period history.

## Original requirement implication

The original p14r3 role-target/control leaf assumes that never exceeding RIVAL_TEAM_ROLES means no surplus and therefore zero terminations. The original role-count checks still pass. Recovery deliberately changes the surplus premise while cutting: no slot retains otherwise unprotected employees, and shared charge, reserve and payback law still apply. The six observed rows are owned by that adopted behavior, not evidence that role-target construction or the shared termination charge is broken.

The narrow repair should preserve every original role-count assertion and preserve zero unexplained/non-cutting terminations, while checking any legitimate cutting release against real entry, protection, term, charge, reserve/payback, receipt and employment/accounting authority. Do not install a universal six-count law or weaken unrelated releases. Any concrete original-test adaptation requires its own reviewed patch and final-source execution. This diagnostic alone does not prove absence of other seed/horizon effects, final guarded R4 parity, save-reader acceptance not exercised by the diagnostic, balance quality or broad checkpoint closure. No original test was modified.
