# Ledger r2 source types — measured admission

Accepted for the two separate reviewed197-file arms. C0 RESULT `415c31566b7d60406277e97c5bad5842def6f1a5d90172e0df1428617bdf1c49`; ABC RESULT `000080d38989311d603a7c2464a6da3e57f6b2e73bae9b6a6dbd98aee1199f91`.

All listed artifacts independently rehashed. Both actual compiler/recorder exits0, timeout false and exact source/index guards verified. The old C0 and guarded ABC source identities remain separate; no result is borrowed across arms.

These types receipts authorize only their matching prepared diagnostic runs. The six fixed ledger routes, observed parity and causal missing-row attribution remain unmeasured here. No count or digest change is approved by types. Active first C0 output was not read. No runtime, fixture payload access or source/index/Git mutation occurred during review.
