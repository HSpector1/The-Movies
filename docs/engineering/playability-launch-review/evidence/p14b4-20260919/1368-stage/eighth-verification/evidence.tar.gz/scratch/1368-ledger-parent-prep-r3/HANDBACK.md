# Ledger r3: admit each exact boundary once

Prepared only. The r2 C0-clean p13a timeout remains intact: RESULT a775d1cfdbad0c2399abb51917f803f85adcab9e8856f6f8526ccb16d1a8bc4e, actual child -15 / recorder124 / timedOut true / exact guards. No completed payload or last-week observation exists. Duplicate admission is statically avoidable work, not a proved dominant timeout cause; this revision gives no runtime guarantee. No assembly, compiler, test, fixture read, live/index edit or existing-package mutation occurred.

## Exact correction

PROBE-R2-TO-R3.diff is the entire diagnostic change. admit retains the original public writer, expected version, detached real reader, canonical envelope equality and full tagged input neutrality. After proving the state unchanged it returns its original pre-admission snapshot and sha, instead of traversing the same state a third time.

The actual first runLedger callback admits genesis0 once. Each callback takes a fresh full tagged snapshot and requires both identity of the actual input object and exact tagged equality with the previous admitted boundary before reusing that boundary's digest. It then calls the same tick once, retains original post-tick input-neutrality/week checks, publicly admits the produced state, retains all receipt/history/owner/changed-case/output work, and saves the checked output as the next boundary. No memoization by week, object identity alone, JSON normalization or assumed immutability is used.

The fixed416 callbacks still publicly admit every boundary0..416:417 admissions rather than832. The original runLedger classifier and contemporaneous assertions are byte-identical. All expectedVersion, reader/state neutrality, full-state parity, phase-call counts, original pin comparisons and complete final data fields remain. No output schema, comparator, cardinality oracle, seed, action, horizon, production source or threshold changes. The two source arms'188 production files are each byte-identical to their r2 counterparts; ABC continues to include only the already approved writing guard. Original C0 is historical Save45.

## Exact rebound package

New exclusive arms: S/1368-ledger-arms-03/{C0,ABC}/tree. Each retains197 regular files and differs from its exact arm02 predecessor only in tests/1368-ledger-attribution.test.ts. Five kit test/config files remain, with only that probe changed. SOURCE-DIFFERENCE-PROOF.json, templates, preimages and the full assembler/runner diffs bind the change. The kit's source pins, original classifier, comparator, configs and original frozen test reference are byte-identical to r2.

The assembler verifies every original file, requires independent APFS clones, overlays the reviewed probe, preserves dependency symlink text and verifies original files again. No source hardlinks, fallback copy, Git initialization or old-output replacement. It writes the prebound source/assembly metadata only to the new exclusive arm.

The runner is the r2 recorder with package/arm/output/stem and exact hash bindings updated. Same types/clean/observed modes, exact command binding, actual published coordinator HEAD/remote admission, raw index/stage/source checks, matched fresh types prerequisite, Node20, 5 GiB floor, power/caffeinate, five formal artifacts,300-second leaf and330-second owned-group cap remain. Old r2 types receipts cannot satisfy changed source/kit pins. New results use S/1368-ledger-recorded-runs-r3 and formal stem1368-ledger-r3-. No automatic retry, mode chaining or deadline escalation exists.

Parent next, only after independent static review: assemble the new arms; run fresh C0 types; run the original C0-clean p13a416 route first. Hold the remaining original routes pending this measured result and parent disposition. If continued, ABC also needs its matched fresh types before clean/observed. Both fixed seeds and all six diagnostic processes remain the original experiment, not new research. The untouched comparator still requires complete current clean/observed parity, row-count conservation, exact phase coverage and source-bound causal facts, subordinate to recorder admission.

```sh
/usr/bin/python3 S/1368-ledger-parent-prep-r3/assemble.py --manifest-sha256 REVIEWED_PACKAGE_SHA
/usr/bin/python3 S/1368-ledger-parent-prep-r3/run.py types --arm C0 --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 REVIEWED_PACKAGE_SHA --leaf r1
/usr/bin/python3 S/1368-ledger-parent-prep-r3/run.py clean --arm C0 --seed p13a-core-causal-01 --head ACTUAL_PUBLISHED_HEAD --manifest-sha256 REVIEWED_PACKAGE_SHA --leaf r1 --types-receipt S/1368-ledger-recorded-runs-r3/C0-types-source-r1/RESULT.json --types-receipt-sha256 ACTUAL_TYPES_SHA
```

Expand S to /Users/zacheryspector/studio-scratch. Confirm the actual types output path printed by the runner; no command is executed automatically. Python AST and exact manifest/template/hash consistency checks only have run during authoring. No admission result, ledger explanation, pin movement or checkpoint closure is claimed.
