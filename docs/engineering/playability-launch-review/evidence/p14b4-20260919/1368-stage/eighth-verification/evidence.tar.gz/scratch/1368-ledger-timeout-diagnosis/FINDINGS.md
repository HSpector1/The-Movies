# Ledger timeout: bounded static diagnosis

The first C0-clean p13a run is an actual timeout, not an inherited failure or completed route. RESULT SHA a775d1cfdbad0c2399abb51917f803f85adcab9e8856f6f8526ccb16d1a8bc4e records child -15, recorder124, timedOut true and 331.28419768996537 seconds. Owned-group TERM cleanup reaped the leader and left no survivors; all source/receipt guards are exact. Every listed artifact was independently rehashed for this note. stdout contains only the 80-byte Vitest startup banner; stderr is empty. There is no data.json or completed vitest.json. The last completed game week, active instruction at timeout, CPU/memory attribution and achieved ledger cardinality are unknown.

The probe writes its entire result only in finally, after the synchronous route returns or throws (tests/1368-ledger-attribution.test.ts:552–558). An external termination cannot be interpreted as execution of that finally. Absence of a payload therefore does not locate the timeout before/after genesis, admission or a particular tick. The runner's existing 330-second child deadline and 300-second leaf limit are at run.py:118/131 and probe:561. Neither is changed by this proposal.

## Concrete avoidable work

The timed-out mode is clean: the phase/industry observer block at probe:490–522 never installs. Those optional observers cannot explain this particular run's cost. Full weekly snapshots, admission and change inventories still run in clean mode.

The weekly callback at probe:526–530 calls admit(input) and admit(answer) on every one of 416 ticks. This performs 832 full public writer/reader admission pairs, although there are only 417 distinct boundaries 0..416. Boundaries1..415 are admitted as outputs and again as the next inputs. The original runLedger helper at tests/1368-ledger-original.ts:140–179 performs one normal tick per step and read-only contemporaneous receipt/relationship assertions; it does not require a duplicate public admission of each identical state. Its exact assertion body can remain untouched.

Each admit (probe:467–473) also performs five tagged traversals: state before, detached reader before/after, state after, and a third state traversal solely to return a digest. The latter is redundant after the exact equality check. In addition, the callback independently tags input before and after tick. Counting only these direct whole-state/envelope operations, the old 416 callbacks perform 4,992 tagged traversals and 1,664 canonical envelope serializations, excluding phase observers and per-row histories. It also repeatedly clones the whole exported envelope. These are statically visible costs, not a measured proof of the timeout's dominant cause.

ChangedCases performs repeated prior-case searches and per-case serialization (447–451); employment comparisons and owners' full account copies also recur (434–444,534). Their histories are causally consumed by the comparator. No removal, lossy projection, unsafe identity cache or refactoring of those fields is recommended in the first correction. Source hashing happens only before/after the leaf. Final JSON output has not been proven reached.

## Smallest legitimate correction proposed

Author a new version of the diagnostic only, retaining all production, original runLedger/oracles, source pins, seeds, modes, 416 ticks, 300/330 limits and output/comparator meaning:

1. At the first actual callback input, admit boundary0 and retain its tagged snapshot plus digest. Do not generate another world or call tick separately.
2. At every callback entry, produce the same full tagged input snapshot and require exact equality with the retained last admitted output snapshot. Optionally require identical state object as well; byte equality is mandatory. This proves the original classifier did not alter the admitted boundary between callbacks. Never reuse a digest solely because week or object identity matches.
3. Tick once with the unchanged input and retain the original post-tick full tagged input-neutrality check and exact week increment.
4. Admit every produced boundary1..416 once, preserving the existing writer version assertion, detached actual-reader pre/post snapshots, canonical returned-envelope equality and state neutrality. Return the already verified before snapshot and its hash; replace only the redundant third snap(state) with sha(before).
5. Retain that output admission for the next callback; write exactly the same weekly inputDigest/digest and every existing inventory, receipt, owner, RNG and causal field. Retain the final state digest and every original ledger classifier assertion. Keep the full clean/observed output comparator and exact416 phase-count requirements.

This validates all 417 boundaries without skipping any input, output or historical assertion. It reduces public admission pairs from832 to417, canonical envelope serializations from1664 to834, and the stated direct tagged traversals from4992 to2500 (including the initial admission), with unchanged final serialization and per-row checks. These counts are code-path arithmetic, not timing predictions. No global snapshot memoization, JSON normalization, omitted admission, reduced parity, altered source policy or changed financial/history facts is allowed.

A tiny optional progress marker every52 completed boundaries could make a later failure locatable without dumping state, but it is not needed for the admission correction and should be independently reviewed if added. No broad profiler, route search, split horizon, extended deadline or automatic rerun is proposed.

## Readiness

This is a proposed instrumentation-efficiency fix, not a guaranteed runtime cure. Parent must authorize a new immutable kit, independently review its byte/coverage preservation and typecheck exact new arms before a bounded original-cap run. Keep this failed receipt and all artifacts unchanged. C0clean first remains the controlled next measurement; hold other ledger routes pending its result and parent disposition. A future success still requires the full existing current clean/observed parity and row-conservation/causal attribution checks before any original ledger expectation can be considered. The original frozen/T2 pins remain untouched.

No code, runtime, fixture access, source/index mutation or patch application occurred in this diagnosis.
