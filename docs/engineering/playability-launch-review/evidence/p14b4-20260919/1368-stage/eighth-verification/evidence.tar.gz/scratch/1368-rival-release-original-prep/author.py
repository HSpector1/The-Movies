from pathlib import Path
import difflib,hashlib,json
S=Path('/Users/zacheryspector/studio-scratch'); out=S/'1368-rival-release-original-prep'; rel='tests/p14r3-rival-release.test.ts'; src=S/'1368-save46-swept-proposal-r4/tree'/rel
old=src.read_text(); start=old.index("describe('P14 1305-C R3: no rival exceeds")
block=old[start:]
role=block[block.index('      for (const business'):block.index('    const rivalTerminationReceipts')]
# Keep the original weekly role-count loop byte-for-byte, including closing while brace.
new='''describe('P14 R3 and recovery: natural role targets and accounted cutting releases', () => {
  // 1363-A §4.2 changes surplus while cutting; no role-count excess is needed then.
  // Preserve the original seed, 150 default ticks and every weekly role-count check.
  // Six releases are this measured route's witness, not a universal policy count.
  // 1368's accepted six-termination attribution establishes the week-91 commission
  // cash refusal. This leaf checks the persisted entry and complete-tick effects;
  // it does not claim to observe private decide()/staff() intermediate returns.
  it('keeps role targets and accounts for every lawful cutting release across weeks 1..150', () => {
    type Business = NonNullable<GameState['hollywood']>['businesses'][number]
    type MoneyKind = keyof Business['account']['periods'][number]['movements']
    const total = (business: Business, kind: MoneyKind) =>
      business.account.periods.reduce((sum, period) => sum + period.movements[kind], 0)
    const rivalId = rowStudioId(BASE, 4)
    const expectedCharges = [367016, 395070, 189514, 447746, 197600, 366730]
    const expected = expectedCharges.map((charge, i) => ({
      talentId: `person-${rivalId}-${i}`,
      contractId: `${rivalId}:contract:person-${rivalId}-${i}:0`,
      week: 92, studioId: rivalId, fromStudioId: rivalId, toStudioId: null,
      kind: 'employment', reason: 'termination', eventId: `industry-event-${145 + i}`,
    }))
    let state = BASE
    while (state.market.tick < 150) {
      const before = state
      const week = before.market.tick
      state = tick(state)
      const newEnds = state.hollywood!.receipts.slice(before.hollywood!.receipts.length).filter(
        (r): r is Extract<typeof r, { kind: 'employment' }> =>
          r.kind === 'employment' && r.reason === 'termination' && r.studioId !== state.hollywood!.playerStudioId,
      )
      if (week === 91) {
        const prior = before.hollywood!.businesses.find(b => b.studioId === rivalId)!
        const entered = state.hollywood!.businesses.find(b => b.studioId === rivalId)!
        expect(prior.costCutting.since).toBeNull()
        expect(entered.costCutting.since).toBe(91)
        expect(entered.productions).toEqual([])
        expect(entered.runs).toEqual([])
        expect(entered.development.projects).toHaveLength(prior.development.projects.length)
        expect(entered.activeScriptOrdinals.map(i => entered.development.projects[i]!)
          .filter(p => p.status === 'drafting' || p.status === 'rewriting')).toEqual([])
        // The lawful earlier refund remains in history; it is not release-week income.
        expect(total(entered, 'facilityDemolitionRefund') - total(prior, 'facilityDemolitionRefund')).toBe(450000)
      }
      for (const prior of before.hollywood!.businesses) {
        const next = state.hollywood!.businesses.find(b => b.studioId === prior.studioId)!
        const ends = newEnds.filter(r => r.studioId === prior.studioId)
        let chargeSum = 0
        if (ends.length > 0) {
          expect(week).toBe(92)
          expect(prior.studioId).toBe(rivalId)
          expect(prior.costCutting.since).toBe(91)
          expect(next.costCutting.since).toBe(91)
          expect(ends).toEqual(expected)
          const own = before.hollywood!.activeEmploymentOrdinals
            .filter(i => before.hollywood!.employment[i]!.studioId === prior.studioId)
          expect(own).toEqual([18, 19, 20, 21, 22, 23])
          const busy = industryBusyTalentIds(before.hollywood)
          const capacityOpex = rivalCapacityOpex(prior, before.hollywood!.receipts)
          let remaining = [...own]
          let cash = prior.account.cash
          for (const [index, receipt] of ends.entries()) {
            const ordinal = own[index]!
            const row = before.hollywood!.employment[ordinal]!
            expect(row.contractId).toBe(receipt.contractId)
            expect(row.terms.talentId).toBe(receipt.talentId)
            expect(row.endedWeek).toBeNull()
            expect(row.terms.startWeek).toBe(0)
            expect(row.terms.endWeekExclusive).toBe(208)
            expect(busy.has(receipt.talentId)).toBe(false)
            expect(before.technology.projects.filter(p => p.studioId === prior.studioId)
              .flatMap(p => p.seats.filter(s => s.releasedWeek === null && s.talentId === receipt.talentId))).toEqual([])
            expect(before.promises.filter(p => p.issuerStudioId === prior.studioId &&
              p.beneficiaryPersonId === receipt.talentId && p.outcome === null)).toEqual([])
            const salary = Math.round(row.terms.annualSalary / TUNING.TICKS_PER_YEAR)
            const termLeft = row.terms.endWeekExclusive - week
            expect(termLeft).toBeGreaterThan(TUNING.HIRING_TERMINATION_CAP_WEEKS)
            const charge = salary * Math.min(termLeft, TUNING.HIRING_TERMINATION_CAP_WEEKS)
            expect(charge).toBe(expectedCharges[index])
            expect(terminationCost(row.terms, week)).toBe(charge)
            const operatingCost = remaining.reduce((sum, i) => sum + Math.round(
              before.hollywood!.employment[i]!.terms.annualSalary / TUNING.TICKS_PER_YEAR), 0) +
              TUNING.OVERHEAD_BASE + TUNING.OVERHEAD_PER_EMPLOYEE * remaining.length + capacityOpex
            const saving = salary + TUNING.OVERHEAD_PER_EMPLOYEE
            expect(cash - charge).toBeGreaterThanOrEqual((operatingCost - saving) * prior.policy.reserveWeeks)
            expect(charge * operatingCost).toBeLessThanOrEqual(cash * saving)
            cash -= charge
            chargeSum += charge
            remaining = remaining.filter(i => i !== ordinal)
            expect(state.hollywood!.employment[ordinal]).toEqual({ ...row, endedWeek: week })
            expect(state.hollywood!.activeEmploymentOrdinals).not.toContain(ordinal)
            expect(endReceiptsFor(state, row.contractId)).toEqual([receipt])
            expect(state.freeAgents).toContain(receipt.talentId)
            expect(studioEmployerId(state, receipt.talentId, week)).toBeNull()
          }
          expect(chargeSum).toBe(1963676)
          const kinds = Object.keys(prior.account.periods[0]!.movements) as MoneyKind[]
          let net = 0
          for (const kind of kinds) {
            const delta = total(next, kind) - total(prior, kind)
            const expectedDelta = kind === 'termination' ? -chargeSum :
              kind === 'overhead' ? -TUNING.OVERHEAD_BASE : kind === 'facilityOpex' ? -capacityOpex : 0
            expect(delta, `week ${week} ${kind}`).toBe(expectedDelta)
            net += delta
          }
          expect(capacityOpex).toBe(23500)
          expect(total(next, 'facilityDemolitionRefund')).toBe(total(prior, 'facilityDemolitionRefund'))
          // Only the sum of floating cash movements needs a rounding tolerance.
          expect(Math.abs(next.account.cash - prior.account.cash - net)).toBeLessThanOrEqual(0.00001)
          expect(next.account.periods.at(-1)!.closing).toBe(next.account.cash)
        }
        // A debit without a matching receipt, or an unexplained release at any
        // other rival/week, fails; no non-cutting receipts are filtered away.
        expect(total(next, 'termination') - total(prior, 'termination')).toBe(0 - chargeSum)
      }
'''+role+'''    const rivalTerminationReceipts = state.hollywood!.receipts.filter(
      (r) => r.kind === 'employment' && r.reason === 'termination' && r.studioId !== state.hollywood!.playerStudioId,
    )
    expect(rivalTerminationReceipts).toEqual(expected)
  })
})
'''
updated=old[:start]+new
updated=updated.replace("industryBusyTalentIds, rivalWeeklyOperatingCost, studioEmployerId", "industryBusyTalentIds, rivalCapacityOpex, rivalWeeklyOperatingCost, studioEmployerId")
updated=updated.replace("import type { GameState }", "import { TUNING } from '../src/core/tuning.js'\nimport type { GameState }")
# Remove unused callback name, not a semantic change.
updated=updated.replace('expectedCharges.map((charge, i)', 'expectedCharges.map((_, i)')
dest=out/'candidate'/rel; dest.parent.mkdir(parents=True); dest.write_text(updated)
patch=''.join(difflib.unified_diff(old.splitlines(True),updated.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(out/'original-leaf.patch').write_text(patch)
sha=lambda b:hashlib.sha256(b).hexdigest()
(out/'PREIMAGES.json').write_text(json.dumps({rel:{'path':str(src),'sha256':sha(src.read_bytes()),'bytes':src.stat().st_size}},indent=2)+'\n')
assert role in updated
print(sha(patch.encode()))
