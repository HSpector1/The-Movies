from pathlib import Path
import hashlib, json, tarfile
S=Path('/Users/zacheryspector/studio-scratch')
R=Path('/Users/zacheryspector/The-Movies-headless-program')
E=R/'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
I=S/'1368-eighth-publication-input-inventory/INPUTS.json'
O=E/'1368-stage/eighth-verification'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(I)=='46daf55953f7632fc9e81519f991a0b0cb6dac53508f540c0d78047cdf6dfe6d'
x=json.loads(I.read_text());assert not x['issues']
files=x['newFiles'].copy();refs=x['priorReferences']
run=S/'1368-ledger-recorded-runs-r3/C0-clean-p13a-r1'
assert sha(run/'RESULT.json')=='a211b840cf224756a0f777a74ca5c173f9551da55add50d266d5bbc242b5ea4f'
receipt=json.loads((run/'RESULT.json').read_text())
assert receipt['actualChildExit']==receipt['recorderChildExit']==0 and not receipt['timedOut'] and receipt['allGuardsExact']
assert receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped']
extra=set(q for q in run.rglob('*') if q.is_file())
for name,row in receipt['artifacts'].items():
 p=Path(name);assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'];extra.add(p)
known={row['original'] for row in files+refs}
for p in sorted(extra):
 if str(p) in known:continue
 name='scratch/'+p.relative_to(S).as_posix() if p.is_relative_to(S) else 'evidence/'+p.relative_to(E).as_posix()
 files.append({'path':name,'original':str(p),'size':p.stat().st_size,'sha256':sha(p),'category':'closed-ledger-r3-c0-clean-supplement'})
for p in [I,Path(__file__)]:
 files.append({'path':'scratch/'+p.relative_to(S).as_posix(),'original':str(p),'size':p.stat().st_size,'sha256':sha(p)})
assert len({r['path'] for r in files})==len(files)
for r in files+refs:
 p=Path(r['original']);assert p.is_file() and not any(q.is_symlink() for q in [p,*p.parents]);assert p.stat().st_size==r['size'] and sha(p)==r['sha256'],str(p)
for a in x['priorArchives']:
 archive=Path(a['archive']);assert sha(archive)==a['archiveSha256']
 assert sha(Path(a['manifest']))==a['manifestSha256']
 with tarfile.open(archive,'r:gz') as tar:
  for r in refs:
   if r['priorArchive']!=str(archive):continue
   m=tar.getmember(r['priorArchiveMember']);assert m.isfile() and m.size==r['size'];assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==r['sha256']
assert not O.exists();O.mkdir(parents=True);archive=O/'evidence.tar.gz';files.sort(key=lambda r:r['path'])
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for r in files:tar.add(r['original'],arcname=r['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files);assert [m.name for m in members]==[r['path'] for r in files]
 for m,r in zip(members,files):assert m.isfile() and m.size==r['size'] and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==r['sha256']
for r in files+refs:assert sha(Path(r['original']))==r['sha256']
result={'status':'ARCHIVE_VERIFIED','source_head':x['sincePublishedHead'],'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'file_count':len(files),'logical_bytes':sum(r['size'] for r in files),'files':files,'priorReferences':refs,'priorArchives':x['priorArchives'],'closedRuns':x['closedRuns']+[{'root':str(run),'resultSha256':sha(run/'RESULT.json'),'actualChildExit':0,'recorderChildExit':0,'timedOut':False,'allGuardsExact':True}],'inventoryExclusions':x['excluded'],'supplement':'The later completed r3 C0 clean result and all its artifacts are additionally preserved; no other r3 runtime output included.','inputInventorySha256':sha(I),'scope':'Guarded writing, lawful trust and termination evidence; ledger timeout retained. Recovery in progress; no main promotion.'}
(O/'MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','archive_sha256','archive_bytes','file_count','logical_bytes']}));print('priorReferences',len(refs))
