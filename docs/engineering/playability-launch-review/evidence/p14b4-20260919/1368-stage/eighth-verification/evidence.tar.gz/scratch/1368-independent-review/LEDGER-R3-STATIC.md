# Ledger r3 duplicate-admission correction — independent static review

PROCEED for new isolated arms, fresh C0 types and the one fixed C0-clean p13a416 attempt first; hold the remaining runs for parent disposition as proposed. Manifest `02ff99d3eff42bb8487764eec644df924e91f5e1f6e510b208f619f6f940e1f0`; probe delta `fa3cd08100f2e9f67883874a006f70a32cc37e4cc0a5ef909beb70ff125f4a1b`; new probe `6ae2acc5b5e22ebdfdee8eb73164c6de1d6b2b711cb210a40155cca869bee9bf`.

Verified every package hash and both197-file source maps: only the diagnostic probe changes from the respective old arm. All188 production files, original ledger classifier, configs and comparator remain fixed. Re-read the actual runLedger callback path and full probe/runner/assembly deltas.

Genesis is publicly admitted once, each produced boundary once. Before reusing a digest, a fresh tagged snapshot of the actual next input must equal the previously admitted snapshot and its object identity must match. Input equality is not inferred solely from identity or week. Existing tick input-neutrality, public output admission, expected era and reader/envelope checks remain. Thus all417 distinct boundaries0..416 are still admitted, without duplicate validation of an unchanged adjacent boundary. Original row extraction, assertions, phase evidence and output fields remain.

Assembly uses exclusive new APFS copies with exact original pre/post hashes and dependency-link preservation. Runner changes are package/arm/stem/pin rebindings; fresh matching types and the original300-second leaf/330-second outer cap remain. No seed/horizon fallback or automatic retry was added.

The earlier r2 timeout remains a failed diagnostic. Redundant admission is proven avoidable work, not proven dominant cause; this static approval predicts neither completion nor causal ledger results. No runtime, types, fixture payload access or live/source/index/Git mutation occurred in review.
