from pathlib import Path
import json,hashlib,difflib,ast
S=Path('/Users/zacheryspector/studio-scratch');P=S/'1368-r5-integration-prep';O=S/'1368-writing-guard-integration-prep';B=S/'1368-save46-swept-proposal-r4';D=S/'1368-save46-swept-proposal-r5';G=S/'1368-rival-release-original-prep';L=S/'1368-trust-import-landing-prep'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):
 with (P/n).open('w') as f:f.write(v if isinstance(v,str) else json.dumps(v,indent=2)+'\n')
def diff(a,b,x,y):return ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=x,tofile=y))
old=json.loads((B/'SOURCE-PINS.json').read_text());expected=dict(old);oldassembly=json.loads((B/'ASSEMBLY.json').read_text())
files={'tests/p14r3-rival-release.test.ts':G/'candidate/tests/p14r3-rival-release.test.ts','tests/p14b1-trust-chooser.test.ts':L/'files/tests/p14b1-trust-chooser.test.ts','tests/helpers/1368-trust-import.ts':L/'files/tests/helpers/1368-trust-import.ts'}
assert old['tests/p14r3-rival-release.test.ts']=='ba6ad04787330fe6bf7afd0ad4c84165cce406f2a5fbc7003bd749245062b7ad'
assert old['tests/p14b1-trust-chooser.test.ts']=='7b68095130b2e3d85b8a010f5b2829ca0fc73c805dcda7162ded4a3e0388d39b'
assert 'tests/helpers/1368-trust-import.ts' not in old
for n,p in files.items():
 if n in old:assert sha(B/'tree'/n)==old[n]
 expected[n]=sha(p)
assert len(old)==1625 and len(expected)==1626
write('EXPECTED-SOURCE-PINS.json',dict(sorted(expected.items())))
changed=sorted(n for n in old if old[n]!=expected[n]);added=sorted(set(expected)-set(old));prod={n:h for n,h in old.items() if n.startswith('src/')}
assert len(prod)==188 and all(expected[n]==h for n,h in prod.items())
write('SOURCE-DIFFERENCE-PROOF.json',{'baseHead':'956fc30e340a13461b701e70aa3d3aa34397b653','baseTree':'055f8e8a2cbe64530f15f906959efa6d5c810ddb','baseSourcePinsSha256':sha(B/'SOURCE-PINS.json'),'baseAssemblySha256':sha(B/'ASSEMBLY.json'),'newSourcePinsSha256':sha(P/'EXPECTED-SOURCE-PINS.json'),'baseFiles':1625,'newFiles':1626,'productionFiles':188,'productionDifference':{},'changedTests':{n:{'before':old[n],'after':expected[n]} for n in changed},'addedTests':{n:expected[n] for n in added},'other1623RegularFilesUnchanged':True,'dependencyLinksUnchanged':True,'proofBasis':'Exact reviewed candidate bytes and fixed r4 inventory; full consumed-tree verification is mandatory during parent assembly and before/after every run.'})
write('INTEGRATION.patch',(G/'original-leaf.patch').read_text()+(L/'trust-import-wiring.patch').read_text())
fixture=json.loads((L/'FIXTURE-ADOPTION.json').read_text());write('FIXTURE-ADOPTION.json',fixture)
target={'status':'PROPOSED_R5_NOT_ASSEMBLED_OR_EXECUTED','revision':5,'previousRoot':str(B),'previousHead':'956fc30e340a13461b701e70aa3d3aa34397b653','previousTree':'055f8e8a2cbe64530f15f906959efa6d5c810ddb','previousSourcePinsSha256':sha(B/'SOURCE-PINS.json'),'previousAssemblySha256':sha(B/'ASSEMBLY.json'),'sourcePinsSha256':sha(P/'EXPECTED-SOURCE-PINS.json'),'regularFiles':1626,'dependencyLinks':oldassembly['dependencyLinks'],'productionFiles':188,'changedProductionFiles':[],'changedTestFiles':changed,'newTestFiles':added,'releaseManifestSha256':sha(G/'MANIFEST.json'),'releasePatchSha256':sha(G/'original-leaf.patch'),'trustManifestSha256':sha(L/'MANIFEST.json'),'trustPatchSha256':sha(L/'trust-import-wiring.patch'),'fixtureAdoption':'Parent adopts exact two new trust files at safe publication; assembler never writes through existing p14 dependency link. All 29 external fixture pins must match before every run.','captureProducerIncluded':False}
write('EXPECTED-ASSEMBLY.json',target)
pre=[]
for root,names in [(B,['SOURCE-PINS.json','ASSEMBLY.json']),(O,['MANIFEST.json','assemble.py','run.py','SELECTIONS.json','FIXTURE-PINS.json','tsconfig.producers.json']),(G,['MANIFEST.json','original-leaf.patch','PREIMAGES.json']),(L,['MANIFEST.json','trust-import-wiring.patch','FILE-INVENTORY.json','FIXTURE-ADOPTION.json','ORACLE-PRESERVATION.json'])]:pre.extend(root/n for n in names)
pre.extend(files.values());pre.extend(B/'tree'/n for n in changed)
for name in ['R3-ORIGINAL-RELEASE-CORRECTION-STATIC.md','TRUST-IMPORTED-LEAF-WIRING-STATIC.md','TRUST-IMPORTED-CURRENT-WITNESSES-MEASURED.md','WRITING-GUARD-R4-INTEGRATION-STATIC.md']:pre.append(S/'1368-independent-review'/name)
for root in ['1368-rival-release-title-mapping','1368-trust-import-title-mapping']:pre.append(S/root/'TITLE-MAPPING.json')
write('PREIMAGES.json',{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in pre})
selection=json.loads((O/'SELECTIONS.json').read_text());selection['scope']+=' R5 preserves all six groups exactly and adds release/trust whole-file modes for the two approved original-leaf corrections. No behavioral filters or ledger repins.'
selection['changedFiles']=sorted(set(selection['changedFiles'])|set(files));selection['selections']['release']=['tests/p14r3-rival-release.test.ts'];selection['selections']['trust']=['tests/p14b1-trust-chooser.test.ts'];selection['importEdges'].append(['tests/p14b1-trust-chooser.test.ts','tests/helpers/1368-trust-import.ts'])
# Preserve original graph as historical selection metadata; list new helper's local imports explicitly.
import re
for spec in re.findall(r"from ['\"]([^'\"]+)['\"]",files['tests/helpers/1368-trust-import.ts'].read_text()):
 if spec.startswith('.'):
  import posixpath
  name=posixpath.normpath(posixpath.join('tests/helpers',spec));name=name[:-3]+'.ts' if name.endswith('.js') else name if name.endswith('.ts') else name+'.ts';assert name in expected;selection['importEdges'].append(['tests/helpers/1368-trust-import.ts',name])
write('SELECTIONS.json',selection)
write('SELECTION-DELTA.json',{'unchangedGroups':list(json.loads((O/'SELECTIONS.json').read_text())['selections']),'addedGroups':{k:selection['selections'][k] for k in ['release','trust']},'allPriorSelectionsByteEquivalentAsValues':True,'newHelper':'tests/helpers/1368-trust-import.ts','noTestNamePattern':True,'noLedgerExpectationChanges':True})
fixtures=json.loads((O/'FIXTURE-PINS.json').read_text());assert len(fixtures)==27
for name,row in fixture['files'].items():fixtures[fixture['destination']+'/'+name]=row['sha256']
write('FIXTURE-PINS.json',dict(sorted(fixtures.items())))
write('tsconfig.producers.json',(O/'tsconfig.producers.json').read_text().replace(str(B),str(D)))
# Exact previously reviewed assembler, with test-only r5 bindings and explicit base Git identity.
a=(O/'assemble.py').read_text();a=a.replace('APFS-clone exact r3 files, apply only the reviewed writing guard and landing tests; retain r3 intact.','APFS-clone exact r4 files, apply only approved release/trust tests; retain r4 and every production file intact.')
a=a.replace("P=S/'1368-writing-guard-integration-prep';B=S/'1368-save46-swept-proposal-r3';D=S/'1368-save46-swept-proposal-r4';G=S/'1368-rival-writing-guard-prep';L=S/'1368-rival-writing-landing-tests-prep'", "P=S/'1368-r5-integration-prep';B=S/'1368-save46-swept-proposal-r4';D=S/'1368-save46-swept-proposal-r5';G=S/'1368-rival-release-original-prep';L=S/'1368-trust-import-landing-prep'")
a=a.replace('727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca',sha(G/'MANIFEST.json')).replace('e886c1d8a68f139ecb3fbc635f17f4a890587d7137be29f8868025dca9a0c1c9',sha(L/'MANIFEST.json'))
a=a.replace('len(original)==1622 and len(expected)==1625','len(original)==1625 and len(expected)==1626')
a=a.replace("metadata=inventory(B/'tree',original,links)","assert subprocess.check_output(['/usr/bin/git','-C',str(B/'tree'),'rev-parse','HEAD'],text=True).strip()==target['previousHead']\nassert subprocess.check_output(['/usr/bin/git','-C',str(B/'tree'),'rev-parse','HEAD^{tree}'],text=True).strip()==target['previousTree']\nmetadata=inventory(B/'tree',original,links)")
a=a.replace("(G/'production.patch','guardPatchSha256'),(L/'landing-tests.patch','landingPatchSha256')","(G/'original-leaf.patch','releasePatchSha256'),(L/'trust-import-wiring.patch','trustPatchSha256')")
start=a.index("assert changed==['src/core/hollywoodTick.ts']");end=a.index("assert 'tests/1368-rival-writing-capture.test.ts'",start)
a=a[:start]+"assert sorted(changed)==target['changedTestFiles'] and len(changed)==2\nassert sum(n.startswith('src/') for n in original)==188\nassert all(expected[n]==h for n,h in original.items() if n.startswith('src/'))\nassert set(expected)-set(original)==set(target['newTestFiles']) and len(target['newTestFiles'])==1\n"+a[end:]
a=a.replace("'changedProductionFiles':changed,'other187ProductionFilesUnchanged':True,'allOtherR3FilesUnchanged':True", "'changedProductionFiles':[],'all188ProductionFilesUnchanged':True,'changedTestFiles':sorted(changed),'other1623R4FilesUnchanged':True")
a=a.replace("'regularFiles':1625", "'regularFiles':1626")
write('assemble.py',a);ast.parse(a);write('ASSEMBLER-DELTA.diff',diff((O/'assemble.py').read_text(),a,'r4/assemble.py','r5/assemble.py'))
# Runner: retain original recorder/environment/commands; add two whole-file modes and require fresh r5 six-command types.
v=(O/'run.py').read_text().replace("p=s/'1368-save46-swept-proposal-r4'","p=s/'1368-save46-swept-proposal-r5'").replace("prep=s/'1368-writing-guard-integration-prep'","prep=s/'1368-r5-integration-prep'").replace("'ui','writing']","'ui','writing','release','trust']").replace("parser.add_argument('--child');", "parser.add_argument('--child');parser.add_argument('--types-run-id');")
v=v.replace("stem='1368-swept-r4-'", "stem='1368-swept-r5-'")
v=v.replace("assert re.fullmatch(r'[0-9a-f]{40}',a.head);", "assert (a.mode=='types' and a.types_run_id is None) or (a.mode!='types' and a.types_run_id is not None and re.fullmatch(r'[a-z0-9][a-z0-9-]{0,39}',a.types_run_id))\nassert re.fullmatch(r'[0-9a-f]{40}',a.head);")
for n in ['SELECTIONS.json','tsconfig.producers.json','FIXTURE-PINS.json']:v=v.replace(sha(O/n),sha(P/n))
v=v.replace(sha(B/'SOURCE-PINS.json'),sha(P/'EXPECTED-SOURCE-PINS.json')).replace(sha(B/'ASSEMBLY.json'),sha(P/'EXPECTED-ASSEMBLY.json'))
v=v.replace("RIVAL_WRITING_MANIFEST_SHA256='d097bbf131c1dc495b881d73e96994953b2f6a0ef50f88bd3b043f263024f205')", "RIVAL_WRITING_MANIFEST_SHA256='d097bbf131c1dc495b881d73e96994953b2f6a0ef50f88bd3b043f263024f205',TRUST_AUTHORING_CAPTURE_DIR=str(r/'tests/fixtures/p14/genuine-v45-trust-authoring-week195-1368'),TRUST_AUTHORING_MANIFEST_SHA256='0b98763001eb96949d8e312df5dfe600f1adf599f5466dd59eec214e1f229991')")
# Pin actual types result, all six raw outputs and original five recorder files; identical runner/source/HEAD required.
gate='''def type_prerequisite(pins):
 if a.mode=='types':return None
 q=prep/('run-types-'+a.types_run_id);b=q/'binding.json';result=q/'RESULT.json';data=json.loads(result.read_text());binding=json.loads(b.read_text())
 assert data['mode']=='types' and data['baseHead']==base and data['sourceFiles']==len(source) and data['allGuardsExact'] is True
 assert data['bindingSha256']==sha(b.read_bytes()) and binding['baseHead']==base and binding['pins']==pins
 expected=[('root',['node','node_modules/typescript/bin/tsc','--noEmit']),('ui',['node','node_modules/typescript/bin/tsc','-p','ui/tsconfig.json','--noEmit']),('bridge',['node','node_modules/typescript/bin/tsc','-p','tsconfig.bridge.json']),('contract',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract.ts','--check']),('contract-fixtures',['node','node_modules/vite-node/vite-node.mjs','scripts/generate-bridge-contract-fixtures.ts','--check']),('producers',['node','node_modules/typescript/bin/tsc','--noEmit','-p',str(prep/'tsconfig.producers.json')])]
 assert [(x['name'],x['command']) for x in data['results']]==expected
 paths=[b,result]
 for row in data['results']:
  raw=q/(row['name']+'.txt');assert row['actualChildExit']==0 and sha(raw.read_bytes())==row['rawSha256'];paths.append(raw)
 name='1368-swept-r5-types-'+a.types_run_id;record=json.loads((e/(name+'.json')).read_text());post=json.loads((e/(name+'-postflight.json')).read_text())
 assert record['command']==[sys.executable,str(Path(__file__).resolve()),'types','--head',base,'--run-id',a.types_run_id,'--child',sha(b.read_bytes())]
 assert record['fixedSource'] is True and record['exitCode']==0 and post['fixedSource'] is True and post['allGuardsExact'] is True and post['exitCode']==0
 paths.extend(e/(name+suffix) for suffix in ['.json','.patch','.txt','-preflight.json','-postflight.json'])
 return {str(x):sha(x.read_bytes()) for x in paths}
'''
v=v.replace('if a.child:\n',gate+'if a.child:\n')
v=v.replace("assert verify()==bound['pins']\n commands=[]", "assert verify()==bound['pins'];assert type_prerequisite(bound['pins'])==bound['typesPrerequisite']\n commands=[]")
v=v.replace("assert verify()==bound['pins'];assert sha(binding.read_bytes())==a.child", "assert verify()==bound['pins'];assert type_prerequisite(bound['pins'])==bound['typesPrerequisite'];assert sha(binding.read_bytes())==a.child")
v=v.replace("exclusive(out);out.mkdir();pins=verify();assert", "pins=verify();typesPrerequisite=type_prerequisite(pins);exclusive(out);out.mkdir();assert")
v=v.replace("'baseHead':base,'pins':pins,'sourceFiles'", "'baseHead':base,'pins':pins,'typesPrerequisite':typesPrerequisite,'sourceFiles'")
v=v.replace("approved swept originals plus writing guard regression tests; not broad acceptance", "approved swept originals plus release/trust input corrections; all production unchanged from r4; not broad acceptance")
v=v.replace("k.startswith('RIVAL_WRITING_') or k=='PATH'", "k.startswith('RIVAL_WRITING_') or k.startswith('TRUST_AUTHORING_') or k=='PATH'")
v=v.replace("'--child',sha((out/'binding.json').read_bytes())],cwd=r", "'--child',sha((out/'binding.json').read_bytes()),*(['--types-run-id',a.types_run_id] if a.types_run_id else [])],cwd=r")
v=v.replace("assert verify()==pins\nprint", "assert verify()==pins;assert type_prerequisite(pins)==typesPrerequisite\nprint")
write('run.py',v);ast.parse(v);write('RUNNER-REBIND.diff',diff((O/'run.py').read_text(),v,'r4/run.py','r5/run.py'))
print(json.dumps({'source':sha(P/'EXPECTED-SOURCE-PINS.json'),'assembly':sha(P/'EXPECTED-ASSEMBLY.json'),'runner':sha(P/'run.py'),'assembler':sha(P/'assemble.py'),'files':len(expected)}))
