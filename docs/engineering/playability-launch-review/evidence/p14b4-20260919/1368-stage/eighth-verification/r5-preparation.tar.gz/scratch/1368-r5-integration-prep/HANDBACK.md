# R5 test-only integration proposal

Ready for independent static review and parent-controlled assembly. No assembly, Git initialization, compiler, test, game route, fixture adoption or live write was performed. The parent remains the only executor. This package preserves r4, all prior failures and the original title mappings.

## Exact scope and source

Base: `/Users/zacheryspector/studio-scratch/1368-save46-swept-proposal-r4/tree`, scratch HEAD `956fc30e340a13461b701e70aa3d3aa34397b653`, tree `055f8e8a2cbe64530f15f906959efa6d5c810ddb`, source inventory `ca96ecb42e78ddf4442e17804bd15a80d70e5808a5e78ed42f43b4f06a0320d2`, assembly `604e0a722f5248ef7003ba5dc9216462564d6dad29ba86519612198fb53b94f5`.

Proposed exclusive destination: `/Users/zacheryspector/studio-scratch/1368-save46-swept-proposal-r5/tree`. Its expected inventory is `9af6eb3fad4efd27cf2a231d70dca0f3239ae05e97e1ce0d2db0ca1cf1054704`; assembly is `a9ad5137718a81158f986f4bd50a63a84fbc24c8cd0f05e52d584f6b98a037ca`.

Apply only, in this order:

1. `1368-rival-release-original-prep/original-leaf.patch`, SHA-256 `30ef283b0a15217fa416e78582278be4d13ce5a451f9c17ac52b82ede2efb55d`.
2. `1368-trust-import-landing-prep/trust-import-wiring.patch`, SHA-256 `040c679fa562b6c8424614cebbbbe6588e8bc59320ed94c796a6eb95ed1c6bb4`.

The regular inventory grows from 1,625 to 1,626: two existing test files change and `tests/helpers/1368-trust-import.ts` is added. All 188 production files, every other 1,623 original regular file and all dependency symlink texts are unchanged. The writing guard already in r4 is retained exactly. No ledger expectation, digest, other behavior, timeout, source law or capture producer changes. `SOURCE-DIFFERENCE-PROOF.json` and `PATCH-RECONSTRUCTION.json` bind all three deltas; the latter reconstructs each unified patch in memory against its exact r4 preimage. The assembler will repeat full actual file/metadata and original-postflight checks; this preparation does not claim those future checks have run.

## Review and fixture prerequisites

Both corrections have independent static approval. The assembler's exact `PREIMAGES.json` includes:

- `R3-ORIGINAL-RELEASE-CORRECTION-STATIC.md`, SHA-256 `19c0a36f91a58f7769305f269d0b55c7851e1699098c6e05642307e05ad13340`.
- `TRUST-IMPORTED-LEAF-WIRING-STATIC.md`, SHA-256 `3a51b86ef888112596e651c3063c3c53acc79552ff85a175aa1474be9e2bec5f`.
- The accepted imported trust witness review and both old-to-new title mappings. NEW/GONE observations must retain raw identities; the mapping explains the correction rather than rewriting prior evidence.

At a safe publication checkpoint, parent must adopt exactly the two accepted source files listed in `FIXTURE-ADOPTION.json` from `1368-trust-import-runs-r2/C0-capture-p13a-r1/data` into the real repository directory `tests/fixtures/p14/genuine-v45-trust-authoring-week195-1368`:

- `MANIFEST.json`: 41,502 bytes, SHA-256 `0b98763001eb96949d8e312df5dfe600f1adf599f5466dd59eec214e1f229991`.
- `week195.save45.json.gz`: 135,408 bytes, SHA-256 `f23c298aeea06724b983564f192cbcc0d100aa5f9e27744a82e1fac495d47899`.

The candidate's inherited p14 fixture link points at the real repository. The assembler neither copies fixture payloads nor writes through that link. The runner adds these exact two files to the existing 27 fixture pins and supplies the reviewed paired trust directory/manifest override. The helper performs genuine public Save45 admission before the real current migration; all original three witness assertions, order and absolute week-220 bound remain intact. Capture production remains evidence-only. No newly fabricated fixture is included.

## Parent execution sequence after this package's independent approval

1. Adopt the exact trust fixture at safe publication. Preserve the accepted capture bytes and record the resulting actual published HEAD. Verify the required free-space floor before the next heavy job.
2. Execute `python3 /Users/zacheryspector/studio-scratch/1368-r5-integration-prep/assemble.py --manifest-sha256 <exact independently reviewed MANIFEST hash>`. Destination must not exist. The assembler checks all package/review/preimage hashes, exact r4 HEAD/tree and inventory; APFS clones each regular file with preserved mode/length; recreates only existing symlink texts; applies the two exact patches without an index; and verifies original and destination inventories. It does not initialize Git.
3. Parent initializes the exclusive scratch Git snapshot using the existing integration procedure. No source changes are permitted. Run `python3 /Users/zacheryspector/studio-scratch/1368-r5-integration-prep/run.py types --head <actual published 40-character HEAD> --run-id r1` using the same Python executable for subsequent modes.
4. Independently inspect fresh root, UI, Bridge, contract generator, contract-fixture generator and producer checks. All six existing commands remain in their original order. Then run whole-file `release` and `trust` modes separately with `--types-run-id r1 --head <same HEAD> --run-id r1`. These modes select exactly `tests/p14r3-rival-release.test.ts` and `tests/p14b1-trust-chooser.test.ts`; they do not use a test-name filter.
5. After those results are reviewed, parent selects the remaining unchanged `backward`, `p15`, `current`, `helper-consumers`, `ui` and, if needed, `writing` groups with the same source/HEAD/types binding. The existing group memberships remain 16, 4, 104, 37, 7 and 2 files respectively. This is not a broad/all invocation.

The narrow added types gate requires six zero exits, each raw output hash, the exact commands, matching runner/source/scratch-index/HEAD/config/fixture pins, the actual recorded child command and completed source postflight. It retains hashes of all types receipts through each later run. It refuses r4 types and stale or mismatched r5 types. Ordering release/trust before the remaining groups is a parent scheduling requirement, not a new execution framework.

## Preserved recording law and limitations

`ASSEMBLER-DELTA.diff` and `RUNNER-REBIND.diff` show the complete changes from the reviewed r4 integration kit. The runner preserves Node 20.20.2, all original Vitest budgets and configurations, exact whole-file report checks, five formal recorder artifacts, actual exit propagation, source/HEAD/index/fixture checks before and after, exclusive outputs, 5 GiB free-space floor, power logging and caffeinate. It adds only r5 bindings, trust paired environment inputs, separate whole-file modes and the fresh-types prerequisite. No environment cleanup or deadline increase is introduced.

This inherited full-file runner uses synchronous subprocess execution and has no independent outer process deadline or owned-process-group watchdog. Its test deadlines are the existing test/configuration deadlines; do not describe it as the separate 300/330 diagnostic runner. The parent retains the single-heavy-lane discipline. No duration, GREEN, whole-file acceptance or new checkpoint acceptance is claimed here. The old current-genesis trust failure, old zero-termination assertion failure, and unresolved ledger measurements remain preserved separately.
