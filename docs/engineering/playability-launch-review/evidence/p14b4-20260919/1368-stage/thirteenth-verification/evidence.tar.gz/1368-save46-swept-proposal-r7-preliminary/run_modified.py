import hashlib,json,os,subprocess,sys
from pathlib import Path
out=Path(__file__).resolve().parent;t=out/'tree';r=Path('/Users/zacheryspector/The-Movies-headless-program')
source=json.loads((out/'SOURCE-PINS.json').read_text());assembly=json.loads((out/'ASSEMBLY.json').read_text());selected=assembly['changed']
def verify():
 for name,pin in source.items():assert hashlib.sha256((t/name).read_bytes()).hexdigest()==pin,name
 assert len(selected)==9 and all(name.startswith('tests/') and name.endswith('.test.ts') for name in selected)
verify()
node=Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin');env=dict(os.environ,PATH=str(node)+':'+os.environ['PATH'],P1368_ACCEPTED45_ROOT=str(r/'tests/fixtures/p14/genuine-v45-recovery-witnesses-1368'),P1368_ACCEPTED45_MANIFEST_SHA256='11ad61be481a8bec170f40425cfcfe7fcb24596418d30b6c8bf27895e93c3ba5',P1368_ACCEPTED26_ROOT=str(r/'tests/fixtures/p13b/genuine-v26-period52-1368'),P1368_ACCEPTED26_MANIFEST_SHA256='8e40e51bb360ba6ff6c0d641a03e90aa8ed6f73f8c0b232a9a4b5861af358db4',RIVAL_WRITING_CAPTURE_DIR=str(r/'tests/fixtures/p14/genuine-v46-rival-writing-pre414-1368'),RIVAL_WRITING_MANIFEST_SHA256='d097bbf131c1dc495b881d73e96994953b2f6a0ef50f88bd3b043f263024f205',TRUST_AUTHORING_CAPTURE_DIR=str(r/'tests/fixtures/p14/genuine-v45-trust-authoring-week195-1368'),TRUST_AUTHORING_MANIFEST_SHA256='0b98763001eb96949d8e312df5dfe600f1adf599f5466dd59eec214e1f229991')
cmd=['node','node_modules/vitest/vitest.mjs','run','--project','core',*selected,'--reporter=verbose','--reporter=json','--outputFile.json='+str(out/'modified-r1.json')]
assert not (out/'modified-r1.json').exists()
print(json.dumps({'selected':selected,'sourceFiles':len(source),'command':cmd}),flush=True)
result=subprocess.run(cmd,cwd=t,env=env)
verify();print(json.dumps({'childExit':result.returncode,'sourceExact':True}),flush=True);sys.exit(result.returncode)
