# C0 historical preimage replay proposal r7

**Status: candidate for independent static review; no r7 types or replay has run.** R7 adds only the genuine `tests/contracts/_contractFixtures.ts` to each copied arm. The fixture matches Git `8708d6a9` and the current repository at SHA-256 `7554a6b11f0756c7cd286a7732ab888757a129fe0d9f10657c93c4d214f10de2`. The r6 historical types failure is preserved as a separate receipt. R5's independent REFINE review reproduced execution of an unlisted `argparse.py` before package inventory verification. R7 requires isolated Python startup (`-I -B`) for the external parent and the recorder-spawned child. The runner checks `sys.flags.isolated` before importing any other module. In isolated mode the package directory is absent from `sys.path`; a stdlib-only gate verifies the externally pinned manifest and exact recursive inventory before the runner inserts that directory and imports `guard_logic.py` or `self_check.py`. The child command, formal command checks, and fixture receipt expectations now include exact `-I -B`. A modified listed helper or an unlisted stdlib shadow fails before its top-level code can run. `--bootstrap-check` exercises the gate without starting types or replay.

After an independent r7 ACCEPT receipt is issued at the fixed path, the trusted parent must run the literal external command below. Fill the SHA placeholders from the frozen r7 manifest and runner and the independently issued r7 review receipt. Do not compute those authority pins from current package bytes at launch time. The future r7 review SHA cannot be embedded in this package without a review hash cycle. The external command authenticates manifest, runner, and receipt before loading runner code; it leaves the package directory off `sys.path`. The runner then authenticates the **full package** before adding that directory. Caller-created environment values alone do not establish independent authority.

```bash
python3 -I -B -c 'import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1369-c0-preimage-replay-proposal-r7")
runner=root/"runner.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1369-c0-preimage-proposal-independent-review-r7/RECEIPT.json")
manifest_sha="<FROZEN_R7_MANIFEST_SHA>"
runner_sha="<FROZEN_R7_RUNNER_SHA>"
review_sha="<INDEPENDENTLY_ISSUED_R7_REVIEW_SHA>"
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path
assert sha(manifest.read_bytes())==manifest_sha
code=runner.read_bytes()
assert sha(code)==runner_sha
assert sha(review.read_bytes())==review_sha
assert json.loads(review.read_text())=={"decision":"ACCEPT","package":"1369-C0-PREIMAGE-REPLAY-R7","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_sha,"runnerSha256":runner_sha}
os.environ["C0_R7_EXTERNAL_MANIFEST_SHA256"]=manifest_sha
os.environ["C0_R7_EXTERNAL_REVIEW_SHA256"]=review_sha
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(code,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner)})' types --arm historical --head <EXACT_ORIGIN_HEAD> --manifest-sha256 <FROZEN_R7_MANIFEST_SHA> --self-runner-sha256 <FROZEN_R7_RUNNER_SHA> --leaf <UNIQUE_LEAF> --static-review-receipt /Users/zacheryspector/studio-scratch/1369-c0-preimage-proposal-independent-review-r7/RECEIPT.json --static-review-sha256 <INDEPENDENTLY_ISSUED_R7_REVIEW_SHA>
```

After historical full types passes, use the same invocation with `clean --arm historical` and `--types-receipt <accepted-types-RESULT.json> --types-receipt-sha256 <SHA>`. Historical clean must reproduce all four **original 654-T** digests, original RNG, 417 weekly rows, and four full preimages before modern types is eligible. Modern types and clean require `--historical-receipt <accepted-historical-clean-RESULT.json> --historical-receipt-sha256 <SHA>`; modern clean also needs accepted same-arm full types. Every mode uses a fresh unique leaf. A timeout fails exploratory evidence and does not permit repinning.

R7 retains byte-identical r5/r4 historical and modern production arms and diagnostic, seed `p13a-core-causal-01`, 416 direct ticks, original protected digest expressions, 600-second Vitest/630-second recorder exploratory caps, and the separate 300-second types cap. Historical raw employment `09bcc35ba327579ac63dd1ed63535b23cbc8ff55b25fd9597a2872a819f08750`, current approved employment `4cffcb410893395f8ee93da2d7d6146f35db2369962fe333e02de8d2fc7c0b58`, and modern recorded actual `7e64d2fbfd525edf40daa4fb952fe08ac68d4a877b4d212afd7adcfdca25237d` remain distinct. R4 and R5 REFINE reviews are included as evidence, not admission. R3's exact static ACCEPT receipt remains pinned, while r7 requires its own external ACCEPT.

The runner retains exact remote/local HEAD and source guards, AC and at least 3 GiB free disk, a 256 MiB output limit, formal five-file pre/postflight, separate child and recorder exits, and TERM/KILL/reap/no-survivor checks. `compare.py` reports descriptive first-field differences only after explicit SHA-pinned accepted clean results from unique leaves. This route is `EXPLORATORY_NOT_ACCEPTANCE`; it changes no production behavior or protected pin.
