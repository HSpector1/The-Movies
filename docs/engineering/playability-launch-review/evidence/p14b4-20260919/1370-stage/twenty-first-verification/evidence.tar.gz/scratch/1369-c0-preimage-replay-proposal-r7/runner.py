#!/usr/bin/env python3
"""Formal 416-week exploratory preimage runner; types then clean, historical first."""
import sys
assert sys.flags.isolated, 'Python -I isolated startup required'
import argparse, hashlib, importlib.util, json, os, re, shutil, signal, subprocess, threading, time
from pathlib import Path
sys.dont_write_bytecode = True

# Stdlib-only trust gate. A future independent r7 receipt pins MANIFEST externally.
# This executes before any package helper import in parent and recorder child.
def _authenticate_package_before_import():
    import hashlib as _hashlib, json as _json, os as _os, re as _re, stat as _stat
    from pathlib import Path as _Path
    _root = _Path(__file__).absolute().parent
    assert str(_root) not in sys.path, 'package path present before authentication'
    _manifest = _root / 'MANIFEST.json'
    _pin = _os.environ.get('C0_R7_EXTERNAL_MANIFEST_SHA256', '')
    assert _re.fullmatch(r'[0-9a-f]{64}', _pin), 'missing externally pinned manifest'
    for _path in (_root, _manifest, _Path(__file__).absolute()):
        assert not _path.is_symlink(), 'symlink package path'
    _bytes = _manifest.read_bytes()
    assert _hashlib.sha256(_bytes).hexdigest() == _pin, 'external manifest pin mismatch'
    _m = _json.loads(_bytes)
    assert _m['package'] == '1369-C0-PREIMAGE-REPLAY-R7'
    assert _m['classification'] == 'EXPLORATORY_NOT_ACCEPTANCE'
    assert _m['status'] == 'EXECUTABLE_ONLY_AFTER_INDEPENDENT_R7_REVIEW'
    _found = {}
    def _walk(_folder):
        for _entry in _os.scandir(_folder):
            _path = _Path(_entry.path)
            _relative = _path.relative_to(_root).as_posix()
            _info = _entry.stat(follow_symlinks=False)
            if _stat.S_ISDIR(_info.st_mode):
                _found[_relative] = {'kind': 'directory'}
                _walk(_path)
            elif _stat.S_ISLNK(_info.st_mode):
                _found[_relative] = {'kind': 'symlink', 'target': _os.readlink(_path)}
            elif _stat.S_ISREG(_info.st_mode):
                assert _info.st_nlink == 1, 'hardlinked package object'
                _found[_relative] = ({'kind':'manifest'} if _relative == 'MANIFEST.json' else
                    {'kind':'file','sha256':_hashlib.sha256(_path.read_bytes()).hexdigest()})
            else:
                raise AssertionError('unexpected package object: ' + _relative)
    _walk(_root)
    assert _found == _m['objectInventory'], 'exact package inventory mismatch'
    _self = _Path(__file__).absolute()
    assert _self == _root / 'runner.py'
    assert _hashlib.sha256(_self.read_bytes()).hexdigest() == _m['runnerSha256']
    return _pin
_AUTHENTICATED_MANIFEST_SHA256 = _authenticate_package_before_import()
if len(sys.argv) == 2 and sys.argv[1] == '--bootstrap-check':
    print('BOOTSTRAP_PASS:' + _AUTHENTICATED_MANIFEST_SHA256)
    sys.exit(0)

sys.path.insert(0, str(Path(__file__).absolute().parent))
import guard_logic, self_check

ROOT = Path(__file__).resolve().parent
RUNS = Path('/Users/zacheryspector/studio-scratch/1369-c0-preimage-recorded-runs-r7')
REPO = Path('/Users/zacheryspector/The-Movies-headless-program')
EVIDENCE = REPO / 'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
SELF = ROOT / 'runner.py'
NODE = Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
GUARD = EVIDENCE / 'run-bounded-source-guards.py'
RECORDER = EVIDENCE / 'run-bounded-source-c2.mjs'
CLEANUP = Path('/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/cleanup.py')
BRANCH = 'refs/heads/wip/headless-program-20260916-ts'
PACKAGE = '1369-C0-PREIMAGE-REPLAY-R7'
R3_REVIEW = Path('/Users/zacheryspector/studio-scratch/1369-c0-preimage-proposal-independent-review-r3/REVIEW.md')
R3_REVIEW_SHA256 = '7f5614f6c858429d469ff58a721d3bf486f9c592c27e95957bd455873f780d3a'
R3_RECEIPT = Path('/Users/zacheryspector/studio-scratch/1369-c0-preimage-proposal-independent-review-r3/RECEIPT.json')
R3_RECEIPT_SHA256 = '5b2763621019c36fedd36687ee30d44d1dd823c3c1f17c8ecf6319e6316b9acd'
R7_REVIEW = Path('/Users/zacheryspector/studio-scratch/1369-c0-preimage-proposal-independent-review-r7/RECEIPT.json')
EXTERNAL_REVIEW_ENV = 'C0_R7_EXTERNAL_REVIEW_SHA256'
SCOPE = ['src','bridge','tests','ui','generated','scripts','package.json','package-lock.json',
         'vitest.config.ts','vitest.workspace.ts','tsconfig.json','tsconfig.bridge.json','tsconfig.src.json',
         ':(exclude)tests/fixtures',':(exclude)ui/e2e',':(exclude)ui/public']

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value): return hashlib.sha256(value).hexdigest()
def environment(): return dict(os.environ, PATH=str(NODE.parent)+':'+os.environ.get('PATH',''), GIT_OPTIONAL_LOCKS='0')
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO,env=environment())
def safe(path):
    path=Path(path); assert path.is_absolute() and str(path)==os.path.abspath(path)
    for part in [path,*path.parents]: assert not part.is_symlink(),str(part)
def exclusive(path): safe(path); assert not os.path.lexists(path),'existing output: '+str(path)
def write(path,obj):
    with Path(path).open('x') as f: json.dump(obj,f,indent=2,sort_keys=True); f.write('\n')
def manifest(): return json.loads((ROOT/'MANIFEST.json').read_text())
def ac_power():
    output=subprocess.check_output(['pmset','-g','batt'],text=True)
    assert "Now drawing from 'AC Power'" in output,'AC power required'
    return output
def command_for(mode,arm,out):
    assert arm in ('historical','modern')
    if mode=='types': return [str(NODE),'node_modules/typescript/bin/tsc','--noEmit','-p','tsconfig.json']
    assert mode=='clean'
    return [str(NODE),'node_modules/vitest/vitest.mjs','run','--config','vitest.preimage.config.ts',
            '--maxWorkers','1','--minWorkers','1','--no-file-parallelism','--reporter=verbose',
            '--reporter=json','--outputFile.json='+str(out/'vitest.json')]

def verify(head,manifest_pin,runner_pin,arm):
    assert arm in ('historical','modern') and re.fullmatch('[0-9a-f]{40}',head)
    assert re.fullmatch('[0-9a-f]{64}',manifest_pin) and re.fullmatch('[0-9a-f]{64}',runner_pin)
    assert manifest_pin==_AUTHENTICATED_MANIFEST_SHA256
    safe(ROOT); safe(SELF); safe(ROOT/'MANIFEST.json')
    assert Path(__file__).resolve()==SELF and sha(SELF)==runner_pin and sha(ROOT/'MANIFEST.json')==manifest_pin
    m=manifest(); assert m['package']==PACKAGE and m['classification']=='EXPLORATORY_NOT_ACCEPTANCE'
    assert m['status']=='EXECUTABLE_ONLY_AFTER_INDEPENDENT_R7_REVIEW'
    assert m['horizon']==416 and m['seed']=='p13a-core-causal-01'
    assert (m['testTimeoutSeconds'],m['outerTimeoutSeconds'])==(600,630)
    assert m['maxRunOutputBytes']==268435456 and m['minimumFreeBytes']==3*1024**3
    assert m['runnerSha256']==runner_pin
    self_check.check()
    for name,pin in m['entrypoints'].items():
        path=Path(name); safe(path); assert sha(path)==pin,name
    assert subprocess.check_output([str(NODE),'--version'],text=True).strip()=='v20.20.2'
    assert git('rev-parse','HEAD').decode().strip()==head
    assert git('symbolic-ref','HEAD').decode().strip()==BRANCH
    assert git('ls-remote','--exit-code','origin',BRANCH).decode().split()==[head,BRANCH]
    assert git('diff','HEAD','--',*SCOPE)==b''
    assert git('ls-files','--others','--exclude-standard','--',*SCOPE)==b''
    index=Path(git('rev-parse','--path-format=absolute','--git-path','index').decode().strip()); safe(index)
    tree=ROOT/'arms'/arm/'tree'
    assert (tree/'node_modules').is_symlink() and (tree/'node_modules').resolve()==(REPO/'node_modules').resolve()
    return {'package':PACKAGE,'arm':arm,'head':head,'branch':BRANCH,'originHead':head,
        'indexSha256':sha(index),'stageSha256':digest(git('ls-files','--stage','-z')),
        'boundedDiffSha256':digest(git('diff','HEAD','--',*SCOPE)),
        'manifestSha256':manifest_pin,'runnerSha256':runner_pin,
        'armFilePinsSha256':digest(json.dumps(m['arms'][arm]['files'],sort_keys=True).encode()),
        'entrypoints':m['entrypoints'],'diagnosticSha256':m['diagnosticSha256'],
        'horizon':416,'seed':m['seed'],'testTimeoutSeconds':600,'outerTimeoutSeconds':630}

def prior_types(path,pin,pins,arm):
    safe(path); assert path.name=='RESULT.json' and path.is_relative_to(RUNS) and sha(path)==pin
    guard_logic.assert_types_receipt(json.loads(path.read_text()),pins,command_for('types',arm,path.parent),arm,path,EVIDENCE)
def prior_historical(path,pin,pins):
    safe(path); assert path.name=='RESULT.json' and path.is_relative_to(RUNS) and sha(path)==pin
    record=json.loads(path.read_text()); target=manifest()['expectedPins']['historicalOriginal654']; rng=manifest()['expectedRng']['historical']
    guard_logic.assert_prior_historical(record,pins,target,rng,path,EVIDENCE,command_for('clean','historical',path.parent))
    checked=guard_logic.validate_preimages(path.parent/'preimages',target,rng,manifest()['maxRunOutputBytes'])
    assert checked==record['validation']
    vitest=json.loads((path.parent/'vitest.json').read_text())
    assert vitest['numTotalTests']==vitest['numPassedTests']==1 and vitest['numFailedTests']==0
def admit_review(path,pin,manifest_pin,runner_pin):
    safe(R3_REVIEW); safe(R3_RECEIPT)
    assert sha(R3_REVIEW)==R3_REVIEW_SHA256 and sha(R3_RECEIPT)==R3_RECEIPT_SHA256
    assert json.loads(R3_RECEIPT.read_text())=={
        'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R3',
        'classification':'EXPLORATORY_NOT_ACCEPTANCE',
        'manifestSha256':'819c727e11b538a341c92493b928a26ab2793782612b60bc486419c9953da92a',
        'runnerSha256':'9bc4ef181961bd72a63d8fe8ee308be7ca21ca261867b6515630edd8acf87ccf'}
    # The parent must use the separately reviewed literal invocation. This
    # environment value is its handoff, not proof of independence by itself.
    assert path==R7_REVIEW and os.environ.get(EXTERNAL_REVIEW_ENV)==pin
    assert manifest_pin==_AUTHENTICATED_MANIFEST_SHA256
    safe(path); assert sha(path)==pin
    review=json.loads(path.read_text())
    assert review=={'decision':'ACCEPT','package':PACKAGE,
        'classification':'EXPLORATORY_NOT_ACCEPTANCE',
        'manifestSha256':manifest_pin,'runnerSha256':runner_pin}
def import_cleanup():
    assert sha(CLEANUP)==manifest()['entrypoints'][str(CLEANUP)]
    spec=importlib.util.spec_from_file_location('reviewed_preimage_cleanup',CLEANUP)
    helper=importlib.util.module_from_spec(spec); old=sys.dont_write_bytecode; sys.dont_write_bytecode=True
    try: spec.loader.exec_module(helper)
    finally: sys.dont_write_bytecode=old
    return helper

def child(out,binding_pin):
    safe(out/'binding.json'); assert sha(out/'binding.json')==binding_pin
    b=json.loads((out/'binding.json').read_text()); arm=b['arm']; mode=b['mode']
    assert mode in ('types','clean') and b['command']==command_for(mode,arm,out)
    assert (b['seed'],b['horizon'],b['probeTestSeconds'],b['outerCapSeconds'])==('p13a-core-causal-01',416,600,630)
    assert b['formalStem']=='1369-c0-preimage-r7-'+out.name
    preflight=EVIDENCE/(b['formalStem']+'-preflight.json'); safe(preflight)
    pre=json.loads(preflight.read_text())
    assert pre['head']==b['head'] and pre['remote']==b['head'] and pre['advanceCap']==0
    assert pre['index']['sha256']==b['pins']['indexSha256']
    assert pre['stageEntries']['sha256']==b['pins']['stageSha256']
    admit_review(Path(b['staticReviewReceipt']),b['staticReviewSha256'],b['manifestSha256'],b['runnerSha256'])
    assert verify(b['head'],b['manifestSha256'],b['runnerSha256'],arm)==b['pins']
    if mode=='clean': prior_types(Path(b['typesReceipt']),b['typesReceiptSha256'],b['pins'],arm)
    if arm=='modern':
        hp=verify(b['head'],b['manifestSha256'],b['runnerSha256'],'historical')
        prior_historical(Path(b['historicalReceipt']),b['historicalReceiptSha256'],hp)
    helper=import_cleanup(); tree=ROOT/'arms'/arm/'tree'
    process_env=environment(); process_env['PREIMAGE_OUTPUT']=str(out/'preimages')
    done=threading.Event(); limit=threading.Event(); disk=threading.Event()
    def watch(proc):
        while not done.wait(1):
            try:
                total=sum(p.stat().st_size for p in out.rglob('*') if p.is_file() and not p.is_symlink())
                if total>manifest()['maxRunOutputBytes']: limit.set()
                if shutil.disk_usage(ROOT).free<manifest()['minimumFreeBytes']: disk.set()
                if limit.is_set() or disk.is_set():
                    os.killpg(proc.pid,signal.SIGTERM); return
            except ProcessLookupError: return
            except Exception:
                disk.set()
                try: os.killpg(proc.pid,signal.SIGTERM)
                except ProcessLookupError: pass
                return
    start=time.monotonic(); timed_out=False; wait_error=None
    with (out/'stdout.txt').open('x') as stdout,(out/'stderr.txt').open('x') as stderr:
        proc=subprocess.Popen(b['command'],cwd=tree,env=process_env,stdout=stdout,stderr=stderr,start_new_session=True)
        watcher=threading.Thread(target=watch,args=(proc,),daemon=True); watcher.start()
        try:
            write(out/'LAUNCH.json',{'childPid':proc.pid,'ownedProcessGroup':proc.pid,'startNewSession':True,
                  'monotonicStarted':start,'command':b['command'],'bindingSha256':binding_pin,
                  'actualWaitTimeoutSeconds':630 if mode=='clean' else 300})
            try: proc.wait(timeout=630 if mode=='clean' else 300)
            except subprocess.TimeoutExpired: timed_out=True
        except Exception as error: wait_error=error
        finally:
            done.set(); watcher.join(timeout=2)
            def check_source():
                return not limit.is_set() and not disk.is_set() and verify(b['head'],b['manifestSha256'],b['runnerSha256'],arm)==b['pins'] and sha(out/'binding.json')==binding_pin
            def write_receipt(row):
                row.update(stdoutSha256=sha(out/'stdout.txt'),stderrSha256=sha(out/'stderr.txt'),
                    outputLimitExceeded=limit.is_set(),diskReserveBreached=disk.is_set(),
                    outputBytes=sum(p.stat().st_size for p in out.rglob('*') if p.is_file() and not p.is_symlink()))
                write(out/'CHILD.json',row)
            code=helper.finish_child(proc,timed_out,start,b['command'],check_source,write_receipt,wait_error)
    return code

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode',choices=('types','clean')); ap.add_argument('--arm',required=True,choices=('historical','modern'))
    ap.add_argument('--head',required=True); ap.add_argument('--manifest-sha256',required=True)
    ap.add_argument('--self-runner-sha256',required=True); ap.add_argument('--leaf',required=True)
    ap.add_argument('--types-receipt'); ap.add_argument('--types-receipt-sha256')
    ap.add_argument('--historical-receipt'); ap.add_argument('--historical-receipt-sha256')
    ap.add_argument('--static-review-receipt',required=True); ap.add_argument('--static-review-sha256',required=True)
    a=ap.parse_args(); assert re.fullmatch('[a-z0-9-]+',a.leaf)
    admit_review(Path(a.static_review_receipt),a.static_review_sha256,a.manifest_sha256,a.self_runner_sha256)
    assert (a.types_receipt is not None and a.types_receipt_sha256 is not None)==(a.mode=='clean')
    assert (a.historical_receipt is not None and a.historical_receipt_sha256 is not None)==(a.arm=='modern')
    tag=a.arm+'-'+a.mode+'-'+a.leaf; out=RUNS/tag; exclusive(out)
    pins=verify(a.head,a.manifest_sha256,a.self_runner_sha256,a.arm)
    if a.mode=='clean': prior_types(Path(a.types_receipt),a.types_receipt_sha256,pins,a.arm)
    if a.arm=='modern':
        hp=verify(a.head,a.manifest_sha256,a.self_runner_sha256,'historical')
        prior_historical(Path(a.historical_receipt),a.historical_receipt_sha256,hp)
    assert shutil.disk_usage(ROOT).free>=manifest()['minimumFreeBytes']
    power=ac_power(); stem='1369-c0-preimage-r7-'+tag
    formal=[EVIDENCE/(stem+suffix) for suffix in ('.json','.patch','.txt','-preflight.json','-postflight.json')]
    for path in formal: exclusive(path)
    out.parent.mkdir(exist_ok=True); out.mkdir(); (out/'preimages').mkdir(); (out/'power.txt').write_text(power)
    subprocess.Popen(['caffeinate','-is','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    command=command_for(a.mode,a.arm,out)
    binding={'package':PACKAGE,'classification':'EXPLORATORY_NOT_ACCEPTANCE','mode':a.mode,'arm':a.arm,
        'head':a.head,'pins':pins,'manifestSha256':a.manifest_sha256,'runnerSha256':a.self_runner_sha256,
        'seed':'p13a-core-causal-01','horizon':416,'command':command,'probeTestSeconds':600,'outerCapSeconds':630,
        'typesReceipt':a.types_receipt,'typesReceiptSha256':a.types_receipt_sha256,
        'historicalReceipt':a.historical_receipt,'historicalReceiptSha256':a.historical_receipt_sha256,
        'staticReviewReceipt':a.static_review_receipt,'staticReviewSha256':a.static_review_sha256,
        'formalStem':stem}
    write(out/'binding.json',binding); guard=[sys.executable,str(GUARD)]
    subprocess.run([*guard,'pre',stem,'0'],cwd=REPO,env=environment(),check=True)
    recorder_status=None; post_status=None; formal_errors=[]
    try:
        recorder_status=subprocess.run([str(NODE),str(RECORDER),stem,sys.executable,'-I','-B',str(SELF),'--child',str(out),sha(out/'binding.json')],cwd=REPO,env=environment()).returncode
    except Exception as error: formal_errors.append({'phase':'recorder','type':type(error).__name__,'message':str(error)})
    finally:
        try: post_status=subprocess.run([*guard,'post',stem],cwd=REPO,env=environment()).returncode
        except Exception as error: formal_errors.append({'phase':'postflight','type':type(error).__name__,'message':str(error)})
    try:
        record=json.loads(formal[0].read_text()); post=json.loads(formal[4].read_text())
        assert not formal_errors and recorder_status==post_status==0
        assert record['command']==[sys.executable,'-I','-B',str(SELF),'--child',str(out),sha(out/'binding.json')]
        assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
        assert record['sourceSha']==record['sourceShaAtEnd']==post['head']==a.head
        assert verify(a.head,a.manifest_sha256,a.self_runner_sha256,a.arm)==pins
    except Exception as error:
        present=[p for p in out.rglob('*') if p.is_file()]+[p for p in formal if p.is_file()]
        write(out/'WRAPPER-FAILURE.json',{'status':'FORMAL_OR_POSTFLIGHT_FAILURE',
            'recorderStatus':recorder_status,'postflightStatus':post_status,'formalErrors':formal_errors,
            'errorType':type(error).__name__,'error':str(error),
            'artifacts':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in present}})
        return 1
    try:
        child_result=json.loads((out/'CHILD.json').read_text()); group=child_result['processGroup']
        assert child_result['command']==command and record['exitCode']==post['exitCode']
        assert isinstance(child_result['reportingErrors'],list)
        assert all(type(group[k]) is bool for k in ('cleanupVerified','noSurvivors','leaderReaped'))
        expected=124 if child_result['timedOut'] else (1 if child_result['reportingErrors'] or not child_result['allGuardsExact'] or not all(group[k] for k in ('cleanupVerified','noSurvivors','leaderReaped')) else child_result['actualChildExit'])
        assert record['exitCode']==expected
    except Exception as error:
        present=[p for p in out.rglob('*') if p.is_file()]+[p for p in formal if p.is_file()]
        write(out/'WRAPPER-FAILURE.json',{'status':'INCOMPLETE_CHILD_REPORT','actualChildExit':None,
            'recorderChildExit':record.get('exitCode'),'errorType':type(error).__name__,'error':str(error),
            'artifacts':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in present}})
        return 1
    power_error=None
    try: (out/'power-post.txt').write_text(ac_power())
    except Exception as error: power_error={'type':type(error).__name__,'message':str(error)}
    run_bytes=sum(p.stat().st_size for p in out.rglob('*') if p.is_file() and not p.is_symlink())
    output_ok=run_bytes<=manifest()['maxRunOutputBytes']
    disk_ok=shutil.disk_usage(ROOT).free>=manifest()['minimumFreeBytes']
    validation=None; validation_error=None
    if expected==0 and power_error is None and output_ok and disk_ok and not child_result['outputLimitExceeded'] and not child_result['diskReserveBreached']:
        try:
            if a.mode=='clean':
                report=json.loads((out/'vitest.json').read_text())
                assert report['numTotalTests']==report['numPassedTests']==1 and report['numFailedTests']==0
                target=manifest()['expectedPins']['historicalOriginal654' if a.arm=='historical' else 'modernRecordedActual']
                validation=guard_logic.validate_preimages(out/'preimages',target,manifest()['expectedRng'][a.arm],manifest()['maxRunOutputBytes'])
            else: validation={'freshFullTypes':True}
        except Exception as error: validation_error={'type':type(error).__name__,'message':str(error)}
    paths=[p for p in out.rglob('*') if p.is_file()]+formal
    for path in paths: safe(path)
    artifacts={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(paths)}
    accepted=expected==0 and power_error is None and output_ok and disk_ok and validation is not None and validation_error is None and not child_result['outputLimitExceeded'] and not child_result['diskReserveBreached']
    result={**child_result,'package':PACKAGE,'classification':'EXPLORATORY_NOT_ACCEPTANCE',
        'mode':a.mode,'arm':a.arm,'seed':'p13a-core-causal-01','pins':pins,'recorderChildExit':record['exitCode'],
        'staticReviewSha256':a.static_review_sha256,
        'recorderStatus':recorder_status,'livePostflightExact':True,'validation':validation,
        'validationError':validation_error,'powerPostflightError':power_error,'runOutputBytes':run_bytes,
        'outputBoundExact':output_ok,'diskReservePostflight':disk_ok,'accepted':accepted,'artifacts':artifacts,
        'interpretation':'Exploratory preimage evidence only; no protected acceptance.'}
    write(out/'RESULT.json',result)
    write(out/'RESULT.sha256.json',{'sha256':sha(out/'RESULT.json')})
    print(json.dumps({'result':str(out/'RESULT.json'),'sha256':sha(out/'RESULT.json'),
        'accepted':accepted,'actualChildExit':child_result['actualChildExit'],'recorderChildExit':record['exitCode']}))
    return 0 if accepted else 1

if __name__=='__main__':
    if len(sys.argv)==4 and sys.argv[1]=='--child': sys.exit(child(Path(sys.argv[2]),sys.argv[3]))
    sys.exit(main())
