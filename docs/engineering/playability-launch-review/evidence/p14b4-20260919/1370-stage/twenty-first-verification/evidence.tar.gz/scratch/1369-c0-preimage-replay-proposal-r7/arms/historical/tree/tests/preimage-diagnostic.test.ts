// Identical diagnostic source is copied into both isolated arms.
// It records the original four JSON.stringify preimages without changing the engine.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { appendFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { it } from 'vitest'
import { p13aGeneratedStudio } from '../src/harness/p13a/fixtures.js'
import { tick } from '../src/core/tick.js'
import type { GameState } from '../src/core/types.js'

const seed = 'p13a-core-causal-01'
const endWeek = 416
const output = process.env.PREIMAGE_OUTPUT
assert.ok(output && resolve(output) === output, 'PREIMAGE_OUTPUT must be absolute')
mkdirSync(output, { recursive: true })
const sha = (bytes: string) => createHash('sha256').update(bytes).digest('hex')
const encode = (value: unknown) => JSON.stringify(value)
const settlement = (state: GameState) => state.talentMarket.receipts
  .filter((r) => r.kind === 'settled' || r.kind === 'declined' || r.kind === 'expired')
  .map((r) => [r.eventId, r.kind, r.week, r.talentId, r.studioId, r.reasons, r.dropped])
const eventContext = (state: GameState, receipt: GameState['talentMarket']['receipts'][number]) => {
  const market = state.talentMarket as unknown as Record<string, unknown>
  const subject = receipt.talentId
  return {
    receipt,
    cases: state.talentMarket.cases.filter((c) => c.talentId === subject),
    proposalReceipts: state.talentMarket.receipts.filter((r) => r.talentId === subject),
    proposals: Array.isArray(market.proposals) ? market.proposals.filter((p: any) => p.talentId === subject) : market.proposals,
    promises: state.promises.filter((p) => p.beneficiaryPersonId === subject),
    person: state.talent.find((p) => p.id === subject),
    employment: state.hollywood!.employment.filter((e) => e.terms.talentId === subject),
    businesses: state.hollywood!.businesses,
  }
}
const writeFinal = (name: string, value: unknown) => {
  const bytes = encode(value)
  writeFileSync(resolve(output, `${name}.json`), bytes, { flag: 'wx' })
  return { sha256: sha(bytes), bytes: Buffer.byteLength(bytes), length: Array.isArray(value) ? value.length : null }
}

it('records the full p13a original digest preimages', () => {
  let state = p13aGeneratedStudio(seed)
  assert.equal(state.market.tick, 0)
  let seenReceipts = 0
  let seenTakes = 0
  const weeklyPath = resolve(output, 'weekly.ndjson')
  const chooserPath = resolve(output, 'terminal-context.ndjson')
  writeFileSync(weeklyPath, '', { flag: 'wx' })
  writeFileSync(chooserPath, '', { flag: 'wx' })
  appendFileSync(weeklyPath, encode({ week: 0, receiptsAppended: [], receipts: state.talentMarket.receipts, employment: state.hollywood!.employment,
    takesAppended: state.firstTakes, firstTakes: state.firstTakes, settlement: settlement(state) }) + '\n')
  for (let step = 1; step <= endWeek; step++) {
    state = tick(state)
    const receipts = state.talentMarket.receipts
    assert.equal(state.market.tick, step, 'contiguous natural ticks')
    assert.ok(state.talentMarket.receipts.length >= seenReceipts, 'receipt append-only invariant')
    assert.ok(state.firstTakes.length >= seenTakes, 'first-take append-only invariant')
    const addedReceipts = state.talentMarket.receipts.slice(seenReceipts)
    const addedTakes = state.firstTakes.slice(seenTakes)
    appendFileSync(weeklyPath, encode({ week: step, receiptsAppended: addedReceipts, receipts,
      employment: state.hollywood!.employment, takesAppended: addedTakes,
      firstTakes: state.firstTakes, settlement: settlement(state) }) + '\n')
    for (const receipt of addedReceipts) {
      if (receipt.kind === 'settled' || receipt.kind === 'declined' || receipt.kind === 'expired') {
        appendFileSync(chooserPath, encode({ week: step, ...eventContext(state, receipt) }) + '\n')
      }
    }
    seenReceipts = state.talentMarket.receipts.length
    seenTakes = state.firstTakes.length
  }
  const final = {
    seed, week: state.market.tick, rngState: state.rngState,
    settlement: writeFinal('settlement', settlement(state)),
    receipts: writeFinal('receipts', state.talentMarket.receipts),
    employment: writeFinal('employment', state.hollywood!.employment),
    takes: writeFinal('takes', state.firstTakes),
    weekly: { sha256: sha(readFileSync(weeklyPath, 'utf8')) },
    terminalContext: { sha256: sha(readFileSync(chooserPath, 'utf8')) },
  }
  writeFileSync(resolve(output, 'final.json'), encode(final) + '\n', { flag: 'wx' })
}, 600_000)
