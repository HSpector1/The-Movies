import { defineConfig } from 'vitest/config'
export default defineConfig({ test: { environment: 'node', include: ['tests/preimage-diagnostic.test.ts'], fileParallelism: false, maxWorkers: 1, minWorkers: 1, testTimeout: 600_000 } })
