#!/usr/bin/env python3
"""Isolated stdlib-only read of exact independently reviewed r7 preimages."""
import collections, hashlib, json, os, sys
from pathlib import Path
assert sys.flags.isolated and sys.dont_write_bytecode
ROOT=Path('/Users/zacheryspector/studio-scratch')
RUNS=ROOT/'1369-c0-preimage-recorded-runs-r7'
OUT=ROOT/'1369-c0-r7-full-preimage-compare-r1'
PINS={
 'historical':{
  'result':'5235b18b83c8e70dd12b36a7bda932e78cb5b55ef344419a92e4e370f540c5cc',
  'review':'8268a22969b59bf3f2488ffc5dfc8c2ae454aeac336198c65f776dc73646854a',
  'receipt':'b5d06db3828c4f481375802a53384cc3b0bb9a937c4783fe960cc4b5dd88c2f9',
  'arrays':{'settlement':'706e54c6ec9728df1664025982ebbafeb0fc36afb245b6bd0b983305f6a10a77','receipts':'af8c4d1325ecb350dbc07fbf2f762dd8257db04075b8030bf7bd975b4cb2a766','employment':'09bcc35ba327579ac63dd1ed63535b23cbc8ff55b25fd9597a2872a819f08750','takes':'8af116b1687ed210c02953b5b506456e638a64482e8042b0e549b0d57e428694'},
  'weekly':'ec8146b1930678cb9bbab7605297fe09adccef561a338b17e13ea96398fa51b2',
  'final':'7e0e93f250668d70e9255904510043ef70b581fef5c0809250971fe268948b6e'},
 'modern':{
  'result':'4c3fe1aab82df9cf924f6a5c380e27a9999f5c7e3fa3a4acbfc3854156743207',
  'review':'1c01bc91fd6f8e5cede3cc086937cedb2c776bfe7e4a57b8a4a0fe1e682f9f49',
  'receipt':'676bdd2c18655526a9cffdf18cb6a0b63e7bdd4b1d4ee05e47478706db85d3d7',
  'arrays':{'settlement':'8a4df62fdd64ba26fc6e00e438c47c25749921fcad0e849921a7909f2f8b85f9','receipts':'1c3f415bf98e969c3af783e2613b19bd6c573e935a49fd93289626ce956720f9','employment':'7e64d2fbfd525edf40daa4fb952fe08ac68d4a877b4d212afd7adcfdca25237d','takes':'e88c6b792a493768e766bbdf59698ed32a48b1c9cf4982cc9f5dfd894983e593'},
  'weekly':'93b501bfefa958a0e2291abbecea68932d3ee4068a771ff03f3d34ae6879008b',
  'final':'e59f552eee54879577e9b129bfd104cc297555f88474455a22d06bcb2576f9a6'}}
PACKAGE='1369-C0-PREIMAGE-REPLAY-R7';HEAD='fad9fb1a8c18de813bb8ad5fac371130736b1b30'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def small(v):
 s=json.dumps(v,ensure_ascii=False,sort_keys=True)
 return s if len(s)<=500 else s[:497]+'...'
def diff(a,b,path='$'):
 if a==b:return None
 if isinstance(a,dict) and isinstance(b,dict):
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:return {'path':path+'.'+str(k),'historical':small(a.get(k,'<ABSENT>')),'modern':small(b.get(k,'<ABSENT>'))}
   d=diff(a[k],b[k],path+'.'+str(k))
   if d:return d
 if isinstance(a,list) and isinstance(b,list):
  for i,(x,y) in enumerate(zip(a,b)):
   d=diff(x,y,path+f'[{i}]')
   if d:return d
  if len(a)!=len(b):return {'path':path+'.length','historical':len(a),'modern':len(b)}
 return {'path':path,'historical':small(a),'modern':small(b)}
def identity(kind,row):
 if kind=='settlement':return (row[2],row[3],row[1])
 if kind=='receipts':return (row.get('week'),row.get('kind'),row.get('talentId'),row.get('studioId'))
 if kind=='employment':return (row.get('contractId'),)
 if kind=='takes':return (row.get('week'),row.get('productionId'),row.get('studioId'))
 raise ValueError(kind)
def matched(kind,left,right):
 def maprows(rows):
  counts=collections.Counter();result={}
  for ordinal,row in enumerate(rows):
   base=identity(kind,row);counts[base]+=1;result[base+(counts[base],)]=(ordinal,row)
  return result
 a,b=maprows(left),maprows(right);keys=a.keys()&b.keys();changed=[k for k in a if k in b and a[k][1]!=b[k][1]]
 first=changed[0] if changed else None
 return {'paired':len(keys),'pairedEqual':len(keys)-len(changed),'pairedChanged':len(changed),'historicalOnly':len(a.keys()-b.keys()),'modernOnly':len(b.keys()-a.keys()),'historicalOnlyExamples':[list(k) for k in sorted(a.keys()-b.keys())[:3]],'modernOnlyExamples':[list(k) for k in sorted(b.keys()-a.keys())[:3]],'firstChanged':None if first is None else {'identity':list(first),'historicalOrdinal':a[first][0],'modernOrdinal':b[first][0],'difference':diff(a[first][1],b[first][1])}}
inputs={};arrays={}
for role in ('historical','modern'):
 pin=PINS[role];leaf=RUNS/f'{role}-clean-clean-r1';review=ROOT/f'1369-c0-preimage-r7-{role}-clean-independent-review-r1'
 for n,key in (('RESULT.json','result'),):assert sha(leaf/n)==pin[key]
 assert sha(review/'REVIEW.md')==pin['review'] and sha(review/'RECEIPT.json')==pin['receipt']
 rec=json.loads((review/'RECEIPT.json').read_text());result=json.loads((leaf/'RESULT.json').read_text())
 assert rec['resultSha256']==pin['result'] and rec['arm']==role and rec['package']==PACKAGE and rec['head']==HEAD
 assert result['accepted'] is True and result['actualChildExit']==result['recorderChildExit']==0 and result['classification']=='EXPLORATORY_NOT_ACCEPTANCE'
 p=leaf/'preimages';assert sha(p/'weekly.ndjson')==pin['weekly'] and sha(p/'final.json')==pin['final']
 arrays[role]={}
 for name,h in pin['arrays'].items():
  q=p/f'{name}.json';assert sha(q)==h;arrays[role][name]=json.loads(q.read_text())
 inputs[role]={'resultSha256':pin['result'],'reviewSha256':pin['review'],'receiptSha256':pin['receipt'],'weeklySha256':pin['weekly'],'finalSha256':pin['final'],'arraySha256':pin['arrays']}
summary={'classification':'DESCRIPTIVE_ONLY_NOT_ACCEPTANCE','package':PACKAGE,'head':HEAD,'seed':'p13a-core-causal-01','horizon':416,'inputs':inputs,'arrays':{},'weekly':{}}
for name in ('settlement','receipts','employment','takes'):
 a,b=arrays['historical'][name],arrays['modern'][name]
 first=next((i for i,(x,y) in enumerate(zip(a,b)) if x!=y),None)
 summary['arrays'][name]={'historicalLength':len(a),'modernLength':len(b),'firstPositional':None if first is None else {'ordinal':first,'difference':diff(a[first],b[first]),'historicalIdentity':list(identity(name,a[first])),'modernIdentity':list(identity(name,b[first]))},'stable':matched(name,a,b)}
weekly={}
for role in ('historical','modern'):
 p=RUNS/f'{role}-clean-clean-r1/preimages/weekly.ndjson';weekly[role]=[json.loads(x) for x in p.read_text().splitlines()]
 assert len(weekly[role])==417 and [x['week'] for x in weekly[role]]==list(range(417))
summary['weekly']['rows']=417
summary['weekly']['firstAny']=next((w for w,(a,b) in enumerate(zip(weekly['historical'],weekly['modern'])) if a!=b),None)
for field in ('receiptsAppended','receipts','employment','takesAppended','firstTakes','settlement'):
 hit=next(((w,diff(a[field],b[field])) for w,(a,b) in enumerate(zip(weekly['historical'],weekly['modern'])) if a[field]!=b[field]),None)
 summary['weekly'][field]=None if hit is None else {'week':hit[0],'difference':hit[1]}
summary['limits']=['Historical employment SHA 09bcc35b... is the original raw 654-T target; later approved 4cffcb41... belongs to a different protected era and is not equated to either r7 array.','First recorded field differences are descriptive and do not identify a first policy decision or individual source-file cause.','The two accepted r7 clean results use prospective exploratory 600/630 limits; this report does not confer original 300/330 or gameplay acceptance.']
OUT.mkdir(exist_ok=True)
(OUT/'REPORT.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'arrays':{k:{'lengths':(v['historicalLength'],v['modernLength']),'firstPositional':v['firstPositional']['difference']['path'] if v['firstPositional'] else None,'firstStable':v['stable']['firstChanged']['difference']['path'] if v['stable']['firstChanged'] else None,'paired':v['stable']['paired'],'only':(v['stable']['historicalOnly'],v['stable']['modernOnly'])} for k,v in summary['arrays'].items()},'weekly':summary['weekly']},indent=2)[:7000])
