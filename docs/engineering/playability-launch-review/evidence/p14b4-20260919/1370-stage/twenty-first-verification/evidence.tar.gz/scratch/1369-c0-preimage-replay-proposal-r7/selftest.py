#!/usr/bin/env python3
"""Static positive and adversarial fixtures; never starts types or a replay."""
import copy, hashlib, importlib.util, json, os, tempfile, sys
from pathlib import Path
sys.dont_write_bytecode = True
os.environ['C0_R7_EXTERNAL_MANIFEST_SHA256'] = hashlib.sha256((Path(__file__).absolute().parent/'MANIFEST.json').read_bytes()).hexdigest()
assert sys.flags.isolated
spec=importlib.util.spec_from_file_location('runner', Path(__file__).absolute().parent/'runner.py')
runner=importlib.util.module_from_spec(spec); sys.modules['runner']=runner; spec.loader.exec_module(runner)
import compare, guard_logic as g, self_check

ROOT = Path(__file__).resolve().parent

def fail(action):
    try: action()
    except (AssertionError, KeyError, FileNotFoundError): return
    raise AssertionError('negative fixture admitted')

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, separators=(',', ':')))

def external_pin_check(manifest_path, runner_path, review_path, manifest_sha, runner_sha, review_sha):
    assert g.sha(manifest_path)==manifest_sha and g.sha(runner_path)==runner_sha
    assert g.sha(review_path)==review_sha
    assert json.loads(review_path.read_text())=={
        'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R7',
        'classification':'EXPLORATORY_NOT_ACCEPTANCE',
        'manifestSha256':manifest_sha,'runnerSha256':runner_sha}

def synthetic_types(base):
    run = base / 'historical-types-q1'; run.mkdir()
    (run / 'preimages').mkdir()
    formal = base / 'formal'; formal.mkdir()
    result_path = run / 'RESULT.json'
    pins = {'head':'h','indexSha256':'i','stageSha256':'s','manifestSha256':'m','runnerSha256':'r'}
    command = ['node','tsc']; stem = '1369-c0-preimage-r7-' + run.name
    binding = {'package':'1369-C0-PREIMAGE-REPLAY-R7','classification':'EXPLORATORY_NOT_ACCEPTANCE',
               'mode':'types','arm':'historical','command':command,'pins':pins,'head':'h',
               'horizon':416,'seed':'p13a-core-causal-01','manifestSha256':'m','runnerSha256':'r',
               'probeTestSeconds':600,'outerCapSeconds':630,'formalStem':stem,'staticReviewSha256':'review'}
    write(run / 'binding.json', binding)
    group = {'ownedProcessGroup':12345,'cleanupVerified':True,'noSurvivors':True,'leaderReaped':True,'errors':[]}
    write(run / 'LAUNCH.json', {'bindingSha256':g.sha(run/'binding.json'),'command':command,
          'startNewSession':True,'actualWaitTimeoutSeconds':300,'childPid':12345,'ownedProcessGroup':12345})
    (run / 'stdout.txt').write_text(''); (run / 'stderr.txt').write_text('')
    (run / 'power.txt').write_text('AC'); (run / 'power-post.txt').write_text('AC')
    child = {'command':command,'actualChildExit':0,'timedOut':False,'allGuardsExact':True,
             'reportingErrors':[],'processGroup':group,'stdoutSha256':g.sha(run/'stdout.txt'),
             'stderrSha256':g.sha(run/'stderr.txt')}
    write(run / 'CHILD.json', child)
    pre = {'head':'h','remote':'h','advanceCap':0,'index':{'sha256':'i'},'stageEntries':{'sha256':'s'}}
    write(formal / (stem+'-preflight.json'), pre)
    (formal / (stem+'.txt')).write_text('formal'); (formal / (stem+'.patch')).write_text('')
    recorder = {'sourceSha':'h','sourceShaAtEnd':'h','fixedSource':True,'exitCode':0,
        'command':['python','-I','-B',str(ROOT/'runner.py'),'--child',str(run),g.sha(run/'binding.json')]}
    write(formal / (stem+'.json'), recorder)
    post = {'head':'h','fixedSource':True,'allGuardsExact':True,'exitCode':0,
            'record':{'sha256':g.sha(formal/(stem+'.json'))},
            'raw':{'sha256':g.sha(formal/(stem+'.txt'))},
            'patch':{'sha256':g.sha(formal/(stem+'.patch'))}}
    write(formal / (stem+'-postflight.json'), post)
    required = g.required_artifacts(result_path, formal, 'types')
    artifacts = {name:{'sha256':g.sha(name),'bytes':Path(name).stat().st_size} for name in required}
    record = {**child,'package':'1369-C0-PREIMAGE-REPLAY-R7','classification':'EXPLORATORY_NOT_ACCEPTANCE',
        'mode':'types','arm':'historical','pins':pins,'accepted':True,'validation':{'freshFullTypes':True},
        'recorderChildExit':0,'recorderStatus':0,'livePostflightExact':True,'powerPostflightError':None,
        'outputBoundExact':True,'diskReservePostflight':True,'outputLimitExceeded':False,
        'diskReserveBreached':False,'staticReviewSha256':'review','artifacts':artifacts}
    write(result_path, record)
    write(run / 'RESULT.sha256.json', {'sha256':g.sha(result_path)})
    return record, pins, command, result_path, formal

def synthetic_preimages(root):
    root.mkdir()
    rows=[{'week':w,'receiptsAppended':[],'receipts':[],'employment':[],
           'takesAppended':[],'firstTakes':[],'settlement':[]} for w in range(417)]
    (root/'weekly.ndjson').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
    (root/'terminal-context.ndjson').write_text('')
    for key in g.KEYS: (root/(key+'.json')).write_text('[]')
    target={key:g.sha(root/(key+'.json')) for key in g.KEYS}
    final={'seed':'p13a-core-causal-01','week':416,'rngState':'synthetic',
           'weekly':{'sha256':g.sha(root/'weekly.ndjson')},
           'terminalContext':{'sha256':g.sha(root/'terminal-context.ndjson')}}
    final.update({key:{'sha256':target[key],'bytes':2,'length':0} for key in g.KEYS})
    write(root/'final.json',final)
    assert g.validate_preimages(root,target,'synthetic',1_000_000)['weeklyRows']==417
    changed=(root/'weekly.ndjson').read_text().replace('"week":208','"week":207',1)
    (root/'weekly.ndjson').write_text(changed)
    write(root/'final.json',{**final,'weekly':{'sha256':g.sha(root/'weekly.ndjson')}})
    fail(lambda:g.validate_preimages(root,target,'synthetic',1_000_000))
    fail(lambda:g.validate_preimages(root,target,'synthetic',10))

def main():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    with tempfile.TemporaryDirectory(prefix='inventory-negative-',dir=ROOT) as extra:
        nested=Path(extra)/'nested'; nested.mkdir(); (nested/'extra.txt').write_text('extra')
        assert self_check.inventory()!=manifest['objectInventory']
        (Path(extra)/'linked-directory').symlink_to(nested,target_is_directory=True)
        fail(self_check.inventory)
    with tempfile.TemporaryDirectory(prefix='receipt-negative-',dir=ROOT) as temp:
        base=Path(temp)
        record,pins,command,path,formal=synthetic_types(base)
        admit=lambda row:g.assert_types_receipt(row,pins,command,'historical',path,formal)
        admit(record)
        for key,value in [('accepted',False),('actualChildExit',1),('timedOut',True),('pins',{'head':'wrong'}),('artifacts',{})]:
            bad=copy.deepcopy(record); bad[key]=value
            fail(lambda bad=bad:admit(bad))
        missing=next(iter(g.required_artifacts(path,formal,'types')))
        bad=copy.deepcopy(record); bad['artifacts'].pop(missing)
        fail(lambda:admit(bad))
        bad=copy.deepcopy(record); bad['processGroup']['noSurvivors']=False
        fail(lambda:admit(bad))
        bad=copy.deepcopy(record); bad['artifacts'][str(path.parent/'binding.json')]['sha256']='0'*64
        fail(lambda:admit(bad))
        formal_file=formal/('1369-c0-preimage-r7-'+path.parent.name+'-postflight.json')
        formal_bytes=formal_file.read_bytes(); formal_file.unlink()
        fail(lambda:admit(record))
        formal_file.write_bytes(formal_bytes)
        # Combined, self-consistent local tamper: change bound HEAD, update binding and
        # launch hashes, then rehash listed artifacts. The independent pins still refuse.
        binding_path=path.parent/'binding.json'; binding=json.loads(binding_path.read_text())
        binding['head']='forged'; write(binding_path,binding)
        launch_path=path.parent/'LAUNCH.json'; launch=json.loads(launch_path.read_text())
        launch['bindingSha256']=g.sha(binding_path); write(launch_path,launch)
        forged=copy.deepcopy(record)
        for item in (binding_path,launch_path):
            forged['artifacts'][str(item)]={'sha256':g.sha(item),'bytes':item.stat().st_size}
        fail(lambda:admit(forged))
        binding['head']='h'; binding['probeTestSeconds']=601; write(binding_path,binding)
        forged_cap=copy.deepcopy(record)
        forged_cap['artifacts'][str(binding_path)]={'sha256':g.sha(binding_path),'bytes':binding_path.stat().st_size}
        fail(lambda:admit(forged_cap))
        forged_route=copy.deepcopy(record); forged_route['mode']='clean'; forged_route['arm']='modern'
        fail(lambda:admit(forged_route))
        review=base/'review.json'
        write(review,{'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R7',
            'classification':'EXPLORATORY_NOT_ACCEPTANCE','manifestSha256':'m','runnerSha256':'r'})
        fail(lambda:runner.admit_review(review,g.sha(review),'m','r'))
        fail(lambda:runner.admit_review(review,'0'*64,'m','r'))
        changed_manifest=base/'changed-manifest.json'; write(changed_manifest,{'runnerSha256':'changed'})
        changed_runner=base/'changed-runner.py'; changed_runner.write_text('changed runner')
        write(review,{'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R7',
            'classification':'EXPLORATORY_NOT_ACCEPTANCE',
            'manifestSha256':g.sha(changed_manifest),'runnerSha256':g.sha(changed_runner)})
        fail(lambda:runner.admit_review(review,g.sha(review),g.sha(changed_manifest),g.sha(changed_runner)))
        frozen_manifest=base/'frozen-manifest.json'; frozen_manifest.write_text('frozen manifest')
        frozen_runner=base/'frozen-runner.py'; frozen_runner.write_text('frozen runner')
        r7_review=base/'r7-review.json'
        fixed_m,fixed_r=g.sha(frozen_manifest),g.sha(frozen_runner)
        write(r7_review,{'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R7',
            'classification':'EXPLORATORY_NOT_ACCEPTANCE','manifestSha256':fixed_m,'runnerSha256':fixed_r})
        fixed_review=g.sha(r7_review)
        external_pin_check(frozen_manifest,frozen_runner,r7_review,fixed_m,fixed_r,fixed_review)
        wrong_package=json.loads(r7_review.read_text()); wrong_package['package']='wrong-package'; write(r7_review,wrong_package)
        fail(lambda:external_pin_check(frozen_manifest,frozen_runner,r7_review,fixed_m,fixed_r,g.sha(r7_review)))
        wrong_package['package']='1369-C0-PREIMAGE-REPLAY-R7'; write(r7_review,wrong_package)
        frozen_manifest.write_text('paired changed manifest'); frozen_runner.write_text('paired changed runner')
        write(r7_review,{'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R7',
            'classification':'EXPLORATORY_NOT_ACCEPTANCE',
            'manifestSha256':g.sha(frozen_manifest),'runnerSha256':g.sha(frozen_runner)})
        fail(lambda:external_pin_check(frozen_manifest,frozen_runner,r7_review,fixed_m,fixed_r,fixed_review))
        fail(lambda:runner.admit_review(review,g.sha(review),'m','r'))
        assert runner.R3_REVIEW.is_file() and runner.R3_RECEIPT.is_file()
        synthetic_preimages(base/'preimages')
        assert compare.first_field([1],[2])['field']=='$[0]'
        historical=runner.RUNS/'historical-clean-static/RESULT.json'
        modern=runner.RUNS/'modern-clean-static/RESULT.json'
        compare.require_unique_clean_paths(historical,modern)
        fail(lambda:compare.require_unique_clean_paths(historical,historical))
        fail(lambda:compare.require_unique_clean_paths(runner.RUNS/'historical-types-static/RESULT.json',modern))
        old=[{'week':week,'receipts':[],'employment':[],'firstTakes':[],'settlement':[]} for week in range(417)]
        new=copy.deepcopy(old); new[208]['receipts']=[{'eventId':'changed'}]
        assert compare.compare_weekly(old,new)['receipts']['week']==208
    print('STATIC_NEGATIVE_FIXTURES_PASS')

if __name__=='__main__': main()
