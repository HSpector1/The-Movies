# 1369 adoption four-arm exploratory proposal r5

Status: `STATIC_PROPOSAL_NO_RUN`. This is the real protected `p13-public-commercial-adoption` seed over 416 natural weeks with 417 genuine save/migration admissions, full weekly snapshots, original pins, 720-second test and 750-second recorder exploratory caps. It is not original U 300/330 or observed acceptance. No r5 types or clean run has occurred.

R5 retains the r2 parent import and r3 child pre-auth fixes, and closes the r4 two-read gap: each bootstrap hashes a single `program` buffer and compiles that same buffer. An isolated external `python3 -I -B -c` parent checks literal manifest, runner and independent review SHA values before executing runner bytes. The runner itself requires isolated startup and checks the externally pinned manifest plus exact recursive package file and symlink inventory before importing `argparse`. The package path remains off `sys.path`. Both parent and recorder child read runner bytes once, hash that immutable buffer, and compile the same buffer. Its recorder child uses a separate `python3 -I -B -c` bootstrap carrying the externally checked manifest, runner, and review hashes as literal values; it checks those bytes before executing runner code, then repeats the full inventory and receipt gates before starting Node. `bootstrap_negative.py` also probes a transient second-read swap: the r4 pattern executes its marker, while r5 does not. It proves that altered listed Python code, an unlisted `argparse.py` shadow, paired manifest/runner drift with a top-level `PREAUTH` marker, extra files and symlinks fail before injected top-level code runs in parent and child paths.

After independent r5 review issues the exact external receipt, invoke the parent through this template. Replace only the three SHA placeholders and HEAD/leaf with separately pinned values; do not compute authority pins from the package at launch. The receipt path and JSON schema are enforced by the runner. Run one arm and one mode at a time through the recorded lane.

```bash
python3 -I -B -c 'import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1369-causal-adoption-exploratory-proposal-r5")
runner=root/"runner/run.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1369-causal-adoption-exploratory-independent-review-r5/RECEIPT.json")
manifest_sha="<FROZEN_R5_MANIFEST_SHA>"
runner_sha="<FROZEN_R5_RUNNER_SHA>"
review_sha="<INDEPENDENT_R5_REVIEW_SHA>"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
program=runner.read_bytes()
assert str(root) not in sys.path and str(root/"runner") not in sys.path
assert sha(manifest)==manifest_sha and hashlib.sha256(program).hexdigest()==runner_sha and sha(review)==review_sha
assert json.loads(review.read_text())=={"decision":"ACCEPT","package":"1369-CAUSAL-ADOPTION-EXPLORATORY-R5","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_sha,"runnerSha256":runner_sha}
os.environ["ADOPTION_R5_EXTERNAL_MANIFEST_SHA256"]=manifest_sha
os.environ["ADOPTION_R5_EXTERNAL_REVIEW_SHA256"]=review_sha
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(program,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner)})' types --arm C0G --head <EXACT_ORIGIN_HEAD> --manifest-sha256 <FROZEN_R5_MANIFEST_SHA> --self-runner-sha256 <FROZEN_R5_RUNNER_SHA> --leaf <UNIQUE_LEAF> --static-review-receipt /Users/zacheryspector/studio-scratch/1369-causal-adoption-exploratory-independent-review-r5/RECEIPT.json --static-review-sha256 <INDEPENDENT_R5_REVIEW_SHA>
```

For clean, use the same bootstrap and exact arm, but `clean --seed p13-public-commercial-adoption` and the fresh same-arm `--types-receipt` and `--types-receipt-sha256`. Do not reuse p13a types. The runner requires caller HEAD to equal live HEAD and explicit origin, with bounded source and index/stage guards; manifest `coordinatorHead` is null only to defer the HEAD until the parent plan checkpoint. R5 retains actual Node and recorder exits, formal five-file pre/postflight, AC/disk checks, cleanup/no-survivor checks, exact artifact membership, and timeout failure. Four source arms C0G/F6G/AG/ABG are byte-identical to the independently reviewed p13a r3 production arms. AG→ABG combines B, Save46 representation and C plumbing, not B alone.

`python3 -I -B selfcheck.py` and `python3 -I -B bootstrap_negative.py` are static checks. Independent adversarial review is required before types, and a separate review of each types receipt before its clean launch. Preserve any new mismatch or timeout as failure evidence.
