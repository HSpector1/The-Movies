#!/usr/bin/env python3
"""Descriptive first-field comparison of two explicit accepted clean leaves."""
import argparse, json, os, sys
from pathlib import Path
sys.dont_write_bytecode = True
import guard_logic, runner, self_check

ROOT = Path(__file__).resolve().parent
RUNS = runner.RUNS
FORMAL = runner.EVIDENCE
ARRAYS = {'receipts': 'receipts', 'employment': 'employment',
          'takes': 'firstTakes', 'settlement': 'settlement'}

def require_unique_clean_paths(historical_path, modern_path):
    assert historical_path != modern_path
    assert historical_path.is_absolute() and modern_path.is_absolute()
    assert historical_path.name == modern_path.name == 'RESULT.json'
    assert historical_path.is_relative_to(RUNS) and modern_path.is_relative_to(RUNS)
    assert historical_path.parent.name.startswith('historical-clean-')
    assert modern_path.parent.name.startswith('modern-clean-')

def first_field(a, b, path='$'):
    if type(a) is not type(b):
        return {'field': path, 'historical': a, 'modern': b}
    if isinstance(a, list):
        for i in range(max(len(a), len(b))):
            if i >= len(a) or i >= len(b):
                return {'field': f'{path}[{i}]', 'historical': a[i] if i < len(a) else '<absent>',
                        'modern': b[i] if i < len(b) else '<absent>'}
            found = first_field(a[i], b[i], f'{path}[{i}]')
            if found: return found
    elif isinstance(a, dict):
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                return {'field': f'{path}.{key}', 'historical': a.get(key, '<absent>'),
                        'modern': b.get(key, '<absent>')}
            found = first_field(a[key], b[key], f'{path}.{key}')
            if found: return found
    elif a != b:
        return {'field': path, 'historical': a, 'modern': b}
    return None

def accepted(path, pin, arm, manifest, historical_reference=None):
    runner.safe(path)
    assert path.name == 'RESULT.json' and path.is_relative_to(RUNS)
    assert path.parent.name.startswith(arm + '-clean-')
    assert guard_logic.sha(path) == pin
    record = json.loads(path.read_text())
    pins = record['pins']
    assert pins['package'] == manifest['package'] and pins['arm'] == arm
    assert pins['manifestSha256'] == guard_logic.sha(ROOT / 'MANIFEST.json')
    assert pins['runnerSha256'] == manifest['runnerSha256']
    assert pins['entrypoints'] == manifest['entrypoints']
    assert pins['armFilePinsSha256'] == runner.digest(json.dumps(manifest['arms'][arm]['files'], sort_keys=True).encode())
    assert pins['seed'] == manifest['seed'] and pins['horizon'] == 416
    assert (pins['testTimeoutSeconds'], pins['outerTimeoutSeconds']) == (600, 630)
    command = runner.command_for('clean', arm, path.parent)
    guard_logic.assert_receipt_integrity(record, pins, command, arm, 'clean', path, FORMAL)
    binding = json.loads((path.parent / 'binding.json').read_text())
    runner.prior_types(Path(binding['typesReceipt']), binding['typesReceiptSha256'], pins, arm)
    if arm == 'modern':
        assert historical_reference is not None
        historical_path, historical_sha, historical_pins = historical_reference
        assert binding['historicalReceipt'] == str(historical_path)
        assert binding['historicalReceiptSha256'] == historical_sha
        runner.prior_historical(historical_path, historical_sha, historical_pins)
    target = manifest['expectedPins']['historicalOriginal654' if arm == 'historical' else 'modernRecordedActual']
    rng = manifest['expectedRng'][arm]
    checked = guard_logic.validate_preimages(path.parent / 'preimages', target, rng, manifest['maxRunOutputBytes'])
    assert checked == record['validation']
    vitest = json.loads((path.parent / 'vitest.json').read_text())
    assert vitest['numTotalTests'] == vitest['numPassedTests'] == 1 and vitest['numFailedTests'] == 0
    weekly = [json.loads(line) for line in (path.parent / 'preimages/weekly.ndjson').read_text().splitlines()]
    return record, weekly

def compare(historical_path, historical_sha, modern_path, modern_sha, output):
    self_check.check()
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    require_unique_clean_paths(historical_path, modern_path)
    old_result, old = accepted(historical_path, historical_sha, 'historical', manifest)
    new_result, new = accepted(modern_path, modern_sha, 'modern', manifest,
                               (historical_path, historical_sha, old_result['pins']))
    common = ('package', 'head', 'branch', 'originHead', 'indexSha256', 'stageSha256',
              'boundedDiffSha256', 'manifestSha256', 'runnerSha256', 'entrypoints',
              'diagnosticSha256', 'horizon', 'seed', 'testTimeoutSeconds', 'outerTimeoutSeconds')
    assert all(old_result['pins'][name] == new_result['pins'][name] for name in common)
    assert old_result['staticReviewSha256'] == new_result['staticReviewSha256']
    differences = compare_weekly(old, new)
    terminal_old = [json.loads(line) for line in (historical_path.parent / 'preimages/terminal-context.ndjson').read_text().splitlines()]
    terminal_new = [json.loads(line) for line in (modern_path.parent / 'preimages/terminal-context.ndjson').read_text().splitlines()]
    result = {'classification': 'EXPLORATORY_NOT_ACCEPTANCE',
              'historicalResult': {'path': str(historical_path), 'sha256': historical_sha},
              'modernResult': {'path': str(modern_path), 'sha256': modern_sha},
              'firstChanged': differences,
              'firstTerminalContextDifference': first_field(terminal_old, terminal_new),
              'preimageFiles': {arm: {name: {'path': str(path.parent / 'preimages' / (name + '.json')),
                                              'sha256': guard_logic.sha(path.parent / 'preimages' / (name + '.json'))}
                                       for name in ARRAYS}
                                for arm, path in (('historical', historical_path), ('modern', modern_path))}}
    runner.exclusive(output)
    with output.open('x') as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write('\n')
    return result

def compare_weekly(old, new):
    assert len(old) == len(new) == 417
    assert [row['week'] for row in old] == [row['week'] for row in new] == list(range(417))
    differences = {}
    for name, weekly_key in ARRAYS.items():
        differences[name] = None
        for week in range(417):
            found = first_field(old[week][weekly_key], new[week][weekly_key])
            if found:
                differences[name] = {'week': week, 'array': name, 'indexAndField': found}
                break
    return differences

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--historical-result', type=Path, required=True)
    parser.add_argument('--historical-sha256', required=True)
    parser.add_argument('--modern-result', type=Path, required=True)
    parser.add_argument('--modern-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    compare(args.historical_result, args.historical_sha256, args.modern_result, args.modern_sha256, args.output)
    print(args.output)

if __name__ == '__main__': main()
