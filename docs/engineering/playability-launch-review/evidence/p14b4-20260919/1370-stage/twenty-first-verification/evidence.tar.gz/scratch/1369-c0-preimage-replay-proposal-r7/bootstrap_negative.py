#!/usr/bin/env python3
"""Static pre-import negative probes of real parent and recorder-child runner paths."""
import hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).absolute().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def attempt(root, manifest_pin, mode, review):
    env=dict(os.environ, C0_R7_EXTERNAL_MANIFEST_SHA256=manifest_pin,
             PYTHONDONTWRITEBYTECODE='1')
    if mode=='parent':
        # The same external parent structure as README, using a synthetic static
        # review fixture; this tests code order, not independent review authority.
        code=f"""import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path({str(root)!r}); runner=root/'runner.py'; manifest=root/'MANIFEST.json'
review=Path({str(review)!r}); manifest_sha={manifest_pin!r}
runner_sha={sha(ROOT/'runner.py')!r}; review_sha={sha(review)!r}
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path
assert sha(manifest.read_bytes())==manifest_sha
program=runner.read_bytes(); assert sha(program)==runner_sha
assert sha(review.read_bytes())==review_sha
assert json.loads(review.read_text())=={{'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R7','classification':'EXPLORATORY_NOT_ACCEPTANCE','manifestSha256':manifest_sha,'runnerSha256':runner_sha}}
os.environ['C0_R7_EXTERNAL_MANIFEST_SHA256']=manifest_sha
os.environ['C0_R7_EXTERNAL_REVIEW_SHA256']=review_sha
sys.argv=[str(runner),'--bootstrap-check']
exec(compile(program,str(runner),'exec'),{{'__name__':'__main__','__file__':str(runner)}})
"""
        args=[sys.executable,'-I','-B','-c',code]
    else:
        args=[sys.executable,'-I','-B',str(root/'runner.py'),'--child','/no/such/leaf','0'*64]
    return subprocess.run(args,cwd=root,env=env,text=True,capture_output=True,timeout=10)

def main():
    fixed=sha(ROOT/'MANIFEST.json')
    with tempfile.TemporaryDirectory(prefix='r7-bootstrap-negative-') as temp:
        root=Path(temp)/'package'; shutil.copytree(ROOT,root,symlinks=True)
        review=Path(temp)/'review.json'
        review.write_text(json.dumps({'decision':'ACCEPT','package':'1369-C0-PREIMAGE-REPLAY-R7','classification':'EXPLORATORY_NOT_ACCEPTANCE','manifestSha256':fixed,'runnerSha256':sha(ROOT/'runner.py')}))
        assert attempt(root,fixed,'parent',review).returncode==0
        # A modified helper must not execute its top-level side effect in either mode.
        helper=root/'guard_logic.py'; marker=Path(temp)/'helper-executed'
        original=helper.read_bytes(); helper.write_bytes((f"open({str(marker)!r},'w').write('BAD')\n").encode()+original)
        for mode in ('parent','child'):
            result=attempt(root,fixed,mode,review)
            assert result.returncode!=0 and not marker.exists() and 'inventory mismatch' in result.stderr, (mode,result.stderr)
        helper.write_bytes(original)
        # Unlisted stdlib shadow must be rejected before its top-level marker executes.
        shadow=root/'argparse.py'; shadow_marker=Path(temp)/'argparse-executed'
        shadow.write_text(f"open({str(shadow_marker)!r},'w').write('BAD')\n")
        for mode in ('parent','child'):
            result=attempt(root,fixed,mode,review)
            assert result.returncode!=0 and not shadow_marker.exists() and 'inventory mismatch' in result.stderr, (mode,result.stderr)
        shadow.unlink()
        # Paired self-consistent runner+manifest edits remain outside fixed external authority.
        runner=root/'runner.py'; runner.write_bytes(runner.read_bytes()+b'\n# paired changed runner\n')
        m=json.loads((root/'MANIFEST.json').read_text()); new=sha(runner)
        m['runnerSha256']=new; m['packageFiles']['runner.py']=new
        m['objectInventory']['runner.py']['sha256']=new
        (root/'MANIFEST.json').write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
        for mode in ('parent','child'):
            result=attempt(root,fixed,mode,review)
            assert result.returncode!=0 and (mode=='parent' or 'external manifest pin mismatch' in result.stderr), (mode,result.stderr)
        # An added nested file or directory symlink is an exact-membership failure.
        shutil.rmtree(root); shutil.copytree(ROOT,root,symlinks=True)
        extra=root/'unlisted'; extra.mkdir(); (extra/'x').write_text('x')
        assert attempt(root,fixed,'parent',review).returncode!=0
        shutil.rmtree(extra); extra.symlink_to(Path(temp),target_is_directory=True)
        assert attempt(root,fixed,'child',review).returncode!=0
    print('BOOTSTRAP_NEGATIVE_PASS: changed helper and argparse shadow before parent/child import; paired drift; extras')

if __name__=='__main__':main()
