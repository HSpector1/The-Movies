import { defineConfig } from 'vitest/config'

const cacheDir = process.env.B_ONLY_RED_R1_CACHE_DIR
if (!cacheDir) throw new Error('STOP: isolated B-only RED cache path missing')
export default defineConfig({
  cacheDir,
  test: {
    environment: 'node',
    include: ['tests/b-only-episode-red.test.ts', 'tests/b-only-save-red.test.ts'],
    fileParallelism: false,
    maxWorkers: 1,
    minWorkers: 1,
    testTimeout: 180_000,
  },
})
