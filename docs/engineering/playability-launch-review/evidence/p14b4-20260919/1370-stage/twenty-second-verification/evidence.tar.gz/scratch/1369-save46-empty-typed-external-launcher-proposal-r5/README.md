# Save46 empty typed external launcher r5

Scratch-only external launcher for the versioned r6 direct package, with the genuine contract helper as a fourth manifest-pinned overlay. The reviewed E0G 197-file source map, pinned runtime and dependency snapshot, isolated cache, clean published HEAD and source/copy-tree guards remain required. No child runs before independent static review and exact external caller pins.
