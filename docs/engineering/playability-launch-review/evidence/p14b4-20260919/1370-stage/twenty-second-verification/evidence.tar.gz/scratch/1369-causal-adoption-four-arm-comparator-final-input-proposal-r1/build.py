import hashlib,json,pathlib
S=pathlib.Path('/Users/zacheryspector/studio-scratch')
P=S/'1369-causal-adoption-four-arm-comparator-proposal-r3'
OUT=S/'1369-causal-adoption-four-arm-comparator-final-input-proposal-r1'
REVIEW=S/'1369-causal-adoption-four-arm-comparator-independent-review-r3/REVIEW.md'
RECEIPT=S/'1369-causal-adoption-four-arm-comparator-independent-review-r3/RECEIPT.json'
EXPECTED_REVIEW='01c2e603c6668d2eb2e6bb29d8982056806e3647cda9720e764d67941ce4c2a6'
EXPECTED_PACKAGE='3e187387ad8e2b440b00edcf5a878295606dbe2607aab8ba1d1b13aac8c20cf8'
EXPECTED_BOOTSTRAP='e16a75c8a4bb97bc54c9bcb82141091ea0e49271e6478f7ab6e92c2a94f1e429'
EXPECTED_COMPARATOR='44de569415c778b87517d15dbc8d1187053c33523446308a0e74628360510e9b'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def save(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
for path,pin in ((REVIEW,EXPECTED_REVIEW),(P/'MANIFEST.json',EXPECTED_PACKAGE),(P/'bootstrap.py',EXPECTED_BOOTSTRAP),(P/'compare.py',EXPECTED_COMPARATOR)):
 require(sha(path)==pin,str(path)+' changed')
static=json.loads(RECEIPT.read_bytes());require(static['decision']=='ACCEPT_STATIC_ONLY' and static['reviewSha256']==EXPECTED_REVIEW and static['packageManifestSha256']==EXPECTED_PACKAGE,'comparator static review binding')
source=S/'1369-causal-adoption-exploratory-proposal-r5';require(sha(source/'MANIFEST.json')=='d78758c1cc4b9d10582b13b5c67a76a1f65de15aa18f2bcbe8f4658ff25688ae','source manifest')
require(sha(source/'runner/run.py')=='1f1edf7602c852afaac30101c02d52259b2941c9893e523936d412ca74a05c36','source runner')
input_doc=json.loads((P/'INPUT-TEMPLATE.json').read_bytes())
pins=json.loads((P/'FINAL-PINS-TEMPLATE.json').read_bytes())
require(set(input_doc['arms'])==set(pins['audits'])=={'C0G','F6G','AG','ABG'},'four roles')
require((input_doc['route'],input_doc['classification'],input_doc['seed'],input_doc['horizon'],input_doc['head'])==('1369-CAUSAL-ADOPTION-CLEAN-720-750-R5','EXPLORATORY_NOT_ACCEPTANCE','p13-public-commercial-adoption',416,'fad9fb1a8c18de813bb8ad5fac371130736b1b30'),'route')
rows={}
for arm,spec in input_doc['arms'].items():
 leaf=pathlib.Path(spec['leaf']);r=leaf/'RESULT.json';d=leaf/'data.json';a=pins['audits'][arm];rp=pathlib.Path(a['receiptPath']);rv=pathlib.Path(a['reviewPath'])
 require(leaf.parent==S/'1369-causal-adoption-exploratory-recorded-runs-r5','run path')
 require(sha(r)==spec['resultSha256'] and sha(d)==spec['dataSha256'],arm+': result/data')
 require(sha(rp)==a['receiptSha256'] and sha(rv)==a['reviewSha256'],arm+': independent receipt/review')
 receipt=json.loads(rp.read_bytes());result=json.loads(r.read_bytes());data=json.loads(d.read_bytes());binding=json.loads((leaf/'binding.json').read_bytes())
 require(receipt['schema']==a['receiptSchema'] and receipt['decision']=='ACCEPT_DIAGNOSTIC_ONLY' and receipt['resultSha256']==spec['resultSha256'] and receipt['dataSha256']==spec['dataSha256'] and receipt['reviewSha256']==a['reviewSha256'],arm+': audit schema/binding')
 require(receipt['resultPath']==str(r) and spec['resultSha256'] in rv.read_text(),arm+': review result identity')
 require(result['pins']['publicationHead']==input_doc['head'] and result['route']==data['route']==binding['route']==input_doc['route'] and result['classification']==data['classification']==binding['classification']==input_doc['classification'],arm+': historical source/route')
 require(result['actualChildExit']==result['recorderChildExit']==0 and result['timedOut'] is False and result['allGuardsExact'] is True and result['processGroup']['cleanupVerified'] is True,arm+': clean outcome')
 require((binding['probeTestSeconds'],binding['outerCapSeconds'])==(720,750) and data['horizon']==len(data['weekly'])==416 and len(result['artifacts'])==14,arm+': wall/horizon/artifact count')
 require(data['originalPins']==json.loads((S/'1369-causal-adoption-exploratory-recorded-runs-r5/C0G-clean-adoption-clean-r1/data.json').read_bytes())['originalPins'],arm+': protected original pins')
 rows[arm]={'leaf':str(leaf),'resultSha256':spec['resultSha256'],'dataSha256':spec['dataSha256'],'receiptSha256':a['receiptSha256'],'reviewSha256':a['reviewSha256'],'rows':len(data['rows']),'weeks':len(data['weekly']),'artifacts':len(result['artifacts'])}
save(OUT/'FINAL-INPUT.json',input_doc)
pins['inputPath']=str(OUT/'FINAL-INPUT.json');pins['inputSha256']=sha(OUT/'FINAL-INPUT.json');pins['comparatorSha256']=EXPECTED_COMPARATOR;pins['packageManifestSha256']=EXPECTED_PACKAGE
require(pins['status']=='PENDING_INDEPENDENT_FINAL_REVIEW','must not self-issue authority')
save(OUT/'FINAL-PINS.candidate.json',pins)
report={'status':'BUILD_ONLY_PENDING_INDEPENDENT_FINAL_REVIEW','comparatorStaticReviewSha256':EXPECTED_REVIEW,'comparatorStaticReceiptSha256':sha(RECEIPT),'packageManifestSha256':EXPECTED_PACKAGE,'bootstrapSha256':EXPECTED_BOOTSTRAP,'comparatorSha256':EXPECTED_COMPARATOR,'finalInputPath':str(OUT/'FINAL-INPUT.json'),'finalInputSha256':pins['inputSha256'],'candidatePinsPath':str(OUT/'FINAL-PINS.candidate.json'),'candidatePinsSha256':sha(OUT/'FINAL-PINS.candidate.json'),'requiredFixedPinsPath':str(S/'1369-causal-adoption-four-arm-comparator-final-pins-r1/FINAL-PINS.json'),'arms':rows,'interpretation':'Descriptive adoption four-arm exploratory 720/750 only; no original 300/330 acceptance, B-alone attribution, protected repin, 1363 closure, or gameplay acceptance.'}
save(OUT/'BUILD-REPORT.json',report)
print(json.dumps(report,indent=2))
