"""Disposable copied-tree probes; no child process or recorded lane."""
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile

import launcher
import sys
sys.path.insert(0, str(launcher.PACKAGE))
from runtime_guard import verify_runtime
sys.path.pop(0)

package = launcher.PACKAGE
sys.path.insert(0, str(package))
spec = importlib.util.spec_from_file_location('save46_probe_runner_static', package / 'runner.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
sys.path.pop(0)

with tempfile.TemporaryDirectory(prefix='save46-r3-tree-probes-', dir='/Users/zacheryspector/studio-scratch') as td:
    tree = Path(td) / 'tree'
    shutil.copytree(runner.SOURCE, tree, symlinks=True)
    for rel in ('tests/save46-finance-direct.test.ts', 'tests/contracts/_contractFixtures.ts', 'tsconfig.probe.json', 'vitest.probe.config.ts'):
        dst = tree / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(package / rel, dst)
    original = runner.verify_execution_tree(tree)
    results = {'clean': original}
    def reject(name, edit, undo):
        edit()
        try:
            try: runner.verify_execution_tree(tree)
            except (AssertionError, ValueError) as error: results[name] = type(error).__name__
            else: raise AssertionError('mutation admitted: ' + name)
        finally: undo()
        assert runner.verify_execution_tree(tree) == original, name + ' restore'
    file = tree / 'tsconfig.probe.json'; saved = file.read_bytes()
    reject('transientCopiedFileMutation', lambda: file.write_bytes(saved + b' '), lambda: file.write_bytes(saved))
    extra = tree / 'rogue.txt'
    reject('extraFile', lambda: extra.write_text('rogue'), extra.unlink)
    directory = tree / 'rogue-empty'
    reject('extraDirectory', directory.mkdir, directory.rmdir)
    link = tree / 'node_modules'; target = link.readlink()
    reject('dependencySymlink', lambda: (link.unlink(), link.symlink_to('/tmp')), lambda: (link.unlink(), link.symlink_to(target)))
    link2 = tree / 'extra-link'
    reject('extraSymlink', lambda: link2.symlink_to('/tmp'), link2.unlink)
print(json.dumps({'status':'STATIC_PASS','cases':results,'childrenLaunched':False}, sort_keys=True))

# Disposable runtime snapshot: mutate executable and bytes behind an unchanged link.
import hashlib
import os
from runtime_guard import verify_runtime
with tempfile.TemporaryDirectory(prefix='save46-r4-runtime-probes-', dir='/Users/zacheryspector/studio-scratch') as td:
    base = Path(td); deps = base/'deps'; deps.mkdir(); (deps/'typescript/bin').mkdir(parents=True); (deps/'vitest').mkdir()
    node = base/'node'; node.write_bytes(b'node-reviewed')
    tsc = deps/'typescript/bin/tsc'; tsc.write_bytes(b'tsc-reviewed')
    vitest = deps/'vitest/vitest.mjs'; vitest.write_bytes(b'vitest-reviewed')
    (deps/'unchanged-link').symlink_to('typescript/bin/tsc')
    h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    inventory = {'schema':'1369-save46-dependencies-r2','excludedCache':'.vite','root':str(deps),
        'directories':['typescript','typescript/bin','vitest'],
        'files':{'typescript/bin/tsc':h(tsc),'vitest/vitest.mjs':h(vitest)},
        'links':{'unchanged-link':'typescript/bin/tsc'}}
    (base/'DEPENDENCIES.json').write_text(json.dumps(inventory))
    runtime = {'nodePath':str(node),'nodeSha256':h(node),'typescriptPath':str(tsc),
        'typescriptSha256':h(tsc),'vitestPath':str(vitest),'vitestSha256':h(vitest),
        'dependencyManifestSha256':h(base/'DEPENDENCIES.json')}
    manifest = {'runtime':runtime}; original = verify_runtime(base,manifest)
    runtime_results = {'clean':original}
    for name,path in [('nodeExecutable',node),('typescriptBehindUnchangedLink',tsc),('vitestBehindUnchangedLink',vitest)]:
        prior=path.read_bytes(); path.write_bytes(prior+b'!')
        try:
            try: verify_runtime(base,manifest)
            except AssertionError: runtime_results[name]='REJECT'
            else: raise AssertionError('runtime mutation admitted: '+name)
        finally: path.write_bytes(prior)
        assert verify_runtime(base,manifest)==original
    assert os.readlink(deps/'unchanged-link')=='typescript/bin/tsc'
    cache=(deps/'.vite/vitest'); cache.mkdir(parents=True); result=cache/'results.json'; result.write_text('first')
    assert verify_runtime(base,manifest)==original
    result.write_text('changed cache')
    assert verify_runtime(base,manifest)==original
    runtime_results['isolatedCacheMutation']='IGNORED_AS_OUTPUT'
print(json.dumps({'status':'STATIC_PASS','runtimeCases':runtime_results,'childrenLaunched':False},sort_keys=True))
