# Independent audit — recorded adoption four-arm comparator r3

**Decision: ACCEPT_DESCRIPTIVE_ONLY.** The recorded output `/Users/zacheryspector/studio-scratch/1369-causal-adoption-four-arm-comparator-recorded-r1` rehashes to SHA-256 `8441494c981df8babe121c7973e20a81394f5f67c5ea7fbd3bd34cdd5693ee72`. It reports `DESCRIPTIVE_FOUR_CLEAN_ONLY` for the adoption seed `p13-public-commercial-adoption`, 416 weeks, route `1369-CAUSAL-ADOPTION-CLEAN-720-750-R5`. Its bound input remains `EXPLORATORY_NOT_ACCEPTANCE`.

I independently rehashed the final input `239062fb79ec7849980e3597ef89a0ce719590ba83408746b74bac69c8b79bb0`, fixed external pins `31f757ec04b8f98bba1fba75d1af55ec83ae9d8462a6f8e2904cb04d59f91505`, comparator package manifest `3e187387ad8e2b440b00edcf5a878295606dbe2607aab8ba1d1b13aac8c20cf8`, bootstrap `e16a75c8a4bb97bc54c9bcb82141091ea0e49271e6478f7ab6e92c2a94f1e429`, comparator `44de569415c778b87517d15dbc8d1187053c33523446308a0e74628360510e9b`, static package review/receipt, and separately issued final-input review/receipt. The output's four admission paths and hashes equal the fixed external pins. I rehashed each arm's RESULT/data bytes and all **14** supporting artifacts, checked each 416-week ordered series, zero actual child/recorder exit, no timeout, and verified cleanup. The output's original/actual/comparison pins equal the underlying data files. The rows are C0G 48, F6G 48, AG 48, ABG 42.

I independently rebuilt stable row groups from each underlying data file using `(week, talentId, subjectStudioId, source-order occurrence)`. Every reported paired/one-sided key, occurrence, source ordinal and equality flag matches. I also rescanned each full weekly record for first differences and checked the first differing source ordinal in each reported final collection:

| Edge | First recorded weekly change | Rows | What the output establishes |
|---|---:|---|---|
| C0G→F6G | none through 416 | 48 paired, all equal; no one-sided row | No measured difference on this seed. |
| F6G→AG | week 215 (`digest`; `inputDigest` at 216; new industry receipt at 265) | 48 paired, all equal; no one-sided row | A+G changes recorded state/receipts without changing this settlement row set. |
| AG→ABG | week 1 (`digest`, `inputDigest`, `owners`) | 42 paired, 24 equal; six AG-only, zero ABG-only | B+Save46/C-plumbing bundle changes this route; it is **not** a B-alone effect. |

The four original protected content pin comparisons—settlement, receipts, employment and takes—remain false in every arm. ABG also fails original row and decline counts. The comparator does not repin them. The week-215 and week-1 observations locate recorded differences; they do not by themselves prove which hunk caused a decision. The output explicitly prohibits individual B attribution, observed acceptance and 1363 closure. This audit likewise does not substitute exploratory 720/750 evidence for the original 300/330 admission or prove gameplay acceptance.

No tracked file, source package or clean leaf was changed, and no test, simulation or comparator rerun was performed in this audit.
