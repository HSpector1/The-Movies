import { defineConfig } from 'vitest/config'
const cacheDir = process.env.SAVE46_EMPTY_R5_CACHE_DIR
if (!cacheDir) throw new Error('STOP: isolated Vitest cache path missing')
export default defineConfig({ cacheDir, test: { environment: 'node', include: ['tests/save46-finance-direct.test.ts'], fileParallelism: false, maxWorkers: 1, minWorkers: 1, testTimeout: 30_000 } })
