# r5 external launcher construction

This fresh launcher binds the r6 package/runner manifest, ten package members plus manifest, the `tests/contracts` package directory, an output leaf distinct from failed r5 and a new independent review identity. Its static mode authenticates package bytes without executing target code; its execution mode still requires isolated Python, external SHA/review/HEAD pins, then snapshots authenticated bytes before import. No typecheck or Vitest run is claimed.
