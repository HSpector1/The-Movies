# Save46 empty typed direct probe r6

Versioned repair of recorded r5 sourceTypes failure: add the genuine `tests/contracts/_contractFixtures.ts` (SHA-256 `7554a6b11f0756c7cd286a7732ab888757a129fe0d9f10657c93c4d214f10de2`) as a fourth pinned copied-tree overlay. The reviewed 197-file E0G source map stays unchanged. Four week-51/52 direct cases remain gated by sourceTypes, fixtureTypes, direct, strict byte/runtime/HEAD/source guards and isolated Vitest cache. Static proposal only; no child has run.
