# Save46 r6 fresh exclusive external launcher

Scratch-only launcher proposal for a fresh exclusive-lane rerun of the unchanged r6 direct package. The prior r5 launcher/result remains preserved as qualified functional evidence under the concurrent-typecheck addendum; this launcher has a new absolute path, review receipt identity and unused output leaf. Package, source, tests, runtime/dependency inventory, runner and copied-tree guards are unchanged. Static review is required before execution.
