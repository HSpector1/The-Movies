#!/usr/bin/env python3
"""Externally pin and snapshot the Save46 empty direct probe before loading package code."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import types

LAUNCHER_PATH = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-typed-external-launcher-proposal-r4/launcher.py')
PACKAGE = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-typed-probe-r5')
MANIFEST_SHA = '577cfa16003c63ff6e72997e171586b43d7add6251e5c9f933caef0c23dbcae0'
RUNNER_SHA = 'a15546ba79ff28e4b14442dd4923cd68dde331ea9f28776789d3ce573901fa11'
REVIEW = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-control-independent-review-r1/REVIEW.md')
REVIEW_SHA = 'acbb49cf33df1901a82e3461f489a8e8d5bc4d96d012cb7626b6548265f05764'
SOURCE_MANIFEST = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-control-proposal-r1/SOURCE-SHA256.json')
SOURCE_MANIFEST_SHA = '21df0988f808b4468ea19866949d354d29c49a1f9556ab87e9add1396289ab8d'
RUNTIME_PINS = {
    'nodePath': '/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node',
    'nodeSha256': 'afea68f4c6280aa32707b2c037084931114a72b5c65412371244e060390c1fc6',
    'typescriptPath': '/Users/zacheryspector/The-Movies-headless-program/node_modules/typescript/bin/tsc',
    'typescriptSha256': '8d5fa5bd883fec0979fc2004f1fe1d99aef40570155d550eadc0b03b55513bf0',
    'vitestPath': '/Users/zacheryspector/The-Movies-headless-program/node_modules/vitest/vitest.mjs',
    'vitestSha256': '39db22f579acf5639bbb17a261408debbde03f4692c0c439e77e7f13aeba74d6',
    'dependencyManifestSha256': 'db6b52e625de4a4a8ca2d7626dd3d1bddd09ff5166aae17b5fcbb893a4557a37',
}
EXPECTED_FILES = frozenset({'MANIFEST.json','README.md','REPORT.md','runner.py','self_check.py','runtime_guard.py','DEPENDENCIES.json',
                            'tests/save46-finance-direct.test.ts','tsconfig.probe.json','vitest.probe.config.ts'})
OUT = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-typed-external-launcher-recorded-r4')
EXTERNAL_REVIEW = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-typed-external-launcher-independent-review-r4/RECEIPT.json')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError('STOP: ' + message)


def verify(package, require_pinned_path=True):
    """Read every package byte once; return only reviewed bytes, never package code objects."""
    package = Path(package)
    require(package.is_absolute() and not package.is_symlink() and package.is_dir(), 'package path')
    if require_pinned_path:
        require(package == PACKAGE, 'package path differs from reviewed absolute path')
    require(REVIEW.is_file() and digest(REVIEW.read_bytes()) == REVIEW_SHA, 'independent source review')
    require(SOURCE_MANIFEST.is_file() and digest(SOURCE_MANIFEST.read_bytes()) == SOURCE_MANIFEST_SHA,
            'reviewed source manifest')
    found = {}
    directories = set()
    for root, dirs, files in os.walk(package, followlinks=False):
        parent = Path(root)
        directories.add(parent.relative_to(package).as_posix())
        for name in dirs:
            entry = parent / name
            require(not entry.is_symlink() and entry.is_dir(), 'package symlink/directory')
        for name in files:
            entry = parent / name
            mode = entry.lstat().st_mode
            require(stat.S_ISREG(mode) and entry.stat().st_nlink == 1, 'package symlink/hardlink/nonregular')
            relative = entry.relative_to(package).as_posix()
            found[relative] = entry.read_bytes()
    require(directories == {'.', 'tests'}, 'exact package directory membership')
    require(set(found) == EXPECTED_FILES, 'exact package membership')
    require(digest(found['MANIFEST.json']) == MANIFEST_SHA, 'external manifest SHA-256')
    require(digest(found['runner.py']) == RUNNER_SHA, 'external runner SHA-256')
    manifest = json.loads(found['MANIFEST.json'])
    require(manifest['schema'] == '1369-save46-empty-typed-probe-r5', 'schema')
    require(manifest['bOnlyProjection'] == 'STOP', 'B-only attribution boundary')
    require(manifest['independentSourceReviewSha256'] == REVIEW_SHA, 'source review manifest pin')
    require(manifest['sourceManifestSha256'] == SOURCE_MANIFEST_SHA, 'source manifest pin')
    require(set(manifest['packageFiles']) == EXPECTED_FILES - {'MANIFEST.json'}, 'manifest file roster')
    runtime = manifest['runtime']
    require(runtime == RUNTIME_PINS, 'externally pinned absolute runtime/dependency snapshot')
    for name, expected_sha in manifest['packageFiles'].items():
        require(digest(found[name]) == expected_sha, 'package member SHA-256: ' + name)
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--static-check', action='store_true')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--head')
    args = parser.parse_args()
    require(args.static_check != args.execute, 'choose exactly one mode')
    verified = verify(PACKAGE)
    if args.static_check:
        print(json.dumps({'status':'STATIC_PASS','package':str(PACKAGE),'manifestSha256':MANIFEST_SHA,
                          'runnerSha256':RUNNER_SHA,'members':len(verified),'bOnlyProjection':'STOP'},sort_keys=True))
        return
    require(sys.flags.isolated == 1 and Path(__file__).resolve() == LAUNCHER_PATH, 'isolated reviewed launcher path required')
    self_pin = os.environ.get('SAVE46_R4_EXTERNAL_LAUNCHER_SHA256', '')
    review_pin = os.environ.get('SAVE46_R4_EXTERNAL_REVIEW_SHA256', '')
    require(len(self_pin) == len(review_pin) == 64 and digest(Path(__file__).read_bytes()) == self_pin, 'external launcher SHA-256')
    require(EXTERNAL_REVIEW.is_file() and digest(EXTERNAL_REVIEW.read_bytes()) == review_pin, 'external launcher review SHA-256')
    require(json.loads(EXTERNAL_REVIEW.read_text()) == {'decision':'ACCEPT','package':'1369-SAVE46-EMPTY-TYPED-EXTERNAL-LAUNCHER-R4','launcherSha256':self_pin,'packageManifestSha256':MANIFEST_SHA}, 'independent launcher review identity')
    require(args.head is not None and len(args.head) == 40 and all(c in '0123456789abcdef' for c in args.head), 'externally bound publication HEAD')
    os.environ['SAVE46_EMPTY_R5_EXPECTED_HEAD'] = args.head
    require(not OUT.exists(), 'output already exists')
    OUT.mkdir(parents=True)
    snapshot = OUT / 'package'
    snapshot.mkdir()
    for name, data in verified.items():
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    require(verify_snapshot(snapshot, verified), 'snapshot differs from reviewed bytes')
    # Source code is loaded only after the caller authenticates and copies exact bytes.
    runtime = types.ModuleType('runtime_guard')
    runtime.__file__ = str(snapshot / 'runtime_guard.py')
    sys.modules['runtime_guard'] = runtime
    exec(compile(verified['runtime_guard.py'], runtime.__file__, 'exec'), runtime.__dict__)
    helper = types.ModuleType('self_check')
    helper.__file__ = str(snapshot / 'self_check.py')
    sys.modules['self_check'] = helper
    exec(compile(verified['self_check.py'], helper.__file__, 'exec'), helper.__dict__)
    main_globals = {'__name__':'__main__','__file__':str(snapshot / 'runner.py'), '__package__':None}
    sys.argv = [str(snapshot / 'runner.py'), '--execute', '--manifest-sha256', MANIFEST_SHA,
                '--self-runner-sha256', RUNNER_SHA]
    exec(compile(verified['runner.py'], main_globals['__file__'], 'exec'), main_globals)


def verify_snapshot(snapshot, verified):
    actual = {}
    directories = set()
    for path in snapshot.rglob('*'):
        if path.is_dir() and not path.is_symlink():
            directories.add(path.relative_to(snapshot).as_posix())
        elif path.is_file():
            if path.is_symlink() or path.stat().st_nlink != 1:
                return False
            actual[path.relative_to(snapshot).as_posix()] = path.read_bytes()
        elif path.is_symlink():
            return False
    return actual == verified and directories == {'tests'}


if __name__ == '__main__':
    main()
