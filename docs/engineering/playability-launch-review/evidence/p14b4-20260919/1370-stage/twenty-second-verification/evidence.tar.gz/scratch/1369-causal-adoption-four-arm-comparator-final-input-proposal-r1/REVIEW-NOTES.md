# Adoption four-arm final-input proposal — pending independent final review

The frozen `FINAL-INPUT.json` names C0G, F6G, AG and ABG exact exploratory adoption r5 clean leaves and RESULT/data hashes. The builder rehashed all four independently accepted clean receipt/review pairs, source runner/manifest, r3 comparator package and static review, and confirmed route, seed, 416 weeks, 720/750 wall bounds, historical publication HEAD, 14 listed artifacts and zero child/recorder exits. `BUILD-REPORT.json` records those inputs and their hashes.

`FINAL-PINS.candidate.json` is deliberately `PENDING_INDEPENDENT_FINAL_REVIEW`; the comparator rejects it. The fixed authority path expected by comparator r3 is `/Users/zacheryspector/studio-scratch/1369-causal-adoption-four-arm-comparator-final-pins-r1/FINAL-PINS.json`, not created by this builder. A different reviewer must independently inspect the full input, four audits, source identity and artifact graph, then issue that file with `ACCEPT_FOUR_CLEAN_INPUT` if warranted and publish a literal externally pinned `python3 -I -B -c` command. This build did not execute the comparator.

Any later report remains a description of the exploratory 720/750 adoption route. It cannot retroactively pass original 300/330, make a B-alone claim from AG→ABG, repin protected digests, close 1363, or establish gameplay acceptance.

Lesson: freeze the exact four result/data/review identities in one input while keeping final acceptance authority outside the builder's package.
