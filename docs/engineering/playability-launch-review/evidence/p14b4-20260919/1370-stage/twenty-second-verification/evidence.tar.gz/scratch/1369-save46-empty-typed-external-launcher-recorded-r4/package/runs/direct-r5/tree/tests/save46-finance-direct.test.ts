import { describe, expect, it } from 'vitest'
import { moveRivalMoney, newFinancePeriod, RIVAL_MONEY_KINDS } from '../src/core/hollywood.js'
import type { RivalAccount } from '../src/core/hollywoodTypes.js'

function account(era: 'live' | 'research-v27'): RivalAccount {
  return {
    openingBalance: 100,
    openingBasis: 'before-capacity-and-signing',
    cash: 100,
    periods: [newFinancePeriod(51, 100, era)],
  }
}

function roster(era: 'live' | 'research-v27'): string[] {
  return RIVAL_MONEY_KINDS.filter(kind => era === 'live' ||
    (kind !== 'termination' && kind !== 'facilityDemolitionRefund')).slice().sort()
}

describe('explicit finance-era time boundaries', () => {
  for (const era of ['research-v27', 'live'] as const) {
    it(`${era}: same-year and next-year researchCapacity debits conserve cash and exact keys`, () => {
      const row = account(era)
      moveRivalMoney(row, 'researchCapacity', -7, 51, era)
      expect(row.cash).toBe(93)
      expect(row.periods).toHaveLength(1)
      expect(row.periods[0]).toMatchObject({ fromWeek: 51, throughWeek: 51, opening: 100, closing: 93 })
      expect(row.periods[0]!.movements.researchCapacity).toBe(-7)
      expect(Object.keys(row.periods[0]!.movements).sort()).toEqual(roster(era))

      moveRivalMoney(row, 'researchCapacity', -11, 52, era)
      expect(row.cash).toBe(82)
      expect(row.periods).toHaveLength(2)
      expect(row.periods[0]).toMatchObject({ fromWeek: 51, throughWeek: 51, opening: 100, closing: 93 })
      expect(row.periods[1]).toMatchObject({ fromWeek: 52, throughWeek: 52, opening: 93, closing: 82 })
      expect(row.periods[1]!.movements.researchCapacity).toBe(-11)
      expect(Object.keys(row.periods[1]!.movements).sort()).toEqual(roster(era))
      expect(row.periods.every(p => Number.isFinite(p.opening) && Number.isFinite(p.closing) &&
        Object.values(p.movements).every(Number.isFinite))).toBe(true)
      expect(row.periods.reduce((total, p) => total + Object.values(p.movements).reduce((a, b) => a + b, 0), 100)).toBe(82)
    })
  }

  it('historical V27 refuses later kinds without mutation', () => {
    const row = account('research-v27')
    const before = structuredClone(row)
    expect(() => moveRivalMoney(row, 'facilityDemolitionRefund', 1, 51, 'research-v27')).toThrow()
    expect(() => moveRivalMoney(row, 'termination', -1, 51, 'research-v27')).toThrow()
    expect(row).toEqual(before)
  })

  it('an existing same-year V27 period must have its historical exact roster', () => {
    const row = account('research-v27')
    row.periods[0]!.movements.facilityDemolitionRefund = 0
    const before = structuredClone(row)
    expect(() => moveRivalMoney(row, 'researchCapacity', -1, 51, 'research-v27')).toThrow()
    expect(row).toEqual(before)
  })
})
