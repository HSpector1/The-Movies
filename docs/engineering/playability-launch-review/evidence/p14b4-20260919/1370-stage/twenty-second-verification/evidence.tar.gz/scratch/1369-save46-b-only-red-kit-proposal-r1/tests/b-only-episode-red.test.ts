import { describe, expect, it } from 'vitest'
import { p13aGeneratedStudio } from '../src/harness/p13a/fixtures.js'
import { tick } from '../src/core/tick.js'
import { terminationCost } from '../src/core/employment.js'
import type { GameState } from '../src/core/types.js'

// A public generated world and real weekly ticks supply all dated facts.
// This is an intentionally failing E0G consumer test: E0G cannot enter B.
let week93: GameState | undefined
function witness(): GameState {
  if (week93 === undefined) {
    let state = p13aGeneratedStudio('p13a-core-causal-01')
    while (state.market.tick < 93) state = tick(state)
    week93 = state
  }
  return week93
}
function fourthRival(state: GameState): string {
  const identity = state.hollywood!.identities.find(row => row.role === 'rival' && row.row === 4)
  if (!identity) throw new Error('missing fourth generated rival')
  return identity.studioId
}

describe('B cost cutting through the public weekly world', () => {
  it('enters after a scheduled cash-closed decision and retains its dated episode', () => {
    const state = witness()
    const studioId = fourthRival(state)
    const business = state.hollywood!.businesses.find(row => row.studioId === studioId)!
    expect(business.costCutting).toEqual({ version: 1, since: 91 })
    expect(business.productions).toHaveLength(0)
    expect(business.runs).toHaveLength(0)
    expect(business.account.periods.every(p => p.movements.facilityDemolitionRefund === 0)).toBe(true)
  })

  it('ends real contracts with exact charge and receipt, without a post-episode hire or renewal', () => {
    const state = witness()
    const studioId = fourthRival(state)
    const h = state.hollywood!
    const business = h.businesses.find(row => row.studioId === studioId)!
    expect(business.costCutting.since).toBe(91)
    const ends = h.receipts.filter(r => r.kind === 'employment' && r.studioId === studioId &&
      r.reason === 'termination' && r.week === 92)
    expect(ends.length).toBeGreaterThan(0)
    const allEnds = h.receipts.filter(r => r.kind === 'employment' && r.studioId === studioId &&
      r.reason === 'termination')
    const charged = allEnds.reduce((sum, r) => {
      if (r.kind !== 'employment') return sum
      const interval = h.employment.find(e => e.contractId === r.contractId)
      expect(interval).toBeDefined()
      expect(interval!.endedWeek).toBe(r.week)
      return sum + terminationCost(interval!.terms, r.week)
    }, 0)
    expect(business.account.periods.reduce((sum, p) => sum + p.movements.termination, 0)).toBe(-charged)
    const newCommitments = h.receipts.filter(r => r.kind === 'employment' && r.studioId === studioId &&
      r.week > business.costCutting.since! && r.reason !== 'termination' && r.reason !== 'expiry')
    expect(newCommitments).toHaveLength(0)
  })

  it('retains physical bodies and has no C receipt or positive refund', () => {
    const state = witness()
    const h = state.hollywood!
    expect(h.receipts.some(r => r.kind === 'facilityDisposed')).toBe(false)
    expect(h.businesses.every(b => b.account.periods.every(p => p.movements.facilityDemolitionRefund === 0))).toBe(true)
    for (const receipt of h.receipts) {
      if (receipt.kind !== 'laboratoryOperational') continue
      const owner = h.businesses.find(b => b.studioId === receipt.studioId)!
      expect(owner.operations.facilities.some(f => f.id === receipt.facilityId)).toBe(true)
    }
  })
})
