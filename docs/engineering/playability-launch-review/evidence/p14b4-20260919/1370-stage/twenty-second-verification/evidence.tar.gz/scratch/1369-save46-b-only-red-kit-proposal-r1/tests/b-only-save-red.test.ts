import { describe, expect, it } from 'vitest'
import { p13aGeneratedStudio } from '../src/harness/p13a/fixtures.js'
import { tick } from '../src/core/tick.js'
import { convertV46ToV45, loadSave, makeSave, migrateToLive, stableStringify, validateSaveV46 } from '../src/core/save.js'
import type { GameState } from '../src/core/types.js'

let week93: GameState | undefined
function witness(): GameState {
  if (week93 === undefined) {
    let state = p13aGeneratedStudio('p13a-core-causal-01')
    while (state.market.tick < 93) state = tick(state)
    week93 = state
  }
  return week93
}

describe('B episode authority through current Save46 consumers', () => {
  it('saves, validates, loads and resaves an actual non-null episode without erasing it', () => {
    const state = witness()
    const episode = state.hollywood!.businesses.find(b => b.costCutting.since !== null)
    expect(episode).toBeDefined() // RED on E0G before any migration assertion.
    const saved = makeSave(state)
    expect(validateSaveV46(saved)).toEqual(saved)
    const loaded = migrateToLive(loadSave(JSON.parse(stableStringify(saved))))
    expect(stableStringify(makeSave(loaded.state))).toBe(stableStringify(saved))
    expect(loaded.state.hollywood!.businesses.find(b => b.studioId === episode!.studioId)!.costCutting.since)
      .toBe(episode!.costCutting.since)
  })

  it('refuses to erase a real B episode in a V46 to V45 downgrade', () => {
    const saved = makeSave(witness())
    expect(saved.state.hollywood!.businesses.some(b => b.costCutting.since !== null)).toBe(true)
    const before = stableStringify(saved)
    expect(() => convertV46ToV45(saved)).toThrow(/costCutting\.since/)
    expect(stableStringify(saved)).toBe(before)
  })

  it('keeps zero refund and refuses C disposal even with an actual B episode', () => {
    const saved = makeSave(witness())
    expect(saved.state.hollywood!.businesses.some(b => b.costCutting.since !== null)).toBe(true)
    const before = stableStringify(saved)
    const refund = structuredClone(saved)
    refund.state.hollywood!.businesses[0]!.account.periods[0]!.movements.facilityDemolitionRefund = 1
    expect(() => validateSaveV46(refund)).toThrow()
    const disposal = structuredClone(saved) as unknown as { state: { hollywood: { receipts: unknown[] } } }
    disposal.state.hollywood.receipts.push({ kind: 'facilityDisposed', eventId: 'forged', week: 92,
      studioId: saved.state.hollywood!.businesses[0]!.studioId, facilityId: 'forged',
      planId: 'forged', blueprintId: 'research-laboratory', refund: 1 })
    expect(() => validateSaveV46(disposal)).toThrow()
    expect(stableStringify(saved)).toBe(before)
  })
})
