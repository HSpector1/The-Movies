"""Static caller-only adversarial probes; never executes package code or direct tests."""
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import launcher

with tempfile.TemporaryDirectory(prefix='save46-external-probes-',dir='/Users/zacheryspector/studio-scratch') as temporary:
    base = Path(temporary)
    cases = {}
    for name in ('clean_copy', 'paired_runner_manifest_tamper', 'extra_file', 'symlink_substitution', 'extra_directory'):
        copy = base / name
        shutil.copytree(launcher.PACKAGE, copy, symlinks=True)
        if name == 'paired_runner_manifest_tamper':
            runner = copy / 'runner.py'
            runner.write_bytes(runner.read_bytes() + b'\n# unreviewed runner\n')
            manifest = json.loads((copy / 'MANIFEST.json').read_text())
            manifest['packageFiles']['runner.py'] = hashlib.sha256(runner.read_bytes()).hexdigest()
            (copy / 'MANIFEST.json').write_text(json.dumps(manifest))
        elif name == 'extra_file':
            (copy / 'EXTRA.txt').write_text('unreviewed')
        elif name == 'symlink_substitution':
            (copy / 'README.md').unlink()
            (copy / 'README.md').symlink_to('/dev/null')
        elif name == 'extra_directory':
            (copy / 'surprise').mkdir()
        try:
            launcher.verify(copy, require_pinned_path=False)
            cases[name] = 'ACCEPT'
        except ValueError as error:
            cases[name] = str(error)
    try:
        launcher.verify(base / 'clean_copy', require_pinned_path=True)
        cases['wrong_package_path'] = 'ACCEPT'
    except ValueError as error:
        cases['wrong_package_path'] = str(error)
assert cases['clean_copy'] == 'ACCEPT'
assert all(cases[name].startswith('STOP: ') for name in cases if name != 'clean_copy')
assert not launcher.OUT.exists()
print(json.dumps({'status':'STATIC_PASS','cases':cases,'packageRunnerLoaded':False,
                  'typesOrDirectTestsRun':False,'outputCreated':False},sort_keys=True))
