#!/usr/bin/env python3
"""Guarded, future typed/direct probe. Execution requires reviewed explicit opt-in."""
import argparse
import hashlib
import json
import os
import stat
import shutil
import signal
import subprocess
import time
from pathlib import Path

from self_check import ROOT, REPO, SOURCE, check, sha
from runtime_guard import verify_runtime


def verify_execution_tree(tree):
    """Hash exact copied execution bytes, directories and the sole dependency link."""
    expected = json.loads((SOURCE.parent / 'SOURCE-SHA256.json').read_text())
    package = json.loads((ROOT / 'MANIFEST.json').read_text())
    overlays = ('tests/save46-finance-direct.test.ts', 'tests/contracts/_contractFixtures.ts', 'tsconfig.probe.json', 'vitest.probe.config.ts')
    for rel in overlays:
        assert rel not in expected, 'STOP: overlay collides with source'
        expected[rel] = package['packageFiles'][rel]
    assert len(expected) == 201, 'STOP: expected copied tree must have 201 regular files'
    expected_dirs = set()
    for rel in expected:
        for parent in Path(rel).parents:
            if parent.as_posix() != '.': expected_dirs.add(parent.as_posix())
    actual_files = {}
    actual_dirs = set()
    actual_links = {}
    for folder, dirs, files in os.walk(tree, followlinks=False):
        base = Path(folder)
        for name in list(dirs):
            item = base / name; rel = item.relative_to(tree).as_posix()
            if item.is_symlink(): actual_links[rel] = os.readlink(item); dirs.remove(name)
            else:
                assert stat.S_ISDIR(item.lstat().st_mode), 'STOP: unexpected tree object'
                actual_dirs.add(rel)
        for name in files:
            item = base / name; rel = item.relative_to(tree).as_posix()
            mode = item.lstat().st_mode
            if stat.S_ISLNK(mode): actual_links[rel] = os.readlink(item)
            else:
                assert stat.S_ISREG(mode) and item.stat().st_nlink == 1, 'STOP: unreviewed tree object: ' + rel
                actual_files[rel] = sha(item)
    assert actual_files == expected, 'STOP: execution file roster/bytes differ'
    assert actual_dirs == expected_dirs, 'STOP: execution directory roster differs'
    assert actual_links == {'node_modules': package['nodeModulesTarget']}, 'STOP: dependency link differs'
    descriptor = {'files': actual_files, 'directories': sorted(actual_dirs), 'links': actual_links}
    return hashlib.sha256(json.dumps(descriptor, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def bounded(command, cwd, seconds, stdout_path, stderr_path, env=None):
    with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
        child = subprocess.Popen(command, cwd=cwd, stdout=out, stderr=err, start_new_session=True, env=env)
        timed_out = False
        try:
            code = child.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
    try:
        os.killpg(child.pid, 0)
        survived = True
    except ProcessLookupError:
        survived = False
    return {'command': command, 'exit': code, 'timedOut': timed_out, 'survivingProcessGroup': survived,
            'stdoutSha256': sha(stdout_path), 'stderrSha256': sha(stderr_path)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--self-runner-sha256', required=True)
    args = parser.parse_args()
    if not args.execute:
        raise SystemExit('STOP: static proposal; use self_check.py before independent runner review')
    if sha(ROOT / 'MANIFEST.json') != args.manifest_sha256:
        raise SystemExit('STOP: manifest differs from external review pin')
    if sha(ROOT / 'runner.py') != args.self_runner_sha256:
        raise SystemExit('STOP: runner differs from external review pin')
    prior = check()
    run = ROOT / 'runs' / 'direct-r6'
    run.mkdir(parents=True, exist_ok=False)
    tree = run / 'tree'
    shutil.copytree(SOURCE, tree, symlinks=True)
    (tree / 'tests' / 'save46-finance-direct.test.ts').write_bytes((ROOT / 'tests/save46-finance-direct.test.ts').read_bytes())
    (tree / 'tests' / 'contracts').mkdir()
    (tree / 'tests' / 'contracts' / '_contractFixtures.ts').write_bytes((ROOT / 'tests/contracts/_contractFixtures.ts').read_bytes())
    for name in ('tsconfig.probe.json', 'vitest.probe.config.ts'):
        (tree / name).write_bytes((ROOT / name).read_bytes())
    executed_tree_sha = verify_execution_tree(tree)
    package_manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    runtime_sha = verify_runtime(ROOT, package_manifest)
    node = package_manifest['runtime']['nodePath']
    tsc = package_manifest['runtime']['typescriptPath']
    result = {'startedUtc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'guardsBefore': prior, 'executedTreeSha256': executed_tree_sha, 'runtimeSha256': runtime_sha, 'steps': {}, 'accepted': False, 'bOnlyProjection': 'STOP'}
    try:
        steps = [
            ('sourceTypes', [node, tsc, '--noEmit', '-p', 'tsconfig.json'], 180),
            ('fixtureTypes', [node, tsc, '--noEmit', '-p', 'tsconfig.probe.json'], 180),
            ('direct', [node, package_manifest['runtime']['vitestPath'], 'run', '--config',
                        'vitest.probe.config.ts', '--reporter=json', '--outputFile', str(run / 'vitest.json')], 60),
        ]
        for name, command, seconds in steps:
            assert check() == prior, 'STOP: source/package/repo changed before child'
            assert verify_execution_tree(tree) == executed_tree_sha, 'STOP: copied tree changed before child'
            assert verify_runtime(ROOT, package_manifest) == runtime_sha, 'STOP: runtime changed before child'
            child_env = None
            if name == 'direct':
                cache = run / 'vitest-cache'
                assert not cache.exists(), 'STOP: cache output already exists'
                assert cache.resolve().is_relative_to(run.resolve()), 'STOP: cache escapes run output'
                child_env = {**os.environ, 'SAVE46_EMPTY_R6_CACHE_DIR': str(cache)}
            result['steps'][name] = bounded(command, tree, seconds, run / (name + '.stdout.log'),
                                            run / (name + '.stderr.log'), env=child_env)
            step = result['steps'][name]
            assert verify_execution_tree(tree) == executed_tree_sha, 'STOP: copied tree changed during child'
            assert verify_runtime(ROOT, package_manifest) == runtime_sha, 'STOP: runtime changed during child'
            if step['exit'] != 0 or step['timedOut'] or step['survivingProcessGroup']:
                result['stoppedAt'] = name
                break
        if len(result['steps']) == 3 and 'stoppedAt' not in result:
            vitest = json.loads((run / 'vitest.json').read_text())
            result['vitestSha256'] = sha(run / 'vitest.json')
            result['testsPassed'] = vitest['numPassedTests']
            result['testsFailed'] = vitest['numFailedTests']
            result['accepted'] = result['testsPassed'] == 4 and result['testsFailed'] == 0
    except Exception as exc:
        result['error'] = repr(exc)
    finally:
        try:
            result['guardsAfter'] = check()
            result['sourceAndRepoUnchanged'] = result['guardsAfter'] == prior
            result['executionTreePostflightSha256'] = verify_execution_tree(tree)
            result['executionTreeUnchanged'] = result['executionTreePostflightSha256'] == executed_tree_sha
            result['runtimePostflightSha256'] = verify_runtime(ROOT, package_manifest)
            result['runtimeUnchanged'] = result['runtimePostflightSha256'] == runtime_sha
        except Exception as exc:
            result['sourceAndRepoUnchanged'] = False
            result['postflightError'] = repr(exc)
        result['accepted'] = bool(result['accepted'] and result['sourceAndRepoUnchanged'] and result.get('executionTreeUnchanged') is True and result.get('runtimeUnchanged') is True)
        result['finishedUtc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        (run / 'RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
        (run / 'RESULT.sha256.json').write_text(json.dumps({'sha256': sha(run / 'RESULT.json')}) + '\n')
    print(json.dumps({'accepted': result['accepted'], 'resultSha256': sha(run / 'RESULT.json')}))
    if not result['accepted']:
        raise SystemExit('STOP: typed/direct probe failed; retain result without repin')


if __name__ == '__main__':
    main()
