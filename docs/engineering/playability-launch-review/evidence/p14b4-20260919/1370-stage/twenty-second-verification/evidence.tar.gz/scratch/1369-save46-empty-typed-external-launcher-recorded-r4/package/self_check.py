#!/usr/bin/env python3
"""Static, complete source/package byte and repository guards. Never launches a test."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/zacheryspector/The-Movies-headless-program')
SOURCE = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-control-proposal-r1/tree')
SOURCE_MANIFEST = SOURCE.parent / 'SOURCE-SHA256.json'
REVIEW = Path('/Users/zacheryspector/studio-scratch/1369-save46-empty-control-independent-review-r1/REVIEW.md')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files(root):
    return {str(path.relative_to(root)): sha(path) for path in root.rglob('*') if path.is_file() and not path.is_symlink()}


def check():
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    assert set(manifest) == {
        'bOnlyProjection', 'boundaryWeeks', 'financeEras', 'independentSourceReviewSha256',
        'nodeModulesTarget', 'packageFiles', 'repoHead', 'schema', 'runtime',
        'sourceManifestSha256', 'testCount',
    }, 'STOP: unreviewed manifest field'
    assert manifest['schema'] == '1369-save46-empty-typed-probe-r5', 'STOP: wrong package schema'
    assert manifest['bOnlyProjection'] == 'STOP'
    assert manifest['boundaryWeeks'] == [51, 52]
    assert manifest['financeEras'] == ['research-v27', 'live']
    assert manifest['testCount'] == 4
    assert set(manifest['packageFiles']) == {
        'README.md', 'REPORT.md', 'runner.py', 'self_check.py', 'runtime_guard.py', 'DEPENDENCIES.json',
        'tests/save46-finance-direct.test.ts', 'tsconfig.probe.json',
        'vitest.probe.config.ts',
    }, 'STOP: unexpected package inventory'
    assert sha(ROOT / 'DEPENDENCIES.json') == manifest['runtime']['dependencyManifestSha256']
    assert SOURCE_MANIFEST.is_file() and sha(SOURCE_MANIFEST) == manifest['sourceManifestSha256']
    assert REVIEW.is_file() and sha(REVIEW) == manifest['independentSourceReviewSha256']
    source_expected = json.loads(SOURCE_MANIFEST.read_text())
    assert files(SOURCE) == source_expected, 'STOP: source files differ from complete reviewed manifest'
    source_links = sorted(str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_symlink())
    assert source_links == ['node_modules'], 'STOP: unexpected source symlink'
    assert os.readlink(SOURCE / 'node_modules') == manifest['nodeModulesTarget'], 'STOP: dependency target changed'
    package_expected = manifest['packageFiles']
    package_actual = {k: v for k, v in files(ROOT).items() if not k.startswith('runs/') and k != 'MANIFEST.json'}
    assert package_actual == package_expected, 'STOP: package bytes or membership changed'
    assert not [p for p in ROOT.rglob('*') if p.is_symlink() and not str(p.relative_to(ROOT)).startswith('runs/')], 'STOP: unexpected package symlink'
    assert REPO.is_dir()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    assert manifest['repoHead'] is None, 'STOP: publication HEAD must be externally bound'
    expected_head = os.environ.get('SAVE46_EMPTY_R5_EXPECTED_HEAD', '')
    assert len(expected_head) == 40 and all(c in '0123456789abcdef' for c in expected_head), 'STOP: missing external HEAD'
    assert head == expected_head, 'STOP: live repo HEAD changed'
    remote = subprocess.check_output(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/wip/headless-program-20260916-ts'], cwd=REPO, text=True).split()
    assert remote == [expected_head, 'refs/heads/wip/headless-program-20260916-ts'], 'STOP: origin HEAD differs'
    status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO)
    assert status == b'', 'STOP: live repo is dirty'
    return {'sourceFiles': len(source_expected), 'packageFiles': len(package_expected), 'repoHead': head,
            'sourceManifestSha256': sha(SOURCE_MANIFEST), 'packageManifestSha256': sha(ROOT / 'MANIFEST.json')}


if __name__ == '__main__':
    print(json.dumps(check(), sort_keys=True))
