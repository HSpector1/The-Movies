"""Static source and fixture guard for the S1 salary diagnostic arms."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/zacheryspector/studio-scratch/1370-c0-s1-salary-control-proposal-r1')
R3 = Path('/Users/zacheryspector/studio-scratch/1370-c0-external-observer-proposal-r3')
R3_MANIFEST_SHA = '5ffb357efa422989f81e69bee34db24a0d7893ccbc84071ea53d75fdcd3f33d2'
NODE_MODULES = Path('/Users/zacheryspector/The-Movies-headless-program/node_modules')
OLD = b'    const terms = offerForTalent(state.seed,person,208,week)\n'
NEW = (b'    // S1 diagnostic control: quote the drawn entry age, keeping committed talent and provenance unchanged.\n'
       b'    const exactEntryAge = entered.find(row => row.id === person.id)?.age\n'
       b'    const terms = offerForTalent(state.seed,exactEntryAge === undefined ? person : {...person,age:exactEntryAge},208,week)\n')
sha = lambda data: hashlib.sha256(data).hexdigest()

def check():
    manifest=json.loads((ROOT/'MANIFEST.json').read_bytes())
    r3_bytes=(R3/'MANIFEST.json').read_bytes()
    assert sha(r3_bytes)==manifest['baselineR3ManifestSha256']==R3_MANIFEST_SHA
    r3=json.loads(r3_bytes)
    assert manifest['package']=='1370-C0-S1-SALARY-CONTROL-R1'
    assert manifest['classification']=='EXPLORATORY_NOT_ACCEPTANCE'
    assert manifest['status']=='EXECUTABLE_ONLY_AFTER_INDEPENDENT_S1_REVIEW'
    assert (manifest['seed'],manifest['horizon'],manifest['testTimeoutSeconds'],manifest['outerTimeoutSeconds'])==('p13a-core-causal-01',416,600,630)
    assert manifest['expectedPins']['m0RecordedActual']==r3['expectedPins']['modernRecordedActual']
    assert manifest['expectedPins']['s1Unpinned'] is None
    assert manifest['expectedRng']['m0']==manifest['expectedRng']['s1']==r3['expectedRng']['modern']
    assert manifest['entrypoints']==r3['entrypoints']
    assert manifest['modernSourceTree']=='13880d9b0ba72aff5d4c5bcf5d12fe682c5de554'
    assert sha((ROOT/'runner.py').read_bytes())==manifest['runnerSha256']
    assert sha((ROOT/'guard_logic.py').read_bytes())==manifest['guardLogicSha256']
    diagnostic=(ROOT/'diagnostic.test.ts').read_bytes()
    assert sha(diagnostic)==manifest['diagnosticSha256']
    assert b'firstOfferWitness' in diagnostic and b'state = tick(state)' in diagnostic
    assert b'const endWeek = 416' in diagnostic and b'}, 600_000)' in diagnostic
    base=r3['arms']['modern']['files']
    for arm in ('m0','s1'):
        tree=ROOT/'arms'/arm/'tree'
        assert (tree/'node_modules').is_symlink()
        assert (tree/'node_modules').resolve()==NODE_MODULES.resolve()
        files=manifest['arms'][arm]['files']
        assert set(files)==set(base)
        actual={str(p.relative_to(tree)) for p in tree.rglob('*') if p.is_file() and p.name!='node_modules'}
        assert actual==set(files), (arm,sorted(actual^set(files)))
        for name,pin in files.items():
            path=tree/name
            assert path.is_file() and not path.is_symlink() and sha(path.read_bytes())==pin,(arm,name)
            expected=(diagnostic if name=='tests/preimage-diagnostic.test.ts'
                else NEW_SOURCE if arm=='s1' and name=='src/core/hollywood.ts'
                else (R3/'arms/modern/tree'/name).read_bytes())
            assert path.read_bytes()==expected,(arm,name,'source identity')
            if name not in ('tests/preimage-diagnostic.test.ts','src/core/hollywood.ts') or arm=='m0':
                if name!='tests/preimage-diagnostic.test.ts': assert pin==base[name]
        assert (tree/'tests/preimage-diagnostic.test.ts').read_bytes()==diagnostic
        assert b'testTimeout: 600_000' in (tree/'vitest.preimage.config.ts').read_bytes()
        assert files['tests/contracts/_contractFixtures.ts']=='7554a6b11f0756c7cd286a7732ab888757a129fe0d9f10657c93c4d214f10de2'
    assert manifest['arms']['m0']['files']['src/core/hollywood.ts']==base['src/core/hollywood.ts']
    assert manifest['arms']['s1']['files']['src/core/hollywood.ts']==sha(NEW_SOURCE)
    print('STATIC_CHECK_PASS: exact M0/S1 source, fixture, diagnostic and single salary hunk')

BASE_SOURCE=(R3/'arms/modern/tree/src/core/hollywood.ts').read_bytes()
assert BASE_SOURCE.count(OLD)==1
NEW_SOURCE=BASE_SOURCE.replace(OLD,NEW,1)
