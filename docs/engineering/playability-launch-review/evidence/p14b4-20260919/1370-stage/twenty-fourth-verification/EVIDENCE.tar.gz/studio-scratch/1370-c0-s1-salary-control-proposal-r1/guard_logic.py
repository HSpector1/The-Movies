"""Pure admission checks shared by the formal runner and negative fixtures."""
import hashlib
import json
from pathlib import Path

KEYS = ('settlement', 'receipts', 'employment', 'takes')
WEEK_KEYS = {'week', 'receiptsAppended', 'receipts', 'employment', 'takesAppended', 'firstTakes', 'settlement'}
TERMINAL = {'settled', 'declined', 'expired'}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def required_artifacts(receipt_path, formal_dir, mode):
    run = Path(receipt_path).parent
    stem = '1370-c0-s1-control-r1-' + run.name
    local = ['binding.json', 'LAUNCH.json', 'CHILD.json', 'stdout.txt', 'stderr.txt', 'power.txt', 'power-post.txt']
    if mode == 'clean':
        local += ['vitest.json']
        local += ['preimages/' + name for name in ('final.json', 'weekly.ndjson', 'terminal-context.ndjson', 'trace.ndjson', 'trace-schema.json')]
        local += ['preimages/' + key + '.json' for key in KEYS]
    formal = [stem + suffix for suffix in ('.json', '.patch', '.txt', '-preflight.json', '-postflight.json')]
    return {str(run / name) for name in local} | {str(Path(formal_dir) / name) for name in formal}

def assert_receipt_integrity(record, pins, command, arm, mode, receipt_path, formal_dir):
    receipt_path = Path(receipt_path)
    run = receipt_path.parent
    assert receipt_path.name == 'RESULT.json' and receipt_path.is_file()
    assert record['package'] == '1370-C0-S1-SALARY-CONTROL-R1'
    assert record['classification'] == 'EXPLORATORY_NOT_ACCEPTANCE'
    assert record['mode'] == mode and record['arm'] == arm and record['command'] == command
    assert record['pins'] == pins and record['accepted'] is True
    assert record['actualChildExit'] == record['recorderChildExit'] == record['recorderStatus'] == 0
    assert record['allGuardsExact'] and record['livePostflightExact'] and not record['timedOut']
    assert not record['reportingErrors'] and record['powerPostflightError'] is None
    assert record['outputBoundExact'] and record['diskReservePostflight']
    assert not record['outputLimitExceeded'] and not record['diskReserveBreached']
    group = record['processGroup']
    assert group['cleanupVerified'] and group['noSurvivors'] and group['leaderReaped'] and not group['errors']
    expected = required_artifacts(receipt_path, formal_dir, mode)
    assert set(record['artifacts']) == expected
    for name, item in record['artifacts'].items():
        path = Path(name)
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    local = {name for name in expected if Path(name).is_relative_to(run)}
    assert {str(p) for p in run.rglob('*') if p.is_file()} == local | {str(receipt_path), str(run / 'RESULT.sha256.json')}
    assert {str(p) for p in run.rglob('*') if p.is_dir()} == {str(run / 'preimages')}
    assert all(not p.is_symlink() for p in run.rglob('*'))
    assert json.loads((run / 'RESULT.sha256.json').read_text()) == {'sha256': sha(receipt_path)}
    binding_path = run / 'binding.json'; binding = json.loads(binding_path.read_text())
    launch = json.loads((run / 'LAUNCH.json').read_text())
    child = json.loads((run / 'CHILD.json').read_text())
    assert binding['package'] == record['package'] and binding['classification'] == record['classification']
    assert binding['mode'] == mode and binding['arm'] == arm and binding['command'] == command
    assert binding['pins'] == pins and binding['head'] == pins['head']
    assert binding['horizon'] == 416 and binding['seed'] == 'p13a-core-causal-01'
    assert binding['manifestSha256'] == pins['manifestSha256'] and binding['runnerSha256'] == pins['runnerSha256']
    assert binding['probeTestSeconds'] == 600 and binding['outerCapSeconds'] == 630
    assert binding['formalStem'] == '1370-c0-s1-control-r1-' + run.name
    assert record['staticReviewSha256'] == binding['staticReviewSha256']
    assert launch['bindingSha256'] == sha(binding_path) and launch['command'] == command
    assert launch['startNewSession'] is True and launch['actualWaitTimeoutSeconds'] == (300 if mode == 'types' else 630)
    assert launch['childPid'] == launch['ownedProcessGroup'] == group['ownedProcessGroup']
    assert child['command'] == command and child['actualChildExit'] == 0 and child['timedOut'] is False
    assert child['allGuardsExact'] and not child['reportingErrors']
    assert child['processGroup'] == group
    assert child['stdoutSha256'] == sha(run / 'stdout.txt') and child['stderrSha256'] == sha(run / 'stderr.txt')
    formal = Path(formal_dir); stem = binding['formalStem']
    pre = json.loads((formal / (stem + '-preflight.json')).read_text())
    recorder = json.loads((formal / (stem + '.json')).read_text())
    post = json.loads((formal / (stem + '-postflight.json')).read_text())
    assert pre['head'] == pre['remote'] == pins['head'] and pre['advanceCap'] == 0
    assert pre['index']['sha256'] == pins['indexSha256'] and pre['stageEntries']['sha256'] == pins['stageSha256']
    assert recorder['sourceSha'] == recorder['sourceShaAtEnd'] == post['head'] == pins['head']
    assert recorder['fixedSource'] and recorder['exitCode'] == post['exitCode'] == 0
    assert post['fixedSource'] and post['allGuardsExact']
    child_command = recorder['command']
    assert len(child_command) == 11
    assert child_command[:4] == [binding['recorderPython'], '-I', '-B', '-c']
    assert hashlib.sha256(child_command[4].encode()).hexdigest() == pins['childBootstrapSha256']
    assert child_command[5:] == [pins['manifestSha256'], pins['runnerSha256'], binding['staticReviewSha256'],
                                  '--child', str(run), sha(binding_path)]
    assert post['record']['sha256'] == sha(formal / (stem + '.json'))
    assert post['raw']['sha256'] == sha(formal / (stem + '.txt'))
    assert post['patch']['sha256'] == sha(formal / (stem + '.patch'))

def assert_types_receipt(record, pins, command, arm, receipt_path, formal_dir):
    assert_receipt_integrity(record, pins, command, arm, 'types', receipt_path, formal_dir)
    assert record['validation'] == {'freshFullTypes': True}

def assert_prior_m0(record, pins, target, rng, receipt_path, formal_dir, command):
    assert_receipt_integrity(record, pins, command, 'm0', 'clean', receipt_path, formal_dir)
    assert record['validation']['actual'] == target and record['validation']['allPinsMatch'] is True
    assert record['validation']['weeklyRows'] == 417 and record['validation']['rng'] == rng

def validate_preimages(directory, target, rng, max_bytes):
    directory = Path(directory)
    files = [directory / name for name in ('final.json', 'weekly.ndjson', 'terminal-context.ndjson', 'trace.ndjson', 'trace-schema.json')]
    files += [directory / (key + '.json') for key in KEYS]
    assert all(path.is_file() and not path.is_symlink() for path in files)
    assert all(path.stat().st_size <= max_bytes for path in files)
    assert sum(path.stat().st_size for path in files) <= max_bytes
    final = json.loads((directory / 'final.json').read_text())
    assert final['seed'] == 'p13a-core-causal-01' and final['week'] == 416 and final['rngState'] == rng
    assert sha(directory / 'weekly.ndjson') == final['weekly']['sha256']
    assert sha(directory / 'terminal-context.ndjson') == final['terminalContext']['sha256']
    assert final['trace']['schema'] == 'c0-external-observer/v1' and final['trace']['rows'] == 43
    assert sha(directory / 'trace.ndjson') == final['trace']['sha256']
    assert sha(directory / 'trace-schema.json') == final['trace']['schemaSha256']
    trace_schema = json.loads((directory / 'trace-schema.json').read_text())
    assert trace_schema['version'] == 'c0-external-observer/v1' and trace_schema['rowCount'] == 43
    assert [row['kind'] for row in trace_schema['rows']] == ['salary', 'film', 'market']
    trace = [json.loads(line) for line in (directory / 'trace.ndjson').read_text().splitlines()]
    assert len(trace) == 43 and [row['week'] for row in trace] == [0, *range(75, 115), 207, 208]
    assert [row['kind'] for row in trace] == ['salary', *(['film'] * 40), 'market', 'market']
    assert all(row['schema'] == 'c0-external-observer/v1' for row in trace)
    assert trace[0]['contractId'] == 'studio-aca408ec-r01:contract:person-studio-aca408ec-r01-0:0'
    assert len(trace[0]['initialEmployment']) == 24
    witness = trace[0]['firstOfferWitness']
    assert len(witness) == 24
    assert [row['contractId'] for row in witness] == [row['contractId'] for row in trace[0]['initialEmployment']]
    assert all(row['storedAnnual'] == employment['annualSalary'] and
               row['storedSigningBonus'] == employment['signingBonus']
               for row, employment in zip(witness, trace[0]['initialEmployment']))
    assert all(row['matchesExactQuote'] or row['matchesStoredQuote'] for row in witness)
    assert all(row['productionId'] == 'studio-aca408ec-r01:film:10' for row in trace[1:41])
    assert all(row['talentId'] == 'person-studio-aca408ec-r01-0' for row in trace[41:])
    weekly = [json.loads(line) for line in (directory / 'weekly.ndjson').read_text().splitlines()]
    assert len(weekly) == 417 and [row['week'] for row in weekly] == list(range(417))
    assert all(set(row) == WEEK_KEYS for row in weekly)
    terminal = []
    previous = None
    for row in weekly:
        assert all(isinstance(row[k], list) for k in WEEK_KEYS - {'week'})
        projection = [[r.get(k) for k in ('eventId', 'kind', 'week', 'talentId', 'studioId', 'reasons', 'dropped')]
                      for r in row['receipts'] if r['kind'] in TERMINAL]
        assert row['settlement'] == projection
        if previous is None:
            assert row['receiptsAppended'] == []
        else:
            old_receipts, new_receipts = previous['receipts'], row['receipts']
            old_takes, new_takes = previous['firstTakes'], row['firstTakes']
            assert len(new_receipts) >= len(old_receipts) and new_receipts[:len(old_receipts)] == old_receipts
            assert len(new_takes) >= len(old_takes) and new_takes[:len(old_takes)] == old_takes
            assert row['receiptsAppended'] == new_receipts[len(old_receipts):]
            assert row['takesAppended'] == new_takes[len(old_takes):]
            terminal += [(row['week'], r) for r in row['receiptsAppended'] if r['kind'] in TERMINAL]
        previous = row
    contexts = [json.loads(line) for line in (directory / 'terminal-context.ndjson').read_text().splitlines()]
    assert len(contexts) == len(terminal)
    for context, (week, receipt) in zip(contexts, terminal):
        assert set(context) == {'week', 'receipt', 'cases', 'proposalReceipts', 'proposals', 'promises', 'person', 'employment', 'businesses'}
        assert context['week'] == week and context['receipt'] == receipt
        assert isinstance(context['cases'], list) and isinstance(context['proposalReceipts'], list)
        assert isinstance(context['promises'], list) and isinstance(context['employment'], list) and isinstance(context['businesses'], list)
    values = {'settlement': previous['settlement'], 'receipts': previous['receipts'],
              'employment': previous['employment'], 'takes': previous['firstTakes']}
    actual = {}
    for key in KEYS:
        path = directory / (key + '.json')
        meta = final[key]
        assert path.stat().st_size == meta['bytes'] and sha(path) == meta['sha256']
        value = json.loads(path.read_text())
        assert isinstance(value, list) and value == values[key] and len(value) == meta['length']
        actual[key] = meta['sha256']
    if target is not None: assert actual == target
    return {'actual': actual, 'expected': target, 'allPinsMatch': actual == target if target is not None else None, 'rng': rng, 'weeklyRows': 417,
            'terminalContexts': len(contexts), 'traceRows': len(trace), 'traceSha256': final['trace']['sha256'],
            'preimageBytes': {key: final[key]['bytes'] for key in KEYS}}
