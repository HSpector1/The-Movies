# C0 S1 salary-input control, executable proposal r1

**Awaiting independent static review. Do not launch types, Vitest, the recorder or a game child yet.** This scratch package contains two modern C0 source snapshots: M0 is byte-for-byte the independently audited r3 modern source; S1 differs only at `src/core/hollywood.ts` in one founding-offer hunk. S1 quotes the already captured exact entry age on a temporary `Talent` copy, while the committed person, provenance, RNG key, term, hiring order and money movement remain on the modern path. It is a diagnostic counterfactual, not a product fix. If the modern validator rejects its terms, preserve that failure and stop; do not relax validation.

Both arms run the same diagnostic test. Its 43-row trace adds a read-only `firstOfferWitness` to the week-zero salary row: each of the 24 initial contracts carries its exact/stored age, pure exact/stored `offerForTalent` quotes, committed terms and quote-match flags. The witness does **not** claim to observe a private call argument; the source hunk and immutable arm diff establish which argument S1 passes. Derived hiring streams use fresh deterministic instances, and the witness never edits state or advances the simulation stream. The film and market observer rows, four original terminal JSON preimages, 417 weekly rows and all 40 terminal contexts retain r3's forms.

M0 must match the already recorded modern four terminal digests and RNG. S1 has no predeclared protected digest: its full actual arrays, RNG and validator outcome are measured, then compared with M0 by stable identity plus occurrence under a separately reviewed comparison. `allPinsMatch: null` on an admitted S1 result means no protected expected pin was applied, not a failure waiver. A failed source, typecheck, validator, test, timeout, recorder or cleanup check is preserved as failure and stops subsequent stages. No S1 result alone proves the terminal employment cause.

The route order is M0 types → M0 clean → S1 types → S1 clean, with full source, HEAD/remote, index/stage, entrypoint, AC/disk/output, formal pre/postflight, actual child/recorder exit and process-group cleanup guards. Use one exclusive recorded heavy lane around the entire sequence. The seed is `p13a-core-causal-01`; the horizon is natural week 0 plus 416 direct ticks (417 weekly records). Types cap 300 seconds; clean Vitest cap 600 seconds and recorder cap 630 seconds, **exploratory only**. These bounds do not alter the original 300/330 observed result or authorize 720/750 acceptance. Every stage uses a fresh leaf and five new formal files. The S1 runner requires accepted M0 clean and its own fresh types receipt before S1 clean.

Before launching, an independent reviewer must inspect this package's exact source and fixture inventory, the one-hunk S1 diff, equal diagnostic bytes and witness purity, runner/child immutable-buffer authentication, no mutable helper imports, exact result/guard checks, S1 unpinned-result semantics and failure preservation. The reviewer must issue a separate fixed receipt at `/Users/zacheryspector/studio-scratch/1370-c0-s1-salary-control-independent-review-r1/RECEIPT.json` with exactly `{ "decision": "ACCEPT", "package": "1370-C0-S1-SALARY-CONTROL-R1", "classification": "EXPLORATORY_NOT_ACCEPTANCE", "manifestSha256": "<frozen manifest SHA>", "runnerSha256": "<frozen runner SHA>" }`. Static acceptance permits only an attempt, not a result or causal verdict.

The trusted parent must supply literal externally issued manifest, runner and review-receipt hashes and a **newly published, clean** full launch HEAD equal to `origin/refs/heads/wip/headless-program-20260916-ts`. It must hash one runner byte buffer and execute that same buffer with `python3 -I -B -c`, setting `C0_S1_CONTROL_R1_EXTERNAL_MANIFEST_SHA256` and `C0_S1_CONTROL_R1_EXTERNAL_REVIEW_SHA256` only after those checks. The recorder child uses the runner's embedded isolated bootstrap with the same immutable-buffer authentication. Never compute authority pins from mutable package bytes at run time or invoke `runner.py` directly.

Use this literal parent bootstrap with externally issued SHA values; the verified review receipt is passed in the same immutable buffer, not reread by the runner:

```bash
python3 -I -B -c 'import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1370-c0-s1-salary-control-proposal-r1")
runner=root/"runner.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1370-c0-s1-salary-control-independent-review-r1/RECEIPT.json")
manifest_pin="<FROZEN_MANIFEST_SHA256>"
runner_pin="<FROZEN_RUNNER_SHA256>"
review_pin="<INDEPENDENT_REVIEW_RECEIPT_SHA256>"
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path and not root.is_symlink()
manifest_bytes=manifest.read_bytes(); assert sha(manifest_bytes)==manifest_pin
code=runner.read_bytes(); assert sha(code)==runner_pin
review_bytes=review.read_bytes(); assert sha(review_bytes)==review_pin
assert json.loads(review_bytes)=={"decision":"ACCEPT","package":"1370-C0-S1-SALARY-CONTROL-R1","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_pin,"runnerSha256":runner_pin}
os.environ["C0_S1_CONTROL_R1_EXTERNAL_MANIFEST_SHA256"]=manifest_pin
os.environ["C0_S1_CONTROL_R1_EXTERNAL_REVIEW_SHA256"]=review_pin
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(code,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner),"_EXTERNAL_EXECUTED_RUNNER_BYTES":code,"_EXTERNAL_REVIEW_BYTES":review_bytes})' RUN_ARGUMENTS
```

For each stage, pass `types|clean --arm m0|s1 --head <PUBLISHED_FULL_SHA> --manifest-sha256 <FROZEN_MANIFEST_SHA> --self-runner-sha256 <FROZEN_RUNNER_SHA> --leaf <FRESH_LEAF> --static-review-receipt <FIXED_RECEIPT_PATH> --static-review-sha256 <INDEPENDENT_RECEIPT_SHA>`. Clean stages also pass their matching `--types-receipt` and SHA; both S1 stages pass the admitted `--m0-receipt` and SHA. Run M0 before S1. The package runner itself enforces these dependencies and exact formal artifacts; a separate versioned four-route launcher should be reviewed if automation rather than these explicit staged calls is used.

This proposal preserves the r3 package and its prior output unchanged. M0's source tree remains `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`; S1 has an independently pinned altered tree. The accepted design is `1370-c0-causal-controls-design-r1/DESIGN.md` SHA `547afcd6c9d871e7c7e4573536eec4e0daee3f4aaeb36a52e6bfd4e3d493354f`, accepted as **design only**. No repository source or protected value is changed here.
