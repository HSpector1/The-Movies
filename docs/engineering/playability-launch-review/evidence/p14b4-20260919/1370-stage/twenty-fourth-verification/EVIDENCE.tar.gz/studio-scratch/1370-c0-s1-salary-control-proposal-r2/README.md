# C0 S1 salary-input control, executable proposal r2

**Static proposal awaiting independent review; do not launch a heavy child.** R1 and its independent REFINE receipt are preserved unchanged. R2 fixes the missing actual first-decision witness. It remains an exploratory diagnostic counterfactual, not a product change, acceptance result or causal claim.

Both M0 and S1 contain the same small observer hook in `src/core/hollywood.ts`. At each week-zero founding offer, the hook records the actual `offerInput.age` passed once to `offerForTalent`, the returned annual/signing terms, and the account's cash and signing-period movement immediately before and after the single existing `moveRivalMoney` call. It appends 24 rows in source order to `preimages/first-offer-witness.ndjson`. The hook reads existing values and writes only this diagnostic file; it does not add a quote, RNG draw, account move, state mutation, branch in the game decision or changed term. A file write failure fails the route. The equal hook changes the diagnostic source identity of **both** arms relative to the accepted r3 modern arm, and is never labeled an unmodified production source.

S1 differs from the instrumented M0 in **one line**: M0 sets `offerInput = person`, whereas S1 sets `offerInput` to a temporary copy at the exact age already captured in `entered` for a freshly minted person, falling back to the stored person for a reused person. Committed integer talent age, provenance, hiring order, single offer call, term, account debit and all validators are otherwise unchanged. `self_check.py` reconstructs the two source files from the pinned r3 modern source using the exact equal hook and one S1 input-line replacement, then verifies every file in both 201-file arms and the genuine fixture. The identical test emits the r3 43-row trace with its existing pure 24-offer quote table plus the new independently hashed actual-call/debit file. The guard checks all 24 actual rows against source-order contracts and pure quotes, requires `cashAfter = cashBefore − signingBonus` and the same signing-period delta, and requires input age to follow the M0/S1 source rule.

M0 must reproduce the separately recorded modern four protected digests and RNG. S1 has **no predeclared protected digest**: its actual four arrays and RNG are measured, with `allPinsMatch: null` and complete structural validation. If the modern validator refuses the diagnostic quote, preserve the failure and stop; do not weaken validation or change a protected pin. An admitted S1 leaf still needs independently reviewed source-order identity-plus-occurrence comparison against M0 before any attribution.

The sequential route is M0 types → M0 416-week clean → S1 types → S1 416-week clean. Each route requires fresh isolated outputs and five formal files, exact branch/local/origin HEAD, `HEAD:src` tree `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`, index/stage, full package/arm/entrypoint pins, AC/disk/output gates, child and recorder exits, pre/postflight source guards and process-group cleanup. Use one exclusive recorded heavy lane. Seed `p13a-core-causal-01`, natural week 0 plus 416 direct ticks, 417 weekly records, all terminal contexts, four original JSON preimages, 43 trace rows and 24 actual-offer rows are mandatory. Types cap 300 seconds; clean Vitest cap 600 seconds and recorder cap 630 seconds, all exploratory. The original 300/330 observed failure and prospective 720/750 acceptance remain separate.

An independent reviewer must inspect exact package inventory, equal instrumentation purity and output ordering, the one-line S1 source difference, fixture/source identities, actual-call/debit guard, immutable parent/child runner and review-receipt buffers, full output/formal/cleanup admission and validator-refusal stop. The reviewer must issue a fixed receipt at `/Users/zacheryspector/studio-scratch/1370-c0-s1-salary-control-independent-review-r2/RECEIPT.json` with exactly `{ "decision": "ACCEPT", "package": "1370-C0-S1-SALARY-CONTROL-R2", "classification": "EXPLORATORY_NOT_ACCEPTANCE", "manifestSha256": "<frozen manifest SHA>", "runnerSha256": "<frozen runner SHA>" }`. Static ACCEPT permits an attempt only.

The trusted caller supplies **literal external** manifest, runner and independent review-receipt SHA values plus a newly published, clean full HEAD. It reads each once, verifies each, and executes the same runner byte buffer with isolated `python3 -I -B -c`. The verified review receipt bytes are passed into the runner; it does not reread a mutable path. The child bootstrap embedded in the runner does the same. Direct `runner.py` execution is refused. Use this parent shape:

```bash
python3 -I -B -c 'import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1370-c0-s1-salary-control-proposal-r2")
runner=root/"runner.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1370-c0-s1-salary-control-independent-review-r2/RECEIPT.json")
manifest_pin="<FROZEN_MANIFEST_SHA256>"
runner_pin="<FROZEN_RUNNER_SHA256>"
review_pin="<INDEPENDENT_REVIEW_RECEIPT_SHA256>"
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path and not root.is_symlink()
manifest_bytes=manifest.read_bytes(); assert sha(manifest_bytes)==manifest_pin
code=runner.read_bytes(); assert sha(code)==runner_pin
review_bytes=review.read_bytes(); assert sha(review_bytes)==review_pin
assert json.loads(review_bytes)=={"decision":"ACCEPT","package":"1370-C0-S1-SALARY-CONTROL-R2","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_pin,"runnerSha256":runner_pin}
os.environ["C0_S1_CONTROL_R2_EXTERNAL_MANIFEST_SHA256"]=manifest_pin
os.environ["C0_S1_CONTROL_R2_EXTERNAL_REVIEW_SHA256"]=review_pin
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(code,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner),"_EXTERNAL_EXECUTED_RUNNER_BYTES":code,"_EXTERNAL_REVIEW_BYTES":review_bytes})' RUN_ARGUMENTS
```

For each stage, `RUN_ARGUMENTS` means `types|clean --arm m0|s1 --head <PUBLISHED_FULL_SHA> --manifest-sha256 <FROZEN_MANIFEST_SHA> --self-runner-sha256 <FROZEN_RUNNER_SHA> --leaf <FRESH_LEAF> --static-review-receipt <FIXED_RECEIPT_PATH> --static-review-sha256 <INDEPENDENT_RECEIPT_SHA>`. Clean stages also require their types RESULT path/SHA; both S1 stages require admitted M0 clean RESULT path/SHA. Preserve failures and do not invoke the stages outside the one recorded lane.
