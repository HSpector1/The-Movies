# C0 observer recorded-route launcher, proposal r1

**Status: static proposal awaiting independent review. No types, simulation, recorder or other heavy child has run.** This launcher composes the independently static-accepted C0 observer r3 package without modifying it. The exact r3 manifest, runner, independent review and receipt, and heavy-lane wrapper are pinned in this package's manifest. It keeps the original 654-T historical preimage pins, the later approved aging employment pin, and the separately recorded modern actual pins in their distinct roles.

The runtime `--head` must be supplied as a full SHA from the **next published documentation checkpoint**. The launcher checks exact local HEAD, `origin` branch, and `HEAD:src` tree `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`. It does not select a HEAD itself. A clean repository at launch and fresh exclusive run/formal output names are required. `--run-id` is an externally chosen lowercase identifier, reused across four unique arm/mode tags. The parent invokes the launcher once through the pinned `/Users/zacheryspector/studio-scratch/heavy-queue/lane-run.sh` so its lock covers the entire sequence. `--lane-log` must be that wrapper's log path; the launcher verifies the owned lock before and between routes.

The sequence is historical full types → historical exploratory clean → modern full types → modern exploratory clean. Each route invokes the r3 parent via isolated `python3 -I -B -c` with a single externally pinned runner byte buffer. R3's recorder child uses its own isolated immutable-buffer bootstrap. The historical clean receives its types RESULT SHA; both modern routes receive the accepted historical clean RESULT SHA; modern clean also receives its own types RESULT SHA. Every route keeps r3's seed `p13a-core-causal-01`, 416 natural ticks/417 weekly records, full four preimages and 40 terminal contexts, 43 observer rows, 300-second types, 600-second Vitest/630-second recorder exploratory caps, original/modern expected pins, source pre/postflight, output/disk/power limits and process-group cleanup. A failure stops the sequence and preserves its leaf and launcher failure record; no later route runs. Wrapper exit zero is never treated as child admission.

Independent review must check this launcher's immutable parent bootstrap, exact package inventory, r3/review/wrapper pins, one-lane ownership, fresh output preflight, dependency receipt ordering, r3 formal/child/cleanup audits, and no test/clean path reachable through `--static-check`. Review must issue a separate fixed receipt at `/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-independent-review-r1/RECEIPT.json` with exactly `{ "decision": "ACCEPT", "package": "1370-C0-OBSERVER-ROUTE-LAUNCHER-R1", "classification": "EXPLORATORY_NOT_ACCEPTANCE", "manifestSha256": "<frozen launcher manifest SHA>", "runnerSha256": "<frozen launcher runner SHA>" }`. Static review is permission to attempt the recorded route; it is not a passed route or 1363 closure.

The trusted caller must use the **literal external** parent bootstrap below after replacing the manifest, runner and independently issued launcher review receipt SHA placeholders. The same verified launcher byte buffer is compiled and executed. This command belongs inside the pinned lane wrapper invocation, with the runtime HEAD and fresh run ID supplied only after the next published checkpoint. Never compute authority SHA values from mutable bytes at launch time.

```bash
python3 -I -B -c 'import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-proposal-r1")
runner=root/"runner.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-independent-review-r1/RECEIPT.json")
manifest_pin="<FROZEN_LAUNCHER_MANIFEST_SHA256>"
runner_pin="<FROZEN_LAUNCHER_RUNNER_SHA256>"
review_pin="<INDEPENDENT_LAUNCHER_REVIEW_RECEIPT_SHA256>"
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path and not root.is_symlink()
manifest_bytes=manifest.read_bytes()
assert sha(manifest_bytes)==manifest_pin
code=runner.read_bytes()
assert sha(code)==runner_pin
review_bytes=review.read_bytes()
assert sha(review_bytes)==review_pin
assert json.loads(review_bytes)=={"decision":"ACCEPT","package":"1370-C0-OBSERVER-ROUTE-LAUNCHER-R1","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_pin,"runnerSha256":runner_pin}
os.environ["C0_OBSERVER_LAUNCH_R1_EXTERNAL_MANIFEST_SHA256"]=manifest_pin
os.environ["C0_OBSERVER_LAUNCH_R1_EXTERNAL_REVIEW_SHA256"]=review_pin
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(code,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner),"_EXTERNAL_EXECUTED_LAUNCHER_BYTES":code})' --head <NEXT_PUBLISHED_HEAD> --run-id <FRESH_RUN_ID> --lane-log /Users/zacheryspector/studio-scratch/heavy-queue/<FRESH_LOG_NAME>
```

The launcher records each actual r3 RESULT path/SHA and audits accepted child/recorder zero, formal/source/cleanup gates, the exact historical or modern full-preimage pins, 417/40/43 row counts and RNG before starting the next route. Its `RESULT.json` is exploratory evidence only, never observed acceptance or a protected repin.
