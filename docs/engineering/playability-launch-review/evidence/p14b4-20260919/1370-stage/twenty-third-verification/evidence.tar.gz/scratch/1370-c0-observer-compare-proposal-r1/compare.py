#!/usr/bin/env python3
"""Read-only comparison of completed, externally pinned C0 observer routes."""
import argparse
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

R3_MANIFEST = Path('/Users/zacheryspector/studio-scratch/1370-c0-external-observer-proposal-r3/MANIFEST.json')
R3_MANIFEST_SHA = '5ffb357efa422989f81e69bee34db24a0d7893ccbc84071ea53d75fdcd3f33d2'
LAUNCHER_MANIFEST_SHA = 'e911546c5496de661c7fd7e6a195c5ef1e56085e5f6e1e9dbbb3bd91b31cfaa5'
ROUTE_ORDER = [('historical', 'types'), ('historical', 'clean'), ('modern', 'types'), ('modern', 'clean')]
KEYS = ('settlement', 'receipts', 'employment', 'takes')
SHA = re.compile(r'[0-9a-f]{64}\Z')

def read_pin(path, pin):
    assert path.is_absolute() and not path.is_symlink()
    assert SHA.fullmatch(pin)
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == pin, str(path)
    return data

def read_json(path, pin):
    return json.loads(read_pin(path, pin))

def identity(kind, row):
    if kind == 'settlement':
        assert isinstance(row, list) and len(row) == 7
        return (row[2], row[3], row[1])
    assert isinstance(row, dict)
    if kind == 'receipts': return tuple(row[key] for key in ('week', 'kind', 'talentId', 'studioId'))
    if kind == 'employment': return (row['contractId'],)
    if kind == 'takes': return tuple(row[key] for key in ('week', 'productionId', 'studioId'))
    if kind == 'trace':
        base = (row['kind'], row['week'])
        return base + ((row['contractId'],) if row['kind'] == 'salary' else
                       (row['productionId'],) if row['kind'] == 'film' else (row['talentId'],))
    raise AssertionError(kind)

def label_rows(kind, rows):
    assert isinstance(rows, list)
    occurrence = defaultdict(int)
    labeled = []
    for index, row in enumerate(rows):
        key = identity(kind, row)
        count = occurrence[key]
        occurrence[key] += 1
        labeled.append((json.dumps([*key, count], separators=(',', ':')), index, row))
    assert len({label for label, _, _ in labeled}) == len(labeled)
    return labeled

def first_field(left, right, path='$'):
    if type(left) is not type(right): return {'path':path, 'historical':left, 'modern':right}
    if isinstance(left, dict):
        for key in sorted(set(left) | set(right)):
            next_path = path + '.' + key
            if key not in left: return {'path':next_path, 'historical':'<absent>', 'modern':right[key]}
            if key not in right: return {'path':next_path, 'historical':left[key], 'modern':'<absent>'}
            found = first_field(left[key], right[key], next_path)
            if found: return found
    elif isinstance(left, list):
        for i in range(min(len(left),len(right))):
            found = first_field(left[i],right[i],path+'['+str(i)+']')
            if found: return found
        if len(left) != len(right): return {'path':path+'.length','historical':len(left),'modern':len(right)}
    elif left != right: return {'path':path, 'historical':left, 'modern':right}
    return None

def compare_rows(kind, historical, modern):
    h = label_rows(kind, historical); m = label_rows(kind, modern)
    hd={label:(index,row) for label,index,row in h}; md={label:(index,row) for label,index,row in m}
    common=set(hd)&set(md)
    changed=[]
    for label,index,row in h:
        if label in common:
            field=first_field(row,md[label][1])
            if field: changed.append({'identityOccurrence':label,'historicalIndex':index,'modernIndex':md[label][0],**field})
    hs=[label for label,_,_ in h]; ms=[label for label,_,_ in m]
    order=next(({'index':i,'historical':hs[i] if i<len(hs) else '<end>',
                 'modern':ms[i] if i<len(ms) else '<end>'}
                for i in range(max(len(hs),len(ms))) if i>=len(hs) or i>=len(ms) or hs[i]!=ms[i]),None)
    return {'historicalRows':len(h),'modernRows':len(m),'firstSourceOrderDifference':order,
            'firstMatchedFieldDifference':changed[0] if changed else None,
            'changedMatchedCount':len(changed),'changedMatchedSample':changed[:10],
            'historicalOnly':[label for label,_,_ in h if label not in md][:20],
            'modernOnly':[label for label,_,_ in m if label not in hd][:20],
            'historicalOnlyCount':sum(label not in md for label,_,_ in h),
            'modernOnlyCount':sum(label not in hd for label,_,_ in m)}

def verify_route_record(record, expected_arm, expected_mode, head, manifest):
    assert record['arm']==expected_arm and record['mode']==expected_mode
    result=read_json(Path(record['path']),record['sha256'])
    assert result['package']=='1370-C0-EXTERNAL-OBSERVER-R3'
    assert result['classification']=='EXPLORATORY_NOT_ACCEPTANCE' and result['accepted'] is True
    assert result['arm']==expected_arm and result['mode']==expected_mode
    assert result['pins']['head']==result['pins']['originHead']==head
    assert result['pins']['branch']=='refs/heads/wip/headless-program-20260916-ts'
    assert result['pins']['manifestSha256']==R3_MANIFEST_SHA
    assert result['pins']['runnerSha256']==manifest['runnerSha256']
    assert result['seed']==manifest['seed'] and result['pins']['horizon']==416
    assert result['actualChildExit']==result['recorderChildExit']==result['recorderStatus']==0
    assert result['allGuardsExact'] and result['livePostflightExact'] and not result['timedOut']
    assert not result['reportingErrors'] and result['powerPostflightError'] is None
    assert result['outputBoundExact'] and result['diskReservePostflight']
    assert not result['outputLimitExceeded'] and not result['diskReserveBreached']
    group=result['processGroup']
    assert group['cleanupVerified'] and group['noSurvivors'] and group['leaderReaped'] and not group['errors']
    assert json.loads((Path(record['path']).parent/'RESULT.sha256.json').read_text())=={'sha256':record['sha256']}
    for name,item in result['artifacts'].items():
        assert len(read_pin(Path(name),item['sha256']))==item['bytes']
    return result

def load_clean(record, expected_arm, manifest, result):
    assert record['arm']==expected_arm and record['mode']=='clean'
    path=Path(record['path'])
    assert result['validation']['allPinsMatch'] is True
    pin_key='historicalOriginal654' if expected_arm=='historical' else 'modernRecordedActual'
    assert result['validation']['actual']==manifest['expectedPins'][pin_key]
    assert result['validation']['rng']==manifest['expectedRng'][expected_arm]
    assert (result['validation']['weeklyRows'],result['validation']['terminalContexts'],result['validation']['traceRows'])==(417,40,43)
    base=path.parent/'preimages'; values={}
    for kind in KEYS:
        file=base/(kind+'.json')
        artifact=result['artifacts'][str(file)]
        raw=read_pin(file,artifact['sha256'])
        assert len(raw)==artifact['bytes']
        assert artifact['sha256']==result['validation']['actual'][kind]
        values[kind]=json.loads(raw)
    trace=base/'trace.ndjson'
    artifact=result['artifacts'][str(trace)]
    raw=read_pin(trace,artifact['sha256'])
    assert len(raw)==artifact['bytes'] and artifact['sha256']==result['validation']['traceSha256']
    values['trace']=[json.loads(line) for line in raw.splitlines()]
    assert len(values['trace'])==43
    assert [r['week'] for r in values['trace']]==[0,*range(75,115),207,208]
    assert [r['kind'] for r in values['trace']]==['salary',*(['film']*40),'market','market']
    schema=base/'trace-schema.json'
    schema_artifact=result['artifacts'][str(schema)]
    schema_json=json.loads(read_pin(schema,schema_artifact['sha256']))
    assert schema_json['version']=='c0-external-observer/v1' and schema_json['rowCount']==43
    return values

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--route-result',type=Path,required=True)
    parser.add_argument('--route-result-sha256',required=True)
    parser.add_argument('--head',required=True)
    args=parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}',args.head)
    manifest=read_json(R3_MANIFEST,R3_MANIFEST_SHA)
    route=read_json(args.route_result,args.route_result_sha256)
    assert route['package']=='1370-C0-OBSERVER-ROUTE-LAUNCHER-R2'
    assert route['classification']=='EXPLORATORY_NOT_ACCEPTANCE'
    assert route['status']=='FOUR_ROUTES_RECORDED'
    assert route['launcherManifestSha256']==LAUNCHER_MANIFEST_SHA
    assert route['r3ManifestSha256']==R3_MANIFEST_SHA
    assert route['boundHead']==args.head
    assert route['sourceTree']=='13880d9b0ba72aff5d4c5bcf5d12fe682c5de554'
    records=route['routes']
    assert [(r['arm'],r['mode']) for r in records]==ROUTE_ORDER
    assert all(r['launcherParentExit']==r['actualChildExit']==r['recorderChildExit']==0 for r in records)
    verified=[verify_route_record(record,arm,mode,args.head,manifest)
              for record,(arm,mode) in zip(records,ROUTE_ORDER)]
    assert verified[0]['validation']==verified[2]['validation']=={'freshFullTypes':True}
    historical=load_clean(records[1],'historical',manifest,verified[1])
    modern=load_clean(records[3],'modern',manifest,verified[3])
    report={'classification':'OBSERVATIONAL_DIFFERENCES_ONLY_NO_CAUSAL_CLAIM',
            'routeResultSha256':args.route_result_sha256,'boundHead':args.head,
            'historicalOriginalPins':manifest['expectedPins']['historicalOriginal654'],
            'modernRecordedPins':manifest['expectedPins']['modernRecordedActual'],
            'comparisons':{kind:compare_rows(kind,historical[kind],modern[kind]) for kind in (*KEYS,'trace')}}
    print(json.dumps(report,indent=2,sort_keys=True))

if __name__=='__main__': main()
