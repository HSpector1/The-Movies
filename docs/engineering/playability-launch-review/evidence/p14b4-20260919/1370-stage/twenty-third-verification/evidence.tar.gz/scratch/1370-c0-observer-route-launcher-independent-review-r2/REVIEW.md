# Independent static review: C0 observer route launcher r2

**Decision: ACCEPT for one exploratory four-route attempt only.** This review did not run types, Vitest, the game, a recorder, or the heavy-lane wrapper. It does not admit any run result, protected preimage repin, observed acceptance, or 1363 closure.

Reviewed package: `/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-proposal-r2`. Exact SHA-256: `MANIFEST.json` `e911546c5496de661c7fd7e6a195c5ef1e56085e5f6e1e9dbbb3bd91b31cfaa5`; `runner.py` `e5abdee689e48a401aa94160a5b8d57828c15a310d1ee214e5c115f344ec45ea`; literal r3 parent bootstrap `28dc156be965e18621e543414bf501ada54b0022e6bb8b535439080f194f35c2`. This review's separate `RECEIPT.json` SHA-256 is `04e52e498efc073447987bdf184427a0b1ed14c63a89bff4fcf9487ea96ade6c`.

The r1→r2 runner diff changes only proposal/output/review identifiers and environment keys, plus the blocking inventory assertion. The assertion now compares the run-leaf walk to the expected **local** files, `RESULT.json`, and its checksum sidecar. The preceding exact `result['artifacts']` comparison still includes the five external formal files, and the loop still checks every artifact's regular-file status, size and SHA-256. This closes the r1 REFINE without weakening formal membership or hashes. The README diff reflects that correction and the r2 literal caller. The manifest inventory is exactly its three files.

The isolated `python3 -I -B` buffered static check passed with the external manifest pin. A wrong external manifest pin failed before package authentication. The launcher compiles the externally hashed runner byte buffer; it authenticates the complete local inventory before using package-local helpers. Its literal r3 parent bootstrap hashes one r3 runner buffer, manifest and independent receipt before compile/exec. The pinned r3 static acceptance receipt SHA is `90064761badc7203adbb17d30a39310a3078be16699b1ae8cc01574ac224cd24`; r3 manifest and runner pins are unchanged. The r3 parent retains its independently reviewed immutable child bootstrap, exact source/formal/cleanup guards, original historical versus recorded modern pins, and 416 natural ticks/417 weekly records with 40 terminal contexts and 43 trace rows. R2 keeps 300-second types and 600/630-second exploratory clean limits. It attempts historical types → historical clean → modern types → modern clean, passing only SHA-pinned prior admitted results to dependent routes. It requires an externally bound full local/remote HEAD, fixed source tree, clean checkout, fresh outputs, and lane lock matching the invoked wrapper log. It stops and preserves a failure record if any route or audit fails.

At review time, local HEAD and the branch's remote head were both `ec81334589982378032bc21715c23dd09d88f201`, the checkout was clean, and `HEAD:src` was `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`. The proposed run ID below had no occupied launcher leaf, r3 leaf, or formal output. Recheck these facts immediately before execution. The lane lock is an operational ownership check; preserve the wrapper log and `.meta` alongside the route evidence. Independently audit actual child/recorder and cleanup results after execution.

## Exact externally pinned launch

Run from `/Users/zacheryspector/The-Movies-headless-program` as **one** heavy-lane wrapper invocation. This literal command fixes the reviewed manifest, runner, receipt, published HEAD, run ID and log name; if any of these facts changes, stop and obtain new review rather than updating hashes in place.

```bash
bash /Users/zacheryspector/studio-scratch/heavy-queue/lane-run.sh 0 /Users/zacheryspector/studio-scratch/heavy-queue/1370-c0-observer-route-r2-recorded-r1.log python3 -I -B -c 'import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-proposal-r2")
runner=root/"runner.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-independent-review-r2/RECEIPT.json")
manifest_pin="e911546c5496de661c7fd7e6a195c5ef1e56085e5f6e1e9dbbb3bd91b31cfaa5"
runner_pin="e5abdee689e48a401aa94160a5b8d57828c15a310d1ee214e5c115f344ec45ea"
review_pin="04e52e498efc073447987bdf184427a0b1ed14c63a89bff4fcf9487ea96ade6c"
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path and not root.is_symlink()
manifest_bytes=manifest.read_bytes()
assert sha(manifest_bytes)==manifest_pin
code=runner.read_bytes()
assert sha(code)==runner_pin
review_bytes=review.read_bytes()
assert sha(review_bytes)==review_pin
assert json.loads(review_bytes)=={"decision":"ACCEPT","package":"1370-C0-OBSERVER-ROUTE-LAUNCHER-R2","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_pin,"runnerSha256":runner_pin}
os.environ["C0_OBSERVER_LAUNCH_R2_EXTERNAL_MANIFEST_SHA256"]=manifest_pin
os.environ["C0_OBSERVER_LAUNCH_R2_EXTERNAL_REVIEW_SHA256"]=review_pin
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(code,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner),"_EXTERNAL_EXECUTED_LAUNCHER_BYTES":code})' --head ec81334589982378032bc21715c23dd09d88f201 --run-id c0-observer-recorded-r1 --lane-log /Users/zacheryspector/studio-scratch/heavy-queue/1370-c0-observer-route-r2-recorded-r1.log
```
