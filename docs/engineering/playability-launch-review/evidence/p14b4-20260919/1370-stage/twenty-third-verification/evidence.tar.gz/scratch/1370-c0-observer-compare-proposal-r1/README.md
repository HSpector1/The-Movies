# C0 recorded observer comparison, proposal r1

**Static proposal only.** Do not run this comparator while a route is incomplete. It is read-only Python and starts no TypeScript, Vitest, Node, recorder, or game process. It is not an acceptance gate or causal proof. Independent review of this exact comparator and of the completed four-route leaf is required before its output is used for 1363 attribution.

## Immutable inputs before invocation

1. The completed launcher-r2 `RESULT.json` path and its separately recorded SHA-256, plus the full externally bound launch HEAD. The launcher result must say `FOUR_ROUTES_RECORDED` and contain exactly historical types, historical clean, modern types, modern clean in that order. No `FAILURE.json` or partial route can substitute for it. Launcher manifest SHA-256 is fixed at `e911546c5496de661c7fd7e6a195c5ef1e56085e5f6e1e9dbbb3bd91b31cfaa5`.
2. All four r3 `RESULT.json` paths and SHA-256 values carried by that finished launcher result. The tool rereads all four exact result bytes and their sidecars, validates their source HEAD, branch, fixed r3 manifest/runner, successful child and recorder exits, source guards, output/power/disk bounds, cleanup, and hashes every listed artifact. Each path must remain in its original r3 leaf. R3 manifest is `5ffb357efa422989f81e69bee34db24a0d7893ccbc84071ea53d75fdcd3f33d2`; runner is `0b9673246537378822b4be078dfccd61cfefa7ab566d63f623ec88f6147bb72a`.
3. The two clean leaves' exact `trace.ndjson`, `trace-schema.json`, and four JSON preimages, as named and hashed by their r3 result artifact tables. Both schemas must identify `c0-external-observer/v1`; trace identity is one salary row at week 0, film rows at weeks 75–114, and market rows at weeks 207–208. The original 654-T historical pins and the modern recorded actual pins remain separate manifest roles. The later approved aging employment pin `4cffcb410893395f8ee93da2d7d6146f35db2369962fe333e02de8d2fc7c0b58` is not the original historical employment pin.
4. The fixed source identities from the reviewed r3 package: historical production commit `8708d6a98e6eb4ad53e3a54e431c4b40b974f79d`, historical `src` tree `0ee21d8179977aaa0726ffb5d1b2bb2568c9df97`, historical fixture commit `9e58ec9d20fe802a7fb846a951549394c8f97aac`; modern `src` tree `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`. The runtime launch HEAD is an externally supplied documentation checkpoint, not a hardcoded prior HEAD.

Invocation after review and completion:

```bash
python3 -I -B compare.py --route-result /absolute/path/to/RESULT.json --route-result-sha256 <RECORDED_SHA256> --head <FULL_PUBLISHED_LAUNCH_HEAD>
```

The output is JSON on stdout. For each of the four protected arrays and the 43-row trace, it reports first source-order identity difference, first differing field among matched identities, unmatched identities, and bounded examples. Identities include their source-order occurrence counter: settlement `(week,talentId,kind)`, receipts `(week,kind,talentId,studioId)`, employment `(contractId)`, takes `(week,productionId,studioId)`, trace `(kind,week,subject)`. It does not sort source rows, promote a modern pin to historical, infer an internal market decision from a post-settlement empty array, or assign causality to a source commit.

Independent review should verify comparator byte pin and no-write/no-child behavior, full four-receipt gate, exact artifact hashes and original/modern pin roles, occurrence alignment, bounded report semantics, and field paths. Then review its actual output alongside the preserved r3 clean leaves. A changed/unexplained failure, missing protected pin, source drift, timeout, or incomplete route remains a stop, not a comparator pass.
