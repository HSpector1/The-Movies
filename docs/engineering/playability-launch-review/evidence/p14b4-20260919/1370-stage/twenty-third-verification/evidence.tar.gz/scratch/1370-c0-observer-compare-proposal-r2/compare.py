#!/usr/bin/env python3
"""Read-only comparison of completed, externally pinned C0 observer routes."""
import sys
assert sys.flags.isolated, 'isolated Python startup required'
assert isinstance(_EXTERNAL_EXECUTED_COMPARATOR_BYTES, bytes), 'external immutable-buffer execution required'
import argparse
import hashlib
import json
import os
import re
import stat
import types
from collections import defaultdict
from pathlib import Path

ROOT = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-compare-proposal-r2')
PACKAGE = '1370-C0-OBSERVER-COMPARE-R2'
R3 = Path('/Users/zacheryspector/studio-scratch/1370-c0-external-observer-proposal-r3')
R3_MANIFEST = R3 / 'MANIFEST.json'
R3_RUNS = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-recorded-runs-r3')
LAUNCH_RUNS = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launches-r2')
REVIEW = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-compare-independent-review-r2/RECEIPT.json')
FORMAL = Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919')
NODE = '/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node'
R3_MANIFEST_SHA = '5ffb357efa422989f81e69bee34db24a0d7893ccbc84071ea53d75fdcd3f33d2'
LAUNCHER_MANIFEST_SHA = 'e911546c5496de661c7fd7e6a195c5ef1e56085e5f6e1e9dbbb3bd91b31cfaa5'
ROUTE_ORDER = [('historical', 'types'), ('historical', 'clean'), ('modern', 'types'), ('modern', 'clean')]
KEYS = ('settlement', 'receipts', 'employment', 'takes')
SHA = re.compile(r'[0-9a-f]{64}\Z')
sha = lambda data: hashlib.sha256(data).hexdigest()

def safe(path):
    assert path.is_absolute() and str(path) == os.path.abspath(path)
    for part in (path, *path.parents): assert not part.is_symlink(), str(part)

def authenticate_package():
    pin=os.environ.get('C0_OBSERVER_COMPARE_R2_EXTERNAL_MANIFEST_SHA256','')
    assert SHA.fullmatch(pin), 'missing external comparator manifest pin'
    safe(ROOT)
    assert str(ROOT) not in sys.path
    raw=(ROOT/'MANIFEST.json').read_bytes()
    assert sha(raw)==pin
    manifest=json.loads(raw)
    assert manifest['package']==PACKAGE and manifest['status']=='STATIC_PROPOSAL_AWAITING_INDEPENDENT_REVIEW'
    found={}
    for entry in os.scandir(ROOT):
        info=entry.stat(follow_symlinks=False)
        assert stat.S_ISREG(info.st_mode) and info.st_nlink==1, entry.name
        path=Path(entry.path)
        found[entry.name]='self-excluded' if entry.name=='MANIFEST.json' else sha(path.read_bytes())
    assert found==manifest['files'], 'exact comparator inventory mismatch'
    assert (ROOT/'compare.py').read_bytes()==_EXTERNAL_EXECUTED_COMPARATOR_BYTES
    assert sha(_EXTERNAL_EXECUTED_COMPARATOR_BYTES)==manifest['files']['compare.py']
    return manifest

PACKAGE_MANIFEST=authenticate_package()

def load_reviewed_guard():
    safe(R3); safe(R3_MANIFEST)
    manifest=json.loads(read_pin(R3_MANIFEST,R3_MANIFEST_SHA))
    path=R3/'guard_logic.py'; safe(path)
    code=read_pin(path,manifest['packageFiles']['guard_logic.py'])
    assert manifest['packageFiles']['guard_logic.py']=='a67eb1a65901db15b9b7a7d45d52ca7fcebb1f7be23b09e78a35fa7ff2dd33ef'
    module=types.ModuleType('reviewed_c0_guard_logic')
    module.__file__=str(path)
    exec(compile(code,str(path),'exec'),module.__dict__)
    return manifest,module

def verify_compare_review():
    pin=os.environ.get('C0_OBSERVER_COMPARE_R2_EXTERNAL_REVIEW_SHA256','')
    assert SHA.fullmatch(pin), 'missing external comparator review pin'
    receipt=read_json(REVIEW,pin)
    assert receipt=={'decision':'ACCEPT','package':PACKAGE,
                     'classification':'OBSERVATIONAL_DIFFERENCES_ONLY_NO_CAUSAL_CLAIM',
                     'manifestSha256':os.environ['C0_OBSERVER_COMPARE_R2_EXTERNAL_MANIFEST_SHA256'],
                     'comparatorSha256':PACKAGE_MANIFEST['files']['compare.py']}

def read_pin(path, pin):
    safe(path)
    assert SHA.fullmatch(pin)
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == pin, str(path)
    return data

def read_json(path, pin):
    return json.loads(read_pin(path, pin))

def identity(kind, row):
    if kind == 'settlement':
        assert isinstance(row, list) and len(row) == 7
        return (row[2], row[3], row[1])
    assert isinstance(row, dict)
    if kind == 'receipts': return tuple(row[key] for key in ('week', 'kind', 'talentId', 'studioId'))
    if kind == 'employment': return (row['contractId'],)
    if kind == 'takes': return tuple(row[key] for key in ('week', 'productionId', 'studioId'))
    if kind == 'trace':
        base = (row['kind'], row['week'])
        return base + ((row['contractId'],) if row['kind'] == 'salary' else
                       (row['productionId'],) if row['kind'] == 'film' else (row['talentId'],))
    raise AssertionError(kind)

def label_rows(kind, rows):
    assert isinstance(rows, list)
    occurrence = defaultdict(int)
    labeled = []
    for index, row in enumerate(rows):
        key = identity(kind, row)
        count = occurrence[key]
        occurrence[key] += 1
        labeled.append((json.dumps([*key, count], separators=(',', ':')), index, row))
    assert len({label for label, _, _ in labeled}) == len(labeled)
    return labeled

def first_field(left, right, path='$'):
    if type(left) is not type(right): return {'path':path, 'historical':left, 'modern':right}
    if isinstance(left, dict):
        for key in sorted(set(left) | set(right)):
            next_path = path + '.' + key
            if key not in left: return {'path':next_path, 'historical':'<absent>', 'modern':right[key]}
            if key not in right: return {'path':next_path, 'historical':left[key], 'modern':'<absent>'}
            found = first_field(left[key], right[key], next_path)
            if found: return found
    elif isinstance(left, list):
        for i in range(min(len(left),len(right))):
            found = first_field(left[i],right[i],path+'['+str(i)+']')
            if found: return found
        if len(left) != len(right): return {'path':path+'.length','historical':len(left),'modern':len(right)}
    elif left != right: return {'path':path, 'historical':left, 'modern':right}
    return None

def compare_rows(kind, historical, modern):
    h = label_rows(kind, historical); m = label_rows(kind, modern)
    hd={label:(index,row) for label,index,row in h}; md={label:(index,row) for label,index,row in m}
    common=set(hd)&set(md)
    changed=[]
    for label,index,row in h:
        if label in common:
            field=first_field(row,md[label][1])
            if field: changed.append({'identityOccurrence':label,'historicalIndex':index,'modernIndex':md[label][0],**field})
    hs=[label for label,_,_ in h]; ms=[label for label,_,_ in m]
    order=next(({'index':i,'historical':hs[i] if i<len(hs) else '<end>',
                 'modern':ms[i] if i<len(ms) else '<end>'}
                for i in range(max(len(hs),len(ms))) if i>=len(hs) or i>=len(ms) or hs[i]!=ms[i]),None)
    return {'historicalRows':len(h),'modernRows':len(m),'firstSourceOrderDifference':order,
            'firstMatchedFieldDifference':changed[0] if changed else None,
            'changedMatchedCount':len(changed),'changedMatchedSample':changed[:10],
            'historicalOnly':[label for label,_,_ in h if label not in md][:20],
            'modernOnly':[label for label,_,_ in m if label not in hd][:20],
            'historicalOnlyCount':sum(label not in md for label,_,_ in h),
            'modernOnlyCount':sum(label not in hd for label,_,_ in m)}

def command_for(mode,arm,out):
    assert arm in ('historical','modern')
    if mode=='types': return [NODE,'node_modules/typescript/bin/tsc','--noEmit','-p','tsconfig.json']
    assert mode=='clean'
    return [NODE,'node_modules/vitest/vitest.mjs','run','--config','vitest.preimage.config.ts',
            '--maxWorkers','1','--minWorkers','1','--no-file-parallelism','--reporter=verbose',
            '--reporter=json','--outputFile.json='+str(out/'vitest.json')]

def verify_route_record(record, expected_arm, expected_mode, head, manifest, guard, run_id):
    assert record['arm']==expected_arm and record['mode']==expected_mode
    path=Path(record['path'])
    out=R3_RUNS/(expected_arm+'-'+expected_mode+'-'+run_id)
    assert path==out/'RESULT.json'
    safe(out)
    result=read_json(path,record['sha256'])
    assert result['package']=='1370-C0-EXTERNAL-OBSERVER-R3'
    assert result['classification']=='EXPLORATORY_NOT_ACCEPTANCE' and result['accepted'] is True
    assert result['arm']==expected_arm and result['mode']==expected_mode
    assert result['pins']['head']==result['pins']['originHead']==head
    assert result['pins']['branch']=='refs/heads/wip/headless-program-20260916-ts'
    assert result['pins']['manifestSha256']==R3_MANIFEST_SHA
    assert result['pins']['runnerSha256']==manifest['runnerSha256']
    assert result['seed']==manifest['seed'] and result['pins']['horizon']==416
    assert result['pins']['arm']==expected_arm and result['pins']['package']=='1370-C0-EXTERNAL-OBSERVER-R3'
    assert result['pins']['seed']==manifest['seed']
    assert (result['pins']['testTimeoutSeconds'],result['pins']['outerTimeoutSeconds'])==(600,630)
    assert result['pins']['entrypoints']==manifest['entrypoints']
    assert result['pins']['diagnosticSha256']==manifest['diagnosticSha256']
    assert result['pins']['childBootstrapSha256']==manifest['childBootstrapSha256']
    arm_file_pin=sha(json.dumps(manifest['arms'][expected_arm]['files'],sort_keys=True).encode())
    assert result['pins']['armFilePinsSha256']==arm_file_pin
    assert result['actualChildExit']==result['recorderChildExit']==result['recorderStatus']==0
    assert result['allGuardsExact'] and result['livePostflightExact'] and not result['timedOut']
    assert not result['reportingErrors'] and result['powerPostflightError'] is None
    assert result['outputBoundExact'] and result['diskReservePostflight']
    assert not result['outputLimitExceeded'] and not result['diskReserveBreached']
    group=result['processGroup']
    assert group['cleanupVerified'] and group['noSurvivors'] and group['leaderReaped'] and not group['errors']
    assert result['staticReviewSha256']=='90064761badc7203adbb17d30a39310a3078be16699b1ae8cc01574ac224cd24'
    expected_command=command_for(expected_mode,expected_arm,out)
    safe(FORMAL)
    guard.assert_receipt_integrity(result,result['pins'],expected_command,expected_arm,expected_mode,path,FORMAL)
    assert record['validation']==result['validation']
    assert record['actualChildExit']==result['actualChildExit']
    assert record['recorderChildExit']==result['recorderChildExit']
    return result

def load_clean(record, expected_arm, manifest, result, guard):
    assert record['arm']==expected_arm and record['mode']=='clean'
    path=Path(record['path'])
    assert result['validation']['allPinsMatch'] is True
    pin_key='historicalOriginal654' if expected_arm=='historical' else 'modernRecordedActual'
    assert result['validation']['actual']==manifest['expectedPins'][pin_key]
    assert result['validation']['rng']==manifest['expectedRng'][expected_arm]
    assert (result['validation']['weeklyRows'],result['validation']['terminalContexts'],result['validation']['traceRows'])==(417,40,43)
    base=path.parent/'preimages'; values={}
    validated=guard.validate_preimages(base,manifest['expectedPins'][pin_key],manifest['expectedRng'][expected_arm],manifest['maxRunOutputBytes'])
    assert result['validation']==validated
    for kind in KEYS:
        file=base/(kind+'.json')
        artifact=result['artifacts'][str(file)]
        raw=read_pin(file,artifact['sha256'])
        assert len(raw)==artifact['bytes']
        assert artifact['sha256']==result['validation']['actual'][kind]
        values[kind]=json.loads(raw)
    trace=base/'trace.ndjson'
    artifact=result['artifacts'][str(trace)]
    raw=read_pin(trace,artifact['sha256'])
    assert len(raw)==artifact['bytes'] and artifact['sha256']==result['validation']['traceSha256']
    values['trace']=[json.loads(line) for line in raw.splitlines()]
    assert len(values['trace'])==43
    assert [r['week'] for r in values['trace']]==[0,*range(75,115),207,208]
    assert [r['kind'] for r in values['trace']]==['salary',*(['film']*40),'market','market']
    assert all(r['schema']=='c0-external-observer/v1' for r in values['trace'])
    assert values['trace'][0]['contractId']=='studio-aca408ec-r01:contract:person-studio-aca408ec-r01-0:0'
    assert len(values['trace'][0]['initialEmployment'])==24
    assert all(r['productionId']=='studio-aca408ec-r01:film:10' for r in values['trace'][1:41])
    assert all(r['talentId']=='person-studio-aca408ec-r01-0' for r in values['trace'][41:])
    schema=base/'trace-schema.json'
    schema_artifact=result['artifacts'][str(schema)]
    schema_json=json.loads(read_pin(schema,schema_artifact['sha256']))
    assert schema_json['version']=='c0-external-observer/v1' and schema_json['rowCount']==43
    assert [r['kind'] for r in schema_json['rows']]==['salary','film','market']
    return values

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--static-check',action='store_true')
    parser.add_argument('--route-result',type=Path)
    parser.add_argument('--route-result-sha256')
    parser.add_argument('--head')
    args=parser.parse_args()
    manifest,guard=load_reviewed_guard()
    if args.static_check:
        assert args.route_result is None and args.route_result_sha256 is None and args.head is None
        print('STATIC_CHECK_PASS:'+os.environ['C0_OBSERVER_COMPARE_R2_EXTERNAL_MANIFEST_SHA256'])
        return
    verify_compare_review()
    assert args.route_result and args.route_result_sha256 and args.head
    assert re.fullmatch(r'[0-9a-f]{40}',args.head)
    assert args.route_result.name=='RESULT.json'
    assert args.route_result.parent.parent==LAUNCH_RUNS
    run_id=args.route_result.parent.name
    assert re.fullmatch(r'[a-z0-9-]+',run_id)
    safe(args.route_result.parent); safe(LAUNCH_RUNS)
    expected_launch_files={'RESULT.json'}|{arm+'-'+mode+suffix for arm,mode in ROUTE_ORDER
                                              for suffix in ('.stdout.txt','.stderr.txt')}
    assert {p.name for p in args.route_result.parent.iterdir()}==expected_launch_files
    assert all(p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
               for p in args.route_result.parent.iterdir())
    route=read_json(args.route_result,args.route_result_sha256)
    assert route['package']=='1370-C0-OBSERVER-ROUTE-LAUNCHER-R2'
    assert route['classification']=='EXPLORATORY_NOT_ACCEPTANCE'
    assert route['status']=='FOUR_ROUTES_RECORDED'
    assert route['launcherManifestSha256']==LAUNCHER_MANIFEST_SHA
    assert route['r3ManifestSha256']==R3_MANIFEST_SHA
    assert route['boundHead']==args.head
    assert route['sourceTree']=='13880d9b0ba72aff5d4c5bcf5d12fe682c5de554'
    records=route['routes']
    assert [(r['arm'],r['mode']) for r in records]==ROUTE_ORDER
    assert all(r['launcherParentExit']==r['actualChildExit']==r['recorderChildExit']==0 for r in records)
    verified=[verify_route_record(record,arm,mode,args.head,manifest,guard,run_id)
              for record,(arm,mode) in zip(records,ROUTE_ORDER)]
    assert verified[0]['validation']==verified[2]['validation']=={'freshFullTypes':True}
    historical=load_clean(records[1],'historical',manifest,verified[1],guard)
    modern=load_clean(records[3],'modern',manifest,verified[3],guard)
    report={'classification':'OBSERVATIONAL_DIFFERENCES_ONLY_NO_CAUSAL_CLAIM',
            'routeResultSha256':args.route_result_sha256,'boundHead':args.head,
            'historicalOriginalPins':manifest['expectedPins']['historicalOriginal654'],
            'modernRecordedPins':manifest['expectedPins']['modernRecordedActual'],
            'comparisons':{kind:compare_rows(kind,historical[kind],modern[kind]) for kind in (*KEYS,'trace')}}
    print(json.dumps(report,indent=2,sort_keys=True))

if __name__=='__main__': main()
