#!/usr/bin/env python3
"""Read-only package/source guard; no simulation."""
import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/zacheryspector/The-Movies-headless-program')
FROZEN = Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/C0/tree')
HIST = '8708d6a98e6eb4ad53e3a54e431c4b40b974f79d'
EVIDENCE = '9e58ec9d20fe802a7fb846a951549394c8f97aac'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def inventory():
    found = {}
    def visit(folder):
        for entry in os.scandir(folder):
            path = Path(entry.path)
            relative = path.relative_to(ROOT).as_posix()
            mode = entry.stat(follow_symlinks=False).st_mode
            if stat.S_ISDIR(mode):
                found[relative] = {'kind': 'directory'}
                visit(path)
            elif stat.S_ISLNK(mode):
                assert relative in ('arms/historical/tree/node_modules', 'arms/modern/tree/node_modules'), relative
                target = os.readlink(path)
                assert target == '/Users/zacheryspector/The-Movies-headless-program/node_modules'
                found[relative] = {'kind': 'symlink', 'target': target}
            elif stat.S_ISREG(mode):
                assert entry.stat(follow_symlinks=False).st_nlink == 1, relative
                found[relative] = {'kind': 'manifest'} if relative == 'MANIFEST.json' else {'kind': 'file', 'sha256': digest(path.read_bytes())}
            else:
                raise AssertionError(('unexpected package object', relative))
    visit(ROOT)
    return found

def check():
    m = json.loads((ROOT / 'MANIFEST.json').read_text())
    baseline_path = Path('/Users/zacheryspector/studio-scratch/1369-c0-preimage-replay-proposal-r7/MANIFEST.json')
    assert digest(baseline_path.read_bytes()) == m['baselineR7ManifestSha256'] == '9fc209f9fbf0e0240c404383f4b08338c9a16902d1cacc89600ff80a538038ae'
    baseline = json.loads(baseline_path.read_text())
    assert inventory() == m['objectInventory'], 'exact package object inventory mismatch'
    assert m['package'] == '1370-C0-EXTERNAL-OBSERVER-R3'
    assert m['status'] == 'EXECUTABLE_ONLY_AFTER_INDEPENDENT_R3_REVIEW'
    assert m['classification'] == 'EXPLORATORY_NOT_ACCEPTANCE'
    assert (m['testTimeoutSeconds'], m['outerTimeoutSeconds']) == (600, 630)
    assert m['maxRunOutputBytes'] == 268435456 and m['minimumFreeBytes'] == 3 * 1024**3
    present = {p.name for p in ROOT.iterdir() if p.is_file() and p.name != 'MANIFEST.json'}
    assert present == set(m['packageFiles']), (sorted(present - set(m['packageFiles'])), sorted(set(m['packageFiles']) - present))
    for relative, pin in m['packageFiles'].items():
        assert digest((ROOT / relative).read_bytes()) == pin, relative
    assert m['historicalSourceCommit'] == HIST
    assert m['historicalTestCommit'] == EVIDENCE
    assert m['seed'] == 'p13a-core-causal-01' and m['horizon'] == 416
    assert digest((REPO / m['trace']['path']).read_bytes()) == m['trace']['sha256']
    assert digest((REPO / m['raw654']['path']).read_bytes()) == m['raw654']['sha256']
    assert digest((ROOT / 'diagnostic.test.ts').read_bytes()) == m['diagnosticSha256']
    assert digest((ROOT / 'runner.py').read_bytes()) == m['runnerSha256']
    assert digest((ROOT / 'guard_logic.py').read_bytes()) == m['guardLogicSha256']
    raw = json.loads((REPO / m['raw654']['path']).read_text())
    original = next(row for row in raw if row['seed'] == m['seed'])
    assert m['expectedPins']['historicalOriginal654'] == {
        'settlement': original['settlementDigest'], 'receipts': original['receiptsDigest'],
        'employment': original['employmentDigest'], 'takes': original['takesDigest']}
    modern_data = json.loads(Path(m['modernRecordedData']['path']).read_text())
    assert digest(Path(m['modernRecordedData']['path']).read_bytes()) == m['modernRecordedData']['sha256']
    assert m['expectedPins']['modernRecordedActual'] == {key: modern_data['actualPins'][key] for key in ('settlement', 'receipts', 'employment', 'takes')}
    assert m['currentApprovedEmploymentPinNotHistorical'] == '4cffcb410893395f8ee93da2d7d6146f35db2369962fe333e02de8d2fc7c0b58'
    expressions = (
        '[r.eventId, r.kind, r.week, r.talentId, r.studioId, r.reasons, r.dropped]',
        'sha(JSON.stringify(state.talentMarket.receipts))',
        'sha(JSON.stringify(state.hollywood!.employment))',
        'sha(JSON.stringify(state.firstTakes))',
    )
    for arm in ('historical', 'modern'):
        tree = ROOT / 'arms' / arm / 'tree'
        record = m['arms'][arm]
        assert set(record['files']) == set(baseline['arms'][arm]['files'])
        assert {name: pin for name, pin in record['files'].items() if name != 'tests/preimage-diagnostic.test.ts'} == {
            name: pin for name, pin in baseline['arms'][arm]['files'].items() if name != 'tests/preimage-diagnostic.test.ts'}
        actual = {str(p.relative_to(tree)) for p in tree.rglob('*') if p.is_file() and p.name != 'node_modules'}
        assert actual == set(record['files']), (arm, sorted(actual - set(record['files'])), sorted(set(record['files']) - actual))
        for relative, pin in record['files'].items():
            p = tree / relative
            assert not p.is_symlink() and digest(p.read_bytes()) == pin, (arm, relative)
            if relative.startswith('src/'):
                origin = (subprocess.check_output(['git', 'show', HIST + ':' + relative], cwd=REPO)
                          if arm == 'historical' else (FROZEN / relative).read_bytes())
                assert digest(origin) == pin, (arm, relative, 'origin')
        assert (tree / 'tests/preimage-diagnostic.test.ts').read_bytes() == (ROOT / 'diagnostic.test.ts').read_bytes()
        protected = (tree / 'tests/bridge-p14b5-relationships.test.ts').read_text()
        assert all(expression in protected for expression in expressions), (arm, 'original expressions')
        if arm == 'historical':
            assert all(original[key] in protected for key in ('settlementDigest', 'receiptsDigest', 'employmentDigest', 'takesDigest'))
            for relative in ('tests/helpers/p14b2-fixtures.ts', 'tests/bridge-p14b5-relationships.test.ts'):
                origin = subprocess.check_output(['git', 'show', EVIDENCE + ':' + relative], cwd=REPO)
                assert digest(origin) == record['files'][relative]
        else:
            source_pins = json.loads((FROZEN.parent / 'SOURCE-PINS.json').read_text())
            for relative, pin in source_pins.items():
                assert record['files'][relative] == pin, (arm, relative, 'frozen pin')
    fixture = 'tests/contracts/_contractFixtures.ts'
    fixture_pin = '7554a6b11f0756c7cd286a7732ab888757a129fe0d9f10657c93c4d214f10de2'
    assert all(m['arms'][arm]['files'][fixture] == fixture_pin for arm in ('historical', 'modern'))
    assert digest(subprocess.check_output(['git', 'show', HIST + ':' + fixture], cwd=REPO)) == fixture_pin
    assert digest((REPO / fixture).read_bytes()) == fixture_pin
    assert m['arms']['historical']['files']['src/harness/p13a/fixtures.ts'] == m['arms']['modern']['files']['src/harness/p13a/fixtures.ts']
    test = (ROOT / 'diagnostic.test.ts').read_text()
    assert "const seed = 'p13a-core-causal-01'" in test and 'const endWeek = 416' in test
    assert 'state = tick(state)' in test and '}, 600_000)' in test
    for arm in ('historical', 'modern'):
        config = (ROOT / 'arms' / arm / 'tree/vitest.preimage.config.ts').read_text()
        assert 'testTimeout: 600_000' in config
    print('STATIC_CHECK_PASS: two isolated arms, identical diagnostic, exact source origins, 416-week seed')

if __name__ == '__main__':
    check()
