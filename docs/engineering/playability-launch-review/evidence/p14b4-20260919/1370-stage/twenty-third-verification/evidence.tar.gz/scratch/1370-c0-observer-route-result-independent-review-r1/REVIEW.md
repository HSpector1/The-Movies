# Independent audit: C0 observer four-route exploratory result

**Decision: ACCEPT_EXPLORATORY_EVIDENCE_ONLY.** This admits the exact recorded four-route result for trace analysis. It is not a causal explanation, protected preimage repin, 1363 observed acceptance, or native gameplay acceptance. No heavy command was run during this read-only audit.

The launcher `RESULT.json` at `/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launches-r2/c0-observer-recorded-r1/RESULT.json` hashes to `9622b578c516c12289cd43016aeb3315bbd4cb5aa636e2235a8ef823a4f2bf9a`. It records `EXPLORATORY_NOT_ACCEPTANCE`, bound HEAD `ec81334589982378032bc21715c23dd09d88f201`, source tree `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`, launcher manifest `e911546c5496de661c7fd7e6a195c5ef1e56085e5f6e1e9dbbb3bd91b31cfaa5`, and independently accepted r3 observer manifest `5ffb357efa422989f81e69bee34db24a0d7893ccbc84071ea53d75fdcd3f33d2`.

I independently rehashed all four route `RESULT.json` files and their exact artifact rosters, including five formal files per route outside each run leaf. All artifact size/SHA entries and leaf/sidecar membership match. The sequence and RESULT hashes are:

| Route | RESULT SHA-256 | Artifacts |
| --- | --- | ---: |
| historical types | `4d48e8deb2586869e104d9ba7a01e282e87fc0479ebe2012c7787163ba42ef82` | 12 |
| historical clean | `f7ad1f2c3642c8cc7025c3b853070ea0c546215292155d13ae8eb4ecb51239b4` | 22 |
| modern types | `8e23019c8a4dbbe3343b045c68ae863e9f75ec36bfd52b89bd16d39e6a61969d` | 12 |
| modern clean | `a81b07a8b089b9dbd9f9292d622451b19afb485d443f6d0153345a1bedfe6521` | 22 |

Each actual child, recorder child, recorder wrapper and launcher parent exit is zero. Each route reports accepted with exact guards, live source postflight, output and disk bounds, no timeout, no reporting or power errors, and process-group cleanup verified with no survivors. Formal record/postflight files for each route independently state fixed source, exact guards and HEAD, and zero exit. Historical clean matches the r3 `historicalOriginal654` four preimage digests; modern clean matches `modernRecordedActual` four digests. Both match their pinned RNG and have 417 weekly rows, 40 terminal contexts and 43 observer trace rows; I counted each NDJSON file and verified its trace SHA. Types routes report fresh full types. Binding receipts follow the exact dependency chain: historical clean uses historical types SHA; both modern routes use historical clean SHA; modern clean uses modern types SHA.

The heavy-lane `.meta` records start and `end, exit 0`; the wrapper log prints the launcher result SHA. The lane lock has been released. Local and remote branch HEAD remain `ec81334589982378032bc21715c23dd09d88f201`; `HEAD:src` remains `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`. The working tree has exactly the twenty new formal evidence files as untracked objects and no tracked modifications. These formal files are part of the hashed run evidence, so their presence is expected; preserve them for the checkpoint.

This result establishes that the original historical and recorded modern full-preimage routes replayed under the external observer without changing their pinned digests. Interpretation of the 43 trace rows requires a separate comparison and independent review. No protected C0 digest may be repinned from this exploratory result alone.
