# C0 recorded observer comparison, proposal r2

**Static proposal awaiting independent review.** R1 is preserved as REFINE. R2 is read-only Python; it starts no TypeScript, Vitest, Node, recorder, game, or other subprocess. Do not run it against the recorded route until the exact r2 bytes receive an independent static ACCEPT receipt and the launcher route is complete. Its output is observational differences, not acceptance or a causal verdict.

R2 corrects the r1 review findings. It authenticates its own three-file package against an external manifest SHA before executing package logic. A trusted caller must hash the same immutable `compare.py` byte buffer before compiling and executing it. At runtime it also checks an externally pinned independent r2 review receipt. It reads the r3 `guard_logic.py` bytes only after verifying the fixed r3 manifest and exact helper hash, then compiles that verified buffer in an isolated module. There is no mutable path import.

The completed launcher-r2 `RESULT.json` path must be beneath `/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launches-r2/<run-id>/RESULT.json`, with its SHA supplied independently by the caller. The frozen launcher does not create a RESULT sidecar; the external SHA is its immutable authority. The comparator requires exact launcher leaf membership: one RESULT plus eight route stdout/stderr logs. It requires the result status `FOUR_ROUTES_RECORDED`, externally bound full HEAD, source tree `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`, launcher manifest `e911546c5496de661c7fd7e6a195c5ef1e56085e5f6e1e9dbbb3bd91b31cfaa5`, and exactly historical types → historical clean → modern types → modern clean. It rereads all four r3 RESULT bytes at the route-recorded SHA values and checks their exact fixed run-root/leaf names and checksum sidecars.

For every r3 route the comparator invokes the pinned r3 receipt integrity logic. That checks the complete local plus five external formal artifact-key set and hashes, exact local inventory, no symlinks, binding/LAUNCH/CHILD agreement, preflight HEAD/remote/index/stage, recorder source start/end, postflight guards and formal raw/patch hashes, command/timeouts, child exits, process-group cleanup, and source/power/disk/output gates. The comparator adds fixed command, arm-file inventory digest, package/runner/entrypoint/diagnostic pins, branch, HEAD and result-to-launcher summary equality. For both clean routes it invokes the pinned r3 full preimage validator, which checks the final, 417 weekly, all terminal contexts, 43 trace rows and schema, four protected arrays, append-only invariants, original or modern pin role, and RNG. The later aging-era employment pin remains separate from the original 654-T historical employment pin.

Source identities remain those fixed in r3: historical production commit `8708d6a98e6eb4ad53e3a54e431c4b40b974f79d`, historical `src` tree `0ee21d8179977aaa0726ffb5d1b2bb2568c9df97`, historical fixture commit `9e58ec9d20fe802a7fb846a951549394c8f97aac`; modern `src` tree `13880d9b0ba72aff5d4c5bcf5d12fe682c5de554`. The runtime HEAD remains externally supplied.

After admission, each of the four protected arrays and the 43-row trace is compared by stable identity plus source-order occurrence. It reports first order difference, first matched-row field difference, unmatched identities and bounded examples. No sorting or repinning occurs. Internal market decisions marked `unobserved` in the equal-source trace remain ambiguous.

The trusted launcher must use literal externally supplied manifest, comparator, and independent review-receipt SHA values; never calculate authority pins from mutable files at run time. Its bootstrap should execute:

```python
import hashlib, os, sys
from pathlib import Path
root=Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-compare-proposal-r2')
code=(root/'compare.py').read_bytes()
assert hashlib.sha256(code).hexdigest() == '<FROZEN_COMPARATOR_SHA256>'
assert hashlib.sha256((root/'MANIFEST.json').read_bytes()).hexdigest() == '<FROZEN_MANIFEST_SHA256>'
os.environ['C0_OBSERVER_COMPARE_R2_EXTERNAL_MANIFEST_SHA256']='<FROZEN_MANIFEST_SHA256>'
os.environ['C0_OBSERVER_COMPARE_R2_EXTERNAL_REVIEW_SHA256']='<INDEPENDENT_REVIEW_RECEIPT_SHA256>'
sys.argv=[str(root/'compare.py'), '--route-result', '<COMPLETED_LAUNCH_RESULT_PATH>',
          '--route-result-sha256', '<EXTERNALLY_RECORDED_RESULT_SHA256>', '--head', '<FULL_LAUNCH_HEAD>']
exec(compile(code,str(root/'compare.py'),'exec'),
     {'__name__':'__main__','__file__':str(root/'compare.py'),
      '_EXTERNAL_EXECUTED_COMPARATOR_BYTES':code})
```

Run that bootstrap under `python3 -I -B`. Before review, `--static-check` can be substituted for the route arguments; it authenticates only the comparator package and fixed r3 helper and does not read route outputs. The independent reviewer must inspect exact package pins, external bootstrap, admission coverage, occurrence matching and bounded report, then issue a receipt at `/Users/zacheryspector/studio-scratch/1370-c0-observer-compare-independent-review-r2/RECEIPT.json` containing exactly `decision=ACCEPT`, `package=1370-C0-OBSERVER-COMPARE-R2`, `classification=OBSERVATIONAL_DIFFERENCES_ONLY_NO_CAUSAL_CLAIM`, and the frozen manifest/comparator SHA values.
