# 1370 C0 external observer, proposal r3

**Frozen scratch package awaiting independent static review. Do not run types, clean, Vitest, the recorder, or any heavy child before an independent ACCEPT receipt.** The package copies the reviewed r7 historical and modern production arms byte-for-byte. Only `tests/preimage-diagnostic.test.ts` is replaced, identically in both arms, with the original four preimage writes plus a read-only `trace.ndjson`. The copied `node_modules` links resolve to the live repository's dependency tree. No production source behavior or repository file is changed.

This is `EXPLORATORY_NOT_ACCEPTANCE`, seed `p13a-core-causal-01`, 416 natural ticks, 417 weekly snapshots, four full original preimages, 40 terminal contexts, one Vitest test, 600-second test/630-second recorder and 300-second types cap. The original 300/330 observed acceptance route retains its own result. The original 654-T historical pins, separately approved aging-era employment pin, and modern actual pins are distinct fields in `MANIFEST.json`. A mismatch or timeout fails.

The trace has exactly 43 rows: one week-0 salary quote and 24 starting employment terms; film 10 public-state snapshots on weeks 75 through 114 inclusive; and the first market subject's publicly persisted case, proposals, promises, employment and studio account state at weeks 207 and 208. Package-search refusal, freeze predicate, descriptor bands and pairwise order are deliberately `unobserved`. They require a separately reviewed, instrumented tier and are not inferred from terminal records. The diagnostic imports only read-only offer, worldgen salary, derived RNG stream and tuning functions and never writes to `GameState`.

R1 remains frozen with independent static `REFINE` (review SHA-256 `89da4adfeb0227a21e5771b37f3e5e916c389e84905b46aeddecad7dce133e86`): the recorder launched a mutable runner path, and package helpers were re-read after hashing. R2 is also `REFINE` because its manifest drifted from the SHA supplied for independent review (`03f1cd6519714674df1131720e6d3d60a75a61fa5fa8d3bd35ed994fabf7d621` to `0dd3f0bd0e19d1f6d141aa188642cd2f19bd02297cd20ba767c351cbca464a1a`). R3 requires an **external isolated `python3 -I -B -c` bootstrap in both parent and recorder child**. Each reads the manifest, runner and independent review receipt once, checks the externally issued SHA pins and receipt shape, then compiles and executes the exact verified runner byte buffer. Direct `python3 runner.py` fails because it lacks `_EXTERNAL_EXECUTED_RUNNER_BYTES`. The runner inventories the entire package before loading helpers; `guard_logic.py` and `self_check.py` execute from those same verified byte buffers. The external Python source guard and cleanup helper likewise execute from buffers captured and verified in one read, so a path swap after the check cannot change code executed. The repo's Node recorder remains its separately pinned external entrypoint; its recorded child command contains the immutable Python bootstrap and is checked by SHA and exact arguments.

R3 retains published clean HEAD/remote/source guards, fixed Node/toolchain, AC and disk checks, formal pre/postflight, child and recorder status checks, and process-group cleanup. `guard_logic.py` adds exact trace schema/row validation to all r7 preimage checks. `self_check.py` independently compares each copied `src/` file with its historical Git source, frozen modern source pins and r7 manifest, verifies the genuine fixture and the original protected digest expressions, and checks equal diagnostic bytes in both arms. Full types is required on each arm before its clean; historical clean is required before modern routes.

Before launch, an independent reviewer must issue a fixed `RECEIPT.json` at `/Users/zacheryspector/studio-scratch/1370-c0-observer-independent-review-r3/RECEIPT.json` with exactly `{ "decision": "ACCEPT", "package": "1370-C0-EXTERNAL-OBSERVER-R3", "classification": "EXPLORATORY_NOT_ACCEPTANCE", "manifestSha256": "<frozen manifest SHA>", "runnerSha256": "<frozen runner SHA>" }`. The reviewer must inspect the observer's purity and cross-arm type compatibility, package inventory and bootstrap, old-versus-new diagnostic difference, guard behavior, exact original pins, and failure paths. Static ACCEPT alone never admits a run. A trusted parent must issue a literal external `python3 -I -B -c` bootstrap with the frozen manifest/runner/review SHA values, hash and execute the same runner bytes, and place the verified bytes into `_EXTERNAL_EXECUTED_RUNNER_BYTES`. It sets `C0_OBSERVER_R3_EXTERNAL_MANIFEST_SHA256` plus `C0_OBSERVER_R3_EXTERNAL_REVIEW_SHA256` only after those independent checks. Do not compute authority pins from mutable package bytes at launch time.

The parent command template is below. Replace its three literal SHA placeholders from the frozen r3 manifest, runner and **independently issued** review receipt before execution. `RUN_ARGUMENTS` means the r7-shaped `types` or `clean` arguments with a fresh leaf and exact remote HEAD; it is not a shell variable to expand from mutable package state.

```bash
python3 -I -B -c 'import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1370-c0-external-observer-proposal-r3")
runner=root/"runner.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1370-c0-observer-independent-review-r3/RECEIPT.json")
manifest_pin="<FROZEN_R3_MANIFEST_SHA256>"
runner_pin="<FROZEN_R3_RUNNER_SHA256>"
review_pin="<INDEPENDENT_R3_REVIEW_RECEIPT_SHA256>"
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path and not root.is_symlink()
manifest_bytes=manifest.read_bytes()
assert sha(manifest_bytes)==manifest_pin
code=runner.read_bytes()
assert sha(code)==runner_pin
review_bytes=review.read_bytes()
assert sha(review_bytes)==review_pin
assert json.loads(review_bytes)=={"decision":"ACCEPT","package":"1370-C0-EXTERNAL-OBSERVER-R3","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_pin,"runnerSha256":runner_pin}
os.environ["C0_OBSERVER_R3_EXTERNAL_MANIFEST_SHA256"]=manifest_pin
os.environ["C0_OBSERVER_R3_EXTERNAL_REVIEW_SHA256"]=review_pin
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(code,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner),"_EXTERNAL_EXECUTED_RUNNER_BYTES":code})' RUN_ARGUMENTS
```

No source attribution follows from this package alone. Its result may locate the first visible decision and narrow the candidate map. The original r7 clean RESULT files remain immutable and must be independently rehashed before comparing any new output.
