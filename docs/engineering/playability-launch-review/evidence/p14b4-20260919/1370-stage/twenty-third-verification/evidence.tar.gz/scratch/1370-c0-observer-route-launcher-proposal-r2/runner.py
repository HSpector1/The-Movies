#!/usr/bin/env python3
"""Sequential, externally pinned C0 observer route launcher; never acceptance."""
import sys
assert sys.flags.isolated, 'isolated Python startup required'
assert isinstance(_EXTERNAL_EXECUTED_LAUNCHER_BYTES, bytes), 'execute only externally authenticated launcher bytes'
import argparse, hashlib, json, os, re, stat, subprocess
from pathlib import Path

ROOT = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-proposal-r2')
REPO = Path('/Users/zacheryspector/The-Movies-headless-program')
EVIDENCE = REPO / 'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
R3 = Path('/Users/zacheryspector/studio-scratch/1370-c0-external-observer-proposal-r3')
R3_REVIEW = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-independent-review-r3')
R3_RUNS = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-recorded-runs-r3')
RUNS = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launches-r2')
LANE = Path('/Users/zacheryspector/studio-scratch/heavy-queue/lane-run.sh')
LOCK = Path('/Users/zacheryspector/studio-scratch/HEAVY-LANE-LOCK')
PACKAGE = '1370-C0-OBSERVER-ROUTE-LAUNCHER-R2'
BRANCH = 'refs/heads/wip/headless-program-20260916-ts'
LAUNCH_REVIEW = Path('/Users/zacheryspector/studio-scratch/1370-c0-observer-route-launcher-independent-review-r2/RECEIPT.json')
sha = lambda data: hashlib.sha256(data).hexdigest()

def authenticate_package():
    pin = os.environ.get('C0_OBSERVER_LAUNCH_R2_EXTERNAL_MANIFEST_SHA256', '')
    assert re.fullmatch(r'[0-9a-f]{64}', pin), 'missing external launcher manifest pin'
    assert not ROOT.is_symlink() and str(ROOT) not in sys.path
    raw = (ROOT / 'MANIFEST.json').read_bytes()
    assert sha(raw) == pin, 'external launcher manifest pin mismatch'
    manifest = json.loads(raw)
    assert manifest['package'] == PACKAGE and manifest['status'] == 'EXECUTABLE_ONLY_AFTER_INDEPENDENT_REVIEW'
    found = {}
    buffers = {}
    def walk(folder):
        for entry in os.scandir(folder):
            path = Path(entry.path)
            rel = path.relative_to(ROOT).as_posix()
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISDIR(info.st_mode):
                found[rel] = {'kind': 'directory'}
                walk(path)
            elif stat.S_ISLNK(info.st_mode):
                found[rel] = {'kind': 'symlink', 'target': os.readlink(path)}
            elif stat.S_ISREG(info.st_mode):
                assert info.st_nlink == 1, rel
                content = path.read_bytes()
                found[rel] = {'kind': 'manifest'} if rel == 'MANIFEST.json' else {'kind': 'file', 'sha256': sha(content)}
                buffers[rel] = content
            else:
                raise AssertionError('unexpected package object: ' + rel)
    walk(ROOT)
    assert found == manifest['objectInventory'], 'exact launcher inventory mismatch'
    assert buffers['runner.py'] == _EXTERNAL_EXECUTED_LAUNCHER_BYTES
    assert sha(_EXTERNAL_EXECUTED_LAUNCHER_BYTES) == manifest['runnerSha256']
    return pin, manifest

MANIFEST_PIN, MANIFEST = authenticate_package()

# This literal is part of the launcher runner SHA. It validates one r3 package,
# runner and independently issued receipt byte buffer before executing the
# exact runner bytes. It never uses a mutable import path for r3 code.
R3_PARENT_BOOTSTRAP = '''import hashlib,json,os,sys
from pathlib import Path
assert sys.flags.isolated
root=Path("/Users/zacheryspector/studio-scratch/1370-c0-external-observer-proposal-r3")
runner=root/"runner.py"
manifest=root/"MANIFEST.json"
review=Path("/Users/zacheryspector/studio-scratch/1370-c0-observer-independent-review-r3/RECEIPT.json")
manifest_pin="5ffb357efa422989f81e69bee34db24a0d7893ccbc84071ea53d75fdcd3f33d2"
runner_pin="0b9673246537378822b4be078dfccd61cfefa7ab566d63f623ec88f6147bb72a"
review_pin="90064761badc7203adbb17d30a39310a3078be16699b1ae8cc01574ac224cd24"
sha=lambda data:hashlib.sha256(data).hexdigest()
assert str(root) not in sys.path and not root.is_symlink()
manifest_bytes=manifest.read_bytes()
assert sha(manifest_bytes)==manifest_pin
code=runner.read_bytes()
assert sha(code)==runner_pin
review_bytes=review.read_bytes()
assert sha(review_bytes)==review_pin
assert json.loads(review_bytes)=={"decision":"ACCEPT","package":"1370-C0-EXTERNAL-OBSERVER-R3","classification":"EXPLORATORY_NOT_ACCEPTANCE","manifestSha256":manifest_pin,"runnerSha256":runner_pin}
os.environ["C0_OBSERVER_R3_EXTERNAL_MANIFEST_SHA256"]=manifest_pin
os.environ["C0_OBSERVER_R3_EXTERNAL_REVIEW_SHA256"]=review_pin
sys.argv=[str(runner),*sys.argv[1:]]
exec(compile(code,str(runner),"exec"),{"__name__":"__main__","__file__":str(runner),"_EXTERNAL_EXECUTED_RUNNER_BYTES":code})'''

def read_pinned(path, expected):
    assert path.is_absolute() and not path.is_symlink(), str(path)
    content = path.read_bytes()
    assert sha(content) == expected, str(path)
    return content

def verify_r3():
    r3_manifest = json.loads(read_pinned(R3 / 'MANIFEST.json', MANIFEST['r3']['manifestSha256']))
    read_pinned(R3 / 'runner.py', MANIFEST['r3']['runnerSha256'])
    review = json.loads(read_pinned(R3_REVIEW / 'RECEIPT.json', MANIFEST['r3']['receiptSha256']))
    read_pinned(R3_REVIEW / 'REVIEW.md', MANIFEST['r3']['reviewSha256'])
    read_pinned(LANE, MANIFEST['laneRunnerSha256'])
    assert r3_manifest['package'] == '1370-C0-EXTERNAL-OBSERVER-R3'
    assert (r3_manifest['seed'], r3_manifest['horizon'], r3_manifest['testTimeoutSeconds'], r3_manifest['outerTimeoutSeconds']) == ('p13a-core-causal-01', 416, 600, 630)
    assert (r3_manifest['observerSchema'], r3_manifest['observerRows']) == ('c0-external-observer/v1', 43)
    assert r3_manifest['currentApprovedEmploymentPinNotHistorical'] == '4cffcb410893395f8ee93da2d7d6146f35db2369962fe333e02de8d2fc7c0b58'
    assert review == {'classification':'EXPLORATORY_NOT_ACCEPTANCE','decision':'ACCEPT',
        'manifestSha256':MANIFEST['r3']['manifestSha256'],'package':'1370-C0-EXTERNAL-OBSERVER-R3',
        'runnerSha256':MANIFEST['r3']['runnerSha256']}
    assert sha(R3_PARENT_BOOTSTRAP.encode()) == MANIFEST['r3ParentBootstrapSha256']
    return r3_manifest

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0')).decode().strip()

def verify_head(bound_head):
    assert re.fullmatch(r'[0-9a-f]{40}', bound_head), 'externally bound full HEAD required'
    assert git('rev-parse','HEAD') == bound_head
    assert git('symbolic-ref','HEAD') == BRANCH
    assert git('ls-remote','--exit-code','origin',BRANCH).split() == [bound_head, BRANCH]
    assert git('rev-parse','HEAD:src') == MANIFEST['modernSourceTree']
    return bound_head

def verify_launcher_review():
    pin = os.environ.get('C0_OBSERVER_LAUNCH_R2_EXTERNAL_REVIEW_SHA256','')
    assert re.fullmatch(r'[0-9a-f]{64}', pin), 'missing externally pinned launcher review'
    review = json.loads(read_pinned(LAUNCH_REVIEW, pin))
    assert review == {'decision':'ACCEPT','package':PACKAGE,'classification':'EXPLORATORY_NOT_ACCEPTANCE',
        'manifestSha256':MANIFEST_PIN,'runnerSha256':MANIFEST['runnerSha256']}

def route_paths(arm,mode,run_id):
    tag = arm + '-' + mode + '-' + run_id
    out = R3_RUNS / tag
    stem = '1370-c0-observer-r3-' + tag
    formal = [EVIDENCE / (stem + suffix) for suffix in ('.json','.patch','.txt','-preflight.json','-postflight.json')]
    return out, formal

def require_exclusive(run_id, launch_dir):
    assert not launch_dir.exists(), 'launcher output exists'
    for arm,mode in [('historical','types'),('historical','clean'),('modern','types'),('modern','clean')]:
        out,formal=route_paths(arm,mode,run_id)
        assert not out.exists(), str(out)
        assert all(not path.exists() for path in formal), (arm,mode,'formal output occupied')

def verify_lane(lane_log):
    assert lane_log.is_absolute() and not lane_log.is_symlink()
    assert LOCK.is_file() and not LOCK.is_symlink(), 'single heavy lane lock absent'
    assert LOCK.read_text().startswith('lane-run ' + lane_log.name + ', started '), 'wrong heavy lane owner'

def write_new(path, value):
    with path.open('x') as f:
        json.dump(value,f,indent=2,sort_keys=True)
        f.write('\n')

def stage_args(mode,arm,head,run_id,prior_types=None,historical=None):
    args=[mode,'--arm',arm,'--head',head,'--manifest-sha256',MANIFEST['r3']['manifestSha256'],
        '--self-runner-sha256',MANIFEST['r3']['runnerSha256'],'--leaf',run_id,
        '--static-review-receipt',str(R3_REVIEW/'RECEIPT.json'),
        '--static-review-sha256',MANIFEST['r3']['receiptSha256']]
    if prior_types is not None:
        args += ['--types-receipt',prior_types['path'],'--types-receipt-sha256',prior_types['sha256']]
    if historical is not None:
        args += ['--historical-receipt',historical['path'],'--historical-receipt-sha256',historical['sha256']]
    return args

def audit_result(out,arm,mode,head,r3_manifest):
    path=out/'RESULT.json'
    raw=path.read_bytes()
    result=json.loads(raw)
    assert result['package']=='1370-C0-EXTERNAL-OBSERVER-R3' and result['classification']=='EXPLORATORY_NOT_ACCEPTANCE'
    assert result['mode']==mode and result['arm']==arm and result['accepted'] is True
    assert result['seed']=='p13a-core-causal-01' and result['pins']['head']==head
    assert result['pins']['manifestSha256']==MANIFEST['r3']['manifestSha256']
    assert result['pins']['runnerSha256']==MANIFEST['r3']['runnerSha256']
    assert result['staticReviewSha256']==MANIFEST['r3']['receiptSha256']
    assert result['actualChildExit']==result['recorderChildExit']==result['recorderStatus']==0
    assert result['allGuardsExact'] and result['livePostflightExact'] and not result['timedOut']
    assert result['outputBoundExact'] and result['diskReservePostflight']
    assert not result['outputLimitExceeded'] and not result['diskReserveBreached']
    assert not result['reportingErrors'] and result['powerPostflightError'] is None
    group=result['processGroup']
    assert group['cleanupVerified'] and group['noSurvivors'] and group['leaderReaped'] and not group['errors']
    prefix=arm+'-'+mode+'-'
    assert out.name.startswith(prefix)
    _,formal=route_paths(arm,mode,out.name[len(prefix):])
    local=['binding.json','LAUNCH.json','CHILD.json','stdout.txt','stderr.txt','power.txt','power-post.txt']
    if mode=='clean':
        local+=['vitest.json']
        local+=['preimages/'+name for name in ('final.json','weekly.ndjson','terminal-context.ndjson','trace.ndjson','trace-schema.json')]
        local+=['preimages/'+key+'.json' for key in ('settlement','receipts','employment','takes')]
    required={str(out/name) for name in local}|{str(path) for path in formal}
    assert set(result['artifacts'])==required
    for name,item in result['artifacts'].items():
        p=Path(name)
        assert p.is_file() and not p.is_symlink()
        content=p.read_bytes()
        assert len(content)==item['bytes'] and sha(content)==item['sha256']
    assert {str(p) for p in out.rglob('*') if p.is_file()}=={str(out/name) for name in local}|{str(path),str(out/'RESULT.sha256.json')}
    assert {str(p) for p in out.rglob('*') if p.is_dir()}=={str(out/'preimages')}
    assert all(not p.is_symlink() for p in out.rglob('*'))
    assert json.loads((out/'RESULT.sha256.json').read_text())=={'sha256':sha(raw)}
    if mode=='types':
        assert result['validation']=={'freshFullTypes':True}
    else:
        validation=result['validation']
        target=r3_manifest['expectedPins']['historicalOriginal654' if arm=='historical' else 'modernRecordedActual']
        assert validation['actual']==target and validation['allPinsMatch'] is True
        assert validation['rng']==r3_manifest['expectedRng'][arm]
        assert (validation['weeklyRows'],validation['terminalContexts'],validation['traceRows'])==(417,40,43)
        assert validation['traceSha256']==sha((out/'preimages/trace.ndjson').read_bytes())
    return {'path':str(path),'sha256':sha(raw),'arm':arm,'mode':mode,
            'validation':result['validation'],'actualChildExit':result['actualChildExit'],
            'recorderChildExit':result['recorderChildExit']}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--static-check',action='store_true')
    parser.add_argument('--head')
    parser.add_argument('--run-id')
    parser.add_argument('--lane-log')
    args=parser.parse_args()
    r3_manifest=verify_r3()
    if args.static_check:
        assert args.head is None and args.run_id is None and args.lane_log is None
        print('STATIC_CHECK_PASS:'+MANIFEST_PIN)
        return 0
    verify_launcher_review()
    assert args.head and args.run_id and args.lane_log
    assert re.fullmatch(r'[a-z0-9-]+',args.run_id)
    head=verify_head(args.head)
    lane_log=Path(args.lane_log)
    verify_lane(lane_log)
    assert git('status','--porcelain')=='', 'publish the documentation checkpoint before launch'
    launch_dir=RUNS/args.run_id
    require_exclusive(args.run_id,launch_dir)
    launch_dir.parent.mkdir(exist_ok=True)
    launch_dir.mkdir()
    records=[]
    route=[('historical','types'),('historical','clean'),('modern','types'),('modern','clean')]
    try:
        for arm,mode in route:
            verify_lane(lane_log)
            verify_head(head)
            previous_types=next((r for r in records if r['arm']==arm and r['mode']=='types'),None) if mode=='clean' else None
            previous_hist=next((r for r in records if r['arm']=='historical' and r['mode']=='clean'),None) if arm=='modern' else None
            if mode=='clean': assert previous_types is not None
            if arm=='modern': assert previous_hist is not None
            out,_=route_paths(arm,mode,args.run_id)
            cmd=[sys.executable,'-I','-B','-c',R3_PARENT_BOOTSTRAP,
                 *stage_args(mode,arm,head,args.run_id,previous_types,previous_hist)]
            name=arm+'-'+mode
            with (launch_dir/(name+'.stdout.txt')).open('x') as stdout,(launch_dir/(name+'.stderr.txt')).open('x') as stderr:
                status=subprocess.run(cmd,cwd=REPO,stdout=stdout,stderr=stderr,env=os.environ.copy()).returncode
            assert status==0, (name,'r3 parent exit',status)
            record=audit_result(out,arm,mode,head,r3_manifest)
            record['launcherParentExit']=status
            records.append(record)
            verify_head(head)
        write_new(launch_dir/'RESULT.json',{'package':PACKAGE,'classification':'EXPLORATORY_NOT_ACCEPTANCE',
            'status':'FOUR_ROUTES_RECORDED','boundHead':head,'sourceTree':MANIFEST['modernSourceTree'],
            'launcherManifestSha256':MANIFEST_PIN,'r3ManifestSha256':MANIFEST['r3']['manifestSha256'],
            'routes':records})
        print(json.dumps({'result':str(launch_dir/'RESULT.json'),'sha256':sha((launch_dir/'RESULT.json').read_bytes())}))
        return 0
    except Exception as error:
        write_new(launch_dir/'FAILURE.json',{'package':PACKAGE,'status':'STOP_PRESERVE_FAILURE',
            'boundHead':head,'completed':records,'errorType':type(error).__name__,'error':str(error)})
        raise

if __name__=='__main__':
    sys.exit(main())
