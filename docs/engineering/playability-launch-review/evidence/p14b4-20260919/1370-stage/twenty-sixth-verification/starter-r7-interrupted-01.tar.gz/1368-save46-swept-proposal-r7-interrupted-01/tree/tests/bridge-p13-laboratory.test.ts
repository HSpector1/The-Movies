import { describe, expect, it } from 'vitest'
import { applyActions } from '../src/core/actions.js'
import { generateWorld } from '../src/core/worldgen.js'
import { initializeHollywood } from '../src/core/hollywood.js'
import { commitPlacement } from '../src/core/placement.js'
import { tick } from '../src/core/tick.js'
import { campaignDate } from '../src/core/calendar.js'
import { weeklyBurn } from '../src/core/economyView.js'
import type { GameState } from '../src/core/types.js'
import { laboratoryActionSpecs } from '../bridge/laboratory.ts'
import { industryPage } from '../bridge/industry.ts'
import { BridgeSession } from '../bridge/session.ts'
import { PROTOCOL_VERSION, SCHEMA_ID } from '../bridge/protocol.ts'
import { BRIDGE_SCHEMA } from '../bridge/schema/bridge-schema.ts'
import { parseWireValue } from '../bridge/schema/runtime.ts'
import type { IndustryQuery } from '../bridge/schema/industry-schema.ts'

function laboratory(): GameState {
  const generated = generateWorld('p13-bridge-generated-laboratory')
  let state = initializeHollywood(applyActions({ ...generated, economyEngagedEver: true }, [{ kind: 'activateStudioOperations' }]), 'fresh')
  state = commitPlacement(state, { blueprintId: 'research-laboratory', origin: { gx: 0, gy: 9 } })
  for (let week = 0; week < 12; week++) state = tick(state)
  return state
}
const query = (extra: Partial<IndustryQuery> = {}): IndustryQuery => ({ protocolVersion: PROTOCOL_VERSION, schemaId: SCHEMA_ID,
  type: 'industryQuery', view: 'laboratory', targetId: 'placed-1', page: 0, pageSize: 12,
  lane: 'audienceAwareness', period: 'all', requestId: 'lab-read', sessionId: 'lab-test', expectedStateRevision: 0, ...extra })

describe('P13A Laboratory bridge', () => {
  it('publishes one exact Laboratory with named employment and truthful early-release refusal', () => {
    const state = laboratory()
    const before = JSON.stringify(state)
    const session = new BridgeSession(state, 'lab-test')
    // P13B-S3-T4: the page gained the two `plan-queue-*` companions on this Laboratory,
    // which pushed the two studio-wide sound rows past a 12-row page. The page size is
    // widened by exactly those two rows so this case still reads the same decisions.
    const page = session.industry(query({ pageSize: 14 }))
    expect('laboratory' in page).toBe(true)
    if (!('laboratory' in page) || !page.laboratory) throw new Error('Laboratory page absent')
    expect(parseWireValue(BRIDGE_SCHEMA.$defs.StudioIndustryResponse, page)).toEqual(page)
    expect(page.laboratory.buildingId).toBe('placed-1')
    expect(page.laboratory.seatLabel).toContain('0 of 4')
    const recruit = page.laboratory.actions.find(a => a.id === 'recruit-1-t-sci-00')!
    expect(recruit.enabled).toBe(true)
    expect(recruit.detail).toContain('208-week contract')
    expect(recruit.detail).toContain('$2,000/week')
    expect(recruit.detail).toContain('$1,500/week in studio employment overhead')
    expect(recruit.detail).toContain('weekly commitments rise by $3,500')
    expect(recruit.detail).toContain('This contract ends 1924 · Week 13')
    expect(recruit.detail).toContain('It ends before research opens 1925 · Week 1')
    expect(recruit.detail).toContain('payroll starts now')
    expect(page.laboratory.seatLabel).not.toContain('P13A')
    expect(recruit.intent?.kind).toBe('researchAction')
    const purchase = page.laboratory.actions.find(a => a.id === 'purchase-synchronized-sound')!
    expect(purchase.enabled).toBe(false)
    expect(purchase.disabledReason).toContain('1928 · Week 1')
    expect(purchase.intent).toBeNull()
    expect(JSON.stringify(state)).toBe(before)
  })

  it('rejects wrong building, stale revision and Save As session while keeping output detached', () => {
    const state = laboratory(), session = new BridgeSession(state, 'lab-test')
    expect(session.industry(query({ targetId: 'Research Laboratory' }))).toMatchObject({ accepted: false, reasonCode: 'INVALID_CONTROL' })
    expect(session.industry(query({ expectedStateRevision: 1 }))).toMatchObject({ accepted: false, reasonCode: 'STALE_REVISION' })
    expect(session.industry(query({ sessionId: 'save-as-copy' }))).toMatchObject({ accepted: false, reasonCode: 'SESSION_MISMATCH' })
    const page = session.industry(query())
    if (!('laboratory' in page) || !page.laboratory) throw new Error('Laboratory page absent')
    page.laboratory.scientistLabel = 'A mutated consumer copy'
    const fresh = session.industry(query())
    if (!('laboratory' in fresh) || !fresh.laboratory) throw new Error('Laboratory page absent')
    expect(fresh.laboratory.scientistLabel).not.toBe('A mutated consumer copy')
  })

  it('pages decisions without exposing private Laboratory data in public Industry pages', () => {
    const state = laboratory(), session = new BridgeSession(state, 'lab-test')
    const first = session.industry(query({ pageSize: 2 }))
    if (!('laboratory' in first) || !first.laboratory) throw new Error('Laboratory page absent')
    expect(first.laboratory.actions).toHaveLength(2)
    const next = session.industry(query({ pageSize: 2, page: 1 }))
    if (!('laboratory' in next) || !next.laboratory) throw new Error('Laboratory page absent')
    expect(next.laboratory.actions[0]!.id).not.toBe(first.laboratory.actions[0]!.id)
    expect(session.industry(query({ pageSize: 2, page: 999 }))).toMatchObject({ accepted: false })
    const publicPage = industryPage(state, 'lab-test', 0, query({ view: 'studios', targetId: null }))
    expect(publicPage.laboratory).toBeNull()
    expect(JSON.stringify(publicPage)).not.toContain('scientistLabel')
  })

  it('does not let read-side preflights spend money or invent employment/research history', () => {
    const state = laboratory(), before = JSON.stringify(state)
    const specs = laboratoryActionSpecs(state)
    expect(specs.some(s => s.action.kind === 'installAcousticInstruments' && s.enabled)).toBe(true)
    expect(specs.some(s => s.action.kind === 'recruitScientist' && s.enabled)).toBe(true)
    expect(JSON.stringify(state)).toBe(before)
    expect(state.technology.projects).toHaveLength(0)
    expect(state.talent.some(t => t.role === 'scientist')).toBe(false)
  })

  it('commits the exact named hire once, rejects its stale sibling intent, then assigns the employed Scientist', () => {
    const session = new BridgeSession(laboratory(), 'lab-test')
    const page = session.industry(query())
    if (!('laboratory' in page) || !page.laboratory) throw new Error('Laboratory page absent')
    const recruit = page.laboratory.actions.find(a => a.id === 'recruit-1-t-sci-00')!
    const instruments = page.laboratory.actions.find(a => a.id === 'instruments-1')!
    const weeklyBefore = weeklyBurn(session.gameState)
    const command = { protocolVersion: PROTOCOL_VERSION, schemaId: SCHEMA_ID, type: 'submitIntent' as const,
      commandId: 'hire-once', sessionId: session.sessionId, expectedStateRevision: 0, payload: { intentId: recruit.intent!.intentId } }
    expect(session.command(command).accepted).toBe(true)
    expect(weeklyBurn(session.gameState) - weeklyBefore).toBe(3_500)
    const cash = session.gameState.studio.cash
    expect(session.command(command).accepted).toBe(true)
    expect(session.gameState.studio.cash).toBe(cash)
    expect(session.gameState.talent.filter(t => t.role === 'scientist')).toHaveLength(1)
    expect(session.command({ ...command, commandId: 'stale-instruments', expectedStateRevision: session.stateRevision,
      payload: { intentId: instruments.intent!.intentId } })).toMatchObject({ accepted: false, reasonCode: 'INTENT_NOT_AVAILABLE' })
    const current = session.industry(query({ expectedStateRevision: session.stateRevision }))
    if (!('laboratory' in current) || !current.laboratory) throw new Error('Laboratory page absent')
    expect(current.laboratory.scientistId).toBeNull()
    expect(current.laboratory.scientistLabel).toContain(session.gameState.talent.find(t => t.role === 'scientist')!.name + ' is employed')
    const assign = current.laboratory.actions.find(a => a.id.startsWith('assign-'))!
    expect(assign.enabled).toBe(true)
    expect(session.command({ ...command, commandId: 'assign-scientist', expectedStateRevision: session.stateRevision,
      payload: { intentId: assign.intent!.intentId } }).accepted).toBe(true)
    expect(session.gameState.technology.projects[0]).toMatchObject({ status: 'paused', verifiedWork: 0, expenditure: 0 })
  })

  it('acknowledges completed acoustic instruments while the Scientist seat remains unassigned', () => {
    let state = laboratory()
    const lab = state.placement.facilities.find(p => p.blueprintId === 'research-laboratory')!
    state = applyActions(state, [{ kind: 'installAcousticInstruments', laboratoryFacilityId: lab.facilityId }])
    const pending = new BridgeSession(state, 'lab-test').industry(query())
    if (!('laboratory' in pending) || !pending.laboratory) throw new Error('Laboratory page absent')
    expect(pending.laboratory.installationLabel).toContain('Due 1920 · Week 18')
    expect(pending.laboratory.installationLabel).toContain('$0 during installation')
    for (let week = 0; week < 5; week++) state = tick(state)
    const page = new BridgeSession(state, 'lab-test').industry(query())
    if (!('laboratory' in page) || !page.laboratory) throw new Error('Laboratory page absent')
    expect(page.laboratory.scientistId).toBeNull()
    expect(page.laboratory.bottleneckLabel).toBe('Acoustic instruments are operational. Assign one Scientist before research can begin.')
    expect(page.laboratory.installationLabel).toContain('Completed 1920 · Week 18')
    expect(page.laboratory.installationLabel).toContain('operating cost on advances after completion')
    expect(page.laboratory.actions.some(a => a.id === 'instruments-1')).toBe(false)
  })

  it('shows rival sound only from the actual operational receipt, without exposing private finances', () => {
    // P13B-S8 (ratified CANDIDATE law): the shared technology.adoptions array
    // now also carries a rival INVENTOR's own row (research completed ~276,
    // committed 276, operational 288 — already operational by week 417), so
    // the first non-player row is no longer necessarily this case's own
    // commercial-purchase subject. This case is specifically about the
    // COMMERCIAL route (`'commercial purchase'` assertions below), so it
    // selects that route explicitly rather than array position.
    //
    // RE-EXPRESSED (test-author, P14A.1 T4, evidence 24/25): pinning the
    // purchase to week 428 and reading the pulse's first 50 rows are BOTH
    // falsified by pinned law, not by a defect — week 416 is now the
    // market's SECOND synchronized expiry, whose settlement round writes
    // up to 50 employment receipts into this same 13-week pulse window
    // (paging the technologyAdopted row off page 0), and the settlement's
    // premium-tier payroll/signing bonuses cost the week-416-eligible rival
    // the §48 cash gate by exactly 348,487 (evidence 18), so the first
    // purchase-route adoption is now a LATER-ENTERING rival. Derive the
    // purchasing studio, its committed/operational weeks and the pulse row
    // from the chain's own receipts instead — the technique
    // tests/p13a-rival-adoption.test.ts already uses (`naturalPurchaseSnapshot`:
    // walk forward from the catalogue's own `commercialWeek` floor, 416,
    // until a `route === 'purchase'` row appears) — and page/filter the
    // pulse for the row instead of assuming it is on page 0. Every
    // disclosure assertion below (no private finances) is unchanged.
    let prev = initializeHollywood(generateWorld('p13-public-commercial-adoption'), 'fresh')
    while (prev.market.tick < 416) prev = tick(prev) // synchronized-sound's own fixed catalogue commercialWeek floor
    let state = prev
    while (!state.technology.adoptions.some(a => a.route === 'purchase')) { prev = state; state = tick(state) }
    const pending = state.technology.adoptions.find(a => a.studioId !== state.hollywood!.playerStudioId && a.route === 'purchase')
    expect(pending).toBeDefined()
    expect(pending!.operationalWeek).toBeNull()
    const studioQuery = query({ view: 'studio', targetId: pending!.studioId, lane: 'recent' })
    const before = industryPage(state, 'lab-test', 0, studioQuery)
    expect(before.tendencies.some(t => t.label === 'Observed sound adoption')).toBe(false)
    while (state.technology.adoptions.find(a => a.id === pending!.id)!.operationalWeek === null) state = tick(state)
    const operationalWeek = state.technology.adoptions.find(a => a.id === pending!.id)!.operationalWeek!
    const receipt = state.hollywood!.receipts.find(r => r.kind === 'technologyAdopted' && r.adoptionId === pending!.id)
    expect(receipt).toMatchObject({ week: operationalWeek, studioId: pending!.studioId })
    const after = industryPage(state, 'lab-test', 0, studioQuery)
    const observed = after.tendencies.find(t => t.label === 'Observed sound adoption')!
    expect(observed.detail).toContain(campaignDate(operationalWeek).label)
    expect(observed.detail).toContain('commercial purchase')
    expect(observed.basis).toContain('not a strategy forecast')
    // The pulse's own row order is by GROUP first (releases, people, studios,
    // announcements) and only then by week — a settlement week can legitimately
    // fill the window with dozens of 'people'-group rows that outrank the
    // 'studios'-group technologyAdopted row. Page until found, or exhaust every page.
    let pulse: ReturnType<typeof industryPage> | undefined
    let found: ReturnType<typeof industryPage>['activities'][number] | undefined
    for (let page = 0; ; page++) {
      pulse = industryPage(state, 'lab-test', 0, query({ view: 'pulse', targetId: null, pageSize: 50, page }))
      found = pulse.activities.find(a => a.eventId === receipt!.eventId)
      if (found || page + 1 >= pulse.pageCount) break
    }
    expect(found).toBeDefined()
    expect(found!.headline).toContain('operational synchronized sound')
    for (const page of [after, pulse!]) {
      expect(parseWireValue(BRIDGE_SCHEMA.$defs.StudioIndustryResponse, page)).toEqual(page)
      const json = JSON.stringify(page)
      for (const privateField of ['equipmentCost', 'accessCost', 'account', 'annualSalary', 'researchSpend', 'negativeScale'])
        expect(json).not.toContain('"' + privateField + '"')
    }
  }, 60_000)
})
