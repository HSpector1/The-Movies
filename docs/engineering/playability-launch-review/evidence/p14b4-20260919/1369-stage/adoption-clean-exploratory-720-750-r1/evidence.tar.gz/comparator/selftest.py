#!/usr/bin/env python3
"""Small guard and occurrence tests using the historical p13a pair only."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from unittest.mock import patch

import compare as module
from compare import compare, sha, formal_gate

HERE = Path(__file__).resolve().parent
fixture = json.loads((HERE / "p13a-fixture-pins.json").read_text())
result = compare(fixture, fixture=True)
assert result["counts"] == {"C0": 40, "ABC": 18, "paired": 18, "pairedIdentical": 0, "C0Only": 22, "ABCOnly": 0}
assert {name: row["week"] for name, row in result["firstWeeklyDifferences"].items()} == {
    "newIndustryReceipts": 78, "changedEmployment": 93,
    "changedCases": 196, "newMarketReceipts": 196, "firstTakes": 246}
assert "rng" not in result["firstWeeklyDifferences"]
assert len(result["paired"]) + len(result["C0Only"]) == result["counts"]["C0"]
assert len(result["paired"]) + len(result["ABCOnly"]) == result["counts"]["ABC"]
assert result["firstFinalDifferences"]["market.cases"]


def reject(manifest, fragment):
    try:
        compare(manifest, fixture=True)
    except (ValueError, KeyError) as exc:
        assert fragment in str(exc), (fragment, exc)
    else:
        raise AssertionError("expected rejection: " + fragment)


for change, message in ((lambda m: m.update(seed="wrong"), "wrong seed"),
                        (lambda m: m.update(horizon=52), "manifest horizon"),
                        (lambda m: m["arms"]["C0"].update(dataSha256="0" * 64), "data hash"),
                        (lambda m: m["arms"]["ABC"]["pins"].update(assemblySha256="0" * 64), "complete receipt pins"),
                        (lambda m: m["arms"]["C0"].update(dataSourcePinsDigest="0" * 64), "data source pins")):
    altered = deepcopy(fixture)
    change(altered)
    reject(altered, message)

try:
    compare(fixture)
except ValueError as exc:
    assert "wrong seed for this mode" in str(exc)
else:
    raise AssertionError("ordinary mode accepted the historical p13a seed")
with tempfile.TemporaryDirectory() as temp:
    leaf = Path(temp).resolve()
    original = Path(fixture["arms"]["C0"]["leaf"])
    (leaf / "data.json").symlink_to(original / "data.json")
    receipt = json.loads((original / "RESULT.json").read_text())
    receipt["actualChildExit"] = 1
    (leaf / "RESULT.json").write_text(json.dumps(receipt))
    altered = deepcopy(fixture)
    altered["arms"]["C0"]["leaf"] = str(leaf)
    altered["arms"]["C0"]["resultSha256"] = sha(leaf / "RESULT.json")
    reject(altered, "exits")


leaf = Path(fixture["arms"]["C0"]["leaf"])
receipt = json.loads((leaf / "RESULT.json").read_text())
binding = json.loads((leaf / "binding.json").read_text())
profile = {"manifestSha256": receipt["pins"]["runnerManifestSha256"],
           "manifestPath": Path("/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/MANIFEST.json"),
           "runnerSha256": receipt["pins"]["selfRunnerSha256"],
           "runnerPath": Path("/Users/zacheryspector/studio-scratch/1368-ledger-lowspace-runner-proposal-r2/run.py"),
           "caps": (300, 330)}
for name in ("binding.json", "vitest.json", "progress.jsonl"):
    artifacts = deepcopy(receipt["artifacts"])
    del artifacts[str(leaf / name)]
    try:
        formal_gate("C0", leaf, receipt, binding, artifacts, profile)
    except ValueError as exc:
        assert "missing artifact" in str(exc), exc
    else:
        raise AssertionError("accepted receipt missing " + name)

forged = deepcopy(binding)
forged["probeTestSeconds"] = forged["outerCapSeconds"] = 999
original_read = module.read
def forged_binding(path):
    return forged if Path(path) == leaf / "binding.json" else original_read(path)
with patch.object(module, "read", forged_binding):
    reject(fixture, "reviewed time caps")

adoption_shaped = deepcopy(fixture)
adoption_shaped["seed"] = "p13-public-commercial-adoption"
try:
    compare(adoption_shaped)
except ValueError as exc:
    assert "C0: RESULT identity" in str(exc), exc
else:
    raise AssertionError("adoption mode accepted historical p13a receipt")

print("PASS: historical p13a accounting, first differences, and adversarial missing-artifact/999-cap rejections; adoption remains unmeasured")
