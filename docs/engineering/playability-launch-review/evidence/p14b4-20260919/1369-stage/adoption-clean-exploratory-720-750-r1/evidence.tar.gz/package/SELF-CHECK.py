"""Read-only package audit; optional TypeScript checks. Writes receipt outside the pinned package."""
import ast,difflib,hashlib,json,os,pathlib,subprocess,sys
S=pathlib.Path('/Users/zacheryspector/studio-scratch');P=S/'1369-adoption-extended-proposal-r1'
O=S/'1368-ledger-arms-04';K=S/'1368-ledger-parent-prep-r4/kit';R=pathlib.Path('/Users/zacheryspector/The-Movies-headless-program')
NODE=pathlib.Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def walk(tree):
 files={};links={}
 for root,dirs,names in os.walk(tree,followlinks=False):
  q=pathlib.Path(root)
  for d in list(dirs):
   p=q/d
   if p.is_symlink():links[p.relative_to(tree).as_posix()]=str(p.resolve());dirs.remove(d)
  for n in names:
   p=q/n
   if p.is_symlink():links[p.relative_to(tree).as_posix()]=str(p.resolve())
   else:
    assert p.is_file() and p.stat().st_nlink==1,p
    files[p.relative_to(tree).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
 return files,links
assert sha(O/'ASSEMBLY.json')=='8d027bf8e9cd6aa5e874b6f053e14b5b17be3701c6f4966b3b42610cf7fd6b38'
assert sha(K/'MANIFEST.json')=='01cea5e3beffcb65032dbd45bbb8c56a44016c913bff27c0f756e58d04353a53'
assert sha(K/'SOURCE-PINS.json')=='a2ba20f3ac5009f11c938ec55b7cb21371f1f8d3b74b7febe0f344e95f93a61a'
manifest=json.loads((P/'MANIFEST.json').read_text())
assert manifest['classification']=='EXPLORATORY_NOT_ACCEPTANCE' and manifest['route']=='1369-adoption-clean-exploratory-720-750-r1'
assert (manifest['horizon'],manifest['probeTestSeconds'],manifest['outerCapSeconds'])==(416,720,750)
assert sha(P/'runner/run.py')==manifest['runnerSha256']
package_files,package_links=walk(P)
assert package_links=={'arms/C0/tree/node_modules':str((R/'node_modules').resolve()),'arms/ABC/tree/node_modules':str((R/'node_modules').resolve())}
assert set(package_files)==set(manifest['files'])|{'MANIFEST.json','runner/run.py'}
for name,row in manifest['files'].items():assert package_files[name]==row,name
kit=json.loads((P/'kit/MANIFEST.json').read_text())
assert set(kit)=={name.removeprefix('kit/') for name in package_files if name.startswith('kit/') and name!='kit/MANIFEST.json'}
for name,pin in kit.items():assert sha(P/'kit'/name)==pin,name
assert manifest['kitManifestSha256']==sha(P/'kit/MANIFEST.json')
inputs=json.loads((P/'kit/SOURCE-PINS.json').read_text())
assert set(inputs)=={'C0','ABC'}
report={'status':'STATIC_PASS','classification':manifest['classification'],'route':manifest['route'],'packageManifestSha256':sha(P/'MANIFEST.json'),'runnerSha256':sha(P/'runner/run.py'),'arms':{},'typeChecks':{}}
for arm,pin in [('C0','00d4b886c0acbeb64ebc413348427723c7b5dcf0fbbce845fceb4a149d4d3a7f'),('ABC','43ee074d7833ddae4993794b9084d603bb7eebd2943de7b7949e31759b5de336')]:
 old=O/arm/'tree';new=P/'arms'/arm/'tree';oldpins=json.loads((O/arm/'SOURCE-PINS.json').read_text());newpins=json.loads((P/'arms'/arm/'SOURCE-PINS.json').read_text())
 assert sha(O/arm/'SOURCE-PINS.json')==pin
 of,ol=walk(old);nf,nl=walk(new)
 assert len(of)==len(nf)==len(oldpins)==len(newpins)==197
 assert ol==nl=={'node_modules':str((R/'node_modules').resolve())}
 assert {name:x['sha256'] for name,x in of.items()}==oldpins
 assert {name:x['sha256'] for name,x in nf.items()}==newpins
 changed=sorted(name for name in oldpins if oldpins[name]!=newpins[name])
 assert changed==['tests/1368-ledger-attribution.test.ts','vitest.1368-ledger.config.ts']
 assert sum(name.startswith('src/') for name in oldpins)==188
 assert all(oldpins[name]==newpins[name] for name in oldpins if name.startswith('src/'))
 for rel,before,after,label in [('tests/1368-ledger-attribution.test.ts','}, 300_000)','}, 720_000)','PROBE'),('vitest.1368-ledger.config.ts','testTimeout: 300_000','testTimeout: 720_000','CONFIG')]:
  a=(old/rel).read_text();b=(new/rel).read_text()
  assert a.count(before)==1 and b==a.replace(before,after) and b.count(after)==1
  assert b==(P/'kit/files'/rel).read_text()
  expected=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile=f'arm04/{arm}/{rel}',tofile=f'exploratory/{arm}/{rel}'))
  assert (P/f'{label}-{arm}.diff').read_text()==expected
 assert all(newpins[rel]==kit['files/'+rel] for rel in ['tests/1368-ledger-attribution.test.ts','tests/1368-ledger-original.ts','tsconfig.1368-ledger.json','vitest.1368-ledger.config.ts','vitest.1368-ledger.workspace.ts'])
 assert len(inputs[arm])==189 and all(newpins[name]==value for name,value in inputs[arm].items())
 a=json.loads((P/'arms'/arm/'ASSEMBLY.json').read_text())
 assert a['classification']==manifest['classification'] and a['route']==manifest['route']
 assert a['sourcePinsSha256']==sha(P/'arms'/arm/'SOURCE-PINS.json')==manifest['arms'][arm]['sourcePinsSha256']
 assert a['kitManifestSha256']==manifest['kitManifestSha256']
 assert sha(P/'arms'/arm/'ASSEMBLY.json')==manifest['arms'][arm]['assemblySha256']
 assert a['originalSourcePinsSha256']==pin and a['originalAssemblySha256']==sha(O/arm/'ASSEMBLY.json')
 assert a['regularFiles']==197 and a['productionFiles']==188 and set(a['files'])==set(newpins)
 assert all(a['files'][name]['sha256']==newpins[name] and a['files'][name]['bytes']==nf[name]['bytes'] for name in newpins)
 report['arms'][arm]={'regularFiles':197,'productionFiles':188,'changedFiles':changed,'sourcePinsSha256':a['sourcePinsSha256'],'assemblySha256':sha(P/'arms'/arm/'ASSEMBLY.json')}
runner=(P/'runner/run.py').read_text();ast.parse(runner)
assert 'try: proc.wait(timeout=750)' in runner and "choices=['types', 'clean']" in runner
assert 'prior_types(Path(a.types_receipt), a.types_receipt_sha256, pins)' in runner
assert "assert git('ls-remote', '--exit-code', 'origin', BRANCH)" in runner
assert 'run-bounded-source-guards.py' in runner and 'run-bounded-source-c2.mjs' in runner and 'finish_child' in runner
original=(S/'1368-ledger-lowspace-runner-proposal-r2/run.py').read_text()
expected=''.join(difflib.unified_diff(original.splitlines(keepends=True),runner.splitlines(keepends=True),fromfile=str(S/'1368-ledger-lowspace-runner-proposal-r2/run.py'),tofile=str(P/'runner/run.py')))
assert (P/'RUNNER.diff').read_text()==expected
if '--types' in sys.argv:
 assert subprocess.check_output([str(NODE),'--version'],text=True).strip()=='v20.20.2'
 for arm in ['C0','ABC']:
  p=P/'arms'/arm/'tree';cmd=[str(NODE),'node_modules/typescript/bin/tsc','--noEmit','-p','tsconfig.1368-ledger.json']
  result=subprocess.run(cmd,cwd=p,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  report['typeChecks'][arm]={'command':cmd,'exitCode':result.returncode,'output':result.stdout}
  assert result.returncode==0,(arm,result.stdout)
out=S/'1369-adoption-extended-static-check-r2.json';assert not out.exists();out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'receipt':str(out),'sha256':sha(out),'status':report['status']}))
