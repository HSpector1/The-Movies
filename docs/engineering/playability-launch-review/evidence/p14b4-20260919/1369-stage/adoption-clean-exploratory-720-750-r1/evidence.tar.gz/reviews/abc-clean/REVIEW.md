# Independent ABC adoption clean gate — exploratory 720/750 r1

**Disposition: ACCEPT for the completed ABC adoption-seed clean diagnostic only.** The result is `EXPLORATORY_NOT_ACCEPTANCE`. It does not replace the original 300/330-second route, admit protected repins, establish C0-to-ABC causality, or close 1363.

## Identity and prerequisites

The final package MANIFEST SHA is `92c0b904e68906d77e9155bc9bd41b526c6a431af2c67fa34ff297274c5f1372`, and runner SHA is `776394a3289387042810de5bfbcaa2c4f21b5b97c65edbe259505b90b3485232`. I rehashed all 418 manifest-listed file members with exact sizes and found no mismatch. The independent static review at SHA `c93e5f44da1d96a2ef6d2ce9d29b842623d7d71f7bf6e98b06a46bab7b7d42f6` accepted this exact frozen-source package and its two per-arm timeout edits. ABC binding names the package and runner, adoption seed, 416-week horizon, 720-second probe limit, 750-second outer cap, original source pins, and ABC types receipt SHA `fbb7d295316121bef193b5980f6cddc0cd34a411a3200443d3d77e4e5391ac0e`. I rehashed that types receipt and all 11 named artifacts. It reports PASS, actual child and recorder exit zero, exact guards and postflight, and verified cleanup. The ABC clean RESULT SHA is `69d981eb77f6a912687fa8e3385a421cab73ffa6562413ae17cb305517d4b854`.

## Formal record and execution

I rehashed all 14 artifacts named by clean RESULT, including formal preflight, postflight, JSON record, empty patch and raw log, plus binding, launch, child, power, stdout, stderr, progress, data and Vitest report. Pre/postflight guard scope, HEAD, source paths/files/inventory, manual status, index and stage entries match exactly. The formal record pins publication HEAD `2253bcb128f6c4d3593982703289b746d3fcf171` at both ends, an empty tested diff, no untracked source, `fixedSource=true`, exit zero and exact postflight. Local HEAD and explicit origin working-branch HEAD matched that SHA during review. Untracked formal records from the coordinator's modes were present; the tracked source/index identity remained fixed by the ABC formal guards.

The lane log and metadata name the pinned runner, ABC arm, adoption seed, manifest, runner, leaf and same-arm types receipt. They end with wrapper exit zero and the exact clean RESULT SHA. The raw formal log closes with exit zero, fixed source and exact postflight; the patch and stderr are empty. RESULT and CHILD separately report actual Node exit zero, recorder exit zero, no timeout, 359.477 seconds elapsed, exact guards and no reporting errors. Process group 51093 was absent before and after cleanup; `cleanupVerified`, `leaderReaped` and `noSurvivors` are true. A live process-group check also found it absent.

## Data and limit

Data SHA is `9e3450efe5c3e719a406c5bd1da69dcad5f51f5137004d19120744578b5a1aa2`. It reports `completed=true`, ABC, clean, the adoption seed, horizon 416, 416 contiguous weekly rows from 1 through 416, and final weekly digest equal to `finalStateDigest`. There are no observer-only phase or industry rows. Eight progress records mark weeks 52, 104, 156, 208, 260, 312, 364 and 416. Vitest JSON reports one suite and one test passed, zero failed; stdout independently says one file and one test passed. All 42 adoption rows are present: 36 settled, six declined, zero expired. Against the original 48-row protected pin, `rows` and `declined` comparisons are false; `settled`, `expired` and RNG are true; settlement, receipts, employment and takes digest comparisons are false. This gate validates a complete, source-bound exploratory diagnostic, not protected behavior acceptance or a causal explanation for the row deficit.

No tracked file, HANDOFF, index, commit, push or heavy lane was changed by this review.
