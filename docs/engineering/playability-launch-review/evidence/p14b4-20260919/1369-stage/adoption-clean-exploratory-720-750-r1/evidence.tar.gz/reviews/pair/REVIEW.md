# Independent exploratory adoption C0→ABC pair review

Decision: **ACCEPT** as a source-bound, descriptive comparison of the two completed 416-week exploratory CLEAN leaves. This review does not establish which individual A/F6/B/C change caused a difference, observed parity, protected repins, original 300/330 acceptance, or 1363 closure.

## Identity and replay

The frozen `compare.py` hashes to `ee8d8c1165693597c3d585c5b5535339f79612bb4858ba18cb69b0aea381aedf`; its prior independent ACCEPT review hashes to `05c3a4035eb55c402e5c1163d56dbae5bbb2f66cf85c66941ff9131426e94932`. Input `adoption-pins.json` hashes to `f49eca5c6d2ab9d615ede7ee384b628576e83f02bbd31dd3eb21a31b9be1d5cd`. The C0 and ABC RESULT hashes match the input manifest exactly: `64453c5636882e7e609021d00c3ad346796e5a402b30e83ff96548cc3433ea5f` and `69d981eb77f6a912687fa8e3385a421cab73ffa6562413ae17cb305517d4b854`. Each input data hash, source-manifest hash, RESULT pin map, and raw-data source-pin digest also matches its leaf. The separate C0 and ABC independent ACCEPT reviews hash to `49e424199ec6cf4a6293e848249e9fbf1c515a66bfdcceed700e26cbbf8e273f` and `318837f9a2a9b90e2a7b565c1acc5f8e8aa8bbc5df7ca9690ad296c06dd7868f`. Both RESULT files report PASS, actual child and recorder exit zero, and `EXPLORATORY_NOT_ACCEPTANCE`.

I reran the frozen comparator with that input manifest into this review's `RERUN-REPORT.json`. It hashes to `b24fe702b325bdea7c6461b8724bc14b4fdb1813b82fe4fde4f8a6990efc5f09`, byte-identical to the submitted `REPORT.json` at the same hash. The comparator's source, formal execution, artifact, Vitest, and progress gates passed during this replay. This verifies the report for these exact leaves; it is not an independent process-execution witness beyond the accepted leaf reviews.

## Independent raw-data check

I separately grouped each raw `data.json` row by `(week, talentId, subjectStudioId)`, pairing duplicate-key occurrences in source order. The result is C0 48 rows, ABC 42 rows, 42 paired, six C0-only, zero ABC-only. The status mix is C0 36 settled/12 declined versus ABC 36 settled/six declined; all six C0-only rows are declines for `person-studio-5a47d054-r04-0` through `-5` at week 416. Twenty-four paired rows are byte-equivalent as JSON objects. The other 18 paired rows differ only in `eventId`; all 42 have equal content with `eventId` removed. The first shifted pair, keyed by week 416 / `person-studio-5a47d054-r01-0` / `studio-5a47d054-r02`, is `talent-market-event-223` in C0 and `-205` in ABC. These IDs reflect receipt sequence position and do not by themselves show changed row substance. The six absent ABC rows are a genuine count/content difference.

Independently scanned weekly fields first differ at week 265 for new industry receipts, week 308 for changed employment, and week 404 for changed cases and new market receipts. `firstTakes` and RNG have no weekly difference. The first differing final-array source ordinals are industry receipts 371 (C0 511, ABC 515 total), employment 42 (64 each), market cases 42 (48 versus 42), and market receipts 167 (247 versus 223). These are ordinal first differences, not stable-identity causal attributions. The report's 42/48 counts, status mix, first weeks and final ordinals agree with this direct calculation.

The sources differ as a bundle. The paired row contents and event ID sequence should not be conflated, and the missing rows cannot be assigned to a particular intervention from this comparison alone. Protected settlement, receipt, employment, and take digests are still unaccepted; ABC remains below the original 48-row pin. Further source-qualified intermediate arms are needed for causal reconciliation.

No tracked source, HANDOFF, index, commit, push, or heavy lane was changed for this review.
