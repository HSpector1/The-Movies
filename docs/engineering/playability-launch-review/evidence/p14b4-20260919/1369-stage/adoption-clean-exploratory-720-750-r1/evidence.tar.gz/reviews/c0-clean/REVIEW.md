# Independent C0 adoption clean gate — exploratory 720/750 r1

**Disposition: ACCEPT for the completed C0 adoption-seed clean diagnostic only.** This is `EXPLORATORY_NOT_ACCEPTANCE`; it does not replace the original 300/330-second U route, admit protected repins, establish ABC parity, or close 1363.

## Identity and prerequisites

The final package MANIFEST SHA is `92c0b904e68906d77e9155bc9bd41b526c6a431af2c67fa34ff297274c5f1372`, and its runner SHA is `776394a3289387042810de5bfbcaa2c4f21b5b97c65edbe259505b90b3485232`. I rehashed all 418 manifest-listed file members with exact sizes and found no mismatch. The earlier independent static review is ACCEPT at REVIEW SHA `c93e5f44da1d96a2ef6d2ce9d29b842623d7d71f7bf6e98b06a46bab7b7d42f6`; it verified the frozen arm04 source and the only two per-arm timeout edits. The C0 clean binding names the exact package, runner, C0 arm, adoption seed, 416-week horizon, 720-second Vitest limit, 750-second outer cap, and prior C0 types receipt SHA `cb8006305e94a564ba3aa919b6890dfde197687284e2880d8467bce62828ce58`. That types receipt independently rehashes and reports PASS, actual child/recorder exit zero, exact guards and postflight. The C0 RESULT SHA is `64453c5636882e7e609021d00c3ad346796e5a402b30e83ff96548cc3433ea5f`.

## Formal record and execution

I rehashed all 14 artifacts named by RESULT, including the formal preflight, postflight, JSON record, empty patch, raw log, binding, stdout, stderr, progress, data and Vitest report. The formal pre/postflight head, source paths/files/inventory, manual status, index and stage entries match exactly. They pin publication HEAD `2253bcb128f6c4d3593982703289b746d3fcf171`; the formal record has the same source SHA at both ends, an empty tested diff, no untracked source, fixedSource true and exit 0. Local HEAD and explicit origin HEAD were both that SHA during review. New untracked formal records from the coordinator's later mode were present, but the tracked source/index identity remained fixed by the C0 formal guards.

The lane log and `.meta` name the pinned runner command, arm, seed, manifest, runner, leaf, types receipt and source HEAD; they end with wrapper exit 0 and the exact RESULT SHA. The raw formal log closes at exit 0 with fixed source and exact postflight; the empty patch and clean stderr are rehashed. RESULT and CHILD separately report actual Node exit 0, recorder exit 0, no timeout, 374.963 seconds elapsed, exact guards and no reporting errors. Process group 19568 was absent before and after cleanup; cleanupVerified, leaderReaped and noSurvivors are true, and a live process-group check found it absent.

## Data and limit

The JSON data is complete: `completed=true`, C0, clean, adoption seed, horizon 416, 416 contiguous weekly rows from 1 through 416, and final weekly digest equal to finalStateDigest. Eight progress records mark weeks 52, 104, 156, 208, 260, 312, 364 and 416. Vitest JSON reports one suite and one test passed, zero failed; stdout independently says one file and one test passed. The 48 protected adoption rows are present: 36 settled, 12 declined, zero expired. Row/status/RNG comparisons to historical pins are true. Settlement, receipts, employment and takes digest comparisons remain false. This clean gate validates a completed, source-bound diagnostic; it is not a protected behavior acceptance or causal reconciliation.

No tracked file, HANDOFF, index, commit, push, or heavy lane was changed by this review.
