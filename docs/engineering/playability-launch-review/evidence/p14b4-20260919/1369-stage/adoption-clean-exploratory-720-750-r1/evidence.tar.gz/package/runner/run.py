"""1369 adoption clean exploratory types and clean; never original-cap acceptance."""
import argparse, hashlib, importlib.util, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
R = Path('/Users/zacheryspector/The-Movies-headless-program')
S = Path('/Users/zacheryspector/studio-scratch')
P = S / '1369-adoption-extended-proposal-r1'
ARMS = P / 'arms'
KIT = P / 'kit'
RUNS = S / '1369-adoption-clean-exploratory-recorded-r1'
SELF = P / 'runner/run.py'
ROUTE = '1369-adoption-clean-exploratory-720-750-r1'
CLASSIFICATION = 'EXPLORATORY_NOT_ACCEPTANCE'
PROBE_SECONDS = 720
OUTER_SECONDS = 750
E = R / 'docs/engineering/playability-launch-review/evidence/p14b4-20260919'
NODE = Path('/Users/zacheryspector/.nvm/versions/node/v20.20.2/bin/node')
CLEANUP = S / '1368-ledger-parent-prep-r4/cleanup.py'
BRANCH = 'refs/heads/wip/headless-program-20260916-ts'
SCOPE = ['src', 'bridge', 'tests', 'ui', 'generated', 'scripts', 'package.json', 'package-lock.json', 'vitest.config.ts', 'vitest.workspace.ts', 'tsconfig.json', 'tsconfig.bridge.json', 'tsconfig.src.json', ':(exclude)tests/fixtures', ':(exclude)ui/e2e', ':(exclude)ui/public']
FIXED = {
    CLEANUP: '4698b610b50289fd289e3235c564c087774b443422ca7e0ac6635284babc49e4',
    Path('/Users/zacheryspector/studio-scratch/1368-rival-writing-guard-prep/MANIFEST.json'): '727183f5a89fbd5318af4bda67b6605871dcd5a270c82e142e625bd0c00e42ca',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-01/ASSEMBLY.json'): '05cba942c8cb0d2ce8837f5b5020f7714b73a8a0db0ff8f4f72b7fc19381e1bd',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ASSEMBLY.json'): '8d027bf8e9cd6aa5e874b6f053e14b5b17be3701c6f4966b3b42610cf7fd6b38',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/C0/ASSEMBLY.json'): '7134409ad5d09a9d2dbb16080165b1161cc351c0042fc893d5d78874e13ed303',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/C0/SOURCE-PINS.json'): '00d4b886c0acbeb64ebc413348427723c7b5dcf0fbbce845fceb4a149d4d3a7f',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/ASSEMBLY.json'): 'c37c8d1a1c58a6729cc75a6fb5f38fd1158f60c9cf17a54c7b290aeec1a9f259',
    Path('/Users/zacheryspector/studio-scratch/1368-ledger-arms-04/ABC/SOURCE-PINS.json'): '43ee074d7833ddae4993794b9084d603bb7eebd2943de7b7949e31759b5de336',
    Path('/Users/zacheryspector/studio-scratch/1368-recovery-legacy-prep/run-recovery.py'): '7568362dbfdc07cf63d768dda14edd4e754f89b3aeae14ebf0ef335d8832be02',
    Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919/run-bounded-source-guards.py'): '1a1e144c25dd36320c64237d5b58f19d848eb85171fa777e5772c2c3fff1a20e',
    Path('/Users/zacheryspector/The-Movies-headless-program/docs/engineering/playability-launch-review/evidence/p14b4-20260919/run-bounded-source-c2.mjs'): 'ae167b103ddaa714268cd63e163daa4966b0c3b8f07bfa3e9bd8f0c7d07751a2',
}
SEEDS = {"p13-public-commercial-adoption": "adoption"}


def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def safe(path):
    assert path.is_absolute() and str(path) == os.path.abspath(path)
    for part in [path, *path.parents]: assert not part.is_symlink(), str(part)
def exclusive(path):
    safe(path); assert not os.path.lexists(path), 'existing output: ' + str(path)
def write(path, obj):
    with path.open('x') as f: json.dump(obj, f, indent=2); f.write('\n')
def environment():
    return dict(os.environ, PATH=str(NODE.parent) + ':' + str(R / '.venv/bin') + ':' + os.environ.get('PATH', ''), GIT_OPTIONAL_LOCKS='0')
def git(*args): return subprocess.check_output(['git', *args], cwd=R, env=environment())
def verify(head, manifest_pin, arm, runner_pin):
    assert arm in ["C0", "ABC"]
    ARM = ARMS / arm; T = ARM / "tree"
    assert re.fullmatch('[0-9a-f]{40}', head)
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert git('symbolic-ref', 'HEAD').decode().strip() == BRANCH
    assert git('diff', '--name-only', 'HEAD', '--', *SCOPE) == b'', 'dirty live source'
    assert git('ls-files', '--others', '--exclude-standard', '--', *SCOPE) == b'', 'untracked live source'
    assert re.fullmatch('[0-9a-f]{64}', manifest_pin)
    safe(SELF); assert Path(__file__).resolve() == SELF
    assert re.fullmatch('[0-9a-f]{64}', runner_pin) and sha(SELF) == runner_pin
    safe(P / 'MANIFEST.json'); assert sha(P / 'MANIFEST.json') == manifest_pin
    manifest = json.loads((P / 'MANIFEST.json').read_text())
    assert (manifest['classification'], manifest['route'], manifest['probeTestSeconds'], manifest['outerCapSeconds'], manifest['horizon']) == (CLASSIFICATION, ROUTE, PROBE_SECONDS, OUTER_SECONDS, 416)
    assert manifest['seed'] == 'p13-public-commercial-adoption' and manifest['allowedModes'] == ['types', 'clean']
    assert manifest['allowedArms'] == ['C0', 'ABC'] and manifest['runNamespace'] == str(RUNS)
    assert manifest['runnerSha256'] == runner_pin
    assert manifest['arms'][arm]['sourcePinsSha256'] == sha(ARM / 'SOURCE-PINS.json')
    assert manifest['arms'][arm]['assemblySha256'] == sha(ARM / 'ASSEMBLY.json')
    assert manifest['kitManifestSha256'] == sha(KIT / 'MANIFEST.json')
    for name, row in manifest['files'].items():
        path = P / name; safe(path); assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
    expected = set(manifest['files']) | {'MANIFEST.json', 'runner/run.py'}
    actual = {p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_file() and 'node_modules' not in p.parts}
    assert actual == expected, 'package file membership changed'
    links = {p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_symlink()}
    assert links == {'arms/C0/tree/node_modules', 'arms/ABC/tree/node_modules'}
    for path, pin in FIXED.items(): safe(path); assert sha(path) == pin, str(path)
    source = json.loads((ARM / 'SOURCE-PINS.json').read_text()); assert len(source) == 197
    kit = json.loads((KIT / 'MANIFEST.json').read_text())
    for name, row in kit.items():
        path = KIT / name; safe(path); assert sha(path) == row
    kit_names = ['tests/1368-ledger-attribution.test.ts', 'tests/1368-ledger-original.ts', 'tsconfig.1368-ledger.json', 'vitest.1368-ledger.config.ts', 'vitest.1368-ledger.workspace.ts']
    assert sorted(n.removeprefix('files/') for n in kit if n.startswith('files/')) == sorted(kit_names)
    for name in kit_names: assert source[name] == kit['files/' + name]
    inputs = json.loads((KIT / 'SOURCE-PINS.json').read_text())[arm]
    assert len(inputs) == 189
    for name, pin in inputs.items(): assert source[name] == pin
    assembly = json.loads((ARM / 'ASSEMBLY.json').read_text())
    assert assembly['arm'] == arm and assembly['productionFiles'] == 188 and assembly['regularFiles'] == 197
    assert set(assembly['files']) == set(source)
    assert assembly['originalPins'] == inputs
    assert assembly['classification'] == CLASSIFICATION and assembly['route'] == ROUTE
    assert assembly['originalSourcePinsSha256'] == sha(S / '1368-ledger-arms-04' / arm / 'SOURCE-PINS.json')
    assert assembly['originalAssemblySha256'] == sha(S / '1368-ledger-arms-04' / arm / 'ASSEMBLY.json')
    assert set(assembly['changedFromArm04']) == {'tests/1368-ledger-attribution.test.ts', 'vitest.1368-ledger.config.ts'}
    probe = (T / 'tests/1368-ledger-attribution.test.ts').read_text()
    config = (T / 'vitest.1368-ledger.config.ts').read_text()
    assert probe.count('}, 720_000)') == 1 and '}, 300_000)' not in probe
    assert config.count('testTimeout: 720_000') == 1 and 'testTimeout: 300_000' not in config
    assert assembly['sourcePinsSha256'] == sha(ARM / 'SOURCE-PINS.json')
    assert assembly['kitManifestSha256'] == sha(KIT / 'MANIFEST.json')
    for name, row in assembly['files'].items(): assert source[name] == row['sha256'] and (T / name).stat().st_size == row['bytes']
    actual = []
    safe(T)
    for folder, dirs, files in os.walk(T, followlinks=False):
        root = Path(folder)
        if root == T:
            assert 'node_modules' in dirs; dirs.remove('node_modules')
        for name in dirs: safe(root / name)
        for name in files:
            path = root / name; safe(path); assert path.is_file() and path.stat().st_nlink == 1
            rel = path.relative_to(T).as_posix(); assert rel in source and sha(path) == source[rel], rel
            actual.append(rel)
    assert sorted(actual) == sorted(source)
    assert (T / 'node_modules').is_symlink() and (T / 'node_modules').resolve() == (R / 'node_modules').resolve()
    assert subprocess.check_output([str(NODE), '--version'], text=True).strip() == 'v20.20.2'
    entries = [NODE, T / 'node_modules/typescript/bin/tsc', T / 'node_modules/vitest/vitest.mjs']
    index = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    return {'arm': arm, 'publicationHead': head, 'publicationIndexSha256': sha(index), 'publicationStageSha256': digest(git('ls-files', '--stage', '-z')),
            'boundedDiffSha256': digest(git('diff', 'HEAD', '--', *SCOPE)), 'sourcePinsSha256': sha(ARM / 'SOURCE-PINS.json'),
            'assemblySha256': sha(ARM / 'ASSEMBLY.json'), 'kitManifestSha256': sha(KIT / 'MANIFEST.json'),
            'inputPinsSha256': sha(KIT / 'SOURCE-PINS.json'), 'runnerManifestSha256': manifest_pin, 'selfRunnerSha256': runner_pin,
            'entrypoints': {str(path): sha(path) for path in entries}, 'regularFiles': 197, 'classification': CLASSIFICATION, 'route': ROUTE, 'probeTestSeconds': PROBE_SECONDS, 'outerCapSeconds': OUTER_SECONDS, 'horizon': 416, 'originalSourcePinsSha256': assembly['originalSourcePinsSha256'], 'originalAssemblySha256': assembly['originalAssemblySha256']}
def command_for(mode, out):
    if mode == 'types': return [str(NODE), 'node_modules/typescript/bin/tsc', '--noEmit', '-p', 'tsconfig.1368-ledger.json']
    assert mode == 'clean'
    return [str(NODE), 'node_modules/vitest/vitest.mjs', 'run', '--workspace', 'vitest.1368-ledger.workspace.ts', '--config', 'vitest.1368-ledger.config.ts', '--maxWorkers', '1', '--minWorkers', '1', '--no-file-parallelism', '--reporter=verbose', '--reporter=json', '--outputFile.json=' + str(out / 'vitest.json')]

def prior_types(path, pin, current):
    safe(path); assert path.name == 'RESULT.json' and path.parent.parent == RUNS and path.parent.is_dir() and sha(path) == pin
    receipt = json.loads(path.read_text())
    assert receipt['command'] == command_for('types', path.parent)
    assert receipt['mode'] == 'types' and receipt['arm'] == current['arm'] and receipt['seed'] is None
    assert receipt['status'] == 'PASS' and receipt['classification'] == CLASSIFICATION and receipt['route'] == ROUTE and receipt['allGuardsExact'] and receipt['livePostflightExact'] and receipt['actualChildExit'] == 0 and receipt['recorderChildExit'] == 0 and not receipt['timedOut']
    assert receipt['processGroup']['noSurvivors'] and receipt['processGroup']['leaderReaped'] and receipt['processGroup']['cleanupVerified'] and not receipt['reportingErrors']
    assert (path.parent / 'binding.json').exists() and (path.parent / 'LAUNCH.json').exists() and (path.parent / 'CHILD.json').exists()
    binding = json.loads((path.parent / 'binding.json').read_text())
    assert binding['classification'] == CLASSIFICATION and binding['route'] == ROUTE and binding['arm'] == current['arm'] and binding['mode'] == 'types' and binding['seed'] is None
    assert binding['pins'] == receipt['pins'] and binding['command'] == receipt['command']
    assert binding['outerCapSeconds'] == OUTER_SECONDS and binding['probeTestSeconds'] == PROBE_SECONDS and binding['horizon'] == 416
    # Documentation publication may advance between modes; consumed source and kit must not.
    for name in ['arm', 'sourcePinsSha256', 'assemblySha256', 'kitManifestSha256', 'inputPinsSha256', 'runnerManifestSha256', 'selfRunnerSha256', 'entrypoints', 'regularFiles', 'classification', 'route', 'probeTestSeconds', 'outerCapSeconds', 'horizon', 'originalSourcePinsSha256', 'originalAssemblySha256']:
        assert receipt['pins'][name] == current[name], 'types source differs: ' + name
    assert len(receipt['artifacts']) >= 10
    stem = ROUTE + '-' + path.parent.name.lower()
    formal = {str(E / (stem + suffix)) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']}
    local = {str(path.parent / name) for name in ['binding.json', 'LAUNCH.json', 'CHILD.json', 'stdout.txt', 'stderr.txt', 'power.json']}
    assert formal | local <= set(receipt['artifacts'])
    for name, row in receipt['artifacts'].items():
        f = Path(name); safe(f); assert sha(f) == row['sha256'] and f.stat().st_size == row['bytes']
def child(out, binding_pin):
    safe(out / 'binding.json'); assert sha(out / 'binding.json') == binding_pin
    b = json.loads((out / 'binding.json').read_text())
    assert b['arm'] in ['C0', 'ABC']; T = ARMS / b['arm'] / 'tree'
    assert b['mode'] in ['types', 'clean']
    assert b['classification'] == CLASSIFICATION and b['route'] == ROUTE
    assert b['seed'] is None if b['mode'] == 'types' else b['seed'] in SEEDS
    assert b['outerCapSeconds'] == OUTER_SECONDS == 750 and b['probeTestSeconds'] == PROBE_SECONDS == 720 and b['horizon'] == 416
    assert b['command'] == command_for(b['mode'], out)
    assert verify(b['publicationHead'], b['manifestPin'], b['arm'], b['selfRunnerSha256']) == b['pins']
    if b['mode'] == 'clean': prior_types(Path(b['typesReceipt']), b['typesReceiptSha256'], b['pins'])
    # Import only after verifying the reviewed helper's exact SHA; __main__ is not run.
    spec = importlib.util.spec_from_file_location('reviewed_cleanup', CLEANUP); helper = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode; sys.dont_write_bytecode = True
    try: spec.loader.exec_module(helper)
    finally: sys.dont_write_bytecode = old
    env = environment(); env.update(LEDGER_ARM=b['arm'], LEDGER_MODE=b['mode'], LEDGER_SEED=b['seed'] or '', LEDGER_OUTPUT=str(out / 'data.json'), LEDGER_PROGRESS=str(out / 'progress.jsonl'))
    start = time.monotonic(); timed_out = False; wait_error = None
    with (out / 'stdout.txt').open('x') as stdout, (out / 'stderr.txt').open('x') as stderr:
        proc = subprocess.Popen(b['command'], cwd=T, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            # Persist launch identity before the bounded wait, independently of final reporting.
            write(out / 'LAUNCH.json', {'nodePid': proc.pid, 'ownedProcessGroup': proc.pid,
                'startNewSession': True, 'monotonicStarted': start, 'command': b['command'], 'bindingSha256': binding_pin, 'classification': CLASSIFICATION, 'route': ROUTE, 'outerCapSeconds': OUTER_SECONDS})
            try: proc.wait(timeout=750)
            except subprocess.TimeoutExpired: timed_out = True
        except Exception as error:
            wait_error = error
        finally:
            def check_source():
                return verify(b['publicationHead'], b['manifestPin'], b['arm'], b['selfRunnerSha256']) == b['pins'] and sha(out / 'binding.json') == binding_pin
            def write_receipt(row):
                row.update(stdoutSha256=sha(out / 'stdout.txt'), stderrSha256=sha(out / 'stderr.txt'))
                write(out / 'CHILD.json', row)
            exit_code = helper.finish_child(proc, timed_out, start, b['command'], check_source, write_receipt, wait_error)
    return exit_code

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=['types', 'clean']); ap.add_argument('--arm', required=True, choices=['C0', 'ABC']); ap.add_argument('--seed', choices=list(SEEDS)); ap.add_argument('--head', required=True)
    ap.add_argument('--manifest-sha256', required=True); ap.add_argument('--self-runner-sha256', required=True); ap.add_argument('--leaf', required=True)
    ap.add_argument('--types-receipt'); ap.add_argument('--types-receipt-sha256'); a = ap.parse_args()
    assert Path(__file__).resolve() == SELF
    assert re.fullmatch('[a-z0-9-]+', a.leaf)
    assert a.seed is None if a.mode == 'types' else a.seed in SEEDS
    tag = a.arm + '-' + a.mode + '-' + (SEEDS[a.seed] if a.seed else 'source') + '-' + a.leaf
    out = RUNS / tag; exclusive(out)
    pins = verify(a.head, a.manifest_sha256, a.arm, a.self_runner_sha256)
    assert git('ls-remote', '--exit-code', 'origin', BRANCH).decode().split() == [a.head, BRANCH]
    if a.mode == 'clean':
        assert a.types_receipt and a.types_receipt_sha256
        prior_types(Path(a.types_receipt), a.types_receipt_sha256, pins)
    else: assert not a.types_receipt and not a.types_receipt_sha256
    assert shutil.disk_usage(R).free >= 3 * 1024**3
    stem = ROUTE + '-' + tag.lower()
    for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']: exclusive(E / (stem + suffix))
    safe(RUNS); RUNS.mkdir(exist_ok=True); out.mkdir()
    command = command_for(a.mode, out)
    binding = {'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'horizon': 416, 'publicationHead': a.head, 'classification': CLASSIFICATION, 'route': ROUTE, 'sourceStatus': 'Frozen arm04 source; exploratory timeout extension only. Publication HEAD is coordinator provenance only', 'pins': pins, 'manifestPin': a.manifest_sha256, 'selfRunnerSha256': a.self_runner_sha256, 'command': command, 'typesReceipt': a.types_receipt, 'typesReceiptSha256': a.types_receipt_sha256, 'outerCapSeconds': OUTER_SECONDS, 'probeTestSeconds': PROBE_SECONDS}
    write(out / 'binding.json', binding)
    power = subprocess.check_output(['pmset', '-g', 'batt'], text=True)
    write(out / 'power.json', {'pmset': power, 'acPower': "Now drawing from 'AC Power'" in power})
    assert "Now drawing from 'AC Power'" in power, 'AC power required'
    subprocess.Popen(['caffeinate', '-is', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    guard = [sys.executable, str(E / 'run-bounded-source-guards.py')]
    subprocess.run([*guard, 'pre', stem, '0'], cwd=R, env=environment(), check=True)
    try:
        recorder = subprocess.run([str(NODE), str(E / 'run-bounded-source-c2.mjs'), stem, sys.executable, str(SELF), '--child', str(out), sha(out / 'binding.json')], cwd=R, env=environment()).returncode
    finally: post_code = subprocess.run([*guard, 'post', stem], cwd=R, env=environment()).returncode
    record = json.loads((E / (stem + '.json')).read_text()); post = json.loads((E / (stem + '-postflight.json')).read_text())
    assert post_code == 0 and recorder == record['exitCode']
    assert record['command'] == [sys.executable, str(SELF), '--child', str(out), sha(out / 'binding.json')]
    assert record['fixedSource'] and post['fixedSource'] and post['allGuardsExact']
    assert record['sourceSha'] == record['sourceShaAtEnd'] == post['head'] == a.head
    assert record['exitCode'] == post['exitCode']
    assert verify(a.head, a.manifest_sha256, a.arm, a.self_runner_sha256) == pins
    # Reporting failure is evidence, never an invented Node exit or successful cleanup.
    try:
        child_result = json.loads((out / 'CHILD.json').read_text())
        assert isinstance(child_result, dict) and child_result['command'] == command
        assert isinstance(child_result['processGroup'], dict) and isinstance(child_result['reportingErrors'], list)
        assert isinstance(child_result['timedOut'], bool) and isinstance(child_result['allGuardsExact'], bool)
        assert child_result['actualChildExit'] is None or type(child_result['actualChildExit']) is int
        group = child_result['processGroup']
        assert all(type(group[key]) is bool for key in ['cleanupVerified', 'noSurvivors', 'leaderReaped'])
        code = child_result['actualChildExit']
        failed_reporting = bool(child_result['reportingErrors']) or not child_result['allGuardsExact']
        expected_exit = 124 if child_result['timedOut'] else (1 if failed_reporting or not group['cleanupVerified'] or not group['noSurvivors'] or not group['leaderReaped'] else (code if isinstance(code, int) and code >= 0 else 1))
        assert record['exitCode'] == post['exitCode'] == expected_exit, 'Node/cleanup/recorder exit mismatch'
    except Exception as error:
        paths = [f for f in out.iterdir() if f.is_file()] + [E / (stem + suffix) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']]
        for f in paths: safe(f)
        write(out / 'WRAPPER-FAILURE.json', {'status': 'INCOMPLETE_CHILD_REPORT', 'actualChildExit': None,
            'timedOut': None, 'noSurvivors': None, 'recorderChildExit': record['exitCode'],
            'livePostflightExact': True, 'command': command, 'errorType': type(error).__name__, 'error': str(error),
            'artifacts': {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in paths}})
        return 1
    if a.mode == 'clean' and expected_exit == 0:
        data = json.loads((out / 'data.json').read_text())
        assert data['completed'] is True and data['sourcePostflight'] is True
        assert (data['arm'], data['mode'], data['seed'], data['horizon']) == (a.arm, a.mode, a.seed, 416)
        assert data['sourcePins'] == json.loads((KIT / 'SOURCE-PINS.json').read_text())[a.arm]
        assert len(data['weekly']) == 416 and [row['week'] for row in data['weekly']] == list(range(1, 417))
        report = json.loads((out / 'vitest.json').read_text())
        assert report['numTotalTests'] == report['numPassedTests'] == 1 and report['numFailedTests'] == 0
        progress = [json.loads(line) for line in (out / 'progress.jsonl').read_text().splitlines()]
        assert [row['week'] for row in progress] == list(range(52, 417, 52))
        assert all(set(row) == {'week', 'elapsedSeconds'} and isinstance(row['elapsedSeconds'], (int, float)) and 0 <= row['elapsedSeconds'] < float('inf') for row in progress)
        assert all(left['elapsedSeconds'] <= right['elapsedSeconds'] for left, right in zip(progress, progress[1:]))
    paths = [f for f in out.rglob('*') if f.is_file()]
    for f in paths: safe(f)
    paths += [E / (stem + suffix) for suffix in ['.json', '.patch', '.txt', '-preflight.json', '-postflight.json']]
    artifacts = {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in sorted(paths)}
    write(out / 'RESULT.json', {**child_result, 'status': 'PASS' if expected_exit == 0 else ('TIMEOUT' if child_result['timedOut'] else 'FAIL'), 'classification': CLASSIFICATION, 'route': ROUTE, 'mode': a.mode, 'arm': a.arm, 'seed': a.seed, 'pins': pins, 'recorderChildExit': record['exitCode'], 'allGuardsExact': child_result['allGuardsExact'], 'livePostflightExact': True, 'artifacts': artifacts, 'interpretation': 'EXPLORATORY_NOT_ACCEPTANCE; never original 300/330 acceptance. Actual Node and recorder exits are separate.'})
    print(json.dumps({'receipt': str(out / 'RESULT.json'), 'receiptSha256': sha(out / 'RESULT.json'), 'actualChildExit': child_result['actualChildExit'], 'timedOut': child_result['timedOut']}))
    return record['exitCode'] if isinstance(record['exitCode'], int) and record['exitCode'] >= 0 else 1
if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '--child': sys.exit(child(Path(sys.argv[2]), sys.argv[3]))
    try:
        sys.exit(main())
    except BaseException as error:
        # Retain an incomplete receipt if formal reporting or admission fails after output creation.
        try:
            args = sys.argv
            arm = args[args.index('--arm') + 1]
            leaf = args[args.index('--leaf') + 1]
            mode = args[1]
            seed = args[args.index('--seed') + 1] if '--seed' in args else None
            if arm in ('C0', 'ABC') and mode in ('types', 'clean') and (seed is None or seed in SEEDS):
                tag = arm + '-' + mode + '-' + (SEEDS[seed] if seed else 'source') + '-' + leaf
                out = RUNS / tag
                if out.is_dir() and not (out / 'RESULT.json').exists():
                    artifacts = {}
                    for f in out.rglob('*'):
                        if f.is_file() and not f.is_symlink():
                            artifacts[str(f)] = {'sha256': sha(f), 'bytes': f.stat().st_size}
                    failure = {'status': 'INCOMPLETE_CHILD_REPORT', 'classification': CLASSIFICATION,
                               'route': ROUTE, 'mode': mode, 'arm': arm, 'seed': seed,
                               'actualChildExit': None, 'recorderChildExit': None,
                               'timedOut': None, 'processGroup': {'cleanupVerified': None,
                               'noSurvivors': None, 'leaderReaped': None},
                               'errorType': type(error).__name__, 'error': str(error),
                               'artifacts': artifacts}
                    write(out / 'RESULT.json', failure)
        finally:
            raise
