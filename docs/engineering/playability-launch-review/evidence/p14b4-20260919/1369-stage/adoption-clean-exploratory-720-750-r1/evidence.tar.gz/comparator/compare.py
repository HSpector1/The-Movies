#!/usr/bin/env python3
"""Source-bound, descriptive comparison of two complete CLEAN ledger leaves."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import sys

TARGET_SEED = "p13-public-commercial-adoption"
HORIZON = 416
# Exact extended package bytes independently accepted in
# 1369-adoption-extended-independent-review-r1/REVIEW.md.
EXPLORATORY_MANIFEST_SHA256 = "92c0b904e68906d77e9155bc9bd41b526c6a431af2c67fa34ff297274c5f1372"
EXPLORATORY_RUNNER_SHA256 = "776394a3289387042810de5bfbcaa2c4f21b5b97c65edbe259505b90b3485232"
EXPLORATORY_RUNNER_PATH = Path("/Users/zacheryspector/studio-scratch/1369-adoption-extended-proposal-r1/runner/run.py")
EXPLORATORY_MANIFEST_PATH = Path("/Users/zacheryspector/studio-scratch/1369-adoption-extended-proposal-r1/MANIFEST.json")
FIXTURE_MANIFEST_SHA256 = "3675e4d50a12bef7c1ffb13186f161844795512b20dc41f736d5872f964b995f"
FIXTURE_MANIFEST_PATH = Path("/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/MANIFEST.json")
FIXTURE_RUNNER_SHA256 = "7eb654ebd6b45ab297262b38315414643a1ac26d08b3a03c7b78dcd875aa6f4d"
FIXTURE_RUNNER_PATH = Path("/Users/zacheryspector/studio-scratch/1368-ledger-lowspace-runner-proposal-r2/run.py")
FIELDS = ("changedCases", "newMarketReceipts", "newIndustryReceipts", "changedEmployment", "firstTakes", "rng")


def check(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compact_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def artifact(path, artifacts, arm):
    key = str(path)
    check(key in artifacts, f"{arm}: missing artifact {key}")
    descriptor = artifacts[key]
    check(path.is_file() and path.stat().st_size == descriptor["bytes"] and sha(path) == descriptor["sha256"], f"{arm}: artifact {key}")
    return read(path) if path.suffix == ".json" else None


def source_gate(arm, spec, pins, profile):
    source_manifest = Path(spec["sourceManifest"]).resolve(strict=True)
    check(source_manifest == profile["armRoot"] / arm / "SOURCE-PINS.json", f"{arm}: arm path")
    check(sha(source_manifest) == pins["sourcePinsSha256"], f"{arm}: source manifest hash")
    arm_dir = source_manifest.parent
    assembly_path, tree = arm_dir / "ASSEMBLY.json", arm_dir / "tree"
    check(sha(assembly_path) == pins["assemblySha256"], f"{arm}: assembly hash")
    source_files, assembly = read(source_manifest), read(assembly_path)
    check(len(source_files) == pins["regularFiles"] == 197 and set(source_files) == set(assembly["files"]), f"{arm}: source inventory")
    check(assembly["arm"] == arm and assembly["regularFiles"] == 197 and assembly["productionFiles"] == 188, f"{arm}: assembly identity")
    check(assembly["sourcePinsSha256"] == pins["sourcePinsSha256"] and assembly["kitManifestSha256"] == pins["kitManifestSha256"], f"{arm}: assembly pins")
    actual = []
    for folder, dirs, files in os.walk(tree, followlinks=False):
        root = Path(folder)
        if root == tree:
            check("node_modules" in dirs and (tree / "node_modules").is_symlink(), f"{arm}: node_modules")
            dirs.remove("node_modules")
        for name in files:
            path = root / name
            check(path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1, f"{arm}: unsafe source file {path}")
            rel = path.relative_to(tree).as_posix()
            check(rel in source_files, f"{arm}: unexpected source file {rel}")
            check(sha(path) == source_files[rel] == assembly["files"][rel]["sha256"] and path.stat().st_size == assembly["files"][rel]["bytes"], f"{arm}: source hash {rel}")
            actual.append(rel)
    check(set(actual) == set(source_files) and len(actual) == 197, f"{arm}: missing source files")
    for entry, expected in pins["entrypoints"].items():
        check(sha(Path(entry)) == expected, f"{arm}: entrypoint {entry}")
    kit = profile["kit"]
    check(sha(kit / "MANIFEST.json") == pins["kitManifestSha256"] and sha(kit / "SOURCE-PINS.json") == pins["inputPinsSha256"], f"{arm}: kit/source input pins")
    kit_inputs = read(kit / "SOURCE-PINS.json")[arm]
    check(len(kit_inputs) == 189 and kit_inputs == {name: source_files[name] for name in kit_inputs}, f"{arm}: kit input source map")
    for name, expected in read(kit / "MANIFEST.json").items():
        check(sha(kit / name) == expected, f"{arm}: kit member {name}")
    return tree, source_files


def formal_gate(arm, leaf, receipt, binding, artifacts, profile):
    required_leaf = ("binding.json", "LAUNCH.json", "CHILD.json", "data.json", "vitest.json", "progress.jsonl", "stdout.txt", "stderr.txt")
    for name in required_leaf:
        artifact(leaf / name, artifacts, arm)
    launch, child = read(leaf / "LAUNCH.json"), read(leaf / "CHILD.json")
    check(launch["bindingSha256"] == sha(leaf / "binding.json") and launch["command"] == binding["command"] and launch["startNewSession"] is True, f"{arm}: launch binding")
    check(launch["ownedProcessGroup"] == child["processGroup"]["ownedProcessGroup"], f"{arm}: process group")
    for key in ("actualChildExit", "timedOut", "processGroup", "elapsedSeconds", "allGuardsExact", "command", "reportingErrors", "stdoutSha256", "stderrSha256"):
        check(receipt[key] == child[key], f"{arm}: child {key}")
    check(receipt["stdoutSha256"] == sha(leaf / "stdout.txt") and receipt["stderrSha256"] == sha(leaf / "stderr.txt"), f"{arm}: streams")
    vitest = read(leaf / "vitest.json")
    check(vitest["success"] is True and vitest["numTotalTests"] == vitest["numPassedTests"] == 1 and vitest["numFailedTests"] == 0 and vitest["numTotalTestSuites"] == vitest["numPassedTestSuites"] == 1 and vitest["numFailedTestSuites"] == 0, f"{arm}: one Vitest PASS")
    check(len(vitest["testResults"]) == 1 and vitest["testResults"][0]["status"] == "passed" and len(vitest["testResults"][0]["assertionResults"]) == 1 and vitest["testResults"][0]["assertionResults"][0]["status"] == "passed", f"{arm}: Vitest assertion")
    progress = [json.loads(line) for line in (leaf / "progress.jsonl").read_text().splitlines()]
    check([row["week"] for row in progress] == list(range(52, 417, 52)), f"{arm}: eight progress marks")
    check(all(set(row) == {"week", "elapsedSeconds"} and isinstance(row["elapsedSeconds"], (int, float)) and math.isfinite(row["elapsedSeconds"]) and row["elapsedSeconds"] >= 0 for row in progress), f"{arm}: progress shape")
    check(all(a["elapsedSeconds"] <= b["elapsedSeconds"] for a, b in zip(progress, progress[1:])), f"{arm}: progress order")
    formal = [Path(name) for name in artifacts if "/docs/" in name]
    check(len(formal) == 5, f"{arm}: formal artifact count")
    stem = next((p.name[:-15] for p in formal if p.name.endswith("-preflight.json")), None)
    check(stem is not None, f"{arm}: preflight absent")
    directory = next(p.parent for p in formal if p.name == stem + "-preflight.json")
    expected = {directory / (stem + suffix) for suffix in (".json", ".patch", ".txt", "-preflight.json", "-postflight.json")}
    check(set(formal) == expected, f"{arm}: formal artifact set")
    pre, record, post = (artifact(directory / (stem + suffix), artifacts, arm) for suffix in ("-preflight.json", ".json", "-postflight.json"))
    for suffix in (".patch", ".txt"):
        artifact(directory / (stem + suffix), artifacts, arm)
    head = receipt["pins"]["publicationHead"]
    check(pre["head"] == post["head"] == record["sourceSha"] == record["sourceShaAtEnd"] == head, f"{arm}: formal source HEAD")
    check(pre["advanceCap"] == 0 and record["fixedSource"] is True and post["fixedSource"] is True and post["allGuardsExact"] is True, f"{arm}: formal guards")
    check(record["exitCode"] == post["exitCode"] == receipt["recorderChildExit"] == 0, f"{arm}: formal exits")
    check(record["testedDiffSha256"] == record["testedDiffSha256AtEnd"] == receipt["pins"]["boundedDiffSha256"] and record["untrackedSource"] == record["untrackedSourceAtEnd"] == [], f"{arm}: formal diff")
    check(post["record"]["sha256"] == sha(directory / (stem + ".json")) and post["raw"]["sha256"] == sha(directory / (stem + ".txt")) and post["patch"]["sha256"] == sha(directory / (stem + ".patch")), f"{arm}: postflight members")
    check(Path(profile["manifestPath"]).is_file() and sha(Path(profile["manifestPath"])) == profile["manifestSha256"], f"{arm}: package manifest hash")
    check(Path(profile["runnerPath"]).is_file() and sha(Path(profile["runnerPath"])) == profile["runnerSha256"], f"{arm}: runner hash")
    check(record["command"][-4:] == [str(profile["runnerPath"]), "--child", str(leaf), sha(leaf / "binding.json")], f"{arm}: recorder command")


def verify(arm, spec, seed, profile):
    leaf = Path(spec["leaf"]).resolve(strict=True)
    receipt_path, data_path = leaf / "RESULT.json", leaf / "data.json"
    check(sha(receipt_path) == spec["resultSha256"], f"{arm}: RESULT hash")
    check(sha(data_path) == spec["dataSha256"], f"{arm}: data hash")
    receipt, data = read(receipt_path), read(data_path)
    for obj, label in ((receipt, "RESULT"), (data, "data")):
        check((obj["arm"], obj["mode"], obj["seed"]) == (arm, "clean", seed), f"{arm}: {label} identity")
    check(data["horizon"] == HORIZON and data["completed"] is True and data["sourcePostflight"] is True, f"{arm}: complete horizon/postflight")
    check(receipt["actualChildExit"] == receipt["recorderChildExit"] == 0, f"{arm}: exits")
    check(receipt["timedOut"] is False and receipt["allGuardsExact"] is True and receipt["livePostflightExact"] is True and receipt["reportingErrors"] == [], f"{arm}: formal guards")
    group = receipt["processGroup"]
    check(group["noSurvivors"] is True and group["leaderReaped"] is True and group["cleanupVerified"] is True and group["errors"] == [], f"{arm}: cleanup")
    pins = receipt["pins"]
    check(spec["pins"] == pins, f"{arm}: complete receipt pins")
    for key, expected in spec["pins"].items():
        check(pins[key] == expected, f"{arm}: pin {key}")
    check(pins["arm"] == arm, f"{arm}: source arm")
    check(pins["runnerManifestSha256"] == profile["manifestSha256"] and pins["selfRunnerSha256"] == profile["runnerSha256"], f"{arm}: reviewed package identity")
    if profile["classification"]:
        check(receipt["status"] == "PASS" and receipt["classification"] == pins["classification"] == profile["classification"] and receipt["route"] == pins["route"] == profile["route"], f"{arm}: exploratory identity")
        check((pins["probeTestSeconds"], pins["outerCapSeconds"], pins["horizon"]) == (*profile["caps"], HORIZON), f"{arm}: exploratory source caps")
    check(compact_hash(data["sourcePins"]) == spec["dataSourcePinsDigest"], f"{arm}: data source pins")
    check(len(data["weekly"]) == HORIZON and [w["week"] for w in data["weekly"]] == list(range(1, HORIZON + 1)), f"{arm}: contiguous weeks")
    check(data["phaseRows"] == data["industryRows"] == [], f"{arm}: clean observer arrays")
    check(data["actualPins"]["rows"] == len(data["rows"]), f"{arm}: row count")
    counts = Counter(row["kind"] for row in data["rows"])
    check(all(data["actualPins"][k] == counts[k] for k in ("settled", "declined", "expired")), f"{arm}: status counts")
    artifacts = receipt["artifacts"]
    check(str(data_path) in artifacts, f"{arm}: data absent from artifact list")
    check(artifacts[str(data_path)]["sha256"] == spec["dataSha256"], f"{arm}: data artifact pin")
    for name, descriptor in artifacts.items():
        path = Path(name).resolve(strict=True)
        check(path.is_file() and path.stat().st_size == descriptor["bytes"] and sha(path) == descriptor["sha256"], f"{arm}: artifact {name}")
    tree, source_files = source_gate(arm, spec, pins, profile)
    check(all(source_files.get(name) == value for name, value in data["sourcePins"].items()), f"{arm}: source manifest content")
    binding = read(leaf / "binding.json")
    check((binding["arm"], binding["mode"], binding["seed"], binding["horizon"]) == (arm, "clean", seed, HORIZON), f"{arm}: binding identity")
    check((binding["probeTestSeconds"], binding["outerCapSeconds"]) == profile["caps"], f"{arm}: reviewed time caps")
    if profile["classification"]:
        check(binding["classification"] == profile["classification"] and binding["route"] == profile["route"], f"{arm}: binding exploratory identity")
    check(binding["pins"] == pins and binding["publicationHead"] == pins["publicationHead"] and binding["manifestPin"] == profile["manifestSha256"] and binding["selfRunnerSha256"] == profile["runnerSha256"], f"{arm}: binding source identity")
    check(binding["typesReceipt"] and binding["typesReceiptSha256"] == sha(Path(binding["typesReceipt"])), f"{arm}: prior types receipt")
    types = read(Path(binding["typesReceipt"]))
    check(types["mode"] == "types" and types["arm"] == arm and types["actualChildExit"] == types["recorderChildExit"] == 0 and types["allGuardsExact"] is True and types["timedOut"] is False, f"{arm}: prior types status")
    for key in ("sourcePinsSha256", "assemblySha256", "kitManifestSha256", "inputPinsSha256", "runnerManifestSha256", "selfRunnerSha256", "entrypoints", "regularFiles"):
        check(types["pins"][key] == pins[key], f"{arm}: prior types {key}")
    check(binding.get("cleanReceipt") is None and binding.get("cleanReceiptSha256") is None, f"{arm}: clean predecessor")
    command = binding["command"]
    check(command == [next(name for name in pins["entrypoints"] if name.endswith("/node")), "node_modules/vitest/vitest.mjs", "run", "--workspace", "vitest.1368-ledger.workspace.ts", "--config", "vitest.1368-ledger.config.ts", "--maxWorkers", "1", "--minWorkers", "1", "--no-file-parallelism", "--reporter=verbose", "--reporter=json", "--outputFile.json=" + str(leaf / "vitest.json")], f"{arm}: probe command")
    check(receipt["command"] == command, f"{arm}: receipt command")
    check(str(tree / "tests/1368-ledger-attribution.test.ts") == read(leaf / "vitest.json")["testResults"][0]["name"], f"{arm}: Vitest source")
    formal_gate(arm, leaf, receipt, binding, artifacts, profile)
    return {"leaf": str(leaf), "resultSha256": spec["resultSha256"], "dataSha256": spec["dataSha256"], "sourcePinsSha256": pins["sourcePinsSha256"], "assemblySha256": pins["assemblySha256"], "artifactCount": len(artifacts)}, data


def rows_by_key(rows):
    buckets = defaultdict(list)
    for ordinal, row in enumerate(rows):
        key = (row["week"], row["talentId"], row["subjectStudioId"])
        buckets[key].append({"sourceOrdinal": ordinal, "row": row})
    return buckets


def selected_final(data, talent_ids):
    market = data["finalMarket"]
    def relevant(item):
        return item.get("talentId", item.get("personId")) in talent_ids or item.get("terms", {}).get("talentId") in talent_ids
    return {
        "market": {name: [r for r in rows if relevant(r)] for name, rows in market.items() if isinstance(rows, list)},
        "employment": [r for r in data["finalEmployment"] if relevant(r)],
        "industryReceipts": [r for r in data["finalIndustryReceipts"] if relevant(r)],
        "retirements": [r for r in data["finalRetirements"] if relevant(r)],
    }


def first_final_differences(c0, abc):
    collections = {"market." + name: (c0["finalMarket"][name], abc["finalMarket"][name])
                   for name in ("cases", "proposals", "receipts")}
    collections.update({name: (c0[name], abc[name]) for name in
                        ("finalEmployment", "finalIndustryReceipts", "finalRetirements")})
    first = {}
    for name, (left, right) in collections.items():
        for index in range(max(len(left), len(right))):
            a = left[index] if index < len(left) else None
            b = right[index] if index < len(right) else None
            if a != b:
                first[name] = {"sourceOrdinal": index, "C0": a, "ABC": b,
                               "C0Count": len(left), "ABCCount": len(right)}
                break
    return first


def compare(spec, fixture=False):
    seed = spec["seed"]
    check(seed == ("p13a-core-causal-01" if fixture else TARGET_SEED), "wrong seed for this mode")
    check(spec["horizon"] == HORIZON and set(spec["arms"]) == {"C0", "ABC"}, "manifest horizon/arms")
    if fixture:
        profile = {"manifestSha256": FIXTURE_MANIFEST_SHA256, "manifestPath": FIXTURE_MANIFEST_PATH, "runnerSha256": FIXTURE_RUNNER_SHA256, "runnerPath": FIXTURE_RUNNER_PATH, "kit": Path("/Users/zacheryspector/studio-scratch/1368-ledger-parent-prep-r4/kit"), "armRoot": Path("/Users/zacheryspector/studio-scratch/1368-ledger-arms-04"), "classification": None, "route": None, "caps": (300, 330)}
    else:
        check(EXPLORATORY_MANIFEST_SHA256 and EXPLORATORY_RUNNER_SHA256 and EXPLORATORY_RUNNER_PATH and EXPLORATORY_MANIFEST_PATH, "exploratory adoption package is not yet pinned")
        package = Path("/Users/zacheryspector/studio-scratch/1369-adoption-extended-proposal-r1")
        profile = {"manifestSha256": EXPLORATORY_MANIFEST_SHA256, "manifestPath": EXPLORATORY_MANIFEST_PATH, "runnerSha256": EXPLORATORY_RUNNER_SHA256, "runnerPath": EXPLORATORY_RUNNER_PATH, "kit": package / "kit", "armRoot": package / "arms", "classification": "EXPLORATORY_NOT_ACCEPTANCE", "route": "1369-adoption-clean-exploratory-720-750-r1", "caps": (720, 750)}
        check(sha(profile["manifestPath"]) == profile["manifestSha256"], "exploratory package hash")
        package_manifest = read(profile["manifestPath"])
        check((package_manifest["classification"], package_manifest["route"], package_manifest["seed"], package_manifest["horizon"], package_manifest["probeTestSeconds"], package_manifest["outerCapSeconds"], package_manifest["runnerSha256"]) == (profile["classification"], profile["route"], TARGET_SEED, HORIZON, 720, 750, profile["runnerSha256"]), "exploratory package content")
        for name, descriptor in package_manifest["files"].items():
            member = package / name
            check(member.is_file() and member.stat().st_size == descriptor["bytes"] and sha(member) == descriptor["sha256"], "exploratory package member " + name)
    c0id, c0 = verify("C0", spec["arms"]["C0"], seed, profile)
    abcid, abc = verify("ABC", spec["arms"]["ABC"], seed, profile)
    check(c0["originalPins"] == abc["originalPins"], "original pins differ")
    check(c0["sourcePins"] != abc["sourcePins"], "source maps unexpectedly equal")
    old, new = rows_by_key(c0["rows"]), rows_by_key(abc["rows"])
    paired, c0_only, abc_only = [], [], []
    for key in sorted(set(old) | set(new)):
        left, right = old[key], new[key]
        for i in range(min(len(left), len(right))):
            paired.append({"key": list(key), "occurrence": i + 1, "C0": left[i], "ABC": right[i], "rowEqual": left[i]["row"] == right[i]["row"]})
        for i in range(len(right), len(left)):
            c0_only.append({"key": list(key), "occurrence": i + 1, **left[i]})
        for i in range(len(left), len(right)):
            abc_only.append({"key": list(key), "occurrence": i + 1, **right[i]})
    check(len(c0["rows"]) == len(paired) + len(c0_only) and len(abc["rows"]) == len(paired) + len(abc_only), "occurrence accounting")
    first = {}
    for left, right in zip(c0["weekly"], abc["weekly"]):
        for field in FIELDS:
            if field not in first and left[field] != right[field]:
                first[field] = {"week": left["week"], "C0": left[field], "ABC": right[field], "C0Digest": compact_hash(left[field]), "ABCDigest": compact_hash(right[field])}
    changed_talents = {r["key"][1] for r in c0_only + abc_only}
    changed_talents.update(r["key"][1] for r in paired if not r["rowEqual"])
    return {
        "status": "DESCRIPTIVE_TWO_CLEAN_ONLY", "seed": seed, "horizon": HORIZON,
        "inputs": {"C0": c0id, "ABC": abcid}, "originalPins": c0["originalPins"],
        "actualPins": {"C0": c0["actualPins"], "ABC": abc["actualPins"]},
        "pinComparisons": {"C0": c0["pinComparisons"], "ABC": abc["pinComparisons"]},
        "counts": {"C0": len(c0["rows"]), "ABC": len(abc["rows"]), "paired": len(paired), "pairedIdentical": sum(r["rowEqual"] for r in paired), "C0Only": len(c0_only), "ABCOnly": len(abc_only)},
        "statusMix": {"C0": dict(Counter(r["kind"] for r in c0["rows"])), "ABC": dict(Counter(r["kind"] for r in abc["rows"]))},
        "firstWeeklyDifferences": first, "firstFinalDifferences": first_final_differences(c0, abc),
        "paired": paired, "C0Only": c0_only, "ABCOnly": abc_only,
        "relevantFinal": {"C0": selected_final(c0, changed_talents), "ABC": selected_final(abc, changed_talents)},
        "limits": ["Two sources differ as a bundle; no individual A/F6/B/C cause is assigned.", "This does not admit observed parity, protected repins, or 1363 closure."],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, help="JSON with seed, horizon, and exact C0/ABC leaf, RESULT/data hashes, source manifest, source digests and RESULT pins")
    parser.add_argument("--fixture-p13a", action="store_true", help="permit historical p13a input for self-test only")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    check(not args.output.exists(), "output already exists")
    result = compare(read(args.manifest), args.fixture_p13a)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(args.output), "sha256": sha(args.output), "counts": result["counts"], "firstWeeks": {k: v["week"] for k, v in result["firstWeeklyDifferences"].items()}}, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, FileNotFoundError, TypeError) as exc:
        print(f"REJECTED: {exc}", file=sys.stderr)
        sys.exit(2)
