// ── Public API (phase 1) ─────────────────────────────────────────────────────
// The test author imports ONLY from here. Re-exports the phase-1 surface:
// §2 declarations, the §2.1 vector math, §16 TUNING + named constants, §4 shape
// declarations, §13 grid declarations, the seeded RNG (M9), and §17 save.
//
// Phase-2+ logic (applyActions, tick, reception, forecast, agents, worldgen,
// broadcast) is intentionally absent — those phases add their exports here.

// §2 / §7 / §8 / §10 types
export type {
  Genre,
  SegmentId,
  CulturalForce,
  CreativeRole,
  CastSlot,
  Range,
  Persona,
  Expression,
  Talent,
  RoleRequirement,
  FilmConcept,
  FilmShape,
  ShapeOption,
  ShapeEffects,
  Promise,
  Budget,
  Production,
  FilmResult,
  TheatricalRun,
  TheatricalRunStatus,
  GameStateV3,
  FilmParticipant,
  FilmParticipantRole,
  FilmParticipants,
  Standing,
  Segment,
  CompetingRelease,
  MarketState,
  EraConfig,
  Studio,
  GameState,
  GameStateV2,
  GameStateV4,
  GameStateV5,
  GameStateV6,
  GameStateV7,
  GameStateV8,
  GameStateV9,
  GameStateV10,
  GameStateV11,
  PublicityTier,
  PublicityState,
  StudioOperationsMode,
  FacilityCapability,
  StudioFacility,
  ProductionPhase,
  FacilityReservation,
  ShootingTaskStatus,
  ShootingTask,
  ProductionBlocker,
  ProductionSetupRecipeId,
  ProductionSetupRoute,
  ProductionSetupRecord,
  ProductionSetupProvenance,
  ProductionWorkflow,
  StudioOperations,
  ConstructionMode,
  ConstructionParcelId,
  ConstructionProjectId,
  ConstructionProjectKind,
  ConstructionFacilityId,
  ConstructionProjectStatus,
  ConstructionParcel,
  ConstructionProject,
  StudioConstruction,
  // ── Placement Core V12 ──
  LotCell,
  LotRect,
  LotParcel,
  ParcelTerrain,
  FacilityBlueprint,
  PlacedFacility,
  PlacementStatus,
  PlacementRejection,
  PlacementCellVerdict,
  PlacementRequest,
  PlacementQuote,
  StudioPlacement,
  StudioPlacementMode,
  GameStateV12,
  // ── P13B-S3 physical plans ──
  PhysicalPlan,
  PhysicalPlanWork,
  PhysicalPlanStatus,
  PhysicalPlanAdmission,
  PlanQuoteSnapshot,
  StudioPhysicalPlans,
  GameStateV23,
  GameStateV24,
  GameStateV29,
  GameStateV30,
  GameStateV31,
  GameStateV32,
  GameStateV33,
  TalentProvenanceRoot,
  TalentProvenanceRow,
  RelationshipEdge,
  RelationshipDriver,
  RelationshipDriverKind,
  RelationshipTier,
  RelationshipCompetition,
  RomanceBond,
  RomanceTrack,
  ProfessionalPromiseV29,
  ProfessionalPromiseV30,
  ProfessionalPromiseV32,
  CastRoleCountPredicate,
  // ── Blueprint Requirements (C1-M2) ──
  BlueprintRequirement,
  BlueprintRequirementKind,
  UnmetRequirement,
  BlueprintAvailability,
  // ── Property State (C1-M1a) ──
  PlacementQueryOptions,
  PlacementMutationRefusal,
  FacilityEngagement,
  FacilityEngagementKind,
  FacilityMoveRequest,
  FacilityDemolitionRequest,
  PropertyState,
  PropertyStructure,
  PropertyStructureRole,
  GameStateV13,
  GameStateV14,
  GameStateV15,
  GameStateV16,
  ReleaseCommitment,
  StudioReleaseAuthority,
  SetTypeId,
  StudioSet,
  WorkflowBindings,
  ProductionQueueEntry,
  BlueprintBeat,
  MovieBlueprint,
  OriginalScreenplays,
  CommissionOriginalScreenplayPayload,
  StudioEvent,
  StudioEventKind,
  StudioEventLog,
  CashLedgerCheckpoint,
  ScriptDevelopmentMode,
  ScriptProjectStatus,
  ScriptRewriteCount,
  ScriptAssessment,
  ScriptReservation,
  ScriptProject,
  ScriptDevelopment,
  CommissionScriptPayload,
  GreenlightScriptProjectPayload,
  ScriptWriterAssignment,
  DevelopmentCastingOccupancy,
  CastingSessionsMode,
  CastingSessionStatus,
  CastingReservation,
  CastingSlate,
  AuditionResult,
  CastingResults,
  CastingSession,
  CastingSessions,
  StartCastingSessionPayload,
  TalentCareerEvent,
  CareerReasonCode,
  Action,
  AuthoredTalentInput,
  CustomTalentInput,
  BalancedTalentInput,
  ArchetypePreset,
  // D-11 employment / contracts / ledger / founding (types.ts)
  EmploymentStatus,
  Contract,
  LedgerKind,
  LedgerEntry,
  LedgerKindV10,
  LedgerEntryV10,
  FoundingState,
  Confidence,
  ForecastBand,
  ForecastFactorKey,
  SegmentForecast,
  Forecast,
  BroadcastFacts,
  BroadcastItem,
  CoverageContext,
  // D-9 multi-discipline talent vocabulary + supporting types (types.ts)
  Discipline,
  ActingSkill,
  WritingSkill,
  DirectingSkill,
  CraftSkill,
  SkillPair,
  DisciplineSkills,
  SkillProfiles,
  Ceilings,
  GenreExpEntry,
  GenreExperience,
  DevRates,
  WorkHistory,
  PotentialTier,
  SkillBias,
} from './types.js'

// Development & Casting Annex V1 — exact capital-project lifecycle and view.
export {
  ANNEX_PARCEL_ID,
  ANNEX_PROJECT_ID,
  ANNEX_PROJECT_KIND,
  ANNEX_FACILITY_ID,
  ANNEX_NAME,
  ANNEX_CAPEX,
  ANNEX_DURATION_WEEKS,
  ANNEX_CAPACITY_GAIN,
  ANNEX_LEDGER_NOTE,
  emptyStudioConstruction,
  initialManagedStudioConstruction,
  assertStudioConstructionInvariants,
  completeDueConstruction,
} from './construction.js'
export type {
  ConstructionInvariantOptions,
  ConstructionCompletion,
} from './construction.js'

// ── Placement Core V12 + Property State (C1-M1a) ─────────────────────────────
export {
  INITIAL_PROPERTY,
  BARE_LOT_DEPTH,
  BARE_LOT_PROPERTY,
  BARE_LOT_ROADS,
  BARE_LOT_WIDTH,
  BARE_LOT_PARCELS,
  BARE_LOT_STRUCTURES,
  bareLotProperty,
  INITIAL_PROPERTY_STRUCTURES,
  LOT_DEPTH,
  LOT_PARCELS,
  LOT_ROADS,
  LOT_WIDTH,
  LEGACY_EXPANSION_PARCEL_ID,
  cellKey,
  clonePropertyState,
  initialProperty,
  isOnLot,
  isRoadCell,
  parcelAt,
  parcelById,
  parcelHasRoadFrontage,
  placementWouldSeverLot,
  propertyOf,
  propertyStructureCellKeys,
  rectCells,
  roadCellKeys,
  structureCells,
} from './lot.js'
export {
  BASELINE_DEVELOPMENT_OFFICE_TIER,
  DEVELOPMENT_OFFICE_TIER_BLUEPRINT_IDS,
  developmentOfficeEstUplift,
  developmentOfficeTier,
  freelancerFeeMultiplier,
  hasOperationalBlueprint,
  nonStackingDiscountMultiplier,
  operationalBlueprintCount,
  supersedingOperationalBlueprintId,
} from './facilityEffects.js'
// P13B-S4 — the Office standard authority. A standard is derived from ordinary
// placement records, never persisted, so these are the ONE way to read one.
export {
  conversionQuote,
  developmentStandard,
  facilityOffline,
  highestOperationalDevelopmentStandard,
  isOfficeConversionBlueprint,
  offlineFacilityIds,
} from './officeConversion.js'
export type { ConversionQuote, DevelopmentStandard } from './officeConversion.js'
export {
  LIVE_REQUIREMENT_KINDS,
  blueprintAtInstanceLimit,
  blueprintInstanceCount,
  blueprintMaxInstances,
  blueprintRequirementMet,
  blueprintRequirementReason,
  evaluateBlueprintRequirements,
  requirementIsAttainable,
  FOUNDING_OFFICE_BLUEPRINT_ID,
  FOUNDING_OFFICE_REQUIREMENT_REASON,
  foundingPhaseOf,
  foundingPhaseRequirementsFor,
  effectiveBlueprintMaxInstances,
  blueprintAtInstanceLimitFor,
  blueprintNeededNow,
} from './blueprintRequirements.js'
export type { FoundingPhase } from './blueprintRequirements.js'
export {
  PLACEMENT_REJECTION_ORDER,
  RESERVED_PARCEL_BLUEPRINTS,
  parcelReservedBlueprintId,
  assertStudioPlacementInvariants,
  blueprintById,
  clearanceRingCells,
  commitPlacement,
  completeDuePlacements,
  emptyStudioPlacement,
  expectedWeeklyOperatingCostAt,
  footprintCells,
  initialManagedStudioPlacement,
  legacyAnnexPlacement,
  legacyAnnexOffered,
  legacyAnnexPlacementRequest,
  groundOccupiedCellKeys,
  occupiedCellKeys,
  capacityProvidingPlacedFacilities,
  operationalPlacedFacilities,
  placedStudioFacility,
  placementRegimeReady,
  queryPlacement,
  quoteForBlueprint,
  facilityEngagements,
  facilityInstallationPhase,
  facilityMoveRefusal,
  facilityDemolitionRefusal,
  facilityDemolitionRefund,
  moveFacility,
  demolishFacility,
  demolishedFacilityHistory,
  blueprintByLedgerNote,
  studioConstructionView,
  studioPlacementView,
  weeklyPlacementOperatingCost,
} from './placement.js'
export type {
  PlacedFacilityView,
  PlacementCatalogView,
  PlacementCompletion,
  PlacementParcelView,
  StudioConstructionView,
  StudioPlacementView,
} from './placement.js'

// ── Presence Projection V1 ───────────────────────────────────────────────────
// A pure, save-neutral projection of the CURRENT week into per-person beats.
// Changes zero outcomes, persists nothing, consumes zero simulation RNG.
export {
  BEATS_PER_WEEK,
  PRESENCE_DEPARTURE_WINDOW,
  PRESENCE_LAST_WORK_BEAT,
  ROSTER_HOME_FACILITY,
  rosterHomeFacilityId,
  studioPresence,
} from './presence.js'
export type {
  PersonPresence,
  PresenceBeat,
  PresenceCredit,
  PresenceEngagement,
  PresenceWithholding,
  StudioPresence,
} from './presence.js'

// ── First Film Journey V1 ────────────────────────────────────────────────────
// A pure, save-neutral projection of "where is my picture and what do I do next",
// derived entirely from the existing screenplay/casting/production read models.
export { firstFilmJourney } from './firstFilmJourney.js'
export type {
  FirstFilmJourneyNext,
  FirstFilmJourneyStage,
  FirstFilmJourneyView,
  PictureJourneyBeat,
  JourneySite,
  JourneyTargetKind,
} from './firstFilmJourney.js'

// §2.1 vector math + EPSILON
export {
  EPSILON,
  personaToExpression,
  magnitude,
  dot,
  distance,
  personaDistance,
  safeCosine,
} from './vector.js'

// numeric primitives used by contract formulas
export { clamp, mean, lerp, smoothstep, remap, weightedMean, sum, product } from './math.js'

// §16 TUNING + contract-declared named constants + D-9 named tables (D-9.16)
export {
  TUNING,
  CAST_WEIGHT,
  CASTING_CANDIDATES_PER_ROLE,
  CASTING_MIN_UNIQUE_CANDIDATES,
  CASTING_SESSION_WEEKS,
  CASTING_OBSERVATION_SIGMA,
  CASTING_RESULT_HALF_WIDTH,
  SLOT_TRANSFORM,
  ROLE_WEIGHT,
  FORCE_VECTORS,
  INITIAL_STANDING,
  WORLD_CONFIG,
  // C2a-M3 — the distributions a film concept is drawn from, and the fixed cast
  // slot order both worldgen and the screenplay mint build against.
  CONCEPT_DISTRIBUTIONS,
  SLOT_ORDER,
  // D-9.16 large tables / fixed orders (named exports beside CAST_WEIGHT/FORCE_VECTORS)
  SKILL_ORDER,
  DISCIPLINE_ORDER,
  PERSON_DISCIPLINE_ORDER,
  GENRE_ORDER,
  ROLE_TO_DISCIPLINE,
  // RULING B (2026-07-26) — multi-hyphenate generation mixture tables
  GEN_ARCHETYPE_MIX,
  GEN_SECONDARY_BANDS,
  GEN_ADJACENCY,
  OVR_WEIGHTS,
  GENRE_SKILL_WEIGHTS,
  SHAPE_SKILL_MODS,
  PROMISE_SKILL_MODS,
  PROMISE_MOD_THRESHOLDS,
  SLOT_SKILL_MODS,
  TEMPER_BANDS,
  POTENTIAL_TIER_THRESHOLDS,
  AUTHORED_TIER_COST,
  AUTHORED_TIER_RANGE,
  AUTHORED_START_OVR,
  // D-11.C Balanced Creator archetype presets
  BALANCED_ARCHETYPES,
  // C2a-M2 — the §3.4 buildable slate and the Set catalog (charter §9)
  STAGE_STANDARD_BLUEPRINT,
  STAGE_BLUEPRINTS,
  POST_BUILDING_BLUEPRINT,
  SCENERY_SHOP_BLUEPRINT,
  BASELINE_DEVELOPMENT_CASTING_BLUEPRINT,
  SET_BLUEPRINTS,
  SET_TYPE_LABELS,
  setBlueprintById,
  // C2a-M4: the queue's `build-blueprint` remedy quotes this catalog, so a
  // surface can price the relief it is being offered.
  FACILITY_BLUEPRINTS,
} from './tuning.js'
export type { SetBlueprint } from './tuning.js'

// §4 shape declarations + resolveShape (phase 2)
export { SHAPE_OPTIONS, specificity, resolveShape } from './shape.js'

// §5 reception pipeline (phase 2)
export {
  resolveReception,
  buildFilmResult,
  roleFit,
  castContribution,
  computeSegmentAppeal,
  computeBoxOffice,
  budgetRealizationDelta,
  scriptPotentialAppealDelta,
} from './reception.js'
export type { ReceptionInputs, ReceptionResult } from './reception.js'

// §7 forecast pipeline (phase 2) + the deterministic forecast-center helper
// (§15.6's behavioral-independence tests use it; the contract itself defines the
// deterministic center in §7/B16).
export { computeForecast, forecastCenters, bandOf } from './forecast.js'
export type { ForecastInputs, ForecastContext, ForecastCenters, DeterministicCore } from './forecast.js'

// §13 grid declarations
export {
  NEGATIVE_BUDGET_MULTIPLIERS,
  MARKETING_BUDGET_LEVELS,
  PROMISE_WIDTHS,
  PROMISE_CENTERS,
  rangeFrom,
  CANDIDATE_CONFIG,
} from './grid.js'

// D-17B §4 — regime-aware, capacity-anchored marketing menu. The legacy fixed
// grid above remains public because it is still authoritative for disengaged/M0A play.
export {
  marketingCapacityFor,
  marketingMenuFromCapacity,
  marketingLevelsFor,
} from './marketingMenu.js'
export type { MarketingMenu, MarketingMenuInputs } from './marketingMenu.js'

// D-17B §2 — exact publicity decision read model (same lift/cooldown/affordability as action).
export {
  PUBLICITY_TIER_ORDER,
  publicityLiftAt,
  publicityOffer,
  publicityOffers,
} from './publicity.js'
export type { PublicityOffer } from './publicity.js'

// seeded RNG (M9)
export { RngStream, stream } from './rng.js'
export type { RngPurpose } from './rng.js'

// §9 world generation (phase 3) + the §10-shared salary curve (B7)
export { generateWorld, salaryCurve } from './worldgen.js'
export type { GenerateWorldOptions } from './worldgen.js'

// ── C2a-M3 — Renewable Screenplay Generation V1 (charter §3.5) ───────────────
// The authored vocabulary, the mint, the set demand, the writer-speed law, and
// the provenance a surface prints.
export {
  BEAT_TEMPLATES,
  BEATS_PER_BLUEPRINT,
  TITLE_LEAD_BY_GENRE,
  UNUSED_RECOVERED_BEAT_SHAPES,
  type BeatTemplate,
  type BeatTemplateProvenance,
  type TemplateBeat,
} from './data/screenplay.js'
export { TITLE_LEAD, TITLE_NOUN } from './data/wordlists.js'
export {
  ACQUIRED_SCREENPLAY_LABEL,
  ORIGINAL_CONCEPT_ID_PREFIX,
  assertMovieBlueprintInvariants,
  beatsForGenre,
  blueprintForConcept,
  developmentOfficeRichnessTier,
  emptyOriginalScreenplays,
  generateScreenplayTitle,
  isOriginalConceptId,
  isOriginalScreenplay,
  mintOriginalConcept,
  mintedNegativeCost,
  movieBlueprint,
  normalizeScreenplayTitle,
  originalConceptId,
  originalScreenplayCredit,
  persistedConceptIds,
  renameScreenplayRefusal,
  requiredSetDemand,
  requiredSetTypes,
  screenplayDraftConsequence,
  screenplayProvenance,
  scriptDraftWeeks,
  writingPaceExperience,
  type MovieBlueprintInvariantContext,
  type RequiredSetTypeView,
  type ScreenplayProvenanceView,
  type ScreenplayRenameRefusal,
} from './screenplay.js'
export { persistedProductionIds } from './productionIdentity.js'

// §3 applyActions (phase 3) — greenlight / cancel / createTalent / createCustomTalent / createBalancedTalent
export { applyActions, previewCustomTalent, previewBalancedTalent, balancedBoostDiscipline, predictProductionId } from './actions.js'

// Production Operations V1 — authoritative phase/facility/task helpers.
export {
  INITIAL_STUDIO_FACILITIES,
  foundingFacilitiesOf,
  emptyStudioOperations,
  initialManagedStudioOperations,
  addManagedProductionWorkflow,
  advanceManagedProductions,
  emptyWorkflowBindings,
  productionPhaseForRemainingTicks,
  // C2a-M4 (§3.3): the queue order for production transitions and the derived
  // aging term it is ordered by.
  productionWaitWeeks,
  productionsInSweepOrder,
  assertStudioOperationsInvariants,
} from './operations.js'

// Shared resource occupancy (C2a-M0, charter §3.2) — THE one named union
// producer over every persisted holder of studio capacity, plus the fail-closed
// cross-owner double-booking refusal every boundary wires into.
export {
  occupiedResourceSlots,
  resourceClaims,
  resourceClaimsOf,
  resourceSlotClaimsOf,
  screenplayOccupiedSlotKeys,
  findDoubleBookedResourceSlot,
  assertNoDoubleBookedResourceSlots,
  isResourceSlotClaim,
  facilitySlotKey,
  resourceSlotKey,
  resourceFacilityKey,
} from './occupancy.js'

// ── C2a-M1 — Sets (charter §3.1) and the studio event ledger (§5) ────────────
export {
  SET_TYPES,
  STARTER_SET_TYPE,
  HOUSE_SET_BLUEPRINT_ID,
  ENDOWED_HOUSE_SET_STAGES,
  ENDOWED_NEXT_SET_ID,
  endowedHouseSets,
  neutralGenreWeights,
  setId,
  setTypeLabel,
  // C2a-M2 — the life of a Set (charter §3.1)
  assertSetsInvariants,
  bindableSetsOnStage,
  commissionSet,
  commissionSetRefusal,
  completeDueSets,
  depleteSetNoveltyForRelease,
  hasFreeSceneryCapacity,
  mintSetName,
  productionBoundToSet,
  repairSet,
  repairSetRefusal,
  setBindingUplift,
  setById,
  setCapexLedgerNote,
  setCommissionCost,
  setCommissionRefusalCopy,
  setDemolitionRefund,
  setGenreFit,
  setIsUnderRepair,
  setIsUsable,
  setMountedOn,
  setNoveltyReceptionFactor,
  setRepairLedgerNote,
  setRepairRefusalCopy,
  setStrikeLedgerNote,
  setStrikeRefusalCopy,
  strikeSet,
  strikeSetRefusal,
  wearSetAtWrap,
} from './sets.js'
export type {
  SetCommissionRefusal,
  SetRepairRefusal,
  SetStrikeRefusal,
  SetRefusalCopy,
} from './sets.js'
export type { KnownSetTypeId } from './sets.js'
export {
  TIER_D_STUDIO_EVENT_KINDS,
  isTierDStudioEventKind,
  emptyStudioEventLog,
  compactStudioEvents,
  commitStudioEvents,
  disabledStudioEventSink,
  studioEventProductionIds,
  StudioEventSink,
} from './studioEvents.js'
export type { StudioEventDraft } from './studioEvents.js'
export type {
  OccupancySources,
  OccupiedSlotFilter,
  ResourceClaim,
  ResourceDoubleBooking,
  ResourceKind,
  ResourceOccupancy,
  ResourceOwnerKind,
  ResourceSlotClaim,
} from './occupancy.js'

// Script Projects V1 — authoritative screenplay lifecycle and shared capacity.
export {
  emptyScriptDevelopment,
  initialManagedScriptDevelopment,
  canonicalScriptProjectId,
  nextScriptProjectId,
  scriptOccupiedFacilitySlots,
  developmentCastingOccupancy,
  availableDevelopmentCastingSlots,
  allocateScriptReservation,
  commissionScriptProject,
  assessFirstDraft,
  scriptRewriteDelta,
  rewriteAssessment,
  completeDueScriptWork,
  requestScriptRewrite,
  acceptScriptProject,
  linkScriptProjectToProduction,
  returnScriptProjectToReady,
  markScriptProjectProduced,
  scriptProjectForProduction,
  readyScriptPerceivedStrength,
  linkedScriptStrengthOverride,
  scriptProjectsNeedingReview,
  nextScriptProjectNeedingReview,
  activeScriptWriterAssignments,
  joinScreenplayWriterPool,
  scriptProjectWriterIds,
  scriptWriterAssignment,
  screenplayFactsMatch,
  assertScriptDevelopmentInvariants,
} from './scriptDevelopment.js'
export type {
  ScriptWorkSources,
  ScriptDevelopmentInvariantContext,
} from './scriptDevelopment.js'

// Casting Sessions V1 — optional one-week camera tests and persisted evidence.
export {
  emptyCastingSessions,
  initialManagedCastingSessions,
  canonicalCastingSessionId,
  nextCastingSessionId,
  castingSessionForProject,
  castingSessionsNeedingReview,
  nextCastingSessionNeedingReview,
  castingSlateTalentIds,
  assertCastingSlateLaw,
  assertCastingSlateEligibility,
  castingOccupiedFacilitySlots,
  castingDevelopmentCastingOccupancy,
  allocateCastingReservation,
  startCastingSession,
  auditionObservation,
  completeDueCastingSessions,
  acknowledgeCastingSession,
  assertCastingSessionsInvariants,
} from './castingSessions.js'
export type {
  CastingStartSources,
  CastingCompletionSources,
  CastingSessionsInvariantContext,
} from './castingSessions.js'

// Casting Sessions V1 — narrow player-facing Casting Room projection.
export {
  CASTING_SESSION_CONSEQUENCE,
  castingSessionsReadModel,
  nextCastingDecision,
} from './castingReadModel.js'
export type {
  CastingCandidateView,
  AuditionEvidenceView,
  CastingProjectActionView,
  CastingProjectView,
  CastingReviewDecisionView,
  CastingSessionsReadModel,
} from './castingReadModel.js'

// Script Projects V1 — narrow player-facing Writers Room projection. These
// fresh read models contain perceived estimates and legal commands only.
export {
  SCRIPT_DEVELOPMENT_WEEK_CONSEQUENCE,
  estimatedScriptAssessment,
  estimatedBandForScore,
  scriptAssessmentExplanation,
  rewriteDecisionPreview,
  scriptCapacityView,
  scriptProjectsReadModel,
  nextScriptDecision,
  nextStudioDecision,
} from './scriptReadModel.js'
export type {
  ScriptAssessmentExplanationView,
  RewriteDecisionPreviewView,
  ScriptProjectSection,
  ScriptPlayerBlockerKind,
  ScriptPlayerBlocker,
  ScriptProjectActionView,
  EstimatedScriptAssessmentView,
  ScriptWriterView,
  ScriptProjectCardView,
  ScriptCapacityOccupantView,
  ScriptCapacitySlotView,
  ScriptCapacityFacilityView,
  ScriptCapacityView,
  CommissionConceptView,
  CommissionWriterView,
  ScriptCommissionAvailabilityView,
  ScriptPackageAvailabilityView,
  ReadyScriptPackageView,
  ScriptReviewDecisionView,
  ProductionOperationsCommand,
  ProductionOperationsDecisionView,
  StudioDecisionView,
  ScriptLotAttentionView,
  ScriptProjectsReadModel,
} from './scriptReadModel.js'

// Casting Package V1 — the role-first package-assembly projection (director/
// lead/antagonist/support/craftLead pools, closed budget menus, readiness).
export { castingPackageReadModel, freelancerMarketRefreshWeek, hiringMarketView, returnWeek } from './castingPackageReadModel.js'
export type {
  PackageCandidateView,
  PublicSignalView,
  AuditionEvidenceRef,
  RolePoolView,
  CastingPackageProjectView,
  ContractOfferView,
  HiringCandidateView,
  PackageBlockerView,
} from './castingPackageReadModel.js'

// Studio Calendar & Capacity Board V1 — pure studio-wide planning projection.
export { studioCalendar } from './studioCalendar.js'
export type {
  StudioCalendarDecisionView,
  StudioCalendarOccupantView,
  StudioCalendarSlotView,
  StudioCalendarFacilityView,
  StudioCalendarCommitmentView,
  StudioCalendarProductionFacilityView,
  StudioCalendarProductionBlockerView,
  StudioCalendarProductionView,
  StudioCalendarContractView,
  StudioCalendarExpiryClusterView,
  StudioCalendarSummaryView,
  StudioCalendarView,
} from './studioCalendar.js'

// ── The production queue (C2a-M4, charter §3.3) ──────────────────────────────
// Phase-Gate Admission: the front doors admit what capacity cannot yet carry,
// and the queue is the studio's record of what is waiting for what.
export {
  QUEUE_GATE_CAPABILITY,
  QueueableCapacityRefusal,
  freeGateSlot,
  gateSlotAvailable,
  nextQueueOrdinal,
  queueEntryLabel,
  queueEntrySubjectId,
  queueInPriorityOrder,
  queueWaitWeeks,
} from './productionQueue.js'
export { admitQueuedIntents } from './queueAdmission.js'
export type { QueueAdmissionResult } from './queueAdmission.js'

// ── The Studio Queue (C2a-M4, charter §3.3) ──────────────────────────────────
// The DERIVED law-2 surface: what waits, what it needs, who occupies it, when it
// frees, and what relieves it. Beside `studioCalendar()`, fed by the same
// authorities, and never persisted.
export { studioQueueView } from './studioQueueView.js'
export type {
  StudioQueueNeedView,
  StudioQueueOccupantView,
  StudioQueueRemedy,
  StudioQueueWaiterView,
  StudioQueueView,
} from './studioQueueView.js'

// ── Scenery Load-In V2 (C2a-M5, charter §4.2) ────────────────────────────────
// The one place ground has a deterministic consequence on time. Pure geometry
// over authored structures and completed placements; nothing persisted.
export {
  facilityBodyCentre,
  gridDistance,
  isSceneryLoadIn,
  sceneryLoadInDecision,
  sceneryLoadInFor,
  sceneryLoadInWeeksForDistance,
} from './sceneryLoadIn.js'
export type {
  SceneryLoadIn,
  SceneryLoadInDecision,
  SceneryLoadInWithheldReason,
  SceneryLoadInWithholding,
} from './sceneryLoadIn.js'

// ── Studio Week Theater V1 (C2a-M5, charter §4.2) ────────────────────────────
// The manufacturing loop as beat tracks over the engine's own ten-beat week —
// scenery in transit, stages hot and dark, sets going up and coming down, a wrap
// clearing a stage, companies waiting, a building rising. Presence's twin: pure,
// save-neutral, RNG-neutral, withholds with a reason, never throws.
export { studioWeekTheater } from './studioWeekTheater.js'
export type {
  StudioWeekTheater,
  TheaterBeat,
  TheaterSubject,
  TheaterSubjectKind,
  TheaterWithholding,
} from './studioWeekTheater.js'

// §6 standing (phase 3) — the three-channel updateStanding (B12 context param)
export { updateStanding } from './standing.js'
export type { ReleaseBenchmarks, StandingContext } from './standing.js'

// §3 tick (phase 3/D-9) — PRODUCTION→RELEASE→RECEPTION→STANDING→BROADCAST→DEVELOPMENT.
// DEVELOPMENT (step 6, D-9.8) is gated by TickOptions.develop (default false).
export { tick } from './tick.js'
export type { TickOptions } from './tick.js'

// ── D-9 talent read-only summaries + the §5/§7 effectiveSkill substitute ──────
// effectiveSkill + projectSkillWeights are the ONLY sim-read functions; the rest
// are display/development inputs (never read by §5/§7). (talentSummary.ts)
export {
  effectiveSkill,
  castSlotExecution,
  projectSkillWeights,
  genreExperience,
  workHistoryCount,
  roleOVR,
  roleTier,
  projectFit,
  expectedPerformance,
  temperamentSummary,
  expectedPotentialTier,
  expectedPotentialRange,
  workEthicLabel,
  careerIdentity,
  developmentReport,
  ageRunwayMult,
} from './talentSummary.js'
export type { SkillUse, PerformanceBand, DisciplineStanding, CareerIdentity } from './talentSummary.js'

// ── D-9.8 development (tick step 6 core) — pure per-release skill growth ───────
export { developTalent } from './development.js'
export type { DevelopmentContext } from './development.js'

// ── D-11.C newspaper release reveal (newspaper.ts) — pure deterministic derivation ─
export {
  buildFilmChronicle,
  buildNewspaper,
  criticStars,
  audienceTier,
  aggregateAudienceScore,
  NEWSPAPER_MASTHEAD,
} from './newspaper.js'
// ── P07A W0 canonical reception-verdict module (single source of the verdict logic) ─
export { criticBand, criticTier, filmCommittedCost, filmAudienceScore } from './receptionVerdict.js'
export type { ReceptionBand, CriticTier } from './receptionVerdict.js'
export type {
  NewspaperView,
  NewspaperInput,
  CriticRating,
  AudienceTier,
  FilmChronicleScriptInput,
  FilmChronicleLedgerInput,
  FilmChronicleReception,
  FilmChronicleInput,
  FilmChronicleUnavailable,
  FilmChronicleCreativeRecord,
  FilmChronicleCredits,
  FilmChronicleProductionRecord,
  FilmChronicleFit,
  FilmChroniclePackageRecord,
  FilmChronicleView,
} from './newspaper.js'

// ── D-12 studio economy (economy.ts) — pure theatrical-run + fame-saturation math ─
export { fameReach, theatricalSchedule, openTheatricalRun, legacyTheatricalRun } from './economy.js'

// ── D-12 financial read models (economyView.ts) — the SINGLE UI money source ────
// Pure, deterministic, display-only. Mirrors the exact engine math (tick 3.5/7.5,
// payroll, solvency, runway). The sim never reads these.
export {
  weeklyOverhead,
  weeklyFacilityOperatingCost,
  projectedWeeklyOverhead,
  weeklyBurn,
  foundingRunwayPreview,
  runNextWeekRevenue,
  runRemainingRevenue,
  expectedWeeklyRunRevenue,
  pipelineRunRevenue,
  runway,
  affordability,
  commitmentPreview,
  breakEvenGross,
  prospectiveCycleFixedCost,
  cycleInclusiveBreakEvenGross,
  regimeStudioShare,
  affordabilityScopes,
  offerObligation,
  postSigningRunway,
  runView,
  activeRunViews,
  financeTotals,
  periodSummary,
  financeView,
} from './economyView.js'
export type {
  Runway,
  CommitmentPreview,
  CycleFixedCost,
  CycleInclusiveBreakEven,
  AffordabilityScopes,
  OfferObligation,
  PostSigningRunway,
  RunView,
  FinanceTotals,
  PeriodSummary,
  FinanceView,
} from './economyView.js'

// ── D-17A/T3 retrospective fixed-cost allocation (fixedCostAllocation.ts) ──────
// Pure managerial attribution of ACTUAL ledger payroll+overhead across the films that
// occupied the studio each week, with unallocated idle burn reported separately. Reconciles
// to the ledger over any window (R7 safeguard). The sim never reads it.
export {
  allocateFixedCosts,
  allocateFixedCostSeries,
  fixedCostOccupancy,
  filmOccupancyWindows,
  ledgerFixedCostByWeek,
  partitionWeeklyFixedCost,
} from './fixedCostAllocation.js'
export type {
  AllocationWindow,
  FixedCostAllocation,
  FilmFixedCostAllocation,
  WeeklyOccupancy,
} from './fixedCostAllocation.js'

// ── D-15 Studio Run Recap (studioRunRecap.ts) — pure read-only run explainer ───
// Reconstructs the whole-run recap (capital story, film slate, talent development,
// concentration, current position + recovery, inflections, warnings) from the live
// GameState. Adds no persistence, mutates nothing, advances no RNG, recomputes no
// film/career outcome. The sim never reads it.
export {
  studioRunRecap,
  classifyContribution,
  // D-17A/T4 — the recap's own package/affordability builders, promoted (math untouched) so
  // every surface answers "can I make a film?" with the same number.
  cheapestPackage,
  standardPackage,
  cheapestPackageQuote,
  standardPackageQuote,
  packageAllIn,
  contractedRosterCanField,
  recentTypicalCommitment,
  affordabilityOf,
} from './studioRunRecap.js'
export type {
  StudioRunRecap,
  RunSummary,
  CapitalStory,
  RecapFilm,
  RecapTalent,
  Concentration,
  ConcentrationEntry,
  RecurringMember,
  CurrentPosition,
  PositionAffordability,
  PackageBreakdown,
  ProspectivePackageQuote,
  RecoveryPosition,
  FilmContributionClass,
  InflectionPoint,
  InflectionKind,
  RecapWarning,
  RecapWarningCode,
  WarningSeverity,
  FixedCostAllocationBasis,
} from './studioRunRecap.js'

// ── D-11 employment / contracts / roster / freelancer market (employment.ts) ──
// Pure, deterministic, read-only helpers (status/offers/markets/payroll/founding).
// The engine reads these in actions.ts (sign/renew/release/greenlight legality) and
// tick.ts (payroll/expiration); the UI reads the display/selector helpers.
export {
  employmentEngaged,
  economyEngaged,
  canAfford,
  employmentStatus,
  activeContract,
  isContracted,
  assignableForFilm,
  assignmentProjectCost,
  busyTalentIds,
  activeProductionCompanyTalentIds,
  seatingProduction,
  activeWritingAssignmentIds,
  creditedWriterIds,
  weeklySalary,
  guaranteedComp,
  terminationCost,
  weeklyPayroll,
  annualPayroll,
  renewalWindowOpen,
  contractOffer,
  contractOfferOptions,
  offerForTalent,
  freelancerFee,
  freelancerMarketIds,
  hiringMarketIds,
  rosterTalent,
  rosterCoverage,
  foundingMinimumsMet,
  foundingGaps,
  FOUNDING_MINIMUMS,
  beginFounding,
  correlateConceptCost,
} from './employment.js'
export type { ContractOffer, Affordability } from './employment.js'

// ── Phase 5.1 CYCLE 3 — Film Package assessment helpers (READ-ONLY UI summaries) ─
// Pure, deterministic, JSON-serializable read-only assessments the UI calls so it
// never reinvents a §5/§7/D-9 formula. The sim never reads any of these (exactly
// like the D-9 talentSummary display functions). (filmPackage.ts)
export {
  creativeCohesion,
  packageFit,
  executionConfidence,
  forecastProfitRange,
  greenlightAssessment,
  risksMaterialized,
  packageDelta,
  // D-17A/T6 — same-rule discoverability exposure (mirrors reception.ts:633-642);
  // player-visible operands only, no realized draw.
  discoveryExposure,
  // Casting Package V1 — the negative-budget-menu formula promoted verbatim from
  // ui/src/engine/adapter.ts's requiredNegative, symmetric to marketingLevelsFor.
  requiredNegative,
} from './filmPackage.js'
export type {
  CreativeCohesion,
  AssignmentFit,
  PackageFitInput,
  PackageFit,
  ExecutionConfidence,
  ExecutionConfidenceInput,
  ExecutionConfidenceContext,
  MoneyRange,
  ForecastProfitRange,
  ForecastProfitInput,
  ForecastProfitContext,
  GreenlightAssessment,
  PreTickSnapshot,
  MaterializedRisk,
  RisksMaterialized,
  AssignmentDelta,
  PackageDelta,
  PackageSide,
  DiscoveryExposure,
} from './filmPackage.js'

// §8 broadcast (phase 4) — the minimal deterministic broadcast core (B22/B23/B24/M10).
// Public entry + facts/ranking/template helpers for the test author, plus the two
// release template ids and their renderer.
export {
  evaluateReleaseBroadcast,
  deriveFacts,
  rankRelease,
  editorialRelevance,
  renderReleaseTemplate,
  releaseTemplateId,
  RELEASE_BETTER_TEMPLATE_ID,
  RELEASE_WORSE_TEMPLATE_ID,
} from './broadcast.js'
export type { ReleaseBroadcastInputs, RankingBreakdown } from './broadcast.js'

// §13 candidate generator (phase 3, step 4) — the finite, deterministic,
// agent-independent decision grid (B18/B19/B21).
export { generateCandidates, packageReceptionInputs } from './candidates.js'
export type { CandidatePackage } from './candidates.js'

// §13 agents (phase 3, step 4) — RandomAgent + OracleAgent over the shared grid
// (ruling #3/#4, D-1).
export { RandomAgent, OracleAgent } from './agents.js'
export type { Agent } from './agents.js'

// §17 save — frozen V1–V10 envelopes plus live Annex V1 V11.
// stableStringify/deepEqual are unchanged. validateSave dispatches on version and
// loudly rejects unknown versions. New games save as V11.
export {
  stableStringify,
  deepEqual,
  validateSave,
  validateSaveV1,
  validateSaveV2,
  validateSaveV3,
  validateSaveV4,
  validateSaveV5,
  validateSaveV6,
  validateSaveV7,
  validateSaveV8,
  validateSaveV9,
  validateSaveV10,
  validateSaveV11,
  validateSaveV12,
  validateSaveV13,
  validateSaveV14,
  validateSaveV15,
  validateSaveV16,
  LIVE_SAVE_VERSION,
  makeSave,
  makeSaveV1,
  makeSaveV2,
  makeSaveV3,
  makeSaveV4,
  makeSaveV5,
  makeSaveV6,
  makeSaveV7,
  makeSaveV8,
  makeSaveV9,
  makeSaveV10,
  makeSaveV11,
  makeSaveV12,
  makeSaveV13,
  makeSaveV14,
  makeSaveV15,
  makeSaveV16,
  loadSave,
  exportSave,
  importSave,
  // D-9.15 (owner-overridden) — legacy V1 → NEW V2, deterministic + idempotent.
  migrateTalent,
  convertV1ToV2,
  importLegacyV1,
  // D-11.16 — legacy V2 → NEW V3 (and V1 → V3), deterministic + idempotent.
  convertV2ToV3,
  importLegacyV2,
  importLegacyV1ToV3,
  // D-12 — legacy V3 → NEW V4 (and V2/V1 → V4) + migrateToV4, deterministic + idempotent.
  convertV3ToV4,
  importLegacyV3ToV4,
  importLegacyV2ToV4,
  importLegacyV1ToV4,
  migrateToV4,
  // D-14 — legacy V4 → NEW V5 + migrateToV5, deterministic + idempotent.
  convertV4ToV5,
  migrateToV5,
  // D-17A/R2 — legacy V5 → NEW V6 + migrateToV6 (reconstructs the persisted engagement
  // fact), deterministic + idempotent.
  convertV5ToV6,
  migrateToV6,
  // D-17B/E4 — legacy V6 → NEW V7 + migrateToV7 (seeds the empty publicity state),
  // deterministic + idempotent.
  convertV6ToV7,
  migrateToV7,
  emptyPublicityState,
  // Production Operations V1 — legacy V7 → V8 seeds explicit legacy/empty state.
  emptyLegacyOperations,
  convertV7ToV8,
  migrateToV8,
  // Script Projects V1 — legacy V8 → V9 seeds explicit legacy/empty state.
  emptyLegacyScriptDevelopment,
  convertV8ToV9,
  migrateToV9,
  // Casting Sessions V1 — legacy V9 → V10 seeds explicit legacy/empty state.
  convertV9ToV10,
  migrateToV10,
  // Development & Casting Annex V1 — legacy V10 → live V11.
  convertV10ToV11,
  convertV11ToV12,
  convertV12ToV13,
  convertV13ToV14,
  migrateToV11,
  migrateToV12,
  migrateToV13,
  migrateToV14,
  // P04A (§2.5) — live V14 → NEW V15 + migrateToV15 (identity-bearing queue
  // expiry: `subjectId` on `queueIntentExpired`), deterministic + idempotent.
  convertV14ToV15,
  migrateToV15,
  // P06A (charter W1) — live V15 → NEW V16 + migrateToV16 (the release-
  // commitment authority root; empty on migration = explicitly uncommitted).
  convertV15ToV16,
  migrateToV16,
  // P08A — live V16 → NEW V17 + migrateToV17 (the studio-history root).
  convertV16ToV17,
  migrateToV17,
  makeSaveV17,
  validateSaveV17,
  // P09 — live V17 → NEW V18 + migrateToV18 (the founding-regime root).
  convertV17ToV18,
  migrateToV18,
  makeSaveV18,
  validateSaveV18,
  validateSaveV19,
  migrateToV19,
  convertV18ToV19,
  validateSaveV20,
  migrateToV20,
  convertV19ToV20,
  // P13B-S1 — frozen V20 → V21 + migrateToV21 (technology root v2: named
  // seats and single-pool per-week research receipts).
  validateSaveV21,
  migrateToV21,
  convertV20ToV21,
  // P13B-S2 — live V21 → NEW V22 + migrateToV22 (technology root v3: per-Laboratory
  // receipt rows, the 1/160,000 project-credit base and the cooperation week).
  validateSaveV22,
  migrateToV22,
  convertV21ToV22,
  // P13B-S3 — frozen V22 → V23 + migrateToV23 (the persistent physical plan root).
  validateSaveV23,
  migrateToV23,
  convertV22ToV23,
  // P13B-S5 — live V23 → NEW V24 + migrateToV24 (technology root v4: adoption
  // component rows and durable equipment assets).
  validateSaveV24,
  migrateToV24,
  convertV23ToV24,
  // P13B-S6 — V25 → V26 + migrateToV26 (the widened cancellation leaves).
  validateSaveV26,
  migrateToV26,
  convertV25ToV26,
  // P13B-S8 — live V26 → NEW V27 + migrateToV27 (the rival research movements and receipts).
  validateSaveV27,
  migrateToV27,
  convertV26ToV27,
  convertV27ToV26,
  projectHollywoodPreV27,
  // P14A.1 — live V27 → NEW V28 + migrateToV28 (the `talentMarket` root).
  validateSaveV28,
  migrateToV28,
  // P14B.1 — live V28 → NEW V29 + migrateToV29 (`firstTakes` + `promises`).
  validateSaveV29,
  migrateToV29,
  convertV28ToV29,
  convertV29ToV28,
  // P14B.4 — V29 → V30 + migrateToV30 (explicit P2 seat class; record 600).
  validateSaveV30,
  migrateToV30,
  convertV29ToV30,
  convertV30ToV29,
  // P14B.5 — V30 → V31 + migrateToV31 (the `relationships` root).
  validateSaveV31,
  migrateToV31,
  convertV30ToV31,
  convertV31ToV30,
  // P14B.7 — V31 → V32 + migrateToV32 (the waived-promise link).
  validateSaveV32,
  migrateToV32,
  convertV31ToV32,
  convertV32ToV31,
  // P14C.1 — V32 → V33 + migrateToV33 (the talent provenance root).
  validateSaveV33,
  validateTalentProvenanceRoot,
  migrateToV33,
  convertV32ToV33,
  convertV33ToV32,
  // P14C.2a — live V33 → NEW V34 + migrateToV34 (the career lifecycle root), and the
  // live-route alias every "lift to what makeSave stamps" caller uses (record 776).
  validateSaveV34,
  validateCareerLifecycleRoot,
  migrateToV34,
  convertV33ToV34,
  convertV34ToV33,
  migrateToLive,
  // P14C.4 — V34 → V35 + migrateToV35 (the cohort receipts), the live boundary until
  // P14C.2b (record 793 §5).
  validateSaveV35,
  convertV34ToV35,
  convertV35ToV34,
  migrateToV35,
  // P14C.2b — V35 → V36 + migrateToV36 (the single final extension).
  validateSaveV36,
  convertV35ToV36,
  convertV36ToV35,
  migrateToV36,
  // Record 840 — the Scientist retirement law, with frozen prior readers.
  validateSaveV37,
  convertV36ToV37,
  convertV37ToV36,
  migrateToV37,
  validateSaveV38,
  convertV37ToV38,
  convertV38ToV37,
  migrateToV38,
  validateSaveV39,
  convertV38ToV39,
  convertV39ToV38,
  migrateToV39,
  validateSaveV40,
  convertV39ToV40,
  convertV40ToV39,
  migrateToV40,
  validateSaveV41,
  convertV40ToV41,
  convertV41ToV40,
  migrateToV41,
  validateSaveV42,
  convertV41ToV42,
  convertV42ToV41,
  migrateToV42,
  validateSaveV43,
  convertV42ToV43,
  convertV43ToV42,
  migrateToV43,
  validateSaveV44,
  convertV43ToV44,
  convertV44ToV43,
  migrateToV44,
  // The shared P15 step, Save45 (1361-F ruling 8): slice 2a's Power Ranking archive and P15 allocator.
  validateSaveV45,
  convertV44ToV45,
  convertV45ToV44,
  migrateToV45,
  // Combined rival recovery, Save46 (1367-H).
  validateSaveV46,
  convertV45ToV46,
  convertV46ToV45,
  migrateToV46,
  // 1364 (1364-A §3), Save47: the recruitment-fund authority `foundingFunding`, additive over Save46.
  FOUNDING_FUNDING_SAVE_VERSION,
  validateSaveV47,
  convertV46ToV47,
  convertV47ToV46,
  migrateToV47,
  // P15B (record 1370-ar), Save48: the P15B save step under its own names and the conventional
  // version-derived aliases (renumbered with P15B_SAVE_VERSION in save.ts).
  P15B_SAVE_VERSION,
  validateSaveP15B,
  convertToP15BSave,
  convertFromP15BSave,
  migrateToP15BSave,
  validateSaveV48,
  convertV47ToV48,
  convertV48ToV47,
  migrateToV48,
  convertV27ToV28,
  convertV28ToV27,
  // P13B-S5-R07 — live V24 → NEW V25 + migrateToV25 (the widened production
  // setup plan leaves and the four setup history rows).
  validateSaveV25,
  migrateToV25,
  convertV24ToV25,
} from './save.js'
export type {
  SaveFileV1,
  SaveFileV2,
  SaveFileV3,
  SaveFileV4,
  SaveFileV5,
  SaveFileV6,
  SaveFileV7,
  SaveFileV8,
  SaveFileV9,
  SaveFileV10,
  SaveFileV11,
  SaveFileV12,
  SaveFileV13,
  SaveFileV14,
  SaveFileV15,
  SaveFileV16,
  SaveFileV17,
  SaveFileV18,
  SaveFileV19,
  SaveFileV20,
  SaveFileV21,
  SaveFileV22,
  SaveFileV23,
  SaveFileV24,
  SaveFileV25,
  SaveFileV26,
  SaveFileV27,
  SaveFileV28,
  SaveFileV29,
  SaveFileV30,
  SaveFileV31,
  SaveFileV32,
  SaveFileV33,
  SaveFileV34,
  SaveFileV35,
  SaveFileV36,
  SaveFileV37,
  SaveFileV38,
  SaveFileV39,
  SaveFileV40,
  SaveFileV41,
  SaveFileV42,
  SaveFileV43,
  SaveFileV44,
  SaveFileV45,
  SaveFileV46,
  SaveFileV47,
  // P15B (record 1370-ar), Save48.
  SaveFileP15B,
  SaveFileV48,
  LiveSaveFile,
  SaveFile,
  TalentV1,
  GameStateV1,
} from './save.js'

// ── P13B-S5-R07 Production setup recipes (the rehearsal → Shooting subtask) ──
export {
  SETUP_RECIPES,
  setupRecipeById,
  setupForecast,
  deriveSetupProvenance,
  createProductionSetupRouteResolver,
  validateProductionSetup,
} from './productionSetup.js'
export type { ProductionSetupRecipe } from './productionSetup.js'

// ── P14A.1 The contested talent market (One Contested Expiry Core) ──────────
export {
  initialTalentMarket,
  talentMarketEngaged,
  enteredStudioIds,
  marketEligibility,
  caseForTalent,
  caseOpenForTalent,
  isPremiumTier,
  releaseFloor,
  publicPriorityOrder,
  publicPreferredTerm,
  studioOffer,
  playerOffer,
  playerOfferOptions,
  proposalDraft,
  submitProposal,
  withdrawProposal,
  currentProposals,
  caseDisclosure,
  releaseDisclosure,
  rivalProposalTrigger,
  advanceTalentMarketWeek,
  projectTalentMarketPreV28,
  validateTalentMarketRoot,
  UNKNOWN,
} from './talentMarket.js'
export type {
  DescriptorKey,
  FreezeDrop,
  MarketEligibility,
  MarketCaseView,
  MarketCaseDescriptor,
  ProposalDraft,
  ProposalIntent,
  CaseDisclosure,
  DisclosedProposal,
  ReleaseDisclosure,
  DisclosedPromise,
  Disclosed,
} from './talentMarket.js'

// ── P14B.1 The first kept promise (promises, feasibility, outcomes, trust) ──
export {
  firstTakeReceipts,
  appendFirstTakes,
  allPromises,
  promiseOutcomes,
  promiseFeasibility,
  reclassifyPromise,
  attachPromise,
  advancePromisesWeek,
  breakPromisesOnTermination,
  breakPromisesOnCancel,
  waiverAccepted,
  waivePromise,
  trustDrivers,
  trustDescriptor,
  promiseBuffer,
  proposalDigest,
  promiseDigest,
  attachedPromiseDigest,
  projectPromisesPreV29,
  projectPromisesPreV32,
  validatePromiseRoots,
  validatePromiseRootsV30,
  PROMISE_RULES_VERSION,
  DIRECTING_PROMISE_RULES_VERSION,
  PROMISE_SLACK_WEEKS,
  TRUST_HORIZON_WEEKS,
  WEEKS_TO_FIRST_TAKE,
} from './promises.js'
export type {
  PromiseAttachment,
  PromiseDraft,
  TrustDescriptor,
  TrustDriver,
  TrustDriverKind,
  TrustLabel,
} from './promises.js'

// ── P14B.5 The first shared-work bond (edges, drift, tier, chemistry, root) ──
export {
  advanceRelationshipsWeek,
  recordCancelledAfterFirstTake,
  recordCastingCompetition,
  relationshipsAtV31,
  relationshipsAtV42,
  assertRelationshipsAtV31,
  currentCloseness,
  currentTier,
  currentRomanceValue,
  romanceStatus,
  romanceEndWeek,
  pairChemistry,
  driverGain,
  rosterTies,
  tiersOnRoster,
  relationshipsReasonSentence,
  requireRelationshipsRoot,
  validateRelationshipsRoot,
  projectRelationshipsPreV31,
  hasConflictEvidence,
  RELATIONSHIP_RULES_VERSION,
  RELATIONSHIP_CONFLICT_COMPETITIONS,
  RIVALS_SAME_SLOT_COMPETITIONS,
  RELATIONSHIP_BASELINE,
  RELATIONSHIP_TIERS,
  RELATIONSHIP_TIER_FLOOR,
  RELATIONSHIP_DRIVER_KINDS,
  RELATIONSHIP_DRIVER_KINDS_V31,
  RELATIONSHIP_PROXIMITY_HIGH,
  RELATIONSHIP_PROXIMITY_MID,
  RELATIONSHIP_PROXIMITY_LOW,
  RELATIONSHIP_REPEAT_CAP,
  RELATIONSHIP_SUCCESS_DELTA,
  RELATIONSHIP_FAILURE_DELTA,
  RELATIONSHIP_CANCEL_DELTA,
  RELATIONSHIP_COMPETITION_DELTA,
  RELATIONSHIP_COMPETITION_REPEAT_CAP,
  RELATIONSHIP_SUCCESS_CRITIC_SCORE,
  RELATIONSHIP_FAILURE_CRITIC_SCORE,
  RELATIONSHIP_DRIFT_GRACE_WEEKS,
  RELATIONSHIP_DRIFT_RETURN_WEEKS,
  RELATIONSHIP_RECENT_CAP,
  ROMANCE_FORMATION_THRESHOLD,
  ROMANCE_EXIT_THRESHOLD,
  ROMANCE_PROXIMITY_GAIN,
  ROMANCE_SUCCESS_GAIN,
  ROMANCE_GRACE_WEEKS,
  ROMANCE_DECAY_WEEKS,
} from './relationships.js'
export type { PairChemistry, RelationshipDelta, RosterTie } from './relationships.js'

// ── P13B-S3 Physical plans (persistent queue, dependencies, admission) ───────
export {
  initialPhysicalPlans,
  planQuoteSnapshot,
  planAdmissionView,
  resolvedTargetFacilityId,
  studioPhysicalPlans,
  validatePhysicalPlans,
  admitPhysicalPlans,
  applyPhysicalPlanAction,
} from './physicalPlans.js'
export type { PlanAdmissionView, PhysicalPlanAction } from './physicalPlans.js'
export {
  installationQuoteFingerprint,
  placementQuoteFingerprint,
  physicalQuoteFingerprint,
} from './placement.js'

// ── P06A Release Authority (charter W1) ──────────────────────────────────────
export {
  initialReleaseAuthority,
  mintReleaseCommitmentId,
  releaseCommitmentFor,
  committedReleaseIds,
  commitPictureToReleaseRefusal,
  withReleaseCommitment,
  pruneReleasedCommitments,
  assertReleaseAuthorityInvariants,
  releaseHoldBusyTalentIds,
  RELEASE_COMMITMENT_NAMESPACE,
} from './releaseAuthority.js'

// ── D-14 Talent Career Impact — Star Power progression + frozen career events ──
export {
  computeStarPowerDelta,
  buildTalentCareerEvent,
  starPowerRoleWeight,
  roleDiscipline,
  flattenParticipants,
} from './starPower.js'
export type { StarPowerInput, StarPowerResult, CareerEventInput } from './starPower.js'

// ── P08A Standing & Studio History Spine V1 ──────────────────────────────────
export {
  initialStudioHistory,
  migratedStudioHistory,
  historyRecordedAt,
  StudioHistorySink,
  disabledStudioHistorySink,
  standingDeltas,
  standingChanged,
  classifyHistorySignificance,
  historyDraft,
  commitStudioHistory,
  appendStudioHistory,
  foldRoutineHistory,
  assertStudioHistoryInvariants,
  studioHistoryChronology,
  standingReceipts,
  studioHistoryTimeline,
  studioHistoryRecording,
  filmSubject,
  studioSubject,
  cloneStanding,
  HISTORY_ROUTINE_WINDOW_WEEKS,
  HISTORY_STANDING_MAJOR_DELTA,
} from './studioHistory.js'
export type { StudioHistoryDraft, StudioHistoryFacts } from './studioHistory.js'
export { releaseStandingDrivers, STANDING_FORMULA_VERSION } from './standing.js'
export type {
  StandingChannelKey,
  StandingChangeSource,
  StandingChangeFacts,
  StudioHistorySignificance,
  StudioHistorySubject,
  StudioHistoryEvent,
  StudioHistoryEventKind,
  StudioHistoryState,
  GameStateV17,
  GameStateV18,
  FoundingRegime,
} from './types.js'
export { forecastHistoryForOwner } from './industryCareer.js'
export { exportCurrentState } from './save.js'

// ── P14C.1 Materialized aging — age derived from provenance, never incremented ──
export {
  anchorOf,
  ageAt,
  nextBirthdayWeek,
  provenanceRowFor,
  recomputeDue,
  buildTalentProvenance,
  materializeAges,
  withTalentProvenance,
  birthdaysDueAt,
} from './aging.js'

// ── P14C.2a Retirement lifecycle core (records 773/777) ──
export {
  LIFECYCLE_INTENT_RULES_VERSION,
  RETIREMENT_RECENT_WORK_WEEKS,
  retirementWindow,
  initialCareerLifecycle,
  retirementRecordFor,
  lifecycleStatus,
  contractEndRefusal,
  assignmentRefusal,
  advanceCareerLifecycleWeek,
  // P14C.4 deterministic replenishment (record 793 §4)
  isCohortWeek,
  cohortRequest,
  cohortEntrantAge,
  // P14C.2b — the single final extension and the split step (record 806 §3–§5)
  extensionIssuer,
  commitRetirementExtension,
  advanceLifecycleIntent,
  advanceLifecycleSettlement,
} from './careerLifecycle.js'
export type { LifecycleStatus } from './careerLifecycle.js'
export type { RetirementCause, RetirementStatus, RetirementRecord, CareerLifecycleRoot, GameStateV34, CohortReceipt, CareerLifecycleRootV35, GameStateV35 } from './types.js'
export type { RetirementRecordV36, CareerLifecycleRootV36, MarketCaseVariant, TalentMarketCaseV36, TalentMarketStateV36, GameStateV36 } from './types.js'
export type { GameStateV37 } from './types.js'
// P14C.2b (record 806 §8.4)
export { openMarketCaseFor } from './talentMarket.js'
export { campaignDate } from './calendar.js'
export { SYNCHRONIZED_SOUND, researchWeekQuote, playerTechnologyAccess, technologyAccess, validateTechnologyV2, validateTechnologyV3, liftTechnologyV2, liftTechnologyV3 } from './technology.js'
export { adoptionQuote, equipmentAssets } from './technologyAdoption.js'
export type { AdoptionQuote, AdoptionRequest } from './technologyAdoption.js'
export { productionTechnologyView } from './technologyProduction.js'
export type { StudioTechnology, StudioTechnologyV2, StudioTechnologyV3, TechnologyAction, ResearchProject, ResearchWeekReceipt, ResearchLabContribution, TechnologyAdoption, TechnologyAdoptionComponent, TechnologyEquipmentAsset, ProductionTechnology } from './technologyTypes.js'

export type { GameStateV40, GameStateV41, GameStateV42, GameStateV43, GameStateV44, GameStateV45, GameStateV46, GameStateV47, GameStateV48, ProfessionalPromiseV40, OpportunitySeatClass, OpportunityPredicate, GenreOpportunityPredicate, ProjectOpportunityPredicate, FirstTakeSubject, FirstTakeSubjects,
  GameStateV38, GameStateV39, ProfessionalPromiseV39, DirectorCountPredicate, CareerLifecycleRootV38, TransitionTarget, TransitionRoleTier, TransitionPotentialTier,
  RetirementKey, ProfessionAnchor, TransitionPictureRef, TransitionContextWitness, TransitionTargetInput,
  TransitionInputs, TransitionEvaluation, ProfessionChange, IndustryRetirement, TransitionDue } from './types.js'
export { professionAtWeek, transitionInputsFor, chooseProfessionTransition, advanceProfessionTransitions,
  TRANSITION_RULES_VERSION } from './professionTransitions.js'
// P15C Wave 2 (1359-A §7; 1361-F ruling 19): the Legacy's ref resolver, which its validator uses and
// Wave 3's views will read refs through.
export { legacyRefResolver } from './campaignLegacy.js'
export type { LegacyRef, LegacyRefPlace } from './campaignLegacy.js'

// 1364 (1364-A §3): the recruitment-fund authority `foundingFunding` (Save47).
export {
  initialFoundingFunding,
  validateFoundingFunding,
  recordsFoundingFund,
  TICK_OPEN_DRAFT_REFUSAL,
  type FoundingFund,
  type FoundingFundingAllocation,
  type FoundingFundingContext,
  type FoundingFundingRoot,
} from './foundingFunding.js'
// P15B Waves 2-5 (record 1370-ar): the live condition, loans, closure and notices.
export { CONDITION_PHASE_ID, CONDITION_LAWS, LOAN_LAWS, initialCorporateCondition, requireCorporateCondition, conditionRecord, conditionFacts, closureDue,
  outstandingLoan, loanInstallmentDueFor, advanceCorporateConditionWeek, applyTakeLoan, releaseRefusal, terminableContracts, remedyCapability,
  studioRemedies, validateCorporateConditionRoot } from './corporateConditionLive.js'
export { CLOSURE_LAW_VERSION, CLOSURE_PHASE_ID, initialStudioClosure, requireStudioClosure, closedWeekOf, closureStops, isOperatingStudio, assertOperatingPlayer,
  advanceStudioClosureWeek, closureRecordOf, claimsOfClosure, estateEventsOf, estateView, validateStudioClosureRoot } from './studioClosure.js'
export type { ClosurePhaseOptions, EstateView } from './studioClosure.js'
export { corporateNotices, publicConditionLabel, closureDueWeek } from './corporateNotices.js'
export type { CorporateNotice } from './corporateNotices.js'
export type { StudioConditionRecord, ConditionEvent, StudioLoanRecord, CorporateConditionRoot, ClosureDisposition, ClosureClaim, ClosureClaimPayment,
  EstateLot, ClosureEstate, ClosureReceipt, EstateEvent, ClosureRecord, StudioClosureRoot, P15BStepRoots, GameStateP15B } from './types.js'

// Wave5 browser quotation: expose existing pure owners without duplicating loan arithmetic.
export { loanMaxPrincipal, contractLoan } from './studioLoan.js'
export { studioWeeklyFixedCost } from './powerRankingArchive.js'
// ── P16 (Save46): story properties, four rights, title history, cashless valuation ──
// P17 consumes `permissionFor`/`currentHolder`/`branchAuthority` for continuations and cameos, and calls
// `linkContinuationAtGreenlight` for a continuation with its own concept; P18 consumes `permissionFor(…, 'R4', …)`.
export {
  RIGHTS_ROOT_VERSION, STORY_PROPERTY_ID_PREFIX, ESTATE_HOLDER_PREFIX, R4_CONSUMER_LIVE, SAME_CONCEPT_GREENLIGHT_USE, RIGHTS_TRANSACTION_KINDS, ESTATE_PENDING_REASONS,
  storyPropertyId, parseStoryPropertyId, subjectKey, initialRightsRoot, cutoverRightsRoot, cutoverDowngradeRefusal, validateRightsRoot,
  resolveTitles, authenticTitles, isLegacyDate, currentHolder, holderAt, subjectsHeldBy, rightsAuthority, branchAuthority, licenceInForce,
  materializeLegacyTitles, appendTitleEvent, greenlightRightsRefusal, mintStoryPropertyAtGreenlight, linkContinuationAtGreenlight, mintFilmTitleAtRelease, compareRightsDate,
} from './rights.js'
export type {
  RightsRoot, RightsDate, RightSubject, TitleEvent, TitleCause, TitleSource, StoryProperty, FilmTitle, Licence, LicenceScope,
  RightsOffer, RightsInstrument, RightsTransaction, DiligenceRecord, DisclosureBody, EstateRecord, EstateLot as RightsEstateLot, EstateBid,
  HolderResult, AuthorityResult, BranchAuthority, TitleResolution, ResolvedProperty, ResolvedFilmTitle, TitleEvidence, EstatePending, EstatePendingReason,
} from './rights.js'
export { libraryValuationV1, subjectValueV1, r2CatalogueValue, r1OptionValue } from './propertyValuation.js'
export type { ValuationResult, ValuationItem } from './propertyValuation.js'
export type { GameStateV49, P16LedgerKind } from './types.js'
export type { P16RivalMoneyKind } from './hollywoodTypes.js'
export { P16_RIVAL_MONEY_KINDS } from './hollywoodTypes.js'
export { P16_SAVE_VERSION, P16_PREDECESSOR_SAVE_VERSION, P16_LEDGER_KINDS, validateSaveV49, convertV48ToV49, convertV49ToV48, migrateToV49 } from './save.js'
export type { SaveFileV49 } from './save.js'
// P16B: bilateral sales, licences, diligence, finance law (symmetric: the same functions serve player and rivals).
// Permitted-bidder facts come from P15B's readers through ONE adapter point, `corporateConditionReaders`
// (UNBOUND and fail-closed at base 6510c971 — rightsFinance.ts names the binding the integrator makes).
export { corporateConditionReaders, UNBOUND_CORPORATE_CONDITION_READERS, conditionFactsFor, permittedBidderRefusal, weeklyFixedCost, studioCash, reservedCash, spendableCash, postPurchaseReserve, affordabilityRefusal, moveStudioCash } from './rightsFinance.js'
export type { CorporateConditionReaders, ConditionStageRecord, ConditionFacts } from './rightsFinance.js'
// licence.ts is the ONE licence producer; P17/P18 call `permissionFor` at every boundary they consume a right.
export { licenceGrantRefusal, mintLicence, permissionFor, licenceStatus, licencesHeldBy, activeProductionOn, activeRunOn, blockingEncumbrance, R3_USES, R4_USES, P16_LICENCE_LAW } from './licence.js'
export type { LicenceGrant, LicenceLaw, Permission } from './licence.js'
export { advanceRightsWeek } from './rightsTick.js'
export { offerRefusal, makeOffer, acceptOffer, rejectOffer, withdrawOffer, closingRefusal, instrumentRefusal, resaleHoldbackRefusal, offerCooldownRefusal,
  rivalWillingness, answerRivalOffers, expireOffers, offerParties, instrumentSubject } from './assetSale.js'
export type { OfferInput, PlayerOfferInput } from './assetSale.js'
export { diligenceRefusal, requestDiligence, disclosureFor, disclosureBody, publicDiligenceReceipts } from './dueDiligence.js'
export type { DiligenceInput } from './dueDiligence.js'
export type { DiligenceTarget, DiligenceScopeItem } from './rights.js'
// P16C: estates (typed P15 handoff adapter point) and healthy absorption law/preview.
export { estateHandoffRefusal, openEstate, estateBidRefusal, submitEstateBid, resolveEstate, closeDueEstates, estateWindow, lotEncumbranceRefs } from './estate.js'
export type { EstateHandoff, EstateBidInput } from './estate.js'
export { absorptionRefusal, absorptionDisclosureRefusal, absorptionAsk, rivalAbsorptionWillingness, quoteAbsorption, closeAbsorption, ABSORPTION_CLOSING_PREREQUISITES, ABSORPTION_DISCLOSURE_SCOPE } from './acquisition.js'
export type { AbsorptionInput, AbsorptionQuote, AbsorptionRefusal, AbsorptionContractQuote, AbsorptionProductionQuote, RetentionChoice, ContractRetentionReason, ProductionDisposition, ProductionDispositionReason } from './acquisition.js'

export { buyerScriptConcepts } from './continuedScripts.js'
