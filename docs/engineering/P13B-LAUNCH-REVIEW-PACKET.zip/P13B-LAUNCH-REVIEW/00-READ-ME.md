# P13B launch-review packet

Read 00-P13B-REVIEW-INDEX.md, 01-P13B-LAUNCH-DRAFT.md, 02-P13B-DECISIONS-AND-ACCEPTANCE.md, 03-PAPER-ECONOMICS.md, 04-SOURCE-INDEX.md and 05-INDEPENDENT-REVIEW.md in order. Source index specifies required source sequence.

Reviewed document commit: `15b45afd36ada15ed51e3ba656de6a4a3befb5e7`. This ZIP includes the real documents and required source excerpts. No implementation is authorized. Run `shasum -a 256 -c SHA256SUMS.txt` from this extracted root. Manifest hashes payload files; SHA256SUMS also covers MANIFEST.json, excluding only itself. The outer ZIP checksum is in the separate delivery receipt.
