# REF-O — exact source excerpts

Repository: `HSpector1/The-Movies`
Commit: `e48541b55d8c0825968c4f148996593bdd9f22b6`
Path: `docs/design/CODEX-P13-P15-OWNER-RULINGS.md`
Full source Git blob: `a22798689f7e57fab73116b8c7ef86bda53b3bc7`
Full source SHA-256: `e22a20a2c010bdc6f797e8c0466bc4ee4adabe0212b31b25e41f0f5d77488797`
Full source bytes: 28691

[Immutable source](https://github.com/HSpector1/The-Movies/blob/e48541b55d8c0825968c4f148996593bdd9f22b6/docs/design/CODEX-P13-P15-OWNER-RULINGS.md)

Selected lines only. Historical source; instructions and proposed numbers retain their original authority and are not execution orders.

## Original lines 40–170

```text
## 2. P13 — Eras, Technology & Studio Innovation

### 2.1 Approved boundary

**OWNER APPROVED:**

- one global technology catalogue;
- one shared industry timeline;
- studio-relative research and adoption state;
- technologies whose effects are concrete capabilities, compatibility rules, facilities, costs,
  production consequences, or visible world consequences;
- rivals consuming the same catalogue under the same domain law;
- no cloned private rival technology trees; and
- eventual public standardization.

P13A is bounded to one synchronized-sound transition, one Research Laboratory, one Scientist
assignment, research versus wait, one rival consequence, and one Production/world consequence.

### 2.2 Explicit deferrals

**NOT APPROVED FOR P13 IMPLEMENTATION:** licensing, patents, royalties, technology-rights transfers, and an exact
alternate-history acceleration law. *(Amended 2026-09-10, §2.4.)* Patents remain parked in P16+. Supplier
commercialization of studio-developed technology, including licensing and time-limited royalties, is
Owner-desired later scope: its terms and package placement are undecided. P16+ remains the default placement;
Current Ops recommends a placement and the Owner approves any departure from P16+. P13 preserves the invention
provenance and interfaces it needs. Bounded
early research through investment is Owner direction under §2.4. This deferral covers the global public-rollout
timeline, not the per-studio funded research rate: an R&D budget that accelerates a studio's own qualified
research is Owner direction, while an unlimited alternate-history law that moves the public rollout itself is
still not approved.

### 2.3 Open Owner decisions

**OWNER DECISION OPEN:** exact historical windows; whether and how licensing exists; which
technologies may be skipped; alternate-history acceleration; and precise public-standardization
dates.

None of those decisions may be inferred from the P13A boundary. Licensing and exact alternate-
history acceleration are not part of P13A. *(Amended 2026-09-10: §2.4 records which of these the Owner has
since directed; exact windows, dates, curves and commercial terms remain open.)*

### 2.4 P13 Owner-direction amendment — 2026-09-10

**AMENDMENT STATUS:** OWNER PRODUCT DIRECTION RECORDED · UPDATED P13/FACILITY PLAN, CURRENT OPS REVIEW REQUIRED · NUMERICAL RULES AND COMMERCIAL TERMS PROVISIONAL · FINAL POST-P12 SOURCE REFRESH REQUIRED · GAMEPLAY IMPLEMENTATION NOT AUTHORIZED

**Source:** two Owner messages of 2026-09-10, the second correcting the filming typo in the first, carried in the P13 input kit (`OWNER-DIRECTION-SOURCE-EXCERPTS.md`). This amendment records product direction for P13 only. It changes no P14 or P15 ruling, reopens no P11 acceptance and redirects no running P12 work. The updated plans live in the [P13 design §2A](./CODEX-ERAS-TECHNOLOGY-STUDIO-INNOVATION-PACKAGE-13.md#2a-owner-selected-product-direction--2026-09-10), the [Builder Annex §4.2 matrix](./CODEX-ERAS-TECHNOLOGY-STUDIO-INNOVATION-PACKAGE-13-BUILDER-ANNEX.md#42-owner-direction-analytical-matrix--2026-09-10-candidate), the [facility addendum §6a](./FACILITY-UPGRADES-AND-STUDIO-OVERVIEW-01.md#6a-gap-aware-conversion-and-direct-purchase--2026-09-10-owner-direction) and the [review hub](./FACILITY-MODERNIZATION-CURRENT-OPS-REVIEW.md#owner-direction-update--2026-09-10).

Every statement in this record and in the updated plans carries one of five labels. **OWNER-SELECTED PRODUCT DIRECTION** is the Owner's settled preference; it is not "unapproved" because coding has not begun. **IMPLEMENTATION RECOMMENDATION** is how the plans propose to realize it and may change at Current Ops' activation review. **NUMERICAL/CONTENT HYPOTHESIS** covers every number, curve, date, rate and horizon in examples. **LATER COMMERCIALIZATION SCOPE** covers supplier commercialization, whose terms and package placement remain undecided. **POST-P12 VERIFICATION REQUIRED** marks seams that the final P13 reconnaissance must confirm against accepted P12.

#### 2.4.1 OWNER-SELECTED PRODUCT DIRECTION

1. **Early research, fixed commercial rollout.** Technology can be developed early through meaningful investment. Commercial availability follows a predetermined, historically informed rollout at which compatible upgrades become purchasable by any studio.
2. **Knowledge prerequisites.** Research has genuine prerequisites in the style the Owner cited from Crusader Kings III. Cash accelerates qualified research; it does not bypass missing knowledge, required people, facility capability or necessary work. No empire-strength requirement exists.
3. **Rivals can out-invest.** Rivals research under the same law and can gain the lead.
4. **Named researchers to capacity.** A studio employs multiple named research employees, up to each building's capacity.
5. **R&D budgets.** Each project receives an R&D budget that materially accelerates development the more the studio invests.
6. **Cooperation and diminishing returns.** Researchers and laboratories can work together on one project or split across projects. Two maximum-capacity laboratories on one project produce substantially less than twice one laboratory's output; the Owner suggested about 1.5–1.75× as a balancing direction, not a formula.
7. **Retained progress (7A).** Verified research progress survives cancellation and pausing. Wages and materials already spent remain spent.
8. **Film technology lock (corrected).** Films currently filming keep their existing technology. Films that have not started filming can use new technology.
9. **Persistent queues.** The player queues multiple buildings, conversions and research projects the way The Sims queues actions, with dependencies and parallel laboratories, without constant clicking.
10. **Installation cancellation (10B).** Pay for completed installation work and necessary restoration; recover only genuinely refundable unused commitments.
11. **Inventor pricing.** A studio that developed a technology and then buys or deploys it receives a meaningful own-development price advantage.
12. **Leapfrog purchase (3C) with gap-aware conversion.** A studio never buys obsolete intermediate equipment merely to buy the current version. Modernizing a substantially older or incompatible building may take longer and involve more work than converting a nearly compatible one, following the Owner's stadium analogy.
13. **Forecasts (4B).** Distant developments show forecast windows; public dates become increasingly concrete as release approaches, so a purchase is not blindsided by a predictable launch the following week.
14. **Supplier commercialization desired.** Commercializing studio-developed technology through a supplier, potentially for an upfront payment plus time-limited royalties, is positive product direction. Rates, term, exclusivity, supplier sales behavior and package placement are not selected.

#### 2.4.2 Superseded and re-labeled statements

Historical decisions remain history. The following statements no longer govern current instructions.

| Where | Former statement | Status from 2026-09-10 |
|---|---|---|
| §2.2 above; design §2, §11 law 5, §16, §23 "research versus licensing"; roadmap | licensing, royalties and rights transfers "parked in P16+ unless a later Owner ruling places them elsewhere"; licensing "an optional successor route requiring a separate Owner decision" | Supplier commercialization is Owner-desired **LATER COMMERCIALIZATION SCOPE**. P16+ remains the default placement unless a later Owner ruling places it elsewhere; Current Ops' activation review prepares the recommendation and the Owner settles it. P13 preserves invention provenance and the interfaces it needs. "Licensing is not original-game parity" remains a true source fact and is no longer a reason to exclude the feature. |
| §2.3 above; design §23 "transition dates", §25 | early acceleration undecided; "an exact alternate-history acceleration law" not approved; no defined early-research investment direction | Early, cash-funded research within bounded windows is **OWNER-SELECTED PRODUCT DIRECTION**. Exact windows, dates, curves and acceleration limits remain **NUMERICAL/CONTENT HYPOTHESIS**. Unlimited alternate history is still not promised. |
| §2.3 above; design §23 "can technology be skipped?" | which technologies may be skipped remained open | Direct purchase without obsolete intermediate equipment is direction. Knowledge prerequisites remain; they never become a compulsory equipment-shopping chain. |
| §2.1 and §6 above; design §23 substrate rows, §26; Annex §1 | one Laboratory and one Scientist as the bounded proof; "P13A proves research versus wait" | The single laboratory/person/sound demonstration remains a useful early checkpoint. It does not establish completion of multi-person staffing, budgets, cooperation, parallel projects or queues, which are the intended experience. |
| design §12.2, §12.3; Annex §3.3, §3.4, receipt sketch | cancelled research "preserves spent work only if the catalogue explicitly defines it"; "zero or catalogue-defined retained work" | Superseded by 7A: verified research work is always retained and may seed exactly one restart. Installation cancellation follows 10B. |
| facility addendum §6, §9, §10 stage 3; design §3.2 | scheduled-after-work admission and queues are "later work"; "no scheduled-after-work promise yet" | Persistent plan queues are direction. They still need not block inventory or the first ordinary retrofit; they are no longer deferred beyond the intended experience. |
| facility addendum §7, §12; hub "Cancellation differs by scope" | "no voluntary post-commit abort" recommended for the first ordinary retrofit | Remains a recommendation for ordinary P09 work only. Technology installation cancellation follows 10B; the plans recommend aligning ordinary work with 10B, which Current Ops decides. |
| design §12.1 `inFlightGrace`, §27 journey 17; Annex §3.5 | "in-flight" undefined beyond a catalogue grace rule | In-flight means first actual filming has begun. Creation, development, greenlight and queue entry do not lock technology. |
| design §16 | research expense allowed only "where P11 law permits explicit project expense" | A per-project R&D budget ceiling, charged through P11 only for usable work, is direction; P11 still owns debit timing and categories. |
| design §23 "forecast precision" | bounded window only | Bounded window for distant developments, concrete public date near release. The near-release horizon is a hypothesis. |
| design §24 question 8 | whether multiple laboratories add parallelism, reliability or only capacity | Answered in direction: both cooperation with diminishing returns and parallel projects. |
| design §2, §3.2, §11 law 5, §12.2, §14, §16, §23; Annex §3.2, §4, §5.3, §10, §16.3; addendum §§4, 7, 10; hub ownership table | the studio's route set closed at research and wait, with licensing the only contemplated addition | A third `purchase` route is Owner direction, legal from commercial release and priced, so a studio that neither researched nor waited can buy the current version (design §12.1a). Adoption, work orders, cancellation and history are unchanged. Whether P13A's own fixture proves it is a Current Ops scope question. |

#### 2.4.3 Preserved, recommended and still open

**Preserved:** one global catalogue and timeline; symmetric player/rival law; no private rival trees; no generic quality bonus; no hidden era penalty; eventual public standards without blanket mandatory replacement; P08/P09/P10/P11/P12 ownership; P09's separate Builder obligation; visual lot experience, honest counts, exact navigation, one-owner finance, migration and rival-symmetry protections; FUP-001–FUP-019 and every existing P13 requirement and proof obligation. Commercial release never makes old equipment unusable by itself.

**IMPLEMENTATION RECOMMENDATION:** capability-based delivery under the later outcome-first order (design §2A: core, ready, later); six separated facts (eligibility, progress, commercial availability, installation, operational capability, standard); budget as a ceiling with disclosed marginal benefit and bottleneck; decomposed inventor quotes; gap-aware conversion descriptors; plan queues with execution-time revalidation inside player-approved authority; the technology lock at first actual filming; supplier-agreement interfaces. Difficult parts are sequenced, not discarded; no later commercial feature is a prerequisite of the first research experience.

**NUMERICAL/CONTENT HYPOTHESIS (Current Ops activation review decides):** research-work quantities, budget tiers and saturation, the concentration factor (whose value is 0.75–0.875, being what makes the **total** output of two cooperating laboratories land inside the Owner's 1.5–1.75×; the two must never be confused, see [catalogue §5.3](./STUDIO-UPGRADE-AND-RESEARCH-CATALOGUE-01.md#53-parallel-profiles-and-the-corrected-concentration-law)), early-research bounds and fixed commercial milestones, concession rates and eligible components, conversion descriptors, the near-release disclosure horizon, admission-policy default, restoration and refund components, and every example in the Annex matrix.

**LATER COMMERCIALIZATION SCOPE:** royalty rate and basis, upfront pricing, term, exclusivity, early supplier launch versus the fixed milestone, commercial obsolescence, independent rival invention, transfer and co-development entitlement, final package placement.

**POST-P12 VERIFICATION REQUIRED:** the accepted production lifecycle's first-filming seam; the authorized employment action for researchers; P12 conserved resources funding rival budgets; P11 quote/commit symbols and refundable-commitment dispositions; and the migration starting version from the accepted save head. *(The calendar item is closed as of 2026-09-11: the shared calendar is a delivered P12 producer per handoff `13370d4`, and §2.6 records what that does and does not settle.)*

**The catalogue that gives this direction content.** [The Studio Upgrade and Research Catalogue](./STUDIO-UPGRADE-AND-RESEARCH-CATALOGUE-01.md) disposes of all 58 proposed candidates and the research briefs, anchors its numbers to the accepted blueprints, and works out the Owner's direct Office I→III route including the accepted prerequisite that currently blocks it. It is an **IMPLEMENTATION RECOMMENDATION** throughout and approves no tuning.

**Not done here:** no gameplay coding, tests, schemas, saves, assets, tuning constants, new package number, coding order, PR, merge, P11 reopening or P12 redirection. The separate multi-campaign save library is not implemented; P13 state stays campaign-specific and Save/Load restores it without rerolling or sharing research between campaigns.

### 2.5 Owner response to the catalogue — 2026-09-11

**OWNER-SELECTED PRODUCT DIRECTION.** The Owner reviewed the Studio Upgrade and Research Catalogue at commit `b7824988a80b170363c08ac7a809498729d84d04` and returned five directions. They are settled and are not to be re-asked. Nothing outside these five is approved by this response, and no new approval may be inferred from it.

1. **Inventor benefits are accounted by component.** Legitimate benefits coexist when they concern different costs. No expense is credited twice, and usable equipment already produced and paid for is never charged again. The catalogue's earlier recommendation that an inventor take only the larger of two credits is withdrawn.
2. **Cooperation and splitting are both legitimate.** Researchers may cooperate on one project or split across projects. One example built from identical projects does not establish that splitting is always inferior.
3. **The research department's existence is settled.** Laboratories, named researchers, staffing capacity and research budgets are selected product direction and are not to be put to the Owner again. What remains is to define the missing implementation and its dependencies.
4. **Renovation need not be cheaper than new construction.** Meaningful upgrade, expansion, new-build and waiting alternatives are all preserved.
5. **Direct Office I→III conversion without purchasing Office II remains selected.** Under comparable conditions it takes substantially longer than II→III. The illustrative 4, 8 and 16 weeks are not approved tuning.

**Current Ops note, not Owner text.** The withdrawn no-stacking recommendation had also departed from accepted design §16a.2, which already decomposed the quote into technology/access, equipment, site adaptation and installation and already billed prototype equipment once. Item 1 restores agreement with the accepted product as well as with the Owner.

**Also recorded by the same response.** The proposed five-times money scale is a hypothesis, not Owner approval. New-build Office III prerequisite removal and any below-target research-scaling exceptions remain recommendations pending disposition. Equipment rental and supplier commercialization remain later proposals unless separately selected.

**Where the corrections live.** [Catalogue §9.2](./STUDIO-UPGRADE-AND-RESEARCH-CATALOGUE-01.md#92-inventor-against-commercial-buyer-whole-life) recomputes inventor pricing by component, the dependency-respecting schedule and the whole-life comparison; [§9.4](./STUDIO-UPGRADE-AND-RESEARCH-CATALOGUE-01.md#94-research-allocation-when-concentrating-helps-and-when-splitting-helps) tests research allocation across seven fixtures; [§11](./STUDIO-UPGRADE-AND-RESEARCH-CATALOGUE-01.md#11-decision-register) is the decision register that separates settled direction from everything else.

### 2.6 Bounded reconciliation of the catalogue — 2026-09-11

**CURRENT OPS DIRECTION, NOT OWNER PRODUCT DIRECTION. NO NEW APPROVAL.** A bounded reconciliation of the corrected catalogue at `4dd3eb895fd65660e57268b0f878481ac1912d0c` was directed on the same day, to settle its economic conclusions and its decision classification before they support launch decisions. It is documentation and paper analysis only, it selects nothing, and no approval may be inferred from it. It records explicitly that the five-times pricing scale, the illustrative office durations, and recommendations ENG-2 and ENG-3 all remain provisional, and that equipment rental and any hire route for scarce capabilities remain later proposed scope unless separately selected.

**What it settled, without changing any Owner direction.** The operating-charge rule was corrected to the accepted one, which grants a body's new Opex at `operational` rather than at part-completion. Four weekly rates that had been labelled as the proposed five-times scale were traced to the catalogue's own accepted-anchored class bands, and the one place the two scales disagree is disclosed under ENG-1. The existing-department comparison was completed over the same 52 weeks: developing is $60,000 cheaper in project expenditure, $67,200 dearer to run for the twenty-eight extra weeks it holds the capability, and so **$7,200 dearer in horizon cash**, with the economic benefit of twenty-eight earlier weeks left unpriced rather than converted into invented revenue. The overlapped schedule's cash was recomputed from its own dates. The twenty-four-stage figure is bounded to the formula that produces it. The allocation conclusions are bounded to the model that produced them, so the rejected universal claim is not replaced by another one. The whole calculation is published in [catalogue §9.7](./STUDIO-UPGRADE-AND-RESEARCH-CATALOGUE-01.md#97-the-whole-calculation-compactly) as labelled paper analysis.

**Decision classification.** Because item 3 above is settled, the missing foundations of laboratories, researchers, staffing and budgets are recorded as **implementation prerequisites for Current Ops to sequence**, PREQ-1 to PREQ-10 in the catalogue register, and are separated there into those the first sound film needs and those it does not. They are not put to the Owner again. Two identifiers moved and both remain resolvable: OPEN-1 became PREQ-1, and OPEN-3, a hire route for scarce capabilities, became LATER-5 beside equipment rental.

**One tension in that second move, disclosed rather than glossed.** OPEN-3 sat in a class whose decider was the Owner, and a Current Ops direction moved it into a class headed "nothing here needs a decision now", while §6 below says every decision marked open in this record remains an Owner decision. The move records **scope**, not a resolution: the hire route is unselected either way, LATER-5 states that a separate selection would be needed to open it, and the Owner may return it to the open class at any time. Nothing about the route was decided by reclassifying it.

**Calendar status.** The shared calendar now exists as a delivered P12 producer, `campaignDate()` mapping week 0 to 1920 Week 1 under `campaign-calendar-1920-52/v1` with `market.tick` authoritative ([P12 to P13 producer handoff `13370d4`](https://github.com/HSpector1/The-Movies/blob/13370d428f0693f3279732f6f4cc360a7fcaa4df/docs/engineering/P12-TO-P13-PRODUCER-HANDOFF.md)). The same handoff records that the calendar does not itself deliver technology, so exact per-entry technology dates remain a P13 recommendation. Only that published handoff was read; deeper reconnaissance of accepted code belongs to the launch-preparation assignment. P13 execution still requires a separate Current Ops order.

---

```
