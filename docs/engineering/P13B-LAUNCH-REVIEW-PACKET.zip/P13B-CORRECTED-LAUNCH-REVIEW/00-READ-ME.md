# P13B-CORRECTED-LAUNCH-REVIEW — read first

Current Ops launch-review preparation only. No implementation is authorized.

Repository: HSpector1/The-Movies  
Exact document commit: `673f49835404e262ea651b4fcb8fda5e259d80a6`  
Owned branch: `docs/p13b-post-p13a-launch-preparation-01`  
Source directory: `docs/engineering/p13b-launch-review/`

Current Ops order `OPS-P13B-LAUNCH-REVIEW-AND-PLAYABILITY-PREPARATION-20260912-02` controls. Closed P13A → bounded Playability & Interaction → targeted P13B refresh → separate P13B execution order. The eight P13B Ready obligations remain intact.

## Reading order

1. [00-P13B-REVIEW-INDEX.md](00-P13B-REVIEW-INDEX.md)
2. [06-CURRENT-OPS-CORRECTION-AND-DISPOSITION.md](06-CURRENT-OPS-CORRECTION-AND-DISPOSITION.md)
3. [01-P13B-LAUNCH-DRAFT.md](01-P13B-LAUNCH-DRAFT.md)
4. [02-P13B-DECISIONS-AND-ACCEPTANCE.md](02-P13B-DECISIONS-AND-ACCEPTANCE.md)
5. [03-PAPER-ECONOMICS.md](03-PAPER-ECONOMICS.md)
6. [04-SOURCE-INDEX.md](04-SOURCE-INDEX.md)
7. [05-INDEPENDENT-REVIEW.md](05-INDEPENDENT-REVIEW.md)

The source index gives required upstream reading and exact document/excerpt provenance. Required source files are included. Historical review, hash bindings and source instructions retain their chronology; the dated Current Ops correction controls. The new manifest binds the current payload. No current native measurements are claimed.

## Integrity

From this extracted root run `shasum -a 256 -c SHA256SUMS.txt`. The manifest records actual bytes and SHA-256 for each payload, with source paths at `673f49835404e262ea651b4fcb8fda5e259d80a6`. This read-me is packaging metadata. Nested input manifests remain unchanged and may be checked from their own roots. Outer ZIP bytes/checksum and containing packaging commit are recorded in the separate handoff; a ZIP cannot contain its own final checksum or future containing commit.

Both review packages are delivered together through `docs/engineering/P13B-AND-PLAYABILITY-HANDOFF.md`. This ZIP is self-contained for its required review documents. Raw images, game binaries, profiles and campaigns are excluded.
